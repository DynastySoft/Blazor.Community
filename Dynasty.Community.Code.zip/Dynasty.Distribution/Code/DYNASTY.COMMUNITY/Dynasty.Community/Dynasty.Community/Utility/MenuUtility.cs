﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Local;
using Dynasty.Database;

namespace Dynasty.ASP
{
	internal static class modMenuUtility
	{
		private static clsDynastyUtility moUtility = new clsDynastyUtility();

		public static bool LoadMenu(ref clsDatabase cur_db, string language_type, ref List<Models.clsMainMenu> menu_list, ref string[,] user_security, string root_name = "", bool root_only_fl = false, string app_id = "")
		{

			bool return_value = false;
			clsRecordset cur_set = new clsRecordset(ref cur_db);
			clsRecordset security_set = new clsRecordset(ref cur_db);
			string menu_caption = "";
			string web_page = "";
			string menu_name = "";
			string order_id = "";
			string last_order_id = "";
			string function_len = "";
			string sql_str = "";

			int menu_id = 1;
			int menu_level = 0;
			int parent_menu = 0;

			int[] parent_list = new int [] { 0, 0, 0, 0, 0, 0 };

			clsGeneral o_gen = new clsGeneral(ref cur_db);

			try
			{

				//if (cur_db.iUserType_id < clsConstant.USER_DIRECTOR_TYPE)
				//{
				//	cur_db.uSecurity.bDoNotShowMyFavorites_fl = true;
				//	cur_db.uSecurity.bDoNotShowDashBoard_fl = true;
				//}

				// GetWebModuleID() is used only for the page-level security. For anything else, cur_db.sCurProgram_nm has to be used
				////
				//if (!modSecurity.GetUserSecurity(ref cur_db, modGeneralUtility.GetWebModuleID(), cur_db.sUserGroup_cd, ref security_set, ref user_security))
				//{
				//	return return_value;
				//}

				if (cur_db.CurrentDatabaseType() == GlobalVar.goConstant.DB_ORACLE_TYPE || cur_db.CurrentDatabaseType() == GlobalVar.goConstant.DB_MYSQL_TYPE)
				{
					function_len = "LENGTH";
				}
				else
				{
					function_len = "LEN";
				}

				// If this user uses a foreign language, need to translate the menu here.
				// 
				if (moUtility.IsEmpty(cur_db.sLanguage_cd))
                {
					sql_str = "SELECT * FROM tblGOMenuNames";		// Be careful, Oracle does not accept the combination of * and extra field name with alias
				}
				else
                {
					sql_str = "SELECT tblGOMenuNames.*, tblGOLanguageTranslator.sLocal AS sMenuLabel";
					sql_str += " FROM tblGOMenuNames LEFT JOIN tblGOLanguageTranslator ON (tblGOMenuNames.sMenu_nm = tblGOLanguageTranslator.sMenu_nm AND tblGOLanguageTranslator.sPage_nm = 'MAINMENU' AND tblGOLanguageTranslator.sLanguage_cd = '" + cur_db.sLanguage_cd + "')";
				}

				sql_str += SelectMenuItemsByVersion(ref cur_db, app_id);

				if (root_only_fl)
				{
					sql_str += " AND " + function_len + "(sDisplayOrder_id) = 2";
				}
				else if (moUtility.IsNonEmpty(root_name))
				{
					sql_str += " AND (" + function_len + "(sDisplayOrder_id) = 2 OR sDisplayOrder_id LIKE '" + root_name + "%')";
				}

#if (SaaS == false)
	sql_str += " AND sWebPage_nm <> 'pathfinder'";      // Let SAAS version have this feature only for now.
#endif

                sql_str += " ORDER BY sDisplayOrder_id";

				if (cur_set.CreateSnapshot(sql_str) == false)
				{
					return false;
				}

				while (cur_set.EOF() == false)
				{

					modGeneralUtility.RunEvents();

					if (moUtility.IsEmpty(cur_db.sLanguage_cd))
					{
						menu_caption = cur_set.sField("sDescription");
					}
					else
                    {
						menu_caption = cur_set.sField("sMenuLabel");
					}

					menu_name = (cur_set.sField("sMenu_nm"));
					web_page = (cur_set.sField("sWebPage_nm"));
					order_id = (cur_set.sField("sDisplayOrder_id"));

					if (moUtility.SUCase(web_page) == "USER")
                    {
						web_page = "UserProfile";		// Blazor version uses different name.
                    }

					// Switch the page names that are platinum-specific
					// If cur_db.sCurProgram_nm = goConstant.PLMENU_NAME Then
					if (moUtility.SUCase(web_page) == moUtility.SUCase("SummaryAccounts"))
					{
						web_page = "GLSummaryAccounts";
					}
					//End If

					if ((cur_set.iField("iDisabled_fl") == 0) && !(cur_set.sField("sMenu_nm") == "mnuHelpAdvisor" && moUtility.IsNonEmpty(cur_db.sCurFiscalYear)))
					{
						// Check if this menu is to be included.
						//
						if (CheckMenuToInclude(ref cur_db, cur_set))
						{
                            //if (cur_db.iUserType_id > clsConstant.USER_DIRECTOR_TYPE || security_set.FindRecord("sMenu_nm", order_id))		// Directors should go thru screen security
                            //{
                                // Each level has two letters.
                                //
                                menu_level = (int)(moUtility.SLength(order_id) / 2);        // Menu level starts with 1.

                                if (menu_level == 1)
                                {
                                    parent_menu = 0;
                                }
                                else if (moUtility.SLength(order_id) > moUtility.SLength(last_order_id))
                                {
                                    parent_menu = menu_id - 1;
                                }
                                else if (moUtility.SLength(order_id) < moUtility.SLength(last_order_id))
                                {
                                    parent_menu = parent_list[menu_level - 1];
                                }

								// 05/20/2025
                                //menu_list.Add(new Models.clsMainMenu { iMenuLevel = menu_level, iMenu_id = menu_id, iParentMenu_id = parent_menu, sPage_nm = web_page, sMenu_nm = menu_caption, bExpended_fl = false});
                                menu_list.Add(new Models.clsMainMenu { iMenuLevel = menu_level, iMenu_id = menu_id, iParentMenu_id = parent_menu, sPage_nm = web_page, sMenu_nm = menu_name, bExpended_fl = false, sDescription = menu_caption });

                                parent_list[menu_level] = menu_id;      // Keep the latest menu-id for each level
                                last_order_id = order_id;
                                menu_id += 1;
                            //}
                        }
					}

					cur_set.MoveNext();
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadMenu)");
			}

			return return_value;
		}
		public static string SelectMenuByVersion(ref clsDatabase cur_db)
		{

			string return_value = "";
			string sql_str = "";
			string function_len = "";

			if (cur_db.CurrentDatabaseType() == GlobalVar.goConstant.DB_ORACLE_TYPE || cur_db.CurrentDatabaseType() == GlobalVar.goConstant.DB_MYSQL_TYPE)
			{
				function_len = "LENGTH";
			}
			else
			{
				function_len = "LEN";
			}

			if (moUtility.IsEmpty(cur_db.sCurProgram_nm) || cur_db.sCurProgram_nm == GlobalVar.goConstant.PLMENU_NAME || cur_db.sCurProgram_nm == GlobalVar.goConstant.ENMENU_NAME)
			{
				// Platinum & Enterprise are selected by sModule_id, already
			}
			else // Dynasty.ASP & Professional
			{
				sql_str += " AND (";
				sql_str += " " + function_len + "(sDisplayOrder_id) = 2 ";
				sql_str += " OR sDisplayOrder_id LIKE '__" + modConstant.WEB_MENU_ORDER_OF_SM + "%'";
				sql_str += " OR sDisplayOrder_id LIKE '__" + modConstant.WEB_MENU_ORDER_OF_AR + "%'";
				sql_str += " OR sDisplayOrder_id LIKE '__" + modConstant.WEB_MENU_ORDER_OF_AP + "%'";
				sql_str += " OR sDisplayOrder_id LIKE '__" + modConstant.WEB_MENU_ORDER_OF_GL + "%'";
				sql_str += " OR sDisplayOrder_id LIKE '__" + modConstant.WEB_MENU_ORDER_OF_IV + "%'";
				sql_str += " OR sDisplayOrder_id LIKE '__" + modConstant.WEB_MENU_ORDER_OF_NP + "%'"; // Should always be visible, and they need to disable this in group security
				if (cur_db.sCurProgram_nm == GlobalVar.goConstant.GOMENU_NAME)
				{
					sql_str += " OR sDisplayOrder_id LIKE '__" + modConstant.WEB_MENU_ORDER_OF_WO + "%'";
					sql_str += " OR sDisplayOrder_id LIKE '__" + modConstant.WEB_MENU_ORDER_OF_WH + "%'";
					sql_str += " OR sDisplayOrder_id LIKE '__" + modConstant.WEB_MENU_ORDER_OF_MF + "%'";
					sql_str += " OR sDisplayOrder_id LIKE '__" + modConstant.WEB_MENU_ORDER_OF_RM + "%'";
					sql_str += " OR sDisplayOrder_id LIKE '__" + modConstant.WEB_MENU_ORDER_OF_SO + "%'";
					sql_str += " OR sDisplayOrder_id LIKE '__" + modConstant.WEB_MENU_ORDER_OF_PO + "%'";
					sql_str += " OR sDisplayOrder_id LIKE '__" + modConstant.WEB_MENU_ORDER_OF_FA + "%'";
					sql_str += " OR sDisplayOrder_id LIKE '__" + modConstant.WEB_MENU_ORDER_OF_RM + "%'";
				}
				sql_str += ")";
			}

			return_value = sql_str;

			return return_value;
		}

        public static bool CheckMenuToInclude(ref clsDatabase cur_db, clsRecordset cur_set)
		{

            bool return_value = true;

			if (moUtility.IsSystemAdministrator(cur_db) || moUtility.IsSystemSuperUser(cur_db))
            {
				return true;
            }

            // 01/31/2020  If only WMS(IV, S/O and P/O) is implemented, 
            //
            if ((cur_db.uProgram.bAPExist_fl == false) && (cur_db.uProgram.bARExist_fl == false ) && cur_db.uProgram.bIVExist_fl && cur_db.uProgram.bWHExist_fl)
            {

                if (cur_db.uProgram.bSOExist_fl && cur_set.iField("iModule_id") == clsConstant.DYNASTY_MODULE_ID_AR)
                {

                    if (moUtility.SUCase(cur_set.sField("sMenu_nm")) == moUtility.SUCase("mnuSetupAR") || moUtility.SUCase(cur_set.sField("sMenu_nm")) == moUtility.SUCase("mnuSetupARCustomer") || moUtility.SUCase(cur_set.sField("sMenu_nm")) == moUtility.SUCase("mnuSetupARTerms"))
                    {
                        return_value = true; // Because S/O needs customer with terms information
                    }
                    else
                    {
                        return_value = false;
                    }

                }
                else if (cur_db.uProgram.bPOExist_fl && cur_set.iField("iModule_id") == clsConstant.DYNASTY_MODULE_ID_AP)
                {

                    if (moUtility.SUCase(cur_set.sField("sMenu_nm")) == moUtility.SUCase("mnuSetupAP") || moUtility.SUCase(cur_set.sField("sMenu_nm")) == moUtility.SUCase("mnuSetupAPVendor") || moUtility.SUCase(cur_set.sField("sMenu_nm")) == moUtility.SUCase("mnuSetupAPTerms"))
                    {
                        return_value = true; // Because P/O needs vendor with terms information
                    }
                    else
                    {
                        return_value = false;
                    }

                }

            }

            return return_value;

		}
		public static string SelectMenuItemsByVersion(ref clsDatabase cur_db, string app_id = "")
		{

			string return_value = "";

			return_value = " WHERE iDisabled_fl = 0";


            // In Community verson, only SA can access user profile.
            //
            if (cur_db.CommunityVersion && moUtility.IsSystemAdministrator(cur_db) == false)
            {
                return_value += " AND sWebPage_nm <> 'UserProfile'";
            }

            // Community version does not have page-level security.  Just show all pages.
            //
            if (cur_db.CommunityVersion == false && moUtility.IsSystemAdministrator(cur_db) == false)
            {
                return_value += " AND sDisplayOrder_id IN (SELECT sMenu_nm FROM tblGOUserGroupSecurity WHERE sModule_id = '" + modGeneralUtility.GetWebModuleID() + "' AND sUserGroup_cd = '" + cur_db.sUserGroup_cd + "')";
            }

            // APP-specific
            //
            if (moUtility.IsNonEmpty(app_id))
            {
				return_value += " AND sModule_id = '" + app_id + "'";
			}
			else
            {
				return_value += " AND sModule_id = '" + modGeneralUtility.GetWebModuleID() + "'";
			}

			// Exclude Inquiry which is for Platinum and SAAS version only.
			//
			if (cur_db.sCurProgram_nm != GlobalVar.goConstant.PLMENU_NAME && cur_db.sCurProgram_nm != GlobalVar.goConstant.SSMENU_NAME)
            {
				return_value += " AND tblGOMenuNames.sMenu_nm NOT LIKE 'mnuInquiry%'";     // DO NOT USE iVersion_id < 50  because M/C is a part of PL and can be sold separately.
			}

			// Version-specific
			//
			return_value += " AND (iVersion_id = 0 OR ( ";
			if (cur_db.sCurProgram_nm == GlobalVar.goConstant.PLMENU_NAME || cur_db.sCurProgram_nm == GlobalVar.goConstant.SSMENU_NAME)
			{
				return_value += " iVersion_id <= 50 ";
			}
			else if (cur_db.sCurProgram_nm == GlobalVar.goConstant.ENMENU_NAME)
			{
				return_value += " iVersion_id <= 40 ";
			}
			else if (cur_db.sCurProgram_nm == GlobalVar.goConstant.GOMENU_NAME)		// Professional verion
			{
				return_value += " iVersion_id <= 35 ";
			}
            else if (cur_db.sCurProgram_nm == GlobalVar.goConstant.DYMENU_NAME)		// Community version
            {
                return_value += " iVersion_id = 30 ";
            }
            else        // if industry-specific
            {
                return_value += " iVersion_id <= 20 ";
            }
            return_value += "))";

			// SPecific modules.
			//
			return_value += " AND iModule_id IN (0";
			return_value += "," + clsConstant.DYNASTY_MODULE_ID_SM.ToString();

			if (cur_db.uProgram.bGLExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_GL.ToString();
			}
			if (cur_db.uProgram.bIVExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_IV.ToString();
			}
			if (cur_db.uProgram.bARExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_AR.ToString();
			}
			if (cur_db.uProgram.bAPExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_AP.ToString();
			}
			if (cur_db.uProgram.bSOExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_SO.ToString();
                if (! cur_db.uProgram.bARExist_fl && cur_db.uProgram.bIVExist_fl && cur_db.uProgram.bWHExist_fl ) 
                {
                    return_value += "," + clsConstant.DYNASTY_MODULE_ID_AR.ToString();          // 01/31/2020 Because S/O needs customer and terms info at the minimal
                }
			}
			if (cur_db.uProgram.bPOExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_PO.ToString();
                if (!cur_db.uProgram.bAPExist_fl && cur_db.uProgram.bIVExist_fl && cur_db.uProgram.bWHExist_fl)
                {
                    return_value += "," + clsConstant.DYNASTY_MODULE_ID_AP.ToString();          // 01/31/2020 Because S/O needs customer and terms info at the minimal
                }
            }
			if (cur_db.uProgram.bWHExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_WH.ToString();
				//return_value += "," + clsConstant.DYNASTY_MODULE_ID_RMA.ToString();
			}
			if (cur_db.uProgram.bRCExist_fl)
			{
				//return_value &= "," & goConstant.DYNASTY_MODULE_ID_RC.ToString
			}
			if (cur_db.uProgram.bMFExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_MFG.ToString();
			}
			if (cur_db.uProgram.bCMExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_CRM.ToString();
			}
			if (cur_db.uProgram.bWOExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_WO.ToString();
			}

			if (cur_db.uProgram.bMCExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_MC.ToString();
			}
			if (cur_db.uProgram.bPRExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_PR.ToString();
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_HR.ToString();
			}
			if (cur_db.uProgram.bBRExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_BR.ToString();
			}
			if (cur_db.uProgram.bJCExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_JC.ToString();
			}
			if (cur_db.uProgram.bFAExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_FA.ToString();
			}

			// Industry-specific modules and 
			//
			if (cur_db.uProgram.bNPExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_NP.ToString();
			}
			if (cur_db.uProgram.bRTExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_RENTAL.ToString();
			}
			if (cur_db.uProgram.bIEExist_fl)
			{
				return_value += "," + clsConstant.DYNASTY_MODULE_ID_IMPORT.ToString();
			}

			return_value += " )";


            if (cur_db.iVertical_id > 0)
			{
				return_value += " AND ( iVertical_id =  0 OR iVertical_id = " + cur_db.iVertical_id.ToString() + " )";
			}

			return return_value;

		}

	}

}
