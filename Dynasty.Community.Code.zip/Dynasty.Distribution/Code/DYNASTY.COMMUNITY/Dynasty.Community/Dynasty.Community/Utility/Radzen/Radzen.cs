﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//

using System;
using System.Globalization;

using Dynasty.Database;

// This is a utility file for Radzen chart
//
namespace Dynasty.ASP
{
    internal static class modRadzen
    {
        public const string SMOOTH = "Smooth Lines";
        public const string SHOW_DATA_LABEL = "Show Data Labels";
        public const string LINE_LIMIT_WARNING = "10 Lines Max.";
        public const int MAX_LINES = 10;

        public static bool chkSmooth_fl = true;
        public static bool chkShowDataLabels_fl = false;
        public static bool bShowLineLimits = false;

        public static bool chkPeriodic_fl = true;
        public static bool chkFinalcial_fl = true;
        public static bool chkBalance_fl = true;

        private static clsDynastyUtility moUtility = new clsDynastyUtility();

        public static bool GetLineChartData(ref clsDatabase cur_db, ref clsRadzenChart[] cur_chart, string[,] cur_data, string[] captions, int total_col, int total_row, bool summary_fl)
        {
            bool return_value = true;
            int row_num = 0;
            int col_num = 0;

            try
            {
                bShowLineLimits = false;

                if (total_row == 0)
                {
                    return false;
                }

                if (total_row > MAX_LINES)
                {
                    total_row = MAX_LINES;          // No more than max lines
                    bShowLineLimits = true;
                }

                cur_chart = new clsRadzenChart[total_row];

                for (row_num = 0; row_num < total_row; row_num++)
                {
                    cur_chart[row_num] = new clsRadzenChart();
                    cur_chart[row_num].Data = new clsRadzenChart.clsData[total_col - 1];

                    for (col_num = 0; col_num < total_col - 1; col_num++)
                    {
                        cur_chart[row_num].Data[col_num] = new clsRadzenChart.clsData();

                        if (summary_fl && total_row == 1)
                        {
                            cur_chart[row_num].Title = cur_db.oLanguage.oCaption.SUMMARY;
                            cur_chart[row_num].Data[col_num].Category = captions[col_num];
                            cur_chart[row_num].Data[col_num].Value = moUtility.ToValue(cur_data[col_num, row_num]);
                        }
                        else
                        {
                            cur_chart[row_num].Title = moUtility.IIf(moUtility.IsNonEmpty(cur_data[0, row_num]), cur_data[0, row_num], cur_db.oLanguage.oCaption.UNKNOWN);
                            cur_chart[row_num].Data[col_num].Category = captions[col_num + 1];                              
                            cur_chart[row_num].Data[col_num].Value = moUtility.ToValue(cur_data[col_num + 1, row_num]);     // [col_num + 1] is because the first column is the summary group-id.
                        }
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + " GetLineChartData()");
            }

            return return_value;
        }

        public static bool GetPieData(ref clsDatabase cur_db, ref clsRadzenChart.clsData[] chart_rec, string[] cur_data, string[] captions, int total_col)
        {
            bool return_value = false;
            int i = 0;

            try
            {
                chart_rec = new clsRadzenChart.clsData[total_col];

                for (i = 0; i < total_col; i++)
                {
                    chart_rec[i] = new clsRadzenChart.clsData();

                    chart_rec[i].Category = captions[i];

                    chart_rec[i].Value = moUtility.ToValue(cur_data[i]);
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + " GetPieData()");

            }

            return return_value;
        }

        public static string FormatValue(object value)
        {
            //return ((double)value).ToString("C0", CultureInfo.CreateSpecificCulture("en-US"));    // Meaning Currency with 1 decimal

            if (value != null)
            {
                return ((double)value).ToString("N0", CultureInfo.CreateSpecificCulture("en-US"));      // Meaning General number with 0 decimal
            }

            return string.Empty;

        }

        public static string FormatAsMonth(object value)
        {
            if (value != null)
            {
                return Convert.ToDateTime(value).ToString("MMM");
            }

            return string.Empty;
        }

    }
}