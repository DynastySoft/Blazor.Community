﻿//  Copyright (c) DynastySoft Corp, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Dynasty.Database;

// This is for Radzen chart
//
namespace Dynasty.ASP
{
    public class clsRadzenChart
    {
        public string Title = "";

        public class clsData
        {
            public string Category { get; set; }
            public decimal Value { get; set; }
        }

        public clsData[] Data = new clsData[1];
    }
}
