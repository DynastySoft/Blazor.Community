﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Local;
using Dynasty.Database;

//  THIS IS THE COLLECTION OF LOADING FOR WEB-VERSION.
//  THE COMMON ONES ARE IN modLoadUtility
//
namespace Dynasty.ASP
{
	internal static class modWebLoadUtility
	{
		public static void ClearComboBox(ref List<Models.clsCombobox> cur_box)
		{

			ArrayList item_list = new ArrayList();

			try
			{
				cur_box.Clear();
				item_list.Add(new clsComboBoxItem("", ""));
				LoadComboBox(ref cur_box, item_list);


			}
			catch (Exception ex)
			{

			}

		}

		public static void LoadComboBox(ref List<Models.clsCombobox> cur_box, ArrayList item_list)
		{

			try
			{
				foreach (clsComboBoxItem i in item_list)
                {
					cur_box.Add(new Models.clsCombobox { Value = i.Value, Text = i.Text });

				}
			}
			catch (Exception ex)
			{

			}

		}

        public static void AddItemToComboBox(ref List<Models.clsCombobox> cur_box, string item_value, string item_text)
        {
            ArrayList item_list = new ArrayList();

            if (GlobalVar.goUtility.IsNonEmpty(item_value))
            {
                foreach (var itm in cur_box)
                {
                    if (itm.Value == item_value)
                    {
                        return;
                    }
                }

                item_list.Add(new clsComboBoxItem(item_text, item_value));
                LoadComboBox(ref cur_box, item_list);
            }
        }

        public static void RemoveItemFromComboBox(ref List<Models.clsCombobox> cur_box, string item_value)
        {
            if (GlobalVar.goUtility.IsNonEmpty(item_value))
            {
                cur_box.Remove(cur_box.Find(i => i.Value == item_value));
            }
        }

        public static void LoadUnitCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string fiscal_year = "";
            string user_id = "";
            string currency_cd = "";
            string last_code = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;
            string[] unit_codes = null;
            int i = 0;
            int line_num = 0;

            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sFromUnit_cd, sToUnit_cd FROM tblGOUnit";
            sql_str += " ORDER BY sFromUnit_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            if (cur_set.RecordCount() > 0)
            {

                GlobalVar.goUtility.ResizeDim(ref unit_codes, (cur_set.RecordCount() * 2 - 1));

                i = 0;

                while (!cur_set.EOF())
                {

                    unit_codes[i] = cur_set.sField("sFromUnit_cd");
                    unit_codes[i + 1] = cur_set.sField("sToUnit_cd");

                    i += 2;
                    cur_set.MoveNext();

                }

                GlobalVar.goUtility.QuickSort1(ref unit_codes);

                last_code = "";

                for (i = 0; i <= unit_codes.GetUpperBound(0); i++)
                {

                    if (!GlobalVar.goUtility.IsEmpty(unit_codes[i]) & unit_codes[i] != last_code)
                    {
                        item_list.Add(new clsComboBoxItem(unit_codes[i], unit_codes[i]));
                        last_code = unit_codes[i];
                    }

                }

            }

            LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

            return;

        }

        public static void LoadItemType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool clear_flag = true, bool add_all_flag = false, bool exclude_summary_flag = false, bool inventory_only_flag = false)
        {

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            int i = 0;
            bool first_one = false;
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);

            try
            {

                if (clear_flag)
                {
                    i = 0;
                }

                sql_str = "SELECT * FROM tblIVItemType";

                if (inventory_only_flag)
                {
                    sql_str += " WHERE iItem_typ IN (" + GlobalVar.goUtility.InventoryItemTypeList() + ")";
                }
                else if (exclude_summary_flag)
                {
                    sql_str += " WHERE iItem_typ < " + GlobalVar.goIVConstant.SUMMARY_SALES_ITEM_TYPES.ToString();
                }
                sql_str += " ORDER BY iItem_typ";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                item_list.Add(new clsComboBoxItem("", "0"));
                first_one = true;

                while (cur_set.EOF() == false)
                {

                    if (GlobalVar.goUtility.IsNonEmpty(cur_set.sField("sDescription")))
                    {
                        if (first_one && (cur_set.iField("iItem_typ")) >= GlobalVar.goIVConstant.SUMMARY_SALES_ITEM_TYPES)
                        {
                            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oMessage.ACCT_TYPE_DIVIDER, "0"));
                            first_one = false;
                        }
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iItem_typ").ToString()));
                        i = i + 1;
                    }

                    cur_set.MoveNext();
                }

                // This is for the purpose of report
                //
                if (add_all_flag)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL_TYPES, cur_db.oLanguage.oString.STR_ALL_TYPES));
                }

                LoadComboBox(ref cur_box, item_list);

                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadItemType)");
                return;

            }

        }

        //	public static void LoadProcessingMode(ref clsDatabase cur_db, ref RadioButtonList cur_box)
        //	{

        //		DataTable data_table = new DataTable();
        //		DataRow data_row = null;

        //		data_table.Columns.Add(new DataColumn("Text", typeof(string)));
        //		data_table.Columns.Add(new DataColumn("Value", typeof(string)));

        //		data_row = data_table.NewRow();
        //		data_row[0] = GlobalVar.goConstant.BATCH_MODE;
        //		data_row[1] = GlobalVar.goConstant.BATCH_MODE_NUM.ToString();
        //		data_table.Rows.Add(data_row);
        //		data_row = data_table.NewRow();
        //		data_row[0] = GlobalVar.goConstant.REALTIME_MODE;
        //		data_row[1] = GlobalVar.goConstant.REALTIME_MODE_NUM.ToString();
        //		data_table.Rows.Add(data_row);

        //		cur_box.DataSource = new DataView(data_table);
        //		cur_box.DataTextField = "Text";
        //		cur_box.DataValueField = "Value";
        //		cur_box.DataBind();

        //	}

        //	public static void LoadAddressType(ref clsDatabase cur_db, ref RadioButtonList cur_box)
        //	{

        //		DataTable data_table = new DataTable();
        //		DataRow data_row = null;

        //		data_table.Columns.Add(new DataColumn("Text", typeof(string)));
        //		data_table.Columns.Add(new DataColumn("Value", typeof(string)));

        //		data_row = data_table.NewRow();
        //		data_row[0] = "U.S.A.";
        //		data_row[1] = GlobalVar.goConstant.ADDRESS_USA.ToString();
        //		data_table.Rows.Add(data_row);
        //		data_row = data_table.NewRow();
        //		data_row[0] = "Canada";
        //		data_row[1] = GlobalVar.goConstant.ADDRESS_CANADA.ToString();
        //		data_table.Rows.Add(data_row);
        //		data_row = data_table.NewRow();
        //		data_row[0] = "Others";
        //		data_row[1] = GlobalVar.goConstant.ADDRESS_OTHER.ToString();
        //		data_table.Rows.Add(data_row);

        //		cur_box.DataSource = new DataView(data_table);
        //		cur_box.DataTextField = "Text";
        //		cur_box.DataValueField = "Value";
        //		cur_box.DataBind();

        //	}

        //	public static void LoadFreightType(ref clsDatabase cur_db, ref RadioButtonList cur_box)
        //	{

        //		DataTable data_table = new DataTable();
        //		DataRow data_row = null;

        //		data_table.Columns.Add(new DataColumn("Text", typeof(string)));
        //		data_table.Columns.Add(new DataColumn("Value", typeof(string)));

        //		data_row = data_table.NewRow();
        //		data_row[0] = "Use Dynasty table based on Weight";
        //		data_row[1] = modConstant.FREIGHT_BY_WEIGHT_NUM.ToString();
        //		data_table.Rows.Add(data_row);
        //		data_row = data_table.NewRow();
        //		data_row[0] = "Use Dynasty table based on Price";
        //		data_row[1] = modConstant.FREIGHT_BY_PRICE_NUM.ToString();
        //		data_table.Rows.Add(data_row);
        //		data_row = data_table.NewRow();
        //		data_row[0] = "Use Dynasty table based on Quantity";
        //		data_row[1] = modConstant.FREIGHT_BY_QUANTITY_NUM.ToString();
        //		data_table.Rows.Add(data_row);
        //		data_row = data_table.NewRow();
        //		data_row[0] = "Use 3rd party table such as UPS and FedEx";
        //		data_row[1] = modConstant.FREIGHT_BY_UPS_NUM.ToString();
        //		data_table.Rows.Add(data_row);

        //		cur_box.DataSource = new DataView(data_table);
        //		cur_box.DataTextField = "Text";
        //		cur_box.DataValueField = "Value";
        //		cur_box.DataBind();

        //	}

        //	public static void LoadBudgetType(ref clsDatabase cur_db, ref RadioButtonList cur_box)
        //	{

        //		DataTable data_table = new DataTable();
        //		DataRow data_row = null;

        //		data_table.Columns.Add(new DataColumn("Text", typeof(string)));
        //		data_table.Columns.Add(new DataColumn("Value", typeof(string)));

        //		data_row = data_table.NewRow();
        //		data_row[0] = "No Budget";
        //		data_row[1] = GlobalVar.goGLConstant.NO_BUDGET_TYPE.ToString();
        //		data_table.Rows.Add(data_row);
        //		data_row = data_table.NewRow();
        //		data_row[0] = "No Strict";
        //		data_row[1] = GlobalVar.goGLConstant.SOFT_BUDGET_TYPE.ToString();
        //		data_table.Rows.Add(data_row);
        //		data_row = data_table.NewRow();
        //		data_row[0] = "Strict";
        //		data_row[1] = GlobalVar.goGLConstant.STRICT_BUDGET_TYPE.ToString();
        //		data_table.Rows.Add(data_row);

        //		cur_box.DataSource = new DataView(data_table);
        //		cur_box.DataTextField = "Text";
        //		cur_box.DataValueField = "Value";
        //		cur_box.DataBind();

        //	}

        //	public static void LoadDateType(ref clsDatabase cur_db, ref RadioButtonList cur_box)
        //	{

        //		DataTable data_table = new DataTable();
        //		DataRow data_row = null;

        //		data_table.Columns.Add(new DataColumn("Text", typeof(string)));
        //		data_table.Columns.Add(new DataColumn("Value", typeof(string)));

        //		data_row = data_table.NewRow();
        //		data_row[0] = "MM/DD/YYYY";
        //		data_row[1] = GlobalVar.goConstant.AMERICAN_DATE.ToString();
        //		data_table.Rows.Add(data_row);
        //		data_row = data_table.NewRow();
        //		data_row[0] = "DD/MM/YYYY";
        //		data_row[1] = GlobalVar.goConstant.ENGLISH_DATE.ToString();
        //		data_table.Rows.Add(data_row);
        //		data_row = data_table.NewRow();
        //		data_row[0] = "YYYY/MM/DD";
        //		data_row[1] = GlobalVar.goConstant.ASIAN_DATE.ToString();
        //		data_table.Rows.Add(data_row);

        //		cur_box.DataSource = new DataView(data_table);
        //		cur_box.DataTextField = "Text";
        //		cur_box.DataValueField = "Value";
        //		cur_box.DataBind();

        //	}

        //	public static void LoadMoneyType(ref clsDatabase cur_db, ref RadioButtonList cur_box)
        //	{

        //		DataTable data_table = new DataTable();
        //		DataRow data_row = null;

        //		data_table.Columns.Add(new DataColumn("Text", typeof(string)));
        //		data_table.Columns.Add(new DataColumn("Value", typeof(string)));

        //		data_row = data_table.NewRow();
        //		data_row[0] = "#,###.##";
        //		data_row[1] = GlobalVar.goConstant.ROUND_TO_CENT.ToString();
        //		data_table.Rows.Add(data_row);
        //		data_row = data_table.NewRow();
        //		data_row[0] = "#,###";
        //		data_row[1] = GlobalVar.goConstant.ROUND_TO_DOLLAR.ToString();
        //		data_table.Rows.Add(data_row);
        //		data_row = data_table.NewRow();
        //		data_row[0] = "#,###.###";
        //		data_row[1] = GlobalVar.goConstant.ROUND_TO_THIRD.ToString();
        //		data_table.Rows.Add(data_row);
        ////		data_row = data_table.NewRow();
        ////		data_row[0] = "#,####";
        ////		data_row[1] = GlobalVar.goConstant.ROUND_TO_ASIAN.ToString();
        ////		data_table.Rows.Add(data_row);
        //		data_row = data_table.NewRow();
        //		data_row[0] = "EURO";
        //		data_row[1] = GlobalVar.goConstant.ROUND_TO_EURO.ToString();
        //		data_table.Rows.Add(data_row);

        //		cur_box.DataSource = new DataView(data_table);
        //		cur_box.DataTextField = "Text";
        //		cur_box.DataValueField = "Value";
        //		cur_box.DataBind();

        //	}

        //	public static void LoadRMASystemItemConditionToDataGrid(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        //	{

        //		int line_num = 0;
        //		string[,] inv_condition = null;
        //		clsRMA o_rma = null;
        //		ArrayList item_list = new ArrayList();

        //		o_rma = new clsRMA(ref cur_db);

        //		// This will grab the system-defined conditions in the array.
        //		//
        //           o_rma.GetInventoryConditions(ref inv_condition);

        //		item_list.Add(new clsComboBoxItem("", ""));

        //		for (line_num = 0; line_num < inv_condition.GetLength(1); line_num++)
        //		{
        //			item_list.Add(new clsComboBoxItem(inv_condition[clsRMA.ITEM_CONDITION_DESC_COL, line_num], inv_condition[clsRMA.ITEM_CONDITION_ID_COL, line_num]));
        //		}

        //		LoadComboBox(ref cur_box, item_list);

        //	}

        public static void LoadCustomFields(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {

            ArrayList item_list = new ArrayList();

            try
            {

                item_list.Add(new clsComboBoxItem("", ""));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ACCOUNT, "0A")); // Values need to be unique. otherwise it would not select well. It just goes to the first item if Value has the same values.
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ASSET, "0B")); // A,B,C,D have no meanings. It is just to give identifiable values in selection.
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CARD_LOAN, "0C"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CONTACT_MANAGER, "0D"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CUSTOMER, "0E"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_EMPLOYEE, "0F"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_FUND, "0G"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_HELP_DESK, "0H"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ITEM, "0I"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_JOB, "0J"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_JOB_OPENING, "0K"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_LOT_MANAGER, "0L"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_OFFICE, "0M"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PROJECT, "0N"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_RMA, "0O"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_RMA_FULFILLMENT_CENTER, "0P"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_SALESREP, "0Q"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_SERIAL_MANAGER, "0R"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_VENDOR, "0S"));
                item_list.Add(new clsComboBoxItem("", ""));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CASH_PAYMENT, GlobalVar.goConstant.TRX_PAYMENT_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CASH_RECEIPT, GlobalVar.goConstant.TRX_RECEIPT_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CREDIT_MEMO, GlobalVar.goConstant.TRX_CM_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DEBIT_MEMO, GlobalVar.goConstant.TRX_DM_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_INVOICE, GlobalVar.goConstant.TRX_INVOICE_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ORDER, GlobalVar.goConstant.TRX_SO_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PURCHASE_ORDER, GlobalVar.goConstant.TRX_PO_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PURCHASE_REQUISITION, GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_QUOTE, GlobalVar.goConstant.TRX_QUOTE_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_VOUCHER, GlobalVar.goConstant.TRX_PURCHASE_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_WORK_ORDER, GlobalVar.goConstant.TRX_WO_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_FACILITY_SERVICE_MANAGER, GlobalVar.goConstant.TRX_FA_SERVICE_PLAN_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_FA_RENTAL, GlobalVar.goConstant.TRX_FA_RENTAL_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_FA_RETURN, GlobalVar.goConstant.TRX_FA_RENTAL_RETURN_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_FA_RESERVATION, GlobalVar.goConstant.TRX_FA_RENTAL_RESERVATION_TYPE.ToString()));

                LoadComboBox(ref cur_box, item_list);

            }
            catch (Exception ex)
            {

            }

        }

    }

}
