﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP
{
	internal static class modPayrollUtility
	{

		public static void GetPayrollTaxCaptions(ref clsDatabase cur_db)
		{

			string sql_str = "";
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			modPRVariable.guPayrollCaption.sFederal = GlobalVar.goPRConstant.FEDERAL_INCOME_TAX;
			modPRVariable.guPayrollCaption.sState = GlobalVar.goPRConstant.STATE_INCOME_TAX;
			modPRVariable.guPayrollCaption.sLocal = GlobalVar.goPRConstant.LOCAL_INCOME_TAX;
			modPRVariable.guPayrollCaption.sFICA = GlobalVar.goPRConstant.FICA_TAX;
			modPRVariable.guPayrollCaption.sFUTA = GlobalVar.goPRConstant.FUTA_TAX;
			modPRVariable.guPayrollCaption.sSUI = GlobalVar.goPRConstant.SUI_TAX;
			modPRVariable.guPayrollCaption.sSDI = GlobalVar.goPRConstant.SDI_TAX;
			modPRVariable.guPayrollCaption.sSET = GlobalVar.goPRConstant.SET_TAX;
			modPRVariable.guPayrollCaption.sMEDICARE = GlobalVar.goPRConstant.MEDICARE_TAX;
			modPRVariable.guPayrollCaption.sOther = GlobalVar.goPRConstant.OTHER_TAX;

			sql_str = "SELECT * FROM tblGOOption WHERE sModule_id = '" + GlobalVar.goConstant.PRMENU_NAME + "'";
			sql_str += " AND (sOption_cd = '" + GlobalVar.goPRConstant.FEDERAL_INCOME_TAX + "'";
			sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.STATE_INCOME_TAX + "'";
			sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.LOCAL_INCOME_TAX + "'";
			sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.FICA_TAX + "'";
			sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.FUTA_TAX + "'";
			sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.SUI_TAX + "'";
			sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.SDI_TAX + "'";
			sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.SET_TAX + "'";
			sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.MEDICARE_TAX + "'";
			sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.OTHER_TAX + "'";
			sql_str += ")";
			if (!cur_set.CreateSnapshot(sql_str))
			{
				return;
			}

			while (!cur_set.EOF())
			{

				if (cur_set.sField("sOption_cd").ToString() == GlobalVar.goPRConstant.FEDERAL_INCOME_TAX)
				{
					modPRVariable.guPayrollCaption.sFederal = cur_set.sField("sOptionValue");
				}
				else if (cur_set.sField("sOption_cd").ToString() == GlobalVar.goPRConstant.STATE_INCOME_TAX)
				{
					modPRVariable.guPayrollCaption.sState = cur_set.sField("sOptionValue");
				}
				else if (cur_set.sField("sOption_cd").ToString() == GlobalVar.goPRConstant.LOCAL_INCOME_TAX)
				{
					modPRVariable.guPayrollCaption.sLocal = cur_set.sField("sOptionValue");
				}
				else if (cur_set.sField("sOption_cd").ToString() == GlobalVar.goPRConstant.FICA_TAX)
				{
					modPRVariable.guPayrollCaption.sFICA = cur_set.sField("sOptionValue");
				}
				else if (cur_set.sField("sOption_cd").ToString() == GlobalVar.goPRConstant.FUTA_TAX)
				{
					modPRVariable.guPayrollCaption.sFUTA = cur_set.sField("sOptionValue");
				}
				else if (cur_set.sField("sOption_cd").ToString() == GlobalVar.goPRConstant.SUI_TAX)
				{
					modPRVariable.guPayrollCaption.sSUI = cur_set.sField("sOptionValue");
				}
				else if (cur_set.sField("sOption_cd").ToString() == GlobalVar.goPRConstant.SDI_TAX)
				{
					modPRVariable.guPayrollCaption.sSDI = cur_set.sField("sOptionValue");
				}
				else if (cur_set.sField("sOption_cd").ToString() == GlobalVar.goPRConstant.SET_TAX)
				{
					modPRVariable.guPayrollCaption.sSET = cur_set.sField("sOptionValue");
				}
				else if (cur_set.sField("sOption_cd").ToString() == GlobalVar.goPRConstant.MEDICARE_TAX)
				{
					modPRVariable.guPayrollCaption.sMEDICARE = cur_set.sField("sOptionValue");
				}
				else if (cur_set.sField("sOption_cd").ToString() == GlobalVar.goPRConstant.OTHER_TAX)
				{
					modPRVariable.guPayrollCaption.sOther = cur_set.sField("sOptionValue");
				}
				else
				{
					// Not expected
				}

				cur_set.MoveNext();

			}

		}

		public static bool SavePayrollTaxCaptions(ref clsDatabase cur_db)
		{

			bool return_value = false;
			string insert_str = "";
			string value_str = "";
			string sql_str = "";
			DateTime cur_time = default(DateTime);
			clsRecordset cur_set = null;

			try
			{

					cur_set = new clsRecordset(ref cur_db);

					sql_str = "DELETE FROM tblGOOption WHERE sModule_id = '" + GlobalVar.goConstant.PRMENU_NAME + "'";
					sql_str += " AND (sOption_cd = '" + GlobalVar.goPRConstant.FEDERAL_INCOME_TAX + "'";
					sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.STATE_INCOME_TAX + "'";
					sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.LOCAL_INCOME_TAX + "'";
					sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.FICA_TAX + "'";
					sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.FUTA_TAX + "'";
					sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.SUI_TAX + "'";
					sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.SDI_TAX + "'";
					sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.SET_TAX + "'";
					sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.MEDICARE_TAX + "'";
					sql_str += " OR sOption_cd = '" + GlobalVar.goPRConstant.OTHER_TAX + "'";
					sql_str += ")";

					if (!cur_db.ExecuteSQL(sql_str))
					{
						return return_value;
					}

					cur_time = DateTime.Now;

					insert_str = "INSERT INTO tblGOOption(";
					insert_str = insert_str + "sOption_cd";
					insert_str = insert_str + ",sModule_id";
					insert_str = insert_str + ",sOptionValue";
					insert_str = insert_str + ",iOptionValue";
					insert_str = insert_str + ",fOptionValue";
					insert_str = insert_str + ",dtLastUpdate_dt";
					insert_str = insert_str + ",sLastUpdate_id";
					insert_str = insert_str + ") VALUES (";

					value_str = "'" + GlobalVar.goPRConstant.FEDERAL_INCOME_TAX + "'";
					value_str = value_str + ",'" + GlobalVar.goConstant.PRMENU_NAME + "'";
					value_str = value_str + ",'" + modPRVariable.guPayrollCaption.sFederal + "'";
					value_str = value_str + ",0";
					value_str = value_str + ",0";
					value_str = value_str + "," + cur_db.CreateDatetimeValue(cur_time); //" & goUtility.SFormat(cur_time, o_gen.GetDatetimeFormat()) & "'"
					value_str = value_str + ",'" + cur_db.sUser_cd + "'";
					value_str = value_str + ")";
					if (!cur_db.ExecuteSQL(insert_str + value_str))
					{
						return return_value;
					}

					value_str = "'" + GlobalVar.goPRConstant.STATE_INCOME_TAX + "'";
					value_str = value_str + ",'" + GlobalVar.goConstant.PRMENU_NAME + "'";
					value_str = value_str + ",'" + modPRVariable.guPayrollCaption.sState + "'";
					value_str = value_str + ",0";
					value_str = value_str + ",0";
					value_str = value_str + "," + cur_db.CreateDatetimeValue(cur_time); //" & goUtility.SFormat(cur_time, o_gen.GetDatetimeFormat()) & "'"
					value_str = value_str + ",'" + cur_db.sUser_cd + "'";
					value_str = value_str + ")";
					if (!cur_db.ExecuteSQL(insert_str + value_str))
					{
						return return_value;
					}

					value_str = "'" + GlobalVar.goPRConstant.LOCAL_INCOME_TAX + "'";
					value_str = value_str + ",'" + GlobalVar.goConstant.PRMENU_NAME + "'";
					value_str = value_str + ",'" + modPRVariable.guPayrollCaption.sLocal + "'";
					value_str = value_str + ",0";
					value_str = value_str + ",0";
					value_str = value_str + "," + cur_db.CreateDatetimeValue(cur_time); //" & goUtility.SFormat(cur_time, o_gen.GetDatetimeFormat()) & "'"
					value_str = value_str + ",'" + cur_db.sUser_cd + "'";
					value_str = value_str + ")";
					if (!cur_db.ExecuteSQL(insert_str + value_str))
					{
						return return_value;
					}

					value_str = "'" + GlobalVar.goPRConstant.FICA_TAX + "'";
					value_str = value_str + ",'" + GlobalVar.goConstant.PRMENU_NAME + "'";
					value_str = value_str + ",'" + modPRVariable.guPayrollCaption.sFICA + "'";
					value_str = value_str + ",0";
					value_str = value_str + ",0";
					value_str = value_str + "," + cur_db.CreateDatetimeValue(cur_time); //" & goUtility.SFormat(cur_time, o_gen.GetDatetimeFormat()) & "'"
					value_str = value_str + ",'" + cur_db.sUser_cd + "'";
					value_str = value_str + ")";
					if (!cur_db.ExecuteSQL(insert_str + value_str))
					{
						return return_value;
					}

					value_str = "'" + GlobalVar.goPRConstant.FUTA_TAX + "'";
					value_str = value_str + ",'" + GlobalVar.goConstant.PRMENU_NAME + "'";
					value_str = value_str + ",'" + modPRVariable.guPayrollCaption.sFUTA + "'";
					value_str = value_str + ",0";
					value_str = value_str + ",0";
					value_str = value_str + "," + cur_db.CreateDatetimeValue(cur_time); //" & goUtility.SFormat(cur_time, o_gen.GetDatetimeFormat()) & "'"
					value_str = value_str + ",'" + cur_db.sUser_cd + "'";
					value_str = value_str + ")";
					if (!cur_db.ExecuteSQL(insert_str + value_str))
					{
						return return_value;
					}

					value_str = "'" + GlobalVar.goPRConstant.SUI_TAX + "'";
					value_str = value_str + ",'" + GlobalVar.goConstant.PRMENU_NAME + "'";
					value_str = value_str + ",'" + modPRVariable.guPayrollCaption.sSUI + "'";
					value_str = value_str + ",0";
					value_str = value_str + ",0";
					value_str = value_str + "," + cur_db.CreateDatetimeValue(cur_time); //" & goUtility.SFormat(cur_time, o_gen.GetDatetimeFormat()) & "'"
					value_str = value_str + ",'" + cur_db.sUser_cd + "'";
					value_str = value_str + ")";
					if (!cur_db.ExecuteSQL(insert_str + value_str))
					{
						return return_value;
					}

					value_str = "'" + GlobalVar.goPRConstant.SDI_TAX + "'";
					value_str = value_str + ",'" + GlobalVar.goConstant.PRMENU_NAME + "'";
					value_str = value_str + ",'" + modPRVariable.guPayrollCaption.sSDI + "'";
					value_str = value_str + ",0";
					value_str = value_str + ",0";
					value_str = value_str + "," + cur_db.CreateDatetimeValue(cur_time); //" & goUtility.SFormat(cur_time, o_gen.GetDatetimeFormat()) & "'"
					value_str = value_str + ",'" + cur_db.sUser_cd + "'";
					value_str = value_str + ")";
					if (!cur_db.ExecuteSQL(insert_str + value_str))
					{
						return return_value;
					}

					value_str = "'" + GlobalVar.goPRConstant.SET_TAX + "'";
					value_str = value_str + ",'" + GlobalVar.goConstant.PRMENU_NAME + "'";
					value_str = value_str + ",'" + modPRVariable.guPayrollCaption.sSET + "'";
					value_str = value_str + ",0";
					value_str = value_str + ",0";
					value_str = value_str + "," + cur_db.CreateDatetimeValue(cur_time); //" & goUtility.SFormat(cur_time, o_gen.GetDatetimeFormat()) & "'"
					value_str = value_str + ",'" + cur_db.sUser_cd + "'";
					value_str = value_str + ")";
					if (!cur_db.ExecuteSQL(insert_str + value_str))
					{
						return return_value;
					}

					value_str = "'" + GlobalVar.goPRConstant.MEDICARE_TAX + "'";
					value_str = value_str + ",'" + GlobalVar.goConstant.PRMENU_NAME + "'";
					value_str = value_str + ",'" + modPRVariable.guPayrollCaption.sMEDICARE + "'";
					value_str = value_str + ",0";
					value_str = value_str + ",0";
					value_str = value_str + "," + cur_db.CreateDatetimeValue(cur_time); //" & goUtility.SFormat(cur_time, o_gen.GetDatetimeFormat()) & "'"
					value_str = value_str + ",'" + cur_db.sUser_cd + "'";
					value_str = value_str + ")";
					if (!cur_db.ExecuteSQL(insert_str + value_str))
					{
						return return_value;
					}

					value_str = "'" + GlobalVar.goPRConstant.OTHER_TAX + "'";
					value_str = value_str + ",'" + GlobalVar.goConstant.PRMENU_NAME + "'";
					value_str = value_str + ",'" + modPRVariable.guPayrollCaption.sOther + "'";
					value_str = value_str + ",0";
					value_str = value_str + ",0";
					value_str = value_str + "," + cur_db.CreateDatetimeValue(cur_time); //" & goUtility.SFormat(cur_time, o_gen.GetDatetimeFormat()) & "'"
					value_str = value_str + ",'" + cur_db.sUser_cd + "'";
					value_str = value_str + ")";
					if (!cur_db.ExecuteSQL(insert_str + value_str))
					{
						return return_value;
					}

					return true;

			}
			catch (Exception ex)
			{

						modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(SavePayrollTaxCaptions)");
						return return_value;

			}

		}

	}

}
