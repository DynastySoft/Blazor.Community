﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
// using System.Windows.Forms;

using Dynasty.Database;
using Dynasty.Local;
using System.Web;
using System.Configuration;

namespace Dynasty.ASP
{
	public class clsCompany
	{

		// ***********************************************************
		// THIS CLASS INCLUDES company-related routines.
		// ***********************************************************

		public string[,] sCompanyNames; // Names of company. Make this public
		public int iTotalCompanyNames; // Keep it public

		private clsDynastyUtility oUtility = new clsDynastyUtility();

		public bool OpenDatabase(ref clsDatabase cur_db, string company_name = "")
		{

			bool return_value = false;
			string user_id = "";
			string password = "";
			string db_name = "";
			string server_name = "";
			bool DSNless_fl = false;

			// ==================================================================================================================================================================================
			// CONNECTION SCHEMA :
			//
			// Single Company : 
			//        The initial connection string is expected in appsettings.json file. 
			//        i.e., "DynastyDB": "Server=dell;Initial Catalog=Dynasty" where Dynasty is the target database 
			//
			// ==================================================================================================================================================================================

			try
			{
				if (cur_db.IsConnected())
				{
					return true;
				}

				// Right now, Only SQL Server can run DSN-less report until Crystal is ready for other DB's.
				//
				DSNless_fl = (cur_db.CurrentDatabaseType() == GlobalVar.goConstant.CONNECTION_SQLSERVER_TYPE && oUtility.IsNonEmpty(cur_db.sConnectionString));

				// These can be passed from routines other than login
				//
				server_name = cur_db.sServer_nm;
				db_name = cur_db.sDatabase_nm;

				if (!oUtility.GetUserInfoFromConnectionStr(cur_db.sConnectionString, ref server_name, ref db_name, ref user_id, ref password)) // This will extract the user id/password.
				{
					modDialogUtility.DisplayBox(ref cur_db, "Connection string in Web.config file is not properly structured.");
					return false;
				}
				else if (oUtility.IsEmpty(server_name) || oUtility.IsEmpty(db_name))
				{
					modDialogUtility.DisplayBox(ref cur_db, "Connection string in Web.config file is not properly structured.");
					return false;
				}

				//  Neccesary to reset these with the ones from the connection string in Web.config.
				//  These will be used system-wide.
				//
				if (oUtility.IsNonEmpty(user_id))
				{
					GlobalVar.goConstant.SYSTEM_USER_ID = user_id;
				}
				if (oUtility.IsNonEmpty(password))
				{
					GlobalVar.goConstant.SYSTEM_USER_PASSWORD = password;
				}

				// ==================================================================================================
				// This is the actual connection to the user database.
				// ==================================================================================================
				cur_db.sServer_nm = server_name;
				cur_db.sDatabase_nm = db_name;
				cur_db.sConnectionString = cur_db.CreateSQLConnectionString(cur_db.sServer_nm, cur_db.sDatabase_nm);

				if (cur_db.ConnectSQLDatabase(cur_db.sConnectionString) == false)
				{
					return false;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(OpenDatabase)");
			}

			return return_value;
		}

		public void CloseDatabase(ref clsDatabase cur_db)
		{
			try
			{
				cur_db.CloseDatabase();
			}
			catch (Exception ex)
			{
				// let it go
			}

		}

		public bool WriteCompanyNames(ref clsDatabase cur_db, ref string[,] company_names)
		{
			return true;
		}

		public bool ReadCompanyNames(ref clsDatabase cur_db, ref string[,] company_names, string ccn = "")
		{
			return true;
		}

		// PURPOSE:  To Write to INI file.
		//
		public bool WriteIniFile(ref clsDatabase cur_db, string file_name)
		{
			return true;
		}

		// PURPOSE:  To read INI file and set the option item values accordingly.
		//
		public bool ReadIniFile(ref clsDatabase cur_db, string file_name)
		{
			return true;
		}

		// PURPOSE:  To set the value of item in INI file.
		// COMMENTS: If the line starts with
		//              "[", then it is the section title.
		//              "a" thru "z", then it is the item name.
		//              any others, the the line will be considered a comment line.
		//
		private bool ReadIniLine(ref clsDatabase cur_db, string buff, ref string section_name, ref string item_name, ref string item_value)
		{
			return true;
		}

		public bool GetDatabaseNameFromCompanyName(ref clsDatabase cur_db, ref string company_name, ref string db_name, ref string server_name, ref string dsn, ref int db_type, string CCN)
		{
			return true;
		}

		public bool GetDatabaseInfo(string[,] company_list, ref string company_short_name, ref string company_full_name, ref string db_name, ref string server_name, ref string dsn_name, ref string database_type, ref bool use_sp_fl)
		{
			return true;
		}

		//  PURPOSE:  To save a option value a user picked.
		//
		public void SaveSystemINIVars(ref clsDatabase cur_db, string item_name, string item_value)
		{

		}

		// PURPOSE:  To set the user-specific option values.
		//
		public bool SetSystemINIVars(ref clsDatabase cur_db)
		{

			return true;

		}

		public string GetRecentlyUsedCompanyName(int db_index = -100)
		{
			return "";
		}

		public string GetRecentlyUsedDatabaseName(int db_index = -100)
		{
			return "";
		}

		//  PURPOSE: To reset the sRecentlyUsedDBNames, and put the passed-company info
		//           into the first line.
		//
		public bool SetRecentlyUsedCompanyName(ref clsDatabase cur_db, string company_name, string path_name)
		{
			return true;	
		}

		public bool GetCCNInfo(ref clsDatabase cur_db)
		{
			
			return true;

		}

		public bool NoLoginInfo(ref clsDatabase cur_db)
		{
			return true;
		}


		public bool LoadCompanyNames(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool include_current_company = true)
		{
			bool return_value = false;
			int line_num = 0;
			int item_num = 0;

			string[,] company_names = null;
			ArrayList item_list = new ArrayList();

			try
			{
				cur_box.Clear();

				item_list.Add(new clsComboBoxItem("", ""));

				modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadCompanyNames)");
			}

			return return_value;
		}

	}

}
