﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//
//




using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Local;
using Dynasty.Database;

namespace Dynasty.ASP
{
	public class clsSerialUtility
	{

		public int iDialogRequested_typ;
		public string sDialogMessageRequested;

		public const int DIALOG_REQUESTED_IN_ITEM_CODE_VALIDATION = 1;
		public const int DIALOG_REQUESTED_IN_SERIAL_NUM_VALIDATION = 2;
		public const int DIALOG_REQUESTED_IN_QTY_VALIDATION = 3;

		clsArray oArray = new clsArray();
		clsDynastyUtility oUtility = new clsDynastyUtility();

		public clsSerialUtility() : base()
		{
		}

		// PURPOSE: to initialize the serial/lot grid in the transaction screen.
		//          This should be called in FormLoadExtra().
		//
		public void InitSerialGrid(ref clsDatabase cur_db, ref clsSerial cur_serial, ref string[,] serial_grid, int trx_type)
		{

			try
			{

				//modWebGridUtility.SpreadsheetAlignColumns(ref serial_grid, clsSerial.QTY_COL, GlobalVar.goConstant.ALIGNMENT_RIGHT);
				//modWebGridUtility.SpreadsheetAlignColumns(ref serial_grid, clsSerial.DATE_EXPIRES_COL, GlobalVar.goConstant.ALIGNMENT_CENTER);
				//modWebGridUtility.SpreadsheetAlignColumns(ref serial_grid, clsSerial.DATE_WARRANTY_EXPIRES_COL, GlobalVar.goConstant.ALIGNMENT_CENTER);

				//if (trx_type == GlobalVar.goConstant.TRX_RECEIPT_TYPE || trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE || trx_type == GlobalVar.goConstant.TRX_IV_PURCHASE_TYPE || trx_type == GlobalVar.goConstant.TRX_IV_RECEIVING_TYPE)
				//{
				//	modWebGridUtility.SpreadsheetHideColumns(ref serial_grid, clsSerial.DATE_EXPIRES_COL, false);
				//	modWebGridUtility.SpreadsheetHideColumns(ref serial_grid, clsSerial.DATE_WARRANTY_EXPIRES_COL, false);
				//}
				//else
				//{
				//	modWebGridUtility.SpreadsheetHideColumns(ref serial_grid, clsSerial.DATE_EXPIRES_COL);
				//	modWebGridUtility.SpreadsheetHideColumns(ref serial_grid, clsSerial.DATE_WARRANTY_EXPIRES_COL);
				//}

				////SpreadsheetHideColumns(serial_grid, clsSerial.DELETE_BUTTON_COL)
				//modWebGridUtility.SpreadsheetHideColumns(ref serial_grid, clsSerial.UNIT_PRICE_COL);
				//modWebGridUtility.SpreadsheetHideColumns(ref serial_grid, clsSerial.UNIT_COST_COL);
				//modWebGridUtility.SpreadsheetHideColumns(ref serial_grid, clsSerial.LOCATION_CODE_COL);
				//modWebGridUtility.SpreadsheetHideColumns(ref serial_grid, clsSerial.REMARK_COL);
				//modWebGridUtility.SpreadsheetHideColumns(ref serial_grid, clsSerial.DETAIL_LINE_ID_COL);

			}
			catch (Exception ex)
			{

			}

		}

		public void CopySerialArrayToGrid(ref clsDatabase cur_db, ref clsSerial cur_serial, ref string[,] serial_grid, ref string[,] lot_array)
		{

			int line_num = 0;
			int total_rows = 0;

			try
			{

				for (total_rows = 0; total_rows < lot_array.GetLength(1); total_rows++)
				{
					if (oUtility.IsEmpty(lot_array[clsSerial.ITEM_CODE_COL, line_num]))
					{
						break;
					}
				}

				//if (serial_grid.GetLength(1) < total_rows + 5)
				//{
				//	modWebGridUtility.SpreadsheetAddLines(ref cur_db, ref serial_grid, ref dropdown_list, total_rows + 5);
				//}

				for (line_num = 0; line_num <= total_rows; line_num++)
				{
					if (oUtility.IsEmpty(lot_array[clsSerial.ITEM_CODE_COL, line_num]))
					{
						break;
					}
					serial_grid[clsSerial.ITEM_CODE_COL, line_num] = lot_array[clsSerial.ITEM_CODE_COL, line_num];
					serial_grid[clsSerial.SERIAL_CODE_COL, line_num] = lot_array[clsSerial.SERIAL_CODE_COL, line_num];
					serial_grid[clsSerial.DATE_EXPIRES_COL, line_num] = lot_array[clsSerial.DATE_EXPIRES_COL, line_num];
					serial_grid[clsSerial.DATE_WARRANTY_EXPIRES_COL, line_num] = lot_array[clsSerial.DATE_WARRANTY_EXPIRES_COL, line_num];
					serial_grid[clsSerial.DETAIL_LINE_ID_COL, line_num] = lot_array[clsSerial.DETAIL_LINE_ID_COL, line_num];
					serial_grid[clsSerial.UNIT_CODE_COL, line_num] = lot_array[clsSerial.UNIT_CODE_COL, line_num];
					serial_grid[clsSerial.QTY_COL, line_num] = lot_array[clsSerial.QTY_COL, line_num];
					serial_grid[clsSerial.UNIT_PRICE_COL, line_num] = lot_array[clsSerial.UNIT_PRICE_COL, line_num];
					serial_grid[clsSerial.UNIT_COST_COL, line_num] = lot_array[clsSerial.UNIT_COST_COL, line_num];
					serial_grid[clsSerial.LOCATION_CODE_COL, line_num] = lot_array[clsSerial.LOCATION_CODE_COL, line_num];
					serial_grid[clsSerial.REMARK_COL, line_num] = "";
				}

			}
			catch (Exception ex)
			{

			}

		}

		private void CopySerialGridToArray(ref clsSerial cur_serial, ref string[,] serial_grid, ref string[,] lot_array, int cur_sheet = 0)
		{
			int line_num = 0;

			try
			{
				if (serial_grid.GetLength(1) <= 0 || serial_grid.GetLength(0) <= 0)
				{
					return;
				}

				oUtility.ResizeDim(ref lot_array, serial_grid.GetLength(0) - 1, serial_grid.GetLength(1) - 1);

				for (line_num = 0; line_num <= lot_array.GetLength(1) - 1; line_num++)
				{
					lot_array[clsSerial.ITEM_CODE_COL, line_num] = serial_grid[clsSerial.ITEM_CODE_COL, line_num];
					lot_array[clsSerial.SERIAL_CODE_COL, line_num] = serial_grid[clsSerial.SERIAL_CODE_COL, line_num];
					lot_array[clsSerial.DATE_EXPIRES_COL, line_num] = serial_grid[clsSerial.DATE_EXPIRES_COL, line_num];
					lot_array[clsSerial.DATE_WARRANTY_EXPIRES_COL, line_num] = serial_grid[clsSerial.DATE_WARRANTY_EXPIRES_COL, line_num];
					lot_array[clsSerial.DETAIL_LINE_ID_COL, line_num] = serial_grid[clsSerial.DETAIL_LINE_ID_COL, line_num];
					lot_array[clsSerial.UNIT_CODE_COL, line_num] = serial_grid[clsSerial.UNIT_CODE_COL, line_num];
					lot_array[clsSerial.QTY_COL, line_num] = serial_grid[clsSerial.QTY_COL, line_num];
					lot_array[clsSerial.UNIT_PRICE_COL, line_num] = serial_grid[clsSerial.UNIT_PRICE_COL, line_num];
					lot_array[clsSerial.UNIT_COST_COL, line_num] = serial_grid[clsSerial.UNIT_COST_COL, line_num];
					lot_array[clsSerial.LOCATION_CODE_COL, line_num] = serial_grid[clsSerial.LOCATION_CODE_COL, line_num];
					lot_array[clsSerial.REMARK_COL, line_num] = "";
				}

			}
			catch (Exception ex)
			{

			}

		}

		//  PURPOSE:  To save the change of the details into database.
		//
		public bool SaveSerialDetailInFile(ref clsDatabase cur_db, ref clsSerial cur_serial, ref string[,] serial_grid, int trx_type, int trx_num, string key_code
			, string apply_date, string entry_date, bool new_trx, int prev_status, int cur_status, int order_num = 0, int prev_order_num = 0)
		{
			bool return_value = false;
			int line_num = 0;
			int col_num = 0;

			try
			{
				// Use the function in cur_serial.  For the sake of compatibility between VB and ASP, we need to use cur_serial.
				//
				cur_serial.InitSerialLotArray();
				cur_serial.InitSerialLotDetail();
				if (serial_grid.GetLength(1) > cur_serial.iTotalRows)
				{
					cur_serial.iTotalRows = serial_grid.GetLength(1);
					oUtility.ResizeDim(ref cur_serial.sLotArray, clsSerial.TOTAL_COL - 1, cur_serial.iTotalRows - 1);
				}

				for (line_num = 0; line_num <= serial_grid.GetLength(1) - 1; line_num++)
				{
					for (col_num = 0; col_num < clsSerial.TOTAL_COL; col_num++)
					{
						if (col_num != clsSerial.DELETE_BUTTON_COL && col_num != clsSerial.ZOOM_SERIAL_CODE_COL)
						{
							cur_serial.sLotArray[col_num, line_num] = serial_grid[col_num, line_num];
						}
					}
				}

				if (cur_serial.SaveSerialLotDetailInFile(trx_type, trx_num, key_code, apply_date, entry_date, new_trx, prev_status, cur_status, order_num, prev_order_num) == false)
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.SAVING_FAILED);
					return false;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(SaveSerialDetailInFile)");
			}

			return return_value;
		}

		// PURPOSE : This routine will check if the serial/lot numbers are entered correctly.
		//
		public bool ValidSerialDetail(ref clsDatabase cur_db, ref clsSerial cur_serial, ref string[,] main_grid, ref string[,] serial_grid, int itemcode_col, int unitcode_col
			, int itemtype_col, int qty_of_ivunit_col, int quantity_col, int ivunitcode_col, int unitprice_col, int totalcost_col, int trx_type, int trx_num, bool new_flag)
		{

			bool return_value = false;
			int row_num = 0;
			int col_num = 0;
			string[,] main_array = null;

			try
			{
				if (cur_db.bDoNotTrackLot_fl && cur_db.bDoNotTrackSerial_fl)
				{
					return true;
				}

				if (main_grid.GetLength(1) == 0)
				{
					return false;
				}

				// Use the function in cur_serial.  For the sake of compatibility between VB and ASP, we need to use cur_serial.
				//
				if (main_grid.GetLength(1) > 0)
				{
					oUtility.ResizeDim(ref main_array, main_grid.GetLength(0) - 1, main_grid.GetLength(1) - 1);
				}
				else
				{
					oUtility.ResizeDim(ref main_array, main_grid.GetLength(0) - 1, 0);
				}
				for (row_num = 0; row_num < main_grid.GetLength(1); row_num++)
				{
					for (col_num = 0; col_num < main_grid.GetLength(0); col_num++)
					{
						main_array[col_num, row_num] = main_grid[col_num, row_num];
					}
				}

				// We will use the funcationalities in clsSerial
				//
				cur_serial.InitSerialLotArray();
				cur_serial.InitSerialLotDetail();

				if (serial_grid.GetLength(1) > 0)
				{
					oUtility.ResizeDim(ref cur_serial.sLotArray, clsSerial.TOTAL_COL - 1, serial_grid.GetLength(1) - 1);
				}
				cur_serial.iTotalRows = cur_serial.sLotArray.GetLength(1);

				CopySerialGridToArray(ref cur_serial, ref serial_grid, ref cur_serial.sLotArray, 0);

				if (cur_serial.ValidSerialLotDetail(ref main_array, itemcode_col, unitcode_col, itemtype_col, qty_of_ivunit_col, quantity_col, ivunitcode_col, unitprice_col
					, totalcost_col, trx_type, trx_num, new_flag, false) == false)
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.SERIAL_NUM_NOT_SETUP);
					return false;
				}

				return_value = true;

			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ValidSerialDetail)");
			}

			return return_value;
		}

		//public bool SaveSerialInfo(ref clsDatabase cur_db, ref clsSerial cur_serial, ref string[,] serial_grid)
		//{

		//	bool return_value = false;

		//	return_value = true;

		//	return return_value;
		//}

		public bool CheckForDates(ref clsDatabase cur_db, ref clsSerial cur_serial, ref string[,] serial_grid)
		{
			bool return_value = false;
			int line_num = 0;
			int in_num = 0;
			string date_str = null;
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			for (line_num = 0; line_num < serial_grid.GetLength(1); line_num++)
			{
				if (!oUtility.IsEmpty(serial_grid[clsSerial.ITEM_CODE_COL, line_num]) && !oUtility.IsEmpty(serial_grid[clsSerial.SERIAL_CODE_COL, line_num]))
				{
					if (!oUtility.IsEmpty(oUtility.STrim(serial_grid[clsSerial.DATE_EXPIRES_COL, line_num])))
					{
						date_str = oUtility.STrim(serial_grid[clsSerial.DATE_EXPIRES_COL, line_num]);
						if (!o_gen.ValidDate(ref date_str))
						{
							modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.INVALID_DATE_ENTERED);
							return return_value;
						}
					}
					if (!oUtility.IsEmpty(oUtility.STrim(serial_grid[clsSerial.DATE_WARRANTY_EXPIRES_COL, line_num])))
					{
						date_str = oUtility.STrim(serial_grid[clsSerial.DATE_WARRANTY_EXPIRES_COL, line_num]);
						if (!o_gen.ValidDate(ref date_str))
						{
							modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.INVALID_DATE_ENTERED);
							return return_value;
						}
					}
				}
			}

			return true;
		}

		public bool CheckForDuplicates(ref clsDatabase cur_db, ref clsSerial cur_serial, ref string[,] serial_grid, string location_code)
		{
			bool return_value = false;
			int line_num = 0;
			int in_num = 0;
			int item_type = 0;
			string item_code = null;
			string serial_code = null;
			decimal existing_qty = 0M;
			bool serial_num_exist = false;
			clsValidate o_validate = new clsValidate(ref cur_db);

			for (line_num = 0; line_num < serial_grid.GetLength(1); line_num++)
			{
				if (!oUtility.IsEmpty(serial_grid[clsSerial.ITEM_CODE_COL, line_num]) && !oUtility.IsEmpty(serial_grid[clsSerial.SERIAL_CODE_COL, line_num]))
				{
					item_code = serial_grid[clsSerial.ITEM_CODE_COL, line_num];
					serial_code = serial_grid[clsSerial.SERIAL_CODE_COL, line_num];

					if (oUtility.ToValue(serial_grid[clsSerial.QTY_COL, line_num]) > 0)
					{
						for (in_num = line_num + 1; in_num < serial_grid.GetLength(1); in_num++)
						{
							if (item_code == serial_grid[clsSerial.ITEM_CODE_COL, in_num] && serial_code == serial_grid[clsSerial.SERIAL_CODE_COL, in_num] && oUtility.ToValue(serial_grid[clsSerial.QTY_COL, in_num]) > 0)
							{
								if (o_validate.IsValidSerialCode(item_code, serial_code, location_code))
								{
									existing_qty = o_validate.oRecordset.mField("fAvailable_qty");
									item_type = o_validate.oRecordset.iField("iItem_typ");
									serial_num_exist = true;
								}
								else
								{
									existing_qty = 0M;
									serial_num_exist = false;
								}
								o_validate.Release();
								if (item_type == GlobalVar.goIVConstant.SERIAL_ITEM_NUM || !serial_num_exist)
								{
									modDialogUtility.DisplayBox(ref cur_db, item_code + "/" + serial_code + " appears more than once.");
									return false;
								}
							}
						}
					}
					else
					{
						serial_grid[clsSerial.SERIAL_CODE_COL, line_num] = "";
						serial_grid[clsSerial.QTY_COL, line_num] = "";
					}
				}
			}

			return true;
		}

		public bool CheckForQtyAvailable(ref clsDatabase cur_db, ref clsSerial cur_serial, ref string[,] serial_grid, int trx_type, int trx_num, bool new_fl, int order_num, string location_code)
		{
			bool return_value = false;
			int row_num = 0;

			for (row_num = 0; row_num < serial_grid.GetLength(1); row_num++)
			{
				if (!CheckQtyForEachSerialNumber(ref cur_db, ref cur_serial, ref serial_grid, row_num, trx_type, trx_num, new_fl, order_num, location_code))
				{
					return false;
				}
			}

			return true;
		}

		private bool CheckQtyForEachSerialNumber(ref clsDatabase cur_db, ref clsSerial cur_serial, ref string[,] serial_grid, int row_num, int trx_type, int trx_num, bool new_fl
			, int order_num, string location_code)
		{
			bool return_value = false;
			string item_code = null;
			string serial_code = null;
			string loc_code = null;
			decimal qty_needed = 0M;
			decimal existing_qty = 0M;
			bool serial_num_exist = false;
			int item_type = 0;
			int i = 0;
			clsValidate o_valid = new clsValidate(ref cur_db);
			clsSerial o_serial = new clsSerial(ref cur_db);

			try
			{
				item_code = serial_grid[clsSerial.ITEM_CODE_COL, row_num];
				loc_code = serial_grid[clsSerial.LOCATION_CODE_COL, row_num];
				serial_code = oUtility.SUCase(serial_grid[clsSerial.SERIAL_CODE_COL, row_num]);
				qty_needed = oUtility.ToValue(serial_grid[clsSerial.QTY_COL, row_num]);

				if (oUtility.IsEmpty(item_code) || oUtility.IsEmpty(serial_code))
				{
					return true;
				}

				// See if this number is entered more than once in the current transaction.
				// regardless of the item type, the serial/lot number should appear only once in the currennt system.
				//
				for (i = 0; i < serial_grid.GetLength(1); i++)
				{
					if (oUtility.IsEmpty(oUtility.STrim(serial_grid[clsSerial.ITEM_CODE_COL, i])))
					{
						break;
					}
					else if (row_num == i)
					{
						// ignore the current line
					}
					else if (serial_grid[clsSerial.ITEM_CODE_COL, i] == item_code && serial_grid[clsSerial.SERIAL_CODE_COL, i] == serial_code)
					{
						if (o_valid.IsValidSerialCode(item_code, serial_code, location_code))
						{
							existing_qty = o_valid.oRecordset.mField("fAvailable_qty");
							item_type = o_valid.oRecordset.iField("iItem_typ");
							serial_num_exist = true;
						}
						else
						{
							existing_qty = 0M;
							serial_num_exist = false;
						}
						o_valid.Release();
						if (item_type == GlobalVar.goIVConstant.SERIAL_ITEM_NUM)
						{
							serial_grid[clsSerial.SERIAL_CODE_COL, row_num] = "";
							modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.DUPLICATE_IS_FOUND + "(" + serial_code + ")");
							return false;
						}
					}
				}

				if (o_valid.IsValidSerialCode(item_code, serial_code, loc_code))
				{
					existing_qty = o_valid.oRecordset.mField("fAvailable_qty");
					serial_num_exist = true;
				}
				else
				{
					existing_qty = 0M;
					serial_num_exist = false;
				}

				if (!o_valid.IsValidItemCode(item_code))
				{
					return false; // Not expected
				}
				else
				{
					item_type = o_valid.oRecordset.iField("iItem_typ");
				}

				if (oUtility.IsEmpty(serial_code) || oUtility.IsEmpty(item_code))
				{
					return true;
				}

				if (o_serial.PurchasingTransaction(trx_type))
				{

					if (item_type == GlobalVar.goIVConstant.LOT_ITEM_NUM)
					{
						serial_grid[clsSerial.SERIAL_CODE_COL, row_num] = serial_code;
						return true;
					}

					// One serial number can have only qty 1.
					//
					if (serial_num_exist)
					{
						if (existing_qty >= 1)
						{
							serial_grid[clsSerial.SERIAL_CODE_COL, row_num] = "";
							modDialogUtility.DisplayBox(ref cur_db, serial_code + cur_db.oLanguage.oMessage.ALREADY_EXISTS);
							return false;
						}
					}
					else if (UnpostedSerialNumberExist(ref cur_db, trx_type, trx_num, order_num, item_code, serial_code))
					{
						serial_grid[clsSerial.SERIAL_CODE_COL, row_num] = "";
						if (trx_type == GlobalVar.goConstant.TRX_IV_RECEIVING_TYPE)
						{
							modDialogUtility.DisplayBox(ref cur_db, serial_code + cur_db.oLanguage.oMessage.ALREADY_EXIST_NOT_INVOICED_YET);
						}
						else
						{
							modDialogUtility.DisplayBox(ref cur_db, serial_code + cur_db.oLanguage.oMessage.ALREADY_EXIST_NOT_POSTED_YET);
						}
						return false;
					}

					serial_grid[clsSerial.SERIAL_CODE_COL, row_num] = serial_code;
					return true;

				}
				else if (trx_type == GlobalVar.goConstant.TRX_CM_TYPE || trx_type == GlobalVar.goConstant.TRX_IV_SALES_RETURN_TYPE || trx_type == GlobalVar.goConstant.TRX_TRANSFER_IN_TYPE 
					|| trx_type == GlobalVar.goConstant.TRX_IV_MANUFACTURING_OUT_TYPE || trx_type == GlobalVar.goConstant.TRX_PHYSICAL_TYPE)
				{

					if (!serial_num_exist)
					{
						serial_grid[clsSerial.SERIAL_CODE_COL, row_num] = "";
						modDialogUtility.DisplayBox(ref cur_db, serial_code + cur_db.oLanguage.oMessage.DOES_NOT_EXIST);
						return false;
					}

					serial_grid[clsSerial.SERIAL_CODE_COL, row_num] = serial_code;
					return true;

				}

				if (serial_num_exist && !o_serial.PurchasingTransaction(trx_type))
				{
					if ((qty_needed - existing_qty) >= cur_db.fSmallestNumber)
					{
						existing_qty = cur_serial.GetQtyAvailable(trx_type, trx_num, item_code, serial_code, location_code); // GetQtyAvailable returns available_qty + qty committed to this transaction.
						if ((qty_needed - existing_qty) >= cur_db.fSmallestNumber)
						{
							modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NOT_ENOUGH_QTY + "(" + serial_code + ")");
							return false;
						}
					}
				}
				else
				{
					// Can be sold before arrival
					//
					modDialogUtility.DisplayBox(ref cur_db, serial_code + cur_db.oLanguage.oMessage.DOES_NOT_EXIST);
					return false;
				}

				o_valid.oRecordset.Release();
				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CheckQtyForEachSerialNumber)");
			}

			return return_value;
		}

		// This checks the qty in the original entry.
		//
		private decimal GetOriginalQty(ref clsDatabase cur_db, ref clsSerial cur_serial, int trx_type, int trx_num, string item_code, string serial_num, bool new_fl = false)
		{
			decimal return_value = 0M;
			string sql_str = null;
			clsRecordset cur_set = null;

			if (new_fl)
			{
				return 0;
			}

			cur_set = new clsRecordset(ref cur_db);

			sql_str = "SELECT SUM(fQty) AS iCount FROM tblGOSerialTransaction";
			sql_str += " WHERE iTransaction_typ = " + trx_type;
			sql_str += " AND iTransaction_num = " + trx_num;
			sql_str += " AND sItem_cd = '" + item_code + "'";
			sql_str += " AND sSerial_num = '" + serial_num + "'";

			if (!cur_set.CreateSnapshot(sql_str))
			{
				return_value = 0M;
			}
			else
			{
				return_value = cur_set.iField("iCount");
			}

			cur_set.Release();
			return return_value;
		}

		// This will fill the serial numbers automatically.
		//
		public void AutoFillSerialNumbers(ref clsDatabase cur_db, ref clsSerial cur_serial, ref string[,] serial_grid, int trx_type)
		{
			int i = 0;
			string prev_serial = null;
			string prev_item_code = null;
			clsValidate o_valid = new clsValidate(ref cur_db);

			i = 0;
			prev_serial = "";
			prev_item_code = "";

			while (i < serial_grid.GetLength(1))
			{
				if (oUtility.IsEmpty(oUtility.STrim(serial_grid[clsSerial.ITEM_CODE_COL, i])))
				{
					break;
				}

				if (oUtility.STrim(serial_grid[clsSerial.ITEM_CODE_COL, i]) != prev_item_code)
				{
					prev_item_code = oUtility.STrim(serial_grid[clsSerial.ITEM_CODE_COL, i]);
					prev_serial = oUtility.STrim(serial_grid[clsSerial.SERIAL_CODE_COL, i]);
				}
				else if (oUtility.STrim(serial_grid[clsSerial.ITEM_CODE_COL, i]) == prev_item_code && !oUtility.IsEmpty(oUtility.STrim(serial_grid[clsSerial.SERIAL_CODE_COL, i])))
				{
					prev_serial = oUtility.STrim(serial_grid[clsSerial.SERIAL_CODE_COL, i]);
				}
				else if (prev_item_code == oUtility.STrim(serial_grid[clsSerial.ITEM_CODE_COL, i]) && !oUtility.IsEmpty(prev_serial) && oUtility.IsEmpty(oUtility.STrim(serial_grid[clsSerial.SERIAL_CODE_COL, i])))
				{
					serial_grid[clsSerial.SERIAL_CODE_COL, i] = modGeneralUtility.IncreaseStringNumber(ref cur_db, prev_serial, 1).ToString();
					prev_serial = oUtility.STrim(serial_grid[clsSerial.SERIAL_CODE_COL, i]);
				}

				i += 1;
			}
		}

		// ************************************************************************************************************************************************************************************************
		// CAUTION 
		// ************************************************************************************************************************************************************************************************
		// This routine will mimic the logic that is used in Windows version that uses frmLot and clsSerial.sLotArray[) to hold serial/lot info between the calling routine and frmLot.
		// Since clsSerial.sLotArray holds data temporarily only during the current session in ASP envirenment, we need to rely on serial_grid, instead.
		// In order to ustilize the logic in clsSerial, some data manipulation is necessary as follows:
		//   1. When this is called, data in serial_grid needs to be copied to clsSerial.sLotArray[).
		//   2. Call the routines in clsSerial in order to apply the rules.
		//   3. When done, copy clsSerial.sLotArray[) back to serial_grid.
		//   4. Then, return.
		//
		public bool CreateSerialData(ref clsDatabase cur_db, ref clsSerial cur_serial, ref string[,] main_grid, ref string[,] serial_grid, int trx_type, int trx_num, bool new_fl
			, int item_code_col, int unit_code_col, int item_type_col, int qty_in_ivunit_col, int qty_shipped_col, int ivunit_code_col, int unit_price_col, int total_cost_col
			, int location_col, int line_id_col)
		{

			bool return_value = false;
			int col_num = 0;
			int row_num = 0;
			int max_row = 0;
			string[,] temp_array = null;
			string[,] main_array = null;
			bool check_db_fl = false;
			int total_qty = 0;

			if (trx_num <= 0 || trx_type <= 0)
			{
				return false;
			}

			if (serial_grid.GetLength(1) == 0)
			{
				//Return True
			}

			try
			{

				// Create the array that holds the main trasansaction details.
				//
				for (max_row = main_grid.GetLength(1) - 1; max_row >= 0; max_row--)
				{
					if (!oUtility.IsEmpty(main_grid[item_code_col, max_row]))
					{
						break;
					}
				}

				total_qty = 0;
				// Create main_array() from main_grid so that we can use the logics in clsSerial.
				//
				if (main_grid.GetLength(1) > 0)
				{
					oUtility.ResizeDim(ref main_array, main_grid.GetLength(0) - 1, main_grid.GetLength(1) - 1);
				}
				else
				{
					oUtility.ResizeDim(ref main_array, main_grid.GetLength(0) - 1, 0);
				}
				for (row_num = 0; row_num <= max_row; row_num++)
				{
					for (col_num = 0; col_num < main_grid.GetLength(0); col_num++)
					{
						main_array[col_num, row_num] = main_grid[col_num, row_num];
					}
					total_qty += oUtility.ToInteger(main_grid[qty_in_ivunit_col, row_num]);
				}

				cur_serial.InitSerialLotArray();
				cur_serial.InitSerialLotDetail();

				// ASP version loads the existing serial info when a record is read.
				//
				if (serial_grid.GetLength(1) > 0)
				{
					CopySerialGridToArray(ref cur_serial, ref serial_grid, ref cur_serial.sLotArray); // Copy the existing info from serial_grid to clsSerial.sLotArray[)
					cur_serial.bAlreadyCheckedInDatabase_fl = true; // Meaning no need to read from DB in the following routines with the same session.
				}

				oUtility.ResizeDim(ref temp_array, cur_serial.sLotArray.GetUpperBound(0), total_qty);

				if (cur_serial.ValidSerialLotDetail(ref main_array, item_code_col, unit_code_col, item_type_col, qty_in_ivunit_col, qty_shipped_col, ivunit_code_col, unit_price_col, total_cost_col, trx_type, trx_num, new_fl, true))
				{
					if (serial_grid.GetLength(1) > 0) // Has already valid data
					{
						return true;
					}
					else
					{
						// Otherwise, go down to copy cur_serial.sLotArray to serial_grid below
					}
				}
				else if (!cur_serial.CreateSerialLotArray(ref main_array, ref temp_array, item_code_col, unit_code_col, item_type_col, qty_in_ivunit_col, qty_shipped_col, ivunit_code_col, unit_price_col, total_cost_col, location_col, line_id_col))
				{
					return false;
				}
				else
				{
					// ---------------------------------------------------------------------------------------------------------------
					// After CreateSerialLotArray() is run, temp_array() will contain recommended combinations of item code/serial based on main_array.
					// CopySerialLotNumbers() will copy the current serial/lot numbers(in cur_serial.sLotArray) to the matching items in temp_array(). Then, temp_array() has the final/recommended combinations of item codes and serial numbers
					// goUtility.CopyArray will copy temp_array() back to cur_serial.sLotArray so that it can be consumed in the next steps below.
					// ---------------------------------------------------------------------------------------------------------------
					cur_serial.CopySerialLotNumbers(ref cur_serial.sLotArray, ref temp_array);
					oUtility.CopyArray(ref temp_array, ref cur_serial.sLotArray, clsSerial.TOTAL_COL - 1, cur_serial.iTotalRows - 1);
				}

				if (cur_serial.sLotArray.GetLength(1) > serial_grid.GetLength(1))
				{
					oUtility.ResizeDimPreserved(ref serial_grid, serial_grid.GetUpperBound(0), serial_grid.GetUpperBound(1) + 5);
				}

				for (row_num = 0; row_num < cur_serial.sLotArray.GetLength(1); row_num++)
				{
					if (!oUtility.IsEmpty(cur_serial.sLotArray[clsSerial.ITEM_CODE_COL, row_num]))
					{
						for (col_num = 0; col_num < cur_serial.sLotArray.GetLength(0); col_num++)
						{
							serial_grid[col_num, row_num] = cur_serial.sLotArray[col_num, row_num];
						}
					}
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CreateSerialData)");
			}

			return return_value;
		}

		// PURPOSE : This is to insert the serial/lot numbers into the invoice detail for printing.
		//
		public bool InsertSerialNumbersIntoDetail(ref clsDatabase cur_db, int trx_type, int trx_num, ref clsSerial cur_serial, ref string[,] main_grid, ref string[,] serial_grid, string detail_table_name, ref clsRecordset cur_set, string[] detail_field_names, int total_columns, string field_list, string value_list, int item_type_col, int item_code_col, int line_id_col, ref int line_num)
		{
			bool return_value = false;
			int detail_num = 0;
			int i = 0;
			int row_num = 0;
			int col_num = 0;
			int total_serial = 0;
			int serial_row_num = 0;
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsSerial o_serial = new clsSerial(ref cur_db);
			string sql_str = null;
			string additional_value_list = null;
			string additional_field_list = null;

			try
			{
				if (!cur_db.uSecurity.bIncludeSerialInInvoice_fl)
				{
					return true;
				}

				if (o_serial.IsSerialOrLotItem(oUtility.ToInteger(main_grid[item_type_col, row_num])))
				{
					for (serial_row_num = 0; serial_row_num < serial_grid.GetLength(1); serial_row_num++)
					{
						if (!oUtility.IsEmpty(main_grid[item_code_col, row_num]) && main_grid[item_code_col, row_num] == serial_grid[clsSerial.ITEM_CODE_COL, serial_row_num] 
							&& main_grid[line_id_col, row_num] == serial_grid[clsSerial.DETAIL_LINE_ID_COL, serial_row_num])
						{
							line_num += 1;

							additional_value_list = "," + line_num.ToString();
							for (col_num = 0; col_num < total_columns; col_num++)
							{
								if (!oUtility.IsEmpty(oUtility.STrim(detail_field_names[col_num]))) // Attach if field name exist.
								{
									if (oUtility.SUCase(detail_field_names[col_num]) == oUtility.SUCase("sItem_cd"))
									{
										additional_value_list += ",''";
									}
									else if (oUtility.SUCase(detail_field_names[col_num]) == oUtility.SUCase("iItem_typ"))
									{
										additional_value_list += "," + oUtility.ToValue(main_grid[item_type_col, row_num]).ToString();
									}
									else if (oUtility.SUCase(detail_field_names[col_num]) == oUtility.SUCase("sDescription"))
									{
										if (oUtility.ToValue(main_grid[item_type_col, row_num]) == GlobalVar.goIVConstant.SERIAL_ITEM_NUM)
										{
											additional_value_list += ",'" + cur_db.oLanguage.oString.STR_SERIAL_NUM_MARKER + serial_grid[clsSerial.SERIAL_CODE_COL, serial_row_num] + "'";
										}
										else
										{
											additional_value_list += ",'" + cur_db.oLanguage.oString.STR_LOT_NUM_MARKER + serial_grid[clsSerial.SERIAL_CODE_COL, serial_row_num] + "'";
										}
									}
									else
									{
										additional_value_list += "," + o_gen.EncloseField(detail_field_names[col_num], "", cur_set.Size(detail_field_names[col_num]));
									}
								}
								modGeneralUtility.RunEvents();
							}

							sql_str = "INSERT INTO " + detail_table_name + "(";
							sql_str += field_list;
							sql_str += ") VALUES(" + value_list + additional_value_list + ")";

							if (!cur_db.ExecuteSQL(sql_str))
							{
								return return_value;
							}
						}
					}
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(InsertSerialNumbersIntoDetail)");
			}

			return return_value;

		}

		// PURPOSE : To eliminate the serial/lot numbers embeded in the transaction detail.
		//
		public void DeleteSerialNumbersFromDetail(ref clsDatabase cur_db, ref clsSerial cur_serial, ref string[,] main_grid, int item_code_col, int item_type_col)
		{
			int i = 0;
			clsSerial o_serial = new clsSerial(ref cur_db);

			try
			{
				if (!cur_db.uSecurity.bIncludeSerialInInvoice_fl) // Serial/lot numbers are not embeded in the detail.
				{
					return;
				}

				for (i = main_grid.GetLength(1) - 1; i >= 0; i--)
				{
					if (oUtility.IsEmpty(main_grid[item_code_col, i]) && o_serial.IsSerialOrLotItem((oUtility.ToInteger(main_grid[item_type_col, i]))))
					{
						oArray.DeleteCurrentRow(ref main_grid, i); 
					}
				}

			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(DeleteSerialNumbersFromDetail)");
			}

		}

		public bool ShowSerialHistory(ref clsDatabase cur_db, ref string[,] serial_grid, int trx_type, int trx_num)
		{
			bool return_value = false;
			string sql_str = null;
			clsRecordset cur_set = null;
			string tmp = null;
			int row_num = 0;
			DataTable dt = new DataTable();
			DataRow dr = null;

			try
			{
				cur_set = new clsRecordset(ref cur_db);

				sql_str = "SELECT * FROM tblGOSerialTransaction";
				sql_str += " WHERE iTransaction_typ = " + trx_type.ToString();
				sql_str += " AND iTransaction_num = " + trx_num.ToString();
				sql_str += " ORDER BY sItem_cd, sSerial_num";

				if (!cur_set.CreateSnapshot(sql_str))
				{
					return false;
				}
				else if (cur_set.EOF())
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NO_RECORDS_FOUND);
					return false;
				}

				oUtility.ResizeDim(ref serial_grid, serial_grid.GetUpperBound(0), cur_set.RecordCount() - 1);
				row_num = 0;

				while (!cur_set.EOF())
				{
					serial_grid[0, row_num] = cur_set.sField("sItem_cd");
					serial_grid[1, row_num] = cur_set.sField("sSerial_num");

					cur_set.MoveNext();
					row_num += 1;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ShowSerialHistory)");
			}

			return return_value;
		}

		public bool AddOneSerialItem(ref clsDatabase cur_db, ref string[,] serial_grid, int trx_type, int trx_num, string item_code, string serial_num, string location_code
			, ref int expiration_dt, int warranty_date, int line_id_num, string unit_code, decimal qty, decimal unit_price, decimal unit_cost, bool no_duplicate_allowed_fl)
		{

			bool return_value = false;
			int row_num = 0;
			clsSerial o_serial = new clsSerial(ref cur_db);
			clsGeneral o_general = new clsGeneral(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);

			try
			{

				for (row_num = 0; row_num < serial_grid.GetLength(1); row_num++)
				{
					if (oUtility.IsEmpty(serial_grid[clsSerial.ITEM_CODE_COL, row_num]) && !oUtility.IsEmpty(serial_grid[clsSerial.SERIAL_CODE_COL, row_num]))
					{
						break;
					}
					else if (no_duplicate_allowed_fl && serial_grid[clsSerial.ITEM_CODE_COL, row_num] == item_code && serial_grid[clsSerial.SERIAL_CODE_COL, row_num] == serial_num)
					{
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.DUPLICATE_IS_FOUND + "(" + item_code + "/" + serial_num + ")");
						return false;
					}
				}

				if (row_num >= serial_grid.GetLength(1))
				{
					oUtility.ResizeDimPreserved(ref serial_grid, serial_grid.GetUpperBound(0), serial_grid.GetUpperBound(1) + row_num - 1);
				}

				serial_grid[clsSerial.ITEM_CODE_COL, row_num] = item_code;
				serial_grid[clsSerial.SERIAL_CODE_COL, row_num] = serial_num;
				serial_grid[clsSerial.DATE_EXPIRES_COL, row_num] = o_general.ToStrDate(expiration_dt);
				serial_grid[clsSerial.DATE_WARRANTY_EXPIRES_COL, row_num] = o_general.ToStrDate(warranty_date);
				serial_grid[clsSerial.DETAIL_LINE_ID_COL, row_num] = line_id_num.ToString();
				serial_grid[clsSerial.UNIT_CODE_COL, row_num] = unit_code;
				serial_grid[clsSerial.QTY_COL, row_num] = Convert.ToString(oUtility.RoundToQtyFactor(qty));
				serial_grid[clsSerial.UNIT_PRICE_COL, row_num] = o_money.ToStrMoney(unit_price);
				serial_grid[clsSerial.UNIT_COST_COL, row_num] = o_money.ToStrMoney(unit_cost);
				serial_grid[clsSerial.LOCATION_CODE_COL, row_num] = location_code;

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(AddOneSerialItem)");
			}

			return return_value;
		}

		public bool UpdateSerialQty(ref clsDatabase cur_db, ref string[,] serial_grid, int trx_type, int trx_num, int line_id, decimal qty)
		{
			bool return_value = false;
			int row_num = 0;
			clsSerial o_serial = new clsSerial(ref cur_db);

			try
			{
				if (line_id <= 0)
				{
					return true;
				}

				for (row_num = 0; row_num < serial_grid.GetLength(1); row_num++)
				{
					if (oUtility.ToValue(serial_grid[clsSerial.DETAIL_LINE_ID_COL, row_num]) == line_id)
					{
						break;
					}
				}

				if (row_num >= serial_grid.GetLength(1))
				{
					return true; // Not found but just return true and let the user handle the situation.
				}

				serial_grid[clsSerial.QTY_COL, row_num] = qty.ToString();
				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(UpdateSerialQty)");
			}

			return return_value;
		}

		public bool DeleteSerialLine(ref clsDatabase cur_db, ref string[,] serial_grid, int trx_type, int trx_num, int line_id)
		{
			bool return_value = false;
			int row_num = 0;
			int next_num = 0;
			int col_num = 0;
			clsSerial o_serial = new clsSerial(ref cur_db);

			try
			{
				if (line_id <= 0) // line_id starts from 1
				{
					return true; // Just return
				}

				for (row_num = 0; row_num < serial_grid.GetLength(1); row_num++)
				{
					if (oUtility.ToValue(serial_grid[clsSerial.DETAIL_LINE_ID_COL, row_num]) == line_id)
					{
						break;
					}
				}

				if (row_num >= serial_grid.GetLength(1))
				{
					return true; // Not found, but just return true and let the user handle the situation.
				}

				// Move the lines up.
				for (next_num = row_num; next_num <= serial_grid.GetLength(1) - 2; next_num++)
				{
					for (col_num = 0; col_num < serial_grid.GetLength(0); col_num++)
					{
						serial_grid[col_num, next_num] = serial_grid[col_num, next_num + 1];
					}
				}

				for (col_num = 0; col_num < serial_grid.GetLength(0); col_num++)
				{
					serial_grid[col_num, serial_grid.GetLength(1) - 1] = "";
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(DeleteSerialLine)");
			}

			return return_value;
		}

		//  PURPOSE:  To load the data from database into array/grid.
		//
		public bool LoadSerialDetailIntoArray(ref clsDatabase cur_db, ref clsSerial cur_serial, ref string[,] serial_grid, int trx_type, int trx_num)
		{
			bool return_value = false;
			int line_num = 0;

			try
			{

				// We will use the funcationalities in clsSerial
				//
				cur_serial.InitSerialLotArray();
				cur_serial.InitSerialLotDetail();

				if (!cur_serial.LoadSerialLotDetailIntoArray(trx_type, trx_num))
				{
					return false;
				}

				oUtility.ResizeDim(ref serial_grid, serial_grid.GetUpperBound(0), serial_grid.GetUpperBound(1));
				
				line_num = 0;
				CopySerialArrayToGrid(ref cur_db, ref cur_serial, ref serial_grid, ref cur_serial.sLotArray);

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadSerialDetailIntoArray)");
			}

			return return_value;
		}

		public bool ProcessSerialEntry(ref clsDatabase cur_db, ref string[,] main_grid, ref string[,] serial_grid, ref clsSerial cur_serial, int trx_type, int trx_num, int order_num
			, string location_code, int main_item_code_col, int main_unit_code_col, int col_num, int row_num)
		{

			bool return_value = false;

			if (col_num == clsSerial.ITEM_CODE_COL)
			{
				if (!ProcessItem(ref cur_db, ref main_grid, ref serial_grid, ref cur_serial, col_num, row_num, trx_type, trx_num, order_num))
				{
					return false;
				}
			}
			else if (col_num == clsSerial.SERIAL_CODE_COL)
			{
				if (!ProcessSerial(ref cur_db, ref main_grid, ref serial_grid, ref cur_serial, trx_type, trx_num, order_num, col_num, row_num, location_code))
				{
					return false;
				}
				if (serial_grid.GetLength(1) > (row_num + 1))
				{
					if (oUtility.ToValue(serial_grid[clsSerial.QTY_COL, row_num]) > 0 && !oUtility.IsEmpty(serial_grid[clsSerial.ITEM_CODE_COL, row_num + 1]))
					{
						//SpreadsheetSetActiveCell(serial_grid, row_num + 1, col_num)
					}
				}
			}
			else if (col_num == clsSerial.QTY_COL)
			{
				if (!ProcessQty(ref cur_db, ref main_grid, ref serial_grid, ref cur_serial, trx_type, trx_num, col_num, row_num, location_code))
				{
					return false;
				}
			}
			else if (col_num == clsSerial.DATE_EXPIRES_COL || col_num == clsSerial.DATE_WARRANTY_EXPIRES_COL)
			{
				if (!ProcessDate(ref cur_db, ref main_grid, ref serial_grid, ref cur_serial, col_num, row_num))
				{
					return false;
				}
			}

			return true;
		}

		private bool ProcessItem(ref clsDatabase cur_db, ref string[,] main_grid, ref string[,] serial_grid, ref clsSerial cur_serial, int col_num, int row_num, int trx_type
			, int trx_num, int order_num)
		{
			bool return_value = false;
			string item_code = null;
			string serial_num = null;
			string trx_str = null;
			int i = 0;
			int m = 0;
			int original_trx_type = 0;
			clsValidate o_valid = new clsValidate(ref cur_db);
			bool found_by_serial_num_fl = false;

			try
			{

				item_code = oUtility.SUCase(oUtility.STrim(serial_grid[col_num, row_num]));

				if (oUtility.IsEmpty(item_code))
				{
					for (i = 0; i < serial_grid.GetLength(0); i++)
					{
						serial_grid[i, row_num] = "";
					}
					return true;
				}

				if ((trx_type == GlobalVar.goConstant.TRX_CM_TYPE || trx_type == GlobalVar.goConstant.TRX_DM_TYPE) && order_num > 0)
				{
					if (trx_type == GlobalVar.goConstant.TRX_CM_TYPE)
					{
						original_trx_type = GlobalVar.goConstant.TRX_INVOICE_TYPE;
						trx_str = cur_db.oLanguage.oString.STR_INVOICE;
					}
					else
					{
						original_trx_type = GlobalVar.goConstant.TRX_PURCHASE_TYPE;
						trx_str = cur_db.oLanguage.oString.STR_VOUCHER;
					}
					if (!o_valid.IsValidItemCode(item_code, false, false, original_trx_type, order_num))
					{
						modDialogUtility.DisplayBox(ref cur_db, item_code + cur_db.oLanguage.oMessage.DOES_NOT_APPEAR_IN + trx_str + "#: " + order_num.ToString());
						return false;
					}
				}
				else
				{
					// VERY IMPORTANT ------------------------------------------------------------------------
					// New item code is NOT allowed.
					// item code entry is allowed only when qty is split with different serial/lot numbers.
					// meaning that the item code should already appear in serial_grid.
					//
					for (i = 0; i < serial_grid.GetLength(1); i++)
					{
						if (i != row_num && serial_grid[clsSerial.ITEM_CODE_COL, i] == item_code) // Copy the item's information over to the new line.
						{
							for (m = 0; m < serial_grid.GetLength(0); m++)
							{
								serial_grid[m, row_num] = serial_grid[m, i];
							}
							serial_grid[col_num, row_num] = item_code;
							serial_grid[clsSerial.SERIAL_CODE_COL, row_num] = "";
							serial_grid[clsSerial.QTY_COL, row_num] = "";
							break;
						}
					}
					if (i >= serial_grid.GetLength(1)) // Not found in the serial_grid.
					{
						modDialogUtility.DisplayBox(ref cur_db, item_code + cur_db.oLanguage.oMessage.IS_INVALID);
						serial_grid[col_num, row_num] = "";
						return false;
					}
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessItem)");
			}

			return return_value;
		}

		private bool ProcessQty(ref clsDatabase cur_db, ref string[,] main_grid, ref string[,] serial_grid, ref clsSerial cur_serial, int trx_type, int trx_num, int col_num
			, int row_num, string location_code)
		{
			bool return_value = false;
			decimal new_qty = 0M;
			decimal existing_qty = 0M;
			string item_code = serial_grid[clsSerial.ITEM_CODE_COL, row_num];
			string serial_code = serial_grid[clsSerial.SERIAL_CODE_COL, row_num];
			clsValidate o_valid = new clsValidate(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);

			try
			{

				new_qty = oUtility.RoundToQtyFactor(o_money.ToNumMoney(serial_grid[col_num, row_num]));

				if (new_qty < cur_db.fSmallestNumber)
				{
					serial_grid[col_num, row_num] = "1";
					return true;
				}

				if (new_qty > 1M && !oUtility.IsEmpty(serial_grid[clsSerial.ITEM_CODE_COL, row_num]))
				{
					if (!o_valid.IsValidItemCode(serial_grid[clsSerial.ITEM_CODE_COL, row_num]))
					{
						// not expected.
					}
					if (o_valid.oRecordset.iField("iItem_typ") == GlobalVar.goIVConstant.SERIAL_ITEM_NUM)
					{
						serial_grid[clsSerial.QTY_COL, row_num] = "1";
						return true;
					}
				}

				if (oUtility.IsEmpty(serial_code) || oUtility.IsEmpty(item_code))
				{
					// let it go
				}
				else if (cur_serial.QualifiedToCommitQty(trx_type))
				{
					existing_qty = cur_serial.GetQtyAvailable(trx_type, trx_num, item_code, serial_code, location_code); // GetQtyAvailable returns available_qty + qty committed to this transaction.
					if ((new_qty - existing_qty) >= cur_db.fSmallestNumber)
					{
						iDialogRequested_typ = DIALOG_REQUESTED_IN_QTY_VALIDATION;
						sDialogMessageRequested = cur_db.oLanguage.oMessage.NOT_ENOUGH_QTY + cur_db.oLanguage.oMessage.WOULD_LIKE_PROCEED;
						return false;
					}
				}

				serial_grid[col_num, row_num] = new_qty.ToString();

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessQty)");
			}

			return return_value;
		}

		private bool ProcessDate(ref clsDatabase cur_db, ref string[,] main_grid, ref string[,] serial_grid, ref clsSerial cur_serial, int col_num, int row_num)
		{

			bool return_value = false;
			string tmp = null;
			clsValidate o_valid = new clsValidate(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			tmp = serial_grid[col_num, row_num];

			if (oUtility.IsEmpty(tmp))
			{
				return_value = true;
			}
			else if (o_gen.ValidDate(ref tmp))
			{
				serial_grid[col_num, row_num] = tmp;
				return_value = true;
			}

			return return_value;

		}

		public bool IsValidItem(ref string[,] serial_grid, ref clsSerial cur_serial, string item_code)
		{
			bool return_value = false;
			int row_num = 0;

			for (row_num = 0; row_num < serial_grid.GetLength(1); row_num++)
			{
				if (item_code == serial_grid[clsSerial.ITEM_CODE_COL, row_num])
				{
					return true;
				}
			}

			return return_value;
		}

		private bool ProcessSerial(ref clsDatabase cur_db, ref string[,] main_grid, ref string[,] serial_grid, ref clsSerial cur_serial, int trx_type, int trx_num, int order_num
			, int col_num, int row_num, string location_code)
		{
			bool return_value = false;
			string item_code = null;
			string serial_code = null;
			string trx_str = null;
			decimal qty_needed = 0M;
			decimal existing_qty = 0M;
			bool serial_num_exist = false;
			int item_type = 0;
			int i = 0;
			int original_trx_type = 0;
			clsValidate o_valid = new clsValidate(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			try
			{

				item_code = serial_grid[clsSerial.ITEM_CODE_COL, row_num];
				serial_code = oUtility.SUCase(oUtility.STrim(serial_grid[clsSerial.SERIAL_CODE_COL, row_num]));
				qty_needed = oUtility.ToValue(serial_grid[clsSerial.QTY_COL, row_num]);

				if (oUtility.IsEmpty(serial_code) || oUtility.IsEmpty(item_code))
				{
					return true;
				}

				if ((trx_type == GlobalVar.goConstant.TRX_CM_TYPE || trx_type == GlobalVar.goConstant.TRX_DM_TYPE) && order_num > 0)
				{
					if (trx_type == GlobalVar.goConstant.TRX_CM_TYPE)
					{
						original_trx_type = GlobalVar.goConstant.TRX_INVOICE_TYPE;
						trx_str = cur_db.oLanguage.oString.STR_INVOICE;
					}
					else
					{
						original_trx_type = GlobalVar.goConstant.TRX_PURCHASE_TYPE;
						trx_str = cur_db.oLanguage.oString.STR_VOUCHER;
					}
					if (!o_valid.IsValidSerialCode(item_code, serial_code, "", original_trx_type, order_num))
					{
						modDialogUtility.DisplayBox(ref cur_db, item_code + " / " + serial_code + cur_db.oLanguage.oMessage.DOES_NOT_APPEAR_IN + trx_str + "#: " + order_num.ToString());
						return false;
					}
				}
				else
				{
					if (!IsValidItem(ref serial_grid, ref cur_serial, item_code))
					{
						modDialogUtility.DisplayBox(ref cur_db, item_code + cur_db.oLanguage.oMessage.IS_INVALID);
						return false;
					}
				}

				if (o_valid.IsValidSerialCode(item_code, serial_code, location_code))
				{
					existing_qty = o_valid.oRecordset.mField("fAvailable_qty");
					item_type = o_valid.oRecordset.iField("iItem_typ");
					serial_num_exist = true;
				}
				else
				{
					existing_qty = 0M;
					serial_num_exist = false;
				}

				o_valid.oRecordset.Release();

				// See if this number is entered more than once in this screen.
				//
				if (item_type == GlobalVar.goIVConstant.SERIAL_ITEM_NUM)
				{
					for (i = 0; i < serial_grid.GetLength(1); i++)
					{
						if (oUtility.IsEmpty(oUtility.STrim(serial_grid[clsSerial.ITEM_CODE_COL, i])))
						{
							break;
						}
						else if (row_num == i)
						{
							// ignore the current line
						}
						else if (serial_grid[clsSerial.ITEM_CODE_COL, i] == item_code && serial_grid[clsSerial.SERIAL_CODE_COL, i] == serial_code)
						{
							serial_grid[clsSerial.SERIAL_CODE_COL, row_num] = "";
							modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.DUPLICATE_IS_FOUND + "(" + serial_code + ")");
							return false;
						}
					}
				}

				if (trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE || trx_type == GlobalVar.goConstant.TRX_IV_PURCHASE_TYPE || trx_type == GlobalVar.goConstant.TRX_IV_RECEIVING_TYPE 
					|| trx_type == GlobalVar.goConstant.TRX_IV_MANUFACTURING_TYPE || trx_type == GlobalVar.goConstant.TRX_WH_RECEIVING_SLIP_TYPE)
				{

					if (item_type == GlobalVar.goIVConstant.LOT_ITEM_NUM)
					{
						serial_grid[col_num, row_num] = serial_code;
						return true; // Do not care
					}

					// One serial number can have only qty 1.
					//
					if (serial_num_exist)
					{
						if (existing_qty >= 1)
						{
							modDialogUtility.DisplayBox(ref cur_db, serial_code + cur_db.oLanguage.oMessage.ALREADY_EXISTS);
							return false;
						}
					}
					else if (UnpostedSerialNumberExist(ref cur_db, trx_type, trx_num, order_num, item_code, serial_code))
					{
						if (trx_type == GlobalVar.goConstant.TRX_IV_RECEIVING_TYPE)
						{
							modDialogUtility.DisplayBox(ref cur_db, serial_code + cur_db.oLanguage.oMessage.ALREADY_EXIST_NOT_INVOICED_YET);
						}
						else
						{
							modDialogUtility.DisplayBox(ref cur_db, serial_code + cur_db.oLanguage.oMessage.ALREADY_EXIST_NOT_POSTED_YET);
						}
						return false;
					}

					serial_grid[clsSerial.SERIAL_CODE_COL, row_num] = serial_code;
					return true;

				}
				else if (trx_type == GlobalVar.goConstant.TRX_CM_TYPE || trx_type == GlobalVar.goConstant.TRX_IV_SALES_RETURN_TYPE || trx_type == GlobalVar.goConstant.TRX_TRANSFER_IN_TYPE 
					|| trx_type == GlobalVar.goConstant.TRX_PHYSICAL_TYPE)
				{

					if (!serial_num_exist)
					{
						modDialogUtility.DisplayBox(ref cur_db, serial_code + cur_db.oLanguage.oMessage.DOES_NOT_EXIST); // Not possible to receive invalid one.
						return false;
					}

					if ((item_type == GlobalVar.goIVConstant.SERIAL_ITEM_NUM) && (existing_qty >= 1))
					{
						modDialogUtility.DisplayBox(ref cur_db, serial_code + cur_db.oLanguage.oMessage.ALREADY_EXISTS);
						return false;
					}

					serial_grid[col_num, row_num] = serial_code;
					return true;
				}

				if (serial_num_exist)
				{
					if ((qty_needed - existing_qty) >= cur_db.fSmallestNumber)
					{
						existing_qty = cur_serial.GetQtyAvailable(trx_type, trx_num, item_code, serial_code, location_code); // GetQtyAvailable returns available_qty + qty committed to this transaction.
						if ((qty_needed - existing_qty) >= cur_db.fSmallestNumber)
						{
							iDialogRequested_typ = DIALOG_REQUESTED_IN_SERIAL_NUM_VALIDATION;
							sDialogMessageRequested = cur_db.oLanguage.oMessage.NOT_ENOUGH_QTY + cur_db.oLanguage.oMessage.WOULD_LIKE_PROCEED;
							return false;
						}
					}
				}
				else
				{
					// Can be sold before arrival
					//
					iDialogRequested_typ = DIALOG_REQUESTED_IN_SERIAL_NUM_VALIDATION;
					sDialogMessageRequested = serial_code + cur_db.oLanguage.oMessage.DOES_NOT_EXIST + cur_db.oLanguage.oMessage.WOULD_LIKE_PROCEED;
					return false;
				}

				serial_grid[col_num, row_num] = serial_code;
				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessSerial)");
			}

			return return_value;
		}

		// This checks if there is unposted serial numbers for the purchase types
		//
		private bool UnpostedSerialNumberExist(ref clsDatabase cur_db, int trx_type, int trx_num, int order_num, string item_code, string serial_num)
		{
			bool return_value = false;
			string sql_str = null;
			clsRecordset cur_set = null;

			cur_set = new clsRecordset(ref cur_db);

			sql_str = "SELECT COUNT(sSerial_num) AS iMaxNum FROM tblGOSerialTransaction s";

			if (trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE)
			{
				sql_str += " INNER JOIN tblAPChargeUnposted t";
				sql_str += " ON t.iTransaction_typ = s.iTransaction_typ";
				sql_str += " AND t.iTransaction_num = s.iTransaction_num";
				sql_str += " WHERE t.iTransaction_typ = " + trx_type;
				sql_str += " AND t.iTransaction_num <> " + trx_num;
			}
			else if (trx_type == GlobalVar.goConstant.TRX_IV_PURCHASE_TYPE)
			{
				sql_str += " INNER JOIN tblIVTransactionUnposted t";
				sql_str += " ON t.iTransaction_typ = s.iTransaction_typ";
				sql_str += " AND t.iTransaction_num = s.iTransaction_num";
				sql_str += " WHERE t.iTransaction_typ = " + trx_type;
				sql_str += " AND t.iTransaction_num <> " + trx_num;
			}
			else if (trx_type == GlobalVar.goConstant.TRX_IV_RECEIVING_TYPE)
			{
				sql_str += " INNER JOIN tblIVTransactionUnposted t";
				sql_str += " ON t.iTransaction_typ = s.iTransaction_typ";
				sql_str += " AND t.iTransaction_num = s.iTransaction_num";
				sql_str += " WHERE t.iTransaction_typ = " + trx_type;
				sql_str += " AND t.iTransaction_num <> " + trx_num;
				sql_str += " AND t.iTransfer_num = " + order_num;
			}
			else
			{
				return false;
			}

			sql_str += " AND s.sItem_cd = '" + item_code + "'";
			sql_str += " AND s.sSerial_num = '" + serial_num + "'";

			if (!cur_set.CreateSnapshot(sql_str))
			{
				return false;
			}
			else if (cur_set.iField("iMaxNum") >= 1)
			{
				return_value = true;
			}
			else
			{
				return_value = false;
			}

			cur_set.Release();
			return return_value;

		}

		public bool IsEmpty(ref string[,] serial_grid, ref clsSerial cur_serial)
		{

			bool return_value = false;
			int row_num = 0;

			for (row_num = 0; row_num < serial_grid.GetLength(1); row_num++)
			{
				if (!oUtility.IsEmpty(serial_grid[clsSerial.ITEM_CODE_COL, row_num]) && !oUtility.IsEmpty(serial_grid[clsSerial.SERIAL_CODE_COL, row_num]) 
					&& !oUtility.IsEmpty(serial_grid[clsSerial.DETAIL_LINE_ID_COL, row_num]))
				{
					return false;
				}
			}

			return true;
		}

		// This is to read the serial/lot data to begin an existing transaction.
		//
		public bool ReadSerialData(ref clsDatabase cur_db, ref clsSerial cur_serial, ref string[,] serial_grid, int trx_type, int trx_num)
		{
			bool return_value = false;
			int row_num = 0;
			int col_num = 0;
			int max_row = 0;
			int i = 0;

			int item_code_col = Models.clsChargeDetail.ITEM_CODE_COL;
			int item_type_col = Models.clsChargeDetail.ITEM_TYPE_COL;
			int line_id_col = Models.clsChargeDetail.LINE_ID_COL;
			int serial_code_col = Models.clsChargeDetail.SERIAL_CODE_COL;

			try
			{
				cur_serial.InitSerialLotArray();
				cur_serial.InitSerialLotDetail();

				if (trx_type == GlobalVar.goConstant.TRX_TRANSFER_TYPE)
                {
					item_code_col = clsIVTransaction.ITEM_CODE_COL;
					item_type_col = clsIVTransaction.ITEM_TYPE_COL;
					line_id_col = clsIVTransaction.LINE_ID_COL;
					serial_code_col = clsIVTransaction.SERIAL_CODE_COL;
				}

				if (!cur_serial.LoadSerialLotDetailIntoArray(trx_type, trx_num))
				{
					return false;
				}

				for (row_num = 0; row_num <= serial_grid.GetUpperBound(1); row_num ++)
                {
					if (GlobalVar.goUtility.IsNonEmpty(serial_grid[item_code_col, row_num]) 
					&& cur_serial.IsSerialOrLotItem(GlobalVar.goUtility.ToInteger(serial_grid[item_type_col, row_num])))
                    {
						for (i = 0; i <= cur_serial.sLotArray.GetUpperBound(1); i++)
                        {
							if (serial_grid[item_code_col, row_num] == cur_serial.sLotArray[clsSerial.ITEM_CODE_COL, i] 
							&& GlobalVar.goUtility.ToInteger(serial_grid[line_id_col, row_num]) == GlobalVar.goUtility.ToInteger(cur_serial.sLotArray[clsSerial.DETAIL_LINE_ID_COL, i]))
                            {
								serial_grid[serial_code_col, row_num] = cur_serial.sLotArray[clsSerial.SERIAL_CODE_COL, i];
							}
                        }
                    }
                }

				return true;

				for (max_row = cur_serial.sLotArray.GetLength(1) - 1; max_row >= 0; max_row--)
				{
					if (!oUtility.IsEmpty(cur_serial.sLotArray[clsSerial.ITEM_CODE_COL, max_row]))
					{
						break;
					}
				}

				//If max_row  > serial_grid.GetLength(1) Then
				oUtility.ResizeDimPreserved(ref serial_grid, serial_grid.GetUpperBound(0), serial_grid.GetUpperBound(1) + max_row + 5);
				//End If

				for (row_num = 0; row_num <= max_row; row_num++)
				{
					if (!oUtility.IsEmpty(cur_serial.sLotArray[clsSerial.ITEM_CODE_COL, row_num]))
					{
						for (col_num = 0; col_num < cur_serial.sLotArray.GetLength(0); col_num++)
						{
							serial_grid[col_num, row_num] = cur_serial.sLotArray[col_num, row_num];
						}
					}
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ReadSerialData)");
			}

			return return_value;
		}

		public void InitSerialControls(ref clsDatabase cur_db, ref clsSerial cur_serial, ref string[,] serial_grid, int trx_type)
		{

			//if (cur_serial.PurchasingTransaction(trx_type))
			//{
			//	autofill_button.Visible = true;
			//	autofill_button.ToolTip = "Will generate new serial/lot numbers for the same item, starting from the first number you enter.";
			//}
			//else
			//{
			//	autofill_button.Visible = false;
			//}

		}

		public void ClearSerialNumbers(ref clsDatabase cur_db, ref clsSerial cur_serial, ref string[,] serial_grid)
		{
			int row_num = 0;

			try
			{
				for (row_num = 0; row_num < serial_grid.GetLength(1); row_num++)
				{
					serial_grid[clsSerial.SERIAL_CODE_COL, row_num] = "";
				}
			}
			catch (Exception ex)
			{

			}

		}

	}

}
