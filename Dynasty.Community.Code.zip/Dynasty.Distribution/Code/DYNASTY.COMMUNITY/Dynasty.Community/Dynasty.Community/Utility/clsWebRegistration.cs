﻿//  Copyright (c) DynastySoft Corporation, 2002.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//
// +++++++++++++++++++++++++++++++++++++++
// THIS CLASS INCLUDE PRODUCT KEY VALIDATION
// +++++++++++++++++++++++++++++++++++++++
//



using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Database;

namespace Dynasty.ASP
{
	public class clsWebRegistration
	{

		// THESE ARE DB CONNECTION-RELATED VARS THAT ALL CLASSES MUST CARRY FROM NOW ON 08/20/2011.
		//
		private bool bConnected;
		private clsDatabase oDatabase = new clsDatabase();

		// General objects that are used acrossed modules.
		// These are database-dependant.
		//
		private clsGeneral oGeneral;

		public const int PRODUCT_KEY_LENGTH = 14;

		private bool bRegistered;
		private string sProductKey;
		private string sActivationCode;
		private string sLicensee;

		public clsWebRegistration(ref clsDatabase cur_db, bool internal_call_fl = false) : base()
		{


			try
			{

					oDatabase = cur_db;

					if (!internal_call_fl) // THIS WILL STOP INFINITE CALLS
					{
						if (!InitLocalObjects(ref cur_db))
						{
							return;
						}
					}

					bConnected = true;
					return;

			}
			catch (Exception ex)
			{
						bConnected = false;

			}

		}

		private bool InitLocalObjects(ref clsDatabase cur_db)
		{

			bool return_value = false;
			try
			{

					oGeneral = new clsGeneral(ref oDatabase);

					return true;

			}
			catch (Exception ex)
			{
						return return_value;

			}

		}

		public void Release()
		{

			try
			{

			}
			catch (Exception ex)
			{

			}

		}

		// Set the connection manually.
		//
		public void SetDBConnection(ref clsDatabase cur_db)
		{
			oDatabase = cur_db;
			bConnected = true;
		}

		public bool IsErrorFound()
		{

			bool return_value = false;
			return_value = !GlobalVar.goUtility.IsEmpty(oDatabase.sPostingError);
			return return_value;
		}

		public string GetErrorMessage()
		{

			string return_value = null;
			return_value = oDatabase.sPostingError;
			oDatabase.sPostingError = "";
			return return_value;
		}

		public string GetLicensee()
		{

			string return_value = null;
			return_value = sLicensee;

			return return_value;
		}

		public string GetProductKey()
		{

			string return_value = null;
			return_value = sProductKey;

			return return_value;
		}

		public string GetActivationCode()
		{

			string return_value = null;
			return_value = sActivationCode;

			return return_value;
		}

		public bool SetRegistrationKeys(string product_key, string activation_code)
		{

			bool return_value = false;
			if (ValidateActivationCode(product_key, activation_code))
			{
				sProductKey = product_key;
				sActivationCode = activation_code;
				sLicensee = DecodeLicensee(activation_code);
			}
			else
			{
				sProductKey = "";
				sActivationCode = "";
				sLicensee = "";
			}

			return return_value;
		}

		public bool CheckRegistration()
		{

			bool return_value = false;
			return_value = true;

			return return_value;
		}

		// PURPOSE : To validate the activation code against the product key.
		//           Activation code =
		//           chr(asc('A') + goUtility.SLength(company name) + random_num)
		//           + 3 digits of encoded product_key
		//           + a randome char
		//           + the company name.
		//
		public bool ValidateActivationCode(string product_key, string activation_code)
		{

			bool return_value = false;
			string odd_key = null;
			int rand_num = 0;
			int key_num = 0;
			int total_value = 0;
			string even_key = null;
			int i = 0;

			try
			{

				product_key = GlobalVar.goUtility.SReplace(product_key, "-", "");

				if (GlobalVar.goUtility.SLength(product_key) >= GlobalVar.goUtility.SLength(activation_code))
				{
					return return_value;
				}

				total_value = 0;
				for (i = 1; i < GlobalVar.goUtility.SLength(activation_code); i++)
				{
					var tempVar = true;
					total_value = (total_value + GetAsciiValue(activation_code, i, ref tempVar)) % 36;
				}

				var tempVar2 = true;
				if (GetCharValue(total_value, ref tempVar2) != GlobalVar.goUtility.SRight(activation_code, 1))
				{
					return return_value;
				}

				if (GlobalVar.goUtility.SMid(activation_code, 2, 3) == EncodeProductKey(product_key, FindRandomNumber(activation_code)))
				{
					return_value = true;
				}

				return return_value;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(ValidateActivationCode)");
				return return_value;

			}

		}

		// PURPOSE:  To encode the 6 key digists in product key into 3 digits.
		//           It returns 3 digits
		//
		private string EncodeProductKey(string product_key, int random_num)
		{

			string return_value = null;
			int key_num = 0;
			string valid_key = null;

			valid_key = "";

			key_num = GetAsciiValue(product_key, 1) + GetAsciiValue(product_key, 11) + random_num;
			valid_key = valid_key + (char)((key_num % 36) + Convert.ToInt32(GlobalVar.goUtility.IIf((key_num % 36) <= 9, (int)('0'), (int)('A') - 10)));

			key_num = GetAsciiValue(product_key, 3) + GetAsciiValue(product_key, 9) + random_num;
            valid_key = valid_key + (char)((key_num % 36) + Convert.ToInt32(GlobalVar.goUtility.IIf((key_num % 36) <= 9, (int)('0'), (int)('A') - 10)));

			key_num = GetAsciiValue(product_key, 5) + GetAsciiValue(product_key, 7) + random_num;
            valid_key = valid_key + (char)((key_num % 36) + Convert.ToInt32(GlobalVar.goUtility.IIf((key_num % 36) <= 9, (int)('0'), (int)('A') - 10)));

			return_value = valid_key;

			return return_value;

		}

		public bool ValidateProductKey(string product_key)
		{

			bool return_value = false;
			string odd_key = null;
			int key_num = 0;
			string even_key = null;

			try
			{

				// Do not delete this part unless the rule changes.
				// Currently, the code has two '-' at 5 and 10.
				//
				if (GlobalVar.goUtility.SMid(product_key, 5, 1) != "-")
				{
					return return_value;
				}
				else if (GlobalVar.goUtility.SMid(product_key, 10, 1) != "-")
				{
					return return_value;
				}

				product_key = GlobalVar.goUtility.SReplace(product_key, "-", "");

				if (GlobalVar.goUtility.SInStr(product_key, " ") > 0)
				{
					return return_value;
				}
				else if (GlobalVar.goUtility.SLength(GlobalVar.goUtility.STrim(product_key)) < (PRODUCT_KEY_LENGTH - 2))
				{
					return return_value;
				}

				// Odd chars are the key.
				//
				odd_key = GlobalVar.goUtility.SMid(product_key, 1, 1) + GlobalVar.goUtility.SMid(product_key, 3, 1) + GlobalVar.goUtility.SMid(product_key, 5, 1) + GlobalVar.goUtility.SMid(product_key, 7, 1) + GlobalVar.goUtility.SMid(product_key, 9, 1) + GlobalVar.goUtility.SMid(product_key, 11, 1);

				// Even chars are the sequential number.
				//
				even_key = GlobalVar.goUtility.SMid(product_key, 2, 1) + GlobalVar.goUtility.SMid(product_key, 4, 1) + GlobalVar.goUtility.SMid(product_key, 6, 1) + GlobalVar.goUtility.SMid(product_key, 8, 1) + GlobalVar.goUtility.SMid(product_key, 10, 1) + GlobalVar.goUtility.SMid(product_key, 12, 1);

				if (GetMatchingCode(even_key) == odd_key)
				{
					return_value = true;
				}

				return return_value;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(ValidateProductKey)");
				return return_value;

			}

		}

		public bool ValidateProductKeyForMS(string product_key)
		{

			bool return_value = false;
			if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "E-001" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "SBM-111" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "ELITE-111" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "PRO-111" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "ENT-111" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "SBM-111Q" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "ELITE-111Q" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "PRO-111Q" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "ENT-111Q")
			{
				return_value = true;
			}
			else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "D-111" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "D-121") // POS for restaurant Then
			{
				return_value = true;
			}
			else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-001" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-211" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-211S" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-211L" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-211P" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-211E" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-211SQ" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-211LQ" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-211PQ" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-211EQ") // POS Then
			{
				return_value = true;
			}
			else
			{
				return_value = false;
			}

			return return_value;
		}

		public bool CompatibleProducts(string product_key, string new_key)
		{

			bool return_value = false;
			int first_group = 0;
			int second_group = 0;

			if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "E-001")
			{
				first_group = 1;
			}
			else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "SBM-111" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "SBM-111Q" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-211S" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-211SQ")
			{
				first_group = 2;
			}
			else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "ELITE-111" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "ELITE-111Q" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-211L" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-211LQ")
			{
				first_group = 3;
			}
			else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "PRO-111" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "ENT-111" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "PRO-111Q" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "ENT-111Q" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-211P" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-211E" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-211PQ" || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "P-211EQ")
			{
				first_group = 4;
			}
			else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "D-111")
			{
				first_group = 5;
			}
			else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.STrim(product_key)) == "D-121")
			{
				first_group = 6;
			}
			else
			{
				first_group = 0;
			}

			if (GlobalVar.goUtility.SUCase(new_key) == "E-001")
			{
				second_group = 1;
			}
			else if (GlobalVar.goUtility.SUCase(new_key) == "SBM-111" || GlobalVar.goUtility.SUCase(new_key) == "SBM-111Q" || GlobalVar.goUtility.SUCase(new_key) == "P-211S" || GlobalVar.goUtility.SUCase(new_key) == "P-211SQ")
			{
				second_group = 2;
			}
			else if (GlobalVar.goUtility.SUCase(new_key) == "ELITE-111" || GlobalVar.goUtility.SUCase(new_key) == "ELITE-111Q" || GlobalVar.goUtility.SUCase(new_key) == "P-211L" || GlobalVar.goUtility.SUCase(new_key) == "P-211LQ")
			{
				second_group = 3;
			}
			else if (GlobalVar.goUtility.SUCase(new_key) == "PRO-111" || GlobalVar.goUtility.SUCase(new_key) == "ENT-111" || GlobalVar.goUtility.SUCase(new_key) == "PRO-111Q" || GlobalVar.goUtility.SUCase(new_key) == "ENT-111Q" || GlobalVar.goUtility.SUCase(new_key) == "P-211P" || GlobalVar.goUtility.SUCase(new_key) == "P-211E" || GlobalVar.goUtility.SUCase(new_key) == "P-211PQ" || GlobalVar.goUtility.SUCase(new_key) == "P-211EQ")
			{
				second_group = 4;
			}
			else if (GlobalVar.goUtility.SUCase(new_key) == "D-111")
			{
				second_group = 5;
			}
			else if (GlobalVar.goUtility.SUCase(new_key) == "D-121")
			{
				second_group = 6;
			}
			else
			{
				second_group = 0;
			}

			if (first_group == 0 || second_group == 0)
			{
				return return_value;
			}

			return_value = (first_group == second_group);

			return return_value;
		}

		public string CreateRenewalCode(string product_code)
		{

			string return_value = null;
			string renewal_code = null;
			string even_str = null;
			string odd_str = null;
			string date_str = null;
			int i = 0;

			try
			{

				if (GlobalVar.goUtility.IsEmpty(product_code))
				{
					return_value = "";
					return return_value;
				}

				renewal_code = oGeneral.CurrentDate().ToString() + product_code;
				renewal_code = GlobalVar.goUtility.PasswordEncode(renewal_code);

				for (i = 1; i <= GlobalVar.goUtility.SLength(renewal_code); i++)
				{
					if ((i % 2) == 1)
					{
						odd_str += GlobalVar.goUtility.SMid(renewal_code, i, 1);
					}
					else
					{
						even_str += GlobalVar.goUtility.SMid(renewal_code, i, 1);
					}
				}
				return_value = odd_str + even_str;

			}
			catch (Exception ex)
			{

			}

			return return_value;

		}

		public bool ValidateRenewalCode(string product_code, string renewal_code)
		{

			bool return_value = false;
			string even_str = null;
			string odd_str = null;
			string date_str = null;
			string new_code = null;
			int i = 0;

			even_str = "";
			odd_str = "";

			if (GlobalVar.goUtility.SLength(renewal_code) <= 8) // goUtility.SLength(product_code) + 8
			{
				return false;
			}

            odd_str = GlobalVar.goUtility.SLeft(renewal_code, (int)(Math.Round(GlobalVar.goUtility.SLength(renewal_code) / 2.0)));
			even_str = GlobalVar.goUtility.SRight(renewal_code, GlobalVar.goUtility.SLength(renewal_code) - GlobalVar.goUtility.SLength(odd_str));

			new_code = "";
			for (i = 1; i <= GlobalVar.goUtility.SLength(odd_str); i++)
			{
				new_code += GlobalVar.goUtility.SMid(odd_str, i, 1) + GlobalVar.goUtility.IIf(GlobalVar.goUtility.SLength(even_str) >= i, GlobalVar.goUtility.SMid(even_str, i, 1), "").ToString();
			}

			new_code = GlobalVar.goUtility.PasswordDecode(new_code);
			date_str = GlobalVar.goUtility.SLeft(new_code, 8);

			if ((GlobalVar.goUtility.SRight(new_code, GlobalVar.goUtility.SLength(product_code)) != product_code) && !CompatibleProducts(GlobalVar.goUtility.SRight(new_code, GlobalVar.goUtility.SLength(product_code)), product_code))
			{
				return return_value;
			}
			else if (GlobalVar.goUtility.ToValue(date_str).ToString() != date_str) // Has to be numeric for date
			{
				return return_value;
			}
			else if (GlobalVar.goUtility.ToValue(GlobalVar.goUtility.SLeft(date_str, 4)) < (((Convert.ToInt32(oGeneral.CurrentDate()) / 10000)) - 1) || GlobalVar.goUtility.ToValue(GlobalVar.goUtility.SLeft(date_str, 4)) > (((Convert.ToInt32(oGeneral.CurrentDate()) / 10000) + 1)))
			{
				return return_value;
			}

			return_value = (Math.Abs(oGeneral.DateDifference(oGeneral.ToStrDate(oGeneral.CurrentDate()), oGeneral.ToStrDate(GlobalVar.goUtility.ToInteger(date_str)))) <= 31);

			return return_value;
		}

		private string GetMatchingCode(string product_key)
		{

			string return_value = null;
			string valid_key = null;
			int key_num = 0;

			try
			{

				if (GlobalVar.goUtility.SLength(product_key) < 6)
				{
					return_value = "";
					return return_value;
				}

				valid_key = "";

				// 2 th
				//
				key_num = GetAsciiValue(product_key, 1) * GetAsciiValue(product_key, 5) * GetAsciiValue(product_key, 6) / 3 + 101;

				valid_key = valid_key + (char)((key_num % 36) + Convert.ToInt32(GlobalVar.goUtility.IIf((key_num % 36) <= 9, (int)('0'), (int)('A') - 10)));

				// 4 th
				//
				key_num = GetAsciiValue(product_key, 2) * GetAsciiValue(product_key, 5) * GetAsciiValue(product_key, 6) / 3 + 12;

				valid_key = valid_key + (char)((key_num % 36) + Convert.ToInt32(GlobalVar.goUtility.IIf((key_num % 36) <= 9, (int)('0'), (int)('A') - 10)));

				// 6 th
				//
				key_num = GetAsciiValue(product_key, 3) * GetAsciiValue(product_key, 5) * GetAsciiValue(product_key, 6) / 3 + 53;

				valid_key = valid_key + (char)((key_num % 36) + Convert.ToInt32(GlobalVar.goUtility.IIf((key_num % 36) <= 9, (int)('0'), (int)('A') - 10)));

				// 8 th
				//
				key_num = GetAsciiValue(product_key, 5) * GetAsciiValue(product_key, 6) * GetAsciiValue(product_key, 6) / 3 + 14;

				valid_key = valid_key + (char)((key_num % 36) + Convert.ToInt32(GlobalVar.goUtility.IIf((key_num % 36) <= 9, (int)('0'), (int)('A') - 10)));

				// 10 th
				//
				key_num = GetAsciiValue(product_key, 5) * GetAsciiValue(product_key, 6) * GetAsciiValue(product_key, 3) / 3 + 127;

				valid_key = valid_key + (char)((key_num % 36) + Convert.ToInt32(GlobalVar.goUtility.IIf((key_num % 36) <= 9, (int)('0'), (int)('A') - 10)));

				// 12 th
				//
				key_num = GetAsciiValue(product_key, 4) * GetAsciiValue(product_key, 5) * GetAsciiValue(product_key, 6) / 3 + 16;

				valid_key = valid_key + (char)((key_num % 36) + Convert.ToInt32(GlobalVar.goUtility.IIf((key_num % 36) <= 9, (int)('0'), (int)('A') - 10)));

				return_value = valid_key;
				return return_value;

			}
			catch (Exception ex)
			{

				return_value = "";
				return return_value;

			}

		}

		private int GetAsciiValue(string product_key, int char_num)
		{
			bool tempVar = false;
			return GetAsciiValue(product_key, char_num, ref tempVar);
		}

		private int GetAsciiValue(string product_key, int char_num, ref bool start_from_a)
		{

			int return_value = 0;
			// Numbering system starts from "A" so athat A, B, ... Z, 0, 1, ... , 9
			// GetAsciiValue of A = 0
			//
			if (start_from_a)
			{

				if (GlobalVar.goUtility.SMid(product_key, char_num, 1).CompareTo("A") >= 0 && GlobalVar.goUtility.SMid(product_key, char_num, 1).CompareTo("Z") <= 0)
				{
                    return_value = (int)char.Parse(GlobalVar.goUtility.SMid(product_key, char_num, 1)) - (int)('A');
				}
				else
				{
					return_value = GlobalVar.goUtility.ToInteger(GlobalVar.goUtility.SMid(product_key, char_num, 1)) + 26;
				}

				// Numbering system starts from "0" so athat 0, 1, ... 9, A, B, ... , Z
				// GetAsciiValue of 0 = 0
				//
			}
			else
			{
				if (GlobalVar.goUtility.SMid(product_key, char_num, 1).CompareTo("A") >= 0 && GlobalVar.goUtility.SMid(product_key, char_num, 1).CompareTo("Z") <= 0)
				{
					return_value = ((int)char.Parse(GlobalVar.goUtility.SMid(product_key, char_num, 1)) - (int)('A') + 10);
				}
				else
				{
					return_value = GlobalVar.goUtility.ToInteger(GlobalVar.goUtility.SMid(product_key, char_num, 1));
				}
			}

			return return_value;
		}

		private string GetCharValue(int ascii_value)
		{
			bool tempVar = false;
			return GetCharValue(ascii_value, ref tempVar);
		}

		private string GetCharValue(int ascii_value, ref bool start_from_a)
		{

			string return_value = null;
			// Numbering system starts from "A" so that A, B, ... Z, 0, 1, ... , 9
			// GetAsciiValue of A = 0
			//
			if (start_from_a)
			{

				ascii_value = ascii_value % 36;

				if (ascii_value >= 0 && ascii_value <= 25)
				{
					return_value = ((char)((int)('A') + ascii_value)).ToString();
				}
				else
				{
					return_value = ((char)((int)('0') + ascii_value - 26)).ToString();
				}

				// Numbering system starts from "0" so that 0, 1, ... 9, A, B, ... , Z
				// GetAsciiValue of 0 = 0
				//
			}
			else
			{
				if (ascii_value >= 0 && ascii_value <= 9)
				{
					return_value = ((char)((int)('0') + ascii_value)).ToString();
				}
				else
				{
					return_value = ((char)((int)('A') + ascii_value - 10)).ToString();
				}
			}

			return return_value;
		}

		public bool CreateAlphabeticSerialNumber(string start_from, int total_numbers, string skipping_num, ref string[] serial_numbers, string separator, int sep_position)
		{

			bool return_value = false;
			int i = 0;
			string next_num = null;
			string formatted_num = null;
			int j = 0;
			bool dynasty_fl = false;

			try
			{

				start_from = GlobalVar.goUtility.SReplace(start_from, "-", "");
				skipping_num = GlobalVar.goUtility.SReplace(skipping_num, "-", "");

				i = 0;
				next_num = start_from;

				while ((total_numbers + GlobalVar.goConstant.INDEX_BASE - 1) >= i)
				{

					serial_numbers[i] = next_num;

					if (!GlobalVar.goUtility.IsEmpty(separator) && sep_position > 0)
					{
						formatted_num = "";
						j = 0;
						while (j <= ((GlobalVar.goUtility.SLength(serial_numbers[i]) / (sep_position - 1))))
						{
							formatted_num = formatted_num + GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsEmpty(formatted_num), "", separator).ToString() + GlobalVar.goUtility.SMid(serial_numbers[i], (sep_position - 1) * j + 1, sep_position - 1);
							j = j + 1;
						}
						serial_numbers[i] = GlobalVar.goUtility.IIf(GlobalVar.goUtility.SRight(formatted_num, GlobalVar.goUtility.SLength(separator)) == separator, GlobalVar.goUtility.SLeft(formatted_num, GlobalVar.goUtility.SLength(formatted_num) - GlobalVar.goUtility.SLength(separator)), formatted_num).ToString();
					}

					next_num = GetNextAlphabeticNumber(next_num, skipping_num);
					i = i + 1;

				}

				return true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(CreateAlphabeticSerialNumber)");
				return return_value;

			}

		}

		public bool CreateAlphaNumericSerialNumber(string start_from, int total_numbers, string skipping_num, ref string[] serial_numbers, string separator, int sep_position)
		{

			bool return_value = false;
			int i = 0;
			string next_num = null;
			string formatted_num = null;
			int j = 0;
			bool dynasty_fl = false;
			string odd_chars = null;

			try
			{

				if (separator == "JaY")
				{
					start_from = GlobalVar.goUtility.SLeft(start_from, 6);
					skipping_num = "100";
					separator = "-";
					dynasty_fl = true;
				}
				else
				{
					dynasty_fl = false;
				}

				i = 0;
				next_num = start_from;

				while ((total_numbers + GlobalVar.goConstant.INDEX_BASE - 1) >= i)
				{

					if (dynasty_fl)
					{
						odd_chars = GetMatchingCode(next_num);
						serial_numbers[i] = GlobalVar.goUtility.SMid(odd_chars, 1, 1) + GlobalVar.goUtility.SMid(next_num, 1, 1) + GlobalVar.goUtility.SMid(odd_chars, 2, 1) + GlobalVar.goUtility.SMid(next_num, 2, 1) + GlobalVar.goUtility.SMid(odd_chars, 3, 1) + GlobalVar.goUtility.SMid(next_num, 3, 1) + GlobalVar.goUtility.SMid(odd_chars, 4, 1) + GlobalVar.goUtility.SMid(next_num, 4, 1) + GlobalVar.goUtility.SMid(odd_chars, 5, 1) + GlobalVar.goUtility.SMid(next_num, 5, 1) + GlobalVar.goUtility.SMid(odd_chars, 6, 1) + GlobalVar.goUtility.SMid(next_num, 6, 1);
					}
					else
					{
						serial_numbers[i] = next_num;
					}

					if (!GlobalVar.goUtility.IsEmpty(separator) && sep_position > 0)
					{
						formatted_num = "";
						j = 0;
						while (j <= ((GlobalVar.goUtility.SLength(serial_numbers[i]) / (sep_position - 1))))
						{
							formatted_num = formatted_num + GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsEmpty(formatted_num), "", separator).ToString() + GlobalVar.goUtility.SMid(serial_numbers[i], (sep_position - 1) * j + 1, sep_position - 1);
							j = j + 1;
						}
						serial_numbers[i] = GlobalVar.goUtility.IIf(GlobalVar.goUtility.SRight(formatted_num, GlobalVar.goUtility.SLength(separator)) == separator, GlobalVar.goUtility.SLeft(formatted_num, GlobalVar.goUtility.SLength(formatted_num) - GlobalVar.goUtility.SLength(separator)), formatted_num).ToString();
					}

					next_num = GetNextAlphaNumericNumber(next_num, skipping_num);
					i = i + 1;

				}

				return true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(CreateAlphaNumericSerialNumber)");
				return return_value;

			}

		}

		public bool CreateNumericSerialNumber(string start_from, int total_numbers, string skipping_num, ref string[] serial_numbers, string separator, int sep_position)
		{

			bool return_value = false;
			int i = 0;
			string next_num = null;
			string formatted_num = null;
			int j = 0;
			bool dynasty_fl = false;

			try
			{

				if (skipping_num == "-JAY")
				{
					start_from = GlobalVar.goUtility.SLeft(start_from, 10);
					skipping_num = "100";
					dynasty_fl = true;
				}
				else
				{
					dynasty_fl = false;
				}

				start_from = GlobalVar.goUtility.SReplace(start_from, "-", "");
				skipping_num = GlobalVar.goUtility.SReplace(skipping_num, "-", "");

				i = 0;
				next_num = start_from;

				while ((total_numbers - 1) >= i)
				{

					if (dynasty_fl)
					{
						serial_numbers[i] = next_num + GetMatchingCode(next_num);
					}
					else
					{
						serial_numbers[i] = next_num;
					}

					if (!GlobalVar.goUtility.IsEmpty(separator) && sep_position > 0)
					{
						formatted_num = "";
						j = 0;
						while (j <= ((GlobalVar.goUtility.SLength(serial_numbers[i]) / (sep_position - 1))))
						{
							formatted_num = formatted_num + GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsEmpty(formatted_num), "", separator).ToString() + GlobalVar.goUtility.SMid(serial_numbers[i], (sep_position - 1) * j + 1, sep_position - 1);
							j = j + 1;
						}
						serial_numbers[i] = GlobalVar.goUtility.IIf(GlobalVar.goUtility.SRight(formatted_num, GlobalVar.goUtility.SLength(separator)) == separator, GlobalVar.goUtility.SLeft(formatted_num, GlobalVar.goUtility.SLength(formatted_num) - GlobalVar.goUtility.SLength(separator)), formatted_num).ToString();
					}

					next_num = GetNextNumericNumber(next_num, skipping_num);
					i = i + 1;

				}

				return true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(CreateNumericSerialNumber)");
				return return_value;

			}

		}

		private string GetNextAlphabeticNumber(string cur_number, string skipping_number)
		{

			string return_value = null;
			int max_len = 0;
			int carrier = 0;
			string new_number = null;
			int new_decimal_value = 0;

			try
			{

				if (GlobalVar.goUtility.IsEmpty(skipping_number) || skipping_number == "0")
				{
					IncreaseAlphabeticString(ref cur_number);
					return_value = cur_number;
					return return_value;
				}

				IncreaseNumericString(ref skipping_number);
				ConvertToAlphabeticString(ref skipping_number);

				if (GlobalVar.goUtility.SLength(cur_number) > GlobalVar.goUtility.SLength(skipping_number))
				{
					max_len = GlobalVar.goUtility.SLength(cur_number) + 1;
				}
				else
				{
					max_len = GlobalVar.goUtility.SLength(skipping_number) + 1;
				}

				skipping_number = GlobalVar.goUtility.SRight(GlobalVar.goUtility.Space(40) + skipping_number, max_len);
				cur_number = GlobalVar.goUtility.SRight(GlobalVar.goUtility.Space(40) + cur_number, max_len);

				carrier = 0;
				new_number = "";

				while (max_len > 0)
				{

					if (GlobalVar.goUtility.SMid(cur_number, max_len, 1) == " " && GlobalVar.goUtility.SMid(skipping_number, max_len, 1) == " ")
					{
						if (carrier > 0)
						{
							new_number = "A" + new_number;
						}
						break;
					}

					new_decimal_value = GetDecimalValue(GlobalVar.goUtility.SMid(cur_number, max_len, 1), false) + GetDecimalValue(GlobalVar.goUtility.SMid(skipping_number, max_len, 1), false) + carrier;

					if (new_decimal_value > 26)
					{
						carrier = 1;
						new_decimal_value = new_decimal_value - 26;
					}
					else
					{
						carrier = 0;
					}

                    new_number = GlobalVar.goUtility.STrim(((char)((int)('A') + new_decimal_value - 1)).ToString()) + new_number;

					max_len = max_len - 1;

				}

				return_value = new_number;
				return return_value;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(GetNextAlphabeticNumber)");
				return return_value;

			}

		}

		private string GetNextAlphaNumericNumber(string cur_number, string skipping_number)
		{

			string return_value = null;
			int max_len = 0;
			int carrier = 0;
			string new_number = null;
			int new_decimal_value = 0;

			try
			{

				if (GlobalVar.goUtility.IsEmpty(skipping_number) || skipping_number == "0")
				{
					IncreaseAlphaNumericString(ref cur_number);
					return_value = cur_number;
					return return_value;
				}

				IncreaseNumericString(ref skipping_number);
				ConvertToAlphaNumericString(ref skipping_number);

				if (GlobalVar.goUtility.SLength(cur_number) > GlobalVar.goUtility.SLength(skipping_number))
				{
					max_len = GlobalVar.goUtility.SLength(cur_number) + 1;
				}
				else
				{
					max_len = GlobalVar.goUtility.SLength(skipping_number) + 1;
				}

				cur_number = GlobalVar.goUtility.SRight(GlobalVar.goUtility.Space(40) + cur_number, max_len);
				skipping_number = GlobalVar.goUtility.SRight(GlobalVar.goUtility.Space(40) + skipping_number, max_len);

				carrier = 0;
				new_number = "";

				while (max_len > 0)
				{

					if (GlobalVar.goUtility.SMid(cur_number, max_len, 1) == " " && GlobalVar.goUtility.SMid(skipping_number, max_len, 1) == " ")
					{
						if (carrier > 0)
						{
							new_number = "1" + new_number;
						}
						break;
					}

					new_decimal_value = GetDecimalValue(GlobalVar.goUtility.SMid(cur_number, max_len, 1), true) + GetDecimalValue(GlobalVar.goUtility.SMid(skipping_number, max_len, 1), true) + carrier;

					if (new_decimal_value >= 36)
					{
						carrier = 1;
						new_decimal_value = new_decimal_value - 36;
					}
					else
					{
						carrier = 0;
					}

					if (new_decimal_value <= 9)
					{
						new_number = GlobalVar.goUtility.STrim(GlobalVar.goUtility.ToStr(new_decimal_value)) + new_number;
					}
					else
					{
						new_decimal_value = new_decimal_value - 10;
                        new_number = GlobalVar.goUtility.STrim(((char)((int)('A') + new_decimal_value)).ToString()) + new_number;
					}

					max_len = max_len - 1;

				}

				return_value = new_number;
				return return_value;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(GetNextAlphaNumericNumber)");
				return return_value;

			}

		}

		private string GetNextNumericNumber(string cur_number, string skipping_number)
		{

			string return_value = null;
			int max_len = 0;
			int carrier = 0;
			string new_number = null;
			int new_decimal_value = 0;

			try
			{

				if (GlobalVar.goUtility.IsEmpty(skipping_number) || skipping_number == "0")
				{
					IncreaseNumericString(ref cur_number);
					return_value = cur_number;
					return return_value;
				}

				IncreaseNumericString(ref skipping_number);

				if (GlobalVar.goUtility.SLength(cur_number) > GlobalVar.goUtility.SLength(skipping_number))
				{
					max_len = GlobalVar.goUtility.SLength(cur_number) + 1;
				}
				else
				{
					max_len = GlobalVar.goUtility.SLength(skipping_number) + 1;
				}

				skipping_number = GlobalVar.goUtility.SRight(GlobalVar.goUtility.Space(40) + skipping_number, max_len);
				cur_number = GlobalVar.goUtility.SRight(GlobalVar.goUtility.Space(40) + cur_number, max_len);

				carrier = 0;
				new_number = "";

				while (max_len > 0)
				{

					if (GlobalVar.goUtility.SMid(cur_number, max_len, 1) == " " && GlobalVar.goUtility.SMid(skipping_number, max_len, 1) == " ")
					{
						if (carrier > 0)
						{
							new_number = "1" + new_number;
						}
						break;
					}

					new_decimal_value = GlobalVar.goUtility.ToInteger(GlobalVar.goUtility.SMid(cur_number, max_len, 1)) + GlobalVar.goUtility.ToInteger(GlobalVar.goUtility.SMid(skipping_number, max_len, 1)) + carrier;

					if (new_decimal_value >= 10)
					{
						carrier = 1;
						new_decimal_value = new_decimal_value - 10;
					}
					else
					{
						carrier = 0;
					}

                    new_number = GlobalVar.goUtility.STrim(((char)((int)('0') + new_decimal_value)).ToString()) + new_number;

					max_len = max_len - 1;

				}

				return_value = new_number;
				return return_value;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(GetNextNumericNumber)");
				return return_value;

			}

		}

		private int GetDecimalValue(string cur_char, bool alphanumeric_fl)
		{

			int return_value = 0;
			if (cur_char == " ")
			{
				return_value = 0;
			}
			else if (cur_char.CompareTo("0") >= 0 && cur_char.CompareTo("9") <= 0)
			{
				return_value = GlobalVar.goUtility.ToInteger(cur_char);
			}
			else if (alphanumeric_fl)
			{
                return_value = (int)char.Parse(cur_char) - (int)('A') + 10;
			}
			else
			{
                return_value = (int)char.Parse(cur_char) - (int)('A') + 1;
			}

			return return_value;

		}

		private void IncreaseNumericString(ref string cur_str, int cur_pos = 1000)
		{

			int str_len = 0;

			try
			{

				// No more string, return
				//
				if (GlobalVar.goUtility.IsEmpty(GlobalVar.goUtility.STrim(cur_str)))
				{
					return;

					// If this is the first time call, start from the right char.
					//
				}
				else if (cur_pos == 1000)
				{
					cur_str = " " + cur_str;
					str_len = GlobalVar.goUtility.SLength(cur_str);
					cur_pos = str_len;

					// Otherwise, increase the given string.
					//
				}
				else
				{
					str_len = GlobalVar.goUtility.SLength(cur_str);
				}

				// If this is the very first char, and it is a blank,
				// Concatenate "1" and return.
				//
				if (cur_pos == 1 && GlobalVar.goUtility.SMid(cur_str, cur_pos, 1) == " ")
				{
					cur_str = "1" + GlobalVar.goUtility.SRight(cur_str, GlobalVar.goUtility.SLength(cur_str) - 1);
				}
				else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SMid(cur_str, cur_pos, 1)) == "9")
				{
					cur_str = GlobalVar.goUtility.SLeft(cur_str, cur_pos - 1) + "0" + GlobalVar.goUtility.SRight(cur_str, str_len - cur_pos);
					IncreaseNumericString(ref cur_str, cur_pos - 1);
				}
				else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SMid(cur_str, cur_pos, 1)).CompareTo("0") >= 0 && GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SMid(cur_str, cur_pos, 1)).CompareTo("9") < 0)
				{
                    cur_str = GlobalVar.goUtility.SLeft(cur_str, cur_pos - 1) + (char)((int)char.Parse(GlobalVar.goUtility.SMid(cur_str, cur_pos, 1)) + 1) + GlobalVar.goUtility.SRight(cur_str, str_len - cur_pos);
				}

				cur_str = GlobalVar.goUtility.STrim(cur_str);
				return;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(IncreaseNumericString)");
				return;

			}

		}

		private void IncreaseAlphaNumericString(ref string cur_str, int cur_pos = 1000)
		{

			int str_len = 0;

			try
			{

				if (GlobalVar.goUtility.IsEmpty(GlobalVar.goUtility.STrim(cur_str)))
				{
					return;
				}
				else if (cur_pos == 1000)
				{
					cur_str = " " + cur_str;
					str_len = GlobalVar.goUtility.SLength(cur_str);
					cur_pos = str_len;
				}
				else
				{
					str_len = GlobalVar.goUtility.SLength(cur_str);
				}

				// If this is the very first char, and it is a blank
				//
				if (cur_pos == 1 && GlobalVar.goUtility.SMid(cur_str, cur_pos, 1) == " ")
				{
					cur_str = "1" + GlobalVar.goUtility.SRight(cur_str, GlobalVar.goUtility.SLength(cur_str) - 1);
				}
				else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SMid(cur_str, cur_pos, 1)) == "Z")
				{
					cur_str = GlobalVar.goUtility.SLeft(cur_str, cur_pos - 1) + "0" + GlobalVar.goUtility.SRight(cur_str, str_len - cur_pos);
					IncreaseAlphaNumericString(ref cur_str, cur_pos - 1);
				}
				else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SMid(cur_str, cur_pos, 1)) == "9")
				{
					cur_str = GlobalVar.goUtility.SLeft(cur_str, cur_pos - 1) + "A" + GlobalVar.goUtility.SRight(cur_str, str_len - cur_pos);
				}
				else if ((GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SMid(cur_str, cur_pos, 1)).CompareTo("A") >= 0 && GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SMid(cur_str, cur_pos, 1)).CompareTo("Z") < 0) || (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SMid(cur_str, cur_pos, 1)).CompareTo("0") >= 0 && GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SMid(cur_str, cur_pos, 1)).CompareTo("0") < 0))
				{
                    cur_str = GlobalVar.goUtility.SLeft(cur_str, cur_pos - 1) + (char)((int)char.Parse(GlobalVar.goUtility.SMid(cur_str, cur_pos, 1)) + 1) + GlobalVar.goUtility.SRight(cur_str, str_len - cur_pos);
				}

				cur_str = GlobalVar.goUtility.STrim(cur_str);
				return;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(IncreaseAlphaNumericString)");
				return;

			}

		}

		private void IncreaseAlphabeticString(ref string cur_str, int cur_pos = 1000)
		{

			int str_len = 0;

			try
			{

				if (GlobalVar.goUtility.IsEmpty(GlobalVar.goUtility.STrim(cur_str)))
				{
					return;
				}
				else if (cur_pos == 1000)
				{
					cur_str = " " + cur_str;
					str_len = GlobalVar.goUtility.SLength(cur_str);
					cur_pos = str_len;
				}
				else
				{
					str_len = GlobalVar.goUtility.SLength(cur_str);
				}

				// If this is the very first char, and it is a blank
				//
				if (cur_pos == 1 && GlobalVar.goUtility.SMid(cur_str, cur_pos, 1) == " ")
				{
					cur_str = "A" + GlobalVar.goUtility.SRight(cur_str, GlobalVar.goUtility.SLength(cur_str) - 1);
				}
				else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SMid(cur_str, cur_pos, 1)) == "Z")
				{
					cur_str = GlobalVar.goUtility.SLeft(cur_str, cur_pos - 1) + "A" + GlobalVar.goUtility.SRight(cur_str, str_len - cur_pos);
					IncreaseAlphabeticString(ref cur_str, cur_pos - 1);
				}
				else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SMid(cur_str, cur_pos, 1)).CompareTo("A") >= 0 && GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SMid(cur_str, cur_pos, 1)).CompareTo("Z") < 0)
				{
                    cur_str = GlobalVar.goUtility.SLeft(cur_str, cur_pos - 1) + (char)((int)char.Parse(GlobalVar.goUtility.SMid(cur_str, cur_pos, 1)) + 1) + GlobalVar.goUtility.SRight(cur_str, str_len - cur_pos);
				}

				cur_str = GlobalVar.goUtility.STrim(cur_str);
				return;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(IncreaseAlphabeticString)");
				return;

			}

		}

		// cur_string should be number string no larger than "9999"
		//
		private void ConvertToAlphaNumericString(ref string cur_string)
		{

			int cur_val = 0;
			string new_string = null;

			try
			{

				cur_val = GlobalVar.goUtility.ToInteger(cur_string);
				new_string = "";

				while (cur_val > 0)
				{
					if ((cur_val % 36) <= Convert.ToDouble('0'))
					{
						new_string = GlobalVar.goUtility.STrim(GlobalVar.goUtility.ToStr(cur_val % 36)) + new_string;
					}
					else
					{
						new_string = (char)((cur_val % 36) - 9 + (int)('A') - 1) + new_string;
					}
					cur_val = cur_val / 36;
				}

				cur_string = new_string;
				return;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(ConvertToAlphaNumericString)");
				return;

			}

		}

		// cur_string should be number string no larger than "9999"
		//
		private void ConvertToAlphabeticString(ref string cur_string)
		{

			int cur_val = 0;
			string new_string = null;

			try
			{

				cur_val = GlobalVar.goUtility.ToInteger(cur_string);
				new_string = "";

				while (cur_val > 0)
				{
					new_string = (char)((cur_val % 26) + (int)('A') - 1) + new_string;
					cur_val = cur_val / 26;
				}

				cur_string = new_string;
				return;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(ConvertToAlphabeticString)");
				return;

			}

		}

		private int FindRandomNumber(string activation_code)
		{

			int return_value = 0;
			int rand_num = 0;

			var tempVar = true;
			var tempVar2 = true;
			rand_num = GetAsciiValue(activation_code, 5, ref tempVar) - GetAsciiValue(activation_code, 4, ref tempVar2);

			if (rand_num < 0)
			{
				rand_num = rand_num + 36;
			}

			return_value = rand_num;

			return return_value;
		}


		private string FindNextChar(string cur_char, int add_num, bool start_from_a = false)
		{

			string return_value = null;
			int cur_val = 0;
			string new_char = null;

			cur_val = GetAsciiValue(cur_char, 1, ref start_from_a);

			if (cur_val + add_num >= 0)
			{
				new_char = GetCharValue((cur_val + add_num) % 36, ref start_from_a);
			}
			else
			{
				new_char = GetCharValue(cur_val + add_num + 36, ref start_from_a);
			}

			return_value = new_char;

			return return_value;
		}

		// PURPOSE:  To extract the licensee name from the given activation code:
		//           Activation code =
		//           chr(asc('A') + goUtility.SLength(company name) + random_num)
		//           + 3 digits of encoded product_key
		//           + a randome char
		//           + the company name.
		//
		public string DecodeLicensee(string activation_code)
		{

			string return_value = null;
			string odd_str = null;
			string even_str = null;
			int rand_num = 0;
			int i = 0;
			string encoded_company = null;
			string first_char = null;
			int company_len = 0;
			int first_num = 0;
			int second_num = 0;
			string company_name = null;
			bool blank_char = false;

			// Generate a random number.
			//
			activation_code = GlobalVar.goUtility.SReplace(activation_code, "@", ",");
			activation_code = GlobalVar.goUtility.SReplace(activation_code, "%", " ");
			rand_num = FindRandomNumber(activation_code);

			// Create the first char of the activation code.
			// Rule: goUtility.SLength(company_name) <= 20
			//
			var tempVar = true;
			company_len = GetAsciiValue(activation_code, 1, ref tempVar) - rand_num;

			// The company name starts from the sixth char.
			//
			encoded_company = GlobalVar.goUtility.SMid(activation_code, 6, company_len);

			company_name = "";
			for (i = 1; i <= GlobalVar.goUtility.SLength(encoded_company); i++)
			{
				if ((GlobalVar.goUtility.SMid(encoded_company, i, 1).CompareTo("0") >= 0 && GlobalVar.goUtility.SMid(encoded_company, i, 1).CompareTo("9") <= 0) || (GlobalVar.goUtility.SMid(encoded_company, i, 1).CompareTo("A") >= 0 && GlobalVar.goUtility.SMid(encoded_company, i, 1).CompareTo("Z") <= 0))
				{
					company_name = company_name + FindNextChar(GlobalVar.goUtility.SMid(encoded_company, i, 1), -i, true);
				}
				else
				{
					company_name = company_name + GlobalVar.goUtility.SMid(encoded_company, i, 1);
				}
			}
			encoded_company = company_name;

			even_str = "";
			odd_str = "";
			for (i = 1; i <= GlobalVar.goUtility.SLength(encoded_company); i++)
			{
				if ((i % 2) == 1)
				{
					odd_str = odd_str + GlobalVar.goUtility.SMid(encoded_company, i, 1);
				}
				else
				{
					even_str = GlobalVar.goUtility.SMid(encoded_company, i, 1) + even_str;
				}
			}

			i = 1;
			company_name = "";
			while (GlobalVar.goUtility.SLength(odd_str) >= i || GlobalVar.goUtility.SLength(even_str) >= i)
			{
				company_name = company_name + GlobalVar.goUtility.SMid(odd_str, i, 1) + GlobalVar.goUtility.SMid(even_str, i, 1);
				i = i + 1;
			}

			company_name = GlobalVar.goUtility.SLCase(company_name);
			company_name = GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(company_name, 1)) + GlobalVar.goUtility.SRight(company_name, GlobalVar.goUtility.SLength(company_name) - 1);
			blank_char = false;
			i = 2;
			while (GlobalVar.goUtility.SLength(company_name) >= i)
			{
				if (blank_char)
				{
					company_name = GlobalVar.goUtility.SLeft(company_name, i - 1) + GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SMid(company_name, i, 1)) + GlobalVar.goUtility.SRight(company_name, GlobalVar.goUtility.SLength(company_name) - i);
					blank_char = false;
				}
				else if (GlobalVar.goUtility.SMid(company_name, i, 1) == " ")
				{
					blank_char = true;
				}
				i = i + 1;
			}

			return_value = company_name;

			return return_value;
		}
	}

}
