﻿//  Copyright (c) DynastySoft Corp, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Database;
using Dynasty.Local;
//using Dynasty.ASP.Pages.IV;
using Radzen;

namespace Dynasty.ASP
{
	internal static class modSetupUtility
	{

		// PURPOSE : To check if the entire system is set up ok to run.
		//
		private static int CheckDynasty_pass_thru = 0;

		public static bool CheckDynasty(ref clsDatabase cur_db, string calling_module = "")
		{

			bool return_value = false;
//			Static pass_thru As Integer

			if (CheckDynasty_pass_thru < 1)
			{
				modGeneralUtility.ShowStatus(cur_db.oLanguage.oMessage.CHECKING_GL_SETUP);
				if (!CheckGLSystem(ref cur_db, calling_module))
				{
					return return_value;
				}
				else if (!CheckSystemOptions(ref cur_db, calling_module))
				{
					return return_value;
				}
				CheckDynasty_pass_thru = 1;
			}

			modGeneralUtility.ShowStatus("");
			return_value = true;

			return return_value;
		}

		// PURPOSE:  To check the initial setup of G/L system.
		//
		public static bool CheckGLSystem(ref clsDatabase cur_db, string calling_module = "")
		{

			bool return_value = false;
			string sql_str = "";
			string default_earning_acct = "";
			clsRecordset cur_set = null;
			bool default_ca_created = false;

			try
			{

				cur_set = new clsRecordset(ref cur_db);

				// Check if period is set up, yet.
				//
				sql_str = modConstant.PERIOD_DYNASET + " WHERE iStatus_typ = " + GlobalVar.goConstant.STATUS_OPEN;
				if (!cur_set.CreateSnapshot(sql_str))
				{
					return return_value;
				}
				else if (cur_set.EOF())
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.PERIOD_IS_NOT_SET_UP);
					cur_set.Release();
					return return_value;
				}

				cur_set.Release();

				// Check if master table is set.
				//
				default_earning_acct = "";

				if (!cur_set.CreateSnapshot(modConstant.MASTER_DYNASET))
				{
					return return_value;
				}
				else if (cur_set.EOF())
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.MASTER_HAS_NO_RECORD);
					cur_set.Release();
					return return_value;
				}
				else
				{
					cur_set.MoveFirst();
					default_earning_acct = cur_set.sField("sDefaultEarningAcct_cd");
					if (GlobalVar.goUtility.IsEmpty(cur_db.sCurFiscalYear) && calling_module != cur_db.oLanguage.oString.STR_ADVISOR)
					{
						cur_set.Release();
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.MASTER_IS_NOT_SET_UP);
						return return_value;
					}
				}

				cur_set.Release();

				// Check if account is set up, yet.
				//
				sql_str = modConstant.ACCT_DYNASET + " WHERE iSummary_typ = " + GlobalVar.goGLConstant.ACTUAL_TYPE_NUM;
				if (!cur_set.CreateSnapshot(sql_str))
				{
					return return_value;
				}
				else if (cur_set.EOF())
				{
					cur_set.Release();
					if (calling_module == cur_db.oLanguage.oString.STR_ADVISOR)
					{
						if (!CreateDefaultChartOfAccounts(ref cur_db, calling_module))
						{
							return return_value;
						}
						else if (!ReadPostingAccountsFromTextFile(ref cur_db))
						{
							return return_value;
						}
					}
					else
					{
						modDialogUtility.DisplayBox(ref cur_db, "The chart of accounts is not set up, yet.");
						return return_value;
					}
					default_ca_created = true;
				}

				cur_set.Release();

				// Check if journal code table is set up, yet.
				//
				if (!cur_set.CreateSnapshot(modConstant.JOURNAL_CODE_DYNASET))
				{
					return return_value;
				}
				else if (cur_set.EOF())
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.JOUTABLE_IS_NOT_SETUP);
					cur_set.Release();
					return return_value;
				}

				cur_set.Release();

				// Check if the chart of accounts is set up properly.
				//
				if (!default_ca_created)
				{
					if (!ValidateChart(ref cur_db))
					{
						return return_value;
					}
				}

				// Set the default earning account if it is empty.
				//
				if (GlobalVar.goUtility.IsEmpty(cur_db.sDefCEAccount_cd) && GlobalVar.goUtility.IsEmpty(default_earning_acct))
				{
					if (!cur_set.CreateSnapshot(modConstant.ACCT_DYNASET_ACTUAL_ONLY + " AND iGroup_typ = " + GlobalVar.goGLConstant.CURRENT_EARNING_NUM))
					{
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.EARNING_DOES_NOT_EXIST);
						return return_value;
					}
					else
					{
						cur_db.sDefCEAccount_cd = cur_set.sField("sAccount_cd");
						sql_str = "UPDATE tblGOMaster SET";
						sql_str += " sDefaultEarningAcct_cd = '" + cur_db.sDefCEAccount_cd + "'";
						sql_str += ",sGLAcctCodeFormat = '" + cur_db.sGLAcctCodeFormat + "'";
						sql_str += ",iGLAcctCodeLength = " + cur_db.iGLAcctCodeLength;
						if (!cur_db.ExecuteSQL(sql_str))
						{
							return false;
						}
						cur_set.Release();
					}
				}

				if (calling_module != cur_db.oLanguage.oString.STR_ADVISOR)
				{
					if (GlobalVar.goUtility.IsEmpty(GlobalVar.goUtility.STrim(cur_db.sCurFiscalYear)))
					{
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.MASTER_IS_NOT_SET_UP);
						return return_value;
					}
					else if (cur_db.iCurPeriodBegin_dt == 0)
					{
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.MASTER_IS_NOT_SET_UP);
						return return_value;
					}
				}

				return_value = true;

				return return_value;

			}
			catch (Exception ex)
			{

				cur_set.Release();

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CheckGLSystem)");
				return false;

			}

		}

		// PURPOSE:  To create the default chart of account.
		//
		public static bool CreateDefaultChartOfAccounts(ref clsDatabase cur_db, string calling_module = "")
		{

			bool return_value = false;
			string text_line = "";
			string sql_str = "";
			int db_num = 0;
			clsRecordset glbal_set = null;
			clsRecordset peridet_set = null;
			string comp_name = "";
			int rec_num = 0;
			int tot_rec = 0;

			try
			{

				glbal_set = new clsRecordset(ref cur_db);
				peridet_set = new clsRecordset(ref cur_db);

				//  If cur_db.sCurFiscalYear is a blank, then it means the company is not
				// set up properly.
				//
				if (GlobalVar.goUtility.IsEmpty(cur_db.sCurFiscalYear) && calling_module != cur_db.oLanguage.oString.STR_ADVISOR)
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.SETUP_COMPANY_FIRST);
					return false;
				}

				comp_name = cur_db.sCompany_nm; // MainForm.lblCompany_nm.Text

				if (!ReadChartOfAccountsFromTextFile(ref cur_db))
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.CREATING_CHART_OF_ACCOUNTS_FAILED);
					return return_value;
				}

				modGeneralUtility.ShowStatus(cur_db.oLanguage.oMessage.VALIDATING_CHART_OF_ACCT);
				return_value = true;

				if (!ValidateChart(ref cur_db))
				{
					if (!cur_db.ExecuteSQL("DELETE FROM tblGLBalance"))
					{
						return_value = false;
					}
					else if (!cur_db.ExecuteSQL("DELETE FROM tblGLAccont"))
					{
						return_value = false;
					}
					else if (!cur_db.ExecuteSQL("DELETE FROM tblGLAccontNatural"))
					{
						return_value = false;
					}
				}

				modGeneralUtility.ShowStatus("");
				return return_value;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CreateDefaultChartOfAccounts)");
                modSetupUtility.SetCompanyName(cur_db);
				return return_value;

			}

		}

		// PURPOSE : To read the text file which contains the default chart of accounts.
		//
		public static bool ReadChartOfAccountsFromTextFile(ref clsDatabase cur_db, string calling_module = "")
		{

			bool return_value = false;
			string text_line = "";
			string sql_str = "";
			int db_num = 0;
			string comp_name = "";
			clsRecordset period_set = null;
			clsRecordset cur_set = null;
			int rec_num = 0;
			int tot_rec = 0;
			string earning_acct = "";
			clsFileIO io_stream = new clsFileIO();
			int cashflow_id = 0;
			bool csv_file_fl = false;
			string acct_code = "";
			string parent_acct = "";
			string acct_desc = "";
			int summary_type = 0;
			int group_type = 0;
			int acct_level = 0;
			clsGLAccount o_glacct = null;

			try
			{

				period_set = new clsRecordset(ref cur_db);
				cur_set = new clsRecordset(ref cur_db);
				o_glacct = new clsGLAccount(ref cur_db);

				if (GlobalVar.goUtility.IsEmpty(cur_db.sCurFiscalYear))
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.FISCAL_YEAR_IS_INVALID);
					return return_value;
				}
				modGeneralUtility.RunEvents();
				if (!cur_db.ExecuteSQL("DELETE FROM tblGLBalance"))
				{
					return return_value;
				}
				modGeneralUtility.RunEvents();
				if (!cur_db.ExecuteSQL("DELETE FROM tblGLAccount"))
				{
					return return_value;
				}
				modGeneralUtility.RunEvents();
				if (!cur_db.ExecuteSQL("DELETE FROM tblGLAccountNatural"))
				{
					return return_value;
				}
				modGeneralUtility.RunEvents();
				if (!cur_db.ExecuteSQL("DELETE FROM tblGLSegmentedAccount"))
				{
					return return_value;
				}
				modGeneralUtility.RunEvents();
				if (!cur_db.ExecuteSQL("UPDATE tblGLSegment SET iApplied_fl = 0")) // Let it be
				{
					return return_value;
				}
				modGeneralUtility.RunEvents();
				if (!cur_db.ExecuteSQL("UPDATE tblGLSegmentType SET iApplied_fl = 0"))
				{
					return return_value;
				}
				modGeneralUtility.RunEvents();
				if (!cur_db.ExecuteSQL("UPDATE tblGOMaster SET sGLAcctCodeFiller = '', sGLAcctCodeSeparator = ''"))
				{
					return return_value;
				}
				modGeneralUtility.RunEvents();

				if (GlobalVar.goFile.FileExists(cur_db.uDirectory.sHomeDirectory_nm + "\\" + GlobalVar.goConstant.GOCHART_FILE))
				{
					if (!io_stream.OpenFileToRead(cur_db.uDirectory.sHomeDirectory_nm + "\\" + GlobalVar.goConstant.GOCHART_FILE))
					{
						return return_value;
					}
					csv_file_fl = false;
				}
				else if (GlobalVar.goFile.FileExists(cur_db.uDirectory.sHomeDirectory_nm + "\\" + GlobalVar.goUtility.SReplace(GlobalVar.goConstant.GOCHART_FILE, ".TXT", ".csv")))
				{
					if (!io_stream.OpenFileToRead(cur_db.uDirectory.sHomeDirectory_nm + "\\" + GlobalVar.goUtility.SReplace(GlobalVar.goConstant.GOCHART_FILE, ".TXT", ".csv")))
					{
						return return_value;
					}
					csv_file_fl = true;
				}
				else if (GlobalVar.goFile.FileExists(cur_db.uDirectory.sHomeDirectory_nm + "\\" + GlobalVar.goConstant.NPCHART_FILE))
				{
					if (!io_stream.OpenFileToRead(cur_db.uDirectory.sHomeDirectory_nm + "\\" + GlobalVar.goConstant.NPCHART_FILE))
					{
						return return_value;
					}
					csv_file_fl = false;
				}
				else if (GlobalVar.goFile.FileExists(cur_db.uDirectory.sHomeDirectory_nm + "\\" + GlobalVar.goUtility.SReplace(GlobalVar.goConstant.NPCHART_FILE, ".TXT", ".csv")))
				{
					if (!io_stream.OpenFileToRead(cur_db.uDirectory.sHomeDirectory_nm + "\\" + GlobalVar.goUtility.SReplace(GlobalVar.goConstant.NPCHART_FILE, ".TXT", ".csv")))
					{
						return return_value;
					}
					csv_file_fl = true;
				}
				else
				{
					modDialogUtility.DisplayBox(ref cur_db, GlobalVar.goConstant.GOCHART_FILE + cur_db.oLanguage.oMessage.IS_MISSING);
					return return_value;
				}

				rec_num = 0;

				if (!period_set.CreateSnapshot(modConstant.PERIODDET_DYNASET + " WHERE sFiscalYear = '" + cur_db.sCurFiscalYear + "'"))
				{
					return return_value;
				}

				if (period_set.IsEmpty())
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.PERIOD_IS_NOT_SET_UP);
					return return_value;
				}

				// The first line has the total number of records.
				//
				text_line = io_stream.ReadOneLine();

				tot_rec = GlobalVar.goUtility.ToInteger(GlobalVar.goUtility.SLeft(text_line, 4));

				// The second line has the default account format.
				//
				text_line = "";
				text_line = io_stream.ReadOneLine();
				cur_db.sGLAcctCodeFormat = GlobalVar.goUtility.STrim(text_line);

				// The third line has the default earning account code.
				//
				text_line = "";
				text_line = io_stream.ReadOneLine();
				cur_db.sDefCEAccount_cd = GlobalVar.goUtility.STrim(text_line);

				// The fourth line has the length of account code.
				//
				text_line = "";
				text_line = io_stream.ReadOneLine();
				cur_db.iGLAcctCodeLength = GlobalVar.goUtility.ToInteger(text_line);
				o_glacct.sFund_cd = "";

				modGeneralUtility.WaitFor(1);

				while (!io_stream.EndOfFile())
				{

					text_line = io_stream.ReadOneLine();
					modGeneralUtility.RunEvents();

					if (GlobalVar.goUtility.IsNonEmpty(text_line))
					{

						if (tot_rec > 0)
						{
							modGeneralUtility.ShowStatus(cur_db.oLanguage.oMessage.CREATING_NUM + rec_num + "/" + tot_rec);
						}
						else
						{
							modGeneralUtility.ShowStatus(cur_db.oLanguage.oMessage.CREATING_NUM + rec_num);
						}

						if (csv_file_fl)
						{
							acct_code = GlobalVar.goUtility.GetValueInCSVTextLine(text_line, 1);
							acct_desc = GlobalVar.goUtility.GetValueInCSVTextLine(text_line, 2);
							acct_level = GlobalVar.goUtility.ToInteger(GlobalVar.goUtility.GetValueInCSVTextLine(text_line, 3));
							parent_acct = GlobalVar.goUtility.GetValueInCSVTextLine(text_line, 4);
							group_type = GlobalVar.goUtility.ToInteger(GlobalVar.goUtility.GetValueInCSVTextLine(text_line, 5));
							summary_type = GlobalVar.goUtility.ToInteger(GlobalVar.goUtility.GetValueInCSVTextLine(text_line, 6));
							cashflow_id = GlobalVar.goUtility.ToInteger(GlobalVar.goUtility.GetValueInCSVTextLine(text_line, 7));
						}
						else
						{
							acct_code = GlobalVar.goUtility.STrim(GlobalVar.goUtility.SLeft(text_line, 16));
							acct_desc = GlobalVar.goUtility.STrim(GlobalVar.goUtility.SMid(text_line, 17, 40));
							acct_level = GlobalVar.goUtility.ToInteger(GlobalVar.goUtility.SMid(text_line, 57, 1));
							parent_acct = GlobalVar.goUtility.STrim(GlobalVar.goUtility.SMid(text_line, 59, 16));
							group_type = GlobalVar.goUtility.ToInteger(GlobalVar.goUtility.SMid(text_line, 91, 4));
							summary_type = GlobalVar.goUtility.ToInteger(GlobalVar.goUtility.SMid(text_line, 96, 1));
							if (GlobalVar.goUtility.SLength(text_line) >= 100)
							{
								cashflow_id = GlobalVar.goUtility.ToInteger(GlobalVar.goUtility.SMid(text_line, 98, 3));
							}
							else
							{
								cashflow_id = 0;
							}
						}

						if (GlobalVar.goUtility.IsIsAcct(group_type) && summary_type == GlobalVar.goGLConstant.ACTUAL_TYPE_NUM)
						{
							earning_acct = cur_db.sDefCEAccount_cd;
						}
						else
						{
							earning_acct = "";
						}

						if (!o_glacct.CreateGLAccount(ref period_set, acct_code, acct_desc, acct_level, parent_acct, earning_acct, group_type, summary_type, cashflow_id, 0))
						{
							break;
						}

						modGeneralUtility.RunEvents();
						rec_num = rec_num + 1;
						if ((rec_num % 100) == 99) // To catch up database update
						{
							modGeneralUtility.WaitFor(1);
						}

					}

				}

				io_stream.CloseFile();
				modGeneralUtility.RunEvents();

				if (GlobalVar.goUtility.IsNonEmpty(cur_db.sDefCEAccount_cd))
				{
					modGeneralUtility.WaitFor(1); // Let it finish updating
					sql_str = "SELECT * FROM tblGLAccount WHERE sAccount_cd LIKE '" + cur_db.sDefCEAccount_cd + "%' AND iSummary_typ = " + GlobalVar.goGLConstant.ACTUAL_TYPE_NUM.ToString() + " ORDER BY sAccount_cd";
					if (cur_set.CreateSnapshot(sql_str))
					{
						sql_str = "UPDATE tblGOMaster SET ";
						if (!cur_set.EOF())
						{
							if (!cur_set.EOF())
							{
								sql_str += " sDefaultEarningAcct_cd = '" + cur_set.sField("sAccount_cd") + "'";
							}
							else
							{
								sql_str += " sDefaultEarningAcct_cd = ''";
							}
						}
						else
						{
							sql_str += " sDefaultEarningAcct_cd = ''";
						}
						sql_str += ",sGLAcctCodeFormat = '" + cur_db.sGLAcctCodeFormat + "'";
						sql_str += ",iGLAcctCodeLength = " + cur_db.iGLAcctCodeLength;
						if (!cur_db.ExecuteSQL(sql_str))
						{
							return return_value;
						}
					}
				}

				if (!o_glacct.RearrangeGLAccountsAllTables())
				{
					return return_value;
				}

				modGeneralUtility.RunEvents();
				modGeneralUtility.ShowStatus(cur_db.oLanguage.oMessage.CREATING_NUM + rec_num + "  " + cur_db.oLanguage.oString.STR_DONE);
				return true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ReadChartOfAccountsFromTextFile)");
				io_stream.CloseFile();
				return return_value;

			}

		}

		//  PURPOSE:  To create the periods in GLBAL for all the accounts in glacct.
		//
		public static bool CreatePeriodsInGLBalance(ref clsDatabase cur_db, string fiscal_year)
		{

			bool return_value = false;
			clsRecordset period_set = null;
			clsRecordset acct_set = null;
			clsRecordset peridet_set = null;
			clsRecordset glbal_set = null;
			int res = 0;
			int total_rec = 0;
			int cur_rec = 0;
			bool was_in_trx = false;
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsGLAccount o_glacct = new clsGLAccount(ref cur_db);

			try
			{

				acct_set = new clsRecordset(ref cur_db);
				period_set = new clsRecordset(ref cur_db);
				peridet_set = new clsRecordset(ref cur_db);
				glbal_set = new clsRecordset(ref cur_db);

				// Create the GLACCT snapshot.
				//
				if (!acct_set.CreateSnapshot(modConstant.ACCT_DYNASET))
				{
					return false;
				}
				else if (acct_set.EOF())
				{
					return true;
				}

				if (!glbal_set.CreateSnapshot("SELECT DISTINCT sAccount_cd FROM tblGLBalance WHERE sFiscalYear = '" + fiscal_year + "'"))
				{
					return false;
				}
				else if (glbal_set.RecordCount() == acct_set.RecordCount())
				{
					return true;
				}

				total_rec = acct_set.RecordCount();
				acct_set.MoveFirst();

				// Create the GLPERIDET dynaset.
				//
				if (!peridet_set.CreateSnapshot(modConstant.PERIODDET_DYNASET + " WHERE sFiscalYear = '" + fiscal_year + "' ORDER BY iPeriodBegin_dt"))
				{
					return return_value;
				}
				else if (peridet_set.IsEmpty())
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oString.STR_GIVEN_YEAR + "(" + fiscal_year + ")" + cur_db.oLanguage.oMessage.IS_INVALID_IN_GLPERIOD);
					return return_value;
				}
				else
				{
					peridet_set.MoveFirst();
				}

				cur_rec = 1;

				// o_gen.CreateAcctInGLBalance to create an account with full periods in tblGLBalance.
				//
				while (!acct_set.EOF())
				{
					if (!o_glacct.CreateGLAccountInGLBalance(fiscal_year, acct_set.sField("sAccount_cd"), acct_set.iField("iAcctLevel"), acct_set.iField("iGroup_typ"), acct_set.mField("mBalance_amt")))
					{
						return return_value;
					}
					acct_set.MoveNext();
					peridet_set.MoveFirst();
					cur_rec = cur_rec + 1;
					modGeneralUtility.RunEvents();
				}

				acct_set.Release();
				period_set.Release();
				peridet_set.Release();

				was_in_trx = false;
				return true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CreatePeriodsInGLBalance)");

				acct_set.Release();
				period_set.Release();
				peridet_set.Release();
				glbal_set.Release();

				return false;

			}

		}

		// PURPOSE : To check if the chart of accounts is set up ok.
		//
		public static bool ValidateChart(ref clsDatabase cur_db)
		{

			bool return_value = false;
			clsRecordset cur_set = null;
			decimal tot_rec = 0M;
			int i = 0;
			clsGLAccount o_glacct = new clsGLAccount(ref cur_db);

			try
			{

				cur_set = new clsRecordset(ref cur_db);

				modGeneralUtility.ShowStatus(cur_db.oLanguage.oMessage.VALIDATING_CHART_OF_ACCT);
				modGeneralUtility.ShowUncountableProgress();

				if (!cur_db.ExecuteSQL("UPDATE tblGLAccount SET sEarningAcct_cd = '' WHERE iSummary_typ = " + GlobalVar.goGLConstant.SUMMARY_TYPE_NUM.ToString()))
				{
					return return_value;
				}
				else if (!cur_db.ExecuteSQL("UPDATE tblGLAccount SET iAcctLevel = 1 WHERE sParentAcct_cd = '' OR sParentAcct_cd IS NULL"))
				{
					return return_value;
				}

				if (!cur_set.CreateSnapshot("SELECT sAccount_cd FROM tblGLAccount WHERE sParentAcct_cd = '' OR iAcctLevel = 1 ORDER BY sAccount_cd"))
				{
					return return_value;
				}

				while (!cur_set.EOF())
				{

					if (!UpdateAccountLevel(ref cur_db, cur_set.sField("sAccount_cd"), 1))
					{
						return return_value;
					}

					cur_set.MoveNext();
					modGeneralUtility.ShowUncountableProgress();

				}

				if (!cur_set.CreateSnapshot("SELECT * FROM tblGLAccount ORDER BY sAccount_cd"))
				{
					return return_value;
				}

				while (!cur_set.EOF())
				{
					if (!o_glacct.ValidateAcct(cur_set.sField("sAccount_cd"), 0))
					{
						cur_set.Release();
						return return_value;
					}
					cur_set.MoveNext();
					modGeneralUtility.ShowUncountableProgress();
				}

				modGeneralUtility.ShowUncountableProgress(cur_db.oLanguage.oString.STR_DONE);
				cur_set.Release();
				return true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ValidateChart)");
				cur_set.Release();
				return return_value;

			}

		}

		// PURPOSE : To create the default posting accounts group for each module.
		//
		public static bool ReadPostingAccountsFromTextFile(ref clsDatabase cur_db, string calling_module = "")
		{

			bool return_value = false;
			if (!ReadIVAccounts(ref cur_db))
			{
				return return_value;
			}
			else if (!ReadARAccounts(ref cur_db))
			{
				return return_value;
			}
			else if (!ReadAPAccounts(ref cur_db))
			{
				return return_value;
			}
			else if (!ReadBRAccounts(ref cur_db, calling_module))
			{
				return return_value;
			}
			else if (!ReadPRAccounts(ref cur_db))
			{
				return return_value;
			}
			else if (!ReadGLAccounts(ref cur_db))
			{
				return return_value;
			}
            else if (!CreateDefaultCodes(ref cur_db))
            {
                return return_value;
            }

            return_value = true;

			return return_value;
		}

		// PURPOSE : TO create the default codes
		//
		public static bool CreateDefaultCodes(ref clsDatabase cur_db)
		{
			clsRecordset cur_set = null;
			string sql_str = "";

            try
			{
				// Create no-tax in A/R tax table
				//
                sql_str = "SELECT * FROM tblARTax WHERE sTax_cd = 'NOTAX'";

				cur_set = new clsRecordset(ref cur_db);

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return false;
                }
                else if (cur_set.IsEmpty())
                {
                    sql_str = "INSERT INTO tblARTax(";
					sql_str += "sTax_cd";
					sql_str += ",sDescription";
					sql_str += ",iTax_typ";
                    sql_str += ",fTotalTax_pc";
					sql_str += ",iDefault_fl";
					sql_str += ",dtLastUpdate_dt";
                    sql_str += ",sLastUpdate_id";
                    sql_str += ") VALUES (";
                    sql_str += "'NOTAX'";
                    sql_str += ",'No Tax'";
                    sql_str += ",1";
                    sql_str += ",0";
                    sql_str += ",0";
                    sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
                    sql_str += ",'" + cur_db.sUser_cd + "'";
                    sql_str += ")";

                    if (!cur_db.ExecuteSQL(sql_str))
                    {
                        return false;
                    }
                }

                // Create no-tax in A/P tax table
                //
                sql_str = "SELECT * FROM tblAPTax WHERE sTax_cd = 'NOTAX'";

                cur_set = new clsRecordset(ref cur_db);

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return false;
                }
                else if (cur_set.IsEmpty())
                {
                    sql_str = "INSERT INTO tblAPTax(";
                    sql_str += "sTax_cd";
                    sql_str += ",sDescription";
                    sql_str += ",iTax_typ";
                    sql_str += ",fTotalTax_pc";
                    sql_str += ",iDefault_fl";
                    sql_str += ",iFlexTax_fl";
                    sql_str += ",dtLastUpdate_dt";
                    sql_str += ",sLastUpdate_id";
                    sql_str += ") VALUES (";
                    sql_str += "'NOTAX'";
                    sql_str += ",'No Tax'";
                    sql_str += ",1";
                    sql_str += ",0";
                    sql_str += ",0";
                    sql_str += ",0";
                    sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
                    sql_str += ",'" + cur_db.sUser_cd + "'";
                    sql_str += ")";

                    if (!cur_db.ExecuteSQL(sql_str))
                    {
                        return false;
                    }
                }

                return true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CreateDefaultCodes)");
				return false;

			}
		}

        // PURPOSE : To create the default inventory posting accounts group.
        //
        public static bool ReadIVAccounts(ref clsDatabase cur_db)
		{

			bool return_value = false;
			int return_flag = 0;
			string acct_name = "";
			string acct_code = "";
			string cgs = "";
			string iv_in_stock = "";
			string iv_in_transit = "";
			string cgp = "";
			string iv_cash = "";
			string ar_cash = "";
			string physical = "";
			string spoilage = "";
			string variance = "";
			string domestic = "";
			string text_line = "";
			string sql_str = "";
			clsRecordset cur_set = null;
			string ar_return = "";
			string revenue = "";
			string sales_discount = "";
			string ap_return = "";
			clsFileIO io_stream = new clsFileIO();
			string service_revenue = "";
			string service_return = "";

			try
			{

				if (!io_stream.OpenFileToRead(cur_db.uDirectory.sHomeDirectory_nm + "\\default.txt"))
				{
					modDialogUtility.DisplayBox(ref cur_db, "default.txt" + cur_db.oLanguage.oMessage.IS_NOT_FOUND);
					return return_value;
				}

				cur_set = new clsRecordset(ref cur_db);

				while (!io_stream.EndOfFile())
				{

					text_line = "";
					acct_name = "";
					acct_code = "";

					text_line = io_stream.ReadOneLine();

					if (GlobalVar.goUtility.SInStr(text_line, "=") > 0)
					{
						acct_name = GlobalVar.goUtility.SLeft(text_line, GlobalVar.goUtility.SInStr(text_line, "=") - 1);
						acct_code = GlobalVar.goUtility.SRight(text_line, GlobalVar.goUtility.SLength(text_line) - GlobalVar.goUtility.SInStr(text_line, "="));
					}

					if (GlobalVar.goUtility.IsNonEmpty(acct_name) && GlobalVar.goUtility.IsNonEmpty(acct_code))
					{
						if (GlobalVar.goUtility.SUCase(acct_name) == "BR_CASH")
						{
							ar_cash = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AR_REVENUE")
						{
							revenue = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AR_SERVICE_REVENUE")
						{
							service_revenue = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AR_RETURN")
						{
							ar_return = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AR_SERVICE_RETURN")
						{
							service_return = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AR_SALEDISCOUNT")
						{
							sales_discount = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AP_RETURN")
						{
							ap_return = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "IV_CASH") // for POS Then
						{
							iv_cash = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "IV_INSTOCK")
						{
							iv_in_stock = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "IV_INTRANSIT")
						{
							iv_in_transit = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "IV_CGS")
						{
							cgs = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "IV_CGP")
						{
							cgp = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "IV_SPOILAGE")
						{
							spoilage = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "IV_PHYSICAL")
						{
							physical = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "IV_VARIANCE")
						{
							variance = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "IV_DOMESTIC")
						{
							domestic = acct_code;
						}
						else
						{

						}
					}

				}

				io_stream.CloseFile();

				if (GlobalVar.goUtility.IsEmpty(iv_cash))
				{
					iv_cash = ar_cash;
				}

				// Create a record in tblIVAccounts and tblIVClass
				//
				if (GlobalVar.goUtility.IsNonEmpty(iv_in_stock) && GlobalVar.goUtility.IsNonEmpty(iv_in_transit) && GlobalVar.goUtility.IsNonEmpty(cgs) && GlobalVar.goUtility.IsNonEmpty(cgp) && GlobalVar.goUtility.IsNonEmpty(spoilage) && GlobalVar.goUtility.IsNonEmpty(physical) && GlobalVar.goUtility.IsNonEmpty(variance) && GlobalVar.goUtility.IsNonEmpty(domestic))
				{

					sql_str = "SELECT * FROM tblIVAccounts WHERE sPosting_cd = '" + GlobalVar.goUtility.GetDefaultPostingCode() + "'";

					if (!cur_set.CreateSnapshot(sql_str))
					{
						return return_value;
					}
					else if (cur_set.IsEmpty())
					{

						cur_set.Release();

						sql_str = "INSERT INTO tblIVAccounts(";
						sql_str += "sPosting_cd";
						sql_str += ",sDescription";
						sql_str += ",sInventoryAcct_cd";
						sql_str += ",sTransferAcct_cd";
						sql_str += ",sCGSAcct_cd";
						sql_str += ",sCGPAcct_cd";
						sql_str += ",sSpoilageAcct_cd";
						sql_str += ",sAdjustAcct_cd";
						sql_str += ",sVarianceAcct_cd";
						sql_str += ",sInternalUseAcct_cd";
						sql_str += ",sSalesAcct_cd";
						sql_str += ",sSalesReturnAcct_cd";
						sql_str += ",sSalesDiscAcct_cd";
						sql_str += ",sPurchaseReturnAcct_cd";
						sql_str += ",sCashAcct_cd";
						sql_str += ",dtLastUpdate_dt";
						sql_str += ",sLastUpdate_id";
						sql_str += ") VALUES (";
						sql_str += "'" + GlobalVar.goUtility.GetDefaultPostingCode() + "'";
						sql_str += ",'Generic'";
						sql_str += ",'" + iv_in_stock + "'";
						sql_str += ",'" + iv_in_transit + "'";
						sql_str += ",'" + cgs + "'";
						sql_str += ",'" + cgp + "'";
						sql_str += ",'" + spoilage + "'";
						sql_str += ",'" + physical + "'";
						sql_str += ",'" + variance + "'";
						sql_str += ",'" + domestic + "'";
						sql_str += ",'" + revenue + "'";
						sql_str += ",'" + ar_return + "'";
						sql_str += ",'" + sales_discount + "'";
						sql_str += ",'" + ap_return + "'";
						sql_str += ",'" + iv_cash + "'";
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
						sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += ")";

						if (!cur_db.ExecuteSQL(sql_str))
						{
							return return_value;
						}

						sql_str = "INSERT INTO tblIVClass(";
						sql_str += "sClass_cd";
						sql_str += ",sDescription";
						sql_str += ",sPosting_cd";
						sql_str += ",dtLastUpdate_dt";
						sql_str += ",sLastUpdate_id";
						sql_str += ") VALUES (";
						sql_str += "'" + GlobalVar.goUtility.GetDefaultClassCode() + "'";
						sql_str += ",'Generic'";
						sql_str += ",'" + GlobalVar.goUtility.GetDefaultClassCode() + "'";
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
						sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += ")";

						if (!cur_db.ExecuteSQL(sql_str))
						{
							return return_value;
						}

					}

				}

				return true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ReadIVAccounts)");
				return return_value;

			}

		}

		// PURPOSE : To create the default A/R posting accounts group.
		//
		public static bool ReadARAccounts(ref clsDatabase cur_db)
		{

			bool return_value = false;
			int return_flag = 0;
			string acct_name = "";
			string acct_code = "";
			string exchange_loss = "";
			string ar_prepaid = "";
			string revenue = "";
			string receivable = "";
			string ar_return = "";
			string service_revenue = "";
			string service_return = "";
			string sales_discount = "";
			string ar_freight = "";
			string cash_discount = "";
			string write_off = "";
			string ar_charge = "";
			string ar_restock = "";
			string text_line = "";
			string sql_str = "";
			clsRecordset cur_set = null;
			int i = 0;
			string check_acct = "";
			string cash_acct = "";
			clsFileIO io_stream = new clsFileIO();

			try
			{

				if (!io_stream.OpenFileToRead(cur_db.uDirectory.sHomeDirectory_nm + "\\default.txt"))
				{
					modDialogUtility.DisplayBox(ref cur_db, "default.txt" + cur_db.oLanguage.oMessage.IS_NOT_FOUND);
					return return_value;
				}

				cur_set = new clsRecordset(ref cur_db);

				while (!io_stream.EndOfFile())
				{

					text_line = "";
					acct_name = "";
					acct_code = "";

					text_line = io_stream.ReadOneLine();

					if (GlobalVar.goUtility.SInStr(text_line, "=") > 0)
					{
						acct_name = GlobalVar.goUtility.SLeft(text_line, GlobalVar.goUtility.SInStr(text_line, "=") - 1);
						acct_code = GlobalVar.goUtility.SRight(text_line, GlobalVar.goUtility.SLength(text_line) - GlobalVar.goUtility.SInStr(text_line, "="));
					}

					if (GlobalVar.goUtility.IsNonEmpty(acct_name) && GlobalVar.goUtility.IsNonEmpty(acct_code))
					{
						if (GlobalVar.goUtility.SUCase(acct_name) == "AR_REVENUE")
						{
							revenue = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AR_SERVICE_REVENUE")
						{
							service_revenue = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AR_RECEIVABLE")
						{
							receivable = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AR_PREPAID")
						{
							ar_prepaid = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AR_RETURN")
						{
							ar_return = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AR_SERVICE_RETURN")
						{
							service_return = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AR_FREIGHT")
						{
							ar_freight = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AR_SALEDISCOUNT")
						{
							sales_discount = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AR_CASHDISCOUNT")
						{
							cash_discount = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AR_CHARGE")
						{
							ar_charge = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AR_WRITEOFF")
						{
							write_off = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AR_RESTOCK")
						{
							ar_restock = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_CHECK")
						{
							check_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_CASH")
						{
							cash_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_EXCHANGE_LOSS")
						{
							exchange_loss = acct_code;
						}
						else
						{

						}
					}

				}

				io_stream.CloseFile();

				// Create a record in tblARAccounts and tblARClass
				//
				if (GlobalVar.goUtility.IsNonEmpty(revenue) && GlobalVar.goUtility.IsNonEmpty(receivable) && GlobalVar.goUtility.IsNonEmpty(ar_prepaid) && GlobalVar.goUtility.IsNonEmpty(ar_return) && GlobalVar.goUtility.IsNonEmpty(ar_freight) && GlobalVar.goUtility.IsNonEmpty(sales_discount) && GlobalVar.goUtility.IsNonEmpty(cash_discount) && GlobalVar.goUtility.IsNonEmpty(ar_charge) && GlobalVar.goUtility.IsNonEmpty(write_off) && GlobalVar.goUtility.IsNonEmpty(ar_restock))
				{

					sql_str = "SELECT * FROM tblARAccounts WHERE sPosting_cd = '" + GlobalVar.goUtility.GetDefaultPostingCode() + "'";

					if (!cur_set.CreateSnapshot(sql_str))
					{
						return return_value;
					}
					else if (cur_set.IsEmpty())
					{

						cur_set.Release();

						sql_str = "INSERT INTO tblARAccounts(";
						sql_str += "sPosting_cd";
						sql_str += ",sDescription";
						sql_str += ",sIVPosting_cd";
						sql_str += ",sReceivableAcct_cd";
						sql_str += ",sWriteOffAcct_cd";
						sql_str += ",sSalesFreightAcct_cd";
						sql_str += ",sSalesAcct_cd";
						sql_str += ",sSalesReturnAcct_cd";
						sql_str += ",sSalesDiscAcct_cd";
						sql_str += ",sPaymentDiscAcct_cd";
						sql_str += ",sFinChgAcct_cd";
						sql_str += ",sPrepaidAcct_cd";
						sql_str += ",sRestockChgAcct_cd";
						sql_str += ",sCheckAcct_cd";
						sql_str += ",sCashAcct_cd";
						sql_str += ",sVisaAcct_cd";
						sql_str += ",sMCAcct_cd";
						sql_str += ",sAmexAcct_cd";
						sql_str += ",sDinersAcct_cd";
						sql_str += ",sDiscoverAcct_cd";
						sql_str += ",sOtherCashAcct_cd";
						sql_str += ",sNotesAcct_cd";
						sql_str += ",sExchangeLossAcct_cd";
						sql_str += ",dtLastUpdate_dt";
						sql_str += ",sLastUpdate_id";
						sql_str += ") VALUES (";
						sql_str += "'" + GlobalVar.goUtility.GetDefaultPostingCode() + "'";
						sql_str += ",'Generic'";
						sql_str += ",''";
						sql_str += ",'" + receivable + "'";
						sql_str += ",'" + write_off + "'";
						sql_str += ",'" + ar_freight + "'";
						sql_str += ",'" + revenue + "'";
						sql_str += ",'" + ar_return + "'";
						sql_str += ",'" + sales_discount + "'";
						sql_str += ",'" + cash_discount + "'";
						sql_str += ",'" + ar_charge + "'";
						sql_str += ",'" + ar_prepaid + "'";
						sql_str += ",'" + ar_restock + "'";
						sql_str += ",'" + check_acct + "'";
						sql_str += ",'" + cash_acct + "'";
						sql_str += ",'" + check_acct + "'";
						sql_str += ",'" + check_acct + "'";
						sql_str += ",'" + check_acct + "'";
						sql_str += ",'" + check_acct + "'";
						sql_str += ",'" + check_acct + "'";
						sql_str += ",'" + check_acct + "'";
						sql_str += ",'" + check_acct + "'";
						sql_str += ",'" + exchange_loss + "'";
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
						sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += ")";

						if (!cur_db.ExecuteSQL(sql_str))
						{
							return return_value;
						}

						sql_str = "INSERT INTO tblARClass(";
						sql_str += "sClass_cd";
						sql_str += ",sDescription";
						sql_str += ",sPosting_cd";
						sql_str += ",dtLastUpdate_dt";
						sql_str += ",sLastUpdate_id";
						sql_str += ") VALUES (";
						sql_str += "'" + GlobalVar.goUtility.GetDefaultClassCode() + "'";
						sql_str += ",'Generic'";
						sql_str += ",'" + GlobalVar.goUtility.GetDefaultClassCode() + "'";
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
						sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += ")";

						if (!cur_db.ExecuteSQL(sql_str))
						{
							return return_value;
						}

					}

				}

				return true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ReadARAccounts)");
				return return_value;

			}

		}

		// PURPOSE : To create the default A/P posting accounts group.
		//
		public static bool ReadAPAccounts(ref clsDatabase cur_db)
		{

			bool return_value = false;
			int return_flag = 0;
			string acct_name = "";
			string acct_code = "";
			string ap_prepaid = "";
			string purchase = "";
			string payable = "";
			string ap_return = "";
			string exchange_loss = "";
			string credit_card = "";
			string ap_charge = "";
			string cash_discount = "";
			string freight = "";
			string ap_restock = "";
			string text_line = "";
			string sql_str = "";
			clsRecordset cur_set = null;
			int i = 0;
			string check_acct = "";
			string cash_acct = "";
			string utility_acct = "";
			string rent_acct = "";
			string phone_acct = "";
			string membership_acct = "";
			string ad_acct = "";
			string supply_acct = "";
			string visa_acct = "";
			string amex_acct = "";
			string mc_acct = "";
			string discover_acct = "";
			string write_off = "";

            clsFileIO io_stream = new clsFileIO();

			try
			{

				if (!io_stream.OpenFileToRead(cur_db.uDirectory.sHomeDirectory_nm + "\\default.txt"))
				{
					modDialogUtility.DisplayBox(ref cur_db, "default.txt" + cur_db.oLanguage.oMessage.IS_NOT_FOUND);
					return return_value;
				}

				cur_set = new clsRecordset(ref cur_db);

				while (!io_stream.EndOfFile())
				{

					text_line = "";
					acct_name = "";
					acct_code = "";

					text_line = io_stream.ReadOneLine();

					if (GlobalVar.goUtility.SInStr(text_line, "=") > 0)
					{
						acct_name = GlobalVar.goUtility.SLeft(text_line, GlobalVar.goUtility.SInStr(text_line, "=") - 1);
						acct_code = GlobalVar.goUtility.SRight(text_line, GlobalVar.goUtility.SLength(text_line) - GlobalVar.goUtility.SInStr(text_line, "="));
					}

					if (GlobalVar.goUtility.IsNonEmpty(acct_name) && GlobalVar.goUtility.IsNonEmpty(acct_code))
					{
						if (GlobalVar.goUtility.SUCase(acct_name) == "AP_PURCHASE")
						{
							purchase = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AP_PAYABLE")
						{
							payable = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AP_PREPAID")
						{
							ap_prepaid = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AP_RETURN")
						{
							ap_return = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AP_CASHDISCOUNT")
						{
							cash_discount = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AP_FREIGHT")
						{
							freight = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AP_CHARGE")
						{
							ap_charge = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AP_RESTOCK")
						{
							ap_restock = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_CASH")
						{
							cash_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_CHECK")
						{
							check_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AP_RENT")
						{
							rent_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AP_UTILITY")
						{
							utility_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AP_PHONE")
						{
							phone_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AP_AD")
						{
							ad_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AP_MEMBERSHIP")
						{
							membership_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AP_SUPPLY")
						{
							supply_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "AP_CARD")
						{
							credit_card = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_EXCHANGE_LOSS")
						{
							exchange_loss = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_VISA")
						{
							visa_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_MC")
						{
							mc_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_AMEX")
						{
							amex_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_DISCOVER")
						{
							discover_acct = acct_code;
						}
                        else if (GlobalVar.goUtility.SUCase(acct_name) == "AP_WRITEOFF")
                        {
                            write_off = acct_code;
                        }
                        else
                        {

						}
					}

				}

				io_stream.CloseFile();

				// Create a record in tblAPAccounts and tblAPClass
				//
				if (GlobalVar.goUtility.IsNonEmpty(purchase) && GlobalVar.goUtility.IsNonEmpty(payable) && GlobalVar.goUtility.IsNonEmpty(ap_prepaid) && GlobalVar.goUtility.IsNonEmpty(ap_return) && GlobalVar.goUtility.IsNonEmpty(cash_discount) && GlobalVar.goUtility.IsNonEmpty(freight) && GlobalVar.goUtility.IsNonEmpty(ap_charge) && GlobalVar.goUtility.IsNonEmpty(ap_restock))
				{

					sql_str = "SELECT * FROM tblAPAccounts WHERE sPosting_cd = '" + GlobalVar.goUtility.GetDefaultPostingCode() + "'";

					if (!cur_set.CreateSnapshot(sql_str))
					{
						return return_value;
					}
					else if (cur_set.IsEmpty())
					{

						cur_set.Release();

						sql_str = "INSERT INTO tblAPAccounts(";
						sql_str += "sPosting_cd";
						sql_str += ",sDescription";
						sql_str += ",sIVPosting_cd";
						sql_str += ",sPayableAcct_cd";
						sql_str += ",sCGPAcct_cd";
						sql_str += ",sPurchaseReturnAcct_cd";
						sql_str += ",sPaymentDiscAcct_cd";
						sql_str += ",sFinancialChargeAcct_cd";
						sql_str += ",sFreightChargeAcct_cd";
						sql_str += ",sPrepaidAcct_cd";
						sql_str += ",sRestockChargeAcct_cd";
						sql_str += ",sCheckAcct_cd";
						sql_str += ",sCashAcct_cd";
						sql_str += ",sVisaAcct_cd";
						sql_str += ",sMCAcct_cd";
						sql_str += ",sAmexAcct_cd";
						sql_str += ",sDinersAcct_cd";
						sql_str += ",sDiscoverAcct_cd";
						sql_str += ",sOtherCashAcct_cd";
						sql_str += ",sNotesAcct_cd";
						sql_str += ",sExchangeLossAcct_cd";
						sql_str += ",sWriteOffAcct_cd";
						sql_str += ",dtLastUpdate_dt";
                        sql_str += ",sLastUpdate_id";
                        sql_str += ") VALUES (";
						sql_str += "'" + GlobalVar.goUtility.GetDefaultPostingCode() + "'";
						sql_str += ",'Generic'";
						sql_str += ",''";
						sql_str += ",'" + payable + "'";
						sql_str += ",'" + purchase + "'";
						sql_str += ",'" + ap_return + "'";
						sql_str += ",'" + cash_discount + "'";
						sql_str += ",'" + ap_charge + "'";
						sql_str += ",'" + freight + "'";
						sql_str += ",'" + ap_prepaid + "'";
						sql_str += ",'" + ap_restock + "'";
						sql_str += ",'" + check_acct + "'";
						sql_str += ",'" + cash_acct + "'";
						sql_str += ",'" + visa_acct + "'";
						sql_str += ",'" + mc_acct + "'";
						sql_str += ",'" + amex_acct + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + discover_acct + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + exchange_loss + "'";
						sql_str += ",'" + write_off + "'";
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
                        sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += ")";

						if (!cur_db.ExecuteSQL(sql_str))
						{
							return return_value;
						}

					}

					sql_str = "SELECT * FROM tblAPAccounts WHERE sPosting_cd = 'RENT'";

					if (!cur_set.CreateSnapshot(sql_str))
					{
						return return_value;
					}
					else if (cur_set.IsEmpty())
					{

						cur_set.Release();

						sql_str = "INSERT INTO tblAPAccounts(";
						sql_str += "sPosting_cd";
						sql_str += ",sDescription";
						sql_str += ",sIVPosting_cd";
						sql_str += ",sPayableAcct_cd";
						sql_str += ",sCGPAcct_cd";
						sql_str += ",sPurchaseReturnAcct_cd";
						sql_str += ",sPaymentDiscAcct_cd";
						sql_str += ",sFinancialChargeAcct_cd";
						sql_str += ",sFreightChargeAcct_cd";
						sql_str += ",sPrepaidAcct_cd";
						sql_str += ",sRestockChargeAcct_cd";
						sql_str += ",sCheckAcct_cd";
						sql_str += ",sCashAcct_cd";
						sql_str += ",sVisaAcct_cd";
						sql_str += ",sMCAcct_cd";
						sql_str += ",sAmexAcct_cd";
						sql_str += ",sDinersAcct_cd";
						sql_str += ",sDiscoverAcct_cd";
						sql_str += ",sOtherCashAcct_cd";
						sql_str += ",sNotesAcct_cd";
						sql_str += ",sExchangeLossAcct_cd";
						sql_str += ",sWriteOffAcct_cd";
                        sql_str += ",dtLastUpdate_dt";
						sql_str += ",sLastUpdate_id";
						sql_str += ") VALUES (";
						sql_str += "'RENT'";
						sql_str += ",'Rental expenses'";
						sql_str += ",''";
						sql_str += ",'" + payable + "'";
						sql_str += ",'" + rent_acct + "'";
						sql_str += ",'" + rent_acct + "'";
						sql_str += ",'" + cash_discount + "'";
						sql_str += ",'" + ap_charge + "'";
						sql_str += ",'" + freight + "'";
						sql_str += ",'" + ap_prepaid + "'";
						sql_str += ",'" + ap_restock + "'";
						sql_str += ",'" + check_acct + "'";
						sql_str += ",'" + cash_acct + "'";
						sql_str += ",'" + visa_acct + "'";
						sql_str += ",'" + mc_acct + "'";
						sql_str += ",'" + amex_acct + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + discover_acct + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + exchange_loss + "'";
						sql_str += ",'" + write_off + "'";
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
                        sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += ")";

						if (!cur_db.ExecuteSQL(sql_str))
						{
							return return_value;
						}

					}

					sql_str = "SELECT * FROM tblAPAccounts WHERE sPosting_cd = 'UTILITY'";

					if (!cur_set.CreateSnapshot(sql_str))
					{
						return return_value;
					}
					else if (cur_set.IsEmpty())
					{

						cur_set.Release();

						sql_str = "INSERT INTO tblAPAccounts(";
						sql_str += "sPosting_cd";
						sql_str += ",sDescription";
						sql_str += ",sIVPosting_cd";
						sql_str += ",sPayableAcct_cd";
						sql_str += ",sCGPAcct_cd";
						sql_str += ",sPurchaseReturnAcct_cd";
						sql_str += ",sPaymentDiscAcct_cd";
						sql_str += ",sFinancialChargeAcct_cd";
						sql_str += ",sFreightChargeAcct_cd";
						sql_str += ",sPrepaidAcct_cd";
						sql_str += ",sRestockChargeAcct_cd";
						sql_str += ",sCheckAcct_cd";
						sql_str += ",sCashAcct_cd";
						sql_str += ",sVisaAcct_cd";
						sql_str += ",sMCAcct_cd";
						sql_str += ",sAmexAcct_cd";
						sql_str += ",sDinersAcct_cd";
						sql_str += ",sDiscoverAcct_cd";
						sql_str += ",sOtherCashAcct_cd";
						sql_str += ",sNotesAcct_cd";
						sql_str += ",sExchangeLossAcct_cd";
						sql_str += ",sWriteOffAcct_cd";
						sql_str += ",dtLastUpdate_dt";
                        sql_str += ",sLastUpdate_id";
						sql_str += ") VALUES (";
						sql_str += "'UTILITY'";
						sql_str += ",'Utility expenses'";
						sql_str += ",''";
						sql_str += ",'" + payable + "'";
						sql_str += ",'" + utility_acct + "'";
						sql_str += ",'" + utility_acct + "'";
						sql_str += ",'" + cash_discount + "'";
						sql_str += ",'" + ap_charge + "'";
						sql_str += ",'" + freight + "'";
						sql_str += ",'" + ap_prepaid + "'";
						sql_str += ",'" + ap_restock + "'";
						sql_str += ",'" + check_acct + "'";
						sql_str += ",'" + cash_acct + "'";
						sql_str += ",'" + visa_acct + "'";
						sql_str += ",'" + mc_acct + "'";
						sql_str += ",'" + amex_acct + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + discover_acct + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + exchange_loss + "'";
						sql_str += ",'" + write_off + "'";
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
                        sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += ")";

						if (!cur_db.ExecuteSQL(sql_str))
						{
							return return_value;
						}

					}

					sql_str = "SELECT * FROM tblAPAccounts WHERE sPosting_cd = 'PHONE'";

					if (!cur_set.CreateSnapshot(sql_str))
					{
						return return_value;
					}
					else if (cur_set.IsEmpty())
					{

						cur_set.Release();

						sql_str = "INSERT INTO tblAPAccounts(";
						sql_str += "sPosting_cd";
						sql_str += ",sDescription";
						sql_str += ",sIVPosting_cd";
						sql_str += ",sPayableAcct_cd";
						sql_str += ",sCGPAcct_cd";
						sql_str += ",sPurchaseReturnAcct_cd";
						sql_str += ",sPaymentDiscAcct_cd";
						sql_str += ",sFinancialChargeAcct_cd";
						sql_str += ",sFreightChargeAcct_cd";
						sql_str += ",sPrepaidAcct_cd";
						sql_str += ",sRestockChargeAcct_cd";
						sql_str += ",sCheckAcct_cd";
						sql_str += ",sCashAcct_cd";
						sql_str += ",sVisaAcct_cd";
						sql_str += ",sMCAcct_cd";
						sql_str += ",sAmexAcct_cd";
						sql_str += ",sDinersAcct_cd";
						sql_str += ",sDiscoverAcct_cd";
						sql_str += ",sOtherCashAcct_cd";
						sql_str += ",sNotesAcct_cd";
						sql_str += ",sExchangeLossAcct_cd";
						sql_str += ",sWriteOffAcct_cd";
						sql_str += ",dtLastUpdate_dt";
                        sql_str += ",sLastUpdate_id";
						sql_str += ") VALUES (";
						sql_str += "'PHONE'";
						sql_str += ",'Phone expenses'";
						sql_str += ",''";
						sql_str += ",'" + payable + "'";
						sql_str += ",'" + phone_acct + "'";
						sql_str += ",'" + phone_acct + "'";
						sql_str += ",'" + cash_discount + "'";
						sql_str += ",'" + ap_charge + "'";
						sql_str += ",'" + freight + "'";
						sql_str += ",'" + ap_prepaid + "'";
						sql_str += ",'" + ap_restock + "'";
						sql_str += ",'" + check_acct + "'";
						sql_str += ",'" + cash_acct + "'";
						sql_str += ",'" + visa_acct + "'";
						sql_str += ",'" + mc_acct + "'";
						sql_str += ",'" + amex_acct + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + discover_acct + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + exchange_loss + "'";
						sql_str += ",'" + write_off + "'";
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
                        sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += ")";

						if (!cur_db.ExecuteSQL(sql_str))
						{
							return return_value;
						}

					}

					sql_str = "SELECT * FROM tblAPAccounts WHERE sPosting_cd = 'AD'";

					if (!cur_set.CreateSnapshot(sql_str))
					{
						return return_value;
					}
					else if (cur_set.IsEmpty())
					{

						cur_set.Release();

						sql_str = "INSERT INTO tblAPAccounts(";
						sql_str += "sPosting_cd";
						sql_str += ",sDescription";
						sql_str += ",sIVPosting_cd";
						sql_str += ",sPayableAcct_cd";
						sql_str += ",sCGPAcct_cd";
						sql_str += ",sPurchaseReturnAcct_cd";
						sql_str += ",sPaymentDiscAcct_cd";
						sql_str += ",sFinancialChargeAcct_cd";
						sql_str += ",sFreightChargeAcct_cd";
						sql_str += ",sPrepaidAcct_cd";
						sql_str += ",sRestockChargeAcct_cd";
						sql_str += ",sCheckAcct_cd";
						sql_str += ",sCashAcct_cd";
						sql_str += ",sVisaAcct_cd";
						sql_str += ",sMCAcct_cd";
						sql_str += ",sAmexAcct_cd";
						sql_str += ",sDinersAcct_cd";
						sql_str += ",sDiscoverAcct_cd";
						sql_str += ",sOtherCashAcct_cd";
						sql_str += ",sNotesAcct_cd";
						sql_str += ",sExchangeLossAcct_cd";
						sql_str += ",sWriteOffAcct_cd";
						sql_str += ",dtLastUpdate_dt";
                        sql_str += ",sLastUpdate_id";
						sql_str += ") VALUES (";
						sql_str += "'AD'";
						sql_str += ",'Advertisement expenses'";
						sql_str += ",''";
						sql_str += ",'" + payable + "'";
						sql_str += ",'" + ad_acct + "'";
						sql_str += ",'" + ad_acct + "'";
						sql_str += ",'" + cash_discount + "'";
						sql_str += ",'" + ap_charge + "'";
						sql_str += ",'" + freight + "'";
						sql_str += ",'" + ap_prepaid + "'";
						sql_str += ",'" + ap_restock + "'";
						sql_str += ",'" + check_acct + "'";
						sql_str += ",'" + cash_acct + "'";
						sql_str += ",'" + visa_acct + "'";
						sql_str += ",'" + mc_acct + "'";
						sql_str += ",'" + amex_acct + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + discover_acct + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + exchange_loss + "'";
						sql_str += ",'" + write_off + "'";
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
                        sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += ")";

						if (!cur_db.ExecuteSQL(sql_str))
						{
							return return_value;
						}

					}

					sql_str = "SELECT * FROM tblAPAccounts WHERE sPosting_cd = 'MEMBER'";

					if (!cur_set.CreateSnapshot(sql_str))
					{
						return return_value;
					}
					else if (cur_set.IsEmpty())
					{

						cur_set.Release();

						sql_str = "INSERT INTO tblAPAccounts(";
						sql_str += "sPosting_cd";
						sql_str += ",sDescription";
						sql_str += ",sIVPosting_cd";
						sql_str += ",sPayableAcct_cd";
						sql_str += ",sCGPAcct_cd";
						sql_str += ",sPurchaseReturnAcct_cd";
						sql_str += ",sPaymentDiscAcct_cd";
						sql_str += ",sFinancialChargeAcct_cd";
						sql_str += ",sFreightChargeAcct_cd";
						sql_str += ",sPrepaidAcct_cd";
						sql_str += ",sRestockChargeAcct_cd";
						sql_str += ",sCheckAcct_cd";
						sql_str += ",sCashAcct_cd";
						sql_str += ",sVisaAcct_cd";
						sql_str += ",sMCAcct_cd";
						sql_str += ",sAmexAcct_cd";
						sql_str += ",sDinersAcct_cd";
						sql_str += ",sDiscoverAcct_cd";
						sql_str += ",sOtherCashAcct_cd";
						sql_str += ",sNotesAcct_cd";
						sql_str += ",sExchangeLossAcct_cd";
						sql_str += ",sWriteOffAcct_cd";
						sql_str += ",dtLastUpdate_dt";
                        sql_str += ",sLastUpdate_id";
						sql_str += ") VALUES (";
						sql_str += "'MEMBER'";
						sql_str += ",'Membership expenses'";
						sql_str += ",''";
						sql_str += ",'" + payable + "'";
						sql_str += ",'" + membership_acct + "'";
						sql_str += ",'" + membership_acct + "'";
						sql_str += ",'" + cash_discount + "'";
						sql_str += ",'" + ap_charge + "'";
						sql_str += ",'" + freight + "'";
						sql_str += ",'" + ap_prepaid + "'";
						sql_str += ",'" + ap_restock + "'";
						sql_str += ",'" + check_acct + "'";
						sql_str += ",'" + cash_acct + "'";
						sql_str += ",'" + visa_acct + "'";
						sql_str += ",'" + mc_acct + "'";
						sql_str += ",'" + amex_acct + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + discover_acct + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + exchange_loss + "'";
						sql_str += ",'" + write_off + "'";
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
                        sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += ")";

						if (!cur_db.ExecuteSQL(sql_str))
						{
							return return_value;
						}

					}

					sql_str = "SELECT * FROM tblAPAccounts WHERE sPosting_cd = 'SUPPLY'";

					if (!cur_set.CreateSnapshot(sql_str))
					{
						return return_value;
					}
					else if (cur_set.IsEmpty())
					{

						cur_set.Release();

						sql_str = "INSERT INTO tblAPAccounts(";
						sql_str += "sPosting_cd";
						sql_str += ",sDescription";
						sql_str += ",sIVPosting_cd";
						sql_str += ",sPayableAcct_cd";
						sql_str += ",sCGPAcct_cd";
						sql_str += ",sPurchaseReturnAcct_cd";
						sql_str += ",sPaymentDiscAcct_cd";
						sql_str += ",sFinancialChargeAcct_cd";
						sql_str += ",sFreightChargeAcct_cd";
						sql_str += ",sPrepaidAcct_cd";
						sql_str += ",sRestockChargeAcct_cd";
						sql_str += ",sCheckAcct_cd";
						sql_str += ",sCashAcct_cd";
						sql_str += ",sVisaAcct_cd";
						sql_str += ",sMCAcct_cd";
						sql_str += ",sAmexAcct_cd";
						sql_str += ",sDinersAcct_cd";
						sql_str += ",sDiscoverAcct_cd";
						sql_str += ",sOtherCashAcct_cd";
						sql_str += ",sNotesAcct_cd";
						sql_str += ",sExchangeLossAcct_cd";
						sql_str += ",sWriteOffAcct_cd";
						sql_str += ",dtLastUpdate_dt";
                        sql_str += ",sLastUpdate_id";
						sql_str += ") VALUES (";
						sql_str += "'SUPPLY'";
						sql_str += ",'Supply expenses'";
						sql_str += ",''";
						sql_str += ",'" + payable + "'";
						sql_str += ",'" + supply_acct + "'";
						sql_str += ",'" + supply_acct + "'";
						sql_str += ",'" + cash_discount + "'";
						sql_str += ",'" + ap_charge + "'";
						sql_str += ",'" + freight + "'";
						sql_str += ",'" + ap_prepaid + "'";
						sql_str += ",'" + ap_restock + "'";
						sql_str += ",'" + check_acct + "'";
						sql_str += ",'" + cash_acct + "'";
						sql_str += ",'" + visa_acct + "'";
						sql_str += ",'" + mc_acct + "'";
						sql_str += ",'" + amex_acct + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + discover_acct + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + credit_card + "'";
						sql_str += ",'" + exchange_loss + "'";
						sql_str += ",'" + write_off + "'";
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
                        sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += ")";

						if (!cur_db.ExecuteSQL(sql_str))
						{
							return return_value;
						}

					}

					sql_str = "SELECT * FROM tblAPClass WHERE sClass_cd = '" + GlobalVar.goUtility.GetDefaultClassCode() + "'";
					if (!cur_set.CreateSnapshot(sql_str))
					{
						return return_value;
					}
					else if (cur_set.IsEmpty())
					{
						sql_str = "INSERT INTO tblAPClass(";
						sql_str += "sClass_cd";
						sql_str += ",sDescription";
						sql_str += ",sPosting_cd";
						sql_str += ",dtLastUpdate_dt";
						sql_str += ",sLastUpdate_id";
						sql_str += ") VALUES (";
						sql_str += "'" + GlobalVar.goUtility.GetDefaultClassCode() + "'";
						sql_str += ",'Generic'";
						sql_str += ",'" + GlobalVar.goUtility.GetDefaultClassCode() + "'";
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
						sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += ")";

						if (!cur_db.ExecuteSQL(sql_str))
						{
							return return_value;
						}
					}

					sql_str = "SELECT * FROM tblAPClass WHERE sClass_cd = 'EXPENSE'";
					if (!cur_set.CreateSnapshot(sql_str))
					{
						return return_value;
					}
					else if (cur_set.IsEmpty())
					{
						sql_str = "INSERT INTO tblAPClass(";
						sql_str += "sClass_cd";
						sql_str += ",sDescription";
						sql_str += ",sPosting_cd";
						sql_str += ",dtLastUpdate_dt";
						sql_str += ",sLastUpdate_id";
						sql_str += ") VALUES (";
						sql_str += "'EXPENSE'";
						sql_str += ",'Expense Generic'";
						sql_str += ",'SUPPLY'";
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
						sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += ")";

						if (!cur_db.ExecuteSQL(sql_str))
						{
							return return_value;
						}
					}

				}

				return true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ReadAPAccounts)");
				return return_value;

			}

		}

		// Create Back Rec. accounts.
		//
		public static bool ReadBRAccounts(ref clsDatabase cur_db, string calling_module = "")
		{

			bool return_value = false;
			int return_flag = 0;
			string acct_code = "";
			string acct_name = "";
			string check_acct = "";
			string int_acct = "";
			string fin_acct = "";
			string savings_acct = "";
			string text_line = "";
			string sql_str = "";
			clsRecordset cur_set = null;
			int i = 0;
			string payroll_acct = "";
			string visa_acct = "";
			string amex_acct = "";
			string mc_acct = "";
			string discover_acct = "";
			clsFileIO io_stream = new clsFileIO();
			bool bank_exists = false;
			bool card_exists = false;

			try
			{

				cur_set = new clsRecordset(ref cur_db);

				if (calling_module == cur_db.oLanguage.oString.STR_ADVISOR) // Advisor will ask for the bank account and create them there.
				{
					return true;
				}

				sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblBRBankAccount";
				if (!cur_set.CreateSnapshot(sql_str))
				{
					return return_value;
				}
				else if (cur_set.iField("iMaxNum") > 0)
				{
					bank_exists = true;
				}

				sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblBRCreditCard";
				if (!cur_set.CreateSnapshot(sql_str))
				{
					return return_value;
				}
				else if (cur_set.iField("iMaxNum") > 0)
				{
					card_exists = true;
				}

				if (card_exists && bank_exists)
				{
					return true;
				}

				if (!io_stream.OpenFileToRead(cur_db.uDirectory.sHomeDirectory_nm + "\\default.txt"))
				{
					modDialogUtility.DisplayBox(ref cur_db, "default.txt " + cur_db.oLanguage.oMessage.IS_MISSING);
					return return_value;
				}

				while (!io_stream.EndOfFile())
				{

					text_line = "";
					acct_name = "";
					acct_code = "";

					text_line = io_stream.ReadOneLine();

					if (GlobalVar.goUtility.SInStr(text_line, "=") > 0)
					{
						acct_name = GlobalVar.goUtility.SLeft(text_line, GlobalVar.goUtility.SInStr(text_line, "=") - 1);
						acct_code = GlobalVar.goUtility.SRight(text_line, GlobalVar.goUtility.SLength(text_line) - GlobalVar.goUtility.SInStr(text_line, "="));
					}

					if (GlobalVar.goUtility.IsNonEmpty(acct_name) && GlobalVar.goUtility.IsNonEmpty(acct_code))
					{
						if (GlobalVar.goUtility.SUCase(acct_name) == "BR_CHECK")
						{
							check_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "PR_CASH")
						{
							payroll_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_INTEREST")
						{
							int_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_CHARGE")
						{
							fin_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_SAVINGS")
						{
							savings_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_VISA")
						{
							visa_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_MC")
						{
							mc_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_AMEX")
						{
							amex_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_DISCOVER")
						{
							discover_acct = acct_code;
						}
						else
						{
							//
						}
					}

				}

				io_stream.CloseFile();

				// Create cash accounts
				//
				if (!bank_exists && GlobalVar.goUtility.IsNonEmpty(check_acct))
				{

					sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblBRBankAccount WHERE sGLAcct_cd = '" + check_acct + "'";

					if (!cur_set.CreateSnapshot(sql_str))
					{
						return return_value;
					}
					else if (cur_set.iField("iMaxNum") == 0)
					{

						cur_set.Release();

						sql_str = "INSERT INTO tblBRBankAccount(";
						sql_str += "sBank_cd";
						sql_str += ",sAccount_num";
						sql_str += ",sBank_nm";
						sql_str += ",sAddress1";
						sql_str += ",sAddress2";
						sql_str += ",sAddress3";
						sql_str += ",sCity";
						sql_str += ",sState";
						sql_str += ",sZipCode";
						sql_str += ",sCountry_cd";
						sql_str += ",sPhone";
						sql_str += ",sFax";
						sql_str += ",sDescription";
						sql_str += ",sGLAcct_cd";
						sql_str += ",sFinancialChargeAcct_cd";
						sql_str += ",sInterestAcct_cd";
						sql_str += ",iAccount_typ";
						sql_str += ",sElectronic_cd";
						sql_str += ",sCurrency_cd";
						sql_str += ",iNextCheck_num";
						sql_str += ",iNextDeposit_num";
						sql_str += ",mBalance_amt";
						sql_str += ",mBalanceInPrimary_amt";
						sql_str += ",dtLastUpdate_dt";
						sql_str += ",sLastUpdate_id";
						sql_str += ") VALUES (";
						sql_str += "'CHECKING-ACCT'";
						sql_str += ",'checking account'";
						sql_str += ",'Checking Account'";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",'Your main checking account'";
						sql_str += ",'" + check_acct + "'";
						sql_str += ",'" + fin_acct + "'";
						sql_str += ",'" + int_acct + "'";
						sql_str += "," + GlobalVar.goUtility.ToStr(GlobalVar.goBRConstant.CHECKING_ACCT_TYPE_NUM);
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",1";
						sql_str += ",1";
						sql_str += ",0";
						sql_str += ",0";
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
						sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += ")";

						if (!cur_db.ExecuteSQL(sql_str))
						{
							return return_value;
						}

					}

				}

				if (!bank_exists && GlobalVar.goUtility.IsNonEmpty(savings_acct))
				{

					sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblBRBankAccount WHERE sGLAcct_cd = '" + savings_acct + "'";

					if (!cur_set.CreateSnapshot(sql_str))
					{
						return return_value;
					}
					else if (cur_set.iField("iMaxNum") == 0)
					{

						cur_set.Release();

						sql_str = "INSERT INTO tblBRBankAccount(";
						sql_str += "sBank_cd";
						sql_str += ",sAccount_num";
						sql_str += ",sBank_nm";
						sql_str += ",sAddress1";
						sql_str += ",sAddress2";
						sql_str += ",sAddress3";
						sql_str += ",sCity";
						sql_str += ",sState";
						sql_str += ",sZipCode";
						sql_str += ",sCountry_cd";
						sql_str += ",sPhone";
						sql_str += ",sFax";
						sql_str += ",sDescription";
						sql_str += ",sGLAcct_cd";
						sql_str += ",sFinancialChargeAcct_cd";
						sql_str += ",sInterestAcct_cd";
						sql_str += ",iAccount_typ";
						sql_str += ",sElectronic_cd";
						sql_str += ",sCurrency_cd";
						sql_str += ",iNextCheck_num";
						sql_str += ",iNextDeposit_num";
						sql_str += ",mBalance_amt";
						sql_str += ",mBalanceInPrimary_amt";
						sql_str += ",dtLastUpdate_dt";
						sql_str += ",sLastUpdate_id";
						sql_str += ") VALUES (";
						sql_str += "'SAVINGS-ACCT'";
						sql_str += ",'savings account'";
						sql_str += ",'Savings Account'";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",'Your main savings account'";
						sql_str += ",'" + savings_acct + "'";
						sql_str += ",'" + fin_acct + "'";
						sql_str += ",'" + int_acct + "'";
						sql_str += "," + GlobalVar.goUtility.ToStr(GlobalVar.goBRConstant.SAVINGS_ACCT_TYPE_NUM);
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",1";
						sql_str += ",1";
						sql_str += ",0";
						sql_str += ",0";
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
						sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += ")";

						if (!cur_db.ExecuteSQL(sql_str))
						{
							return return_value;
						}

					}

				}

				// Read payroll cash accounts
				//
				if (!bank_exists && GlobalVar.goUtility.IsNonEmpty(payroll_acct))
				{

					sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblBRBankAccount WHERE sGLAcct_cd = '" + payroll_acct + "'";

					if (!cur_set.CreateSnapshot(sql_str))
					{
						return return_value;
					}
					else if (cur_set.iField("iMaxNum") == 0)
					{

						cur_set.Release();

						sql_str = "INSERT INTO tblBRBankAccount(";
						sql_str += "sBank_cd";
						sql_str += ",sAccount_num";
						sql_str += ",sBank_nm";
						sql_str += ",sAddress1";
						sql_str += ",sAddress2";
						sql_str += ",sAddress3";
						sql_str += ",sCity";
						sql_str += ",sState";
						sql_str += ",sZipCode";
						sql_str += ",sCountry_cd";
						sql_str += ",sPhone";
						sql_str += ",sFax";
						sql_str += ",sDescription";
						sql_str += ",sGLAcct_cd";
						sql_str += ",sFinancialChargeAcct_cd";
						sql_str += ",sInterestAcct_cd";
						sql_str += ",iAccount_typ";
						sql_str += ",sElectronic_cd";
						sql_str += ",sCurrency_cd";
						sql_str += ",iNextCheck_num";
						sql_str += ",iNextDeposit_num";
						sql_str += ",mBalance_amt";
						sql_str += ",mBalanceInPrimary_amt";
						sql_str += ",dtLastUpdate_dt";
						sql_str += ",sLastUpdate_id";
						sql_str += ") VALUES (";
						sql_str += "'PAYROLL ACCT'";
						sql_str += ",'Bank account number'";
						sql_str += ",'Your payroll bank'";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",'Payroll Account'";
						sql_str += ",'" + payroll_acct + "'";
						sql_str += ",'" + fin_acct + "'";
						sql_str += ",'" + int_acct + "'";
						sql_str += "," + GlobalVar.goUtility.ToStr(GlobalVar.goBRConstant.CHECKING_ACCT_TYPE_NUM);
						sql_str += ",''";
						sql_str += ",''";
						sql_str += ",1";
						sql_str += ",1";
						sql_str += ",0";
						sql_str += ",0";
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
						sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += ")";

						if (!cur_db.ExecuteSQL(sql_str))
						{
							return return_value;
						}

					}

				}

				//if (!card_exists && GlobalVar.goUtility.IsNonEmpty(visa_acct))
				//{

				//	sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblBRCreditCard WHERE sGLAcct_cd = '" + visa_acct + "'";

				//	if (!cur_set.CreateSnapshot(sql_str))
				//	{
				//		return return_value;
				//	}
				//	else if (cur_set.iField("iMaxNum") == 0)
				//	{
				//		cur_set.Release();
				//		sql_str = "INSERT INTO tblBRCreditCard (";
				//		sql_str += "sCard_cd";
				//		sql_str += ",iAccount_typ";
				//		sql_str += ",sAddress1";
				//		sql_str += ",sAddress2";
				//		sql_str += ",sAddress3";
				//		sql_str += ",sPhone";
				//		sql_str += ",sFax";
				//		sql_str += ",sZipCode";
				//		sql_str += ",sState";
				//		sql_str += ",sCity";
				//		sql_str += ",sGLAcct_cd";
				//		sql_str += ",sFinancialChargeAcct_cd";
				//		sql_str += ",sDescription";
				//		sql_str += ",sAccount_num";
				//		sql_str += ",sComment";
				//		sql_str += ",mBalance_amt";
				//		sql_str += ",sLastUpdate_id";
				//		sql_str += ",dtLastUpdate_dt";
				//		sql_str += ") VALUES (";
				//		sql_str += "'VISA'";
				//		sql_str += "," + GlobalVar.goBRConstant.CARD_CREDIT_TYPE_NUM.ToString();
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",'" + visa_acct + "'";
				//		sql_str += ",'" + fin_acct + "'";
				//		sql_str += ",'Visa Card'";
				//		sql_str += ",'Account number'";
				//		sql_str += ",'Your VISA account'";
				//		sql_str += ",0";
				//		sql_str += ",'" + cur_db.sUser_cd + "'";
				//		sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
				//		sql_str += ")";
				//		if (!cur_db.ExecuteSQL(sql_str))
				//		{
				//			return return_value;
				//		}

				//	}

				//}

				//if (!card_exists && GlobalVar.goUtility.IsNonEmpty(amex_acct))
				//{

				//	sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblBRCreditCard WHERE sGLAcct_cd = '" + amex_acct + "'";

				//	if (!cur_set.CreateSnapshot(sql_str))
				//	{
				//		return return_value;
				//	}
				//	else if (cur_set.iField("iMaxNum") == 0)
				//	{
				//		cur_set.Release();
				//		sql_str = "INSERT INTO tblBRCreditCard (";
				//		sql_str += "sCard_cd";
				//		sql_str += ",iAccount_typ";
				//		sql_str += ",sAddress1";
				//		sql_str += ",sAddress2";
				//		sql_str += ",sAddress3";
				//		sql_str += ",sPhone";
				//		sql_str += ",sFax";
				//		sql_str += ",sZipCode";
				//		sql_str += ",sState";
				//		sql_str += ",sCity";
				//		sql_str += ",sGLAcct_cd";
				//		sql_str += ",sFinancialChargeAcct_cd";
				//		sql_str += ",sDescription";
				//		sql_str += ",sAccount_num";
				//		sql_str += ",sComment";
				//		sql_str += ",mBalance_amt";
				//		sql_str += ",sLastUpdate_id";
				//		sql_str += ",dtLastUpdate_dt";
				//		sql_str += ") VALUES (";
				//		sql_str += "'AMEX'";
				//		sql_str += "," + GlobalVar.goBRConstant.CARD_CREDIT_TYPE_NUM.ToString();
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",'" + amex_acct + "'";
				//		sql_str += ",'" + fin_acct + "'";
				//		sql_str += ",'AMEX Card'";
				//		sql_str += ",'Account number'";
				//		sql_str += ",'Your American Express account'";
				//		sql_str += ",0";
				//		sql_str += ",'" + cur_db.sUser_cd + "'";
				//		sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
				//		sql_str += ")";
				//		if (!cur_db.ExecuteSQL(sql_str))
				//		{
				//			return return_value;
				//		}

				//	}

				//}

				//if (!card_exists && GlobalVar.goUtility.IsNonEmpty(mc_acct))
				//{

				//	sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblBRCreditCard WHERE sGLAcct_cd = '" + mc_acct + "'";

				//	if (!cur_set.CreateSnapshot(sql_str))
				//	{
				//		return return_value;
				//	}
				//	else if (cur_set.iField("iMaxNum") == 0)
				//	{
				//		cur_set.Release();
				//		sql_str = "INSERT INTO tblBRCreditCard (";
				//		sql_str += "sCard_cd";
				//		sql_str += ",iAccount_typ";
				//		sql_str += ",sAddress1";
				//		sql_str += ",sAddress2";
				//		sql_str += ",sAddress3";
				//		sql_str += ",sPhone";
				//		sql_str += ",sFax";
				//		sql_str += ",sZipCode";
				//		sql_str += ",sState";
				//		sql_str += ",sCity";
				//		sql_str += ",sGLAcct_cd";
				//		sql_str += ",sFinancialChargeAcct_cd";
				//		sql_str += ",sDescription";
				//		sql_str += ",sAccount_num";
				//		sql_str += ",sComment";
				//		sql_str += ",mBalance_amt";
				//		sql_str += ",sLastUpdate_id";
				//		sql_str += ",dtLastUpdate_dt";
				//		sql_str += ") VALUES (";
				//		sql_str += "'M/C'";
				//		sql_str += "," + GlobalVar.goBRConstant.CARD_CREDIT_TYPE_NUM.ToString();
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",'" + mc_acct + "'";
				//		sql_str += ",'" + fin_acct + "'";
				//		sql_str += ",'M/C Card'";
				//		sql_str += ",'Account number'";
				//		sql_str += ",'Your Master Card account'";
				//		sql_str += ",0";
				//		sql_str += ",'" + cur_db.sUser_cd + "'";
				//		sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
				//		sql_str += ")";
				//		if (!cur_db.ExecuteSQL(sql_str))
				//		{
				//			return return_value;
				//		}

				//	}

				//}

				//if (!card_exists && GlobalVar.goUtility.IsNonEmpty(discover_acct))
				//{

				//	sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblBRCreditCard WHERE sGLAcct_cd = '" + discover_acct + "'";

				//	if (!cur_set.CreateSnapshot(sql_str))
				//	{
				//		return return_value;
				//	}
				//	else if (cur_set.iField("iMaxNum") == 0)
				//	{
				//		cur_set.Release();
				//		sql_str = "INSERT INTO tblBRCreditCard (";
				//		sql_str += "sCard_cd";
				//		sql_str += ",iAccount_typ";
				//		sql_str += ",sAddress1";
				//		sql_str += ",sAddress2";
				//		sql_str += ",sAddress3";
				//		sql_str += ",sPhone";
				//		sql_str += ",sFax";
				//		sql_str += ",sZipCode";
				//		sql_str += ",sState";
				//		sql_str += ",sCity";
				//		sql_str += ",sGLAcct_cd";
				//		sql_str += ",sFinancialChargeAcct_cd";
				//		sql_str += ",sDescription";
				//		sql_str += ",sAccount_num";
				//		sql_str += ",sComment";
				//		sql_str += ",mBalance_amt";
				//		sql_str += ",sLastUpdate_id";
				//		sql_str += ",dtLastUpdate_dt";
				//		sql_str += ") VALUES (";
				//		sql_str += "'DISCOVER'";
				//		sql_str += "," + GlobalVar.goBRConstant.CARD_CREDIT_TYPE_NUM.ToString();
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",''";
				//		sql_str += ",'" + discover_acct + "'";
				//		sql_str += ",'" + fin_acct + "'";
				//		sql_str += ",'Discover Card'";
				//		sql_str += ",'Account number'";
				//		sql_str += ",'Your Discover account'";
				//		sql_str += ",0";
				//		sql_str += ",'" + cur_db.sUser_cd + "'";
				//		sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
				//		sql_str += ")";
				//		if (!cur_db.ExecuteSQL(sql_str))
				//		{
				//			return return_value;
				//		}

				//	}

				//}

				return true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ReadBRAccounts)");
				return return_value;

			}

		}

		public static bool ReadPRAccounts(ref clsDatabase cur_db)
		{

			bool return_value = false;
			int return_flag = 0;
			string acct_code = "";
			string acct_name = "";
			string text_line = "";
			string sql_str = "";
			clsRecordset cur_set = null;
			int i = 0;
			string expense_acct = "";
			string cash_acct = "";
			string state_acct = "";
			string futa_acct = "";
			string local_acct = "";
			string fica_acct = "";
			string sdi_acct = "";
			string medicare_acct = "";
			string sui_acct = "";
			string k401_acct = "";
			string other_acct = "";
			string pretax_acct = "";
			string life_acct = "";
			string aftertax_acct = "";
			string health_acct = "";
			string dental_acct = "";
			string othe_ins_acct = "";
			clsFileIO io_stream = new clsFileIO();

			try
			{

				if (!io_stream.OpenFileToRead(cur_db.uDirectory.sHomeDirectory_nm + "\\default.txt"))
				{
					modDialogUtility.DisplayBox(ref cur_db, "default.txt" + cur_db.oLanguage.oMessage.IS_NOT_FOUND);
					return return_value;
				}

				cur_set = new clsRecordset(ref cur_db);

				while (!io_stream.EndOfFile())
				{

					text_line = "";
					acct_name = "";
					acct_code = "";

					text_line = io_stream.ReadOneLine();

					if (GlobalVar.goUtility.SInStr(text_line, "=") > 0)
					{
						acct_name = GlobalVar.goUtility.SLeft(text_line, GlobalVar.goUtility.SInStr(text_line, "=") - 1);
						acct_code = GlobalVar.goUtility.SRight(text_line, GlobalVar.goUtility.SLength(text_line) - GlobalVar.goUtility.SInStr(text_line, "="));
					}

					if (GlobalVar.goUtility.IsNonEmpty(acct_name) && GlobalVar.goUtility.IsNonEmpty(acct_code))
					{
						if (GlobalVar.goUtility.SUCase(acct_name) == "PR_CASH")
						{
							cash_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "PR_EXPENSE")
						{
							expense_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "PR_STATE")
						{
							state_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "PR_LOCAL")
						{
							local_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "PR_FUTA")
						{
							futa_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "PR_FICA")
						{
							fica_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "PR_MEDICARE")
						{
							medicare_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "PR_SDI")
						{
							sdi_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "PR_SUI")
						{
							sui_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "PR_OTHER_TAX1")
						{
							other_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "PR_K401")
						{
							k401_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "PR_PRETAX")
						{
							pretax_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "PR_AFTERTAX")
						{
							aftertax_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "PR_LIFE_INS")
						{
							life_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "PR_HEALTH_INS")
						{
							health_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "PR_DENTAL_INS")
						{
							dental_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "PR_OTHER_INS")
						{
							othe_ins_acct = acct_code;
						}
						else
						{
							//
						}
					}

				}

				io_stream.CloseFile();

				sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblPRAccounts";

				if (!cur_set.CreateSnapshot(sql_str))
				{
					return return_value;
				}
				else if (cur_set.iField("iMaxNum") == 0)
				{

					cur_set.Release();

					sql_str = "INSERT INTO tblPRAccounts(";
					sql_str += " sPosting_cd";
					sql_str += ",sDescription";
					sql_str += ",sPRCashAcct_cd";
					sql_str += ",sPRExpenseAcct_cd";
					sql_str += ",sStateAcct_cd";
					sql_str += ",sLocalAcct_cd";
					sql_str += ",sFUTAAcct_cd";
					sql_str += ",sFICAAcct_cd";
					sql_str += ",sMedicareAcct_cd";
					sql_str += ",sSDIAcct_cd";
					sql_str += ",sSUIAcct_cd";
					sql_str += ",sOtherTax1Acct_cd";
					sql_str += ",sK401Acct_cd";
					sql_str += ",sPretaxAcct_cd";
					sql_str += ",sAftertaxAcct_cd";
					sql_str += ",sLifeInsAcct_cd";
					sql_str += ",sHealthInsAcct_cd";
					sql_str += ",sDentalInsAcct_cd";
					sql_str += ",sOtherInsAcct_cd";
					sql_str += ",dtLastUpdate_dt";
					sql_str += ",sLastUpdate_id";
					sql_str += ") VALUES (";
					sql_str += "'" + GlobalVar.goUtility.GetDefaultPostingCode() + "'";
					sql_str += ",'Generic posting group'";
					sql_str += ",'" + cash_acct + "'";
					sql_str += ",'" + expense_acct + "'";
					sql_str += ",'" + state_acct + "'";
					sql_str += ",'" + local_acct + "'";
					sql_str += ",'" + futa_acct + "'";
					sql_str += ",'" + fica_acct + "'";
					sql_str += ",'" + medicare_acct + "'";
					sql_str += ",'" + sdi_acct + "'";
					sql_str += ",'" + sui_acct + "'";
					sql_str += ",'" + other_acct + "'";
					sql_str += ",'" + k401_acct + "'";
					sql_str += ",'" + pretax_acct + "'";
					sql_str += ",'" + aftertax_acct + "'";
					sql_str += ",'" + life_acct + "'";
					sql_str += ",'" + health_acct + "'";
					sql_str += ",'" + dental_acct + "'";
					sql_str += ",'" + othe_ins_acct + "'";
					sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
					sql_str += ",'" + cur_db.sUser_cd + "'";
					sql_str += ")";

					if (!cur_db.ExecuteSQL(sql_str))
					{
						return return_value;
					}

				}

				sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblPRGroup";

				if (!cur_set.CreateSnapshot(sql_str))
				{
					return return_value;
				}
				else if (cur_set.iField("iMaxNum") == 0)
				{

					cur_set.Release();

					sql_str = "INSERT INTO tblPRGroup(";
					sql_str += " sGroup_cd";
					sql_str += ",sDescription";
					sql_str += ",sPosting_cd";
					sql_str += ",sOvertime_cd";
					sql_str += ",iPayroll_typ";
					sql_str += ",dtLastUpdate_dt";
					sql_str += ",sLastUpdate_id";
					sql_str += ") VALUES (";
					sql_str += "'SALARY'";
					sql_str += ",'Salary type'";
					sql_str += ",'" + GlobalVar.goUtility.GetDefaultPostingCode() + "'";
					sql_str += ",'" + clsConstant.DEFAULT_CODE + "'";
					sql_str += ",3";
					sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
					sql_str += ",'" + cur_db.sUser_cd + "'";
					sql_str += ")";

					if (!cur_db.ExecuteSQL(sql_str))
					{
						return return_value;
					}

				}

				sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblPROvertime";

				if (!cur_set.CreateSnapshot(sql_str))
				{
					return return_value;
				}
				else if (cur_set.iField("iMaxNum") == 0)
				{

					cur_set.Release();

					sql_str = "INSERT INTO tblPROvertime(";
					sql_str += " sOvertime_cd";
					sql_str += ",sDescription";
					sql_str += ",iOvertime_typ";
					sql_str += ",fOvertime1Hours";
					sql_str += ",fOvertime1Rate";
					sql_str += ",fOvertime2Hours";
					sql_str += ",fOvertime2Rate";
					sql_str += ",fOvertime3Hours";
					sql_str += ",fOvertime3Rate";
					sql_str += ",dtLastUpdate_dt";
					sql_str += ",sLastUpdate_id";
					sql_str += ") VALUES (";
					sql_str += "'" + clsConstant.DEFAULT_CODE + "'";
					sql_str += ",'General Overtime'";
					sql_str += ",1";
					sql_str += ",20";
					sql_str += ",150";
					sql_str += ",20";
					sql_str += ",200";
					sql_str += ",1000";
					sql_str += ",300";
					sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
					sql_str += ",'" + cur_db.sUser_cd + "'";
					sql_str += ")";

					if (!cur_db.ExecuteSQL(sql_str))
					{
						return return_value;
					}

				}

				return true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ReadPRAccounts)");
				return return_value;

			}

		}

		public static bool ReadGLAccounts(ref clsDatabase cur_db)
		{

			bool return_value = false;
			int return_flag = 0;
			string acct_code = "";
			string acct_name = "";
			string text_line = "";
			string sql_str = "";
			clsRecordset cur_set = null;
			int i = 0;
			string re_acct = "";
			string ce_acct = "";
			string fin_acct = "";
			string int_acct = "";
			clsFileIO io_stream = new clsFileIO();

			try
			{

				if (!io_stream.OpenFileToRead(cur_db.uDirectory.sHomeDirectory_nm + "\\default.txt"))
				{
					modDialogUtility.DisplayBox(ref cur_db, "default.txt" + cur_db.oLanguage.oMessage.IS_NOT_FOUND);
					return return_value;
				}

				cur_set = new clsRecordset(ref cur_db);

				while (!io_stream.EndOfFile())
				{

					text_line = "";
					acct_name = "";
					acct_code = "";

					text_line = io_stream.ReadOneLine();

					if (GlobalVar.goUtility.SInStr(text_line, "=") > 0)
					{
						acct_name = GlobalVar.goUtility.SLeft(text_line, GlobalVar.goUtility.SInStr(text_line, "=") - 1);
						acct_code = GlobalVar.goUtility.SRight(text_line, GlobalVar.goUtility.SLength(text_line) - GlobalVar.goUtility.SInStr(text_line, "="));
					}

					if (GlobalVar.goUtility.IsNonEmpty(acct_name) && GlobalVar.goUtility.IsNonEmpty(acct_code))
					{
						if (GlobalVar.goUtility.SUCase(acct_name) == "GL_REARNING")
						{
							re_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "GL_CEARNING")
						{
							ce_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_CHARGE")
						{
							fin_acct = acct_code;
						}
						else if (GlobalVar.goUtility.SUCase(acct_name) == "BR_INTEREST")
						{
							int_acct = acct_code;
						}
						else
						{
							//
						}
					}

				}

				io_stream.CloseFile();

				sql_str = "UPDATE tblGOMaster SET ";
				sql_str += " sDefaultEarningAcct_cd = '" + ce_acct + "'";
				sql_str += ",sREAccount_cd = '" + re_acct + "'";
				sql_str += ",sInterestAccount_cd = '" + int_acct + "'";
				sql_str += ",sFinancialChargeAccount_cd = '" + fin_acct + "'";
				if (!cur_db.ExecuteSQL(sql_str))
				{
					return return_value;
				}

				// This is needed in Advisor.
				//
				cur_db.sDefCEAccount_cd = ce_acct;
				cur_db.sDefREAccount_cd = re_acct;
				cur_db.sDefFinancialChargeAccount_cd = fin_acct;
				cur_db.sDefInterestAccount_cd = int_acct;

				return true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ReadGLAccounts)");
				return return_value;

			}

		}

		public static bool CheckSystemOptions(ref clsDatabase cur_db)
		{
			return CheckSystemOptions(ref cur_db, "");
		}

		public static bool CheckSystemOptions(ref clsDatabase cur_db, string calling_module)
		{

			bool return_value = false;
			string sql_str = "";
			string cur_year = "";
			clsRecordset cur_set = null;
			int period_begin = 0;
			int period_end = 0;
			int year_begin = 0;
			int year_end = 0;
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			try
			{

				cur_set = new clsRecordset(ref cur_db);

				sql_str = "SELECT * FROM tblGLPeriodDet";
				if (calling_module != cur_db.oLanguage.oString.STR_ADVISOR)
				{
					sql_str += " WHERE sFiscalYear = '" + Convert.ToString(GlobalVar.goUtility.GetYear(o_gen.CurrentDate())) + "'";
				}
				sql_str += " ORDER BY iPeriodBegin_dt";

				if (!cur_set.CreateSnapshot(sql_str))
				{
					return return_value;
				}
				else if (cur_set.EOF())
				{
					return true;
				}

				cur_year = cur_set.sField("sFiscalYear");
				year_begin = cur_set.iField("iPeriodBegin_dt");
				cur_set.MoveLast();
				year_end = cur_set.iField("iPeriodEnd_dt");
				cur_set.MoveFirst();

				while (!cur_set.EOF())
				{

					if (cur_set.iField("iPeriodBegin_dt") <= o_gen.CurrentDate() && cur_set.iField("iPeriodEnd_dt") >= o_gen.CurrentDate())
					{
						period_begin = cur_set.iField("iPeriodBegin_dt");
						period_end = cur_set.iField("iPeriodEnd_dt");
						break;
					}

					cur_set.MoveNext();
				}

				sql_str = "SELECT * FROM tblGOMaster";
				if (!cur_set.CreateSnapshot(sql_str))
				{
					return return_value;
				}
				else if (cur_set.EOF())
				{
					return true;
				}
				else if (GlobalVar.goUtility.IsNonEmpty(cur_set.sField("sCurrentFiscalYear")))
				{
					return true;
				}

				sql_str = "UPDATE tblGOMaster SET";
				sql_str += " sCurrentFiscalYear = '" + cur_year + "'";
				sql_str += ",sCurrentPayrollYear = '" + cur_year + "'";
				sql_str += ",iCurrentYearBegin_dt = " + year_begin;
				sql_str += ",iCurrentYearEnd_dt = " + year_end;
				sql_str += ",iCurrentPeriodBegin_dt = " + period_begin;
				sql_str += ",iCurrentPeriodEnd_dt = " + period_end;
				sql_str += ",iAPExist_fl = " + GlobalVar.goUtility.IIf(GlobalVar.goFile.FileExists(cur_db.uDirectory.sHomeDirectory_nm + "\\" + GlobalVar.goConstant.APMENU_NAME + ".EXE"), GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
				sql_str += ",iARExist_fl = " + GlobalVar.goUtility.IIf(GlobalVar.goFile.FileExists(cur_db.uDirectory.sHomeDirectory_nm + "\\" + GlobalVar.goConstant.ARMENU_NAME + ".EXE"), GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
				sql_str += ",iBRExist_fl = " + GlobalVar.goUtility.IIf(GlobalVar.goFile.FileExists(cur_db.uDirectory.sHomeDirectory_nm + "\\" + GlobalVar.goConstant.BRMENU_NAME + ".EXE"), GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
				sql_str += ",iGLExist_fl = " + GlobalVar.goUtility.IIf(GlobalVar.goFile.FileExists(cur_db.uDirectory.sHomeDirectory_nm + "\\" + GlobalVar.goConstant.GLMENU_NAME + ".EXE"), GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
				sql_str += ",iIVExist_fl = " + GlobalVar.goUtility.IIf(GlobalVar.goFile.FileExists(cur_db.uDirectory.sHomeDirectory_nm + "\\" + GlobalVar.goConstant.IVMENU_NAME + ".EXE"), GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
				sql_str += ",iJCExist_fl = " + GlobalVar.goUtility.IIf(GlobalVar.goFile.FileExists(cur_db.uDirectory.sHomeDirectory_nm + "\\" + GlobalVar.goConstant.JCMENU_NAME + ".EXE"), GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
				sql_str += ",iPOExist_fl = " + GlobalVar.goUtility.IIf(GlobalVar.goFile.FileExists(cur_db.uDirectory.sHomeDirectory_nm + "\\" + GlobalVar.goConstant.POMENU_NAME + ".EXE"), GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
				sql_str += ",iPRExist_fl = " + GlobalVar.goUtility.IIf(GlobalVar.goFile.FileExists(cur_db.uDirectory.sHomeDirectory_nm + "\\" + GlobalVar.goConstant.PRMENU_NAME + ".EXE"), GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
				sql_str += ",iSOExist_fl = " + GlobalVar.goUtility.IIf(GlobalVar.goFile.FileExists(cur_db.uDirectory.sHomeDirectory_nm + "\\" + GlobalVar.goConstant.SOMENU_NAME + ".EXE"), GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
				if (!cur_db.ExecuteSQL(sql_str))
				{
					return return_value;
				}

				cur_db.sCurFiscalYear = cur_year;
				cur_db.iCurYearBegin_dt = year_begin;
				cur_db.iCurYearEnd_dt = year_end;
				cur_db.iCurPeriodBegin_dt = period_begin;
				cur_db.iCurPeriodEnd_dt = period_end;

				cur_set.Release();
				return true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CheckSystemOptions)");
				return return_value;

			}

		}

		public static bool ChartOfAccountsIsAlreadyUsed(ref clsDatabase cur_db)
		{

			bool return_value = false;
			string sql_str = "";
			clsRecordset cur_set = null;

			try
			{

				cur_set = new clsRecordset(ref cur_db);

				return_value = true;

				sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblGLTransaction";

				if (!cur_set.CreateSnapshot(sql_str))
				{
					modDialogUtility.DisplayBox(ref cur_db, "Database connection has failed.");
					return return_value;
				}
				else if (cur_set.iField("iMaxNum") > 0)
				{
					cur_set.Release();
					return return_value;
				}

				sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblGLTransactionUnposted";

				if (!cur_set.CreateSnapshot(sql_str))
				{
					modDialogUtility.DisplayBox(ref cur_db, "Database connection has failed.");
					return return_value;
				}
				else if (cur_set.iField("iMaxNum") > 0)
				{
					cur_set.Release();
					return return_value;
				}

				return false;

				sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblIVAccounts";

				if (!cur_set.CreateSnapshot(sql_str))
				{
					modDialogUtility.DisplayBox(ref cur_db, "Database connection has failed.");
					return return_value;
				}
				else if (cur_set.iField("iMaxNum") > 0)
				{
					modDialogUtility.DisplayBox(ref cur_db, "You need to delete the inventory G/L posting accounts.");
					cur_set.Release();
					return return_value;
				}

				sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblAPAccounts";

				if (!cur_set.CreateSnapshot(sql_str))
				{
					modDialogUtility.DisplayBox(ref cur_db, "Database connection has failed.");
					return return_value;
				}
				else if (cur_set.iField("iMaxNum") > 0)
				{
					modDialogUtility.DisplayBox(ref cur_db, "You need to delete the payable G/L posting accounts.");
					cur_set.Release();
					return return_value;
				}

				sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblARAccounts";

				if (!cur_set.CreateSnapshot(sql_str))
				{
					modDialogUtility.DisplayBox(ref cur_db, "Database connection has failed.");
					return return_value;
				}
				else if (cur_set.iField("iMaxNum") > 0)
				{
					modDialogUtility.DisplayBox(ref cur_db, "You need to delete the receivable G/L posting accounts.");
					cur_set.Release();
					return return_value;
				}

				sql_str = "SELECT COUNT(*) AS iMaxNum FROM tblPRAccounts";

				if (!cur_set.CreateSnapshot(sql_str))
				{
					modDialogUtility.DisplayBox(ref cur_db, "Database connection has failed.");
					return return_value;
				}
				else if (cur_set.iField("iMaxNum") > 0)
				{
					modDialogUtility.DisplayBox(ref cur_db, "You need to delete the payroll G/L posting accounts.");
					cur_set.Release();
					return return_value;
				}

				cur_set.Release();
				return false;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "  (ChartOfAccountsIsAlreadyUsed)");
				return return_value;

			}

		}

		public static bool UpdateAccountLevel(ref clsDatabase cur_db, string parent_acct_code, int parent_acct_level)
		{

			bool return_value = false;
			clsRecordset cur_set = null;
			decimal tot_rec = 0M;
			int i = 0;
			clsGLAccount o_glacct = new clsGLAccount(ref cur_db);

			try
			{

				cur_set = new clsRecordset(ref cur_db);

				if (!cur_set.CreateSnapshot("SELECT sAccount_cd FROM tblGLAccount WHERE sParentAcct_cd = '" + parent_acct_code + "'"))
				{
					return return_value;
				}

				while (!cur_set.EOF())
				{

					if (!cur_db.ExecuteSQL("UPDATE tblGLAccount SET iAcctLevel = " + (parent_acct_level + 1).ToString() + " WHERE sAccount_cd = '" + cur_set.sField("sAccount_cd") + "'"))
					{
						return false;
					}
					else if (!UpdateAccountLevel(ref cur_db, cur_set.sField("sAccount_cd"), parent_acct_level + 1))
					{
						return false;
					}

					cur_set.MoveNext();

				}

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(UpdateAccountLevel)");

			}

			cur_set.Release();
			return return_value;

		}

        public static void SetCompanyName(clsDatabase cur_db, string new_company = "")
        {
			if (new_company != "")
			{
                cur_db.uCompany.sName = new_company;
            }

            GlobalVar.gsCompany_nm = cur_db.uCompany.sName;

            GlobalVar.gsCompany_nm = GlobalVar.goUtility.SReplace(GlobalVar.gsCompany_nm, "Incorporated", "Inc");               // Make them short
            GlobalVar.gsCompany_nm = GlobalVar.goUtility.SReplace(GlobalVar.gsCompany_nm, "Corporation", "Corp");

            if (GlobalVar.goUtility.SLength(GlobalVar.gsCompany_nm) > 18)
            {
                GlobalVar.gsCompany_nm = GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(GlobalVar.gsCompany_nm, 18, true));    // 18 is the max for display in Ucase
            }

        }
    }

}
