﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP
{
	internal static class modPostUtility
	{

		public static bool PostOneTransaction(ref clsDatabase cur_db, int batch_from, int batch_thru, int date_from, int date_thru, int trx_from, int trx_thru, int trx_type, string posting_msg, bool go_on_error, ref int mumber_failed, bool foreign_currency = false, string journal_code = "", bool exclude_memo_with_invoice_num_fl = false)
		{

			bool return_value = false;
			int trx_num = 0;
			int date_posted = 0;
			string comp_name = "";
			string error_msg = "";
			int tot_trx = 0;
			int cur_trx = 0;
			string sql_str = "";
			int cur_trx_num = 0;
			clsRecordset cur_set = null;
			string trx_set_str = "";
			string table_name = "";

			clsPostAP o_postAP = new clsPostAP(ref cur_db);
			clsPostAPMC o_postAPMC = new clsPostAPMC(ref cur_db);
			clsPostAR o_postAR = new clsPostAR(ref cur_db);
			clsPostARMC o_postARMC = new clsPostARMC(ref cur_db);
			clsPostIV o_postIV = new clsPostIV(ref cur_db);
			clsPostGL o_postGL = new clsPostGL(ref cur_db);
			clsPostPR o_postPR = new clsPostPR(ref cur_db);
			clsPostBR o_postBR = new clsPostBR(ref cur_db);

			try
			{

				cur_db.SetPostingError("");

				cur_set = new clsRecordset(ref cur_db);

				if (date_from > date_thru)
				{
					date_thru = date_from;
				}

				if (trx_thru <= 0)
				{
					trx_thru = 999999999;
				}
				else if (trx_from > trx_thru)
				{
					trx_thru = trx_from;
				}

				// According to the transaction type, select the table.
				//
				if (trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE || trx_type == GlobalVar.goConstant.TRX_DM_TYPE)
				{
					if (foreign_currency)
					{
						table_name = "tblAPMCChargeUnposted ";
					}
					else
					{
						table_name = "tblAPChargeUnposted ";
					}
				}
				else if (trx_type == GlobalVar.goConstant.TRX_PAYMENT_TYPE || trx_type == GlobalVar.goConstant.TRX_STOP_PAYMENT_TYPE)
				{
					if (foreign_currency)
					{
						table_name = "tblAPMCPaymentUnposted ";
					}
					else
					{
						table_name = "tblAPPaymentUnposted ";
					}
				}
				else if (trx_type == GlobalVar.goConstant.TRX_INVOICE_TYPE || trx_type == GlobalVar.goConstant.TRX_CM_TYPE)
				{
					if (foreign_currency)
					{
						table_name = "tblARMCChargeUnposted ";
					}
					else
					{
						table_name = "tblARChargeUnposted ";
					}
				}
				else if (trx_type == GlobalVar.goConstant.TRX_RECEIPT_TYPE || trx_type == GlobalVar.goConstant.TRX_NSF_TYPE)
				{
					if (foreign_currency)
					{
						table_name = "tblARMCPaymentUnposted ";
					}
					else
					{
						table_name = "tblARPaymentUnposted ";
					}
				}
				else if (trx_type == GlobalVar.goConstant.TRX_JOURNAL_TYPE)
				{
					table_name = "tblGLTransactionUnposted ";
				}
				else if (trx_type > 7000 && trx_type < 7200)
				{
					table_name = "tblBRTransactionUnposted ";
				}
				else if (trx_type == GlobalVar.goConstant.TRX_IV_PURCHASE_TYPE || trx_type == GlobalVar.goConstant.TRX_IV_PURCHASE_RETURN_TYPE || trx_type == GlobalVar.goConstant.TRX_IV_SALES_TYPE || trx_type == GlobalVar.goConstant.TRX_IV_SALES_RETURN_TYPE 
					|| trx_type == GlobalVar.goConstant.TRX_PHYSICAL_TYPE || trx_type == GlobalVar.goConstant.TRX_SPOILAGE_TYPE || trx_type == GlobalVar.goConstant.TRX_IV_INTERNAL_USE_TYPE || trx_type == GlobalVar.goConstant.TRX_TRANSFER_OUT_TYPE || trx_type == GlobalVar.goConstant.TRX_TRANSFER_IN_TYPE || trx_type == GlobalVar.goConstant.TRX_TRANSFER_TYPE)
				{
					table_name = "tblIVTransactionUnposted ";
				}
				else
				{
					return return_value;
				}

				trx_set_str = "SELECT iTransaction_num FROM " + table_name;

				modGeneralUtility.MouseHourGlass();

				sql_str = " WHERE (iStatus_typ <> " + GlobalVar.goConstant.HOLD_TRX_NUM.ToString() + ")";
				sql_str += " AND (iHoldStatus_typ = 0 OR iStatus_typ = " + GlobalVar.goConstant.VOID_TRX_NUM.ToString() + ")"; // 01/20/2019, Started implementing iHoldStatus_typ.

				if (trx_type == GlobalVar.goConstant.TRX_DM_TYPE || trx_type == GlobalVar.goConstant.TRX_CM_TYPE || trx_type == GlobalVar.goConstant.TRX_TRANSFER_TYPE || trx_type == GlobalVar.goConstant.TRX_TRANSFER_IN_TYPE || trx_type == GlobalVar.goConstant.TRX_TRANSFER_OUT_TYPE)
				{
					sql_str += " AND ((iHoldStatus_typ = 0 AND iCompleted_fl = 1) OR iStatus_typ = " + GlobalVar.goConstant.VOID_TRX_NUM.ToString() + ")";           // Select the ones fulfilled only
				}

				// In rental, credit memo referencing a unposted invoice can come.
				// If it is the case,it has to be posted after the invoices are posted, first
				//
				if (trx_type == GlobalVar.goConstant.TRX_CM_TYPE && exclude_memo_with_invoice_num_fl)
                {
					sql_str += " AND (iOrder_num = 0)";       
				}

				// When a batch is selected, only the batch needs to be selected.
				// 
				if (batch_from > 0 || batch_thru > 0)
				{

					if (batch_from > 0)
					{
						sql_str += " AND (iBatch_num >= " + batch_from + ")";
					}
					if (batch_thru > 0)
					{
						sql_str += " AND (iBatch_num <= " + batch_thru + ")";
					}

					// Only supervisor can give a batch range to post all within the range.
					// Need to make sure that the regular staff can post his/her own batch only.
					//
					if (cur_db.iUserType_id < clsConstant.USER_SUPERVISOR_TYPE && batch_from != batch_thru) // And cur_db.uSecurity.bBlockTransaction_fl Then
					{
						sql_str += " AND (sLastUpdate_id = '" + cur_db.sUser_cd + "')";
					}

				}
				else
				{

					// If batch is enabled, all batches need to be excluded.
					//
					if (cur_db.bEnableBatchEntry_fl)
					{
						// sql_str &= " AND (iBatch_num = 0)"  08/08/2019   When no batch is selected, ignore this option.  Post all transaction types selected.
					}

					if (trx_type != GlobalVar.goConstant.TRX_JOURNAL_TYPE)
					{
						sql_str += " AND (iTransaction_typ = " + trx_type + ")";
					}

					// DO NOT use iEntry_dt.
					//
					if (date_from == date_thru)
					{
						sql_str += " AND (iApply_dt = " + date_from + ")";
					}
					else
					{
						sql_str += " AND (iApply_dt BETWEEN " + date_from + " AND " + date_thru + ")";
					}

					if (trx_from > 0)
					{
						sql_str += " AND (iTransaction_num >= " + trx_from + ")";
					}
					if (trx_thru > 0)
					{
						sql_str += " AND (iTransaction_num <= " + trx_thru + ")";
					}

					if (trx_type == GlobalVar.goConstant.TRX_JOURNAL_TYPE && GlobalVar.goUtility.IsNonEmpty(journal_code))
					{
						sql_str += " AND (sJournal_cd = '" + journal_code + "')";
					}

					// Regular staff can post his own records only when the block option is on
					//
					if (cur_db.iUserType_id < clsConstant.USER_SUPERVISOR_TYPE && cur_db.uSecurity.bBlockTransaction_fl)
					{
						sql_str += " AND (sLastUpdate_id = '" + cur_db.sUser_cd + "')";
					}

				}

				// Sort by iTransaction_num to make sure are in the right order.  Otherwise
				// it may not match up with detail table.
				//
				if (!cur_set.CreateSnapshot(trx_set_str + sql_str + " ORDER BY iTransaction_num "))
				{
					return return_value;
				}
				else if (cur_set.EOF())
				{
					return true;
				}

				tot_trx = cur_set.RecordCount();
				cur_set.MoveFirst();
				cur_trx_num = cur_set.iField("iTransaction_num");
				cur_set.Release();
				cur_trx = 1;
				modGeneralUtility.RunEvents();

				// Post one transaction at a time.
				//
				while (cur_trx_num > 0)
				{

					// Use the company name plate as another progress display area.
					//
					modGeneralUtility.ShowStatus(posting_msg + " : " + cur_trx + " / " + tot_trx);

					// the posting routine according to the transaction type.
					//
					if (trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE)
					{
						if (foreign_currency)
						{
							o_postAPMC.PostMCVoucher(cur_trx_num);
						}
						else
						{
							o_postAP.PostVoucher(cur_trx_num);
						}
					}
					else if (trx_type == GlobalVar.goConstant.TRX_DM_TYPE)
					{
						if (foreign_currency)
						{
							o_postAPMC.PostMCDebitMemo(cur_trx_num);
						}
						else
						{
							o_postAP.PostDM(cur_trx_num);
						}
					}
					else if (trx_type == GlobalVar.goConstant.TRX_PAYMENT_TYPE)
					{
						if (foreign_currency)
						{
							o_postAPMC.PostMCPayment(cur_trx_num);
						}
						else
						{
							o_postAP.PostPayment(cur_trx_num);
						}
					}
					else if (trx_type == GlobalVar.goConstant.TRX_STOP_PAYMENT_TYPE)
					{
						if (foreign_currency)
						{
							o_postAPMC.PostMCStopPayment(cur_trx_num);
						}
						else
						{
							o_postAP.PostStopPayment(cur_trx_num);
						}
					}
					else if (trx_type == GlobalVar.goConstant.TRX_INVOICE_TYPE)
					{
						if (foreign_currency)
						{
							o_postARMC.PostMCInvoice(cur_trx_num);
						}
						else
						{
							o_postAR.PostInvoice(cur_trx_num);
						}
					}
					else if (trx_type == GlobalVar.goConstant.TRX_CM_TYPE)
					{
						if (foreign_currency)
						{
							o_postARMC.PostMCCreditMemo(cur_trx_num);
						}
						else
						{
							o_postAR.PostCM(cur_trx_num);
						}
					}
					else if (trx_type == GlobalVar.goConstant.TRX_RECEIPT_TYPE)
					{
						if (foreign_currency)
						{
							o_postARMC.PostMCReceipt(cur_trx_num);
						}
						else
						{
							o_postAR.PostReceipt(cur_trx_num);
						}
					}
					else if (trx_type == GlobalVar.goConstant.TRX_NSF_TYPE)
					{
						if (foreign_currency)
						{
							o_postARMC.PostMCNSF(cur_trx_num);
						}
						else
						{
							o_postAR.PostNSF(cur_trx_num);
						}
					}
					else if (trx_type == GlobalVar.goConstant.TRX_JOURNAL_TYPE)
					{
						o_postGL.PostJournal(cur_trx_num, 0, 0);
					}
					else if (trx_type == GlobalVar.goConstant.TRX_IV_PURCHASE_TYPE)
					{
						o_postIV.PostPurchase(cur_trx_num);
					}
					else if (trx_type == GlobalVar.goConstant.TRX_IV_PURCHASE_RETURN_TYPE)
					{
						o_postIV.PostPurchaseReturn(cur_trx_num);
					}
					else if (trx_type == GlobalVar.goConstant.TRX_IV_SALES_TYPE)
					{
						o_postIV.PostSales(cur_trx_num);
					}
					else if (trx_type == GlobalVar.goConstant.TRX_IV_SALES_RETURN_TYPE)
					{
						o_postIV.PostSalesReturn(cur_trx_num);
					}
					else if (trx_type == GlobalVar.goConstant.TRX_PHYSICAL_TYPE)
					{
						o_postIV.PostPhysical(cur_trx_num);
					}
					else if (trx_type == GlobalVar.goConstant.TRX_SPOILAGE_TYPE || trx_type == GlobalVar.goConstant.TRX_IV_INTERNAL_USE_TYPE)
					{
						o_postIV.PostSpoilage(trx_type, cur_trx_num);		// Hanldes both
					}
					else if (trx_type == GlobalVar.goConstant.TRX_TRANSFER_OUT_TYPE)
					{
						o_postIV.PostTransferOut(cur_trx_num);
					}
					else if (trx_type == GlobalVar.goConstant.TRX_TRANSFER_IN_TYPE)
					{
						o_postIV.PostTransferReceipt(cur_trx_num);
					}
					else if (trx_type == GlobalVar.goConstant.TRX_TRANSFER_TYPE)
					{
						o_postIV.PostTransferQuick(cur_trx_num);
					}
					else if (trx_type > 7000 && trx_type < 7200)
                    {
						o_postBR.PostTransaction(trx_type, cur_trx_num);

					}

					modGeneralUtility.RunEvents();

					// If there was a posting error, save in the log table.
					//
					if (cur_db.IsErrorFound())
					{
						mumber_failed = mumber_failed + 1;
						DisplayPostingError(ref cur_db, trx_type, cur_trx_num, cur_db.GetErrorMessage(), cur_db.fPostingTime);
						if (!go_on_error)
						{
							return return_value;
						}
					}

					modGeneralUtility.RunEvents();

					// Grab the next transaction to post.
					//
					trx_set_str = "SELECT MIN(iTransaction_num) AS iNext_num FROM " + table_name;
					if (!cur_set.CreateSnapshot(trx_set_str + sql_str + " AND iTransaction_num > " + cur_trx_num))
					{
						break;
					}
					else if (cur_set.EOF())
					{
						break;
					}

					cur_trx_num = cur_set.iField("iNext_num");

					cur_set.Release();

					cur_trx = cur_trx + 1;

					modGeneralUtility.RunEvents(); // Let the other Windows program run as well

				}

				cur_set.Release();
				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(PostOneTransaction)");

			}

			return return_value;

		}

		//  Display error message during the posting time.
		//  If this is realtime mode, display the message.
		//  Otherwise, save in the error log table.
		//
		public static void DisplayPostingError(ref clsDatabase cur_db, int trx_type, int trx_num, string err_text, decimal posting_time)
		{

			clsGeneral o_gen = new clsGeneral(ref cur_db);

			if (cur_db.bRealTimeMode)
			{
				modDialogUtility.DisplayBox(ref cur_db, err_text);
			}
			else if (!o_gen.UseSQLProcedures()) 
			{
				o_gen.SaveErrorLog(trx_type, trx_num, err_text, posting_time);
			}
			else if (!cur_db.IsErrorFound()) // This is because the error message has been consumed when this is called.
			{
				cur_db.SetPostingError(err_text);
			}

		}

	}

}
