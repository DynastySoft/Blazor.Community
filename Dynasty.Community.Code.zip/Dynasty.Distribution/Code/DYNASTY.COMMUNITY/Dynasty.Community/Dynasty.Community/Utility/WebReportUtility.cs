﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//

using System;
using System.IO;
using System.Threading.Tasks;

using Dynasty.Database;

namespace Dynasty.ASP
{
	internal static class modWebReportUtility
	{
		public static bool PDFFound(string pdf_file)											
        {
		 	DateTime stime_started = DateTime.Now;
			clsFile o_file = new clsFile();
			int max_seconds = 0;

			// wait until pdf_file shows up to 10 seconds.
			//
			max_seconds = 10;

			while (o_file.FileExists(pdf_file) == false)
			{
				if (Math.Abs((stime_started - DateTime.Now).TotalSeconds) > max_seconds)
				{
					return false;		// Some thing is wrong.  Report Server is not working
				}
			}

			return true;
		}

	}

}
