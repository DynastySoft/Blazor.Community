﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//

namespace Dynasty.ASP
{
	internal static class modPRVariable
	{

		public static string[,] gsTestTaxTable;

		public struct udtPayrollPayrollCaption
		{
			public string sFederal;
			public string sState;
			public string sLocal;
			public string sFICA;
			public string sFUTA;
			public string sSUI;
			public string sSDI;
			public string sSET;
			public string sMEDICARE;
			public string sOther;
		}

		public static udtPayrollPayrollCaption guPayrollCaption;

	}

}
