﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//
//


using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Local;
using Dynasty.Database;

namespace Dynasty.ASP
{
	public class modWebDashBoard
	{

		public const int DASHBOARD_CUSTOMER_TYPE_NUM = 101;
		public const int DASHBOARD_VENDOR_TYPE_NUM = 102;
		public const int DASHBOARD_BEST_SELLER_TYPE_NUM = 103;
		public const int DASHBOARD_BEST_PROFITOR_TYPE_NUM = 104;
		public const int DASHBOARD_RECEIVABLE_AGING_TYPE_NUM = 105;
		public const int DASHBOARD_PAYABLE_AGING_TYPE_NUM = 106;
		public const int DASHBOARD_RECEIVABLE_FORECAST_TYPE_NUM = 107;
		public const int DASHBOARD_PAYABLE_FORECAST_TYPE_NUM = 108;
		public const int DASHBOARD_PROSPECT_TYPE_NUM = 109;
		public const int DASHBOARD_APPROVAL_TO_MAKE_TYPE_NUM = 110;
		public const int DASHBOARD_APPROVAL_WAITING_TYPE_NUM = 111;

		public const int DASHBOARD_CODE_NUM = 1;
		public const int DASHBOARD_COL_2_NUM = 2;
		public const int DASHBOARD_COL_3_NUM = 3;
		public const int DASHBOARD_COL_4_NUM = 4;
		public const int DASHBOARD_COL_5_NUM = 5;
		public const int DASHBOARD_COL_6_NUM = 6;
		public const int DASHBOARD_COL_7_NUM = 7;
		public const int DASHBOARD_COL_8_NUM = 8;
		public const int DASHBOARD_COL_9_NUM = 9;
		public const int DASHBOARD_COL_10_NUM = 10;

		public const int DASHBOARD_DEPTH_NUM = 21;
		public const int DASHBOARD_TYPE_NUM = 22;

		public const int DASHBOARD_TOTAL_NUM = 23;

		private static clsInquiry moInquiry = new clsInquiry();

		private Models.clsDashBoard moDetail = new Models.clsDashBoard();

		public static void ClearDashboardGrid(ref Models.clsSpreadsheet cur_grid)
		{

			cur_grid.Clear();

		}

		public static void ResizeDashBoard(bool manual_fl = false)
		{

		}

		public static void EnlargeDashBoard()
		{

		}

		private static void ResizeSpreadsheet(int max_columns)
		{

			int col_num = 0;

			try
			{
				//GlobalVar.goUtility.ResizeDim(cur_grid.Data, Models.clsSpreadsheet.)
				//modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_TYPE_NUM);
				//modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_DEPTH_NUM);

				//for (col_num = DASHBOARD_CODE_NUM; col_num < max_columns; col_num++)
				//{
				//	modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, col_num, false);
				//}
				//for (col_num = max_columns; col_num < cur_grid.Columns.Count; col_num++)
				//{
				//	modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, col_num);
				//}

			}
			catch (Exception ex)
			{

			}

		}

        //public static int CustomersToContact(ref clsDatabase cur_db, int cur_date, bool get_count_only)
        //{

        //    int return_value = 0;
        //    ArrayList align_array = new ArrayList();
        //    string alignment_str = null;

        //    try
        //    {

        //        if (get_count_only == false)
        //        {
        //            ClearDashboardGrid(ref cur_grid);
        //            ResizeSpreadsheet(ref cur_grid, DASHBOARD_COL_7_NUM + 1);
        //            FieldName[DASHBOARD_DEPTH_NUM] = "Depth");
        //            FieldName[DASHBOARD_TYPE_NUM] = "Type");
        //            FieldName[DASHBOARD_CODE_NUM] = "Customer Code");
        //            FieldName[DASHBOARD_COL_2_NUM] = "Contact Time");
        //            FieldName[DASHBOARD_COL_3_NUM] = "Customer Name");
        //            FieldName[DASHBOARD_COL_4_NUM] = "Contact Name");
        //            FieldName[DASHBOARD_COL_5_NUM] = "Contact Phone");
        //            FieldName[DASHBOARD_COL_6_NUM] = "Email Address");
        //            FieldName[DASHBOARD_COL_7_NUM] = "Next Remark");
        //        }

        //        clsRecordset cur_set = new clsRecordset(ref cur_db);
        //        string sql_str = "SELECT * FROM tblARCustomer WHERE iNext_dt = " + cur_date.ToString() + " ORDER BY sNextTime";
        //        int row_num = 0;
        //        DataTable dt = new DataTable();
        //        DataRow dr = null;
        //        clsWebDropdownList web_ddl = new clsWebDropdownList(ref cur_db);

        //        if (cur_set.CreateSnapshot(sql_str) == false)
        //        {
        //            return_value = 0;
        //            return return_value;
        //        }
        //        else if (cur_set.RecordCount() == 0)
        //        {
        //            cur_set.Release();
        //            return_value = 0;
        //            return return_value;
        //        }
        //        else if (get_count_only)
        //        {
        //            return_value = cur_set.RecordCount();
        //            cur_set.Release();
        //            return return_value;
        //        }

        //        for (row_num = 1; row_num < cur_grid.Columns.Count; row_num++)
        //        {
        //            dt.Columns.Add(new DataColumn(modWebGridUtility.GetColumnId(row_num), typeof(string)));
        //        }

        //        while (cur_set.EOF() == false)
        //        {

        //            dr = dt.NewRow();

        //            Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
        //            Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_CUSTOMER_TYPE_NUM.ToString();
        //            Data[DASHBOARD_CODE_NUM, row_num] = cur_set.sField("sCustomer_cd");
        //            Data[DASHBOARD_COL_2_NUM, row_num] = cur_set.sField("sNextTime");
        //            Data[DASHBOARD_COL_3_NUM, row_num] = cur_set.sField("sCustomer_nm");
        //            Data[DASHBOARD_COL_4_NUM, row_num] = cur_set.sField("sContact_nm");
        //            Data[DASHBOARD_COL_5_NUM, row_num] = cur_set.sField("sContactPhone");
        //            Data[DASHBOARD_COL_6_NUM, row_num] = cur_set.sField("sEmailAddress");
        //            Data[DASHBOARD_COL_7_NUM, row_num] = cur_set.sField("sNextRemark");

        //            cur_set.MoveNext();
        //            dt.Rows.Add(dr);

        //        }

        //        align_array.Clear();
        //        align_array.Add(moInquiry.GetCssClassName("sCustomer_cd"));
        //        align_array.Add(moInquiry.GetCssClassName("sCustomer_cd"));
        //        align_array.Add(moInquiry.GetCssClassName("sCustomer_cd"));
        //        align_array.Add(moInquiry.GetCssClassName("sCustomer_cd"));
        //        align_array.Add(moInquiry.GetCssClassName("sNextTime"));
        //        align_array.Add(moInquiry.GetCssClassName("sCustomer_nm"));
        //        align_array.Add(moInquiry.GetCssClassName("sContact_nm"));
        //        align_array.Add(moInquiry.GetCssClassName("sContactPhone"));
        //        align_array.Add(moInquiry.GetCssClassName("sEmailAddress"));
        //        align_array.Add(moInquiry.GetCssClassName("sNextRemark"));
        //        align_array.Add(moInquiry.GetCssClassName("sCustomer_cd"));

        //        cur_grid.DataSource = dt;
        //        cur_grid.DataBind();
        //        modWebGridUtility.CopyDataTableToGridView(ref cur_db, ref cur_grid, ref dt, ref web_ddl, align_array); // We need to make sure that dt is bound to grdListing before this is called.

        //        return_value = cur_set.RecordCount();
        //        return return_value;

        //    }
        //    catch (Exception ex)
        //    {

        //        modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CustomersToContact)");
        //        return return_value;

        //    }

        //}

        //public static int ProspectsToContact(ref clsDatabase cur_db, int cur_date, bool get_count_only)
        //{

        //    int return_value = 0;
        //    ArrayList align_array = new ArrayList();
        //    string alignment_str = null;

        //    clsRecordset cur_set = new clsRecordset(ref cur_db);
        //    string sql_str = "SELECT * FROM tblARProspect p LEFT JOIN tblARProspectNextContactReason r ON p.iNextReason_id = r.iNextContactReason_id  WHERE iNext_dt = " + cur_date.ToString() + " ORDER BY sNextTime";
        //    int row_num = 0;
        //    DataTable dt = new DataTable();
        //    DataRow dr = null;
        //    clsWebDropdownList web_ddl = new clsWebDropdownList(ref cur_db);

        //    try
        //    {

        //        if (get_count_only == false)
        //        {
        //            ClearDashboardGrid(ref cur_grid);
        //            ResizeSpreadsheet(ref cur_grid, DASHBOARD_COL_7_NUM + 1);
        //            FieldName[DASHBOARD_DEPTH_NUM] = "Depth");
        //            FieldName[DASHBOARD_TYPE_NUM] = "Type");
        //            FieldName[DASHBOARD_CODE_NUM] = "Contact Phone");
        //            FieldName[DASHBOARD_COL_2_NUM] = "Contact Time");
        //            FieldName[DASHBOARD_COL_3_NUM] = "Contact Name");
        //            FieldName[DASHBOARD_COL_4_NUM] = "Contact Reason");
        //            FieldName[DASHBOARD_COL_5_NUM] = "Mobile Phone");
        //            FieldName[DASHBOARD_COL_6_NUM] = "Email Address");
        //            FieldName[DASHBOARD_COL_7_NUM] = "Next Remark");
        //        }

        //        if (cur_set.CreateSnapshot(sql_str) == false)
        //        {
        //            return_value = 0;
        //            return return_value;
        //        }
        //        else if (cur_set.RecordCount() == 0)
        //        {
        //            cur_set.Release();
        //            return_value = 0;
        //            return return_value;
        //        }
        //        else if (get_count_only)
        //        {
        //            return_value = cur_set.RecordCount();
        //            cur_set.Release();
        //            return return_value;
        //        }

        //        for (row_num = 1; row_num < cur_grid.Columns.Count; row_num++)
        //        {
        //            dt.Columns.Add(new DataColumn(modWebGridUtility.GetColumnId(row_num), typeof(string)));
        //        }

        //        while (cur_set.EOF() == false)
        //        {

        //            dr = dt.NewRow();

        //            Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
        //            Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_PROSPECT_TYPE_NUM.ToString();
        //            Data[DASHBOARD_CODE_NUM, row_num] = cur_set.sField("sProspect_cd");
        //            Data[DASHBOARD_COL_2_NUM, row_num] = cur_set.sField("sNextTime");
        //            Data[DASHBOARD_COL_3_NUM, row_num] = cur_set.sField("sProspect_nm");
        //            Data[DASHBOARD_COL_4_NUM, row_num] = cur_set.sField("sDescription");
        //            Data[DASHBOARD_COL_5_NUM, row_num] = cur_set.sField("sMobilePhone");
        //            Data[DASHBOARD_COL_6_NUM, row_num] = cur_set.sField("sEmailAddress");
        //            Data[DASHBOARD_COL_7_NUM, row_num] = cur_set.sField("sNextRemark");

        //            cur_set.MoveNext();
        //            dt.Rows.Add(dr);

        //        }

        //        align_array.Clear();
        //        align_array.Add(moInquiry.GetCssClassName("sProspect_cd"));
        //        align_array.Add(moInquiry.GetCssClassName("sProspect_cd"));
        //        align_array.Add(moInquiry.GetCssClassName("sProspect_cd"));
        //        align_array.Add(moInquiry.GetCssClassName("sProspect_cd"));
        //        align_array.Add(moInquiry.GetCssClassName("sNextTime"));
        //        align_array.Add(moInquiry.GetCssClassName("sProspect_nm"));
        //        align_array.Add(moInquiry.GetCssClassName("sDescription"));
        //        align_array.Add(moInquiry.GetCssClassName("sMobilePhone"));
        //        align_array.Add(moInquiry.GetCssClassName("sEmailAddress"));
        //        align_array.Add(moInquiry.GetCssClassName("sNextRemark"));

        //        cur_grid.DataSource = dt;
        //        cur_grid.DataBind();
        //        modWebGridUtility.CopyDataTableToGridView(ref cur_db, ref cur_grid, ref dt, ref web_ddl, align_array); // We need to make sure that dt is bound to grdListing before this is called.

        //        return_value = cur_set.RecordCount();
        //        return return_value;

        //    }
        //    catch (Exception ex)
        //    {

        //        modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProspectsToContact)");
        //        return return_value;

        //    }

        //}

        //public static int VendorsToContact(ref clsDatabase cur_db, int cur_date, bool get_count_only)
        //{

        //    int return_value = 0;
        //    ArrayList align_array = new ArrayList();
        //    string alignment_str = null;

        //    try
        //    {

        //        if (get_count_only == false)
        //        {
        //            ClearDashboardGrid(ref cur_grid);
        //            ResizeSpreadsheet(ref cur_grid, DASHBOARD_COL_7_NUM + 1);
        //            FieldName[DASHBOARD_DEPTH_NUM] = "Depth");
        //            FieldName[DASHBOARD_TYPE_NUM] = "Type");
        //            FieldName[DASHBOARD_CODE_NUM] = "Vendor Code");
        //            FieldName[DASHBOARD_COL_2_NUM] = "Contact Time");
        //            FieldName[DASHBOARD_COL_3_NUM] = "Vendor Name");
        //            FieldName[DASHBOARD_COL_4_NUM] = "Contact Name");
        //            FieldName[DASHBOARD_COL_5_NUM] = "Contact Phone");
        //            FieldName[DASHBOARD_COL_6_NUM] = "Email Address");
        //            FieldName[DASHBOARD_COL_7_NUM] = "Next Remark");
        //        }

        //        clsRecordset cur_set = new clsRecordset(ref cur_db);
        //        string sql_str = "SELECT * FROM tblAPVendor WHERE iNext_dt = " + cur_date.ToString() + " ORDER BY sNextTime";
        //        int row_num = 0;
        //        DataTable dt = new DataTable();
        //        DataRow dr = null;
        //        clsWebDropdownList web_ddl = new clsWebDropdownList(ref cur_db);

        //        if (cur_set.CreateSnapshot(sql_str) == false)
        //        {
        //            return_value = 0;
        //            return return_value;
        //        }
        //        else if (cur_set.RecordCount() == 0)
        //        {
        //            return_value = 0;
        //            cur_set.Release();
        //            return return_value;
        //        }
        //        else if (get_count_only)
        //        {
        //            return_value = cur_set.RecordCount();
        //            cur_set.Release();
        //            return return_value;
        //        }

        //        for (row_num = 1; row_num < cur_grid.Columns.Count; row_num++)
        //        {
        //            dt.Columns.Add(new DataColumn(modWebGridUtility.GetColumnId(row_num), typeof(string)));
        //        }

        //        while (cur_set.EOF() == false)
        //        {

        //            dr = dt.NewRow();

        //            Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
        //            Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_VENDOR_TYPE_NUM.ToString();
        //            Data[DASHBOARD_CODE_NUM, row_num] = cur_set.sField("sVendor_cd");
        //            Data[DASHBOARD_COL_2_NUM, row_num] = cur_set.sField("sNextTime");
        //            Data[DASHBOARD_COL_3_NUM, row_num] = cur_set.sField("sVendor_nm");
        //            Data[DASHBOARD_COL_4_NUM, row_num] = cur_set.sField("sContact_nm");
        //            Data[DASHBOARD_COL_5_NUM, row_num] = cur_set.sField("sContactPhone");
        //            Data[DASHBOARD_COL_6_NUM, row_num] = cur_set.sField("sEmailAddress");
        //            Data[DASHBOARD_COL_7_NUM, row_num] = cur_set.sField("sNextRemark");

        //            cur_set.MoveNext();
        //            dt.Rows.Add(dr);

        //        }

        //        align_array.Clear();
        //        align_array.Add(moInquiry.GetCssClassName("sVendor_cd"));
        //        align_array.Add(moInquiry.GetCssClassName("sVendor_cd"));
        //        align_array.Add(moInquiry.GetCssClassName("sVendor_cd"));
        //        align_array.Add(moInquiry.GetCssClassName("sVendor_cd"));
        //        align_array.Add(moInquiry.GetCssClassName("sNextTime"));
        //        align_array.Add(moInquiry.GetCssClassName("sVendor_nm"));
        //        align_array.Add(moInquiry.GetCssClassName("sContact_nm"));
        //        align_array.Add(moInquiry.GetCssClassName("sContactPhone"));
        //        align_array.Add(moInquiry.GetCssClassName("sEmailAddress"));
        //        align_array.Add(moInquiry.GetCssClassName("sNextRemark"));

        //        cur_grid.DataSource = dt;
        //        cur_grid.DataBind();
        //        modWebGridUtility.CopyDataTableToGridView(ref cur_db, ref cur_grid, ref dt, ref web_ddl, align_array); // We need to make sure that dt is bound to grdListing before this is called.

        //        return_value = cur_set.RecordCount();
        //        return return_value;

        //    }
        //    catch (Exception ex)
        //    {

        //        modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(VendorsToContact)");
        //        return return_value;

        //    }

        //}

        //public static int OrdersToShip(ref clsDatabase cur_db, int cur_date, bool get_count_only)
        //{

        //	int return_value = 0;
        //	clsGeneral o_gen = new clsGeneral(ref cur_db);
        //	clsRecordset cur_set = new clsRecordset(ref cur_db);
        //	string sql_str = null;
        //	int row_num = 0;
        //	DataTable dt = new DataTable();
        //	DataRow dr = null;
        //	clsWebDropdownList web_ddl = new clsWebDropdownList(ref cur_db);
        //	ArrayList align_array = new ArrayList();
        //	string alignment_str = null;

        //	try
        //	{

        //		if (get_count_only == false)
        //		{
        //			ClearDashboardGrid(ref cur_grid);
        //			ResizeSpreadsheet(ref cur_grid, DASHBOARD_COL_7_NUM + 1);
        //			FieldName[DASHBOARD_DEPTH_NUM] = "Depth");
        //			FieldName[DASHBOARD_TYPE_NUM] = "Type");
        //			FieldName[DASHBOARD_CODE_NUM] = "Order Number");
        //			FieldName[DASHBOARD_COL_2_NUM] = "Date Ordered");
        //			FieldName[DASHBOARD_COL_3_NUM] = "Date Required");
        //			FieldName[DASHBOARD_COL_4_NUM] = "Date Shipped");
        //			FieldName[DASHBOARD_COL_5_NUM] = "Customer Code");
        //			FieldName[DASHBOARD_COL_6_NUM] = "Customer Name");
        //			FieldName[DASHBOARD_COL_7_NUM] = "Comment");
        //		}

        //		sql_str = "SELECT * FROM tblSOTransaction WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_SO_TYPE.ToString();
        //		sql_str += " AND iStatus_typ = " + GlobalVar.goConstant.OPEN_TRX_NUM.ToString();
        //		sql_str += " AND ((iRequired_dt <= " + cur_date.ToString() + ") OR ((iShipped_dt > 0) AND (iShipped_dt<=" + cur_date.ToString() + ")))";
        //		sql_str += " AND iTransaction_num IN (SELECT iTransaction_num FROM tblSOTransactionDet";
        //		sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_SO_TYPE.ToString();
        //		sql_str += " AND fBackorder_qty > 0)";

        //		if (cur_set.CreateSnapshot(sql_str) == false)
        //		{
        //			return_value = 0;
        //			return return_value;
        //		}
        //		else if (cur_set.RecordCount() == 0)
        //		{
        //			cur_set.Release();
        //			return_value = 0;
        //			return return_value;
        //		}
        //		else if (get_count_only)
        //		{
        //			return_value = cur_set.RecordCount();
        //			cur_set.Release();
        //			return return_value;
        //		}

        //		for (row_num = 1; row_num < cur_grid.Columns.Count; row_num++)
        //		{
        //			dt.Columns.Add(new DataColumn(modWebGridUtility.GetColumnId(row_num), typeof(string)));
        //		}

        //		while (cur_set.EOF() == false)
        //		{

        //			dr = dt.NewRow();

        //			Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
        //			Data[DASHBOARD_TYPE_NUM, row_num] = GlobalVar.goConstant.TRX_SO_TYPE.ToString();
        //			Data[DASHBOARD_CODE_NUM, row_num] = cur_set.iField("iTransaction_num");
        //			Data[DASHBOARD_COL_2_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iApply_dt"));
        //			Data[DASHBOARD_COL_3_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iRequired_dt"));
        //			Data[DASHBOARD_COL_4_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iShipped_dt"));
        //			Data[DASHBOARD_COL_5_NUM, row_num] = cur_set.sField("sCustomer_cd");
        //			Data[DASHBOARD_COL_6_NUM, row_num] = cur_set.sField("sCustomer_nm");
        //			Data[DASHBOARD_COL_7_NUM, row_num] = cur_set.sField("sComment");

        //			cur_set.MoveNext();
        //			dt.Rows.Add(dr);

        //		}

        //		align_array.Clear();
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iApply_dt"));
        //		align_array.Add(moInquiry.GetCssClassName("iRequired_dt"));
        //		align_array.Add(moInquiry.GetCssClassName("iShipped_dt"));
        //		align_array.Add(moInquiry.GetCssClassName("sCustomer_cd"));
        //		align_array.Add(moInquiry.GetCssClassName("sCustomer_nm"));
        //		align_array.Add(moInquiry.GetCssClassName("sComment"));

        //		cur_grid.DataSource = dt;
        //		cur_grid.DataBind();
        //		modWebGridUtility.CopyDataTableToGridView(ref cur_db, ref cur_grid, ref dt, ref web_ddl, align_array); // We need to make sure that dt is bound to grdListing before this is called.

        //		return_value = cur_set.RecordCount();
        //		return return_value;

        //	}
        //	catch (Exception ex)
        //	{

        //		modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(OrdersToShip)");
        //		return return_value;

        //	}

        //}

        //public static int QuotesNotApproved(ref clsDatabase cur_db, int cur_date, bool get_count_only)
        //{

        //	int return_value = 0;
        //	clsGeneral o_gen = new clsGeneral(ref cur_db);
        //	clsRecordset cur_set = new clsRecordset(ref cur_db);
        //	string sql_str = null;
        //	int row_num = 0;
        //	DataTable dt = new DataTable();
        //	DataRow dr = null;
        //	clsWebDropdownList web_ddl = new clsWebDropdownList(ref cur_db);
        //	ArrayList align_array = new ArrayList();
        //	string alignment_str = null;
        //	clsMoney o_money = new clsMoney(ref cur_db);

        //	try
        //	{

        //		if (get_count_only == false)
        //		{
        //			ClearDashboardGrid(ref cur_grid);
        //			ResizeSpreadsheet(ref cur_grid, DASHBOARD_COL_7_NUM + 1);
        //			FieldName[DASHBOARD_DEPTH_NUM] = "Depth");
        //			FieldName[DASHBOARD_TYPE_NUM] = "Type");
        //			FieldName[DASHBOARD_CODE_NUM] = "Quote Number");
        //			FieldName[DASHBOARD_COL_2_NUM] = "Date Quoted");
        //			FieldName[DASHBOARD_COL_3_NUM] = "Date Required");
        //			FieldName[DASHBOARD_COL_4_NUM] = "Customer Code");
        //			FieldName[DASHBOARD_COL_5_NUM] = "Customer Name");
        //			FieldName[DASHBOARD_COL_6_NUM] = "Quote Amount");
        //			FieldName[DASHBOARD_COL_7_NUM] = "Comment");
        //		}

        //		sql_str = "SELECT * FROM tblSOTransaction WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_QUOTE_TYPE.ToString();
        //		sql_str += " AND iStatus_typ <= " + GlobalVar.goConstant.HOLD_TRX_NUM.ToString();

        //		if (cur_set.CreateSnapshot(sql_str) == false)
        //		{
        //			return_value = 0;
        //			return return_value;
        //		}
        //		else if (cur_set.RecordCount() == 0)
        //		{
        //			cur_set.Release();
        //			return_value = 0;
        //			return return_value;
        //		}
        //		else if (get_count_only)
        //		{
        //			return_value = cur_set.RecordCount();
        //			cur_set.Release();
        //			return return_value;
        //		}

        //		for (row_num = 1; row_num < cur_grid.Columns.Count; row_num++)
        //		{
        //			dt.Columns.Add(new DataColumn(modWebGridUtility.GetColumnId(row_num), typeof(string)));
        //		}

        //		while (cur_set.EOF() == false)
        //		{

        //			dr = dt.NewRow();

        //			Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
        //			Data[DASHBOARD_TYPE_NUM, row_num] = GlobalVar.goConstant.TRX_QUOTE_TYPE.ToString();
        //			Data[DASHBOARD_CODE_NUM, row_num] = cur_set.iField("iTransaction_num");
        //			Data[DASHBOARD_COL_2_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iEntry_dt"));
        //			Data[DASHBOARD_COL_3_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iRequired_dt"));
        //			Data[DASHBOARD_COL_4_NUM, row_num] = cur_set.sField("sCustomer_cd");
        //			Data[DASHBOARD_COL_5_NUM, row_num] = cur_set.sField("sCustomer_nm");
        //			Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mTotal_amt"));
        //			Data[DASHBOARD_COL_7_NUM, row_num] = cur_set.sField("sComment");

        //			cur_set.MoveNext();
        //			dt.Rows.Add(dr);

        //		}

        //		align_array.Clear();
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iEntry_dt"));
        //		align_array.Add(moInquiry.GetCssClassName("iRequired_dt"));
        //		align_array.Add(moInquiry.GetCssClassName("sCustomer_cd"));
        //		align_array.Add(moInquiry.GetCssClassName("sCustomer_nm"));
        //		align_array.Add(moInquiry.GetCssClassName("mTotal_amt"));
        //		align_array.Add(moInquiry.GetCssClassName("sComment"));

        //		cur_grid.DataSource = dt;
        //		cur_grid.DataBind();
        //		modWebGridUtility.CopyDataTableToGridView(ref cur_db, ref cur_grid, ref dt, ref web_ddl, align_array); // We need to make sure that dt is bound to grdListing before this is called.

        //		return_value = cur_set.RecordCount();
        //		return return_value;

        //	}
        //	catch (Exception ex)
        //	{

        //		modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(QuotesNotApproved)");
        //		return return_value;

        //	}

        //}

        //public static int BestSellers(ref clsDatabase cur_db, int cur_date)
        //{

        //	int return_value = 0;
        //	clsMoney o_money = new clsMoney(ref cur_db);
        //	clsRecordset cur_set = new clsRecordset(ref cur_db);
        //	string sql_str = null;
        //	int row_num = 0;
        //	DataTable dt = new DataTable();
        //	DataRow dr = null;
        //	clsWebDropdownList web_ddl = new clsWebDropdownList(ref cur_db);
        //	ArrayList align_array = new ArrayList();
        //	string alignment_str = null;

        //	try
        //	{

        //		ResizeSpreadsheet(ref cur_grid, DASHBOARD_COL_10_NUM + 1);
        //		ClearDashboardGrid(ref cur_grid);
        //		FieldName[DASHBOARD_DEPTH_NUM] = "Depth");
        //		FieldName[DASHBOARD_TYPE_NUM] = "Type");
        //		FieldName[DASHBOARD_CODE_NUM] = "Item Code");
        //		FieldName[DASHBOARD_COL_2_NUM] = "Item Description");
        //		modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_COL_3_NUM);
        //		FieldName[DASHBOARD_COL_3_NUM] = "Qtr");
        //		modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_COL_4_NUM);
        //		FieldName[DASHBOARD_COL_4_NUM] = "Period From");
        //		modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_COL_5_NUM);
        //		FieldName[DASHBOARD_COL_5_NUM] = "Period Thru");
        //		FieldName[DASHBOARD_COL_6_NUM] = "Amount Sold");
        //		FieldName[DASHBOARD_COL_7_NUM] = "Qty Sold");
        //		FieldName[DASHBOARD_COL_8_NUM] = "CGS");
        //		FieldName[DASHBOARD_COL_9_NUM] = "Profit");
        //		FieldName[DASHBOARD_COL_10_NUM] = "Margin(%)");

        //		sql_str = "SELECT b.sItem_cd AS sItemCode, i.sDescription AS sDesc, (mSales_amt - mSalesReturn_amt) AS mNetSold, (fSales_qty - fSalesReturn_qty) AS fNetQty";
        //		sql_str += ",mCGS_amt, (mSales_amt - mSalesReturn_amt - mCGS_amt) AS mProfit, sFiscalYear";
        //		sql_str += " FROM tblIVBalance b INNER JOIN tblIVItem i ON b.sItem_cd=i.sItem_cd";
        //		sql_str += " WHERE b.sFiscalYear = '" + GlobalVar.goUtility.GetYear(cur_date) + "'";
        //		sql_str += " AND i.sItem_cd=i.sPrimary_cd";
        //		sql_str += " AND iQuarter=0";
        //		sql_str += " AND sLocation_cd='" + GlobalVar.goConstant.FOR_ALL + "'";
        //		sql_str += " ORDER BY (mSales_amt - mSalesReturn_amt) DESC";

        //		if (cur_set.CreateSnapshot(sql_str) == false)
        //		{
        //			return_value = 0;
        //			return return_value;
        //		}
        //		else if (cur_set.RecordCount() == 0)
        //		{
        //			cur_set.Release();
        //			return_value = 0;
        //			return return_value;
        //		}

        //		for (row_num = 1; row_num < cur_grid.Columns.Count; row_num++)
        //		{
        //			dt.Columns.Add(new DataColumn(modWebGridUtility.GetColumnId(row_num), typeof(string)));
        //		}

        //		row_num = 0;
        //		while ((cur_set.EOF() == false) && (row_num < 10))
        //		{

        //			dr = dt.NewRow();

        //			Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
        //			Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_BEST_SELLER_TYPE_NUM.ToString();
        //			Data[DASHBOARD_CODE_NUM, row_num] = cur_set.sField("sItemCode");
        //			Data[DASHBOARD_COL_2_NUM, row_num] = cur_set.sField("sDesc");
        //			Data[DASHBOARD_COL_3_NUM, row_num] = "";
        //			Data[DASHBOARD_COL_4_NUM, row_num] = "";
        //			Data[DASHBOARD_COL_5_NUM, row_num] = "";
        //			Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mNetSold"));
        //			Data[DASHBOARD_COL_7_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("fNetQty"));
        //			Data[DASHBOARD_COL_8_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mCGS_amt"));
        //			Data[DASHBOARD_COL_9_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mProfit"));
        //			if (cur_set.mField("mNetSold") > 0)
        //			{
        //				Data[DASHBOARD_COL_10_NUM, row_num] = Math.Round(100 * cur_set.mField("mProfit") / cur_set.mField("mNetSold"), 2).ToString() + "%";
        //			}
        //			else
        //			{
        //				Data[DASHBOARD_COL_10_NUM, row_num] = "n/a";
        //			}

        //			cur_set.MoveNext();
        //			dt.Rows.Add(dr);
        //			row_num = 1;

        //		}

        //		align_array.Clear();
        //		align_array.Add(moInquiry.GetCssClassName("sItemCode"));
        //		align_array.Add(moInquiry.GetCssClassName("sItemCode"));
        //		align_array.Add(moInquiry.GetCssClassName("sItemCode"));
        //		align_array.Add(moInquiry.GetCssClassName("sItemCode"));
        //		align_array.Add(moInquiry.GetCssClassName("sDesc"));
        //		align_array.Add(moInquiry.GetCssClassName("sDesc"));
        //		align_array.Add(moInquiry.GetCssClassName("sDesc"));
        //		align_array.Add(moInquiry.GetCssClassName("sDesc"));
        //		align_array.Add(moInquiry.GetCssClassName("mNetSold"));
        //		align_array.Add(moInquiry.GetCssClassName("fNetQty"));
        //		align_array.Add(moInquiry.GetCssClassName("mCGS_amt"));
        //		align_array.Add(moInquiry.GetCssClassName("mProfit"));
        //		align_array.Add(moInquiry.GetCssClassName("mNetSold"));

        //		cur_grid.DataSource = dt;
        //		cur_grid.DataBind();
        //		modWebGridUtility.CopyDataTableToGridView(ref cur_db, ref cur_grid, ref dt, ref web_ddl, align_array); // We need to make sure that dt is bound to grdListing before this is called.

        //		return_value = cur_set.RecordCount();
        //		return return_value;

        //	}
        //	catch (Exception ex)
        //	{

        //		modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(BestSellers)");
        //		return return_value;

        //	}

        //}

        //public static int BestProfitors(ref clsDatabase cur_db, int cur_date)
        //{

        //	int return_value = 0;
        //	clsMoney o_money = new clsMoney(ref cur_db);
        //	clsRecordset cur_set = new clsRecordset(ref cur_db);
        //	string sql_str = null;
        //	int row_num = 0;
        //	DataTable dt = new DataTable();
        //	DataRow dr = null;
        //	clsWebDropdownList web_ddl = new clsWebDropdownList(ref cur_db);
        //	ArrayList align_array = new ArrayList();
        //	string alignment_str = null;

        //	try
        //	{

        //		ResizeSpreadsheet(ref cur_grid, DASHBOARD_COL_10_NUM + 1);
        //		ClearDashboardGrid(ref cur_grid);
        //		FieldName[DASHBOARD_DEPTH_NUM] = "Depth");
        //		FieldName[DASHBOARD_TYPE_NUM] = "Type");
        //		FieldName[DASHBOARD_CODE_NUM] = "Item Code");
        //		FieldName[DASHBOARD_COL_2_NUM] = "Item Description");
        //		modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_COL_3_NUM);
        //		FieldName[DASHBOARD_COL_3_NUM] = "Qtr");
        //		modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_COL_4_NUM);
        //		FieldName[DASHBOARD_COL_4_NUM] = "Period From");
        //		modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_COL_5_NUM);
        //		FieldName[DASHBOARD_COL_5_NUM] = "Period Thru");
        //		FieldName[DASHBOARD_COL_6_NUM] = "Profit");
        //		FieldName[DASHBOARD_COL_7_NUM] = "Amount Sold");
        //		FieldName[DASHBOARD_COL_8_NUM] = "Qty Sold");
        //		FieldName[DASHBOARD_COL_9_NUM] = "CGS");
        //		FieldName[DASHBOARD_COL_10_NUM] = "Margin(%)");

        //		sql_str = "SELECT b.sItem_cd AS sItemCode, i.sDescription AS sDesc, (mSales_amt - mSalesReturn_amt) AS mNetSold, (fSales_qty - fSalesReturn_qty) AS fNetQty";
        //		sql_str += ",mCGS_amt, (mSales_amt - mSalesReturn_amt - mCGS_amt) AS mProfit, sFiscalYear";
        //		sql_str += " FROM tblIVBalance b INNER JOIN tblIVItem i ON b.sItem_cd=i.sItem_cd";
        //		sql_str += " WHERE b.sFiscalYear = '" + GlobalVar.goUtility.GetYear(cur_date) + "'";
        //		sql_str += " AND i.sItem_cd=i.sPrimary_cd";
        //		sql_str += " AND iQuarter=0";
        //		sql_str += " AND sLocation_cd='" + GlobalVar.goConstant.FOR_ALL + "'";
        //		sql_str += " ORDER BY (mSales_amt - mSalesReturn_amt - mCGS_amt) DESC";

        //		if (cur_set.CreateSnapshot(sql_str) == false)
        //		{
        //			return_value = 0;
        //			return return_value;
        //		}
        //		else if (cur_set.RecordCount() == 0)
        //		{
        //			cur_set.Release();
        //			return_value = 0;
        //			return return_value;
        //		}

        //		for (row_num = 1; row_num < cur_grid.Columns.Count; row_num++)
        //		{
        //			dt.Columns.Add(new DataColumn(modWebGridUtility.GetColumnId(row_num), typeof(string)));
        //		}

        //		row_num = 0;
        //		while ((cur_set.EOF() == false) && (row_num < 10))
        //		{

        //			dr = dt.NewRow();

        //			Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
        //			Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_BEST_PROFITOR_TYPE_NUM.ToString();
        //			Data[DASHBOARD_CODE_NUM, row_num] = cur_set.sField("sItemCode");
        //			Data[DASHBOARD_COL_2_NUM, row_num] = cur_set.sField("sDesc");
        //			Data[DASHBOARD_COL_3_NUM, row_num] = "";
        //			Data[DASHBOARD_COL_4_NUM, row_num] = "";
        //			Data[DASHBOARD_COL_5_NUM, row_num] = "";
        //			Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mProfit"));
        //			Data[DASHBOARD_COL_7_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mNetSold"));
        //			Data[DASHBOARD_COL_8_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("fNetQty"));
        //			Data[DASHBOARD_COL_9_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mCGS_amt"));
        //			if (cur_set.mField("mNetSold") > 0)
        //			{
        //				Data[DASHBOARD_COL_10_NUM, row_num] = Math.Round(100 * cur_set.mField("mProfit") / cur_set.mField("mNetSold"), 2).ToString() + "%";
        //			}
        //			else
        //			{
        //				Data[DASHBOARD_COL_10_NUM, row_num] = "n/a";
        //			}

        //			cur_set.MoveNext();
        //			dt.Rows.Add(dr);
        //			row_num += 1;

        //		}

        //		align_array.Clear();
        //		align_array.Add(moInquiry.GetCssClassName("sItemCode"));
        //		align_array.Add(moInquiry.GetCssClassName("sItemCode"));
        //		align_array.Add(moInquiry.GetCssClassName("sItemCode"));
        //		align_array.Add(moInquiry.GetCssClassName("sItemCode"));
        //		align_array.Add(moInquiry.GetCssClassName("sDesc"));
        //		align_array.Add(moInquiry.GetCssClassName("sDesc"));
        //		align_array.Add(moInquiry.GetCssClassName("sDesc"));
        //		align_array.Add(moInquiry.GetCssClassName("sDesc"));
        //		align_array.Add(moInquiry.GetCssClassName("mProfit"));
        //		align_array.Add(moInquiry.GetCssClassName("mNetSold"));
        //		align_array.Add(moInquiry.GetCssClassName("fNetQty"));
        //		align_array.Add(moInquiry.GetCssClassName("mCGS_amt"));
        //		align_array.Add(moInquiry.GetCssClassName("mNetSold"));

        //		cur_grid.DataSource = dt;
        //		cur_grid.DataBind();
        //		modWebGridUtility.CopyDataTableToGridView(ref cur_db, ref cur_grid, ref dt, ref web_ddl, align_array); // We need to make sure that dt is bound to grdListing before this is called.

        //		return_value = cur_set.RecordCount();
        //		return return_value;

        //	}
        //	catch (Exception ex)
        //	{

        //		modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(BestProfitors)");
        //		return return_value;

        //	}

        //}

        //public static int PayableForecast(ref clsDatabase cur_db, int cur_date, bool show_details = false)
        //{

        //	int return_value = 0;
        //	decimal totaldue_amt = 0M;
        //	decimal in30_amt = 0M;
        //	decimal in60_amt = 0M;
        //	decimal in90_amt = 0M;
        //	decimal in120_amt = 0M;
        //	decimal over120_amt = 0M;
        //	clsGeneral o_gen = new clsGeneral(ref cur_db);
        //	clsMoney o_money = new clsMoney(ref cur_db);
        //	clsRecordset cur_set = new clsRecordset(ref cur_db);
        //	string sql_str = null;
        //	int row_num = 0;
        //	DataTable dt = new DataTable();
        //	DataRow dr = null;
        //	clsWebDropdownList web_ddl = new clsWebDropdownList(ref cur_db);
        //	ArrayList align_array = new ArrayList();
        //	string alignment_str = null;

        //	try
        //	{

        //		ClearDashboardGrid(ref cur_grid);
        //		ResizeSpreadsheet(ref cur_grid, DASHBOARD_COL_10_NUM + 1);
        //		FieldName[DASHBOARD_DEPTH_NUM] = "Depth");
        //		FieldName[DASHBOARD_TYPE_NUM] = "Type");
        //		FieldName[DASHBOARD_CODE_NUM] = "Voucher Number");
        //		modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_CODE_NUM, (!show_details));
        //		FieldName[DASHBOARD_COL_2_NUM] = "Invoice Number");
        //		modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_COL_2_NUM, (!show_details));
        //		FieldName[DASHBOARD_COL_3_NUM] = "Date Invoiced");
        //		modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_COL_3_NUM, (!show_details));
        //		FieldName[DASHBOARD_COL_4_NUM] = "Date Due");
        //		modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_COL_4_NUM, (!show_details));
        //		FieldName[DASHBOARD_COL_5_NUM] = "Total Due");
        //		FieldName[DASHBOARD_COL_6_NUM] = "Due In 30 Days");
        //		FieldName[DASHBOARD_COL_7_NUM] = "Due In 60 Days");
        //		FieldName[DASHBOARD_COL_8_NUM] = "Due In 90 Days");
        //		FieldName[DASHBOARD_COL_9_NUM] = "Due In 120 Days");
        //		FieldName[DASHBOARD_COL_10_NUM] = "Over 120");

        //		sql_str = "SELECT * FROM tblAPCharge WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_PURCHASE_TYPE.ToString();
        //		sql_str += " AND iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM.ToString();
        //		sql_str += " AND mDue_amt <> 0 "; // 06/19/2018 Negative voucher is implemented
        //		sql_str += " AND iDue_dt > " + cur_date.ToString();
        //		sql_str += " ORDER BY iDue_dt";

        //		if (cur_set.CreateSnapshot(sql_str) == false)
        //		{
        //			return_value = 0;
        //			return return_value;
        //		}
        //		else if (cur_set.RecordCount() == 0)
        //		{
        //			cur_set.Release();
        //			return_value = 0;
        //			return return_value;
        //		}

        //		for (row_num = 1; row_num < cur_grid.Columns.Count; row_num++)
        //		{
        //			dt.Columns.Add(new DataColumn(modWebGridUtility.GetColumnId(row_num), typeof(string)));
        //		}

        //		while (cur_set.EOF() == false)
        //		{

        //			totaldue_amt = totaldue_amt + cur_set.mField("mDue_amt");

        //			if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, 30))
        //			{
        //				in30_amt = in30_amt + cur_set.mField("mDue_amt");
        //			}
        //			else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, 60))
        //			{
        //				in60_amt = in60_amt + cur_set.mField("mDue_amt");
        //			}
        //			else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, 90))
        //			{
        //				in90_amt = in90_amt + cur_set.mField("mDue_amt");
        //			}
        //			else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, 120))
        //			{
        //				in120_amt = in120_amt + cur_set.mField("mDue_amt");
        //			}
        //			else
        //			{
        //				over120_amt = over120_amt + cur_set.mField("mDue_amt");
        //			}

        //			cur_set.MoveNext();

        //		}

        //		dr = dt.NewRow();

        //		Data[DASHBOARD_DEPTH_NUM, row_num] = "0";
        //		Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_PAYABLE_FORECAST_TYPE_NUM.ToString();
        //		Data[DASHBOARD_CODE_NUM, row_num] = "";
        //		Data[DASHBOARD_COL_2_NUM, row_num] = "";
        //		Data[DASHBOARD_COL_3_NUM, row_num] = "";
        //		Data[DASHBOARD_COL_4_NUM, row_num] = "";
        //		Data[DASHBOARD_COL_5_NUM, row_num] = o_money.ToStrMoney(totaldue_amt);
        //		Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(in30_amt);
        //		Data[DASHBOARD_COL_7_NUM, row_num] = o_money.ToStrMoney(in60_amt);
        //		Data[DASHBOARD_COL_8_NUM, row_num] = o_money.ToStrMoney(in90_amt);
        //		Data[DASHBOARD_COL_9_NUM, row_num] = o_money.ToStrMoney(in120_amt);
        //		Data[DASHBOARD_COL_10_NUM, row_num] = o_money.ToStrMoney(over120_amt);

        //		dt.Rows.Add(dr);

        //		if (show_details)
        //		{

        //			cur_set.MoveFirst();
        //			while (cur_set.EOF() == false)
        //			{

        //				dr = dt.NewRow();

        //				Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_PAYABLE_FORECAST_TYPE_NUM.ToString();
        //				Data[DASHBOARD_CODE_NUM, row_num] = cur_set.iField("iTransaction_num");
        //				Data[DASHBOARD_COL_2_NUM, row_num] = cur_set.sField("sYourReference");
        //				Data[DASHBOARD_COL_3_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iInvoice_dt"));
        //				Data[DASHBOARD_COL_4_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iDue_dt"));
        //				if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, 30))
        //				{
        //					Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //				}
        //				else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, 60))
        //				{
        //					Data[DASHBOARD_COL_7_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //				}
        //				else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, 90))
        //				{
        //					Data[DASHBOARD_COL_8_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //				}
        //				else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, 120))
        //				{
        //					Data[DASHBOARD_COL_9_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //				}
        //				else
        //				{
        //					Data[DASHBOARD_COL_10_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //				}


        //				cur_set.MoveNext();
        //				dt.Rows.Add(dr);

        //			}

        //		}

        //		align_array.Clear();
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("sYourReference"));
        //		align_array.Add(moInquiry.GetCssClassName("iInvoice_dt"));
        //		align_array.Add(moInquiry.GetCssClassName("iDue_dt"));
        //		align_array.Add(moInquiry.GetCssClassName("iDue_dt"));
        //		align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //		align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //		align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //		align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //		align_array.Add(moInquiry.GetCssClassName("mDue_amt"));

        //		cur_grid.DataSource = dt;
        //		cur_grid.DataBind();
        //		modWebGridUtility.CopyDataTableToGridView(ref cur_db, ref cur_grid, ref dt, ref web_ddl, align_array); // We need to make sure that dt is bound to grdListing before this is called.

        //		return_value = cur_set.RecordCount();
        //		return return_value;

        //	}
        //	catch (Exception ex)
        //	{

        //		modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(PayableForecast)");
        //		return return_value;

        //	}

        //}

        //public static int PayableAging(ref clsDatabase cur_db, int cur_date, bool show_details = false)
        //{

        //	int return_value = 0;
        //	decimal pastdue_amt = 0M;
        //	decimal in30_amt = 0M;
        //	decimal in60_amt = 0M;
        //	decimal in90_amt = 0M;
        //	decimal in120_amt = 0M;
        //	decimal over120_amt = 0M;

        //	clsGeneral o_gen = new clsGeneral(ref cur_db);
        //	clsMoney o_money = new clsMoney(ref cur_db);
        //	clsRecordset cur_set = new clsRecordset(ref cur_db);
        //	string sql_str = null;
        //	int row_num = 0;
        //	DataTable dt = new DataTable();
        //	DataRow dr = null;
        //	clsWebDropdownList web_ddl = new clsWebDropdownList(ref cur_db);
        //	ArrayList align_array = new ArrayList();
        //	string alignment_str = null;

        //	try
        //	{

        //		ClearDashboardGrid(ref cur_grid);
        //		ResizeSpreadsheet(ref cur_grid, DASHBOARD_COL_10_NUM + 1);
        //		FieldName[DASHBOARD_DEPTH_NUM] = "Depth");
        //		FieldName[DASHBOARD_TYPE_NUM] = "Type");
        //		FieldName[DASHBOARD_CODE_NUM] = "Voucher Number");
        //		modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_CODE_NUM, (!show_details));
        //		FieldName[DASHBOARD_COL_2_NUM] = "Invoice Number");
        //		modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_COL_2_NUM, (!show_details));
        //		FieldName[DASHBOARD_COL_3_NUM] = "Date Invoiced");
        //		modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_COL_3_NUM, (!show_details));
        //		FieldName[DASHBOARD_COL_4_NUM] = "Date Due");
        //		modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_COL_4_NUM, (!show_details));
        //		FieldName[DASHBOARD_COL_5_NUM] = "Total Past Due");
        //		FieldName[DASHBOARD_COL_6_NUM] = "Last 30 Days");
        //		FieldName[DASHBOARD_COL_7_NUM] = "Last 60 Days");
        //		FieldName[DASHBOARD_COL_8_NUM] = "Last 90 Days");
        //		FieldName[DASHBOARD_COL_9_NUM] = "Last 120 Days");
        //		FieldName[DASHBOARD_COL_10_NUM] = "Over 120");

        //		sql_str = "SELECT * FROM tblAPCharge WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_PURCHASE_TYPE.ToString();
        //		sql_str += " AND iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM.ToString();
        //		sql_str += " AND mDue_amt <> 0 "; // 06/19/2018 Negative voucher is implemented
        //		sql_str += " AND iDue_dt <= " + cur_date.ToString();
        //		sql_str += " ORDER BY iDue_dt";

        //		if (cur_set.CreateSnapshot(sql_str) == false)
        //		{
        //			return_value = 0;
        //			return return_value;
        //		}
        //		else if (cur_set.RecordCount() == 0)
        //		{
        //			cur_set.Release();
        //			return_value = 0;
        //			return return_value;
        //		}

        //		while (cur_set.EOF() == false)
        //		{

        //			if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -120))
        //			{
        //				over120_amt = over120_amt + cur_set.mField("mDue_amt");
        //			}
        //			else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -90))
        //			{
        //				in120_amt = in120_amt + cur_set.mField("mDue_amt");
        //			}
        //			else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -60))
        //			{
        //				in90_amt = in90_amt + cur_set.mField("mDue_amt");
        //			}
        //			else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -30))
        //			{
        //				in60_amt = in60_amt + cur_set.mField("mDue_amt");
        //			}
        //			else // If cur_set.iField("iDue_dt") <= cur_date Then
        //			{
        //				in30_amt = in30_amt + cur_set.mField("mDue_amt");
        //			}

        //			pastdue_amt = pastdue_amt + cur_set.mField("mDue_amt");
        //			cur_set.MoveNext();

        //		}

        //		for (row_num = 1; row_num < cur_grid.Columns.Count; row_num++)
        //		{
        //			dt.Columns.Add(new DataColumn(modWebGridUtility.GetColumnId(row_num), typeof(string)));
        //		}

        //		dr = dt.NewRow();

        //		Data[DASHBOARD_DEPTH_NUM, row_num] = "0";
        //		Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_PAYABLE_AGING_TYPE_NUM.ToString();
        //		Data[DASHBOARD_CODE_NUM, row_num] = "";
        //		Data[DASHBOARD_COL_2_NUM, row_num] = "";
        //		Data[DASHBOARD_COL_3_NUM, row_num] = "";
        //		Data[DASHBOARD_COL_4_NUM, row_num] = "";
        //		Data[DASHBOARD_COL_5_NUM, row_num] = o_money.ToStrMoney(pastdue_amt);
        //		Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(in30_amt);
        //		Data[DASHBOARD_COL_7_NUM, row_num] = o_money.ToStrMoney(in60_amt);
        //		Data[DASHBOARD_COL_8_NUM, row_num] = o_money.ToStrMoney(in90_amt);
        //		Data[DASHBOARD_COL_9_NUM, row_num] = o_money.ToStrMoney(in120_amt);
        //		Data[DASHBOARD_COL_10_NUM, row_num] = o_money.ToStrMoney(over120_amt);

        //		dt.Rows.Add(dr);

        //		if (show_details)
        //		{

        //			cur_set.MoveFirst();
        //			while (cur_set.EOF() == false)
        //			{

        //				dr = dt.NewRow();

        //				Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_PAYABLE_AGING_TYPE_NUM.ToString();
        //				Data[DASHBOARD_CODE_NUM, row_num] = cur_set.iField("iTransaction_num");
        //				Data[DASHBOARD_COL_2_NUM, row_num] = cur_set.sField("sYourReference");
        //				Data[DASHBOARD_COL_3_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iInvoice_dt"));
        //				Data[DASHBOARD_COL_4_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iDue_dt"));

        //				if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -120))
        //				{
        //					Data[DASHBOARD_COL_10_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //				}
        //				else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -90))
        //				{
        //					Data[DASHBOARD_COL_9_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //				}
        //				else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -60))
        //				{
        //					Data[DASHBOARD_COL_8_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //				}
        //				else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -30))
        //				{
        //					Data[DASHBOARD_COL_7_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //				}
        //				else // If cur_set.iField("iDue_dt") <= cur_date Then
        //				{
        //					Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //				}

        //				cur_set.MoveNext();
        //				dt.Rows.Add(dr);

        //			}
        //		}

        //		align_array.Clear();
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("sYourReference"));
        //		align_array.Add(moInquiry.GetCssClassName("iInvoice_dt"));
        //		align_array.Add(moInquiry.GetCssClassName("iDue_dt"));
        //		align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //		align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //		align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //		align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //		align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //		align_array.Add(moInquiry.GetCssClassName("mDue_amt"));

        //		cur_grid.DataSource = dt;
        //		cur_grid.DataBind();
        //		modWebGridUtility.CopyDataTableToGridView(ref cur_db, ref cur_grid, ref dt, ref web_ddl, align_array); // We need to make sure that dt is bound to grdListing before this is called.

        //		return_value = cur_set.RecordCount();
        //		return return_value;

        //	}
        //	catch (Exception ex)
        //	{

        //		modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(PayableAging)");
        //		return return_value;

        //	}

        //}

        //public static int ReceivableForecast(ref clsDatabase cur_db, int cur_date, bool show_detail = false)
        //{

        //    int return_value = 0;
        //    decimal totaldue_amt = 0M;
        //    decimal in30_amt = 0M;
        //    decimal in60_amt = 0M;
        //    decimal in90_amt = 0M;
        //    decimal in120_amt = 0M;
        //    decimal over120_amt = 0M;
        //    clsGeneral o_gen = new clsGeneral(ref cur_db);
        //    clsMoney o_money = new clsMoney(ref cur_db);
        //    clsRecordset cur_set = new clsRecordset(ref cur_db);
        //    string sql_str = null;
        //    int row_num = 0;
        //    DataTable dt = new DataTable();
        //    DataRow dr = null;
        //    clsWebDropdownList web_ddl = new clsWebDropdownList(ref cur_db);
        //    ArrayList align_array = new ArrayList();
        //    string alignment_str = null;

        //    try
        //    {

        //        ClearDashboardGrid(ref cur_grid);
        //        ResizeSpreadsheet(ref cur_grid, DASHBOARD_COL_9_NUM + 1);
        //        FieldName[DASHBOARD_DEPTH_NUM] = "Depth");
        //        FieldName[DASHBOARD_TYPE_NUM] = "Type");
        //        FieldName[DASHBOARD_CODE_NUM] = "Invoice Number");
        //        modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_CODE_NUM, (!show_detail));
        //        FieldName[DASHBOARD_COL_2_NUM] = "Date Applied");
        //        modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_COL_2_NUM, (!show_detail));
        //        FieldName[DASHBOARD_COL_3_NUM] = "Date Due");
        //        modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_COL_3_NUM, (!show_detail));
        //        FieldName[DASHBOARD_COL_4_NUM] = "Total Due");
        //        FieldName[DASHBOARD_COL_5_NUM] = "Due In 30 Days");
        //        FieldName[DASHBOARD_COL_6_NUM] = "Due In 60 Days");
        //        FieldName[DASHBOARD_COL_7_NUM] = "Due In 90 Days");
        //        FieldName[DASHBOARD_COL_8_NUM] = "Due In 120 Days");
        //        FieldName[DASHBOARD_COL_9_NUM] = "Over 120");

        //        sql_str = "SELECT * FROM tblARCharge WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_INVOICE_TYPE.ToString();
        //        sql_str += " AND iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM.ToString();
        //        sql_str += " AND mDue_amt <> 0"; // 06/19/2018 Negative voucher is implemented
        //        sql_str += " AND iDue_dt > " + cur_date.ToString();
        //        sql_str += " ORDER BY iDue_dt";

        //        if (cur_set.CreateSnapshot(sql_str) == false)
        //        {
        //            return_value = 0;
        //            return return_value;
        //        }
        //        else if (cur_set.RecordCount() == 0)
        //        {
        //            cur_set.Release();
        //            return_value = 0;
        //            return return_value;
        //        }

        //        for (row_num = 1; row_num < cur_grid.Columns.Count; row_num++)
        //        {
        //            dt.Columns.Add(new DataColumn(modWebGridUtility.GetColumnId(row_num), typeof(string)));
        //        }

        //        while (cur_set.EOF() == false)
        //        {

        //            totaldue_amt = totaldue_amt + cur_set.mField("mDue_amt");

        //            if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, 30))
        //            {
        //                in30_amt = in30_amt + cur_set.mField("mDue_amt");
        //            }
        //            else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, 60))
        //            {
        //                in60_amt = in60_amt + cur_set.mField("mDue_amt");
        //            }
        //            else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, 90))
        //            {
        //                in90_amt = in90_amt + cur_set.mField("mDue_amt");
        //            }
        //            else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, 120))
        //            {
        //                in120_amt = in120_amt + cur_set.mField("mDue_amt");
        //            }
        //            else
        //            {
        //                over120_amt = over120_amt + cur_set.mField("mDue_amt");
        //            }

        //            row_num += 1;
        //            cur_set.MoveNext();

        //        }

        //        dr = dt.NewRow();

        //        Data[DASHBOARD_DEPTH_NUM, row_num] = "0";
        //        Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_RECEIVABLE_FORECAST_TYPE_NUM.ToString();
        //        Data[DASHBOARD_CODE_NUM, row_num] = "";
        //        Data[DASHBOARD_COL_2_NUM, row_num] = "";
        //        Data[DASHBOARD_COL_3_NUM, row_num] = "";
        //        Data[DASHBOARD_COL_4_NUM, row_num] = o_money.ToStrMoney(totaldue_amt);
        //        Data[DASHBOARD_COL_5_NUM, row_num] = o_money.ToStrMoney(in30_amt);
        //        Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(in60_amt);
        //        Data[DASHBOARD_COL_7_NUM, row_num] = o_money.ToStrMoney(in90_amt);
        //        Data[DASHBOARD_COL_8_NUM, row_num] = o_money.ToStrMoney(in120_amt);
        //        Data[DASHBOARD_COL_9_NUM, row_num] = o_money.ToStrMoney(over120_amt);

        //        dt.Rows.Add(dr);

        //        if (show_detail)
        //        {

        //            cur_set.MoveFirst();
        //            while (cur_set.EOF() == false)
        //            {

        //                dr = dt.NewRow();

        //                Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_RECEIVABLE_FORECAST_TYPE_NUM.ToString();
        //                Data[DASHBOARD_CODE_NUM, row_num] = cur_set.iField("iTransaction_num");
        //                Data[DASHBOARD_COL_2_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iApply_dt"));
        //                Data[DASHBOARD_COL_3_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iDue_dt"));
        //                if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, 30))
        //                {
        //                    Data[DASHBOARD_COL_5_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //                }
        //                else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, 60))
        //                {
        //                    Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //                }
        //                else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, 90))
        //                {
        //                    Data[DASHBOARD_COL_7_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //                }
        //                else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, 120))
        //                {
        //                    Data[DASHBOARD_COL_8_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //                }
        //                else
        //                {
        //                    Data[DASHBOARD_COL_9_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //                }

        //                cur_set.MoveNext();
        //                dt.Rows.Add(dr);

        //            }
        //        }

        //        align_array.Clear();
        //        align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //        align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //        align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //        align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //        align_array.Add(moInquiry.GetCssClassName("iApply_dt"));
        //        align_array.Add(moInquiry.GetCssClassName("iDue_dt"));
        //        align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //        align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //        align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //        align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //        align_array.Add(moInquiry.GetCssClassName("mDue_amt"));

        //        cur_grid.DataSource = dt;
        //        cur_grid.DataBind();
        //        modWebGridUtility.CopyDataTableToGridView(ref cur_db, ref cur_grid, ref dt, ref web_ddl, align_array); // We need to make sure that dt is bound to grdListing before this is called.

        //        return_value = cur_set.RecordCount();
        //        return return_value;

        //    }
        //    catch (Exception ex)
        //    {

        //        modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ReceivableForecast)");
        //        return return_value;

        //    }

        //}

        //public static int ReceivableAging(ref clsDatabase cur_db, int cur_date, bool show_details = false)
        //{

        //    int return_value = 0;
        //    decimal pastdue_amt = 0M;
        //    decimal in30_amt = 0M;
        //    decimal in60_amt = 0M;
        //    decimal in90_amt = 0M;
        //    decimal in120_amt = 0M;
        //    decimal over120_amt = 0M;
        //    clsGeneral o_gen = new clsGeneral(ref cur_db);
        //    clsMoney o_money = new clsMoney(ref cur_db);
        //    clsRecordset cur_set = new clsRecordset(ref cur_db);
        //    string sql_str = null;
        //    int row_num = 0;
        //    DataTable dt = new DataTable();
        //    DataRow dr = null;
        //    clsWebDropdownList web_ddl = new clsWebDropdownList(ref cur_db);
        //    ArrayList align_array = new ArrayList();
        //    string alignment_str = null;

        //    try
        //    {

        //        ClearDashboardGrid(ref cur_grid);
        //        ResizeSpreadsheet(ref cur_grid, DASHBOARD_COL_9_NUM + 1);
        //        FieldName[DASHBOARD_DEPTH_NUM] = "Depth");
        //        FieldName[DASHBOARD_TYPE_NUM] = "Type");
        //        FieldName[DASHBOARD_CODE_NUM] = "Invoice Number");
        //        modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_CODE_NUM, (!show_details));
        //        FieldName[DASHBOARD_COL_2_NUM] = "Date Applied");
        //        modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_COL_2_NUM, (!show_details));
        //        FieldName[DASHBOARD_COL_3_NUM] = "Date Due");
        //        modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, DASHBOARD_COL_3_NUM, (!show_details));
        //        FieldName[DASHBOARD_COL_4_NUM] = "Total Past Due");
        //        FieldName[DASHBOARD_COL_5_NUM] = "Last 30 Days");
        //        FieldName[DASHBOARD_COL_6_NUM] = "Last 60 Days");
        //        FieldName[DASHBOARD_COL_7_NUM] = "Last 90 Days");
        //        FieldName[DASHBOARD_COL_8_NUM] = "Last 120 Days");
        //        FieldName[DASHBOARD_COL_9_NUM] = "Over 120");

        //        sql_str = "SELECT * FROM tblARCharge WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_INVOICE_TYPE.ToString();
        //        sql_str += " AND iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM.ToString();
        //        sql_str += " AND mDue_amt <> 0 "; // 06/19/2018 Negative voucher/invoice is implemented
        //        sql_str += " AND iDue_dt <= " + cur_date.ToString();
        //        sql_str += " ORDER BY iDue_dt";

        //        if (cur_set.CreateSnapshot(sql_str) == false)
        //        {
        //            return_value = 0;
        //            return return_value;
        //        }
        //        else if (cur_set.RecordCount() == 0)
        //        {
        //            cur_set.Release();
        //            return_value = 0;
        //            return return_value;
        //        }

        //        for (row_num = 1; row_num < cur_grid.Columns.Count; row_num++)
        //        {
        //            dt.Columns.Add(new DataColumn(modWebGridUtility.GetColumnId(row_num), typeof(string)));
        //        }

        //        while (cur_set.EOF() == false)
        //        {

        //            if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -120))
        //            {
        //                over120_amt = over120_amt + cur_set.mField("mDue_amt");
        //            }
        //            else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -90))
        //            {
        //                in120_amt = in120_amt + cur_set.mField("mDue_amt");
        //            }
        //            else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -60))
        //            {
        //                in90_amt = in90_amt + cur_set.mField("mDue_amt");
        //            }
        //            else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -30))
        //            {
        //                in60_amt = in60_amt + cur_set.mField("mDue_amt");
        //            }
        //            else // If cur_set.iField("iDue_dt") <= cur_date Then
        //            {
        //                in30_amt = in30_amt + cur_set.mField("mDue_amt");
        //            }

        //            pastdue_amt = pastdue_amt + cur_set.mField("mDue_amt");
        //            cur_set.MoveNext();

        //        }

        //        dr = dt.NewRow();

        //        Data[DASHBOARD_DEPTH_NUM, row_num] = "0";
        //        Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_RECEIVABLE_AGING_TYPE_NUM.ToString();
        //        Data[DASHBOARD_CODE_NUM, row_num] = "";
        //        Data[DASHBOARD_COL_2_NUM, row_num] = "";
        //        Data[DASHBOARD_COL_3_NUM, row_num] = "";
        //        Data[DASHBOARD_COL_4_NUM, row_num] = o_money.ToStrMoney(pastdue_amt);
        //        Data[DASHBOARD_COL_5_NUM, row_num] = o_money.ToStrMoney(in30_amt);
        //        Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(in60_amt);
        //        Data[DASHBOARD_COL_7_NUM, row_num] = o_money.ToStrMoney(in90_amt);
        //        Data[DASHBOARD_COL_8_NUM, row_num] = o_money.ToStrMoney(in120_amt);
        //        Data[DASHBOARD_COL_9_NUM, row_num] = o_money.ToStrMoney(over120_amt);

        //        dt.Rows.Add(dr);

        //        if (show_details)
        //        {

        //            cur_set.MoveFirst();
        //            while (cur_set.EOF() == false)
        //            {

        //                dr = dt.NewRow();

        //                Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_RECEIVABLE_AGING_TYPE_NUM.ToString();
        //                Data[DASHBOARD_CODE_NUM, row_num] = cur_set.iField("iTransaction_num");
        //                Data[DASHBOARD_COL_2_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iApply_dt"));
        //                Data[DASHBOARD_COL_3_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iDue_dt"));

        //                if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -120))
        //                {
        //                    Data[DASHBOARD_COL_9_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //                }
        //                else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -90))
        //                {
        //                    Data[DASHBOARD_COL_8_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //                }
        //                else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -60))
        //                {
        //                    Data[DASHBOARD_COL_7_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //                }
        //                else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -30))
        //                {
        //                    Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //                }
        //                else // If cur_set.iField("iDue_dt") <= cur_date Then
        //                {
        //                    Data[DASHBOARD_COL_5_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
        //                }

        //                cur_set.MoveNext();
        //                dt.Rows.Add(dr);

        //            }
        //        }

        //        align_array.Clear();
        //        align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //        align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //        align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //        align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //        align_array.Add(moInquiry.GetCssClassName("iApply_dt"));
        //        align_array.Add(moInquiry.GetCssClassName("iDue_dt"));
        //        align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //        align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //        align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //        align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //        align_array.Add(moInquiry.GetCssClassName("mDue_amt"));
        //        align_array.Add(moInquiry.GetCssClassName("mDue_amt"));

        //        cur_grid.DataSource = dt;
        //        cur_grid.DataBind();
        //        modWebGridUtility.CopyDataTableToGridView(ref cur_db, ref cur_grid, ref dt, ref web_ddl, align_array); // We need to make sure that dt is bound to grdListing before this is called.

        //        return_value = cur_set.RecordCount();
        //        return return_value;

        //    }
        //    catch (Exception ex)
        //    {

        //        modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ReceivableAging)");
        //        return return_value;

        //    }

        //}

        //public static void DrillDownPayableAgingOnDashBoard(ref clsDatabase cur_db, int cur_date, int row_num)
        //{

        //	try
        //	{

        //		//Dim row_num As Integer = cur_grid.ActiveRow

        //		if (!GlobalVar.goUtility.IsEmpty(modWebGridUtility.SpreadsheetGetCell(cur_grid, DASHBOARD_CODE_NUM, row_num)))
        //		{
        //			//ResizeDashBoard()
        //			//Dim new_form As New frmLookupVoucher
        //			//new_form.MdiParent = MainForm
        //			//new_form.msInitialKey_id = SpreadsheetGetCell(cur_grid, DASHBOARD_CODE_NUM, row_num)
        //			//new_form.Show()
        //			//new_form.BringToFront()
        //			return;
        //		}

        //		PayableAging(ref cur_db, ref cur_grid, cur_date, true);

        //	}
        //	catch (Exception ex)
        //	{

        //	}

        //}

        //public static void DrillDownReceivableAgingOnDashBoard(ref clsDatabase cur_db, int cur_date, int row_num)
        //{

        //	try
        //	{

        //		//Dim row_num As Integer = cur_grid.ActiveRow

        //		ReceivableAging(ref cur_db, ref cur_grid, cur_date, true);

        //	}
        //	catch (Exception ex)
        //	{

        //	}

        //}

        //public static void DrillDownPayableForecastOnDashBoard(ref clsDatabase cur_db, int cur_date, int row_num)
        //{

        //	try
        //	{

        //		//Dim row_num As Integer = cur_grid.ActiveRow

        //		PayableForecast(ref cur_db, ref cur_grid, cur_date, true);

        //	}
        //	catch (Exception ex)
        //	{

        //	}

        //}

        //public static void DrillDownReceivableForecastOnDashBoard(ref clsDatabase cur_db, int cur_date, int row_num)
        //{

        //	try
        //	{

        //		ReceivableForecast(ref cur_db, ref cur_grid, cur_date, true);

        //	}
        //	catch (Exception ex)
        //	{

        //	}

        //}

        //public static int ApprovalsWaitingFor(ref clsDatabase cur_db, int cur_date, bool get_count_only)
        //{

        //	int return_value = 0;
        //	clsMoney o_money = new clsMoney(ref cur_db);
        //	clsApproval o_approval = new clsApproval(ref cur_db);
        //	clsGeneral o_general = new clsGeneral(ref cur_db);
        //	DataRow dr = null;
        //	DataTable dt = new DataTable();
        //	clsWebDropdownList web_ddl = new clsWebDropdownList(ref cur_db);
        //	int row_num = 0;
        //	clsRecordset cur_set = new clsRecordset(ref cur_db);
        //	string sql_str = null;
        //	string trx_type = null;
        //	ArrayList align_array = new ArrayList();
        //	string alignment_str = null;

        //	ClearDashboardGrid(ref cur_grid);
        //	modGeneralUtility.RunEvents();

        //	try
        //	{

        //		if (get_count_only == false)
        //		{
        //			ClearDashboardGrid(ref cur_grid);
        //			FieldName[DASHBOARD_DEPTH_NUM] = "Depth");
        //			FieldName[DASHBOARD_TYPE_NUM] = "Type");
        //			FieldName[DASHBOARD_CODE_NUM] = "Transaction Num");
        //			FieldName[DASHBOARD_COL_2_NUM] = "Transaction Type");
        //			FieldName[DASHBOARD_COL_3_NUM] = "Transaction Amount");
        //			FieldName[DASHBOARD_COL_4_NUM] = "Discount Amount");
        //			FieldName[DASHBOARD_COL_5_NUM] = "Discount %");
        //			FieldName[DASHBOARD_COL_6_NUM] = "Date Created");
        //		}

        //		sql_str = "SELECT * FROM tblGOApprovalStatus WHERE iApprovalStatus_typ = " + clsApproval.APPROVAL_REQUESTED_TYPE_NUM;
        //		sql_str += " AND sLastUpdate_id = '" + cur_db.sUser_cd + "'";

        //		if (cur_set.CreateSnapshot(sql_str) == false)
        //		{
        //			return_value = 0;
        //			return return_value;
        //		}
        //		else if (cur_set.RecordCount() == 0 || get_count_only)
        //		{
        //			return_value = cur_set.RecordCount();
        //			return return_value;
        //		}

        //		return_value = cur_set.RecordCount();

        //		for (row_num = 1; row_num < cur_grid.Columns.Count; row_num++)
        //		{
        //			dt.Columns.Add(new DataColumn(modWebGridUtility.GetColumnId(row_num), typeof(string)));
        //		}

        //		while (cur_set.EOF() == false)
        //		{

        //			if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_JOURNAL_TYPE)
        //			{
        //				trx_type = cur_db.oLanguage.oString.STR_JOURNAL;
        //			}
        //			else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_INVOICE_TYPE)
        //			{
        //				trx_type = cur_db.oLanguage.oString.STR_INVOICE;
        //			}
        //			else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_SO_TYPE)
        //			{
        //				trx_type = cur_db.oLanguage.oString.STR_ORDER;
        //			}
        //			else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_QUOTE_TYPE)
        //			{
        //				trx_type = cur_db.oLanguage.oString.STR_QUOTE;
        //			}
        //			else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_PURCHASE_TYPE)
        //			{
        //				trx_type = cur_db.oLanguage.oString.STR_VOUCHER;
        //			}
        //			else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_PO_TYPE)
        //			{
        //				trx_type = cur_db.oLanguage.oString.STR_PURCHASE_ORDER;
        //			}
        //			else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_RECEIPT_TYPE)
        //			{
        //				trx_type = cur_db.oLanguage.oString.STR_CASH_RECEIPT;
        //			}
        //			else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_PAYMENT_TYPE)
        //			{
        //				trx_type = cur_db.oLanguage.oString.STR_CASH_PAYMENT;
        //			}
        //			else
        //			{
        //				trx_type = cur_db.oLanguage.oString.STR_NA;
        //			}

        //			dr = dt.NewRow();
        //			Data[DASHBOARD_DEPTH_NUM, row_num] = DASHBOARD_APPROVAL_WAITING_TYPE_NUM.ToString();
        //			Data[DASHBOARD_TYPE_NUM, row_num] = cur_set.iField("iTransaction_typ").ToString();
        //			Data[DASHBOARD_CODE_NUM, row_num] = cur_set.iField("iTransaction_num");
        //			Data[DASHBOARD_COL_2_NUM, row_num] = trx_type;
        //			Data[DASHBOARD_COL_3_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mTransaction_amt"));
        //			Data[DASHBOARD_COL_4_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDiscount_amt"));
        //			Data[DASHBOARD_COL_5_NUM, row_num] = GlobalVar.goUtility.RoundToDiscountPerc(cur_set.mField("fDiscount_pc"));
        //			Data[DASHBOARD_COL_6_NUM, row_num] = o_general.ToStrDate(GlobalVar.goUtility.ToInteger(GlobalVar.goUtility.SFormat(cur_set.dtField("dtLastUpdate_dt"), "yyyyMMdd")));
        //			dt.Rows.Add(dr);
        //			cur_set.MoveNext();
        //			modGeneralUtility.RunEvents();

        //		}

        //		align_array.Clear();
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("iTransaction_num"));
        //		align_array.Add(moInquiry.GetCssClassName("mTransaction_amt"));
        //		align_array.Add(moInquiry.GetCssClassName("mDiscount_amt"));
        //		align_array.Add(moInquiry.GetCssClassName("fDiscount_pc"));
        //		align_array.Add(moInquiry.GetCssClassName("dtLastUpdate_dt"));

        //		cur_grid.DataSource = dt;
        //		cur_grid.DataBind();
        //		modWebGridUtility.CopyDataTableToGridView(ref cur_db, ref cur_grid, ref dt, ref web_ddl, align_array); // We need to make sure that dt is bound to grdListing before this is called.

        //		return return_value;

        //	}
        //	catch (Exception ex)
        //	{

        //		modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ApprovalsWaitingFor)");
        //		return return_value;

        //	}

        //}

        //public static int CustomerSupport(ref clsDatabase cur_db, int cur_date, bool get_count_only)
        //{

        //    int return_value = 0;
        //    clsRecordset reason_set = new clsRecordset(ref cur_db);
        //    clsRecordset cur_set = new clsRecordset(ref cur_db);
        //    string sql_str = null;
        //    string reason_str = null;
        //    int row_num = 0;
        //    DataTable dt = new DataTable();
        //    DataRow dr = null;
        //    clsWebDropdownList web_ddl = new clsWebDropdownList(ref cur_db);
        //    ArrayList align_array = new ArrayList();
        //    string alignment_str = null;

        //    try
        //    {

        //        if (get_count_only == false)
        //        {
        //            ClearDashboardGrid(ref cur_grid);
        //            ResizeSpreadsheet(ref cur_grid, DASHBOARD_COL_3_NUM + 1);
        //            FieldName[DASHBOARD_DEPTH_NUM] = "Depth");
        //            FieldName[DASHBOARD_TYPE_NUM] = "Type");
        //            FieldName[DASHBOARD_CODE_NUM] = "Case ID");
        //            FieldName[DASHBOARD_COL_2_NUM] = "Date Requested");
        //            FieldName[DASHBOARD_COL_3_NUM] = "Resolution Requested");
        //        }

        //        sql_str = "SELECT * FROM tblARCustomerSupportDet WHERE iStatus_typ = " + GlobalVar.goConstant.SUPPORT_OPEN_NUM.ToString();
        //        sql_str += " AND sAssignedTo_cd = '" + cur_db.sUser_cd + "'";
        //        sql_str += " AND iResolution_id = 0";

        //        if (cur_set.CreateSnapshot(sql_str) == false)
        //        {
        //            return_value = 0;
        //            return return_value;
        //        }
        //        else if (cur_set.RecordCount() == 0)
        //        {
        //            cur_set.Release();
        //            return_value = 0;
        //            return return_value;
        //        }
        //        else if (get_count_only)
        //        {
        //            return_value = cur_set.RecordCount();
        //            cur_set.Release();
        //            return return_value;
        //        }

        //        sql_str = "SELECT * FROM tblARCustomerCallReason ORDER BY iReason_id";

        //        if (!reason_set.CreateSnapshot(sql_str))
        //        {
        //            return_value = 0;
        //            return return_value;
        //        }

        //        for (row_num = 1; row_num < cur_grid.Columns.Count; row_num++)
        //        {
        //            dt.Columns.Add(new DataColumn(modWebGridUtility.GetColumnId(row_num), typeof(string)));
        //        }

        //        while (cur_set.EOF() == false)
        //        {

        //            dr = dt.NewRow();

        //            reason_str = "";
        //            if (reason_set.FindRecord("iReason_id", cur_set.iField("iReason_id").ToString()))
        //            {
        //                reason_str = reason_set.sField("sDescription");
        //            }
        //            Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
        //            Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_APPROVAL_TO_MAKE_TYPE_NUM.ToString();
        //            Data[DASHBOARD_CODE_NUM, row_num] = cur_set.iField("iSupport_num").ToString();
        //            Data[DASHBOARD_COL_2_NUM, row_num] = cur_set.dtField("dtRequest_dt").ToString();
        //            Data[DASHBOARD_COL_3_NUM, row_num] = reason_str;

        //            cur_set.MoveNext();
        //            dt.Rows.Add(dr);

        //        }

        //        align_array.Clear();
        //        align_array.Add(moInquiry.GetCssClassName("iSupport_num"));
        //        align_array.Add(moInquiry.GetCssClassName("iSupport_num"));
        //        align_array.Add(moInquiry.GetCssClassName("iSupport_num"));
        //        align_array.Add(moInquiry.GetCssClassName("iSupport_num"));
        //        align_array.Add(moInquiry.GetCssClassName("dtRequest_dt"));
        //        align_array.Add(moInquiry.GetCssClassName("sDescription"));

        //        cur_grid.DataSource = dt;
        //        cur_grid.DataBind();
        //        modWebGridUtility.CopyDataTableToGridView(ref cur_db, ref cur_grid, ref dt, ref web_ddl, align_array); // We need to make sure that dt is bound to grdListing before this is called.

        //        return_value = cur_set.RecordCount();
        //        return return_value;

        //    }
        //    catch (Exception ex)
        //    {

        //        modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CustomerSupport)");
        //        return return_value;

        //    }

        //}

    }

}
