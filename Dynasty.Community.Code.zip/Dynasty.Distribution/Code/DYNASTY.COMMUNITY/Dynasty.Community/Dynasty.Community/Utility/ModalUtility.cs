﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Dynasty.ASP
{
    internal static class modModalUtility
    {
        public static bool Dialog(Models.clsModal cur_modal, Func<bool> caller, Models.clsPage cur_page, int calling_point, string dialog_msg, int input_type = -1)
        {
            cur_page.bInDialog_fl = true;         // Meaning a dialog started

            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (cur_modal.IsMyTurn(calling_point))
            {
                cur_modal.Show(dialog_msg, input_type);
                cur_modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (cur_modal.IsMyCall(calling_point))
            {
                if (cur_modal.OK == false)
                {
                    cur_modal.Release();
                    cur_page.bInDialog_fl = false;            // Meaning a dialog is enidng with Cancel button
                    return false;
                }
                else if (cur_modal.ValidInput == false)
                {
                    cur_modal.Show(cur_db.oPageTranslater.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }

                cur_modal.Release();                                                                   // Release this call and proceed.
            }

            cur_page.bInDialog_fl = false;                    // Meaning a dialog is enidng
            return true;
        }

    }
}