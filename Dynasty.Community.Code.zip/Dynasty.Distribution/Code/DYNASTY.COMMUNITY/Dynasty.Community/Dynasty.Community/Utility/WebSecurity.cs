﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Local;
using Dynasty.Database;

namespace Dynasty.ASP
{
	internal static class modSecurity
	{

		// User security info
		//
		public const int SECURITY_MENU_NAME_COL = 0;
		public const int SECURITY_LEVEL_COL = 1;

		//  This array will keep the menu names which are not accessible
		//  by the current user.
		//
		//Public user_security(,) As String  ' As Object  ' User secutiry info.

		//  This will grab all menu names and save them in the database during development,
		//  and the names will be used in the security system.
		//
		public static void CreateMenuNames()
		{

		}

		//  This will get the user-group security info.  This info tells which menu
		//  each user-group cannot access.  The global array user_security() will
		//  keep the menu name which are NOT accessable by this user-group.
		//
		public static bool GetUserSecurity(ref clsDatabase cur_db, string cur_module, string cur_user_group, ref clsRecordset security_set, ref string[,] user_security)
		{

			bool return_value = false;
			string sql_str = "";
			int row_num = 0;
			int tot_rows = 0;

			try
			{

				tot_rows = 100;

				GlobalVar.goUtility.ResizeDim(ref user_security, 2, tot_rows);
				user_security[SECURITY_MENU_NAME_COL, 0] = "";
				user_security[SECURITY_LEVEL_COL, 0] = "";

				sql_str = modConstant.USER_SECURITY_DYNASET + " WHERE sModule_id = '" + cur_module + "'";
				sql_str += " AND sUserGroup_cd = '" + cur_user_group + "'";
				sql_str += " ORDER BY sMenu_nm";

				if (!security_set.CreateSnapshot(sql_str))
				{
					modDialogUtility.DisplayBox(ref cur_db, security_set.GetErrorMessage());
					return return_value;
				}
				else if (security_set.EOF())
				{
					return true;
				}

				GlobalVar.goUtility.ResizeDim(ref user_security, 2, security_set.RecordCount());

				row_num = 0;
				while (security_set.EOF() == false)
				{

					user_security[SECURITY_MENU_NAME_COL, row_num] = security_set.sField("sMenu_nm");
					user_security[SECURITY_LEVEL_COL, row_num] = security_set.iField("iSecurityLevel").ToString();

					if (modConstant.SECURITY_DASHBOARD == user_security[SECURITY_MENU_NAME_COL, row_num])
					{
						cur_db.uSecurity.bDoNotShowDashBoard_fl = false;
					}
					else if (modConstant.SECURITY_MY_FAVORITES == user_security[SECURITY_MENU_NAME_COL, row_num])
					{
						cur_db.uSecurity.bDoNotShowMyFavorites_fl = false;
					}

					modGeneralUtility.RunEvents();
					security_set.MoveNext();
					row_num += 1;

				}

				return_value = true;
				security_set.MoveFirst();
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(GetUserSecurity)");
			}

			return return_value;
		}

		//  This will disble the menu items which this user is not supposed to access.
		//  The global array user_security() will keep the menu names which are NOT
		//  accessable by this user-group.
		//
		public static void SetUserSecurity(ref clsDatabase cur_db)
		{

			GetAllSecurityOptions(ref cur_db, cur_db.sCurProgram_nm);

		}

		//  This checks if the current form is read-only or not.
		//  At this time, there are two cases which may make the current form read-only.
		//  One is to open the form with mbReadOnly preset to True.
		//  The other case is that the user type is view-only.
		//  You may do more tight-security, here depending on the user-type and group.
		//
		public static bool FormIsReadOnly(ref clsDatabase cur_db)
		{

			bool return_value = false;
			if (cur_db.ViewOnly())
			{
				return_value = true;
			}

			return return_value;

		}

		// Checks if the passed menu item is restricted by security system or not.
		// At this point, Trsanction, Setup, and Report menus are restricted.
		//
		public static bool RestrictedMenuItem(ref clsDatabase cur_db)
		{

			bool return_value = false;
			//If goUtility.SLeft(cur_control.Name, goUtility.SLength("mnuTran")) = "mnuTran" Or goUtility.SLeft(cur_control.Name, goUtility.SLength("mnuSetup")) = "mnuSetup" Or goUtility.SLeft(cur_control.Name, goUtility.SLength("mnuLookup")) = "mnuLookup" Or goUtility.SLeft(cur_control.Name, goUtility.SLength("mnuSetup")) = "mnuDaily" Or goUtility.SLeft(cur_control.Name, goUtility.SLength("mnuRepo")) = "mnuRepo" Then
			//If cur_control.Visible And cur_control.Text <> "-" Then
			//RestrictedMenuItem = True
			//End If
			//End If

			return return_value;
		}

		// Checks the security when a menu item is clicked but before the form is
		// open yet.  You may do more tight-security, here depending on the user-type
		// and group.
		//
		public static bool SystemSecurity(ref clsDatabase cur_db)
		{

			bool return_value = false;
			return_value = true;

			return return_value;

		}

		// This will save a System option.
		//
		public static bool SaveSecurityOption(ref clsDatabase cur_db, string app_name, string option_name, int option_value, string option_text = "")
		{

			bool return_value = false;
			string sql_str = "";
			clsRecordset cur_set = null;

			cur_set = new clsRecordset(ref cur_db);

			sql_str = "DELETE FROM  tblGOSecurityOption";
			sql_str += " WHERE sApp_nm = '" + GlobalVar.goUtility.STrim(app_name) + "'";
			sql_str += " AND   sOption_nm = '" + GlobalVar.goUtility.STrim(option_name) + "'";
			if (!cur_db.ExecuteSQL(sql_str))
			{
				return return_value;
			}

			sql_str = "INSERT INTO tblGOSecurityOption(";
			sql_str += "sApp_nm";
			sql_str += ",sOption_nm";
			sql_str += ",iOptionValue";
			sql_str += ",sOptionValue";
			sql_str += ") VALUES (";
			sql_str += "'" + app_name + "'";
			sql_str += ",'" + option_name + "'";
			sql_str += "," + option_value;
			sql_str += ",'" + option_text + "'";
			sql_str += ")";
			if (!cur_db.ExecuteSQL(sql_str))
			{
				return return_value;
			}

			return true;

		}

		// Read a System option.
		//
		public static bool GetSecurityOption(ref clsDatabase cur_db, string app_name, string option_name, ref int option_value)
		{

			bool return_value = false;
			string sql_str = "";
			int initial_value = 0;
			clsRecordset cur_set = null;
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			cur_set = new clsRecordset(ref cur_db);

			// There may be module-specific and company-wide global option values.
			// Grab the module-specific one if there is.
			//
			sql_str = "SELECT * ";
			sql_str += " FROM  tblGOSecurityOption";
			sql_str += " WHERE (sApp_nm = " + app_name;
			sql_str += " OR    sApp_nm = 'ALL')";
			sql_str += " AND   sOption_nm = '" + GlobalVar.goUtility.STrim(option_name) + "'";
			sql_str += " ORDER BY sApp_nm DESC)";

			if (!cur_set.CreateSnapshot(sql_str))
			{
				return return_value;
			}
			else if (!cur_set.EOF())
			{
				option_value = cur_set.iField("iOptionValue");
				return_value = true;
				cur_set.Release();
				return return_value;
			}

			// If the option is not found, put the initial value.
			// Probably, you want to set different initial values depending on the option.
			//
			if (option_name == modConstant.BLOCK_ACCOUNT_BALANCE || option_name == modConstant.BLOCK_APPLY_DATE || option_name == modConstant.BLOCK_ENTRY_DATE || option_name == modConstant.BLOCK_TRANSACTION || option_name == modConstant.USE_PROCESS_DATE)
			{
				initial_value = GlobalVar.goConstant.FLAG_OFF;
			}
			else if (option_name == modConstant.PROCESS_ENTRY_DATE || option_name == modConstant.PROCESS_APPLY_DATE)
			{
				initial_value = o_gen.CurrentDate();
			}

			sql_str += "INSERT INTO tblGOSecurityOption(";
			sql_str += " sApp_nm,";
			sql_str += " sOption_nm,";
			sql_str += " iOptionValue)";
			sql_str += " VALUES (";
			sql_str += "'ALL',"; // company-wide global value.
			sql_str += "'" + GlobalVar.goUtility.STrim(option_name) + "',";
			sql_str += initial_value + ")";

			option_value = initial_value;
			return_value = cur_db.ExecuteSQL(sql_str);

			cur_set.Release();
			return return_value;

		}

		// Reads System options and set the global variables.
		//
		public static bool GetAllSecurityOptions(ref clsDatabase cur_db, string app_name)
		{

			bool return_value = false;
			string sql_str = "";
			int initial_value = 0;
			clsRecordset cur_set = null;
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			cur_set = new clsRecordset(ref cur_db);

			// There may be module-specific and company-wide global option values.
			// Grab the module-specific one if there is.
			//
			sql_str = "SELECT * ";
			sql_str += " FROM  tblGOSecurityOption";
			sql_str += " WHERE sApp_nm = '" + app_name + "'";

			if (app_name == GlobalVar.goConstant.SOMENU_NAME)
			{
				sql_str += " OR sApp_nm = '" + GlobalVar.goConstant.ARMENU_NAME + "'"; // This will pick up A/R options
				sql_str += " ORDER BY sApp_nm, sOption_nm"; // This will make S/O options overide the A/R options
			}
			else if (app_name == GlobalVar.goConstant.POMENU_NAME)
			{
				sql_str += " OR sApp_nm = '" + GlobalVar.goConstant.APMENU_NAME + "'"; // This will pick up A/P options
				sql_str += " ORDER BY sApp_nm, sOption_nm"; // This will make P/O options overide the A/P options
			}
			else if (app_name == GlobalVar.goConstant.IVMENU_NAME)
			{
				sql_str += " OR sApp_nm = '" + GlobalVar.goConstant.ARMENU_NAME + "'"; // This will pick up A/R options
				sql_str += " ORDER BY sApp_nm, sOption_nm"; // This will make IV options overide the A/R options
			}

			if (!cur_set.CreateSnapshot(sql_str))
			{
				return return_value;
			}

			// If the option is not found, put the initial value.
			// Probably, you want to set different initial values depending
			// on the option.
			//
			while (!cur_set.EOF())
			{
				if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.BLOCK_ACCOUNT_BALANCE)
				{
					cur_db.uSecurity.bBlockAccountBalance_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.BLOCK_APPLY_DATE)
				{
					cur_db.uSecurity.bBlockApplyDate_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.BLOCK_ENTRY_DATE)
				{
					cur_db.uSecurity.bBlockEntryDate_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.BLOCK_TRANSACTION)
				{
					cur_db.uSecurity.bBlockTransaction_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.USE_PROCESS_DATE)
				{
					cur_db.uSecurity.bUseProcessDate_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.PROCESS_APPLY_DATE)
				{
					cur_db.uSecurity.iCurApply_dt = cur_set.iField("iOptionValue");
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.BLOCK_ITEM_DATA_CHANGE)
				{
					cur_db.uSecurity.bBlockItemChange_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.BLOCK_ITEM_SCREEN)
				{
					cur_db.uSecurity.bBlockItemScreen_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.BLOCK_PRICE_CHANGE)
				{
					cur_db.uSecurity.bBlockPriceChange_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.BLOCK_PAYMENT_DISCOUNT_CHANGE)
				{
					cur_db.uSecurity.bBlockPaymentDiscount_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.MAX_TOLERANCE_AMOUNT)
				{
					cur_db.uSecurity.mTolerance_amt = cur_set.iField("iOptionValue");
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.DO_NOT_CLOSE_PERIOD)
				{
					cur_db.uSecurity.bDoNotClosePeriod_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.LOCK_CLOSED_PERIODS)
				{
					cur_db.uSecurity.bLockClosedPeriods_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.SHIPPING_QA_IS_REQUIRED)
				{
					cur_db.uSecurity.bShippingQARequired = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.SHOW_COLOR_COLUMN)
				{
					cur_db.uSecurity.bShowColorColumn_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
					cur_db.uSecurity.sColorCaption = GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsEmpty(cur_set.sField("sOptionValue")), cur_db.oLanguage.oString.STR_COLOR, cur_set.sField("sOptionValue")).ToString();
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.SHOW_SIZE_COLUMN)
				{
					cur_db.uSecurity.bShowSizeColumn_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
					cur_db.uSecurity.sSizeCaption = GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsEmpty(cur_set.sField("sOptionValue")), cur_db.oLanguage.oString.STR_SIZE, cur_set.sField("sOptionValue")).ToString();
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.SHOW_MANUFACTURER_COLUMN)
				{
					cur_db.uSecurity.bShowManufacturerColumn_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
					cur_db.uSecurity.sManufacturerCaption = GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsEmpty(cur_set.sField("sOptionValue")), cur_db.oLanguage.oString.STR_MANUFACTURER, cur_set.sField("sOptionValue")).ToString();
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.SHOW_BRAND_COLUMN)
				{
					cur_db.uSecurity.bShowBrandColumn_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
					cur_db.uSecurity.sBrandCaption = GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsEmpty(cur_set.sField("sOptionValue")), cur_db.oLanguage.oString.STR_BRAND, cur_set.sField("sOptionValue")).ToString();
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.SHOW_MODEL_COLUMN)
				{
					cur_db.uSecurity.bShowModelColumn_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
					cur_db.uSecurity.sModelCaption = GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsEmpty(cur_set.sField("sOptionValue")), cur_db.oLanguage.oString.STR_MODEL, cur_set.sField("sOptionValue")).ToString();
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.SHOW_STYLE_COLUMN)
				{
					cur_db.uSecurity.bShowStyleColumn_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
					cur_db.uSecurity.sStyleCaption = GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsEmpty(cur_set.sField("sOptionValue")), cur_db.oLanguage.oString.STR_STYLE, cur_set.sField("sOptionValue")).ToString();
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.VALIDATE_COLOR_COLUMN)
				{
					cur_db.uSecurity.bValidateColorColumn_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.VALIDATE_SIZE_COLUMN)
				{
					cur_db.uSecurity.bValidateSizeColumn_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.VALIDATE_MANUFACTURER_COLUMN)
				{
					cur_db.uSecurity.bValidateManufacturerColumn_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.VALIDATE_BRAND_COLUMN)
				{
					cur_db.uSecurity.bValidateBrandColumn_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.VALIDATE_MODEL_COLUMN)
				{
					cur_db.uSecurity.bValidateModelColumn_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.VALIDATE_STYLE_COLUMN)
				{
					cur_db.uSecurity.bValidateStyleColumn_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.INCLUDE_SERIAL_IN_INVOICE)
				{
					cur_db.uSecurity.bIncludeSerialInInvoice_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.SHOW_PURCHASE_PRICE)
				{
					cur_db.uSecurity.bShowPurchasePrice_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.APPLY_CUSTOMER_PRICING)
				{
					cur_db.uSecurity.bApplyCustomerPricing_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.APPLY_SIZE_TO_UNIT_PRICE)
				{
					cur_db.uSecurity.bApplySizeToUnitPrice_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.LOCK_PRINTED_INVOICE)
				{
					cur_db.uSecurity.bLockPrintedInvoice_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.LOCK_PRINTED_PACKING_SLIP)
				{
					cur_db.uSecurity.bLockPrintedPackingSlip_fl = false; // cur_set.iField("iOptionValue") = goConstant.CHECKED_ON does not make sense 4/24/2019
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.ALLOW_QUANTITY_ALLOCATION)
				{
					cur_db.uSecurity.bAllowQuantityAllocation_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.SECURITY_MY_FAVORITES)
				{
					cur_db.uSecurity.bDoNotShowMyFavorites_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.PRINT_DETAILS_ON_CHECK_STUB)
				{
					cur_db.uSecurity.bPrintDetailsOnCheckStub_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.USE_MATRIX_FORM)
				{
					cur_db.uSecurity.bUseMatrixForm_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.SHOW_ORIGINAL_QTY_ORDERED_ON_INVOICE_QTY)
				{
					cur_db.uSecurity.bShowOriginalQtyOrdered_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.SHOW_MESSAGE_ON_TOP_OF_PAGE)
				{
					cur_db.uSecurity.bShowMessagesOnTop_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.TAX_IS_DISCOUNTABLE)
				{
					cur_db.uSecurity.bTaxIsDiscountable_fl = (cur_set.iField("iOptionValue")) == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.FREIGHT_IS_DISCOUNTABLE)
				{
					cur_db.uSecurity.bFreightIsDiscountable_fl = (cur_set.iField("iOptionValue")) == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.PRIMARY_RULES_SUBITEMS)
				{
					cur_db.uSecurity.bPrimaryRulesSubItems_fl = (cur_set.iField("iOptionValue")) == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.ALLOW_ITEM_CODE_CHANGE)
				{
					cur_db.uSecurity.bAllowItemCodeChange_fl = (cur_set.iField("iOptionValue")) == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.INVOICE_NUMBERING_BY_CUSTOMER)
				{
					cur_db.uSecurity.bInvoiceNumberingByCustomer_fl = (cur_set.iField("iOptionValue")) == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.INVOICE_NUMBERING_BY_JOB)
				{
					cur_db.uSecurity.bInvoiceNumberingByJob_fl = (cur_set.iField("iOptionValue")) == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.EDITABLE_INVOICE_NUMBER)
				{
					cur_db.uSecurity.bEditableInvoiceNumber_fl = (cur_set.iField("iOptionValue")) == GlobalVar.goConstant.CHECKED_ON;
				}
				else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.LOCK_RENTAL_ONECE_BILLED)
				{
					cur_db.uSecurity.bLockRentalAtBilling_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
				}
                else if (GlobalVar.goUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.USE_COMBOBOX_FOR_CASH_ACCOUNTS)
                {
                    cur_db.uSecurity.bUseComboboxForCashAccount_fl = cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON;
                }
                else
                {
					// Not expected
				}
				cur_set.MoveNext();
			}

			// In case not set up yet.
			cur_db.uSecurity.sColorCaption = GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsEmpty(cur_db.uSecurity.sColorCaption), cur_db.oLanguage.oString.STR_COLOR, cur_db.uSecurity.sColorCaption).ToString();
			cur_db.uSecurity.sSizeCaption = GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsEmpty(cur_db.uSecurity.sSizeCaption), cur_db.oLanguage.oString.STR_SIZE, cur_db.uSecurity.sSizeCaption).ToString();
			cur_db.uSecurity.sManufacturerCaption = GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsEmpty(cur_db.uSecurity.sManufacturerCaption), cur_db.oLanguage.oString.STR_MANUFACTURER, cur_db.uSecurity.sManufacturerCaption).ToString();
			cur_db.uSecurity.sBrandCaption = GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsEmpty(cur_db.uSecurity.sBrandCaption), cur_db.oLanguage.oString.STR_BRAND, cur_db.uSecurity.sBrandCaption).ToString();
			cur_db.uSecurity.sModelCaption = GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsEmpty(cur_db.uSecurity.sModelCaption), cur_db.oLanguage.oString.STR_MODEL, cur_db.uSecurity.sModelCaption).ToString();
			cur_db.uSecurity.sStyleCaption = GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsEmpty(cur_db.uSecurity.sStyleCaption), cur_db.oLanguage.oString.STR_STYLE, cur_db.uSecurity.sStyleCaption).ToString();

			// The default values of options are False.
			// But the dates should be today's date.
			//
			if (cur_db.uSecurity.iCurApply_dt < GlobalVar.goConstant.SMALLEST_DATE || cur_db.uSecurity.iCurApply_dt > GlobalVar.goConstant.LARGEST_DATE)
			{
				cur_db.uSecurity.iCurApply_dt = o_gen.CurrentDate();
			}

			cur_set.Release();
			return true;

		}

		//  You may do more tight-security, here depending on the user-type and group.
		//
		public static bool SystemFormSecurityCheck(ref clsDatabase cur_db)
		{

			return true;

		}
		public static bool SystemPrintSecurityCheck(ref clsDatabase cur_db, Models.clsPage cur_page)
		{

			return true;

		}
		public static bool IsValidSupervisor(ref clsDatabase cur_db, ref string user_id, ref string password)
		{

			bool return_value = false;
			string sql_str = "";
			clsRecordset cur_set = null;

			cur_set = new clsRecordset(ref cur_db);

			sql_str = "SELECT * FROM tblGOUser WHERE sUser_cd = '" + user_id + "'";
			sql_str += " AND sPassword = '" + GlobalVar.goUtility.PasswordEncode(password) + "'";

			if (!cur_set.CreateSnapshot(sql_str))
			{
				return return_value;
			}

			// Only supervisor of same group can approve.
			//
			if (!cur_set.EOF())
			{
				if (clsConstant.USER_SUPERVISOR_TYPE <= cur_set.iField("iUserType_id"))
				{
					return_value = true;
				}
			}

			cur_set.Release();
			return return_value;

		}

		public static string GetSecretWord()
		{

			string return_value = "";
			string new_str = "";
			string str = GlobalVar.goUtility.GetRandomNumber(6);
			int i = 0;

			for (i = 1; i <= GlobalVar.goUtility.SLength(str); i++)
			{
				new_str = new_str + " " + GlobalVar.goUtility.SMid(str, i, 1);
			}

			return_value = GlobalVar.goUtility.STrim(new_str);

			return return_value;

		}

		public static bool CheckSecretWord(ref clsDatabase cur_db, string original_str, string new_str)
		{

			bool return_value = false;
			if (GlobalVar.goUtility.IsNonEmpty(GlobalVar.goUtility.STrim(original_str)) & GlobalVar.goUtility.STrim(original_str) != new_str)
			{
				return_value = (GlobalVar.goUtility.SReplace(original_str, " ", "") == new_str);
			}

			return return_value;

		}

	}

}
