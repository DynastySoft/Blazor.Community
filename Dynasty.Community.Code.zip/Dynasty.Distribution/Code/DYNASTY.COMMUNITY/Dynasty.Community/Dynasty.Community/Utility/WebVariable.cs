﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using Dynasty.ASP.Models;
using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP
{
	public static class GlobalVar // modVariable - GlobalVar is more meaningful when convert to C#
	{
		public static string gsCompany_nm = "";

		public static bool gbWebDemoVersion_fl = true; // This has to be turned off. This is to run a demo on a commercial site that has some restrictions.
		public static bool gbCrystalIsNotAvailable_fl = false; // When Crystal Report is not installed in demo system.
		public static bool gbIgnoreLegacyData_fl = true; // This should be used only to test the legacy data. In production, this has to be set to false.

		public static string gsConnectionString = "";

		// 11/1/2015
		// If gbUsePDFFileForReport_fl = true, 
		//       - a pdf file is created and loaded to the browser
		//       - IE/Chrome, both, default to pdf file format when user save the file in the browswer
		// For Blazor, we need to create a PDF file for all reports.
		//
		public static bool gbUsePDFFileForReport_fl = true;

		public const int MAX_SIZE_FOR_ZOOM_WITHOUT_INITIALS = 100;
		public const string LOGIN_WEB_PAGE_NAME = "index";
		public const string DEFAULT_WEB_PAGE_NAME = "default";
		public const string DASHBOARD_PAGE_NAME = "dashboard";
		public const string SETUP_ADVISOR_PAGE_NAME = "setupadvisor";

        public const string WEB_MODULE_ID = "WB";                   // Must match tblGOMenuNames.sModule_id.  This is only for the menu and page-level security. For anything else, moDatabase.sCurProgram_nm has to be used
        public const string WEB_MODULE_PLATINUM_ID = "WBPL";

		public const string PRINTER_FRIENDLY_PAGE_NAME = "GridViewer.aspx";
		public const string PRINTER_FRIENDLY_CHART_PAGE_NAME = "ChartViewer.aspx";
		public const string WORKORDER_PAGE_NAME = "workorder.aspx";

		public const string ANNOUNCEMENT_FILE_NAME = "Announcement.txt";

		public const string LOCAL_DATE_FIELD_ON_MASTER = "txtLocal_dt";

		public const string CSS_TAB_BUTTON = "TabButton";
		public const string CSS_ACTIVE_TAB_BUTTON = "ActiveTabButton";


		// OBJECTS THAT ARE GLOBALLY USED :
		// In Windows environtment, global objects OK.  However, in ASP, each entry will create unique objects.
		//
		//public static clsCaption goCaption;			These are in clsDatabase
		//public static clsMessage goMessage;
		//public static clsString goString;

		public static clsConstant goConstant;
		public static clsAPConstant goAPConstant;
		public static clsARConstant goARConstant;
		public static clsBRConstant goBRConstant;
		public static clsGLConstant goGLConstant;
		public static clsIVConstant goIVConstant;
		public static clsJCConstant goJCConstant;
		public static clsPOConstant goPOConstant;
		public static clsPRConstant goPRConstant;
		public static clsRMConstant goRMConstant;
		public static clsSOConstant goSOConstant;
		public static clsWOConstant goWOConstant;
		public static clsFile goFile;
		public static clsDynastyUtility goUtility;
		public static clsCompany goCompany;
		public static clsRule goRule;
		public static clsStatus goStatus;
		public static clsFileIO goFileIO;
		public static clsNPConstant goNPConstant;
		public static clsFund goFund;
		public static clsFAConstant goFAConstant;
		public static clsBalanceHistory goBalanceHistory;
        public static clsBin goBin;
        public static clsInventory goInventory;

		// Session ID
		//
		public struct udtSessionType
		{

            private int iSession_num; // Dummy field. one variable is required.

            // parameters passed amongst pages.
            public string DSN { get { return "sDSN"; } }
            public string USER_CODE { get { return "sUser_cd"; } }
            public string SERVER_NAME { get { return "sServer_nm"; } }
            public string DATABASE_NAME { get { return "sDatabase_nm"; } }
            public string LANGUAGE_CODE { get { return "sLanguage_cd"; } }
            public string ENTITY_CODE { get { return "sEntity_cd"; } }
            public string ITEM_CODE { get { return "sItem_cd"; } }
            public string GENERAL_VALUE { get { return "sGeneralValue"; } }
            public string CALLING_FIELD_NAME { get { return "sCallingField_nm"; } }
            public string CALLING_PAGE_NAME { get { return "sCallingPage_nm"; } }
            public string CALLING_MENU_NAME { get { return "sCallingMenu_nm"; } }
            public string CALLING_MENU_ID { get { return "sCallingMenu_id"; } }
            public string TRANSACTION_NUM { get { return "iTransaction_num"; } }
            public string IO_STREAM { get { return "IOStream"; } }
            public string PDF_FILE_NAME { get { return "ABS"; } } // Something not meaningful because this shows in URL QueryString to ReportViewer.aspx
            public string CURRENT_TOP_MENU_ID { get { return "Menu ID"; } }
            public string PAGE_NAME { get { return "sPage_nm"; } }
            public string OFFICE_CODE { get { return "sOffice_cd"; } }
            public string CURRENT_MENU_ID { get { return "sCurrentMenu_id"; } }
            public string ARRAY_LIST_1 { get { return "sArrayList_1"; } }
            public string ARRAY_LIST_2 { get { return "sArrayList_2"; } }
            public string ARRAY_LIST_3 { get { return "sArrayList_3"; } }
            public string READY_ONLY { get { return "iReadOnly_fl"; } }
            public string SQL { get { return "sSQL"; } }
            public string LOCAL_DATE { get { return "sLocal_dt"; } }

            public string RDLC_REPORT_ID { get { return "RDLC_SP_PARAMETERS"; } }               // report-id for MS report service. Read the comments in MSReportViewer.aspx.vb.
            public string RDLC_SP_PARAMETERS { get { return "iTransaction_typ"; } }             // stored procedure parameter list for MS report service.
            public string RDLC_REPORT_PARAMETERS { get { return "RDLC_REPORT_PARAMETERS"; } }   // report parameter list for MS report service.

            // parameters passed to reporting pages from MyFavorites menu.
            public string RO_TRANSACTION_TYPE { get { return "iTransaction_typ"; } }
            public string RO_STATUS_TYPE { get { return "iStatus_typ"; } } // 1(open) + 10(hold) + 100(void) + 1000(others)
            public string RO_FORM_NAME { get { return "sForm_nm"; } }
            public string RO_APPLY_DATE_FROM { get { return "iApplyFrom_dt"; } }
            public string RO_APPLY_DATE_THRU { get { return "iApplyThru_dt"; } }
            public string RO_ENTRY_DATE_FROM { get { return "iEntryFrom_dt"; } }
            public string RO_ENTRY_DATE_THRU { get { return "iEntryThru_dt"; } }
            public string RO_SUMMARY_TYPE { get { return "iSummary_typ"; } } // 1 { get { return Detail 10 { get { return Summary 100 { get { return Daily 1000 { get { return Monthly

            public string TABLET_MODE { get { return "Tablet"; } }

		}

		public static udtSessionType guSession;

		// Session ID for Crystal Viewer
		//
		public struct udtCRSessionType
		{

			private int iSession_num; // Dummy field. one variable is required.

            public string CR_SELECTION_FORMULA { get { return "CR_SELECTION_FORMULA"; } }
            public string CR_RPT_FILE_NAME { get { return "CR_RPT_FILE_NAME"; } }
            public string CR_FUNCTIONS { get { return "CR_FUNCTIONS"; } }
            public string CR_PARAMETERS { get { return "CR_PARAMETERS"; } }
            public string CR_SORT_ORDERS { get { return "CR_SORT_ORDERS"; } }
            public string CR_USER_ID { get { return "CR_USER_ID"; } }
            public string CR_PASSWORD { get { return "CR_PASSWORD"; } }
            
		}

		public static udtCRSessionType guCRSession;

		public struct udtTreeView
		{

			private int iMenu_num; // Dummy field. one variable is required.

			public const string MENU_DAILY_CASH_PAYMENT = "Daily Payment - Unposted";
			public const string MENU_DAILY_CASH_RECEIPT = "Daily Receipt - Unposted";
			public const string MENU_DAILY_ORDER_REPORT = "Daily Order Report";
			public const string MENU_DAILY_PURCHASE = "Daily Purchase - Unposted";
			public const string MENU_DAILY_PURCHASE_ORDER_REPORT = "Daily PO Report";
			public const string MENU_DAILY_SALES = "Daily Sales - Unposted";
			public const string MENU_MONTHLY_CASH_PAYMENT = "Monthly Cash Payment";
			public const string MENU_MONTHLY_CASH_RECEIPT = "Monthly Cash Receipt";
			public const string MENU_MONTHLY_PURCHASE = "Monthly Purchase";
			public const string MENU_MONTHLY_SALES = "Monthly Sales";
			public const string MENU_PAYABLE_AGING = "Payable Aging";
			public const string MENU_RECEIVABLE_AGING = "Receivable Aging";
			public const string MENU_WEEKLY_CASH_PAYMENT = "Weekly Cash Payment";
			public const string MENU_WEEKLY_CASH_RECEIPT = "Weekly Cash Receipt";
			public const string MENU_WEEKLY_PURCHASE = "Weekly Purchase";
			public const string MENU_WEEKLY_SALES = "Weekly Sales";

		}

		public static udtTreeView guTreeView;

		// Spread open type
		//
		public struct udtSpreadStyleType
		{
			public string sTable_nm;
			public string sForm_nm;
			public string sFormCaption;
			public string sQuery;
			public string sKeyValue;
			public int iFormIndex_num;
		}

		public static udtSpreadStyleType guSpreadStyle;

		// Segmented items entry vars.
		//
		public struct udtSegmentedItemType
		{

			public string[,] sSegmentedData;
			public int iManufacturer_col;
			public int iBrand_col;
			public int iModel_col;
			public int iStyle_col;
			public int iColor_col;
			public int iSize_col;
			public int iItemCode_col;
			public int iQty_col;
			public int iTotalDetail_col;

		}

		public struct udtButtonColors
		{
			public System.Drawing.Color oBackColor;
			public System.Drawing.Color oForeColor;
			public System.Drawing.Color oActiveBackColor;
			public System.Drawing.Color oActiveForeColor;
		}
		public static udtButtonColors guTabButtonColors;

		public const int CHART_TYPE_LINE_2D = 1;
		public const int CHART_TYPE_LINE_3D = 2;
		public const int CHART_TYPE_AREA_2D = 3;
		public const int CHART_TYPE_AREA_3D = 4;
		public const int CHART_TYPE_STEP_2D = 5;
		public const int CHART_TYPE_STEP_3D = 6;
		public const int CHART_TYPE_BAR_2D = 7;
		public const int CHART_TYPE_BAR_3D = 8;

	}

}
