﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Local;
using Dynasty.Database;

namespace Dynasty.ASP
{
	internal static class modFormUtility
	{
		// PURPOSE : Check if data has been changed.
		//
		public static bool CheckForConcurrency(clsRecordset cur_set, string last_user, DateTime last_update)
		{
			if (cur_set.EOF() == false)
			{
				if (last_user != cur_set.sField("sLastUpdate_id") || last_update != cur_set.dtField("dtLastUpdate_dt"))
				{
					return false;
				}
			}

			return true;
		}

		public static bool IsReservedRecord(ref clsDatabase cur_db, string key_id, bool reserved_fl)
		{

			bool return_value = false;

			return_value = reserved_fl;     // At this point, no extra logic is involved.

			return return_value;

		}

		//  This is to delete the current record on the screen.
		//
		public static bool RecordDelete(ref clsDatabase cur_db, int screen_type, string key_value, string key_field_name, string main_table, string detail_table, string restriction_clause, int trx_type)
		{
			bool return_value = false;
			string key_id = "";
			string sql_str = "";
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{

				if (cur_db.ViewOnly() || trx_type == GlobalVar.goConstant.TRX_INVOICE_TYPE || trx_type == GlobalVar.goConstant.TRX_SO_TYPE || trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE || trx_type == GlobalVar.goConstant.TRX_PO_TYPE) // These cannot be deleted because qty-committement
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.CANNOT_DELETE_THIS_REC);
					return return_value;
				}
				else if (trx_type == GlobalVar.goConstant.TRX_MULTI_JOURNAL_TYPE)
                {
					// Multi-journals can be deleted,
                }
				else if (!cur_db.bDeleteTransactionIsAllowed && screen_type == GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE)
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.CANNOT_DELETE_TRX);
					return return_value;
				}

				// Check if key-id and table name are filled.
				// This checking is only for the programmers.
				// This should not happen in production at all.
				//
				if (GlobalVar.goUtility.IsEmpty(GlobalVar.goUtility.STrim(key_field_name)))
				{
					modDialogUtility.DisplayBox(ref cur_db, "Key field name is not set. ");
					return return_value;
				}
				else if (GlobalVar.goUtility.IsEmpty(GlobalVar.goUtility.STrim(main_table)))
				{
					modDialogUtility.DisplayBox(ref cur_db, "Main table name is not set.");
					return return_value;
				}

				if (GlobalVar.goUtility.IsDateField(key_field_name))
				{
					if (GlobalVar.goUtility.SInStr(key_value, "/") > 0)
					{
						key_id = GlobalVar.goUtility.ToStr(o_gen.ToNumDate(key_value));
					}
					else
					{
						key_id = GlobalVar.goUtility.ToStr(GlobalVar.goUtility.ToValue(key_value));
					}
				}
				else if (GlobalVar.goUtility.IsNumericField(key_field_name))
				{
					key_id = GlobalVar.goUtility.ToStr(GlobalVar.goUtility.ToValue(key_value));
				}
				else
				{
					key_id = "'" + key_value + "'";
				}

				sql_str = "DELETE FROM " + main_table;
				sql_str += " WHERE " + key_field_name + " = " + key_id;
				sql_str += GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(restriction_clause), " AND " + restriction_clause, "");

				if (!cur_set.CreateSnapshot(GlobalVar.goUtility.SReplace(sql_str, "DELETE FROM", "SELECT * FROM")))
				{
					return false;
				}
				else if (cur_set.EOF())
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.CANNOT_DELETE_THIS_REC);
					return false;
				}

				if (!cur_db.ExecuteSQL(sql_str))
				{
					return return_value;
				}
				else if (GlobalVar.goUtility.IsNonEmpty(GlobalVar.goUtility.STrim(detail_table)))
				{

					sql_str = "DELETE FROM " + detail_table;
					sql_str += " WHERE " + key_field_name + " = " + key_id;
					if (screen_type == GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE && trx_type > 0 && trx_type != GlobalVar.goConstant.TRX_JOURNAL_TYPE && trx_type != GlobalVar.goConstant.TRX_MULTI_JOURNAL_TYPE)
					{
						sql_str += " AND iTransaction_typ = " + trx_type.ToString();
					}
					if (!cur_db.ExecuteSQL(sql_str))
					{
						return return_value;
					}

				}

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(RecordDelete)");

			}

			return return_value;

		}

		// Creates a snapshot, and send it to the calling routine.
		// This is used to grab a record and display it on the given screen.
		//
		public static bool RecordRead(ref clsDatabase cur_db, ref clsRecordset cur_set, string key_value, string table_name, string key_field_name, string previous_key, string restriction_clause, ref int matching_type)
		{

			bool return_value = false;
			string sql_str = "";
			string current_value = "";
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			try
			{

				// Check if key-id and table name are filled.
				// This checking is only for the programmers.
				// This should not happen in production at all.
				//
				if (GlobalVar.goUtility.IsEmpty(GlobalVar.goUtility.STrim(key_field_name)))
				{
					modDialogUtility.DisplayBox(ref cur_db, "Please, assign a value to txtKeyField_nm.Text.");
					return return_value;
				}
				else if (GlobalVar.goUtility.IsEmpty(GlobalVar.goUtility.STrim(table_name)))
				{
					modDialogUtility.DisplayBox(ref cur_db, "Please, assign a value to txtTable_nm.Text.");
					return return_value;
				}

				key_value = GlobalVar.goUtility.SReplace(key_value, GlobalVar.goConstant.DOUBLE_QUOTE, ""); // This is necessary because a page can called from other app that have no knowledge of our rules.
				key_value = GlobalVar.goUtility.SReplace(key_value, GlobalVar.goConstant.SINGLE_QUOTE, "");

				if (matching_type == GlobalVar.goConstant.MATCHING_RECORD_TYPE)
				{
					if (GlobalVar.goUtility.IsDateField(key_field_name))
					{
						if (GlobalVar.goUtility.SInStr(key_value, "/") > 0)
						{
							current_value = GlobalVar.goUtility.ToStr(o_gen.ToNumDate(key_value));
						}
						else
						{
							current_value = GlobalVar.goUtility.ToStr(GlobalVar.goUtility.ToInteger(key_value));
						}
					}
					else if (GlobalVar.goUtility.IsNumericField(key_field_name))
					{
						current_value = GlobalVar.goUtility.ToStr(GlobalVar.goUtility.ToInteger(key_value));
					}
					else
					{
						current_value = "'" + key_value + "'";
					}
				}
				else if (matching_type == GlobalVar.goConstant.PREVIOUS_RECORD_TYPE)
				{
					if (GlobalVar.goUtility.IsDateField(key_field_name))
					{
						if (GlobalVar.goUtility.SInStr(previous_key, "/") > 0)
						{
							current_value = GlobalVar.goUtility.ToStr(o_gen.ToNumDate(previous_key));
						}
						else
						{
							current_value = GlobalVar.goUtility.ToStr(GlobalVar.goUtility.ToInteger(previous_key));
						}
					}
					else if (GlobalVar.goUtility.IsNumericField(key_field_name))
					{
						if (GlobalVar.goUtility.ToInteger(previous_key) == 0)
						{
							matching_type = GlobalVar.goConstant.FIRST_RECORD_TYPE;
						}
						current_value = GlobalVar.goUtility.ToStr(GlobalVar.goUtility.ToInteger(previous_key));
					}
					else
					{
						if (GlobalVar.goUtility.IsEmpty(previous_key))
						{
							matching_type = GlobalVar.goConstant.FIRST_RECORD_TYPE;
						}
						current_value = "'" + previous_key + "'";
					}
				}
				else
				{
					if (GlobalVar.goUtility.IsDateField(key_field_name))
					{
						if (GlobalVar.goUtility.SInStr(previous_key, "/") > 0)
						{
							current_value = GlobalVar.goUtility.ToStr(o_gen.ToNumDate(previous_key));
						}
						else
						{
							current_value = GlobalVar.goUtility.ToStr(GlobalVar.goUtility.ToInteger(previous_key));
						}
					}
					else if (GlobalVar.goUtility.IsNumericField(key_field_name))
					{
						current_value = GlobalVar.goUtility.ToStr(GlobalVar.goUtility.ToInteger(previous_key));
					}
					else
					{
						current_value = "'" + previous_key + "'";
					}
				}

				restriction_clause = GlobalVar.goUtility.STrim(restriction_clause);

				if (matching_type == GlobalVar.goConstant.MATCHING_RECORD_TYPE)
				{
					sql_str = "SELECT * FROM " + table_name;
					sql_str += " WHERE " + key_field_name + " = " + current_value;
					sql_str += GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(restriction_clause), " AND " + restriction_clause, "").ToString();
				}
				else if (matching_type == GlobalVar.goConstant.NEXT_RECORD_TYPE)
				{
					sql_str = "SELECT * FROM " + table_name;
					sql_str += " WHERE " + key_field_name + " = ( SELECT MIN(" + key_field_name + ")";
					sql_str += " FROM " + table_name;
					sql_str += " WHERE " + key_field_name + " > " + current_value;
					sql_str += GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(restriction_clause), " AND " + restriction_clause, "").ToString() + ")";
					sql_str += GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(restriction_clause), " AND " + restriction_clause, "").ToString();
				}
				else if (matching_type == GlobalVar.goConstant.PREVIOUS_RECORD_TYPE)
				{
					sql_str = "SELECT * FROM " + table_name;
					sql_str += " WHERE " + key_field_name + " = ( SELECT MAX(" + key_field_name + ")";
					sql_str += " FROM " + table_name;
					sql_str += " WHERE " + key_field_name + " < " + current_value;
					sql_str += GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(restriction_clause), " AND " + restriction_clause, "").ToString() + ")";
					sql_str += GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(restriction_clause), " AND " + restriction_clause, "").ToString();
				}
				else if (matching_type == GlobalVar.goConstant.LAST_RECORD_TYPE)
				{
					sql_str = "SELECT * FROM " + table_name;
					sql_str += " WHERE " + key_field_name + " = ( SELECT MAX(" + key_field_name + ")";
					sql_str += " FROM " + table_name;
					sql_str += GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(restriction_clause), " WHERE " + restriction_clause, "").ToString() + ")";
					sql_str += GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(restriction_clause), " AND " + restriction_clause, "").ToString();
				}
				else if (matching_type == GlobalVar.goConstant.FIRST_RECORD_TYPE)
				{
					sql_str = "SELECT * FROM " + table_name;
					sql_str += " WHERE " + key_field_name + " = ( SELECT MIN(" + key_field_name + ")";
					sql_str += " FROM " + table_name;
					sql_str += GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(restriction_clause), " WHERE " + restriction_clause, "").ToString() + ")";
					sql_str += GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(restriction_clause), " AND " + restriction_clause, "").ToString();
				}
				else
				{
					return return_value;
				}

				if (!cur_set.CreateSnapshot(sql_str))
				{
					cur_set.Release();
					return return_value;
					//ElseIf cur_set.EOF() Then
					//    cur_set.Release()
					//    Exit Function
				}
				else if (cur_set.IsEmpty())
				{
					cur_set.Release();
					return return_value;
				}

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(RecordRead)");
				cur_set.Release();

			}

			return return_value;

		}

		// PURPOSE : TO create where-clause which is used when a record is pulled.
		//
		public static bool CreateWhereClause(ref clsDatabase cur_db, string key_id, string key_field_name, string restriction_clause, ref string where_str)
		{

			bool return_value = false;
			string temp_key = "";
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			try
			{
				restriction_clause = GlobalVar.goUtility.STrim(restriction_clause);

				where_str = "";

				if (GlobalVar.goUtility.IsNonEmpty(GlobalVar.goUtility.STrim(key_field_name))) // If data field name exists
				{
					if (GlobalVar.goUtility.IsDateField(key_field_name))
					{
						if (GlobalVar.goUtility.SInStr(key_id, "/") > 0)
						{
							temp_key = GlobalVar.goUtility.ToStr(o_gen.ToNumDate(key_id));
						}
						else
						{
							temp_key = GlobalVar.goUtility.ToStr(GlobalVar.goUtility.ToValue(key_id));
						}
					}
					else if (GlobalVar.goUtility.IsNumericField(key_field_name))
					{
						temp_key = GlobalVar.goUtility.ToStr(GlobalVar.goUtility.ToValue(key_id));
					}
					else
					{
						temp_key = "'" + key_id + "'";
					}
					where_str = " WHERE " + key_field_name + " = " + temp_key;
					where_str = where_str + GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(restriction_clause), " AND " + restriction_clause, "").ToString();
				}

				return_value = true;

			}
			catch (Exception ex)
			{

			}

			return return_value;

		}

		// This routine sets a restriction to look up a record.
		// This restriction is used when a record is searced.
		//
		public static string SetDefaultRestriction(ref clsDatabase cur_db, int screen_type, int transaction_type)
		{

			string return_value = "";
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			string restriction_clause = "";

			// Use imperative goto when error occurs because some screen may not have
			// form-level variables used here.
			//
			try
			{

				if (screen_type == GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE)
				{

					// Regular staff can look up only his own record if bBlockTransaction_fl is on.
					// manager and viewers can see all the transactions.
					// This rule should be applied to all transactions.
					//
					if (cur_db.ViewOnly() || cur_db.iUserType_id >= clsConstant.USER_SUPERVISOR_TYPE)
					{
						restriction_clause = "";
					}
					else if (cur_db.uSecurity.bBlockTransaction_fl)
					{
						restriction_clause = "sLastUpdate_id = '" + cur_db.sUser_cd + "'";
					}
					else
					{
						restriction_clause = "";
					}

					// Transaction type should be supplied except G/L.
					//
					if (transaction_type >= GlobalVar.goConstant.TRX_PHYSICAL_TYPE && transaction_type != GlobalVar.goConstant.TRX_PRJOURNAL_TYPE)
					{
						restriction_clause += GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(restriction_clause), " AND ", "").ToString() + " iTransaction_typ = " + transaction_type;
					}

                    if (cur_db.bRestrictLocation_fl && GlobalVar.goUtility.IsNonEmpty(o_gen.GetDefaultLocationCode("")))
                    {
                        if (transaction_type == GlobalVar.goConstant.TRX_PHYSICAL_TYPE || transaction_type == GlobalVar.goConstant.TRX_SPOILAGE_TYPE
							|| transaction_type == GlobalVar.goConstant.TRX_IV_INTERNAL_USE_TYPE || transaction_type == GlobalVar.goConstant.TRX_IV_SALES_TYPE 
							|| transaction_type == GlobalVar.goConstant.TRX_IV_SALES_RETURN_TYPE || transaction_type == GlobalVar.goConstant.TRX_IV_PURCHASE_TYPE 
							|| transaction_type == GlobalVar.goConstant.TRX_IV_PURCHASE_RETURN_TYPE || transaction_type == GlobalVar.goConstant.TRX_TRANSFER_IN_TYPE)
                        {
                            restriction_clause += GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(restriction_clause), " AND ", "").ToString() + " sToLocation_cd = '" + o_gen.GetDefaultLocationCode("") + "'";
                        }
                        else if (transaction_type == GlobalVar.goConstant.TRX_INVOICE_TYPE || transaction_type == GlobalVar.goConstant.TRX_CM_TYPE || transaction_type == GlobalVar.goConstant.TRX_SO_TYPE 
							|| transaction_type == GlobalVar.goConstant.TRX_QUOTE_TYPE || transaction_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE || transaction_type == GlobalVar.goConstant.TRX_DM_TYPE 
							|| transaction_type == GlobalVar.goConstant.TRX_PO_TYPE || transaction_type == GlobalVar.goConstant.TRX_PO_QUOTE_TYPE || transaction_type == GlobalVar.goConstant.TRX_IV_MANUFACTURING_TYPE)
                        {
                            restriction_clause += GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(restriction_clause), " AND ", "").ToString() + " sLocation_cd = '" + o_gen.GetDefaultLocationCode("") + "'";
						}
					}

					// Sales staff sees/creates its own transaction only.
					//
					if (GlobalVar.goUtility.IsSalesStaff(cur_db) 
						&& (transaction_type == GlobalVar.goConstant.TRX_INVOICE_TYPE || transaction_type == GlobalVar.goConstant.TRX_CM_TYPE || transaction_type == GlobalVar.goConstant.TRX_SO_TYPE || transaction_type == GlobalVar.goConstant.TRX_QUOTE_TYPE))
                    {
						restriction_clause += GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(restriction_clause), " AND ", "").ToString() + " sSalesrep_cd = '" + cur_db.sUser_cd + "'";
					}

				}
                else
				{
					restriction_clause = "";
				}

				return_value = restriction_clause;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(SetDefaultRestriction)");

			}

			return return_value;

		}

		// To open a record for update.
		//
		public static bool RecordOpen(ref clsDatabase cur_db, ref clsRecordset cur_set, string key_id, string restriction_clause, string main_table, string key_field_name)
		{

			bool return_value = false;
			string sql_str = "";
			string where_str = "";

			try
			{
				sql_str = "SELECT * FROM " + main_table;

				if (!CreateWhereClause(ref cur_db, key_id, key_field_name, restriction_clause, ref where_str))
				{
					return return_value;
				}
				else if (!cur_set.CreateSnapshot(sql_str + where_str))
				{
					return return_value;
				}

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(RecordOpen)");
				cur_set.Release();

			}

			return return_value;

		}

	}

}
