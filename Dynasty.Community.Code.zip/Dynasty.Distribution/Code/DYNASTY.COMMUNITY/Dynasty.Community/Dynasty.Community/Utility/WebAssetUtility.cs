﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//

using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Database;

namespace Dynasty.ASP
{
	internal static class modWebAssetUtility
	{

		public static void LoadFAType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_blank_fl = false)
		{

			clsRecordset cur_set = new clsRecordset(ref cur_db);
			ArrayList item_list = new ArrayList();

			if (add_blank_fl)
			{
				item_list.Add(new clsComboBoxItem("", "0"));
			}

			if (!cur_set.CreateSnapshot("SELECT * FROM tblFAAssetType ORDER BY sDescription"))
			{
				return;
			}
			else if (!add_blank_fl & cur_set.EOF())
			{
				return;
			}

			while (!cur_set.EOF())
			{
				item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iAsset_typ").ToString()));
				cur_set.MoveNext();
			}

			modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

		}

		public static void LoadFAStatus(ref List<Models.clsCombobox> cur_box, bool add_blank_fl = false)
		{

			ArrayList item_list = new ArrayList();

			if (add_blank_fl)
			{
				item_list.Add(new clsComboBoxItem("", "0"));
			}

			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.STATUS_OPERATIONAL, GlobalVar.goFAConstant.STATUS_OPERATIONAL_NUM.ToString()));
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.STATUS_RENTED_OUT, GlobalVar.goFAConstant.STATUS_RENTED_OUT_NUM.ToString()));
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.STATUS_IN_REPAIRSHOP, GlobalVar.goFAConstant.STATUS_IN_REPAIRSHOP_NUM.ToString()));
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.STATUS_IN_INSPECTION, GlobalVar.goFAConstant.STATUS_IN_INSPECTION_NUM.ToString()));
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.STATUS_SUSPENDED, GlobalVar.goFAConstant.STATUS_SUSPENDED_NUM.ToString()));
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.STATUS_RETIRED, GlobalVar.goFAConstant.STATUS_RETIRED_NUM.ToString()));

			modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

		}

		public static void LoadFADepreciationMethods(ref List<Models.clsCombobox> cur_box, bool add_blank_fl = false, bool depreciable_only_fl = false, bool disposable_only_fl = false)
		{

			ArrayList item_list = new ArrayList();

			if (add_blank_fl)
			{
				item_list.Add(new clsComboBoxItem("", "0"));
			}

			if (depreciable_only_fl)
			{

			}
			else if (disposable_only_fl)
			{
				item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.METHOD_NOT_DEPRECIABLE, GlobalVar.goFAConstant.METHOD_NOT_DEPRECIABLE_NUM.ToString()));
			}
			else
			{
				item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.METHOD_NOT_DEPRECIABLE, GlobalVar.goFAConstant.METHOD_NOT_DEPRECIABLE_NUM.ToString()));
				item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.METHOD_DISPOSED, GlobalVar.goFAConstant.METHOD_DISPOSED_NUM.ToString()));
			}

			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.METHOD_STRAIGHT_LINE, GlobalVar.goFAConstant.METHOD_STRAIGHT_LINE_NUM.ToString()));
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.METHOD_DECLINING_BALANCE, GlobalVar.goFAConstant.METHOD_DECLINING_BALANCE_NUM.ToString()));
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.METHOD_DBL_DECLINING_BALANCE, GlobalVar.goFAConstant.METHOD_DBL_DECLINING_BALANCE_NUM.ToString()));
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.METHOD_150_DECLINING_BALANCE, GlobalVar.goFAConstant.METHOD_150_DECLINING_BALANCE_NUM.ToString()));
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.METHOD_SUM_OF_YEARS_DIGITS, GlobalVar.goFAConstant.METHOD_SUM_OF_YEARS_DIGITS_NUM.ToString()));

			modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

		}

		public static void LoadFAPropertyType(ref List<Models.clsCombobox> cur_box, bool add_blank_fl = false, bool depreciable_only_fl = false)
		{

			ArrayList item_list = new ArrayList();

			if (add_blank_fl)
			{
				item_list.Add(new clsComboBoxItem("", "0"));
			}

			if (!depreciable_only_fl)
			{
				item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.PROPERTY_ON_LOAN, GlobalVar.goFAConstant.PROPERTY_ON_LOAN_NUM.ToString()));
			}
			if (!depreciable_only_fl)
			{
				item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.PROPERTY_ON_LEASE, GlobalVar.goFAConstant.PROPERTY_ON_LEASE_NUM.ToString()));
			}
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.PROPERTY_TO_PURCHASE, GlobalVar.goFAConstant.PROPERTY_TO_PURCHASE_NUM.ToString()));
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.PROPERTY_PURCHASED, GlobalVar.goFAConstant.PROPERTY_PURCHASED_NUM.ToString()));

			modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

		}

		public static void LoadFAQueryType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_general_fl = false)
		{

			ArrayList item_list = new ArrayList();

			item_list.Add(new clsComboBoxItem("", ""));

			if (add_general_fl)
			{
				item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_GENERAL_INFO, cur_db.oLanguage.oString.STR_GENERAL_INFO));
			}

			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.QUERY_DEPRECIATION_INFO, GlobalVar.goFAConstant.QUERY_DEPRECIATION_INFO));
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.QUERY_DISPOSAL_INFO, GlobalVar.goFAConstant.QUERY_DISPOSAL_INFO));
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.QUERY_DISPOSED_INFO, GlobalVar.goFAConstant.QUERY_DISPOSED_INFO));
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.QUERY_PAYMENT_INFO, GlobalVar.goFAConstant.QUERY_PAYMENT_INFO));
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.QUERY_SERVICE_INFO, GlobalVar.goFAConstant.QUERY_SERVICE_INFO));
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.QUERY_INSURANCE_INFO, GlobalVar.goFAConstant.QUERY_INSURANCE_INFO));

			modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

		}

		public static void LoadFAServiceQueryType(ref List<Models.clsCombobox> cur_box)
		{

			ArrayList item_list = new ArrayList();

			item_list.Add(new clsComboBoxItem("", ""));

			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.SERVICE_QUERY_HISTORY, GlobalVar.goFAConstant.SERVICE_QUERY_HISTORY));
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.SERVICE_QUERY_NO_HISTORY, GlobalVar.goFAConstant.SERVICE_QUERY_NO_HISTORY));
			item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.SERVICE_QUERY_UPCOMING, GlobalVar.goFAConstant.SERVICE_QUERY_UPCOMING));

			modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

		}

	}

}
