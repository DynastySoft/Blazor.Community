﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Database;
using Dynasty.Local;
using System.Net.Mail;
using Dynasty.ASP.Login;
using Microsoft.AspNetCore.Components;

namespace Dynasty.ASP
{
	internal static class modWebUtility
	{

		public static bool SystemInit(ref clsDatabase cur_db, Models.clsUser cur_user, bool control_panel_fl = false)
		{
			bool return_value = false;
			bool first_time_try = (cur_db.IsConnected() ==  false);

			clsGeneral o_gen = new clsGeneral(ref cur_db);

			cur_db.bIsWEBVersion_fl = true;             // This will disable Windows-based error message. 9/7/2011

#if (SaaS)
            cur_db.bIsSAASVersion_fl = true;
#else
            cur_db.bIsSAASVersion_fl = false;
#endif

            cur_db.bUseSQLProcedures_fl = true;         // Set this when the stored procedures are available. 5/20/2025
                                                        // In SaaS, this is reset individually in tblGOCCN

#if (EDU)
			cur_db.bUseSQLProcedures_fl = false;		// Education license does not support stored procedures   
#elif (COMMUNITY)
            cur_db.bUseSQLProcedures_fl = false;
			cur_db.uSecurity.bUseComboboxForCashAccount_fl = true;
#endif


            modGeneralUtility.GetHomeDirectory(ref cur_db);

			if (first_time_try)
			{
				modGeneralUtility.CreateSubDirectories(ref cur_db); // This will create default dir w/o dsn
			}

			if (OpenDatabase(ref cur_db, cur_user) == false)
			{
				return false;
			}
			else
			{
				if (modGeneralUtility.SetCompanyInfo(ref cur_db) == false)
                {
					return false;
                }
			}

			CopyUserCredentials(ref cur_db, cur_user);      // Reset it with new user info after SetCompanyInfo() is called

			if (control_panel_fl == false)
            {
				if (GlobalVar.goUtility.DatabaseIsOnHold(cur_db))
				{
					modDialogUtility.DisplayBox(ref cur_db, "Database is inactive.");
					return false;
				}
			}

			if (first_time_try)
            {
				modGeneralUtility.CreateSubDirectories(ref cur_db); // This will create all local dir for dsn and language
			}

			modSecurity.GetAllSecurityOptions(ref cur_db, cur_db.sCurProgram_nm);
			o_gen.GetUserProfile();

			modGeneralUtility.GetHomeDirectory(ref cur_db);         // 05/07/2021   Do not delete. FOlder info is reset in OpenDatabase().

			SetCustomOptions(ref cur_db); // This has to be the last line.
			return true;

		}

		public static bool OpenDatabase(ref clsDatabase cur_db, Models.clsUser cur_user, string company_name = "")
		{
			CopyUserCredentials(ref cur_db, cur_user);

#if (SubModuleName)
            cur_db.sCurProgram_nm = SUB_MODULE_ID; 
#elif (COMMUNITY)
			cur_db.sCurProgram_nm = GlobalVar.goConstant.DYMENU_NAME;		// Do not change this to GO or higher
#else
			cur_db.sCurProgram_nm = GlobalVar.goConstant.GOMENU_NAME;		// This can be changed later
#endif

            if (GlobalVar.goCompany.OpenDatabase(ref cur_db, company_name) == false)
            {
                return false;
            }

			CopyUserCredentials(ref cur_db, cur_user);		// Reset it with new user info

			return true;
		}

		public static void CloseDatabase(ref clsDatabase cur_db)
		{

            GlobalVar.goCompany.CloseDatabase(ref cur_db);

		}

		public static bool SetCustomOptions(ref clsDatabase cur_db)
		{

			bool return_value = false;

			try
			{

				// If you need to set the system options for your company regardless of Dynasty system options, this is the place.
				//
				if (cur_db.IsConnected())
				{




				}

				return_value = true;

			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(SetCustomOptions)");
			}

			return return_value;

		}

		public static void CopyUserCredentials(ref clsDatabase cur_db, Models.clsUser cur_user)
        {
			if (cur_db.IsConnected())
            {
				if (GlobalVar.goUtility.IsNonEmpty(cur_db.sUser_cd) && cur_db.iUserType_id == 0)
                {
					if (cur_db.CheckUser(cur_db.sUser_cd, ""))
                    {
						// let it go.  This is for the pages openned in another tab
                    }
                }

				modCommonUtility.NeedToResizeItemCodeColumn(ref cur_db);

				cur_user.bConnected_fl = true;

				cur_user.sItemCodeCSS = cur_db.sItemCodeSizeCSS;
				cur_user.sAPItemDescCSS = cur_db.sAPDescSizeCSS;
				cur_user.sARItemDescCSS = cur_db.sARDescSizeCSS;

				cur_user.sConnectionString = cur_db.sConnectionString;
				cur_user.sUser_cd = cur_db.sUser_cd;
				cur_user.sUser_nm = cur_db.sUser_nm;
				cur_user.sPassword = "";
				cur_user.sCompany_nm = cur_db.sCompany_nm;
				cur_user.sServer_nm = cur_db.sServer_nm;
				cur_user.sDatabase_nm = cur_db.sDatabase_nm;
				cur_user.sCCN = cur_db.sCCN;
				cur_user.sDSN = cur_db.sDSN;
				cur_user.sCCNServer_nm = cur_db.sCCNServer_nm;
				cur_user.sCCNDatabase_nm = cur_db.sCCNDatabase_nm;
				cur_user.sLanguage_cd = cur_db.sLanguage_cd;
				cur_user.sEmailAddress = cur_db.sEmailAddress;
				cur_user.sOffice_cd = cur_db.sOffice_cd;
				cur_user.sPIN = cur_db.sPIN;
				cur_user.sEmployee_cd = cur_db.sEmployee_cd;
				cur_user.bRestrictLocation_fl = cur_db.bRestrictLocation_fl;
				cur_user.bAdmin_fl = cur_db.bAdmin_fl;
				cur_user.bAccounting_fl = cur_db.bAccounting_fl;
				cur_user.bSales_fl = cur_db.bSales_fl;
				cur_user.bAR_fl = cur_db.bAR_fl;
				cur_user.bPurchasing_fl = cur_db.bPurchasing_fl;
				cur_user.bAP_fl = cur_db.bAP_fl;
				cur_user.bWH_fl = cur_db.bWH_fl;
				cur_user.bHelpdesk_fl = cur_db.bHelpdesk_fl;
				cur_user.bTemp_fl = cur_db.bTemp_fl;
				cur_user.iUserType_id = cur_db.iUserType_id;
				cur_user.sUserGroup_cd = cur_db.sUserGroup_cd;
				cur_user.sHomeDirectory_nm = cur_db.uDirectory.sHomeDirectory_nm;
				cur_user.sReportDirectory_nm = cur_db.uDirectory.sReportDirectory_nm;
				cur_user.iMoney_typ = cur_db.iMoney_typ;
				cur_user.iDate_typ = cur_db.iDate_typ;
				cur_user.iBatch_num = cur_db.iBatch_num;
				cur_user.bBatchEnabled_fl = cur_db.AllowBatchEntry();
				cur_user.sLocation_cd = cur_db.sCurLocation_cd;

				cur_user.bUseSQLProcedures_fl = cur_db.bUseSQLProcedures_fl;
				cur_user.bUseDatePicker_fl = cur_db.bUseDatePicker_fl;

				cur_user.bBlockTransaction_fl = cur_db.uSecurity.bBlockTransaction_fl;
				cur_user.bUseComboboxForCashAccount_fl = cur_db.uSecurity.bUseComboboxForCashAccount_fl;

                // Respect the current setting
                //
                cur_user.bDisableDescription_fl = (cur_user.bDisableDescription_fl || cur_db.uPreference.bDisableDescription_fl);
				cur_user.bDisableQuantity_fl = (cur_user.bDisableQuantity_fl || cur_db.uPreference.bDisableQuantity_fl);
				cur_user.bDisableUnitCode_fl = (cur_user.bDisableUnitCode_fl || cur_db.uPreference.bDisableUnitCode_fl);
				cur_user.bDisableUnitPrice_fl = (cur_user.bDisableUnitPrice_fl || cur_db.uPreference.bDisableUnitPrice_fl);

				if (GlobalVar.goUtility.IsNonEmpty(cur_db.uPreference.sBackColor))
                {
					cur_user.sBackColor = cur_db.uPreference.sBackColor;
				}
				if (GlobalVar.goUtility.IsNonEmpty(cur_db.uPreference.sColor))
				{
					cur_user.sColor = cur_db.uPreference.sColor;
				}
				if (cur_db.uPreference.iFontSize > 0)
                {
					cur_user.iFontSize = cur_db.uPreference.iFontSize;
				}

			}
			else if (GlobalVar.goUtility.IsEmpty(cur_db.sConnectionString) || GlobalVar.goUtility.IsEmpty(cur_db.sServer_nm) 
				|| GlobalVar.goUtility.IsEmpty(cur_db.sDatabase_nm) || GlobalVar.goUtility.IsEmpty(cur_db.sUser_cd))
            {
				cur_db.sConnectionString = GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(cur_user.sConnectionString), cur_user.sConnectionString, GlobalVar.gsConnectionString);		// cur_user.sConnectionString;
				cur_db.sUser_cd = cur_user.sUser_cd;
				cur_db.sUser_nm = cur_user.sUser_nm;
				cur_db.sPassword = "";
				cur_db.sCompany_nm = cur_user.sCompany_nm;

				// Respect the first time log-in info.
				if (GlobalVar.goUtility.IsEmpty(cur_db.sServer_nm))
                {
					cur_db.sServer_nm = cur_user.sServer_nm;
				}
				if (GlobalVar.goUtility.IsEmpty(cur_db.sDatabase_nm))
				{
					cur_db.sDatabase_nm = cur_user.sDatabase_nm;
				}
				if (GlobalVar.goUtility.IsEmpty(cur_db.sCCN))
				{
					cur_db.sCCN = GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(cur_user.sCCN), cur_user.sCCN, cur_user.sCompany_nm).ToString();
				}
				if (GlobalVar.goUtility.IsEmpty(cur_db.sDSN))
				{
					cur_db.sDSN = GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(cur_user.sDSN), cur_user.sDSN, cur_user.sCompany_nm).ToString();
				}
				if (GlobalVar.goUtility.IsEmpty(cur_db.sCCNServer_nm))
				{
					cur_db.sCCNServer_nm = cur_user.sCCNServer_nm;
				}
				if (GlobalVar.goUtility.IsEmpty(cur_db.sCCNDatabase_nm))
				{
					cur_db.sCCNDatabase_nm = cur_user.sCCNDatabase_nm;
				}


				cur_db.sLanguage_cd = cur_user.sLanguage_cd;
				cur_db.sEmailAddress = cur_user.sEmailAddress;
				cur_db.sOffice_cd = cur_user.sOffice_cd;
				cur_db.sPIN = cur_user.sPIN;
				cur_db.sEmployee_cd = cur_user.sEmployee_cd;
				cur_db.bRestrictLocation_fl = cur_user.bRestrictLocation_fl;
				cur_db.bAdmin_fl = cur_user.bAdmin_fl;
				cur_db.bAccounting_fl = cur_user.bAccounting_fl;
				cur_db.bSales_fl = cur_user.bSales_fl;
				cur_db.bAR_fl = cur_user.bAR_fl;
				cur_db.bPurchasing_fl = cur_user.bPurchasing_fl;
				cur_db.bAP_fl = cur_user.bAP_fl;
				cur_db.bWH_fl = cur_user.bWH_fl;
				cur_db.bHelpdesk_fl = cur_user.bHelpdesk_fl;
				cur_db.bTemp_fl = cur_user.bTemp_fl;
				cur_db.iUserType_id = cur_user.iUserType_id;
				cur_db.sUserGroup_cd = cur_user.sUserGroup_cd;
				cur_db.uDirectory.sHomeDirectory_nm = cur_user.sHomeDirectory_nm;
				cur_db.uDirectory.sReportDirectory_nm = cur_user.sReportDirectory_nm;
				cur_db.iMoney_typ = cur_user.iMoney_typ;
				cur_db.iDate_typ = cur_user.iDate_typ;
				cur_db.iBatch_num = cur_user.iBatch_num;
				cur_db.sCurLocation_cd = cur_user.sLocation_cd;

				cur_db.bUseSQLProcedures_fl = cur_user.bUseSQLProcedures_fl;
				cur_db.bUseDatePicker_fl = cur_user.bUseDatePicker_fl;

				cur_db.uSecurity.bBlockTransaction_fl = cur_user.bBlockTransaction_fl;
                cur_db.uSecurity.bUseComboboxForCashAccount_fl = cur_user.bUseComboboxForCashAccount_fl;

                // Do not copy these
                //cur_db.sItemCodeSizeCSS = cur_user.sItemCodeCSS;
                //cur_db.sARDescSizeCSS = cur_user.sARItemDescCSS;
                //cur_db.sAPDescSizeCSS = cur_user.sAPItemDescCSS;

                cur_db.bIsWEBVersion_fl = true;

			}

			// Need to preserve the user's language
			//
			cur_db.oLanguage = cur_user.Language;

		}
	}

}
