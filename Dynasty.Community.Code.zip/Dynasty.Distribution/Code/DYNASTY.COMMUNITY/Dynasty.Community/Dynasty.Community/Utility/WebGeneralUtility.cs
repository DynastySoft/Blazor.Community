﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP
{
	internal static class modGeneralUtility
	{
		// Check if the transaction number is still available.
		// If some one already used it, get a new one.
		//
		private static int ShowProgressOnMainProgressBar_max_steps = 0;
		private static int ShowProgressOnMainProgressBar_this_step = 0;

		public static bool CheckTransactionNumber(ref clsDatabase cur_db, bool new_fl, int screen_type, int transaction_type, ref string trx_num)
		{

			bool return_value = false;
			int new_trx_num = 0;
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			try
			{
				if (new_fl && screen_type == GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE)
				{
					new_trx_num = o_gen.GetNextNumber(transaction_type);

					trx_num = new_trx_num.ToString();   //  Get the system-generated number, regardless  09/29/2020

					//if (new_trx_num < GlobalVar.goUtility.ToInteger(trx_num))
					//{
					//	return return_value; // Not expected at all.
					//}
					//else if (new_trx_num > GlobalVar.goUtility.ToInteger(trx_num))
					//{
					//	trx_num = new_trx_num.ToString();
					//}
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CheckTransactionNumber)");
			}

			return return_value;
		}

		public static int ReadNextTransactionNumber(ref clsDatabase cur_db, int trx_typ)
		{

			int return_value = 0;
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			if (trx_typ > 0)
            {
				return_value = o_gen.ReadNextNumber(trx_typ);
			}

			return return_value;

		}

		// disable the Save button in the main toolbar.
		//
		public static void DisableSaveButton(ref clsDatabase cur_db, ref bool modified_fl)
		{

			modified_fl = false;
			//MainForm.cmdSave.Enabled = False

		}

		// PURPOSE : To create the business objects.
		//   
		public static bool InitGlobalObjects(bool re_new_fl = false)
		{

			bool return_value = false;
			try
			{

				if ((!re_new_fl) && (GlobalVar.goCompany != null))
				{
					return true;
				}

				GlobalVar.goConstant = new Dynasty.Local.clsConstant();
				GlobalVar.goAPConstant = new Dynasty.Local.clsAPConstant();
				GlobalVar.goARConstant = new Dynasty.Local.clsARConstant();
				GlobalVar.goBRConstant = new Dynasty.Local.clsBRConstant();
				GlobalVar.goGLConstant = new Dynasty.Local.clsGLConstant();
				GlobalVar.goIVConstant = new Dynasty.Local.clsIVConstant();
				GlobalVar.goJCConstant = new Dynasty.Local.clsJCConstant();
				GlobalVar.goPOConstant = new Dynasty.Local.clsPOConstant();
				GlobalVar.goPRConstant = new Dynasty.Local.clsPRConstant();
				GlobalVar.goRMConstant = new Dynasty.Local.clsRMConstant();
				GlobalVar.goSOConstant = new Dynasty.Local.clsSOConstant();
				GlobalVar.goWOConstant = new Dynasty.Local.clsWOConstant();

				GlobalVar.goFile = new clsFile();
				GlobalVar.goUtility = new clsDynastyUtility();
				GlobalVar.goCompany = new clsCompany();
				GlobalVar.goRule = new clsRule();
				GlobalVar.goStatus = new clsStatus();
				GlobalVar.goFileIO = new clsFileIO();
				GlobalVar.goNPConstant = new clsNPConstant();
				GlobalVar.goFund = new clsFund();
				GlobalVar.goFAConstant = new clsFAConstant();
				GlobalVar.goBalanceHistory = new clsBalanceHistory();
				GlobalVar.goBin = new clsBin();
				GlobalVar.goInventory = new clsInventory();

				GlobalVar.guTabButtonColors.oBackColor = System.Drawing.Color.AliceBlue;
				GlobalVar.guTabButtonColors.oForeColor = System.Drawing.Color.RoyalBlue;
				GlobalVar.guTabButtonColors.oActiveBackColor = System.Drawing.Color.White;
				GlobalVar.guTabButtonColors.oActiveForeColor = System.Drawing.Color.RoyalBlue;

				return_value = true;

				return return_value;

			}
			catch (Exception ex)
			{

			}

			return false;
		}

		public static bool CopyKey(ref clsDatabase cur_db, ref int ascii_code)
		{
			bool tempCopyKey = false;

			bool return_value = false;
			tempCopyKey = (ascii_code == 3);

			return return_value;

		}

		//  PURPOSE:  To set the recently-used company section in File menu.
		//  COMMENT: Before this routine is called, gsRecentlyUsedDBNames has to be set.
		//
		public static void SetRecentCompanyInFileMenu()
		{

			int db_num = 0;
			string company_name = "";

			for (db_num = 0; db_num <= GlobalVar.goConstant.MAX_DB_USED_RECENTLY; db_num++)
			{
				company_name = GlobalVar.goCompany.GetRecentlyUsedCompanyName(db_num);
				if (GlobalVar.goUtility.IsEmpty(company_name))
				{
					break;
				}
			}

		}

		public static void MouseDefault()
		{

			try
			{

			}
			catch (Exception ex)
			{

			}

		}

		public static void MouseHourGlass()
		{

			try
			{

			}
			catch (Exception ex)
			{

			}

		}

		public static void ReArrangeAddressField(ref clsDatabase cur_db, int address_type)
		{

		}

		// PURPOSE:  To make sure that it is o.k. to post.
		// COMMENTS: This routine should be called before posting starts in order to
		//           make sure only one person gets to post at a time.
		//
		public static void WaitForMyTurn(ref clsDatabase cur_db, ref int cancel_fl)
		{

			// This will wait ininitly until the timer checks the database and resets
			// CancelFlag, or the user presses CANCEL button.
			//
			while (true)
			{
				if (cancel_fl != GlobalVar.goConstant.FLAG_WAIT)
				{
					break;
				}
				else
				{
					RunEvents();
				}
			}

		}

		public static void SetDefaultCode(ref clsDatabase cur_db)
		{


		}

		public static void ShowPostingModule(string mess)
		{

			UpdateLastUpdatePanel(mess);

		}

		//  Shows the progrss bar with the percentage of work done.
		//
		public static void ShowProgress(int progress_percentage)
		{

		}

		// PURPOSE:  To read the company-specific values.
		// COMMENTS: The user-specific values are set in o_gen.SetSystemINIVars(), and
		//           they are
		//               giPanelColor, cur_db.iToolAreaPos, cur_db.iStatusAreaPos, cur_db.iLanguage_typ,
		//               and cur_db.bBeepIsOn.
		//
		public static bool SetCompanyInfo(ref clsDatabase cur_db)
		{

			bool return_value = false;
			clsRecordset cur_set = null;
			string sql_str = "";

			try
			{

				cur_set = new clsRecordset(ref cur_db);

				if (!cur_set.CreateSnapshot(modConstant.MASTER_DYNASET))
				{
					MouseDefault();
					return return_value;
				}

				cur_db.bRealTimeMode = (GlobalVar.goConstant.REALTIME_MODE_NUM == cur_set.iField("iProcessingMode"));

				// Each program will set its own flag to true at the form loading time
				// overiding this set up here.
				//
				cur_db.sCurProgram_nm = (cur_set.sField("sVersion_nm"));

				cur_db.uProgram.bSMExist_fl = true;
				cur_db.uProgram.bGLExist_fl = (cur_set.iField("iGLExist_fl") == GlobalVar.goConstant.CHECKED_ON); //Or (cur_db.sCurProgram_nm = goConstant.GOMENU_NAME) 'Or (cur_db.sCurProgram_nm = goConstant.PLMENU_NAME) Or (cur_db.sCurProgram_nm = goConstant.ENMENU_NAME)
				cur_db.uProgram.bIVExist_fl = (cur_set.iField("iIVExist_fl") == GlobalVar.goConstant.CHECKED_ON); //Or (cur_db.sCurProgram_nm = goConstant.GOMENU_NAME) 'Or (cur_db.sCurProgram_nm = goConstant.PLMENU_NAME) Or (cur_db.sCurProgram_nm = goConstant.ENMENU_NAME)
				cur_db.uProgram.bARExist_fl = (cur_set.iField("iARExist_fl") == GlobalVar.goConstant.CHECKED_ON); //Or (cur_db.sCurProgram_nm = goConstant.GOMENU_NAME) 'Or (cur_db.sCurProgram_nm = goConstant.PLMENU_NAME) Or (cur_db.sCurProgram_nm = goConstant.ENMENU_NAME)
				cur_db.uProgram.bAPExist_fl = (cur_set.iField("iAPExist_fl") == GlobalVar.goConstant.CHECKED_ON); //Or (cur_db.sCurProgram_nm = goConstant.GOMENU_NAME) 'Or (cur_db.sCurProgram_nm = goConstant.PLMENU_NAME) Or (cur_db.sCurProgram_nm = goConstant.ENMENU_NAME)
				cur_db.uProgram.bSOExist_fl = (cur_set.iField("iSOExist_fl") == GlobalVar.goConstant.CHECKED_ON); //Or (cur_db.sCurProgram_nm = goConstant.GOMENU_NAME) 'Or (cur_db.sCurProgram_nm = goConstant.PLMENU_NAME) Or (cur_db.sCurProgram_nm = goConstant.ENMENU_NAME)
				cur_db.uProgram.bPOExist_fl = (cur_set.iField("iPOExist_fl") == GlobalVar.goConstant.CHECKED_ON); //Or (cur_db.sCurProgram_nm = goConstant.GOMENU_NAME) 'Or (cur_db.sCurProgram_nm = goConstant.PLMENU_NAME) Or (cur_db.sCurProgram_nm = goConstant.ENMENU_NAME)

				cur_db.uProgram.bPRExist_fl = (cur_set.iField("iPRExist_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.uProgram.bBRExist_fl = (cur_set.iField("iBRExist_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.uProgram.bJCExist_fl = (cur_set.iField("iJCExist_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.uProgram.bTBExist_fl = (cur_set.iField("iTBExist_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.uProgram.bFAExist_fl = (cur_set.iField("iFAExist_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.uProgram.bWHExist_fl = (cur_set.iField("iWHExist_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.uProgram.bRCExist_fl = (cur_set.iField("iRCExist_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.uProgram.bMCExist_fl = (cur_set.iField("iMCExist_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.uProgram.bMFExist_fl = (cur_set.iField("iMFExist_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.uProgram.bCMExist_fl = (cur_set.iField("iCMExist_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.uProgram.bNPExist_fl = (cur_set.iField("iNPExist_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.uProgram.bRTExist_fl = (cur_set.iField("iRTExist_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.uProgram.bWOExist_fl = (cur_set.iField("iWOExist_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.uProgram.bIEExist_fl = (cur_set.iField("iIEExist_fl") == GlobalVar.goConstant.CHECKED_ON);

				cur_db.iMoney_typ = (cur_set.iField("iMoney_typ"));
				cur_db.iDate_typ = (cur_set.iField("iDate_typ"));
				cur_db.iCurBusiness_typ = (cur_set.iField("iBusiness_typ"));
				cur_db.bFundAccounting_fl = (cur_db.iCurBusiness_typ == GlobalVar.goConstant.NP_BUSINESS_NUM);

				cur_db.iCurInvoice_typ = (cur_set.iField("iInvoice_typ"));
				cur_db.iCurCM_typ = (cur_set.iField("iCM_typ"));
				cur_db.iCurStatement_typ = (cur_set.iField("iStatement_typ"));
				cur_db.iInventoryCost_typ = (cur_set.iField("iInventoryCost_typ"));
				cur_db.iFirstFiscalMonth = (cur_set.iField("iFirstMonth"));
				cur_db.iCurPeriodBegin_dt = (cur_set.iField("iCurrentPeriodBegin_dt"));
				cur_db.iCurPeriodEnd_dt = (cur_set.iField("iCurrentPeriodEnd_dt"));
				cur_db.sCurFiscalYear = GlobalVar.goUtility.STrim((cur_set.sField("sCurrentFiscalYear")));
				cur_db.sCurPayrollYear = GlobalVar.goUtility.STrim((cur_set.sField("sCurrentPayrollYear")));
				if (GlobalVar.goUtility.IsEmpty(cur_db.sCurPayrollYear))
				{
					cur_db.sCurPayrollYear = GlobalVar.goUtility.SFormat(DateTime.Now, "yyyy");
				}
				cur_db.iCurYearBegin_dt = (cur_set.iField("iCurrentYearBegin_dt"));
				cur_db.iCurYearEnd_dt = (cur_set.iField("iCurrentYearEnd_dt"));
				cur_db.uCompany.sName = (cur_set.sField("sCompany_nm"));
				cur_db.uCompany.sAddress1 = (cur_set.sField("sAddress1"));
				cur_db.uCompany.sAddress2 = (cur_set.sField("sAddress2"));
				cur_db.uCompany.sAddress3 = (cur_set.sField("sAddress3"));
				cur_db.uCompany.sCity = (cur_set.sField("sCity"));
				cur_db.uCompany.sState = (cur_set.sField("sState"));
				cur_db.uCompany.sZipCode = (cur_set.sField("sZipCode"));
				cur_db.uCompany.sPhone = (cur_set.sField("sPhone"));
				cur_db.uCompany.sFax = (cur_set.sField("sFax"));
				cur_db.uCompany.sCountry_cd = (cur_set.sField("sCountry_cd"));
				cur_db.uCompany.sReseller_num = (cur_set.sField("sCompany_id"));
				cur_db.uCompany.sState_id = (cur_set.sField("sState_id"));
				cur_db.uCompany.sFederal_id = (cur_set.sField("sFederal_id"));
				cur_db.sLastFiscalYear = (cur_set.sField("sLastFiscalYear"));
				cur_db.iLastYearBegin_dt = (cur_set.iField("iLastYearBegin_dt"));
				cur_db.iLastYearEnd_dt = (cur_set.iField("iLastYearEnd_dt"));
				cur_db.iTotalPeriods_num = (cur_set.iField("iTotalPeriods_num"));
				cur_db.iCurBudget_typ = (cur_set.iField("iBudget_typ"));
				cur_db.bRestrictBudgetByPeriod = (cur_set.iField("iRestrictByPeriod_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.sDefCEAccount_cd = (cur_set.sField("sDefaultEarningAcct_cd"));
				cur_db.sGLAcctCodeFormat = (cur_set.sField("sGLAcctCodeFormat"));
				cur_db.iGLAcctCodeLength = (cur_set.iField("iGLAcctCodeLength"));
				cur_db.bUseFullAccountCode_fl = (cur_set.iField("iGLAcctCode_typ") == 1);

				cur_db.iAddress_typ = (cur_set.iField("iAddress_typ"));
				cur_db.iLanguage_typ = (cur_set.iField("iLanguage_typ"));
				cur_db.iUserLevelToRequireField = (cur_set.iField("iUserLevelToRequireField"));

				cur_db.sCurBudget_cd = cur_db.sCurFiscalYear;
				cur_db.iAddress_typ = Convert.ToInt32(GlobalVar.goUtility.IIf(cur_db.iAddress_typ > 0, cur_db.iAddress_typ, GlobalVar.goConstant.ADDRESS_USA));
				cur_db.iMoney_typ = Convert.ToInt32(GlobalVar.goUtility.IIf(cur_db.iMoney_typ > 0, cur_db.iMoney_typ, GlobalVar.goConstant.ROUND_TO_CENT));
				cur_db.iDate_typ = Convert.ToInt32(GlobalVar.goUtility.IIf(cur_db.iDate_typ > 0, cur_db.iDate_typ, GlobalVar.goConstant.AMERICAN_DATE));

				cur_db.bDeleteTransactionIsAllowed = cur_set.iField("iDeleteTransIsAllowed_fl") == GlobalVar.goConstant.CHECKED_ON;
				cur_db.bPostTransactionDirectly = cur_set.iField("iPostTransactionDirectly_fl") == GlobalVar.goConstant.CHECKED_ON;
				cur_db.iInventoryControl_typ = (cur_set.iField("iInventoryControl_typ"));
				cur_db.bPostToGL = cur_set.iField("iPostToGL_fl") == GlobalVar.goConstant.CHECKED_ON;
				cur_db.sCurrency_cd = (cur_set.sField("sCurrency_cd"));

				// Money related info are dictated by the values in the database.
				// If they need to be changed, SA can open database and set the values there manually.
				//
				cur_db.sDecimalPoint = GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(cur_set.sField("sDecimalPoint")), (cur_set.sField("sDecimalPoint")), ".").ToString();
				cur_db.sThousandSeparator = GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(cur_set.sField("sThousandSeparator")), (cur_set.sField("sThousandSeparator")), ",").ToString();

				cur_db.iUseFileForPicture_fl = (cur_set.iField("iUseFileForPicture_fl"));
				//cur_db.uDirectory.sPictureDirectory_nm = (cur_set.sField("sPictureDirectory_nm"))
				//cur_db.uDirectory.sWebPictureDirectory_nm = (cur_set.sField("sWebPictureDirectory_nm"))
				cur_db.iFreightCalculation_typ = (cur_set.iField("iFreightCalculation_typ"));

				if (cur_db.iFreightCalculation_typ == 0)
				{
					cur_db.iFreightCalculation_typ = modConstant.FREIGHT_BY_WEIGHT_NUM;
				}

				cur_db.iRemapEnterToTab_fl = (cur_set.iField("iRemapEnterToTab_fl"));

				cur_db.bMarkupItem_fl = (cur_set.iField("iMarkupItem_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.fMarkup_rt = (cur_set.mField("fMarkup_rt"));
				cur_db.bTrackRevenueByCustomer_fl = (cur_set.iField("iTrackRevenueByCustomer_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.bCalcCommissionByItem_fl = (cur_set.iField("iCalcCommissionByItem_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.bDoNotSummarizeAccountsInPosting_fl = (cur_set.iField("iDoNotSummarizeAccounts_fl") == GlobalVar.goConstant.CHECKED_ON);

				cur_db.iAccounting_typ = Convert.ToInt32(GlobalVar.goUtility.IIf(cur_set.iField("iAccounting_typ") == 0, GlobalVar.goConstant.ACCRUAL_ACCOUNTING_TYPE_NUM, cur_set.iField("iAccounting_typ")));
				cur_db.sSMTPServer_nm = (cur_set.sField("sSMTPServer_nm"));
				cur_db.sPriceCurrency_cd = (cur_set.sField("sPriceCurrency_cd"));
				cur_db.bBuyerRetainSalesTax_fl = (cur_set.iField("iBuyerRetainSalesTax_fl") == GlobalVar.goConstant.FLAG_ON);
				cur_db.mMinAmtToRetainSalesTax_amt = (cur_set.mField("mMinAmtToRetainSalesTax_amt"));
				cur_db.bDeductAbsenceFromPayroll_fl = (cur_set.iField("iDeductAbsenceFromPayroll_fl") == GlobalVar.goConstant.FLAG_ON);
				cur_db.iSalesTax_typ = Convert.ToInt32(GlobalVar.goUtility.IIf(cur_set.iField("iSalesTax_typ") > 0, cur_set.iField("iSalesTax_typ"), GlobalVar.goConstant.TAX_SALES_TAX_TYPE_NUM));
				cur_db.mMaxQuick_amt = cur_set.mField("mMaxQuick_amt");
				cur_db.bEnableBatchEntry_fl = (cur_set.iField("iEnableBatchEntry_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.bFreightTax_fl = (cur_set.iField("iFreightTax_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.iVertical_id = cur_set.iField("iVertical_id");

				cur_db.sSystemEmailAddress = (cur_set.sField("sSystemEmailAddress"));
				cur_db.sSystemEmailPassword = (cur_set.sField("sSystemEmailPassword"));
				cur_db.iSystemEmailUseSSL_fl = (cur_set.iField("iSystemEmailUseSSL_fl"));
				cur_db.iSystemEmailPort_num = (cur_set.iField("iSystemEmailPort_num"));

				cur_db.bUseCalendarYearForDepreciation_fl = (cur_set.iField("iUseCalYearForDepreciation_fl") == GlobalVar.goConstant.FLAG_ON);

				cur_db.iMaxBins_num = cur_set.iField("iMaxBins_num");
				cur_db.uProgram.bFAExist_fl = (cur_set.iField("iFAExist_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.bCommitHold_fl = (cur_set.iField("iCommitHold_fl") == GlobalVar.goConstant.CHECKED_ON);

				cur_db.iItemCodeSize_typ = cur_set.iField("iItemCodeSize_typ");
				cur_db.iAPDescSize_typ = cur_set.iField("iAPDescSize_typ");
				cur_db.iARDescSize_typ = cur_set.iField("iARDescSize_typ");

				cur_db.uDefaultValue.sClass_cd = cur_set.sField("sClass_cd");
				cur_db.uDefaultValue.sPosting_cd = cur_set.sField("sPosting_cd");
				cur_db.uDefaultValue.sTerms_cd = cur_set.sField("sTerms_cd");
				cur_db.uDefaultValue.sTax_cd = cur_set.sField("sTax_cd");
				cur_db.uDefaultValue.sPrice_cd = cur_set.sField("sPrice_cd");
				cur_db.uDefaultValue.sAPClass_cd = cur_set.sField("sAPClass_cd");
				cur_db.uDefaultValue.sAPPosting_cd = cur_set.sField("sAPPosting_cd");
				cur_db.uDefaultValue.sAPTerms_cd = cur_set.sField("sAPTerms_cd");
				cur_db.uDefaultValue.sAPTax_cd = cur_set.sField("sAPTax_cd");
				cur_db.uDefaultValue.mCreditLimit_amt = cur_set.mField("mCreditLimit_amt");
				cur_db.bDoNotTrackLot_fl = (cur_set.iField("iDoNotTrackLot_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.bDoNotTrackSerial_fl = (cur_set.iField("iDoNotTrackSerial_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.bEnableAFT_fl = (cur_set.iField("iEnableAFT_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.iInProduction_typ = cur_set.iField("iInProduction_typ");
				cur_db.iSecurityDeposit_pc = cur_set.iField("iSecurityDeposit_pc");
				cur_db.iFirstPayment_pc = cur_set.iField("iFirstPayment_pc");
				cur_db.bInspectReturn_fl = (cur_set.iField("iInspectReturn_fl") == GlobalVar.goConstant.CHECKED_ON);
				cur_db.bEnablePageLevelSecurity_fl = (cur_set.iField("iEnablePageLevelSecurity_fl") == GlobalVar.goConstant.CHECKED_ON);


				// CASH-BASED ACCOUNTING does not allow the inventory.
				//
				if (cur_db.iAccounting_typ == GlobalVar.goConstant.CASH_ACCOUNTING_TYPE_NUM)
				{
					cur_db.uProgram.bIVExist_fl = false;
				}

				// If posting_in_progress is set, and posting_user is the current user,
				// then reset them.  This is the sign of the system halt in the middle of
				// posting.  If this is not reset here, posting cannot proceed.
				//
				if ((cur_set.iField("iPostingInProgress") > 0) && (cur_set.sField("sPostingUser_cd") == cur_db.sUser_cd))
				{
					sql_str = "UPDATE tblGOMaster SET";
					sql_str += " iPostingInProgress = 0";
					sql_str += ",sPostingUser_cd = ''";
					cur_db.ExecuteSQL(sql_str);
				}

				sql_str = "SELECT MAX(iSegmentLevel) AS iMax FROM tblGLSegment WHERE iApplied_fl > 0";
				if (cur_set.CreateSnapshot(sql_str))
				{
					if (cur_set.EOF())
					{
						cur_db.iTotalSegments_num = 0;
					}
					else
					{
						cur_db.iTotalSegments_num = cur_set.iField("iMax");
					}
				}

				//if (!CreateSubDirectories(ref cur_db))
				//{
				//	return return_value;
				//}

				return_value = true;

				cur_set.Release();
				//cur_db.uProgram.bCMExist_fl = goFile.FileExists("cm.exe")

				modSecurity.GetAllSecurityOptions(ref cur_db, cur_db.sCurProgram_nm); // Do not delete this line because cur_db.uSecurity.bDoNotClosePeriod_fl is set in this routine.
				modPayrollUtility.GetPayrollTaxCaptions(ref cur_db);

				// *********************************************************************************
				// ENDING SECTION :  DO NOT CHANGE THE ORDER IN THIS SECTION.
				// *********************************************************************************

				// Dictate some system values
				//
				DictateSystemValues(ref cur_db);

				return return_value;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(SetCompanyInfo)");
				return_value = false;
				cur_set.Release();
				return return_value;

			}

		}

		// PURPOSE : To set some system values.
		//           If you change here, it will dictate the entire system.
		//
		public static void DictateSystemValues(ref clsDatabase cur_db)
		{

			cur_db.fSmallestNumber = Convert.ToDecimal(0.0001); // Smallest number we use for quantity and unit_cost.

			if (cur_db.iMoney_typ == GlobalVar.goConstant.ROUND_TO_THIRD)
			{
				cur_db.mSmallestMoney_amt = Convert.ToDecimal(0.001);
				cur_db.sCurrencyFormat = "#,##0.000";
				cur_db.sDecimalPoint = ".";
				cur_db.sThousandSeparator = ",";
			}
			else if (cur_db.iMoney_typ == GlobalVar.goConstant.ROUND_TO_CENT)
			{
				cur_db.mSmallestMoney_amt = Convert.ToDecimal(0.01);
				cur_db.sCurrencyFormat = "#,##0.00";
				cur_db.sDecimalPoint = ".";
				cur_db.sThousandSeparator = ",";
			}
			else if (cur_db.iMoney_typ == GlobalVar.goConstant.ROUND_TO_DOLLAR)
			{
				cur_db.mSmallestMoney_amt = Convert.ToDecimal(1);
				cur_db.sCurrencyFormat = "#,##0";
				cur_db.sDecimalPoint = ".";
				cur_db.sThousandSeparator = ",";
			}
			//else if (cur_db.iMoney_typ == GlobalVar.goConstant.ROUND_TO_ASIAN)
			//{
			//	cur_db.mSmallestMoney_amt = 1;
			//	cur_db.sCurrencyFormat = "#,###0";
			//	cur_db.sDecimalPoint = ".";
			//	cur_db.sThousandSeparator = ",";
			//}
			else // Euro
			{
				cur_db.mSmallestMoney_amt = Convert.ToDecimal(0.01);
				cur_db.sCurrencyFormat = "#,##0.00"; // comma and period will be switched in ToStrMoney().
				cur_db.sDecimalPoint = ",";
				cur_db.sThousandSeparator = ".";
			}

		}
		
		public static bool IsApproved(ref clsDatabase cur_db, string message = "")
		{

			bool return_value = false;
			if (clsConstant.USER_SUPERVISOR_TYPE <= cur_db.iUserType_id)
			{
				return true;
			}
			else if (GlobalVar.goUtility.IsEmpty(GlobalVar.goUtility.STrim(message)))
			{
				message = cur_db.oLanguage.oMessage.THIS_NEEDS_TO_BE_APPROVED;
			}

			return_value = true;

			return return_value;

		}

		public static bool GetHomeDirectory(ref clsDatabase cur_db)
		{
			clsFile o_file = new clsFile();

			cur_db.uDirectory.sHomeDirectory_nm = o_file.AppDirectory();							// Do not use App.Path or CurDir().
			cur_db.uDirectory.sReportDirectory_nm = cur_db.uDirectory.sHomeDirectory_nm + "\\Reports";
			cur_db.uDirectory.sReportServerDirectory_nm = GlobalVar.goUtility.SReplace(cur_db.uDirectory.sHomeDirectory_nm, "wwwroot\\Home", "wwwroot\\ReportServer");
			cur_db.uDirectory.sParameterDirectory_nm = GlobalVar.goUtility.SReplace(cur_db.uDirectory.sReportServerDirectory_nm, "ReportServer", "Parameter");
			return true;
		}

		public static bool SetHomeDirectory(ref clsDatabase cur_db)
		{

			bool return_value = false;

			if (GlobalVar.goUtility.IsNonEmpty(cur_db.uDirectory.sHomeDirectory_nm))
			{
				System.IO.Directory.SetCurrentDirectory(cur_db.uDirectory.sHomeDirectory_nm);
				RunEvents();
			}

			return_value = true;

			return return_value;

		}

		//  PURPOSE:  To close the currently open database.
		//
		public static bool CloseCompany(ref clsDatabase cur_db)
		{
			bool tempCloseCompany = false;

			bool return_value = false;
			tempCloseCompany = true;

			return return_value;

		}

		//  PURPOSE:  To save the screen options which a user can change.
		//            This should be called when closing the program.
		//
		public static bool SaveMenuScreen(ref clsDatabase cur_db)
		{
			bool tempSaveMenuScreen = false;

			bool return_value = false;
			tempSaveMenuScreen = true;

			return return_value;

		}

		// PURPOSE:  To wait for a given number of seconds.
		//
		public static void WaitFor(int wait_sec)
		{
			DateTime time_started = DateTime.Now;

            while (wait_sec > Math.Abs((DateTime.Now - time_started).TotalSeconds))
            {
                modGeneralUtility.RunEvents();
            }

		}

		// PURPOSE : To close the current period.
		//
		public static bool CloseCurrentPeriod(ref clsDatabase cur_db, int next_period_begin, int next_period_end)
		{

			bool return_value = false;
			string sql_str = "";
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsInventory o_iv = new clsInventory();

			try
			{

				if ((next_period_begin < 19000101) || (next_period_begin > 29001231))
				{
					return return_value;
				}
				else if ((next_period_begin < cur_db.iCurYearBegin_dt) || (next_period_begin > cur_db.iCurYearEnd_dt))
				{
					return return_value;
				}
				else if (o_gen.ClosePeriod(next_period_begin, next_period_end))
				{
					cur_db.iCurPeriodBegin_dt = next_period_begin;
					cur_db.iCurPeriodEnd_dt = next_period_end;
					o_iv.ClearCommittedInventory(ref cur_db);
					return_value = true;
				}

				return return_value;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CloseCurrentPeriod)");
				return false;

			}

		}

		public static bool CreateSubDirectories(ref clsDatabase cur_db)
		{

			bool return_value = false;
			clsFile o_file = new clsFile();

			try
			{

				o_file.SetDirectoryNames(cur_db);

				// CAUTION ---------------------------------------------------------------------
				// Check the most newly-recently added folder that should appear at the bottom of this routine.
				// If it exists, the others exist already.  This is just to improve the performance.
				//
				if (GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sLogoDirectory_nm))			// THIS FOLDER HAS TO BE THE ONE THAT HAS EACH COMPANY SUB-FOLDER
				{
					return true;
				}


				if (!GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sHomeDirectory_nm))
				{
					o_file.CreateDirectory(cur_db.uDirectory.sHomeDirectory_nm);
				}
				if (!GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sReportServerDirectory_nm))
				{
					o_file.CreateDirectory(cur_db.uDirectory.sReportServerDirectory_nm);
				}
				if (!GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sParameterDirectory_nm))
				{
					o_file.CreateDirectory(cur_db.uDirectory.sParameterDirectory_nm);
				}
				if (!GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sCMDirectory_nm))
				{
					o_file.CreateDirectory(cur_db.uDirectory.sCMDirectory_nm);
				}
				if (!GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sLocaleDirectory_nm))
				{
					o_file.CreateDirectory(cur_db.uDirectory.sLocaleDirectory_nm);
				}
				if (!GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sWebPictureDirectory_nm))
				{
					o_file.CreateDirectory(cur_db.uDirectory.sWebPictureDirectory_nm);
				}
				if (!GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sEmployeePictureDirectory_nm))
				{
					o_file.CreateDirectory(cur_db.uDirectory.sEmployeePictureDirectory_nm);
				}
				if (!GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sInventoryPictureDirectory_nm))
				{
					o_file.CreateDirectory(cur_db.uDirectory.sInventoryPictureDirectory_nm);
				}
				if (!GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sBackupDirectory_nm))
				{
					o_file.CreateDirectory(cur_db.uDirectory.sBackupDirectory_nm);
				}
				if (!GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sPayrollDirectory_nm))
				{
					o_file.CreateDirectory(cur_db.uDirectory.sPayrollDirectory_nm);
				}
				if (!GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sCustomDirectory_nm))
				{
					o_file.CreateDirectory(cur_db.uDirectory.sCustomDirectory_nm);
				}
				if (!GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sCSVExportDirectory_nm))
				{
					o_file.CreateDirectory(cur_db.uDirectory.sCSVExportDirectory_nm);
				}
				if (!GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sCSVImportDirectory_nm))
				{
					o_file.CreateDirectory(cur_db.uDirectory.sCSVImportDirectory_nm);
				}
				if (!GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sHelpDirectory_nm))
				{
					o_file.CreateDirectory(cur_db.uDirectory.sHelpDirectory_nm);
				}
				if (!GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sPDFDirectory_nm))
				{
					o_file.CreateDirectory(cur_db.uDirectory.sPDFDirectory_nm);
				}
				if (!GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sEtcDirectory_nm))
				{
					o_file.CreateDirectory(cur_db.uDirectory.sEtcDirectory_nm);
				}
				if (!GlobalVar.goFile.DirectoryExists(cur_db.uDirectory.sLogoDirectory_nm))
				{
					o_file.CreateDirectory(cur_db.uDirectory.sLogoDirectory_nm);
				}

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CreateSubDirectories)");

			}

			return return_value;

		}

		public static int FindAddressType(ref clsDatabase cur_db, string country_name)
		{

			int return_value = 0;
			if (cur_db.uCompany.sCountry_cd == country_name)
			{
				return_value = cur_db.iAddress_typ;
			}
			else if (GlobalVar.goUtility.SUCase(country_name) == "CANADA")
			{
				return_value = GlobalVar.goConstant.ADDRESS_CANADA;
			}
			else if (GlobalVar.goUtility.SUCase(country_name) == "US" || GlobalVar.goUtility.SUCase(country_name) == "USA" || GlobalVar.goUtility.SUCase(country_name) == "U.S.A." || GlobalVar.goUtility.SUCase(country_name) == GlobalVar.goUtility.SUCase("United States of America") || GlobalVar.goUtility.SUCase(country_name) == GlobalVar.goUtility.SUCase("The United States of America"))
			{
				return_value = GlobalVar.goConstant.ADDRESS_USA;
			}
			else
			{
				return_value = GlobalVar.goConstant.ADDRESS_OTHER;
			}

			return return_value;

		}

		// PURPOSE:  To increase a string number with the given increment.
		//
		public static string IncreaseStringNumber(ref clsDatabase cur_db, string string_num, int incr_num)
		{

			string return_value = "";
			int incr_len = 0;
			string sub_str = "";

			if (GlobalVar.goUtility.SLength(string_num) <= GlobalVar.goUtility.SLength(GlobalVar.goUtility.STrim(GlobalVar.goUtility.ToStr(incr_num))))
			{
				return_value = GlobalVar.goUtility.STrim(GlobalVar.goUtility.ToStr(GlobalVar.goUtility.ToValue(GlobalVar.goUtility.SRight(string_num, incr_len + 1)) + GlobalVar.goUtility.ToValue(Convert.ToString(incr_num))));
				return return_value;
			}

			incr_len = GlobalVar.goUtility.SLength(GlobalVar.goUtility.STrim(GlobalVar.goUtility.ToStr(incr_num)));
			sub_str = GlobalVar.goUtility.STrim(GlobalVar.goUtility.ToStr(GlobalVar.goUtility.ToValue(GlobalVar.goUtility.SRight(string_num, incr_len + 1)) + GlobalVar.goUtility.ToValue(Convert.ToString(incr_num))));

			if (GlobalVar.goUtility.SLength(sub_str) <= (incr_len + 1))
			{
				sub_str = GlobalVar.goUtility.SRight("00000000000" + sub_str, incr_len + 1);
				return_value = GlobalVar.goUtility.SLeft(string_num, GlobalVar.goUtility.SLength(string_num) - incr_len - 1) + sub_str;
			}
			else
			{
				return_value = IncreaseStringNumber(ref cur_db, GlobalVar.goUtility.SLeft(string_num, GlobalVar.goUtility.SLength(string_num) - incr_len - 1), 1) + GlobalVar.goUtility.SRight(sub_str, GlobalVar.goUtility.SLength(sub_str) - 1);
			}

			return return_value;

		}

		public static bool CheckIfNeedToClosePeriod(ref clsDatabase cur_db)
		{

			bool return_value = false;
			clsRecordset cur_set = null;
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			cur_set = new clsRecordset(ref cur_db);

			// If the current date is out of current period, check if the user wants to close the current period.
			// This should be only checked in System Manager.
			//
			if (cur_db.iCurPeriodBegin_dt > 19000000 && !cur_db.uSecurity.bDoNotClosePeriod_fl)
			{
				if (cur_db.sCurFiscalYear == GlobalVar.goUtility.STrim(GlobalVar.goUtility.ToStr(GlobalVar.goUtility.GetYear(o_gen.CurrentDate())))) // DO only for the current year, not for the new year.
				{
					if (o_gen.ChangePeriodAutomatically(o_gen.CurrentDate()))
					{
						if (cur_set.CreateSnapshot(modConstant.MASTER_DYNASET))
						{
							cur_db.iCurPeriodBegin_dt = (cur_set.iField("iCurrentPeriodBegin_dt"));
							cur_db.iCurPeriodEnd_dt = (cur_set.iField("iCurrentPeriodEnd_dt"));
							cur_db.sCurFiscalYear = GlobalVar.goUtility.STrim((cur_set.sField("sCurrentFiscalYear")));
							cur_set.Release();
						}
					}
				}
			}

			return_value = true;

			return return_value;

		}

		public static bool AllowClosedPeriodTransactions(ref clsDatabase cur_db)
		{

			bool return_value = false;
			if (!cur_db.uSecurity.bLockClosedPeriods_fl)
			{
				return_value = true;

				// If they need to enter the closed periods, they need to reset the option.
				//
				//ElseIf cur_db.iUserType_id >= clsConstant.USER_SUPERVISOR_TYPE Then
				//    AllowClosedPeriodTransactions = True
			}
			else
			{
				return_value = false;
			}

			return return_value;

		}

		public static string GetFirstName(ref clsDatabase cur_db, string full_name)
		{

			string return_value = "";
			if (cur_db.iAddress_typ != GlobalVar.goConstant.ADDRESS_CANADA && cur_db.iAddress_typ != GlobalVar.goConstant.ADDRESS_USA)
			{
				return_value = full_name;
			}
			else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(full_name, 3)) == "DR " || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(full_name, 3)) == "DR." || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(full_name, 3)) == "MR " || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(full_name, 3)) == "MR." || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(full_name, 5)) == "MISS " || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(full_name, 3)) == "MS " || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(full_name, 3)) == "MS." || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(full_name, 4)) == "MRS " || GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(full_name, 4)) == "MRS.")
			{
				return_value = full_name;
			}
			else
			{

				if (GlobalVar.goUtility.SInStr(full_name, ",") > 0)
				{
					full_name = GlobalVar.goUtility.SRight(full_name, GlobalVar.goUtility.SLength(full_name) - GlobalVar.goUtility.SInStr(full_name, ","));
				}

				full_name = GlobalVar.goUtility.STrim(full_name);

				if (GlobalVar.goUtility.SInStr(full_name, " ") > 0)
				{
					full_name = GlobalVar.goUtility.SLeft(full_name, GlobalVar.goUtility.SInStr(full_name, " ") - 1);
				}

				return_value = full_name;

			}

			return return_value;

		}

		public static void SendKeys(ref clsDatabase cur_db, string key_string)
		{

		}

		// This is to clear the members of guPass
		//
		public static void ClearPassingValues()
		{

		}

		public static string FormatToIntegerMoney(ref clsDatabase cur_db, decimal money_amt)
		{
			string return_value = "";

			return_value = string.Format("{0:N0}", money_amt);
			return return_value;

			string str_amt = GlobalVar.goUtility.SFormat(money_amt, "#,##0");


			if (cur_db.sDecimalPoint == ",") // For Euro, switch comma and period.
			{
				str_amt = GlobalVar.goUtility.SReplace(str_amt, ",", ".");
			}

			return_value = str_amt;

			return return_value;

		}

		public static void DrawGraph(ref clsDatabase cur_db)
		{

		}

		public static string GetOpenWindowsString(string file_name)
		{

			string return_value = "";

			return_value = "window.open('" + file_name + "','_blank')";
			return return_value;

		}

		public static string FindComboBoxSelectedValue()
		{

			string return_value = "";

			return return_value;

		}

		public static string FindComboBoxSelectedText()
		{

			string return_value = "";

			return return_value;

		}

		public static void InactivateTabButton()
		{

		}

		public static void ActivateTabButton()
		{

		}

		public static void EnableActionButton()
		{

		}

		public static void HideActionButton()
		{

		}

		public static int GetLocalDate(ref clsDatabase cur_db)
		{

			clsGeneral o_gen = new clsGeneral(ref cur_db);

			return 0;
		}

		public static string GetWebModuleID()
		{

			string return_value = "";

            return_value = GlobalVar.WEB_MODULE_ID;

			return return_value;

		}

		public static bool DownloadFile(ref clsDatabase cur_db)
		{
			bool return_value = false;
			return return_value;

		}

		public static string GetVirtualFileName(string file_name, bool for_report_fl = false)
		{

			bool return_value = false;

			file_name = GlobalVar.goUtility.SLCase(GlobalVar.goUtility.SReplace(file_name, "\\", "/"));		// a slash is an escape code

			if (GlobalVar.goUtility.SInStr(file_name, "/home/") <= 0)
			{
				return "";
			}

			if (for_report_fl)
            {
				file_name = GlobalVar.goUtility.SRight(file_name, GlobalVar.goUtility.SLength(file_name) - GlobalVar.goUtility.SInStr(file_name, "/wwwroot/home/"));	// in virtual server, "home" appears twice
			}
			else
            {
				file_name = "~" + GlobalVar.goUtility.SRight(file_name, GlobalVar.goUtility.SLength(file_name) - GlobalVar.goUtility.SInStr(file_name, "/wwwroot/home/") + 1);
			}

			file_name = GlobalVar.goUtility.SReplace(file_name, "wwwroot/", "");

			return file_name;
		}

		public static int AcceptableZoomSize()
		{

			int return_value = 0;

			return_value = GlobalVar.MAX_SIZE_FOR_ZOOM_WITHOUT_INITIALS * 10;

			return return_value;

		}

		public static bool ExportToCSVFile(ref clsDatabase cur_db, string[,] csv_data, string[] field_name, ref string file_name)
		{

			bool return_value = false;
			string tmp = null;
			clsFileIO o_filio = new clsFileIO();
			int col_num = 0;
			int row_num = 0;
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			try
			{

				if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SRight(file_name, 4)) == ".CSV")
				{
					file_name = GlobalVar.goUtility.SLeft(file_name, GlobalVar.goUtility.SLength(file_name) - 4);
				}

				file_name = cur_db.uDirectory.sCSVExportDirectory_nm + "\\" + file_name + ".csv";

				if (!o_filio.OpenFileToWrite(file_name))
				{
					cur_db.SetPostingError("Failed to create the CSV file.");
					return false;
				}

				tmp = "";
				for (row_num = 0; row_num <= field_name.GetUpperBound(0); row_num++)
				{
					tmp += GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsEmpty(tmp), "", modCSConstant.KEY_TAB) + GlobalVar.goUtility.SReplace(GlobalVar.goUtility.SReplace(o_gen.GetReadableFieldName(field_name[row_num]), "<br />", " "), "&nbsp;", " ");
				}
				o_filio.WriteOneLine(tmp);

				for (row_num = 0; row_num <= csv_data.GetUpperBound(1); row_num++)
				{
					tmp = "";
					for (col_num = 0; col_num <= field_name.GetUpperBound(0); col_num++)
					{
                        tmp += GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsEmpty(tmp), "", modCSConstant.KEY_TAB) + GlobalVar.goUtility.SReplace(GlobalVar.goUtility.SReplace(csv_data[col_num, row_num], "<br />", " "), "&nbsp;", " ");
					}
					o_filio.WriteOneLine(tmp);
				}

				o_filio.CloseFile();

				// file_name = GetVirtualFileName(file_name);

				if (GlobalVar.goUtility.IsEmpty(file_name))
				{
					cur_db.SetPostingError("Failed creating excel file.  Please, try again.");
					return false;
				}

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ExportToCSVFile)");

			}

			return return_value;

		}

		public static void RunEvents()
        {

        }
		public static void ShowStatus(string msg)
		{

		}

		public static void ShowUncountableProgress(string end_msg = "")
		{

		}
		public static void RemapKey(string control_name, ref int ascii_code)
		{

		}

		public static void UpdateLastUpdatePanel(string msg = "")
		{

		}

		// Purpose : to sync two dates, one in plain string and another in datetime.
		//
		public static void SyncDates(ref clsDatabase cur_db, ref DateTime? dt_date, ref string str_date, bool use_date_picker)
        {
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			//  If use_date_picker == true, copy the one in datetime type to the other in string type.
			//
			if (use_date_picker)
            {
				if (GlobalVar.goUtility.IsEmpty(dt_date))
                {
					str_date = "";
				}
				else if (GlobalVar.goUtility.IsDate(dt_date))
				{
					str_date = o_gen.ToStrDate(GlobalVar.goUtility.ToInteger(GlobalVar.goUtility.DFormat(dt_date, "yyyyMMdd")));
				}
				else
				{
					str_date = "";
				}
			}
			else
            {
				if (GlobalVar.goUtility.IsEmpty(str_date))
                {
					GlobalVar.goUtility.SetEmptyDate(ref dt_date);
				}
				else if (o_gen.IsValidDate(str_date))
				{
					dt_date = o_gen.ToDate(o_gen.ToNumDate(str_date));
				}
				else
				{
					GlobalVar.goUtility.SetEmptyDate(ref dt_date);
				}
			}
		}

		public static bool GetPassedParameters(string starter_value, Models.clsUser cur_user, Models.clsSession o_session)
        {

			if (GlobalVar.goUtility.IsEmpty(starter_value))
			{
				return true;
			}
			if (o_session.GetSessionValues(starter_value) == false)
			{
				return false;
			}
			if (GlobalVar.goUtility.IsEmpty(o_session.Value.User) || GlobalVar.goUtility.IsEmpty(o_session.Value.Server) 
				|| (GlobalVar.goUtility.IsEmpty(o_session.Value.Database) && GlobalVar.goUtility.IsEmpty(o_session.Value.CCN) && GlobalVar.goUtility.IsEmpty(o_session.Value.DSN)))
			{
				return false;
			}

			if (GlobalVar.goUtility.IsEmpty(cur_user.sServer_nm))
			{
				cur_user.sServer_nm = o_session.Value.Server;
				cur_user.sDatabase_nm = o_session.Value.Database;
				cur_user.sUser_cd = o_session.Value.User;
				cur_user.sPassword = o_session.Value.Password;
				cur_user.sCCN = o_session.Value.CCN;
				cur_user.sDSN = o_session.Value.DSN;
			}

			return true;
        }


		public static bool ArrangeSummaryPageLinksXXX(ref clsDatabase cur_db, int total_records, int max_lines_per_page, ref int first_row, ref int last_row, ref int cur_page
			, ref Models.clsLinkButton PreviousLink, ref Models.clsLinkButton NextLink, ref Models.clsLinkButton Link1, ref Models.clsLinkButton Link2, ref Models.clsLinkButton Link3, ref Models.clsLinkButton Link4, ref Models.clsLinkButton Link5)
		{

			bool return_value = false;
			int remaining_rows = 0;

			const int TOTAL_SUMMARY_PAGES = 5;

			try
			{

				if (cur_page == 0)
				{
					first_row = 0;
				}
				else
				{
					first_row = (cur_page - 1) * max_lines_per_page;
				}

				if (max_lines_per_page > 0 && (total_records > first_row + max_lines_per_page))
				{
					last_row = first_row + max_lines_per_page - 1;
				}
				else
				{
					last_row = total_records - 1;
				}

				remaining_rows = total_records - first_row;

				if (cur_page == 0 || cur_page < GlobalVar.goUtility.ToInteger(Link1.Text) || cur_page > GlobalVar.goUtility.ToInteger(Link5.Text)) // From next button or initial call
				{

					if (cur_page == 0)
					{
						cur_page = 1;
						Link1.Text = "1";
						Link2.Text = "2";
						Link3.Text = "3";
						Link4.Text = "4";
						Link5.Text = "5";
					}

					NextLink.ForeColor = System.Drawing.Color.LightGreen;
					PreviousLink.ForeColor = System.Drawing.Color.LightGreen;

					// remaining_rows is the total rows counting from the first row of Link1 to the end of recordset.
					// When Prev button is pressed, cur_page is set to Link5 so that we need to add this number to create the actual "remaining_rows" that works in this context.
					//
					if (cur_page < GlobalVar.goUtility.ToInteger(Link1.Text))
					{
						remaining_rows += (TOTAL_SUMMARY_PAGES - 1) * max_lines_per_page;
					}

					NextLink.Visible = (remaining_rows > max_lines_per_page * TOTAL_SUMMARY_PAGES);

					Link2.Visible = (remaining_rows > max_lines_per_page * 1);
					Link3.Visible = (remaining_rows > max_lines_per_page * 2);
					Link4.Visible = (remaining_rows > max_lines_per_page * 3);
					Link5.Visible = (remaining_rows > max_lines_per_page * 4);
					NextLink.Visible = (remaining_rows > max_lines_per_page * TOTAL_SUMMARY_PAGES);

					Link1.Visible = Link2.Visible;      // Link1 is visible only when Link2 is

				}

				//PreviousLink.Visible = (goUtility.ToInteger(Link1.Text) > 1)
				PreviousLink.Visible = (cur_page > TOTAL_SUMMARY_PAGES);

				Link1.ForeColor = System.Drawing.Color.LightGreen;
				Link2.ForeColor = System.Drawing.Color.LightGreen;
				Link3.ForeColor = System.Drawing.Color.LightGreen;
				Link4.ForeColor = System.Drawing.Color.LightGreen;
				Link5.ForeColor = System.Drawing.Color.LightGreen;
				Link1.Clicked = false;
				Link2.Clicked = false;
				Link3.Clicked = false;
				Link4.Clicked = false;
				Link5.Clicked = false;

				if ((cur_page % TOTAL_SUMMARY_PAGES) == 0)
				{
					Link5.ForeColor = System.Drawing.Color.Green;
					Link5.Clicked = true;
				}
				if ((cur_page % TOTAL_SUMMARY_PAGES) == 1)
				{
					Link1.ForeColor = System.Drawing.Color.Green;
					Link1.Clicked = true;
				}
				if ((cur_page % TOTAL_SUMMARY_PAGES) == 2)
				{
					Link2.ForeColor = System.Drawing.Color.Green;
					Link2.Clicked = true;
				}
				if ((cur_page % TOTAL_SUMMARY_PAGES) == 3)
				{
					Link3.ForeColor = System.Drawing.Color.Green;
					Link3.Clicked = true;
				}
				if ((cur_page % TOTAL_SUMMARY_PAGES) == 4)
				{
					Link4.ForeColor = System.Drawing.Color.Green;
					Link4.Clicked = true;
				}

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ArrangeSummaryPageLinks)");

			}

			return return_value;

		}
	}

}
