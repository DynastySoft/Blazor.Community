﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using Microsoft.JSInterop;
using System;
using System.Linq;
using System.Threading.Tasks;

using Dynasty.Database;
using Dynasty.Local;
using Microsoft.AspNetCore.DataProtection.AuthenticatedEncryption.ConfigurationModel;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;

namespace Dynasty.ASP.Shared
{
    public partial class SideBarMenu
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        [Inject]
        public ILogger<SideBarMenu> DynastyLogger { get; set; }       // ....... Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    NAMIMG CONVENSTION:  Each starts with "m" followed by a letter indicating data type
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                // ....... Keeps the current page/record info & status

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    NAMIMG CONVENSTION:  Each starts with "m" followed by a letter indicating data type
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;
        private clsGeneral moGeneral;

        private string msCompany_nm = "Dynasty.Blazor";

        private string[,] msUserSecurity;

        //  Menu-related vars
        private bool mbCollapseMenu = true;
        private bool mbHasPageName = true;
        private int miMenuIdClicked = 0;
        private int miPreviousMenuIdClicked = 0;
        public List<Models.clsMainMenu> mnuList = new List<Models.clsMainMenu>();
        private string NavMenuCss => mbCollapseMenu ? "collapse" : null;       // CSS for menu toggling
        private string LoadingMessage { get; set; } = "";

        private readonly string HELP_PAGE = "Help";                             // Should be match the actual page name in tblGOMenuNames
        private readonly string HOME_PAGE = "Home";

        private string CompanyName
        {
            get { return GlobalVar.gsCompany_nm;}
        }

        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;           // Loading is complete
        }
        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-redering.  (first_render_fl == true) only for the first time.
        {
            // Do clean-ups .
            //
            if (moDatabase.IsConnected())
            {
                moDatabase.CloseDatabase();
            }
        }
        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods whose name appears in most code-behind.          NAMIMG CONVENSTION:  Each method name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);

            LoadingMessage = "";            /// cur_db.oLanguage.oCaption.LOADING;

            return true;
        }

        private bool FormLoad()
        {

            if (SystemLogIn() == false)
            {
                return false;
            }
            else if (LoadMenu() == false)
            {
                return false;
            }

            modSetupUtility.SetCompanyName(moDatabase);

            return true;
        }
        private bool FormOpenDatabase()
        {
            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    ShowLoadingError(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  EVENT SECTION  :  UI-component event methods.                        NAMIMG CONVENSTION:  Each method name should end with "_Changed" proceeded by the component name.
        //  ===============================================================================================================================================================================================================================
        private bool ToggleMenu(bool enforced_fl = false)
        {
            if (enforced_fl)
            {
                mbCollapseMenu = !mbCollapseMenu;
            }
            else if (mbHasPageName)
            {
                mbCollapseMenu = !mbCollapseMenu;
            }
            return true;
        }

        public void MenuClicked(Models.clsMainMenu cur_menu)
        {

            Models.clsMainMenu temp_menu;

            miMenuIdClicked = cur_menu.iMenu_id;

            User.sPage_nm = "";

            if (miPreviousMenuIdClicked != miMenuIdClicked)
            {
                if (cur_menu.sPage_nm == HELP_PAGE)
                {
                    mbHasPageName = true;
                    OpenHelp();
                }
                else if (cur_menu.sPage_nm != "" || cur_menu.sMenu_nm == HOME_PAGE)
                {
                    mbHasPageName = true;

                    if (cur_menu.sPage_nm != "" && FormOpenDatabase())
                    {
                        moGeneral.UpdateMyFavorites(GlobalVar.WEB_MODULE_ID, cur_menu.sMenu_nm, cur_menu.sDescription, cur_menu.sPage_nm);
                        User.sPage_nm = cur_menu.sPage_nm;
                        User.iPageSecurityLevel = moGeneral.GetPageSecurityType(GlobalVar.WEB_MODULE_ID, User.sUserGroup_cd, User.sPage_nm);
                    }
                }
                else
                {
                    mbHasPageName = false;

                    // Reset all menu items
                    foreach (Models.clsMainMenu mnu in mnuList)
                    {
                        mnu.bExpended_fl = false;
                    }

                    cur_menu.bExpended_fl = !cur_menu.bExpended_fl;

                    // Expend the parent items climing up to the top.
                    temp_menu = cur_menu;
                    while (temp_menu.iParentMenu_id > 0)
                    {
                        temp_menu = mnuList.Find(m => (m.iMenu_id == temp_menu.iParentMenu_id));
                        temp_menu.bExpended_fl = true;
                    }
                }
            }
            else
            {
                cur_menu.bExpended_fl = !cur_menu.bExpended_fl;

                // Close all child items.
                foreach (Models.clsMainMenu mnu in mnuList.FindAll(m => (m.iParentMenu_id == cur_menu.iMenu_id)))
                {
                    mnu.bExpended_fl = false;
                }
            }

            miPreviousMenuIdClicked = miMenuIdClicked;

            GlobalVar.gsCompany_nm = GlobalVar.gsCompany_nm;        // DO NOT DELETE. Will trigger CompanyName.  Company name may have changed in master and setup advisor

        }

        private bool ExpendMenu(Models.clsMainMenu cur_menu)
        {
            int menu_level = 0;
            Models.clsMainMenu upper_level_menu;

            if (menu_level == 1)
            {
                return true;
            }
            else
            {
                upper_level_menu = mnuList.Find(mnu => mnu.iMenu_id == cur_menu.iParentMenu_id);

                return (upper_level_menu.bExpended_fl && upper_level_menu.iMenu_id == miMenuIdClicked) || (cur_menu.bExpended_fl && cur_menu.sPage_nm == "");

                // return cur_menu.bExpended_fl;
            }
        }

        private List<Models.clsMainMenu> ChildMenu(Models.clsMainMenu cur_menu)
        {
            return mnuList.FindAll(s => s.iParentMenu_id == cur_menu.iMenu_id);
        }

        private bool ChildMenuFound(Models.clsMainMenu cur_menu)
        {
            return (mnuList.FindIndex(s => s.iParentMenu_id == cur_menu.iMenu_id) >= 0);
        }

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================
        private bool SystemLogIn()
        {
            if (GlobalVar.goUtility.IsEmpty(User.sUser_cd))
            {
                //ShowLoadingError(cur_db.oLanguage.oMessage.PLEASE_LOG_IN_FIRST);
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            return true;
        }

        private bool ShowLoadingError(string msg)
        {
            LoadingMessage = msg;
            return true;
        }

        private bool LoadMenu()
        {
            if (modMenuUtility.LoadMenu(ref moDatabase, User.sLanguage_cd, ref mnuList, ref msUserSecurity, "", false, GlobalVar.WEB_MODULE_ID) == false)
            {
                if (moDatabase.IsErrorFound())
                {
                    // ShowLoadingError(moDatabase.GetErrorMessage());          
                }
                else
                {
                    // ShowLoadingError("Menu loading failed.");
                }

                return false;
            }

            return true;
        }

        private bool OpenHelp()
        {
            FormOpenPDF("WebHelp/index.htm");
            return true;
        }

    }
}
