﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Local;
using Microsoft.AspNetCore.Mvc;

namespace Dynasty.ASP.Pages.IV
{
    public partial class Quantity
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<Model> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;                                                               
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;
        private Models.clsSpreadsheet moSpreadsheet;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private Models.clsSession moSession;
        private clsMoney moMoney;
        private Models.clsSpreadsheet moDetail;

        private List<Models.clsCombobox> LocationCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> StatusTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> PhysicalCodeList = new List<Models.clsCombobox>();

        private string msOriginalBin_cd = "";

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader                   
        {
            // Listing of UI items on the header
            //
            public string txtKey_id = "";
            public string txtBin_cd = "";
            public string txtComment = "";

            public string cboLocation_cd = "";
            public string cboPhysicalCycle_cd = "";
            public string cboStatus_typ = "";

            public string txtOrderCost_amt = "";
            public string txtCarryCost_amt = "";
            public string txtReorderLevel_qty = "";
            public string txtMinLevel_qty = "";
            public string txtMaxLevel_qty = "";
            public string lblOnOrder_qty = "";
            public string lblInAssembly_qty = "";
            public string lblUnposted_qty = "";
            public string lblAllocToAssembly_qty = "";
            public string lblOnHand_qty = "";
            public string lblCommToDM_qty = "";
            public string lblCommToInvoice_qty = "";
            public string lblCommToOrder_qty = "";
            public string lblInTransOut_qty = "";
            public string lblInTransIn_qty = "";
            public string lblCommToTransfer_qty = "";
            public string lblAvailable_qty = "";
            public string lblCommToSpoilage_qty = "";
            public string lblPhysicalInventory_dt = "";
            public string lblInRepair_qty = "";

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag                                                                     
            {
                public string txtKey_id = "";
                public string txtBin_cd = "";
                public string cboLocation_cd = "";
                public string cboPhysicalCycle_cd = "";
                public string cboStatus_typ = "";
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()                                                                  
            {
                Tag.txtKey_id = txtKey_id;
                Tag.txtBin_cd = txtBin_cd;
                Tag.cboLocation_cd = cboLocation_cd;
                Tag.cboPhysicalCycle_cd = cboPhysicalCycle_cd;
                Tag.cboStatus_typ = cboStatus_typ;
            }
        }
        private clsHeader Header = new clsHeader();                                                 


        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;                        
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            moSession.RemoveSession(moDatabase);        // Delete the session file.

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows()
        {

            return true;
        }

        private bool FormCalculateTotal()
        {

            return true;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            if (FormCheckSecurity() == false)
            {
                return false;
            }
            else if (FormCheckHeader() == false)
            {
                return false;
            }
            else if (FormCheckExtra() == false)
            {
                return false;
            }

            return true;
        }

        private bool FormCheckExtra()                                                              // validate extra other than the header and detail.
        {
            bool return_value = false;

            try
            {

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckExtra)");
            }

            return return_value;
        }

        private bool FormCheckHeader()                                                             // validate the header data.
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    return false;                               // Not expected
                }
                if (moUtility.IsEmpty(Header.cboLocation_cd))
                {
                    FormShowMessage(User.Language.oMessage.SELECT_LOCATION);
                    FormSetFocus("cboLocation_cd");
                    return false;                               
                }
                if (moUtility.ToInteger(Header.cboStatus_typ) == 0)
                {
                    FormShowMessage(User.Language.oMessage.SELECT_STATUS);
                    FormSetFocus("cboStatus_typ");
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckHeader)");
            }

            return return_value;
        }

        private bool FormCheckConcurrency(clsRecordset cur_set)                                    // Check if someone has changed this record while it is open in this session.
        {
            if (cur_set.IsNonEmpty()) 
            {
                if (moPage.bNew_fl)
                {
                    // If someone has created a record with the same key
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.DUPLICATE_IS_FOUND + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                    moPage.bNew_fl = false;
                }
                else if (moPage.CheckForConcurrency(cur_set) == false)
                {
                    // If someone has updated this record in the meantime.
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        private bool FormCheckToDelete()
        {
            clsIntegrity o_integrity = new clsIntegrity(ref moDatabase);

            if (FormCheckSecurity() == false)
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }
            else if (modFormUtility.IsReservedRecord(ref moDatabase, Header.txtKey_id, moPage.bReserved_fl))
            {
                FormShowMessage(User.Language.oMessage.RESERVED_RECORD_IS_NOT_ALLOWED_TO_DELETE);
                return false;
            }
            else if (o_integrity.IsReferenced(moPage.sModule_id, moPage.sKeyField_nm, Header.txtKey_id))
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }

            return true;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearDetail();
            FormClearExtra();

            return true;
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            msOriginalBin_cd = "";

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearDetail()                                                                   // Clear the entire page.
        {

            moUtility.ResizeDim(ref moDetail.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, 0);
            FormRecreateGrid(moDetail);

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {
            Header.txtBin_cd = "";
            Header.txtComment = "";

            Header.cboLocation_cd = "";
            Header.cboPhysicalCycle_cd = "";
            Header.cboStatus_typ = "";

            Header.txtOrderCost_amt = "";
            Header.txtCarryCost_amt = "";
            Header.txtReorderLevel_qty = "";
            Header.txtMinLevel_qty = "";
            Header.txtMaxLevel_qty = "";
            Header.lblOnOrder_qty = "";
            Header.lblInAssembly_qty = "";
            Header.lblUnposted_qty = "";
            Header.lblAllocToAssembly_qty = "";
            Header.lblOnHand_qty = "";
            Header.lblCommToDM_qty = "";
            Header.lblCommToInvoice_qty = "";
            Header.lblCommToOrder_qty = "";
            Header.lblInTransOut_qty = "";
            Header.lblInTransIn_qty = "";
            Header.lblCommToTransfer_qty = "";
            Header.lblAvailable_qty = "";
            Header.lblCommToSpoilage_qty = "";
            Header.lblPhysicalInventory_dt = "";
            Header.lblInRepair_qty = "";

            return true;
        }

        private bool FormClearMessage()                                                            
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id) || moPage.bNew_fl)
                {
                    FormClear();
                    return true;
                }
                else if (FormCheckToDelete() == false)
                {
                    return false;
                }

                // Transaction begins here.
                //
                if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }

                if (modFormUtility.RecordDelete(ref moDatabase, moPage.iScreen_typ, Header.txtKey_id, moPage.sKeyField_nm, moPage.sTable_nm, moPage.sDetailTable_nm, moPage.sRestrictionClause, moPage.iTransaction_typ) == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }
                else if (FormDeleteExtra() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }

                // Transaction ends here.
                //
                if (moDatabase.TransactionCommit() == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDelete)");
                moDatabase.TransactionRollback();
                return_value = false;
            }

            return return_value;
        }

        private bool FormDeleteExtra()
        {

            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormFindRecord(ref clsRecordset cur_set, int matching_type = 0)
        {
            bool return_value = false;

            matching_type = (int)(moUtility.IIf(matching_type > 0, matching_type, GlobalVar.goConstant.MATCHING_RECORD_TYPE));
            return_value = modFormUtility.RecordRead(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sTable_nm, moPage.sKeyField_nm, moPage.sPreviousKey_id, moPage.sRestrictionClause, ref matching_type);

            return return_value;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moMoney = new clsMoney(ref moDatabase);
            moSession = new Models.clsSession();
            moDetail = new Models.clsSpreadsheet();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.IVMENU_NAME;
            moPage.Title = User.Language.oCaption.QUANTITY;
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormInitHeader();
            FormInitDetail();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitDetail()                                                              // Initialize the page at loading.  Only once.
        {
            // Detail table name.
            //
            moPage.sDetailTable_nm = "";

            moUtility.ResizeDim(ref moDetail.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, 0);

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = "tblIVItemQty"; 
            moPage.sKeyField_nm = "sItem_cd";
            moPage.iTransaction_typ= 0; 

            return true;
        }

        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback
            
            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;

            try 
            {
                if (FormReceiveValues() == false)                    // All pages that use session value need to capture it here before FormOpenDatabase()
                {
                    return false;
                }
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                modLoadUtility.LoadPhysicalInventoryCycleCode(ref moDatabase, ref PhysicalCodeList);
                modLoadUtility.LoadLocationCode(ref moDatabase, ref LocationCodeList);
                modLoadUtility.LoadItemStatusType(ref moDatabase, ref StatusTypeList, true);

                if (moUtility.IsNonEmpty(moPage.sInitialKey_id))
                {
                    Header.txtKey_id = moPage.sInitialKey_id;
                    Header.cboLocation_cd = moGeneral.GetDefaultLocationCode("");
                    cboLocation_cd_Clicked();
                }

                User.bConnected_fl = true;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormMove(int record_move_direction)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormClear();

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            if (FormFindRecord(ref cur_set, record_move_direction) == false)
            {
                return false;
            }

            FormShow(cur_set);
            return true;

        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostSave()
        {
            // If this is a transaction page, and transaction number has changed, let the user know.
            //
            if (moPage.sPreviousKey_id != Header.txtKey_id)
            {
                FormShowMessage(User.Language.oMessage.TRX_NUM_HAS_CHANGED_TO + "  " + Header.txtKey_id, false);
            }

            moPage.sPreviousKey_id = Header.txtKey_id;

            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {

            return true;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormReceiveValues()
        {
            // If connected already, return true.  This means this page came through the menu system.
            //
            if (moUtility.IsNonEmpty(User.sServer_nm) || moDatabase.IsConnected())
            {
                return true;
            }

            // Otherwise, need to login with the info passed from the calling page.
            //
            if (modGeneralUtility.GetPassedParameters(StarterValue, User, moSession) == false)
            {
                FormShowMessage(User.Language.oMessage.PLEASE_LOG_IN_FIRST);
                return false;
            }

            moPage.sInitialKey_id = moSession.Value.Entity;

            return true;
        }

        private bool FormSave()
        {
            bool return_value = false;
            clsRecordset cur_set;

            try
            {
                if (FormOpenDatabase() == false)                     // Has to come before FormCheck()
                {
                    return false;
                }
                else if (FormCheck() == false)                       // Check if data is ok to save.
                {
                    return false;
                }

                moPage.sPreviousKey_id = Header.txtKey_id;
                cur_set = new clsRecordset(ref moDatabase);

                if (modFormUtility.RecordOpen(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sRestrictionClause, moPage.sTable_nm, moPage.sKeyField_nm) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormCheckConcurrency(cur_set) == false)
                {
                    return false;
                }
                else if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormPreSave(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveHeader(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveExtra(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (moDatabase.TransactionCommit() == false)
                {
                    FormShowMessage();
                    moDatabase.TransactionRollback();
                    return false;
                }

                FormPostSave();
                    
                return_value = true;

            }
            catch (Exception ex)
            {

                FormShowMessage(ex.Message + " (FormSave)");
                moDatabase.TransactionRollback();

            }

            return return_value;
        }

        private bool FormSaveExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                if (GlobalVar.goBin.SetDefaultBin(ref moDatabase, Header.cboLocation_cd, Header.txtBin_cd,Header.txtKey_id, 0, msOriginalBin_cd) == false)
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormSaveHeader(clsRecordset cur_set)
        {
            bool return_value = false;
            string sql_str = null;

            try
            {
                sql_str = "UPDATE " + moPage.sTable_nm + " SET";
                sql_str += " sBin_cd = '" + Header.txtBin_cd + "'";
                sql_str += ",mOrderCost_amt = " + moMoney.ToNumMoney(Header.txtOrderCost_amt);
                sql_str += ",mCarryCost_amt = " + moMoney.ToNumMoney(Header.txtCarryCost_amt);
                sql_str += ",sPhysicalCycle_cd = '" + Header.cboPhysicalCycle_cd + "'";
                sql_str += ",iStatus_typ = " + moUtility.ToInteger(Header.cboStatus_typ).ToString();
                sql_str += ",sComment = '" + moUtility.EvalQuote(Header.txtComment) + "'";
                sql_str += ",fReorderLevel_qty = " + moMoney.ToNumMoney(Header.txtReorderLevel_qty);
                sql_str += ",fMinLevel_qty = " + moMoney.ToNumMoney(Header.txtMinLevel_qty);
                sql_str += ",fMaxLevel_qty = " + moMoney.ToNumMoney(Header.txtMaxLevel_qty);
                sql_str += ",sLastUpdate_id = '" + moDatabase.sUser_cd + "'";
                sql_str += ",dtLastUpdate_dt = " + moDatabase.CreateDatetimeValue(DateTime.Now);
                sql_str += " WHERE sItem_cd = '" + moUtility.EvalQuote(Header.txtKey_id) + "'";
                sql_str += " AND sLocation_cd = '" + Header.cboLocation_cd + "'";
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveHeader)");
            }

            return return_value;
        }

        private bool FormSearch()
        {

            return true;
        }

        private bool FormRecreateDetail(Models.clsSpreadsheet cur_spread)
        {
            if (cur_spread.RecreateDetail() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateDetailLine(Models.clsSpreadsheet.clsGrid cur_item, int row_num = -1)
        {
            if (moDetail.RecreateDetailLine(cur_item, row_num) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateGrid(Models.clsSpreadsheet cur_spread)
        {
            if (cur_spread.RecreateGrid() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {
            if (FormShowHeader(cur_set) == false)
            {
                return false;
            }
            else if (FormShowExtra(cur_set) == false)
            {
                return false;
            }
            else if (FormShowDetail() == false)
            {
                return false;
            }

            FormReArrangeHeader();

            return true;
        }

        private bool FormShowDetail()
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
				FormClearDetail();

                if (moValidate.IsValidItemBinCode(Header.txtKey_id, Header.cboLocation_cd, ""))
                {
                    moUtility.ResizeDim(ref moDetail.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, moValidate.oRecordset.RecordCount() - 1);
                    
                    for (row_num = 0; row_num < moValidate.oRecordset.RecordCount(); row_num++)
                    {
                        moDetail.Data[1, row_num] = moValidate.oRecordset.sField("sBin_cd");
                        moDetail.Data[2, row_num] = GlobalVar.goUtility.RoundToQtyFactor(moValidate.oRecordset.mField("fOnHand_qty") - moValidate.oRecordset.mField("fCommToPick_qty")).ToString();
                        moDetail.Data[3, row_num] = GlobalVar.goUtility.RoundToQtyFactor(moValidate.oRecordset.mField("fOnHand_qty")).ToString();
                        moDetail.Data[4, row_num] = GlobalVar.goUtility.RoundToQtyFactor(moValidate.oRecordset.mField("fMaxForThisItem_qty")).ToString();
                        moValidate.oRecordset.MoveNext();
                    }
                }

                FormRecreateGrid(moDetail);
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
            }

            return return_value;
        }

        private bool FormShowExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                moPage.Clear();
                moPage.PreserveTimestamp(cur_set);
                moPage.bNew_fl = false;

                // This is where bReadOnly_fl & bReserved_fl are set according to the nature of the current record.
                //

                msOriginalBin_cd = cur_set.sField("sBin_cd");

                moPage.sPreviousKey_id = Header.txtKey_id;
                Header.Preserve();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowHeader(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                Header.txtKey_id = cur_set.sField(moPage.sKeyField_nm);
                Header.txtComment = cur_set.sField("sComment");
                Header.cboLocation_cd = cur_set.sField("sLocation_cd");
                Header.cboPhysicalCycle_cd = cur_set.sField("sPhysicalCycle_cd");
                Header.cboStatus_typ = cur_set.iField("iStatus_typ").ToString();
                Header.txtBin_cd = cur_set.sField("sBin_cd");
                Header.txtOrderCost_amt = moMoney.ToStrMoney(cur_set.mField("mOrderCost_amt"));
                Header.txtComment = cur_set.sField("sComment");
                Header.txtCarryCost_amt = moMoney.ToStrMoney(cur_set.mField("mCarryCost_amt"));
                Header.txtReorderLevel_qty = cur_set.mField("fReorderLevel_qty").ToString();
                Header.txtMinLevel_qty = cur_set.mField("fMinLevel_qty").ToString();
                Header.txtMaxLevel_qty = cur_set.mField("fMaxLevel_qty").ToString();
                Header.lblPhysicalInventory_dt = moGeneral.ToStrDate(cur_set.iField("iLastPhysInv_dt"));
                Header.lblUnposted_qty = cur_set.mField("fUnposted_qty").ToString();
                Header.lblInAssembly_qty = cur_set.mField("fInAssembly_qty").ToString();
                Header.lblOnOrder_qty = cur_set.mField("fOnOrder_qty").ToString();
                Header.lblOnHand_qty = cur_set.mField("fOnHand_qty").ToString();
                Header.lblAllocToAssembly_qty = cur_set.mField("fAllocToAssembly_qty").ToString();
                Header.lblCommToOrder_qty = cur_set.mField("fCommToOrder_qty").ToString();
                Header.lblCommToInvoice_qty = cur_set.mField("fCommToInvoice_qty").ToString();
                Header.lblCommToDM_qty = cur_set.mField("fCommToDM_qty").ToString();
                Header.lblCommToTransfer_qty = cur_set.mField("fCommToTransfer_qty").ToString();
                Header.lblInTransIn_qty = cur_set.mField("fInTransferIn_qty").ToString();
                Header.lblInTransOut_qty = cur_set.mField("fInTransferOut_qty").ToString();
                Header.lblAvailable_qty = cur_set.mField("fAvailable_qty").ToString();
                Header.lblCommToSpoilage_qty = cur_set.mField("fCommToSpoilage_qty").ToString();
                Header.lblInRepair_qty = cur_set.mField("fInRepair_qty").ToString();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowHeader)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowListing()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moListing.Show(moDatabase, moPage) == false)
            {
                return false;
            }

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moZoom.Caller == "txtBin_cd")
            {
                if (moZoom.Code(ref moDatabase, "tblIVLocationBin", "sItem_cd") == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormClear();
                return true;
            }

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
                {
                    return false;
                }
            }

            FormCancel();
            return true;
        }

        private bool btnDelete_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormClear();
                return true;
            }

            if (FormDialog(btnDelete_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_DELETE) == false)
            {
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (FormDelete() == false)
            {
                return false;
            }
            
            FormClear();
            return true;
        }


        private bool btnFirst_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnFirst_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.FIRST_RECORD_TYPE);
        }

        private bool btnLast_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnLast_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.LAST_RECORD_TYPE);
        }

        private bool btnNext_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnNext_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.NEXT_RECORD_TYPE);
        }

        private bool btnPrevious_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnPrevious_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.PREVIOUS_RECORD_TYPE);
        }

        private bool btnSave_Clicked()
        {
            FormPreEvent();

            if (Modal.Activated)
            {
                return false;
            }
            if (FormSave() == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewHeader_Clicked()
        {
            FormPreEvent();                                                                           
            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool cmdViewListing_Clicked()
        {
            FormPreEvent();       
            
            if (FormShowListing() == false)
            {
                return false;
            }

            FormSwitchView(moView.LISTING_PAGE_NUM);
            return true;

        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        
        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                if (moUtility.IsEmpty(cur_item.Col_0))
                {
                    return false;
                }

                code_selected = cur_item.Col_0;

                if (moZoom.Caller == "txtBin_cd")
                {
                    Header.txtBin_cd = code_selected;
                    txtBin_cd_Changed();
                }

                FormSwitchView(moZoom.iView);
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();                                                                   

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }

        private bool btnZoomOnBin_cd_Clicked()
        {
            FormPreEvent();

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtBin_cd", -1, -1, moView.MAIN_PAGE_NUM, "sBin_cd", "") == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);   // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return true;
        }
        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool cboLocation_cd_Clicked()
        {
            if (Header.cboLocation_cd == Header.Tag.cboLocation_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (cboLocation_cd_Verified() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool txtBin_cd_Changed()
        {
            Header.txtBin_cd = modCommonUtility.CleanCode(Header.txtBin_cd);

            if (Header.txtBin_cd == Header.Tag.txtBin_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.txtBin_cd) || moUtility.IsEmpty(Header.cboLocation_cd))
            {
                return FormPostEvent();
            }
            if (Header.txtBin_cd == User.Language.oString.STR_WH_YARD)
            {
                FormShowMessage(User.Language.oString.STR_WH_YARD + User.Language.oMessage.IS_NOT_ALLOWED_FOR_TRANSACTION);
                Header.txtBin_cd = Header.Tag.txtBin_cd;
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moValidate.IsValidBinCode(Header.cboLocation_cd, Header.txtBin_cd) == false)
            {
                FormShowMessage(Header.txtBin_cd + User.Language.oMessage.IS_INVALID);
                Header.txtBin_cd = Header.Tag.txtBin_cd;
                return false;
            }
            else if (moUtility.IsNonEmpty(moValidate.oRecordset.sField("sItem_cd")) && moValidate.oRecordset.sField("sItem_cd") != Header.txtKey_id)
            {
                if (FormDialog(txtBin_cd_Changed, 100, Header.txtBin_cd + User.Language.oMessage.HAS_BEEN_OCCUPIED_ALREADY + User.Language.oMessage.WOULD_LIKE_PROCEED) == false)
                {
                    if (Modal.Activated == false)   // CANCEL button has been clicked & Dialog is closed now.
                    {
                        Header.txtBin_cd = Header.Tag.txtBin_cd;
                    }
                    return false;
                }
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================
        private bool cboLocation_cd_Verified()
        {
            bool return_value = false;
            clsRecordset cur_set;
            string sql_str = "";

            try
            {
                
                if (FormOpenDatabase() == false)
                {
                    FormClear();
                    FormShowMessage(User.Language.oMessage.CONNECTION_HAS_FAILED);
                    return false;
                }

                cur_set = new clsRecordset(ref moDatabase);

                sql_str = "SELECT * FROM tblIVItemQty WHERE sItem_cd = '" + Header.txtKey_id + "'";
                sql_str += " AND sLocation_cd = '" + Header.cboLocation_cd + "'";
                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    FormClear();
                    return false;
                }
                else if (cur_set.EOF())
                {
                    FormClear();
                    return true;
                }

                FormShow(cur_set);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (cboLocation_cd_Verified)");
            }

            return return_value;
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

    }
}
