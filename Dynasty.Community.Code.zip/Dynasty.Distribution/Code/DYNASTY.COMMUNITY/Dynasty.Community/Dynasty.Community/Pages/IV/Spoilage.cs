﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP.Pages.IV
{
    public partial class Spoilage
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<Sales> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;                                                               
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;
        private Models.clsSpreadsheet moSpreadsheet;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        private bool InventoryBusiness
        {
            get
            {
                return (moDatabase.iCurBusiness_typ == GlobalVar.goConstant.INVENTORY_BUSINESS_NUM);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsMoney moMoney;
        private clsCurrency moCurrency;
        private clsArray moArray;
        private clsSerial moSerial;

        private clsIVTransaction moIVTransaction;

        private List<Models.clsCombobox> StatusTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> FundCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> LocationCodeList = new List<Models.clsCombobox>();

        private string msDefaultRestrictionClause;
        private string msFund_cd = "";

        private decimal mmPriceExchange_rt = 0;
        private decimal mmExchange_rt = 0;
        private decimal mmSaleExchange_rt = 0;

        private bool mbWorkOrderExist_fl = false;

        // These are special flags to disable corresponding columns for fater entry.
        //
        public bool chkUseScanner_fl = false;
        public bool chkDisableDescription_fl = false;
        public bool chkDisableUnit_fl = false;
        public bool chkDisableQty_fl = false;
        public bool chkDisablePrice_fl = false;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader                   
        {
            // Listing of UI items on the header
            //
            public string txtKey_id = "";
            public string cboStatus_typ = "";
            public string cboFund_cd = "";
            public string cboLocation_cd = "";
            public string txtDescription = "";
            public string txtReference = "";
            
            public string txtComment = "";

            // POS for Mobile
            //
            public string txtPOSItem_cd = "";

            // Datetime component is not very user-friendly, yet, as of VS2019.
            // For better understanding this, read the comment on bUseDatePicker_fl in clsUser.
            //
            public string mskEntry_dt = "";
            public string mskApply_dt = "";
            public DateTime? dtEntry_dt = null;
            public DateTime? dtApply_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag                                                                     
            {
                public string txtKey_id  = "";
                public string cboStatus_typ = "";
                public string cboFund_cd = "";
                public string cboLocation_cd = "";

                public string txtPOSItem_cd = "";

                public string mskEntry_dt = "";
                public string mskApply_dt = "";
                public DateTime? dtEntry_dt = null;
                public DateTime? dtApply_dt = null;
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()                                                                  
            {
                Tag.txtKey_id = txtKey_id;
                Tag.cboStatus_typ = cboStatus_typ;
                Tag.cboFund_cd = cboFund_cd;
                Tag.cboLocation_cd = cboLocation_cd;

                Tag.txtPOSItem_cd = txtPOSItem_cd;

                Tag.mskEntry_dt = mskEntry_dt;
                Tag.mskApply_dt = mskApply_dt;
                Tag.dtEntry_dt = dtEntry_dt;
                Tag.dtApply_dt = dtApply_dt;
            }
        }
        private clsHeader Header = new clsHeader();                                                 


        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;                        
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            // If user uses date-picker, we need to change the date field.
            //
            if (User.bUseDatePicker_fl && moUtility.SLeft(field_name, 3) == "msk" && moUtility.SRight(field_name, 3) == "_dt")
            {
                field_name = moUtility.SReplace(field_name, "msk", "dt");
            }
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows()
        {
            if (moIVTransaction.AddMoreRows(User.iLinesToIncrease))
            {
                FormShowMessage();
                FormRecreateGrid();
                return false;
            }

            return true;
        }

        private bool FormCalculateCurrentRow(clsIVTransaction.clsDetail.clsGrid cur_item)
        {
            bool return_value = false;

            try
            {
                cur_item.lblExtended_amt = moMoney.ToStrMoney(moMoney.RoundToMoney(moUtility.ToValue(cur_item.txtQuantity) * moMoney.ToNumMoney(cur_item.txtUnitPrice_amt)));

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCalculateCurrentRow)");
            }

            return return_value;
        }

        private bool FormCalculateDue()
        {


            return true;
        }
        private bool FormCalculateTotal()
        {
            bool return_value = false;
            int row_num = 0;
            decimal total_amt = 0;

            try
            {
                
                return_value = FormCalculateDue();
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCalculateTotal)");
            }

            return return_value;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            if (FormCheckSecurity() == false)
            {
                return false;
            }
            else if (FormRecreateDetail() == false)
            {
                return false;
            }
            else if (FormCheckHeader() == false)
            {
                return false;
            }
            else if (FormCheckDetail() == false)
            {
                return false;
            }
            else if (FormCheckExtra() == false)
            {
                return false;
            }

            return true;
        }

        private bool FormCheckDetail()                                                             // validate Detail for saving.
        {
            bool return_value = false;
            int row_num = 0;
            bool one_record_exist = false;

            try
            {
                FormRecreateDetail();       // Just to make sure.

                for (row_num = 0; row_num < moIVTransaction.sDetailData.GetLength(1); row_num++)
                {
                    // If item_code is not a blank, then check the unit_code and qty.
                    // Otherwise, do not bother.
                    //
                    if (moUtility.IsNonEmpty(moIVTransaction.sDetailData[clsIVTransaction.ITEM_CODE_COL, row_num]) && moUtility.ToValue(moIVTransaction.sDetailData[clsIVTransaction.QTY_COL, row_num]) >= moDatabase.fSmallestNumber)
                    {
                        // user may have changed location_code after the details are entered.
                        //
                        moIVTransaction.sDetailData[clsIVTransaction.LOCATION_COL, row_num] =  Header.cboLocation_cd;

                        if (moUtility.ToValue(moIVTransaction.sDetailData[clsIVTransaction.QTY_COL, row_num]) >= moDatabase.fSmallestNumber && moUtility.IsEmpty(moIVTransaction.sDetailData[clsIVTransaction.UNIT_CODE_COL, row_num]))
                        {
                            FormShowMessage(User.Language.oMessage.UNIT_CODE_IS_MISSING_ON_THE_LINE + " " + (row_num + 1).ToString());
                            return false;
                        }
                        if (moSerial.IsSerialOrLotItem(moUtility.ToInteger(moIVTransaction.sDetailData[clsIVTransaction.ITEM_TYPE_COL, row_num])))
                        {
                            if (moUtility.IsEmpty(moIVTransaction.sDetailData[clsIVTransaction.SERIAL_CODE_COL, row_num]))
                            {
                                FormShowMessage(User.Language.oMessage.PLEASE_ENTER + User.Language.oCaption.SERIAL_NUMBER + " " + (row_num + 1).ToString());
                                return false;
                            }
                            if (moSerial.IsSerialItem(moUtility.ToInteger(moIVTransaction.sDetailData[clsIVTransaction.ITEM_TYPE_COL, row_num])) && Math.Abs(moUtility.ToValue(moIVTransaction.sDetailData[clsIVTransaction.QTY_COL, row_num])) > 1)
                            {
                                FormShowMessage(User.Language.oMessage.SERIAL_ITEM_DOES_NOT_ALLOW_MORE_THAN_1 + moIVTransaction.sDetailData[clsIVTransaction.ITEM_CODE_COL, row_num] + "/" + moIVTransaction.sDetailData[clsIVTransaction.SERIAL_CODE_COL, row_num]);
                                return false;
                            }
                        }

                        one_record_exist = true;
                    }
                    else
                    {
                        moIVTransaction.sDetailData[clsIVTransaction.ITEM_CODE_COL, row_num] = "";
                        moIVTransaction.sDetailData[clsIVTransaction.SERIAL_CODE_COL, row_num] = "";
                        moIVTransaction.sDetailData[clsIVTransaction.UNIT_CODE_COL, row_num] = "";
                        moIVTransaction.sDetailData[clsIVTransaction.QTY_COL, row_num] = "0";
                        moIVTransaction.sDetailData[clsIVTransaction.QTY_IN_IVUNIT_COL, row_num] = "0";
                    }
                }

                if (one_record_exist == false)
                {
                    FormShowMessage(User.Language.oMessage.NO_DETAIL_EXIST_PUT_ON_HOLD);
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckDetail)");
            }

            return return_value;
        }


        private bool FormCheckExtra()                                                              // validate extra other than the header and detail.
        {
            bool return_value = false;

            try
            {

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckExtra)");
            }

            return return_value;
        }

        private bool FormCheckHeader()                                                             // validate the header data.
        {
            bool return_value = false;

            try
            {
                // GENERIC VALIDATIONS FOR ALL TRASNACTIONS
                //
                msFund_cd = GlobalVar.goFund.GetSelectedFundCodeToSave(ref moDatabase, Header.cboFund_cd);

                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormShowMessage(User.Language.oString.STR_TRANSACTION_NUMBER + @User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("txtKey_id");
                    return false;
                }
                else if (moDatabase.bFundAccounting_fl && moUtility.IsEmpty(msFund_cd))
                {
                    FormShowMessage(User.Language.oCaption.FUND_CODE + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("cboFund_cd");
                    return false;
                }
                else if (moUtility.ToInteger(Header.cboStatus_typ) == 0)
                {
                    FormShowMessage(User.Language.oMessage.STATUS_HAS_TO_BE_SELECTED);
                    FormSetFocus("cboStatus_typ");
                    return false;
                }
                else if (moUtility.IsBlankDate(Header.mskEntry_dt))
                {
                    FormShowMessage(User.Language.oMessage.ENTRY_DATE_IS_REQUIRED);
                    FormSetFocus("mskEntry_dt");
                    return false;
                }
                else if (moUtility.ToInteger(Header.cboStatus_typ) != GlobalVar.goConstant.OPEN_TRX_NUM)
                {
                    if (moUtility.IsBlankDate(Header.mskApply_dt))
                    {
                        Header.mskApply_dt = Header.mskEntry_dt;
                        FormSyncDates(false);
                    }
                    return true;
                }
                else if (moUtility.IsBlankDate(Header.mskApply_dt))
                {
                    FormShowMessage(User.Language.oCaption.APPLY_DATE + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("mskApply_dt");
                    return false;
                }
                else if (moDatabase.bRequireDescription_fl && moUtility.IsEmpty(Header.txtDescription))
                {
                    FormShowMessage(User.Language.oCaption.DESCRIPTION + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("txtDescription");
                    return false;
                }


                //  TRANSACTION SPECIFIC VALIDATIONS  BELOW.
                //

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckHeader)");
            }

            return return_value;
        }

        private bool FormCheckConcurrency(clsRecordset cur_set)                                    // Check if someone has changed this record while it is open in this session.
        {
            if (cur_set.IsNonEmpty()) 
            {
                if (moPage.bNew_fl)
                {
                    // If someone has created a record with the same key
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.DUPLICATE_IS_FOUND + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                    moPage.bNew_fl = false;
                }
                else if (moPage.CheckForConcurrency(cur_set) == false)
                {
                    // If someone has updated this record in the meantime.
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                }
            }
            else if (moPage.bNew_fl == false)
            {
                // If current record is missing, it could have been posted by someone.
                // Need to make sure it does not exist in the posted table.
                //
                if (moValidate.IsValidTransaction(moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id), false))
                {
                    FormShowMessage(User.Language.oMessage.THIS_TRX_EXISTS_AND_HAS_BEEN_POSTED_ALREADY);
                    return false;
                }
            }

            return true;
        }

        private bool FormCheckToDelete()
        {
            clsIntegrity o_integrity = new clsIntegrity(ref moDatabase);

            if (FormCheckSecurity() == false)
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }
            else if (modFormUtility.IsReservedRecord(ref moDatabase, Header.txtKey_id, moPage.bReserved_fl))
            {
                FormShowMessage(User.Language.oMessage.RESERVED_RECORD_IS_NOT_ALLOWED_TO_DELETE);
                return false;
            }
            else if (o_integrity.IsReferenced(moPage.sModule_id, moPage.sKeyField_nm, Header.txtKey_id))
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }

            return true;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearDetail();
            FormClearExtra();

            return true;
        }

        private bool FormClearDetail()                                                             // Clear the detail.
        {
            moIVTransaction.Detail.iNextLine_id = 1;
            moIVTransaction.iTotalRows = User.iLinesToIncrease;
            moUtility.ResizeDim(ref moIVTransaction.sDetailData, clsIVTransaction.TOTAL_COLUMNS - 1, moIVTransaction.iTotalRows - 1);

            return FormRecreateGrid();
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {
            Header.txtKey_id = "";
            Header.cboFund_cd = "";
            Header.cboStatus_typ = "";
            Header.txtDescription = "";
            Header.txtReference = "";
            Header.cboLocation_cd = "";

            Header.txtComment = "";

            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            //
            Header.mskEntry_dt = "";
            Header.mskApply_dt = "";
            FormSyncDates(false);

            return true;
        }

        private bool FormClearMessage()                                                            
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id) || moPage.bNew_fl)
                {
                    FormClear();
                    return true;
                }
                else if (FormCheckToDelete() == false)
                {
                    return false;
                }

                // Transaction begins here.
                //
                if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }

                if (modFormUtility.RecordDelete(ref moDatabase, moPage.iScreen_typ, Header.txtKey_id, moPage.sKeyField_nm, moPage.sTable_nm, moPage.sDetailTable_nm, moPage.sRestrictionClause, moPage.iTransaction_typ) == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }
                else if (FormDeleteExtra() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }

                // Transaction ends here.
                //
                if (moDatabase.TransactionCommit() == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDelete)");
                moDatabase.TransactionRollback();
                return_value = false;
            }

            return return_value;
        }

        private bool FormDeleteExtra()
        {

            return true;
        }

        private bool FormDeleteCurrentRow(clsIVTransaction.clsDetail.clsGrid cur_item)
        {
            bool return_value = false;
            int old_num = cur_item.Row_num;

            try
            {
                if (moIVTransaction.DeleteCurrentRow(cur_item) == false)
                {
                    FormShowMessage();
                    FormRecreateGrid();
                    return false;
                }
                if (FormCalculateTotal() == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDeleteCurrentRow)");
                FormRecreateGrid();
            }

            return return_value;
        }

        private bool FormEnableBatch(bool switch_fl = true)
        {
            

            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormFindRecord(ref clsRecordset cur_set, int matching_type = 0)
        {
            bool return_value = false;

            matching_type = (int)(moUtility.IIf(matching_type > 0, matching_type, GlobalVar.goConstant.MATCHING_RECORD_TYPE));
            return_value = modFormUtility.RecordRead(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sTable_nm, moPage.sKeyField_nm, moPage.sPreviousKey_id, moPage.sRestrictionClause, ref matching_type);

            return return_value;
        }


        public bool FormCheckExchangeRate(int apply_date = 0)
        {

            bool return_value = false;
            decimal old_exchange_rate = mmSaleExchange_rt; // DO NOT change to Double because of comparison issue
            decimal old_price_exchange_rate = mmPriceExchange_rt;

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                mmSaleExchange_rt = 1;
                mmPriceExchange_rt = 1;
                return return_value;
            }
            else if (moUtility.IsEmpty(Header.mskApply_dt) && apply_date == 0)
            {
                mmSaleExchange_rt = 1;
                mmPriceExchange_rt = 1;
                return return_value;
            }

            if (apply_date == 0)
            {
                apply_date = moGeneral.ToNumDate(Header.mskApply_dt);
            }
            if (apply_date == 0)
            {
                apply_date = moGeneral.CurrentDate();
            }

            moCurrency.GetSaleExchangeRate(moDatabase.sCurrency_cd, ref mmSaleExchange_rt, ref mmPriceExchange_rt, apply_date);

            if ((old_exchange_rate != mmSaleExchange_rt) || (old_price_exchange_rate != mmPriceExchange_rt))
            {
                return_value = true;
            }

            return return_value;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moMoney = new clsMoney(ref moDatabase);
            moCurrency = new clsCurrency(ref moDatabase);
            moArray = new clsArray();
            moSerial = new clsSerial(ref moDatabase);

            moIVTransaction = new clsIVTransaction(ref moDatabase);
            moIVTransaction.iTransaction_typ = GlobalVar.goConstant.TRX_SPOILAGE_TYPE;

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.IVMENU_NAME;
            moPage.Title = User.Language.oCaption.SPOILAGE_ENTRY;
            moPage.iScreen_typ = GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE;
            moPage.iTransaction_typ = moIVTransaction.iTransaction_typ;
            moPage.iJournal_typ = 0;

            // sRestrictionClause will need to change as some conditions change, which is done in ResetRestrictionClause().
            // moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);
            msDefaultRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);
            ResetRestrictionClause();

            Modal.Release();

            FormInitHeader();
            FormInitDetail();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitDetail()                                                              // Initialize the page at loading.  Only once.
        {
            // Detail table name.
            //
            moPage.sDetailTable_nm = clsIVTransaction.DETAIL_TABLE_NAME;

            FormClearDetail();

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = clsIVTransaction.HEADER_TABLE_NAME; 
            moPage.sKeyField_nm = clsIVTransaction.KEY_FIELD_NAME;

            return true;
        }

        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {

            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            // FormSave() & FormCheck() use the plain textbox whose name starts with "msk"
            // dt* variables are only to interact with UI.  Internally, msk* fields are used.
            //
            FormSyncDates(User.bUseDatePicker_fl);


            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback
            
            return true;
        }

        private bool FormInsertNewRow(clsIVTransaction.clsDetail.clsGrid cur_item)
        {
            bool return_value = false;
            int old_num = cur_item.Row_num;

            try
            {
                if (moIVTransaction.InsertNewRow(cur_item) == false)
                {
                    FormShowMessage();
                    FormRecreateGrid();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormInsertNewRow)");
                FormRecreateGrid();
            }

            return return_value;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;

            try 
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                modLoadUtility.LoadLocationCode(ref moDatabase, ref LocationCodeList);
                modLoadUtility.LoadStatusType(ref moDatabase, ref StatusTypeList);
                modLoadUtility.LoadFundCode(ref moDatabase, ref FundCodeList, moGeneral.CurrentDate(), GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE); // Need to load fund whether it is fund accouning or not

                FormEnableBatch(false);

                ResetRestrictionClause();                                       // Has to set here after database connection.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormMove(int record_move_direction)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormClear();

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            if (FormFindRecord(ref cur_set, record_move_direction) == false)
            {
                return false;
            }

            FormShow(cur_set);
            return true;

        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostSave()
        {
            // If this is a transaction page, and transaction number has changed, let the user know.
            //
            if (moPage.sPreviousKey_id != Header.txtKey_id)
            {
                FormShowMessage(User.Language.oMessage.TRX_NUM_HAS_CHANGED_TO + "  " + Header.txtKey_id, false);
            }

            moPage.sPreviousKey_id = Header.txtKey_id;

            return true;
        }

        private bool FormPostTransactionRealtime()
        {
            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {

            // Put some extra validation against the existing record
            // before saving the current modification.
            //
            if (moPage.bNew_fl == false && cur_set.IsNonEmpty())    // Both goUtility.ToInteger(txtNew_fl.Text) and cur_set.Empty() should be checked : DO NOT CHANGE.
            {

            }
            else if (modGeneralUtility.CheckTransactionNumber(ref moDatabase, moPage.bNew_fl, moPage.iScreen_typ, moPage.iTransaction_typ, ref Header.txtKey_id) == false)
            {
                return false;
            }

            // Someone could have saved with the same number.
            //
            if (moPage.bNew_fl && Header.txtKey_id != moPage.sPreviousKey_id)
            {
                cur_set.Release();
            }
            return true;
        }

        private bool FormReArrangeDetail()                                                         // Arrange(show/hide, enable/disable) the columns in the detail(grid)
        {

            return true;
        }

        private bool FormReArrangeHeader()                                                         //  Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormRecreateDetail()                                                           //  Sync moIVTransaction.sDetailData with moIVTransaction.Detail.Grid for the items that do not have event-handler ONLY.
        {
            if (moIVTransaction.RecreateDetail() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateDetailLine(clsIVTransaction.clsDetail.clsGrid cur_item, int row_num = -1)
        {
            if (moIVTransaction.RecreateDetailLine(cur_item, row_num) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateGrid()                                                             //  Create moIVTransaction.Detail.Grid according to moIVTransaction.sDetailData
        {
            if (moIVTransaction.RecreateGrid() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormSave()
        {
            bool return_value = false;
            clsRecordset cur_set;

            try
            {
                if (FormOpenDatabase() == false)                     // Has to come before FormCheck()
                {
                    return false;
                }
                else if (FormCheck() == false)                       // Check if data is ok to save.
                {
                    return false;
                }

                moPage.sPreviousKey_id = Header.txtKey_id;
                cur_set = new clsRecordset(ref moDatabase);

                if (modFormUtility.RecordOpen(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sRestrictionClause, moPage.sTable_nm, moPage.sKeyField_nm) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormCheckConcurrency(cur_set) == false)
                {
                    return false;
                }
                else if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormPreSave(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveHeader(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveExtra(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveDetail() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (moIVTransaction.SaveTransaction(ref cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormPostTransactionRealtime() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (moDatabase.TransactionCommit() == false)
                {
                    FormShowMessage();
                    moDatabase.TransactionRollback();
                    return false;
                }

                FormPostSave();
                    
                return_value = true;

            }
            catch (Exception ex)
            {

                FormShowMessage(ex.Message + " (FormSave)");
                moDatabase.TransactionRollback();

            }

            return return_value;
        }

        private bool FormSaveDetail()
        {
            bool return_value = false;

            try
            {
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveDetail)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormSaveExtra(clsRecordset cur_set)
        {
            bool return_value = false;
            string extra_log = "";
            string journal_name = "";

            try
            {
                if (SaveSerial() == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormSaveHeader(clsRecordset cur_set)
        {
            bool return_value = false;
            string sql_str = null;

            try
            {

                moIVTransaction.bNew_fl = (moPage.bNew_fl || cur_set.EOF());

                // This is for Concurrency check to go smooth.
                // If someone calls FormSave() without going thru the whole saving routine that
                // clears the screen, and save again later, then FormCheckConcurrency() will raise an error
                // because the record in the database has been updated but moPage.Original.dtLastUpdate_dt still has the old timestamp.
                //
                moPage.Original.sLastUpdate_id = moDatabase.sUser_cd;
                moPage.Original.dtLastUpdate_dt = DateTime.Now;

                moIVTransaction.iTransaction_typ = moPage.iTransaction_typ;
                moIVTransaction.iTransaction_num = moUtility.ToInteger(Header.txtKey_id);
                moIVTransaction.iStatus_typ = moUtility.ToInteger(Header.cboStatus_typ);
                moIVTransaction.iApply_dt = moGeneral.ToNumDate(Header.mskEntry_dt);
                moIVTransaction.iEntry_dt = moGeneral.ToNumDate(Header.mskEntry_dt);
                moIVTransaction.sReference = moUtility.EvalQuote(Header.txtReference);
                moIVTransaction.sDescription = moUtility.EvalQuote(Header.txtDescription);

                moIVTransaction.sToLocation_cd = Header.cboLocation_cd;
                moIVTransaction.sComment = moUtility.EvalQuote(Header.txtComment);

                moIVTransaction.sCreator_id = moPage.Original.sLastUpdate_id;
                moIVTransaction.sLastUpdate_id = moPage.Original.sLastUpdate_id;
                moIVTransaction.dtLastUpdate_dt = moPage.Original.dtLastUpdate_dt;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveHeader)");
            }

            return return_value;
        }

        private bool FormSearch()
        {

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {
            if (FormShowHeader(cur_set) == false)
            {
                return false;
            }
            else if (FormShowDetail() == false)
            {
                return false;
            }
            else if (FormShowExtra(cur_set) == false)
            {
                return false;
            }

            FormReArrangeHeader();
            FormReArrangeDetail();

            return true;
        }

        private bool FormShowDetail()
        {
            bool return_value = false;
            clsRecordset cur_set = new clsRecordset(ref moDatabase);
            int col_num = 0;
            int row_num = 0;
            string sql_str = "";
            string data_field = "";
            string tmp = "";

            try
            {
                FormClearDetail();

                sql_str = "SELECT serial.sSerial_num, det.* FROM tblIVTransactionDetUnposted det LEFT JOIN tblGOSerialTransaction serial";
                sql_str += " ON (det.iTransaction_typ = serial.iTransaction_typ AND det.iTransaction_num = serial.iTransaction_num AND det.iLine_id = serial.iDetail_num) ";
                sql_str += " WHERE det.iTransaction_typ = " + moPage.iTransaction_typ.ToString();
                sql_str += " AND det.iTransaction_num = " + moUtility.ToInteger(Header.txtKey_id).ToString();
                sql_str += " ORDER BY det.iDetail_num";
                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                moIVTransaction.iTotalRows = cur_set.RecordCount() + 4;

                moUtility.ResizeDim(ref moIVTransaction.sDetailData, clsIVTransaction.TOTAL_COLUMNS - 1, moIVTransaction.iTotalRows - 1);

                while (cur_set.EOF() == false)
                {
                    for (col_num = 0; col_num < clsIVTransaction.TOTAL_COLUMNS; col_num++)
                    {
                        data_field = moIVTransaction.sDetailFieldNames[col_num];

                        if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SRight(data_field, GlobalVar.goUtility.SLength(GlobalVar.goRule.AMOUNT_FIELD_SUFFIX))) == GlobalVar.goUtility.SUCase(GlobalVar.goRule.AMOUNT_FIELD_SUFFIX))
                        {
                            tmp = moMoney.ToStrMoney(cur_set.mField(data_field));
                        }
                        else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SRight(data_field, GlobalVar.goUtility.SLength(GlobalVar.goRule.DATE_FIELD_SUFFIX))) == GlobalVar.goUtility.SUCase(GlobalVar.goRule.DATE_FIELD_SUFFIX)
                        && GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(data_field, GlobalVar.goUtility.SLength(GlobalVar.goRule.INTEGER_FIELD_PREFIX))) == GlobalVar.goUtility.SUCase(GlobalVar.goRule.INTEGER_FIELD_PREFIX))
                        {
                            tmp = moGeneral.ToStrDate(cur_set.iField(data_field));
                        }
                        else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(data_field, GlobalVar.goUtility.SLength(GlobalVar.goRule.FLOAT_FIELD_PREFIX))) == GlobalVar.goUtility.SUCase(GlobalVar.goRule.FLOAT_FIELD_PREFIX))
                        {

                            // 02/28/2020
                            // Extra qty used to be represented with "-" sign which confused users.
                            //
                            if (cur_set.mField(data_field) < 0)
                            {
                                tmp = "(" + Math.Abs(cur_set.mField(data_field)).ToString() + ")";
                            }
                            else
                            {
                                tmp = cur_set.mField(data_field).ToString();
                            }

                        }
                        else
                        {
                            tmp = GlobalVar.goUtility.ToStr(cur_set.Field(data_field));
                        }

                        moIVTransaction.sDetailData[col_num, row_num] = tmp;
                    }

                    moIVTransaction.sDetailData[clsIVTransaction.SERIAL_CODE_COL, row_num] = cur_set.sField("sSerial_num");

                    cur_set.MoveNext();
                    row_num += 1;
                }

                moIVTransaction.Detail.iNextLine_id = modCommonUtility.GetNextLineId(moIVTransaction.sDetailData, clsIVTransaction.LINE_ID_COL);

                if (FormRecreateGrid() == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowDetail)");
            }

            return return_value;
        }

        private bool FormShowExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                moPage.Clear();
                moPage.PreserveTimestamp(cur_set);
                moPage.PreserveOriginal(cur_set);
                moPage.bNew_fl = false;

                // This is where bReadOnly_fl & bReserved_fl are set according to the nature of the current record.
                //


                moPage.sPreviousKey_id = Header.txtKey_id;
                Header.Preserve();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowHeader(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                Header.txtKey_id = cur_set.sField(moPage.sKeyField_nm);
                Header.txtDescription = cur_set.sField("sDescription");
                Header.txtReference = cur_set.sField("sReference");
                Header.cboStatus_typ = cur_set.iField("iStatus_typ").ToString();
                Header.cboFund_cd = GlobalVar.goFund.GetSelectedFundCodeToDisplay(ref moDatabase, cur_set.sField("sFund_cd"));
                Header.cboLocation_cd = cur_set.sField("sToLocation_cd");

                Header.txtComment = cur_set.sField("sComment");

                // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
                // Make sure both, dt* and msk*, are sync'ed.
                //
                Header.mskEntry_dt = moGeneral.ToStrDate(cur_set.iField("iEntry_dt"));
                Header.mskApply_dt = moGeneral.ToStrDate(cur_set.iField("iApply_dt"));
                FormSyncDates(false);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowHeader)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowListing()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moListing.Show(moDatabase, moPage, "", "", "", "iStatus_typ", "iEntry_dt") == false)
            {
                return false;
            }
            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtApply_dt, ref Header.mskApply_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtEntry_dt, ref Header.mskEntry_dt, use_date_picker);

            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            moView.SwitchView(moPage, cur_page);

            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moZoom.iColumn == clsIVTransaction.ITEM_CODE_COL)
            {
                if (moZoom.Inventory(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormClear();
                return true;
            }

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
                {
                    return false;
                }
            }

            FormCancel();
            return true;
        }

        private bool btnCopy_Clicked()
        {
            

            return true;
        }


        private bool btnDelete_Clicked()
        {
            FormPreEvent();

            // We do not delete the transactions.
            
            FormClear();
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormExit();
                return true;
            }

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }

        private bool btnFirst_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnFirst_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.FIRST_RECORD_TYPE);
        }

        private bool btnLast_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnLast_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.LAST_RECORD_TYPE);
        }

        private bool btnNext_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnNext_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.NEXT_RECORD_TYPE);
        }

        private bool btnPrevious_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnPrevious_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.PREVIOUS_RECORD_TYPE);
        }

        private bool btnSave_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormSave() == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewHeader_Clicked()
        {
            FormPreEvent();                                                                           
            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool cmdViewListing_Clicked()
        {
            FormPreEvent();       
            
            if (FormShowListing() == false)
            {
                return false;
            }

            FormSwitchView(moView.LISTING_PAGE_NUM);
            return true;

        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnListingSelect_Clicked(Models.clsListing.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.IsEmpty(cur_item.Code))
            {
                return false;
            }

            FormClear();
            Header.txtKey_id = cur_item.Code;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;

            FormPreEvent();

            try
            {
                if (moUtility.IsEmpty(cur_item.Col_0))
                {
                    return false;
                }

                // moIVTransaction.Detail.Grid.Single(i => i.Row_num == moZoom.iRow).txtItem_cd = cur_item.Col_0;
                // moIVTransaction.sDetailData[moZoom.iColumn, moZoom.iRow] = cur_item.Col_0;

                clsIVTransaction.clsDetail.clsGrid detail_item = moIVTransaction.Detail.Grid.Single(i => i.Row_num == moZoom.iRow);

                if (moZoom.iColumn == clsIVTransaction.ITEM_CODE_COL)
                {
                    detail_item.txtItem_cd = cur_item.Col_0;
                    if (DetailItem_cd_Changed(detail_item) == false)
                    {
                        return false;
                    }
                }
                
                FormSwitchView(moZoom.iView);
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }
        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool cmdNew_Clicked()
        {
            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            FormClear();

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            // Get the next transaction number.  This would not consume the number.  FormSave() will consume the number.
            //
            Header.txtKey_id = modGeneralUtility.ReadNextTransactionNumber(ref moDatabase, moPage.iTransaction_typ).ToString();

            if (moUtility.ToInteger(Header.txtKey_id) > 0)
            {
                Header.cboLocation_cd = moGeneral.GetDefaultLocationCode("");
                Header.cboStatus_typ = GlobalVar.goConstant.OPEN_TRX_NUM.ToString();
                Header.mskEntry_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                Header.mskApply_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                FormSyncDates(false);
            }
            else
            {
                FormShowMessage();
                Header.txtKey_id = "";
            }

            return FormPostEvent();
        }
        private bool txtKey_id_Changed()
        {
            if (Header.txtKey_id == Header.Tag.txtKey_id)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (txtKey_id_Verified() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool chkUseScanner_fl_Clicked()
        {
            FormPreEvent();

            // boolean click event kickes in before the value is changed 
            // so that we need to handle this according to the previous value.
            //
            chkDisableDescription_fl = (chkUseScanner_fl == false);
            chkDisablePrice_fl = (chkUseScanner_fl == false);
            chkDisableQty_fl = (chkUseScanner_fl == false);
            chkDisableUnit_fl = (chkUseScanner_fl == false);

            return FormPostEvent();
        }

        private bool cmdPOSFind_Clicked()
        {
            txtPOSItem_cd_Changed();

            return true;
        }

        private bool txtPOSItem_cd_Changed()                                                // This is available only when scanner option is checked
        {
            Header.txtPOSItem_cd = modCommonUtility.CleanCode(Header.txtPOSItem_cd);

            if (Header.txtPOSItem_cd == Header.Tag.txtPOSItem_cd)
            {
                return FormPostEvent();
            }

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                Header.txtPOSItem_cd = "";
                FormSwitchView(moView.MAIN_PAGE_NUM);
                FormSetFocus("txtKey_id");
                return FormPostEvent();
            }

            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moUtility.IsNonEmpty(Header.txtPOSItem_cd))
            {
                txtPOSItem_cd_Verified();
                FormCalculateTotal();
            }

            Header.txtPOSItem_cd = "";
            FormSetFocus("txtPOSItem_cd");

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Verified()
        {
            bool return_value = false;
            clsRecordset cur_set;
            string key_id = "";

            try
            {
                if (moUtility.ToInteger(Header.txtKey_id) > 0)
                {
                    Header.txtKey_id = moUtility.ToInteger(Header.txtKey_id).ToString();
                }
                else
                {
                    Header.txtKey_id = "";
                }

                key_id = Header.txtKey_id;

                if (Header.txtKey_id == Header.Tag.txtKey_id)
                {
                    return true;
                }
                else if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormClear();
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    FormClear();
                    FormShowMessage(User.Language.oMessage.CONNECTION_HAS_FAILED);
                    return false;
                }

                cur_set = new clsRecordset(ref moDatabase);

                if (FormFindRecord(ref cur_set))
                {
                    FormShow(cur_set);
                }
                else
                {
                    cmdNew_Clicked();
                    FormShowMessage(key_id + User.Language.oMessage.IS_NOT_FOUND);
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtKey_id_Verified)");
            }

            return return_value;
        }

        private bool dtEntry_dt_Changed()
        {
            if (Header.dtEntry_dt == Header.Tag.dtEntry_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtEntry_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtEntry_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtEntry_dt) == false)
            {
                Header.dtEntry_dt = Header.Tag.dtEntry_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtEntry_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskEntry_dt_Changed()
        {
            if (Header.mskEntry_dt == Header.Tag.mskEntry_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskEntry_dt) == false)
            {
                Header.mskEntry_dt = Header.Tag.mskEntry_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskEntry_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtApply_dt_Changed()
        {
            if (Header.dtApply_dt == Header.Tag.dtApply_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtApply_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtApply_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtApply_dt) == false)
            {
                Header.dtApply_dt = Header.Tag.dtApply_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtApply_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskApply_dt_Changed()
        {
            if (Header.mskApply_dt == Header.Tag.mskApply_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskApply_dt) == false)
            {
                Header.mskApply_dt = Header.Tag.mskApply_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskApply_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool txtPOSItem_cd_Verified()
        {
            int row_num = 0;
            bool item_found_fl = false;
            bool found_by_serial_num_fl = false;
            decimal sell_unit_price = 0;

            clsIVTransaction.clsDetail.clsGrid grid_line;

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moValidate.IsValidItemAnyCode(Header.txtPOSItem_cd, Header.cboLocation_cd, ref found_by_serial_num_fl) == false)
            {
                FormShowMessage(Header.txtPOSItem_cd + User.Language.oMessage.DOES_NOT_EXIST);
                return false;
            }

            Header.txtPOSItem_cd = moValidate.oRecordset.sField("sItem_cd"); // This is necessary because the item could have been found by other codes such as SKU, UPC & serial number.

            // Check if the item exists already
            //
            for (row_num = 0; row_num < moIVTransaction.sDetailData.GetLength(1); row_num++)
            {
                if (moIVTransaction.sDetailData[clsIVTransaction.ITEM_CODE_COL, row_num] == Header.txtPOSItem_cd)
                {
                    break;
                }
                else if (moUtility.IsEmpty(moIVTransaction.sDetailData[clsIVTransaction.ITEM_CODE_COL, row_num]))
                {
                    break;
                }
            }

            // Add more line 2 lines before the end.
            //
            if (row_num >= moIVTransaction.sDetailData.GetLength(1) - 2)
            {
                FormAddMoreRows();
            }

            grid_line = new clsIVTransaction.clsDetail.clsGrid();

            // Since our calculation is based on the grid, we need to find the grid line corresponding to the one we found in Data[]
            //
            if (moIVTransaction.FindGridLine(row_num, ref grid_line) == false)
            {
                FormShowMessage(moIVTransaction.GetErrorMessage());
                return false;
            }

            // If the item does not exist, add it to the next empty line.
            //
            if (moUtility.IsEmpty(grid_line.txtItem_cd))
            {
                grid_line.txtItem_cd = Header.txtPOSItem_cd;

                if (DetailItem_cd_Verified(grid_line) == false)
                {
                    FormShowMessage();
                    grid_line.txtItem_cd = "";
                    return false;
                }
                grid_line.txtQuantity = "1";
            }
            else
            {
                grid_line.txtQuantity = (moUtility.ToValue(grid_line.txtQuantity) + 1).ToString();
            }

            if (DetailQuantity_Verified(grid_line) == false)
            {
                FormShowMessage();
                grid_line.txtQuantity = moIVTransaction.sDetailData[clsIVTransaction.QTY_COL, row_num];
                return false;

            }

            // Generic function calls for all line item change.
            //
            if (FormCalculateCurrentRow(grid_line) == false)
            {
                return false;
            }

            FormRecreateDetailLine(grid_line);

            return true;
        }


        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else.
        //                                   
        //  ===============================================================================================================================================================================================================================
        private bool cmdAddMoreLines_Clicked()
        {
            FormPreEvent();
            
            FormAddMoreRows();

            return FormPostEvent();
        }

        private bool btnDetailDelete_Clicked(clsIVTransaction.clsDetail.clsGrid cur_item)
        {
            FormPreEvent();

            FormDeleteCurrentRow(cur_item);

            return FormPostEvent();
        }

        private bool btnDetailInsert_Clicked(clsIVTransaction.clsDetail.clsGrid cur_item)
        {
            FormPreEvent();

            FormInsertNewRow(cur_item);

            return FormPostEvent();
        }

        private bool btnZoomOnDetailItem_Clicked(clsIVTransaction.clsDetail.clsGrid cur_item)
        {
            FormPreEvent();

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "", clsIVTransaction.ITEM_CODE_COL, cur_item.Row_num, moView.MAIN_PAGE_NUM, "sItem_cd", "") == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool DetailItem_cd_Changed(clsIVTransaction.clsDetail.clsGrid cur_item)
        {
            cur_item.txtItem_cd = modCommonUtility.CleanCode(cur_item.txtItem_cd);

            if (cur_item.txtItem_cd == moIVTransaction.sDetailData[clsIVTransaction.ITEM_CODE_COL, cur_item.Row_num])         
            {
                return true;                            
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            // If something is not right, reinstate the original.  Otherwise, save it.
            //
            if (DetailItem_cd_Verified(cur_item) == false)                                           
            {
                cur_item.txtItem_cd = moIVTransaction.sDetailData[clsIVTransaction.ITEM_CODE_COL, cur_item.Row_num];
                return false;
            }


            // Generic function calls for all line item change.
            //
            if (FormCalculateCurrentRow(cur_item) == false)
            {
                cur_item.txtItem_cd = moIVTransaction.sDetailData[clsIVTransaction.ITEM_CODE_COL, cur_item.Row_num];
                return false;
            }


            FormRecreateDetailLine(cur_item);
            FormCalculateTotal();

            return FormPostEvent();
        }
        private bool DetailUnit_cd_Changed(clsIVTransaction.clsDetail.clsGrid cur_item)
        {
            cur_item.txtUnit_cd = modCommonUtility.CleanCode(cur_item.txtUnit_cd);

            if (cur_item.txtUnit_cd == moIVTransaction.sDetailData[clsIVTransaction.UNIT_CODE_COL, cur_item.Row_num])
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            // If something is not right, reinstate the original.  Otherwise, save it.
            //
            if (DetailUnit_cd_Verified(cur_item) == false)
            {
                cur_item.txtUnit_cd = moIVTransaction.sDetailData[clsIVTransaction.UNIT_CODE_COL, cur_item.Row_num];
                return false;
            }

            // Generic function calls for all line item change.
            //
            if (FormCalculateCurrentRow(cur_item) == false)
            {
                cur_item.txtUnit_cd = moIVTransaction.sDetailData[clsIVTransaction.UNIT_CODE_COL, cur_item.Row_num];
                return false;
            }
            FormRecreateDetailLine(cur_item);
            FormCalculateTotal();

            return FormPostEvent();
        }

        private bool DetailSerial_cd_Changed(clsIVTransaction.clsDetail.clsGrid cur_item)
        {
            cur_item.txtSerial_cd = moUtility.SUCase(moUtility.STrim(moUtility.EvalQuote(cur_item.txtSerial_cd)));  // DO NOT use CleanCode()

            if (cur_item.txtSerial_cd == moIVTransaction.sDetailData[clsIVTransaction.SERIAL_CODE_COL, cur_item.Row_num])
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsNonEmpty(cur_item.txtSerial_cd))
            {
                if (FormOpenDatabase() == false)
                {
                    cur_item.txtSerial_cd = moIVTransaction.sDetailData[clsIVTransaction.SERIAL_CODE_COL, cur_item.Row_num];
                    return FormPostEvent();
                }
                if (DetailSerial_cd_Verified(cur_item) == false)
                {
                    cur_item.txtSerial_cd = moIVTransaction.sDetailData[clsIVTransaction.SERIAL_CODE_COL, cur_item.Row_num];
                    return FormPostEvent();
                }
            }

            moIVTransaction.sDetailData[clsIVTransaction.SERIAL_CODE_COL, cur_item.Row_num] = cur_item.txtSerial_cd;

            return FormPostEvent();
        }

        private bool DetailQuantity_Changed(clsIVTransaction.clsDetail.clsGrid cur_item)
        {
            cur_item.txtQuantity = Math.Abs(moUtility.ToValue(cur_item.txtQuantity)).ToString();

            if (cur_item.txtQuantity == moIVTransaction.sDetailData[clsIVTransaction.QTY_COL, cur_item.Row_num])
            {
                return true;
            }

            FormPreEvent();

            if (DetailQuantity_Verified(cur_item) == false)
            {
                cur_item.txtQuantity = moIVTransaction.sDetailData[clsIVTransaction.QTY_COL, cur_item.Row_num];
                return false;
            }

            // Generic function calls for all line item change.
            //
            if (FormCalculateCurrentRow(cur_item) == false)
            {
                cur_item.txtQuantity = moIVTransaction.sDetailData[clsIVTransaction.QTY_COL, cur_item.Row_num];
                return false;
            }
            FormRecreateDetailLine(cur_item);
            FormCalculateTotal();

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================
        private bool DetailItem_cd_Verified(clsIVTransaction.clsDetail.clsGrid cur_item)
        {
            bool return_value = false;
            decimal sell_unit_price = 0;

            try
            {
                if (moUtility.IsNonEmpty(cur_item.txtItem_cd))      // Check this item already appears.
                {
                    foreach (var det in moIVTransaction.Detail.Grid)
                    {
                        if (det.txtItem_cd == cur_item.txtItem_cd && (moSerial.IsSerialItem(moUtility.ToInteger(det.lblItem_typ)) == false) && (det.Row_num != cur_item.Row_num))
                        {
                            FormShowMessage(cur_item.txtItem_cd + User.Language.oMessage.APPEARS_MORE_THAN_ONCE);
                            return false;
                        }
                    }
                }

                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                if (moIVTransaction.ValidateItemCode(cur_item, Header.cboLocation_cd, ref sell_unit_price) == false)
                {
                    FormShowMessage();
                    return false;
                }

                cur_item.lblSellUnitPrice_amt = "";
                cur_item.txtUnitPrice_amt = "";
                cur_item.lblInIVUnit_qty = moUtility.RoundToQtyFactor(moUtility.ToValue(cur_item.txtQuantity) * moUtility.ToValue(cur_item.lblConversion_rt)).ToString();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (DetailItem_cd_Verified)");
            }

            return return_value;
        }

        private bool DetailSerial_cd_Verified(clsIVTransaction.clsDetail.clsGrid cur_item)
        {
            if (moUtility.IsEmpty(Header.cboLocation_cd))
            {
                FormShowMessage(User.Language.oMessage.PLEASE_ENTER + User.Language.oCaption.LOCATION_CODE);
                cur_item.txtSerial_cd = moIVTransaction.sDetailData[clsIVTransaction.SERIAL_CODE_COL, cur_item.Row_num];
                return false;
            }
            if (moUtility.IsEmpty(cur_item.txtItem_cd))
            {
                FormShowMessage(User.Language.oMessage.PLEASE_ENTER + User.Language.oCaption.ITEM_CODE);
                cur_item.txtSerial_cd = moIVTransaction.sDetailData[clsIVTransaction.SERIAL_CODE_COL, cur_item.Row_num];
                return false;
            }

            foreach (var det in moIVTransaction.Detail.Grid)
            {
                if (moSerial.IsSerialItem(moUtility.ToInteger(det.lblItem_typ)))
                {
                    if (det.txtItem_cd == cur_item.txtItem_cd && det.txtSerial_cd == cur_item.txtSerial_cd && (det.Row_num != cur_item.Row_num))
                    {
                        FormShowMessage(cur_item.txtItem_cd + "/" + cur_item.txtSerial_cd + User.Language.oMessage.APPEARS_MORE_THAN_ONCE);
                        return false;
                    }
                }
            }

            if (moValidate.IsValidSerialCode(cur_item.txtItem_cd, cur_item.txtSerial_cd, Header.cboLocation_cd) == false)
            {
                FormShowMessage(cur_item.txtItem_cd + "/" + cur_item.txtSerial_cd + User.Language.oMessage.IS_INVALID);
                cur_item.txtSerial_cd = moIVTransaction.sDetailData[clsIVTransaction.SERIAL_CODE_COL, cur_item.Row_num];
                return false;
            }
            else if (moValidate.oRecordset.mField("fAvailable_qty") < moDatabase.fSmallestNumber)
            {
                FormShowMessage(cur_item.txtItem_cd + "/" + cur_item.txtSerial_cd + User.Language.oMessage.DOES_NOT_HAVE_ENOUGH_QTY);
                cur_item.txtSerial_cd = moIVTransaction.sDetailData[clsIVTransaction.SERIAL_CODE_COL, cur_item.Row_num];
                return false;
            }

            return true;
        }

        private bool DetailQuantity_Verified(clsIVTransaction.clsDetail.clsGrid cur_item)
        {
            bool return_value = false;
            decimal conversion_rate = 0;

            try
            {
                cur_item.lblInIVUnit_qty = moUtility.RoundToQtyFactor(moUtility.ToValue(cur_item.txtQuantity) * moUtility.ToValue(cur_item.lblConversion_rt)).ToString();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (DetailQuantity_Verified)");
            }

            return return_value;
        }

        private bool DetailUnit_cd_Verified(clsIVTransaction.clsDetail.clsGrid cur_item)
        {
            bool return_value = false;
            decimal conversion_rate = 0;

            try
            {
                if (moUtility.IsEmpty(cur_item.txtUnit_cd) || moUtility.IsEmpty(cur_item.txtItem_cd))
                {
                    return true;
                }
                
                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                else if (moValidate.IsValidUnitCode(cur_item.txtItem_cd, cur_item.lblIVUnit_cd, cur_item.txtUnit_cd, ref conversion_rate) == false)
                {
                    FormShowMessage(User.Language.oMessage.NO_CONVERSION_EXIST + "(" + cur_item.lblIVUnit_cd + ":" + cur_item.txtUnit_cd + ")");
                    return false;
                }

                //  Calculate the qty in inventory unit.
                //
                moGeneral.CalculateQtyInIVUnit(cur_item.txtItem_cd, cur_item.lblIVUnit_cd, moUtility.ToValue(cur_item.txtQuantity), ref cur_item.txtUnit_cd, ref cur_item.lblInIVUnit_qty, ref conversion_rate);

                cur_item.lblConversion_rt = conversion_rate.ToString();

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (DetailUnit_cd_Verified)");
            }

            return return_value;
        }

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

        public bool ResetRestrictionClause()
        {
            moPage.sRestrictionClause = msDefaultRestrictionClause;

            return true;
        }

        private bool SaveSerial()
        {
            bool return_value = false;
            int row_num = 0;
            int total_num = 0;

            try
            {
                // Copy the serial/lot numbers from moIVTransaction.sDetailData[] to moSerial.sLotArray[] that will be saved at saving.
                //
                for (row_num = 0; row_num < moIVTransaction.sDetailData.GetUpperBound(1); row_num++)
                {
                    if (moSerial.IsSerialOrLotItem(moUtility.ToInteger(moIVTransaction.sDetailData[clsIVTransaction.ITEM_TYPE_COL, row_num]))
                        && moUtility.IsNonEmpty(moIVTransaction.sDetailData[clsIVTransaction.SERIAL_CODE_COL, row_num]))
                    {
                        total_num += 1;
                    }
                }

                if (total_num == 0)
                {
                    return true;
                }

                moUtility.ResizeDim(ref moSerial.sLotArray, clsSerial.TOTAL_COL - 1, total_num - 1);

                total_num = 0;
                for (row_num = 0; row_num < moIVTransaction.sDetailData.GetUpperBound(1); row_num++)
                {
                    if (moSerial.IsSerialOrLotItem(moUtility.ToInteger(moIVTransaction.sDetailData[clsIVTransaction.ITEM_TYPE_COL, row_num]))
                        && moUtility.IsNonEmpty(moIVTransaction.sDetailData[clsIVTransaction.SERIAL_CODE_COL, row_num]))
                    {
                        moSerial.sLotArray[clsSerial.ITEM_CODE_COL, total_num] = moIVTransaction.sDetailData[clsIVTransaction.ITEM_CODE_COL, row_num];
                        moSerial.sLotArray[clsSerial.SERIAL_CODE_COL, total_num] = moIVTransaction.sDetailData[clsIVTransaction.SERIAL_CODE_COL, row_num];
                        moSerial.sLotArray[clsSerial.QTY_COL, total_num] = moIVTransaction.sDetailData[clsIVTransaction.QTY_COL, row_num];
                        moSerial.sLotArray[clsSerial.UNIT_CODE_COL, total_num] = moIVTransaction.sDetailData[clsIVTransaction.UNIT_CODE_COL, row_num];
                        //moSerial.sLotArray[clsSerial.UNIT_COST_COL, total_num] = moIVTransaction.sDetailData[clsIVTransaction.UNIT_COST_COL, row_num];
                        moSerial.sLotArray[clsSerial.UNIT_PRICE_COL, total_num] = moIVTransaction.sDetailData[clsIVTransaction.UNIT_PRICE_COL, row_num];
                        moSerial.sLotArray[clsSerial.DETAIL_LINE_ID_COL, total_num] = moIVTransaction.sDetailData[clsIVTransaction.LINE_ID_COL, row_num];
                        moSerial.sLotArray[clsSerial.LOCATION_CODE_COL, total_num] = Header.cboLocation_cd;

                        total_num += 1;
                    }
                }

                moSerial.iTotalRows = total_num;
                moIVTransaction.oSerial = moSerial;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SaveSerial)");
            }

            return return_value;
        }

    }
}
