﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP.Pages.IV
{
    public partial class ItemHistory
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<BinGenerator> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;                                                               
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        public bool InitialRendering { get; set; } = true;

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsMoney moMoney;
        private Models.clsSpreadsheet moSummary;
        private Models.clsSession moSession;

        private const int LOCATION_COL = 0;
        private const int FISCAL_YEAR_COL = 1;
        private const int QUARTER_COL = 2;
        private const int PERIOD_BEGIN_COL = 3;
        private const int PERIOD_END_COL = 4;
        private const int SALES_AMT_COL = 5;
        private const int SALES_RET_AMT_COL = 6;
        private const int CGS_COL = 7;
        private const int PROFITAMT_COL = 8;
        private const int PROFITPERC_COL = 9;
        private const int SALES_QTY_COL = 10;
        private const int SALES_RET_QTY_COL = 11;
        private const int PURCHASE_AMT_COL = 12;
        private const int PURCHASE_QTY_COL = 13;
        private const int PURCHASE_RET_AMT_COL = 14;
        private const int PURCHASE_RET_QTY_COL = 15;
        private const int SPOILAGE_AMT_COL = 16;
        private const int SPOILAGE_QTY_COL = 17;
        private const int ADJUST_AMT_COL = 18;
        private const int ADJUST_QTY_COL = 19;
        private const int TRANSFER_OUT_AMT_COL = 20;
        private const int TRANSFER_OUT_QTY_COL = 21;
        private const int TRANSFER_IN_AMT_COL = 22;
        private const int TRANSFER_IN_QTY_COL = 23;
        private const int ASSEMBLY_OUT_AMT_COL = 24;
        private const int ASSEMBLY_OUT_QTY_COL = 25;
        private const int ASSEMBLY_IN_AMT_COL = 26;
        private const int ASSEMBLY_IN_QTY_COL = 27;
        private const int INVENTORY_AMT_COL = 28;
        private const int INVENTORY_QTY_COL = 29;
        private const int TURNOVER_RATE_COL = 30;
        private const int TOTAL_SUMMARY_COLUMNS = 31;

        private List<Models.clsCombobox> FiscalYearList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> LocationCodeList = new List<Models.clsCombobox>();


        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================

        private class clsHeader                   
        {
            // Listing of UI items on the header
            //
            public string cboFiscalYear = "";
            public string cboLocation_cd = "";
            public string lblItem_cd = "";
            public string lblItem_nm = "";
            public int optPeriod_typ = GlobalVar.goConstant.TRACK_QUARTERLY_TYPE_NUM;

            // Listing of UI items on the header
            //
            public string mskEntry_dt = "";
            public string mskFrom_dt = "";
            public string mskThru_dt = "";

            public DateTime? dtEntry_dt = null;
            public DateTime? dtFrom_dt = null;
            public DateTime? dtThru_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag
            {
                public string cboFiscalYear = "";
                public string cboLocation_cd = "";

                public string mskEntry_dt = "";
                public string mskFrom_dt = "";
                public string mskThru_dt = "";

                public DateTime? dtEntry_dt = null;
                public DateTime? dtFrom_dt = null;
                public DateTime? dtThru_dt = null;
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()                                                                  
            {
                Tag.cboFiscalYear = cboFiscalYear;
                Tag.cboLocation_cd = cboLocation_cd;

                Tag.mskEntry_dt = mskEntry_dt;
                Tag.mskFrom_dt = mskFrom_dt;
                Tag.mskThru_dt = mskThru_dt;

                Tag.dtEntry_dt = dtEntry_dt;
                Tag.dtFrom_dt = dtFrom_dt;
                Tag.dtThru_dt = dtThru_dt;
            }
        }
        private clsHeader Header = new clsHeader();

        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================

        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }

            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;                        
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();                      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            moSession.RemoveSession(moDatabase);        // Delete the session file as rendering completes.

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            // If user uses date-picker, we need to change the date field.
            //
            if (User.bUseDatePicker_fl && moUtility.SLeft(field_name, 3) == "msk" && moUtility.SRight(field_name, 3) == "_dt")
            {
                field_name = moUtility.SReplace(field_name, "msk", "dt");
            }

            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows(int lines_to_add = 0)
        {
           
            return true;
        }

        private bool FormCalculateTotal()
        {

            return true;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {

            return true;
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            return true;
        }

        private bool FormClearDetail()                                                                   // Clear the entire page.
        {

            moUtility.ResizeDim(ref moSummary.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, 0);

            FormRecreateGrid(moSummary);

            return true;
        }

        private bool FormClearHeader()                                                                   // Clear the entire page.
        {
            return true;
        }

        private bool FormClearMessage()                                                            
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            
            return true;
        }

        private bool FormDeleteExtra()
        {

            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moMoney = new clsMoney(ref moDatabase);
            moSummary = new Models.clsSpreadsheet();
            moSession = new Models.clsSession();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.ARMENU_NAME;
            moPage.Title = "";
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormInitHeader();
            FormInitDetail();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitDetail()                                                              // Initialize the page at loading.  Only once.
        {
            // Detail table name.
            //
            moPage.sDetailTable_nm = "";

            moUtility.ResizeDim(ref moSummary.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, 0);

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = ""; 
            moPage.sKeyField_nm = "";
            moPage.iTransaction_typ= 0; 

            return true;
        }

        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {
            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            // FormSave() & FormCheck() use the plain box whose name starts with "msk"
            // dt* variables are only to interact with UI.  Internally, msk* fields are used.
            //
            FormSyncDates(User.bUseDatePicker_fl);

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtEntry_dt, ref Header.mskEntry_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtFrom_dt, ref Header.mskFrom_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtThru_dt, ref Header.mskThru_dt, use_date_picker);

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback
            
            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;
            ArrayList array_list = new ArrayList();

            try
            {
                FormSwitchView(moView.MAIN_PAGE_NUM);

                // Since this page does not go through the menu system, we need to get the login info that is sent from the calling page.
                //
                if (FormReceiveValues() == false)
                {
                    User.bConnected_fl = true;                      // So that the message will show.
                    return false;
                }
                if (FormOpenDatabase() == false)
                {
                    User.bConnected_fl = true;                      // So that the message will show.
                    return false;
                }

                modLoadUtility.LoadFiscalYear(ref moDatabase, ref FiscalYearList, false, false, false);
                modLoadUtility.LoadLocationCode(ref moDatabase, ref LocationCodeList);

                Header.lblItem_cd = moSession.Value.Entity;

                if (moValidate.IsValidItemCode(Header.lblItem_cd))
                {
                    Header.lblItem_nm = moValidate.oRecordset.sField("sItem_nm");
                }
                Header.cboLocation_cd = moGeneral.GetDefaultLocationCode("");
                Header.cboFiscalYear = moDatabase.sCurFiscalYear;

                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
                ShowSummary();
                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

                User.bConnected_fl = true;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormMove(int record_move_direction)
        {
            return true;
        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostSave()
        {
            
            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {

            return true;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormReceiveValues()
        {
            // If connected already, return true.  This means this page came through the menu system.
            //
            if (moUtility.IsNonEmpty(User.sServer_nm) || moDatabase.IsConnected())
            {
                return true;
            }

            // Otherwise, need to login with the info passed from the calling page.
            //
            if (modGeneralUtility.GetPassedParameters(StarterValue, User, moSession) == false)
            {
                FormShowMessage(User.Language.oMessage.PLEASE_LOG_IN_FIRST);
                return false;
            }

            moPage.sInitialKey_id = moSession.Value.Entity;

            return true;
        }

        private bool FormRecreateDetail(Models.clsSpreadsheet cur_spread)     
        {
            if (cur_spread.RecreateDetail() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateDetailLine(Models.clsSpreadsheet.clsGrid cur_item, int row_num = -1)
        {
            if (moSummary.RecreateDetailLine(cur_item, row_num) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateGrid(Models.clsSpreadsheet cur_spread)                                                  
        {
            if (cur_spread.RecreateGrid() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {

            FormReArrangeHeader();

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);

            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moZoom.Caller == "txtVendor_cd")
            {
                if (moZoom.Vendor(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            else if (moZoom.Caller == "txtItem_cd" || moZoom.Caller == "txtItemThru_cd")
            {
                if (moZoom.Inventory(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
                {
                    return false;
                }
            }

            FormCancel();
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        
        private bool cmdViewMain_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.MAIN_PAGE_NUM);
            return FormPostEvent();
        }

        private bool cmdViewSalesDetail_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.DETAIL_PAGE_NUM);
            return FormPostEvent();
        }

        private bool cmdViewReceiptDetail_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.SECOND_PAGE_NUM);
            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnListingSelect_Clicked(Models.clsListing.clsGrid cur_item)
        {
            FormPreEvent();


            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
               
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }
        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        private bool cmdRefresh_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.cboFiscalYear))
            {
                FormShowMessage(User.Language.oMessage.ENTER_FISCAL_YEAR_FIRST);
                FormSetFocus("cboFiscalYear");
                return false;
            }

            if (moUtility.IsEmpty(Header.cboLocation_cd))
            {
                FormShowMessage(User.Language.oMessage.ENTER_LOCATION_CODE_FIRST);
                FormSetFocus("cboLocation_cd");
                return false;
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            ShowSummary();
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            return FormPostEvent();
        }

        private bool dtFrom_dt_Changed()
        {
            if (Header.dtFrom_dt == Header.Tag.dtFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtFrom_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtFrom_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtFrom_dt) == false)
            {
                Header.dtFrom_dt = Header.Tag.dtFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtFrom_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskFrom_dt_Changed()
        {
            if (Header.mskFrom_dt == Header.Tag.mskFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskFrom_dt) == false)
            {
                Header.mskFrom_dt = Header.Tag.mskFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskFrom_dt");
                return false;
            }

            return FormPostEvent();
        }


        private bool dtThru_dt_Changed()
        {
            if (Header.dtThru_dt == Header.Tag.dtThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtThru_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtThru_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtThru_dt) == false)
            {
                Header.dtThru_dt = Header.Tag.dtThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskThru_dt_Changed()
        {
            if (Header.mskThru_dt == Header.Tag.mskThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskThru_dt) == false)
            {
                Header.mskThru_dt = Header.Tag.mskThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        
        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

        private bool ShowSummary()
        {
            bool return_value = false;

            try
            {
                clsRecordset cur_set = null;
                string sql_str = "";
                int row_num = 0;
                string tmp = "";
                int max_row = 0;
                decimal profit = 0;
                decimal avg_iv = 0;
                decimal profit_perc = 0;
                decimal total_trx = 0;

                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                
                FormClearDetail();

                cur_set = new clsRecordset(ref moDatabase);

                if (Header.optPeriod_typ == GlobalVar.goConstant.TRACK_WEEKLY_TYPE_NUM)
                {
                    sql_str = "SELECT * FROM tblIVBalanceWeekly WHERE sItem_cd = '" + moUtility.EvalQuote(Header.lblItem_cd) + "'";
                }
                else
                {
                    sql_str = "SELECT * FROM tblIVBalance WHERE sItem_cd = '" + moUtility.EvalQuote(Header.lblItem_cd) + "'";
                }

                if (moUtility.IsEmpty(Header.cboLocation_cd))
                {
                    sql_str += " AND sLocation_cd = '" + GlobalVar.goConstant.FOR_ALL + "'";
                }
                else
                {
                    sql_str += " AND sLocation_cd = '" + Header.cboLocation_cd + "'";
                }

                if (moUtility.IsNonEmpty(Header.cboFiscalYear))
                {
                    sql_str += " AND sFiscalYear = '" + Header.cboFiscalYear + "'";
                }

                if (Header.optPeriod_typ == GlobalVar.goConstant.TRACK_YEARLY_TYPE_NUM)
                {
                    sql_str += " AND iQuarter = 0";
                    sql_str += " ORDER BY sFiscalYear, iQuarter, iPeriodBegin_dt";
                }
                else if (Header.optPeriod_typ == GlobalVar.goConstant.TRACK_QUARTERLY_TYPE_NUM)
                {
                    sql_str += " AND (iQuarter = 0 OR iPeriodBegin_dt = 0)";
                    sql_str += " ORDER BY sFiscalYear, iQuarter, iPeriodBegin_dt";
                }
                else if (Header.optPeriod_typ == GlobalVar.goConstant.TRACK_WEEKLY_TYPE_NUM)
                {
                    sql_str += " ORDER BY sFiscalYear, iWeek, iPeriodBegin_dt";
                }
                else
                {
                    sql_str += " ORDER BY sFiscalYear, iQuarter, iPeriodBegin_dt";
                }

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    FormShowMessage();
                    return false;
                }
                else if (cur_set.EOF())
                {
                    FormShowMessage(User.Language.oMessage.NO_RECORDS_FOUND);
                    return true;
                }

                row_num = 0;
                moUtility.ResizeDim(ref moSummary.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, cur_set.RecordCount() - 1);

                while (cur_set.EOF() == false)
                {
                    tmp = cur_set.sField("sLocation_cd");
                    if (tmp == GlobalVar.goConstant.FOR_ALL)
                    {
                        tmp = User.Language.oString.STR_ALL;
                    }
                    moSummary.Data[LOCATION_COL, row_num] = tmp;
                    moSummary.Data[FISCAL_YEAR_COL, row_num] = cur_set.sField("sFiscalYear");

                    // See if this is the yearly total.
                    //
                    if (Header.optPeriod_typ == GlobalVar.goConstant.TRACK_WEEKLY_TYPE_NUM)
                    {
                        tmp = moGeneral.ToStrDate(cur_set.iField("iPeriodBegin_dt"));
                        moSummary.Data[PERIOD_BEGIN_COL, row_num] = tmp;
                        tmp = moGeneral.ToStrDate(cur_set.iField("iPeriodEnd_dt"));
                        moSummary.Data[PERIOD_END_COL, row_num] = tmp;
                    }
                    else if (cur_set.iField("iQuarter") == 0)
                    {
                        moSummary.Data[PERIOD_BEGIN_COL, row_num] = User.Language.oString.STR_YEARLY;
                        moSummary.Data[PERIOD_END_COL, row_num] = User.Language.oString.STR_TOTAL;
                    }
                    else
                    {
                        moSummary.Data[QUARTER_COL, row_num] = moUtility.ToStr(cur_set.iField("iQuarter"));

                        // See if this the quarterly total.
                        //
                        if (cur_set.iField("iPeriodBegin_dt") == 0)
                        {
                            moSummary.Data[PERIOD_BEGIN_COL, row_num] = User.Language.oString.STR_QUARTERLY;
                            moSummary.Data[PERIOD_END_COL, row_num] = User.Language.oString.STR_TOTAL;
                        }
                        else
                        {
                            tmp = moGeneral.ToStrDate(cur_set.iField("iPeriodBegin_dt"));
                            moSummary.Data[PERIOD_BEGIN_COL, row_num] = tmp;
                            tmp = moGeneral.ToStrDate(cur_set.iField("iPeriodEnd_dt"));
                            moSummary.Data[PERIOD_END_COL, row_num] = tmp;
                        }
                    }

                    tmp = moMoney.ToStrMoney(cur_set.mField("mSales_amt"), 0);
                    moSummary.Data[SALES_AMT_COL, row_num] = tmp;
                    tmp = moMoney.ToStrMoney(cur_set.mField("mSalesReturn_amt"), 0);
                    moSummary.Data[SALES_RET_AMT_COL, row_num] = tmp;
                    tmp = moMoney.ToStrMoney(cur_set.mField("mCGS_amt"), 0);
                    moSummary.Data[CGS_COL, row_num] = tmp;

                    // Calculate the profit and profit percent.
                    // profit = sales - return - cgs
                    // profit percent = (profit / ( sales - return )) * 100
                    //
                    profit = cur_set.mField("mSales_amt") - cur_set.mField("mSalesReturn_amt") - cur_set.mField("mCGS_amt");
                    moSummary.Data[PROFITAMT_COL, row_num] = moMoney.ToStrMoney(profit, 0);
                    if (profit >= moDatabase.fSmallestNumber && System.Math.Abs(cur_set.mField("mSales_amt") - cur_set.mField("mSalesReturn_amt")) >= moDatabase.fSmallestNumber)
                    {
                        profit_perc = Convert.ToDecimal(System.Math.Round((profit / (cur_set.mField("mSales_amt") - cur_set.mField("mSalesReturn_amt"))) * 100, 2));
                    }
                    else
                    {
                        profit_perc = 0M;
                    }
                    moSummary.Data[PROFITPERC_COL, row_num] = moUtility.ToStr(profit_perc);

                    tmp = cur_set.mField("fSales_qty").ToString();
                    moSummary.Data[SALES_QTY_COL, row_num] = tmp;
                    tmp = cur_set.mField("fSalesReturn_qty").ToString();
                    moSummary.Data[SALES_RET_QTY_COL, row_num] = tmp;
                    tmp = moMoney.ToStrMoney(cur_set.mField("mPurchase_amt"), 0);
                    moSummary.Data[PURCHASE_AMT_COL, row_num] = tmp;
                    tmp = cur_set.mField("fPurchase_qty").ToString();
                    moSummary.Data[PURCHASE_QTY_COL, row_num] = tmp;
                    tmp = moMoney.ToStrMoney(cur_set.mField("mPurchaseReturn_amt"), 0);
                    moSummary.Data[PURCHASE_RET_AMT_COL, row_num] = tmp;
                    tmp = cur_set.mField("fPurchaseReturn_qty").ToString();
                    moSummary.Data[PURCHASE_RET_QTY_COL, row_num] = tmp;
                    tmp = moMoney.ToStrMoney(cur_set.mField("mSpoilage_amt"), 0);
                    moSummary.Data[SPOILAGE_AMT_COL, row_num] = tmp;
                    tmp = cur_set.mField("fSpoilage_qty").ToString();
                    moSummary.Data[SPOILAGE_QTY_COL, row_num] = tmp;
                    tmp = moMoney.ToStrMoney(cur_set.mField("mAdjust_amt"), 0);
                    moSummary.Data[ADJUST_AMT_COL, row_num] = tmp;
                    tmp = cur_set.mField("fAdjust_qty").ToString();
                    moSummary.Data[ADJUST_QTY_COL, row_num] = tmp;

                    tmp = moMoney.ToStrMoney(cur_set.mField("mTransferOut_amt"), 0);
                    moSummary.Data[TRANSFER_OUT_AMT_COL, row_num] = tmp;
                    tmp = cur_set.mField("fTransferOut_qty").ToString();
                    moSummary.Data[TRANSFER_OUT_QTY_COL, row_num] = tmp;

                    tmp = moMoney.ToStrMoney(cur_set.mField("mTransferIn_amt"), 0);
                    moSummary.Data[TRANSFER_IN_AMT_COL, row_num] = tmp;
                    tmp = cur_set.mField("fTransferIn_qty").ToString();
                    moSummary.Data[TRANSFER_IN_QTY_COL, row_num] = tmp;

                    tmp = moMoney.ToStrMoney(cur_set.mField("mAssemblyOut_amt"), 0);
                    moSummary.Data[ASSEMBLY_OUT_AMT_COL, row_num] = tmp;
                    tmp = cur_set.mField("fAssemblyOut_qty").ToString();
                    moSummary.Data[ASSEMBLY_OUT_QTY_COL, row_num] = tmp;

                    tmp = moMoney.ToStrMoney(cur_set.mField("mAssemblyIn_amt"), 0);
                    moSummary.Data[ASSEMBLY_IN_AMT_COL, row_num] = tmp;
                    tmp = cur_set.mField("fAssemblyIn_qty").ToString();
                    moSummary.Data[ASSEMBLY_IN_QTY_COL, row_num] = tmp;

                    tmp = moMoney.ToStrMoney(cur_set.mField("mInventory_amt"), 0);
                    moSummary.Data[INVENTORY_AMT_COL, row_num] = tmp;
                    tmp = cur_set.mField("fInventory_qty").ToString();
                    moSummary.Data[INVENTORY_QTY_COL, row_num] = tmp;

                    // Do not use Sales/Return amounts in order to calculate the inventory level.
                    // mCGS_amt should always keep the net sales cost.
                    //
                    total_trx = cur_set.mField("fPurchase_qty");
                    total_trx -= cur_set.mField("fPurchaseReturn_qty");
                    total_trx -= cur_set.mField("fSales_qty");
                    total_trx += cur_set.mField("fSalesReturn_qty");
                    total_trx += cur_set.mField("fTransferIn_qty");
                    total_trx -= cur_set.mField("fTransferOut_qty");
                    total_trx += cur_set.mField("fAssemblyIn_qty");
                    total_trx -= cur_set.mField("fAssemblyOut_qty");
                    total_trx -= cur_set.mField("fAdjust_qty");
                    total_trx -= cur_set.mField("fSpoilage_qty");

                    avg_iv = cur_set.mField("fInventory_qty") - (total_trx / 2);

                    if (System.Math.Abs(avg_iv) > moDatabase.fSmallestNumber)
                    {
                        tmp = moUtility.SFormat((cur_set.mField("fSales_qty") - cur_set.mField("fSalesReturn_qty")) / avg_iv * 100, "0.00");
                    }
                    else
                    {
                        tmp = "N/A";
                    }
                    moSummary.Data[TURNOVER_RATE_COL, row_num] = tmp;
                    cur_set.MoveNext();
                    row_num += 1;
                }

                FormRecreateGrid(moSummary);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (ShowSummary)");
            }

            return true;
        }

    }
}
