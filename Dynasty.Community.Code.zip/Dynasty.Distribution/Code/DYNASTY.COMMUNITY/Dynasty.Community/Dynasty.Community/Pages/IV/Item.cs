﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

using Dynasty.Database;
using Dynasty.ASP.Models;

using BlazorInputFile;

namespace Dynasty.ASP.Pages.IV
{
    public partial class Item
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<Item> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;                                                               
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;
        private Models.clsSpreadsheet moQuantity;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        private bool DisableSubItems
        {
            get
            {
                return (moUtility.IsNonEmpty(Header.txtKey_id) && moDatabase.uSecurity.bPrimaryRulesSubItems_fl && Header.txtKey_id != Header.txtPrimary_cd);
            }
        }

        private bool HideFootButtons
        {
            get
            {
                return (moPage.iCurrentView == moView.SEARCH_PAGE_NUM || moPage.iCurrentView == moView.MATRIX_PAGE_NUM || moPage.iCurrentView == moView.ZOOM_PAGE_NUM);
            }
        }

        private bool MatrixItem
        {
            get
            {
                return (moUtility.IsNonEmpty(Header.txtKey_id) && Header.cboItem_typ > GlobalVar.goIVConstant.SUMMARY_SALES_ITEM_TYPES);
            }
        }

        private bool ShowSearchPrinter
        {
            get
            {
                return (mbSearchInitiated_fl && mbSearchPopulated_fl);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsMoney moMoney;
        private clsIntegrity moIntegrity;
        private clsItem moItem;
        private Models.clsCustomField moCustomFields;
        private Models.clsSession moSession;
        private Models.clsSpreadsheet moMatrix;
        private clsInquiry moInquiry;
        private clsCustomization moCustomization;

        private List<Models.clsCombobox> IVGroupCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> SaleCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> EventCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> UnitCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> IVClassCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> TaxCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ItemTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CommissionCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> BoxCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> SetCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> SimilarityCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> WarrantyCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ColorCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> SizeCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> StyleCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ModelCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> BrandCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ManufacturerCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> StatusTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CodeSeparatorList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> OrderByList = new List<Models.clsCombobox>();

        private string msCodeSeparator = "";

        private bool mbPrimaryEntered_fl = false;
        private bool mbShowQuantity_fl = false;
        private string msOriginalIVUnit_cd = "";
        private string msItemImageFile_nm = "";
        private string lblFileToUpload = "";

        private const int MATRIX_SELECT_COL = 0;
        private const int MATRIX_ITEM_COL = 1;
        private const int MATRIX_LABEL_COL = 2;
        private const int MATRIX_DESC_COL = 3;
        private const int MATRIX_UNIT_PRICE_COL = 4;
        private const int MATRIX_SIZE_COL = 5;
        private const int MATRIX_COLOR_COL = 6;
        private const int MATRIX_STYLE_COL = 7;
        private const int MATRIX_MODEL_COL = 8;
        private const int MATRIX_BRAND_COL = 9;
        private const int MATRIX_MANUFACTURER_COL = 10;

        IFileListEntry FileToUpload;

        private int miUDF_num = 0;

        private bool chkAll_fl = false;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader                   
        {
            // Listing of UI items on the header
            //
            public string txtKey_id = "";
            public string txtDescription = "";

            public string txtDisplay_qty = "";
            public string txtMessageForPrice = "";
            public string txtWebClass_cd = "";
            public string txtPrimary_cd = "";
            public string txtFreight_amt = "";
            public string txtSortKey1 = "";
            public string txtSortKey2 = "";
            public string txtSmallPictureFile_nm = "";
            public string txtLength = "";
            public string txtWidth = "";
            public string txtHeight = "";
            public string txtWeight = "";
            public string txtLabel = "";
            public string txtVendor_cd = "";
            public string txtManufacturerItem_cd = "";
            public string txtUPC_cd = "";
            public string txtSKU_cd = "";
            public string txtLeadTime = "";
            public string txtSalePrice_amt = "";
            public string txtSellUnitPrice_amt = "";
            public string txtAltItem_cd = "";
            public string txtStdCost_amt = "";
            public string txtFullPictureFile_nm = "";
            public string txtFullDescription = "";
            public string txtLongDescription = "";
            public string txtComment = "";

            public int cboItem_typ = 0;
            public string cboGroup_cd = "";
            public string cboSale_cd = "";
            public string cboEvent_cd = "";
            public string cboSellUnit_cd = "";
            public string cboPurchaseUnit_cd = "";
            public string cboIVUnit_cd = "";
            public string cboClass_cd = "";
            public string cboTax_cd = "";
            public string cboCommission_cd = "";
            public string cboBox_cd = "";
            public string cboStyle_cd = "";
            public string cboSet_cd = "";
            public string cboSimilarity_cd = "";
            public string cboColor_cd = "";
            public string cboSize_cd = "";
            public string cboModel_cd = "";
            public string cboBrand_cd = "";
            public string cboManufacturer_cd = "";
            public string cboWarranty_cd = "";

            public bool chkNewItem_fl = false;
            public bool chkWebEnabled_fl = false;
            public bool chkDontShowPrice_fl = false;
            public bool chkConsignment_typ = false;
            public bool chkTaxable_fl = false;
            public bool chkPerishable_fl = false;
            public bool chkInternalUseOnly_fl = false;
            public bool chkKit_fl = false;

            public int optAssembly_typ = 0;
            public int cboStatus_typ = 0;

            public string lblLastSalesRet_dt = "";
            public string lblLastSales_dt = "";
            public string lblLastPurchaseRet_dt = "";
            public string lblLastPurchase_dt = "";
            public string lblLastPhysical_dt = "";
            public string lblLastCost_amt = "";
            public string lblLastVendor_cd = "";
            public string lblAvgCost_amt = "";

            public string labMatrixPrimary_cd = "";
            public string labMatrixPrimaryText = "";

            public bool chkShowPicture_fl = false;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag                                                                     
            {
                public string txtKey_id = "";
                public string txtPrimary_cd = "";
                public string txtAltItem_cd = "";
                public string txtVendor_cd = "";
                public string cboTax_cd = "";
                public string cboIVUnit_cd = "";
                public string txtWebClass_cd = "";
                public string txtSmallPictureFile_nm = "";
                public string txtFullPictureFile_nm = "";
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()                                                                  
            {
                Tag.txtKey_id = txtKey_id;
                Tag.txtKey_id = txtKey_id;
                Tag.txtPrimary_cd = txtPrimary_cd;
                Tag.txtAltItem_cd = txtAltItem_cd;
                Tag.txtVendor_cd = txtVendor_cd;
                Tag.cboTax_cd = cboTax_cd;
                Tag.cboIVUnit_cd = cboIVUnit_cd;
                Tag.txtWebClass_cd = txtWebClass_cd;
                Tag.txtSmallPictureFile_nm = txtSmallPictureFile_nm;
                Tag.txtFullPictureFile_nm = txtFullPictureFile_nm;
            }
        }
        private clsHeader Header = new clsHeader();

        private class clsMatrixHeader
        {
            public string cboCodeSeparator = "";

            public bool chkCopyCode_fl = false;
            public bool chkCopyLabel_fl = false;
            public bool chkCopyDescription_fl = false;
            public bool chkCopyUnitPrice_fl = false;

            public bool chkUseSize_fl = false;
            public bool chkUseColor_fl = false;
            public bool chkUseStyle_fl = false;
            public bool chkUseModel_fl = false;
            public bool chkUseBrand_fl = false;
            public bool chkUseManufacturer_fl = false;
        }
        private clsMatrixHeader MatrixHeader = new clsMatrixHeader();

        // Search options
        //
        private string cboSearchOrderBy = "";
        private bool mbSearchInitiated_fl = false;
        private bool mbSearchPopulated_fl = false;
        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;                        
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            moSession.RemoveSession(moDatabase);        // Delete the session file.

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            // If user uses date-picker, we need to change the date field.
            //
            if (User.bUseDatePicker_fl && moUtility.SLeft(field_name, 3) == "msk" && moUtility.SRight(field_name, 3) == "_dt")
            {
                field_name = moUtility.SReplace(field_name, "msk", "dt");
            }
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows()
        {
            
            return true;
        }

        private bool FormCalculateTotal()
        {

            return true;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            if (FormCheckSecurity() == false)
            {
                return false;
            }
            else if (FormCheckHeader() == false)
            {
                return false;
            }
            else if (FormCheckExtra() == false)
            {
                return false;
            }

            return true;
        }

        private bool FormCheckExtra()                                                              // validate extra other than the header and detail.
        {
            bool return_value = false;

            try
            {

                // Custom fields
                //
                if (moCustomFields.CheckValues(moDatabase) == false)
                {
                    FormShowMessage(moCustomFields.GetErrorMessage());
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckExtra)");
            }

            return return_value;
        }

        private bool FormCheckHeader()                                                             // validate the header data.
        {
            bool return_value = false;
            decimal conversion_rate = 0;
            decimal save_rate = 0;
            string sql_str = "";

            clsRecordset cur_set = new clsRecordset(ref moDatabase);
            clsSerial o_serial = new clsSerial(ref moDatabase);

            try
            {

                modCommonUtility.CleanCode(ref Header.txtUPC_cd);
                modCommonUtility.CleanCode(ref Header.txtSKU_cd);

                Header.txtDescription = moUtility.EvalQuote(moUtility.STrim(Header.txtDescription));

                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormShowMessage(User.Language.oCaption.CODE + @User.Language.oMessage.IS_REQUIRED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("txtKey_id");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.txtLabel))
                {
                    FormShowMessage(User.Language.oCaption.LABEL + User.Language.oMessage.IS_REQUIRED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("txtLabel");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.txtDescription))
                {
                    FormShowMessage(User.Language.oCaption.DESCRIPTION + User.Language.oMessage.IS_REQUIRED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("txtDescription");
                    return false;
                }

                
                if (Header.cboItem_typ == 0)
                {
                    FormShowMessage(User.Language.oMessage.ITEM_TYPE_HAS_TO_BE_SELECTED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboItem_typ");
                    return false;

                    // Description item does not require any data.
                    //
                }
                if (Header.cboItem_typ == GlobalVar.goIVConstant.DESCRIPTION_ITEM_NUM)
                {
                    return true;
                }
                if (Header.cboStatus_typ == 0)
                {
                    FormShowMessage(User.Language.oMessage.STATUS_HAS_TO_BE_SELECTED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboStatus_typ");
                    return false;
                }
                if (moUtility.IsEmpty(Header.cboClass_cd))
                {
                    FormShowMessage(User.Language.oMessage.ITEM_CLASS_HAS_TO_BE_SELECTED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboClass_cd");
                    return false;
                }
                if (Header.chkKit_fl && Header.optAssembly_typ == 0)
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_SELECT_THE_KIT_ASSEMBLY_TYPE);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("chkKit_fl");
                    return false;
                }

                // 05/05/2024  Both , consignee and consignor, can use this.  Consignors have customer code, instead.  We just leave this optional for now. 
                //if (Header.chkConsignment_typ && moUtility.IsEmpty(Header.txtVendor_cd)) 
                //{
                //    FormShowMessage(User.Language.oMessage.CONSIGNMENT_ITEMS_REQUIRE_VENDOR_CODE);
                //    FormSwitchView(moView.MAIN_PAGE_NUM);
                //    FormSetFocus("txtVendor_cd");
                //    return false;
                //}

                if (moUtility.IsInventoryItemType(Header.cboItem_typ) || (Header.cboItem_typ) >= GlobalVar.goIVConstant.SUMMARY_SALES_ITEM_TYPES)
                {

                    if (moUtility.IsEmpty(Header.cboIVUnit_cd))
                    {
                        FormShowMessage(User.Language.oMessage.PLEASE_SELECT_THE_INVENTORY_UNIT_CODE);
                        FormSwitchView(moView.MAIN_PAGE_NUM);
                        FormSetFocus("cboIVUnit_cd");
                        return false;
                    }
                    else if (moUtility.IsEmpty(Header.cboPurchaseUnit_cd))
                    {
                        FormShowMessage(User.Language.oMessage.PLEASE_SELECT_THE_PURCHASE_UNIT_CODE);
                        FormSwitchView(moView.MAIN_PAGE_NUM);
                        FormSetFocus("cboPurchaseUnit_cd");
                        return false;
                    }
                    else if (moUtility.IsEmpty(Header.cboSellUnit_cd))
                    {
                        FormShowMessage(User.Language.oMessage.PLEASE_SELECT_THE_SELLING_UNIT_CODE);
                        FormSwitchView(moView.MAIN_PAGE_NUM);
                        FormSetFocus("cboSellUnit_cd");
                        return false;
                    }

                    if (moValidate.IsValidUnitCode(Header.txtKey_id, Header.cboIVUnit_cd, Header.cboPurchaseUnit_cd, ref conversion_rate) == false)
                    {
                        FormShowMessage(User.Language.oMessage.NO_CONVERSION_EXIST + "(" + Header.cboIVUnit_cd + ":" + Header.cboPurchaseUnit_cd + ")");
                        FormSwitchView(moView.MAIN_PAGE_NUM);
                        FormSetFocus("cboPurchaseUnit_cd");
                        return false;
                    }
                    else if (moValidate.IsValidUnitCode(Header.txtKey_id, Header.cboIVUnit_cd, Header.cboSellUnit_cd, ref save_rate) == false) // do not change save_rate. Need to use it below
                    {
                        FormShowMessage(User.Language.oMessage.NO_CONVERSION_EXIST + "(" + Header.cboIVUnit_cd + ":" + Header.cboSellUnit_cd + ")");
                        FormSwitchView(moView.MAIN_PAGE_NUM);
                        FormSetFocus("cboSellUnit_cd");
                        return false;
                    }

                    // If the inventory unit code has changed, make sure it is ok.
                    // 
                    if (moUtility.IsNonEmpty(msOriginalIVUnit_cd) && msOriginalIVUnit_cd != Header.cboIVUnit_cd)
                    {
                        // 12/15/2020  They should be able to change unit code at initial stage.
                        //if (moValidate.IsValidUnitCode(Header.txtKey_id, msOriginalIVUnit_cd, Header.cboSellUnit_cd, ref conversion_rate) == false)
                        //{
                        //    FormShowMessage(User.Language.oMessage.NO_CONVERSION_EXIST + "(" + msOriginalIVUnit_cd + ":" + Header.cboSellUnit_cd + ")"); // not expected
                        //    FormSetFocus("cboSellUnit_cd");
                        //    return false;
                        //}

                        // If original conversion rate is different, need to make sure the inventory is empty.
                        //
                        //if (save_rate != conversion_rate)
                        //{
                            sql_str = "SELECT sItem_cd FROM tblIVItemQty WHERE sItem_cd IN (SELECT sItem_cd FROM tblIVItem WHERE (sItem_cd = '" + Header.txtKey_id + "' OR sPrimary_cd = '" + Header.txtKey_id + "') AND (fOnHand_qty <> 0 or fOnOrder_qty <> 0))";

                            if (cur_set.CreateSnapshot(sql_str) == false)
                            {
                                FormShowMessage();
                                FormSwitchView(moView.MAIN_PAGE_NUM);
                                FormSetFocus("cboIVUnit_cd");
                                return false;
                            }
                            else if (cur_set.RecordCount() > 0)
                            {
                                FormShowMessage(User.Language.oMessage.WHEN_INVENTORY_EXISTS_IVUNIT_CODE_CANNOT_CHANGE);
                                Header.cboIVUnit_cd = msOriginalIVUnit_cd;
                                FormSwitchView(moView.MAIN_PAGE_NUM);
                                FormSetFocus("cboIVUnit_cd");
                                return false;
                            }

                            cur_set.Release();
                        //}
                    }

                    if (o_serial.IsSerialOrLotItem(Header.cboItem_typ) && (Header.cboIVUnit_cd != Header.cboPurchaseUnit_cd || Header.cboIVUnit_cd != Header.cboSellUnit_cd))
                    {
                        FormShowMessage(User.Language.oMessage.SERIAL_LOT_ITEMS_SHOULD_USE_SAME_UNIT);
                        FormSwitchView(moView.MAIN_PAGE_NUM);
                        FormSetFocus("cboIVUnit_cd");
                        return false;
                    }

                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckHeader)");
            }

            return return_value;
        }

        private bool FormCheckConcurrency(clsRecordset cur_set)                                    // Check if someone has changed this record while it is open in this session.
        {
            if (cur_set.IsNonEmpty()) 
            {
                if (moPage.bNew_fl)
                {
                    // If someone has created a record with the same key
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.DUPLICATE_IS_FOUND + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                    moPage.bNew_fl = false;
                }
                else if (moPage.CheckForConcurrency(cur_set) == false)
                {
                    // If someone has updated this record in the meantime.
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        private bool FormCheckToDelete()
        {
            clsIntegrity o_integrity = new clsIntegrity(ref moDatabase);

            if (FormCheckSecurity() == false)
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }
            else if (modFormUtility.IsReservedRecord(ref moDatabase, Header.txtKey_id, moPage.bReserved_fl))
            {
                FormShowMessage(User.Language.oMessage.RESERVED_RECORD_IS_NOT_ALLOWED_TO_DELETE);
                return false;
            }
            else if (o_integrity.IsReferenced(moPage.sModule_id, moPage.sKeyField_nm, Header.txtKey_id))
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }

            return true;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearDetail();
            FormClearExtra();

            return true;
        }

        private bool FormClearDetail()                                                                   // Clear the entire page.
        {

            moUtility.ResizeDim(ref moMatrix.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, 0);

            FormRecreateGrid(moMatrix);

            return true;
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            msOriginalIVUnit_cd = "";
            FileToUpload = null;
            msItemImageFile_nm = "";
            lblFileToUpload = "";
            mbPrimaryEntered_fl = false;
            mbShowQuantity_fl = false;

            moQuantity.Clear();

            // Custom Fields
            //
            moCustomFields.ClearGrid();

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {
            Header.txtKey_id = "";
            Header.txtDescription = "";

            Header.txtDisplay_qty = "";
            Header.txtMessageForPrice = "";
            Header.txtWebClass_cd = "";
            Header.txtPrimary_cd = "";
            Header.txtFreight_amt = "";
            Header.txtSortKey1 = "";
            Header.txtSortKey2 = "";
            Header.txtSmallPictureFile_nm = "";
            Header.txtLength = "";
            Header.txtWidth = "";
            Header.txtHeight = "";
            Header.txtWeight = "";
            Header.txtLabel = "";
            Header.txtVendor_cd = "";
            Header.txtManufacturerItem_cd = "";
            Header.txtUPC_cd = "";
            Header.txtSKU_cd = "";
            Header.txtLeadTime = "";
            Header.txtSalePrice_amt = "";
            Header.txtSellUnitPrice_amt = "";
            Header.txtAltItem_cd = "";
            Header.txtStdCost_amt = "";
            Header.txtFullPictureFile_nm = "";
            Header.txtFullDescription = "";
            Header.txtLongDescription = "";
            Header.txtComment = "";

            Header.cboGroup_cd = "";
            Header.cboSale_cd = "";
            Header.cboEvent_cd = "";
            Header.cboSellUnit_cd = "";
            Header.cboPurchaseUnit_cd = "";
            Header.cboIVUnit_cd = "";
            Header.cboClass_cd = "";
            Header.cboTax_cd = "";
            Header.cboItem_typ = 0;
            Header.cboCommission_cd = "";
            Header.cboBox_cd = "";
            Header.cboStyle_cd = "";
            Header.cboSet_cd = "";
            Header.cboSimilarity_cd = "";
            Header.cboColor_cd = "";
            Header.cboSize_cd = "";
            Header.cboModel_cd = "";
            Header.cboBrand_cd = "";
            Header.cboManufacturer_cd = "";
            Header.cboWarranty_cd = "";

            Header.chkNewItem_fl = false;
            Header.chkWebEnabled_fl = false;
            Header.chkDontShowPrice_fl = false;
            Header.chkConsignment_typ = false;
            Header.chkTaxable_fl = false;
            Header.chkPerishable_fl = false;
            Header.chkInternalUseOnly_fl = false;
            Header.chkKit_fl = false;

            Header.optAssembly_typ = 0;
            Header.cboStatus_typ = 0;

            Header.lblLastSalesRet_dt = "";
            Header.lblLastSales_dt = "";
            Header.lblLastPurchaseRet_dt = "";
            Header.lblLastPurchase_dt = "";
            Header.lblLastPhysical_dt = "";
            Header.lblLastCost_amt = "";
            Header.lblLastVendor_cd = "";
            Header.lblAvgCost_amt = "";

            Header.labMatrixPrimary_cd = "";
            Header.labMatrixPrimaryText = "";

            return true;
        }

        private bool FormClearMessage()                                                            
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id) || moPage.bNew_fl)
                {
                    FormClear();
                    return true;
                }
                else if (FormCheckToDelete() == false)
                {
                    return false;
                }

                // Transaction begins here.
                //
                if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }

                if (modFormUtility.RecordDelete(ref moDatabase, moPage.iScreen_typ, Header.txtKey_id, moPage.sKeyField_nm, moPage.sTable_nm, moPage.sDetailTable_nm, moPage.sRestrictionClause, moPage.iTransaction_typ) == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }
                else if (FormDeleteExtra() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }

                // Transaction ends here.
                //
                if (moDatabase.TransactionCommit() == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDelete)");
                moDatabase.TransactionRollback();
                return_value = false;
            }

            return return_value;
        }

        private bool FormDeleteExtra()
        {
            if (moIntegrity.DeleteDependantsOfItem(Header.txtKey_id, false) == false)
            {
                return false;
            }

            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormFindRecord(ref clsRecordset cur_set, int matching_type = 0)
        {
            bool return_value = false;

            matching_type = (int)(moUtility.IIf(matching_type > 0, matching_type, GlobalVar.goConstant.MATCHING_RECORD_TYPE));
            return_value = modFormUtility.RecordRead(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sTable_nm, moPage.sKeyField_nm, moPage.sPreviousKey_id, moPage.sRestrictionClause, ref matching_type);

            return return_value;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();
            moSearch = new Models.clsEntitySearch();
            moQuantity = new Models.clsSpreadsheet();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moCustomFields = new Models.clsCustomField();
            moSession = new Models.clsSession();
            moMatrix = new Models.clsSpreadsheet();
            moInquiry = new clsInquiry();
            moCustomization = new clsCustomization(ref moDatabase);

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.IVMENU_NAME;
            moPage.Title = User.Language.oCaption.INVENTORY_ITEM;
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            // This page-specific objects.
            //
            moIntegrity = new clsIntegrity(ref moDatabase);
            moMoney = new clsMoney(ref moDatabase);
            moItem = new clsItem(ref moDatabase);

            Modal.Release();

            FormInitHeader();
            FormInitDetail();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitDetail()                                                              // Initialize the page at loading.  Only once.
        {
            // Detail table name.
            //
            moPage.sDetailTable_nm = "";

            moUtility.ResizeDim(ref moMatrix.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, 0);
            FormRecreateGrid(moMatrix);

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = "tblIVItem"; 
            moPage.sKeyField_nm = "sItem_cd";
            moPage.sKeyDescription = "sDescription";
            moPage.iTransaction_typ= 0; 

            return true;
        }

        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback
            
            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;
            ArrayList item_list = new ArrayList();

            try
            {
                if (FormReceiveValues() == false)                    // All pages that use session value need to capture it here before FormOpenDatabase()
                {
                    return false;
                }
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                modWebLoadUtility.LoadItemType(ref moDatabase, ref ItemTypeList);
                modLoadUtility.LoadItemClassCode(ref moDatabase, ref IVClassCodeList);
                modWebLoadUtility.LoadUnitCode(ref moDatabase, ref UnitCodeList);
                modLoadUtility.LoadItemStatusType(ref moDatabase, ref StatusTypeList, false);

                modLoadUtility.LoadManufacturer(ref moDatabase, ref ManufacturerCodeList);
                modLoadUtility.LoadBrand(ref moDatabase, ref BrandCodeList);
                modLoadUtility.LoadModel(ref moDatabase, ref ModelCodeList);
                modLoadUtility.LoadStyle(ref moDatabase, ref StyleCodeList);
                modLoadUtility.LoadSize(ref moDatabase, ref SizeCodeList);
                modLoadUtility.LoadColor(ref moDatabase, ref ColorCodeList);
                modLoadUtility.LoadSetCode(ref moDatabase, ref SetCodeList);
                modLoadUtility.LoadSimilarityCode(ref moDatabase, ref SimilarityCodeList);
                modLoadUtility.LoadItemGroupCode(ref moDatabase, ref IVGroupCodeList);
                modLoadUtility.LoadWarrantyCode(ref moDatabase, ref WarrantyCodeList);
                modLoadUtility.LoadSaleCode(ref moDatabase, ref SaleCodeList);
                modLoadUtility.LoadEventCode(ref moDatabase, ref EventCodeList);
                modLoadUtility.LoadBox(ref moDatabase, ref BoxCodeList);
                modLoadUtility.LoadCommission(ref moDatabase, ref CommissionCodeList);
                modLoadUtility.LoadARTaxCode(ref moDatabase, ref TaxCodeList);

                modLoadUtility.LoadItemCodeSeparator(User, ref CodeSeparatorList);

                OrderByList.Clear();

                item_list.Add(new clsComboBoxItem(User.Language.oCaption.ITEM_CODE, "sItem_cd"));
                item_list.Add(new clsComboBoxItem(User.Language.oCaption.CLASS, "sClass_cd"));
                item_list.Add(new clsComboBoxItem(User.Language.oCaption.GROUP, "sGroup_cd"));
                item_list.Add(new clsComboBoxItem(User.Language.oCaption.COMMISSION, "sCommission_cd"));
                item_list.Add(new clsComboBoxItem(User.Language.oCaption.PRIMARY_ITEM, "sPrimary_cd"));
                item_list.Add(new clsComboBoxItem(User.Language.oCaption.SELL_UNIT_CODE, "sSellUnit_cd"));
                item_list.Add(new clsComboBoxItem(User.Language.oCaption.UNIT_PRICE, "mSellUnitPrice_amt"));

                modWebLoadUtility.LoadComboBox(ref OrderByList, item_list);
                cboSearchOrderBy = "sItem_cd";

                // Custom Fields
                //
                if (moCustomization.ReadCustomInfo(0, User.Language.oString.STR_ITEM))
                {
                    moCustomFields.CreateGrid(moCustomization.sField_nm, moCustomization.sCaptions, moCustomization.bRequired);
                }

                if (moUtility.IsNonEmpty(moPage.sInitialKey_id))
                {
                    Header.txtKey_id = moPage.sInitialKey_id;
                    txtKey_id_Changed();
                }

                User.bConnected_fl = true;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormMove(int record_move_direction)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormClear();

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            if (FormFindRecord(ref cur_set, record_move_direction) == false)
            {
                return false;
            }

            FormShow(cur_set);
            return true;

        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostSave()
        {
            // If this is a transaction page, and transaction number has changed, let the user know.
            //
            if (moPage.sPreviousKey_id != Header.txtKey_id)
            {
                FormShowMessage(User.Language.oMessage.TRX_NUM_HAS_CHANGED_TO + "  " + Header.txtKey_id, false);
            }

            moPage.sPreviousKey_id = Header.txtKey_id;

            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {

            return true;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormReceiveValues()
        {
            // If connected already, return true.  This means this page came through the menu system.
            //
            if (moUtility.IsNonEmpty(User.sServer_nm) || moDatabase.IsConnected())
            {
                return true;
            }

            // Otherwise, need to login with the info passed from the calling page.
            //
            if (modGeneralUtility.GetPassedParameters(StarterValue, User, moSession) == false)
            {
                FormShowMessage(User.Language.oMessage.PLEASE_LOG_IN_FIRST);
                return false;
            }

            moPage.sInitialKey_id = moSession.Value.Entity;

            return true;
        }

        private bool FormRecreateDetail(Models.clsSpreadsheet cur_spread)
        {
            if (cur_spread.RecreateDetail() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateDetailLine(Models.clsSpreadsheet.clsGrid cur_item, int row_num = -1)
        {
            if (moMatrix.RecreateDetailLine(cur_item, row_num) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateGrid(Models.clsSpreadsheet cur_spread)
        {
            if (cur_spread.RecreateGrid() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormSave()
        {
            bool return_value = false;
            clsRecordset cur_set;

            try
            {
                if (FormOpenDatabase() == false)                     // Has to come before FormCheck()
                {
                    return false;
                }
                else if (FormCheck() == false)                       // Check if data is ok to save.
                {
                    return false;
                }

                moPage.sPreviousKey_id = Header.txtKey_id;
                cur_set = new clsRecordset(ref moDatabase);

                if (modFormUtility.RecordOpen(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sRestrictionClause, moPage.sTable_nm, moPage.sKeyField_nm) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormCheckConcurrency(cur_set) == false)
                {
                    return false;
                }
                else if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormPreSave(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveHeader(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveExtra(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (moItem.SaveItem() == false)
                {
                    if (moDatabase.IsErrorFound())
                    {
                        FormShowMessage();
                    }
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (moDatabase.TransactionCommit() == false)
                {
                    FormShowMessage();
                    moDatabase.TransactionRollback();
                    return false;
                }

                FormPostSave();
                    
                return_value = true;

            }
            catch (Exception ex)
            {

                FormShowMessage(ex.Message + " (FormSave)");
                moDatabase.TransactionRollback();

            }

            return return_value;
        }

        private bool FormSaveExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormSaveHeader(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                moItem.bNew_fl = (moPage.bNew_fl || cur_set.EOF());

                Header.txtComment = moUtility.EvalQuote(Header.txtComment);

                // This is for Concurrency check to go smooth.
                // If someone calls FormSave() without going thru the whole saving routine that
                // clears the screen, and save again later, then FormCheckConcurrency() will raise an error
                // because the record in the database has been updated but moPage.Original.dtLastUpdate_dt still has the old timestamp.
                //
                moPage.Original.sLastUpdate_id = moDatabase.sUser_cd;
                moPage.Original.dtLastUpdate_dt = DateTime.Now;

                moItem.sItem_cd = moUtility.EvalQuote(Header.txtKey_id);
                moItem.sDescription = moUtility.EvalQuote(Header.txtDescription);
                moItem.sClass_cd = Header.cboClass_cd;
                moItem.iItem_typ = Header.cboItem_typ;
                moItem.iTaxable_fl = moUtility.IIf(Header.chkTaxable_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moItem.iKit_typ = moUtility.IIf(Header.chkKit_fl, Header.optAssembly_typ, 0);
                moItem.iTrackSales_typ = GlobalVar.goConstant.TRACK_WEEKLY_TYPE_NUM;                    // From 09/08/2014,
                moItem.sAltItem_cd = moUtility.EvalQuote(Header.txtAltItem_cd);
                moItem.sTax_cd = Header.cboTax_cd;
                moItem.sPurchaseUnit_cd = Header.cboPurchaseUnit_cd;
                moItem.sSellUnit_cd = Header.cboSellUnit_cd;
                moItem.sIVUnit_cd = Header.cboIVUnit_cd;
                moItem.mSellUnitPrice_amt = moMoney.ToNumMoney(Header.txtSellUnitPrice_amt);
                moItem.mStdCost_amt = moMoney.ToNumMoney(Header.txtStdCost_amt);
                moItem.sGroup_cd = Header.cboGroup_cd;
                moItem.sUPC_cd = moUtility.EvalQuote(Header.txtUPC_cd);
                moItem.sSKU_cd = moUtility.EvalQuote(Header.txtSKU_cd);
                moItem.sManufacturerItem_cd = moUtility.EvalQuote(Header.txtManufacturerItem_cd);
                moItem.sSortKey1 = moUtility.EvalQuote(Header.txtSortKey1);
                moItem.sSortKey2 = moUtility.EvalQuote(Header.txtSortKey2);
                moItem.sWebClass_cd = moUtility.EvalQuote(Header.txtWebClass_cd);
                moItem.sSale_cd = Header.cboSale_cd;
                moItem.mSalePrice_amt = moMoney.ToNumMoney(Header.txtSalePrice_amt);
                moItem.sEvent_cd = Header.cboEvent_cd;
                moItem.sSimilarity_cd = Header.cboSimilarity_cd;
                moItem.sSet_cd = Header.cboSet_cd;
                moItem.sWarranty_cd = Header.cboWarranty_cd;
                moItem.sManufacturer_cd = Header.cboManufacturer_cd;
                moItem.sBrand_cd = Header.cboBrand_cd;
                moItem.sModel_cd = Header.cboModel_cd;
                moItem.sStyle_cd = Header.cboStyle_cd;
                moItem.sSize_cd = Header.cboSize_cd;
                moItem.sColor_cd = Header.cboColor_cd;
                moItem.fWeight = moUtility.ToValue(Header.txtWeight);
                moItem.fHeight = moUtility.ToValue(Header.txtHeight);
                moItem.fWidth = moUtility.ToValue(Header.txtWidth);
                moItem.fLength = moUtility.ToValue(Header.txtLength);
                moItem.iNewItem_fl = moUtility.IIf(Header.chkNewItem_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moItem.iWebEnabled_fl = moUtility.IIf(Header.chkWebEnabled_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moItem.iConsignment_typ = moUtility.IIf(Header.chkConsignment_typ, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moItem.sSmallPictureFile_nm = moUtility.EvalQuote(Header.txtSmallPictureFile_nm);
                moItem.sFullPictureFile_nm = moUtility.EvalQuote(Header.txtFullPictureFile_nm);
                moItem.iLeadTime = moUtility.ToInteger(Header.txtLeadTime);
                moItem.iDontShowPrice_fl = moUtility.IIf(Header.chkDontShowPrice_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moItem.sMessageForPrice = moUtility.EvalQuote(Header.txtMessageForPrice);
                moItem.sPrimary_cd = moUtility.EvalQuote(Header.txtPrimary_cd);
                moItem.sBox_cd = Header.cboBox_cd;
                moItem.iDisplay_qty = moUtility.ToInteger(Header.txtDisplay_qty);
                moItem.sPreferredVendor_cd = moUtility.EvalQuote(Header.txtVendor_cd);
                moItem.mFreight_amt = moMoney.ToNumMoney(Header.txtFreight_amt);
                moItem.sCommission_cd = Header.cboCommission_cd;
                moItem.sLabel = moUtility.EvalQuote(Header.txtLabel);
                moItem.iPerishable_fl = moUtility.IIf(Header.chkPerishable_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moItem.iInternalUseOnly_fl = moUtility.IIf(Header.chkInternalUseOnly_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moItem.iStatus_typ = Header.cboStatus_typ;

                moItem.sComment = moUtility.SLeft(Header.txtComment, 250);
                moItem.sComment2 = moUtility.SMid(Header.txtComment, 251, 250);
                moItem.sComment3 = moUtility.SMid(Header.txtComment, 501, 250);

                // Attach the custom field list
                //
                moItem.CustomFieldList = moCustomFields.GetFieldList();
                moItem.CustomValueList = moCustomFields.GetValueList(moDatabase);
                moItem.CustomUpdateList = moCustomFields.GetUpdateList(moDatabase);

                moItem.sLastUpdate_id = moPage.Original.sLastUpdate_id;
                moItem.dtLastUpdate_dt = moPage.Original.dtLastUpdate_dt;

                //Extra fields.
                //
                moItem.sLongDescription = moUtility.EvalQuote(Header.txtLongDescription);
                moItem.sFullDescription = moUtility.EvalQuote(Header.txtFullDescription);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveHeader)");
            }

            return return_value;
        }

        private bool FormSearch()
        {
            string where_clause = GetSearchCriteria();

            if (moUtility.IsEmpty(where_clause))
            {
                FormShowMessage(User.Language.oMessage.PLEASE_ENTER_THE_SEARCH_CRITERIA_ON_THE_MAIN_ENTRY_TAB);
                return false;
            }

            if (moUtility.IsNonEmpty(cboSearchOrderBy))
            {
                where_clause = where_clause + " ORDER BY " + cboSearchOrderBy;
            }

            mbSearchPopulated_fl = false;

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moSearch.Show(moDatabase, moPage, where_clause, "sClass_cd", "sGroup_cd", "sCommission_cd", "sPrimary_cd", "sSellUnit_cd", "mSellUnitPrice_amt", "", "", "", "", moCustomization.sField_nm) == false)
            {
                FormShowMessage();
                return false;
            }

            mbSearchInitiated_fl = true;
            mbSearchPopulated_fl = (moSearch.Grid.Count > 0);

            if (mbSearchPopulated_fl == false)
            {
                FormShowMessage(User.Language.oMessage.NO_MATCHING_RECORDS_FOUND);
            }

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {
            if (FormShowHeader(cur_set) == false)
            {
                return false;
            }
            else if (FormShowExtra(cur_set) == false)
            {
                return false;
            }

            FormReArrangeHeader();

            return true;
        }

        private bool FormShowExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                moPage.Clear();
                moPage.PreserveTimestamp(cur_set);
                moPage.bNew_fl = false;

                // Get the default item matrix options
                //
                if (MatrixItem)
                {
                    GetItemMatrixOptions();
                }

                // This is where bReadOnly_fl & bReserved_fl are set according to the nature of the current record.
                //
                msOriginalIVUnit_cd = Header.cboIVUnit_cd;

                if (moUtility.IsNonEmpty(Header.txtSmallPictureFile_nm))
                {
                    msItemImageFile_nm = modGeneralUtility.GetVirtualFileName(moDatabase.uDirectory.sWebInventoryImageDirectory_nm + "\\" + Header.txtSmallPictureFile_nm, true);
                }
                else
                {
                    msItemImageFile_nm = "";
                }

                mbPrimaryEntered_fl = false;

                moPage.sPreviousKey_id = Header.txtKey_id;
                Header.Preserve();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowHeader(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                Header.txtKey_id = cur_set.sField(moPage.sKeyField_nm);
                Header.txtDescription = cur_set.sField("sDescription");

                //mskCreated_dt = moGeneral.ToStrDate(cur_set.iField("iCreated_dt")))
                Header.txtComment = cur_set.sField("sComment") + cur_set.sField("sComment2") + cur_set.sField("sComment3");
                Header.txtDisplay_qty = cur_set.iField("iDisplay_qty").ToString();
                Header.txtMessageForPrice = cur_set.sField("sMessageForPrice");
                Header.txtWebClass_cd = cur_set.sField("sWebClass_cd");
                Header.txtPrimary_cd = cur_set.sField("sPrimary_cd");
                Header.txtFreight_amt = moMoney.ToStrMoney(cur_set.mField("mFreight_amt"));
                Header.txtSortKey1 = cur_set.sField("sSortKey1");
                Header.txtSortKey2 = cur_set.sField("sSortKey2");
                Header.txtSmallPictureFile_nm = GlobalVar.goFile.GetFileName(cur_set.sField("sSmallPictureFile_nm"));
                Header.txtLength = cur_set.mField("fLength").ToString();
                Header.txtWidth = cur_set.mField("fWidth").ToString();
                Header.txtHeight = cur_set.mField("fHeight").ToString();
                Header.txtWeight = cur_set.mField("fWeight").ToString();
                Header.txtDescription = cur_set.sField("sDescription");
                Header.txtLabel = cur_set.sField("sLabel");
                Header.txtVendor_cd = cur_set.sField("sPreferredVendor_cd");
                Header.txtManufacturerItem_cd = cur_set.sField("sManufacturerItem_cd");
                Header.txtUPC_cd = cur_set.sField("sUPC_cd");
                Header.txtSKU_cd = cur_set.sField("sSKU_cd");
                Header.txtLeadTime = cur_set.iField("iLeadTime").ToString();
                Header.txtSalePrice_amt = moMoney.ToStrMoney(cur_set.mField("mSalePrice_amt"));
                Header.txtSellUnitPrice_amt = moMoney.ToStrMoney(cur_set.mField("mSellUnitPrice_amt"));
                Header.txtAltItem_cd = cur_set.sField("sAltItem_cd");
                Header.txtStdCost_amt = moMoney.ToStrMoney(cur_set.mField("mStdCost_amt"));
                Header.chkTaxable_fl = (cur_set.iField("iTaxable_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.txtFullPictureFile_nm = GlobalVar.goFile.GetFileName(cur_set.sField("sFullPictureFile_nm"));
                Header.lblLastSalesRet_dt = moGeneral.ToStrDate(cur_set.iField("iLastSalesRet_dt"));
                Header.lblLastSales_dt = moGeneral.ToStrDate(cur_set.iField("iLastSales_dt"));
                Header.lblLastPurchaseRet_dt = moGeneral.ToStrDate(cur_set.iField("iLastPurchaseRet_dt"));
                Header.lblLastPurchase_dt = moGeneral.ToStrDate(cur_set.iField("iLastPurchase_dt"));
                Header.lblLastPhysical_dt = moGeneral.ToStrDate(cur_set.iField("iLastPhysical_dt"));
                Header.lblLastCost_amt = moMoney.ToStrMoney(cur_set.mField("mLastCost_amt"));
                Header.lblLastVendor_cd = cur_set.sField("sLastVendor_cd");
                Header.chkPerishable_fl = (cur_set.iField("iPerishable_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkInternalUseOnly_fl = (cur_set.iField("iInternalUseOnly_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.lblAvgCost_amt = moMoney.ToStrMoney(cur_set.mField("mAvgCost_amt"));

                Header.chkNewItem_fl = (cur_set.iField("iNewItem_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkWebEnabled_fl = (cur_set.iField("iWebEnabled_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkDontShowPrice_fl = (cur_set.iField("iDontShowPrice_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkConsignment_typ = (cur_set.iField("iConsignment_typ") > 0);       // == GlobalVar.goConstant.FLAG_ON);
                Header.chkKit_fl = cur_set.iField("iKit_typ") > 0;

                if (cur_set.iField("iKit_typ") > 0)
                {
                    Header.optAssembly_typ = cur_set.iField("iKit_typ");
                }
                else
                {
                    Header.optAssembly_typ = 0;
                }

                Header.cboStatus_typ = cur_set.iField("iStatus_typ");

                Header.cboTax_cd = cur_set.sField("sTax_cd");
                Header.cboItem_typ = cur_set.iField("iItem_typ");
                Header.cboClass_cd = cur_set.sField("sClass_cd");
                Header.cboSellUnit_cd = cur_set.sField("sSellUnit_cd");
                Header.cboPurchaseUnit_cd = cur_set.sField("sPurchaseUnit_cd");
                Header.cboIVUnit_cd = cur_set.sField("sIVUnit_cd");
                Header.cboTax_cd = cur_set.sField("sTax_cd");

                Header.cboCommission_cd = cur_set.sField("sCommission_cd");
                Header.cboGroup_cd = cur_set.sField("sGroup_cd");
                Header.cboBox_cd = cur_set.sField("sBox_cd");
                Header.cboStyle_cd = cur_set.sField("sStyle_cd");
                Header.cboSet_cd = cur_set.sField("sSet_cd");
                Header.cboSimilarity_cd = cur_set.sField("sSimilarity_cd");
                Header.cboColor_cd = cur_set.sField("sColor_cd");
                Header.cboSize_cd = cur_set.sField("sSize_cd");
                Header.cboModel_cd = cur_set.sField("sModel_cd");
                Header.cboBrand_cd = cur_set.sField("sBrand_cd");
                Header.cboManufacturer_cd = cur_set.sField("sManufacturer_cd");
                Header.cboWarranty_cd = cur_set.sField("sWarranty_cd");
                Header.cboSale_cd = cur_set.sField("sSale_cd");
                Header.cboEvent_cd = cur_set.sField("sEvent_cd");


                // Custom Fields
                //
                moCustomFields.SetValues(moDatabase, cur_set);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowHeader)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowListing()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moListing.Show(moDatabase, moPage) == false)
            {
                return false;
            }

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moZoom.Caller == "txtVendor_cd")
            {
                if (moZoom.Vendor(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            else if (moZoom.Caller == "txtKey_id" || moZoom.Caller == "txtAltItem_cd" || moZoom.Caller == "txtPrimary_cd")
            {
                if (moZoom.Inventory(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            else if (moZoom.Caller == "txtWebClass_cd")
            {
                if (moZoom.Code(ref moDatabase, "tblIVWebClass") == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            else if (moZoom.Account(ref moDatabase) == false)
            {
                FormShowMessage(null, (moZoom.bShowOptionBar == false));
                return false;
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormClear();
                return true;
            }

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
                {
                    return false;
                }
            }

            FormCancel();
            return true;
        }

        private bool btnDelete_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormClear();
                return true;
            }

            if (FormDialog(btnDelete_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_DELETE) == false)
            {
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (FormDelete() == false)
            {
                return false;
            }
            
            FormClear();
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormExit();
                return true;
            }

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }

        private bool btnFirst_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnFirst_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.FIRST_RECORD_TYPE);
        }

        private bool btnLast_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnLast_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.LAST_RECORD_TYPE);
        }

        private bool btnNext_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnNext_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.NEXT_RECORD_TYPE);
        }

        private bool btnPrevious_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnPrevious_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.PREVIOUS_RECORD_TYPE);
        }

        private bool btnSave_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormSave() == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewHeader_Clicked()
        {
            FormPreEvent();                                                                           
            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool cmdViewSpecification_Clicked()
        {
            FormPreEvent();       
            
            FormSwitchView(moView.SPECIFICTION_PAGE_NUM);
            return true;

        }

        private bool cmdViewMatrixEntry_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.MATRIX_PAGE_NUM);
            return true;

        }
        private bool cmdViewActivities_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.ACTIVITY_PAGE_NUM);
            return true;

        }

        private bool cmdViewSearch_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.SEARCH_PAGE_NUM);
            return true;

        }
        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnListingSelect_Clicked(Models.clsListing.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.IsEmpty(cur_item.Code))
            {
                return false;
            }

            FormClear();
            Header.txtKey_id = cur_item.Code;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnSearchSelect_Clicked(Models.clsEntitySearch.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.IsEmpty(cur_item.Code))
            {
                return false;
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            FormClear();
            Header.txtKey_id = cur_item.Code;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnSearchToPrint_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateSearchHTML();

            return FormPostEvent();
        }

        private bool btnSearchToExcel_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateSearchExcel();

            return FormPostEvent();
        }


        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                if (moUtility.IsEmpty(cur_item.Col_0))
                {
                    return false;
                }

                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

                code_selected = cur_item.Col_0;

                if (moZoom.Caller == "txtVendor_cd")
                {
                    Header.txtVendor_cd = code_selected;
                }
                else if (moZoom.Caller == "txtKey_id")
                {
                    Header.txtKey_id = code_selected;
                    txtKey_id_Changed();
                }
                else if (moZoom.Caller == "txtAltItem_cd")
                {
                    Header.txtAltItem_cd = code_selected;
                }
                else if (moZoom.Caller == "txtPrimary_cd")
                {
                    Header.txtPrimary_cd = code_selected;
                }
                else if (moZoom.Caller == "txtWebClass_cd")
                {
                    Header.txtWebClass_cd = code_selected;
                }

                FormSwitchView(moZoom.iView);
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }

        private bool cboSearchOrderBy_Clicked()
        {
            FormPreEvent();

            FormSearch();

            return FormPostEvent();
        }
        private bool cmdSearch_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            FormSearch();
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            return FormPostEvent();
        }

        private bool btnZoomOnKey_id_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtKey_id", -1, -1, moView.MAIN_PAGE_NUM, "sItem_cd", "") == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);   // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return true;
        }

        private bool btnZoomOnPrimary_cd_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtPrimary_cd", -1, -1, moView.MAIN_PAGE_NUM, "sItem_cd", "") == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);   // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return true;
        }

        private bool btnZoomOnAltItem_cd_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtAltItem_cd", -1, -1, moView.MAIN_PAGE_NUM, "sItem_cd", "") == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);   // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return true;
        }

        private bool btnZoomOnVendor_cd_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtVendor_cd", -1, -1, moView.MAIN_PAGE_NUM, "sVendor_cd", "") == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);   // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return true;
        }

        private bool btnZoomOnWebClass_cd_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtWebClass_cd", -1, -1, moView.SPECIFICTION_PAGE_NUM, "sWebClass_cd", "") == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);   // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Changed()
        {
            if (Header.txtKey_id == Header.Tag.txtKey_id)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (txtKey_id_Verified() == false)
            {
                return false;
            }

            if (moUtility.IsEmpty(Header.txtPrimary_cd) || mbPrimaryEntered_fl == false)
            {
                Header.txtPrimary_cd = Header.txtKey_id;
            }

            // Need to clear up the quantity info.
            //
            mbShowQuantity_fl = false;
            moQuantity.Clear();

            return FormPostEvent();
        }

        private bool txtAltItem_cd_Changed()
        {
            if (Header.txtAltItem_cd == Header.Tag.txtAltItem_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            modCommonUtility.CleanCode(ref Header.txtAltItem_cd);

            if (moUtility.IsEmpty(Header.txtAltItem_cd))
            {
                //
            }
            else if (moValidate.IsValidItemCode(Header.txtAltItem_cd) == false)
            {
                FormShowMessage(Header.txtAltItem_cd + User.Language.oMessage.IS_INVALID);
                Header.txtAltItem_cd = Header.Tag.txtAltItem_cd;
                FormSetFocus("txtAltItem_cd");
            }

            return FormPostEvent();
        }

        private bool txtPrimary_cd_Changed()
        {
            if (Header.txtPrimary_cd == Header.Tag.txtPrimary_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            modCommonUtility.CleanCode(ref Header.txtPrimary_cd);

            if (moUtility.IsEmpty(Header.txtKey_id))
            {

            }
            else if (Header.txtPrimary_cd == Header.txtKey_id)
            {

            }
            else if (moUtility.IsEmpty(Header.txtPrimary_cd))
            {
                Header.txtPrimary_cd = Header.txtKey_id;
            }
            else
            {
                if (FormOpenDatabase() == false)
                {
                    Header.txtPrimary_cd = Header.Tag.txtPrimary_cd;
                    return false;
                }
                if (moValidate.IsValidItemCode(Header.txtPrimary_cd, true) == false)
                {
                    FormShowMessage(Header.txtPrimary_cd + User.Language.oMessage.IS_INVALID);
                    Header.txtPrimary_cd = Header.Tag.txtPrimary_cd;
                    FormSetFocus("txtPrimary_cd");
                }
                else
                {
                    Header.txtSellUnitPrice_amt = moMoney.ToStrMoney(moValidate.oRecordset.mField("mSellUnitPrice_amt"));
                    Header.cboIVUnit_cd = moValidate.oRecordset.sField("sIVUnit_cd");
                    Header.cboSellUnit_cd = moValidate.oRecordset.sField("sSellUnit_cd");
                    Header.cboPurchaseUnit_cd = moValidate.oRecordset.sField("sPurchaseUnit_cd");
                    Header.cboTax_cd = moValidate.oRecordset.sField("sTax_cd");
                    Header.cboCommission_cd = moValidate.oRecordset.sField("sCommission_cd");
                    Header.cboClass_cd = moValidate.oRecordset.sField("sClass_cd");
                    Header.cboGroup_cd = moValidate.oRecordset.sField("sGroup_cd");
                    Header.cboItem_typ = moValidate.oRecordset.iField("iItem_typ");
                    Header.cboWarranty_cd = moValidate.oRecordset.sField("sWarranty_cd");
                    Header.chkTaxable_fl = (moValidate.oRecordset.iField("iTaxable_fl") == GlobalVar.goConstant.CHECKED_ON);
                    Header.chkPerishable_fl = (moValidate.oRecordset.iField("iPerishable_fl") == GlobalVar.goConstant.CHECKED_ON);
                    Header.chkInternalUseOnly_fl = (moValidate.oRecordset.iField("iInternalUseOnly_fl") == GlobalVar.goConstant.CHECKED_ON);

                    Header.txtVendor_cd = moValidate.oRecordset.sField("sPreferredVendor_cd");
                    Header.txtLeadTime = moValidate.oRecordset.iField("iLeadTime").ToString();
                    Header.txtStdCost_amt = moValidate.oRecordset.mField("mStdCost_amt").ToString();

                    Header.cboManufacturer_cd = moValidate.oRecordset.sField("sManufacturer_cd");
                    Header.cboBrand_cd = moValidate.oRecordset.sField("sBrand_cd");
                    //Header.cboModel_cd = moValidate.oRecordset.sField("sModel_cd");
                    //Header.cboSize_cd = moValidate.oRecordset.sField("sSize_cd");
                    //Header.cboColor_cd = moValidate.oRecordset.sField("sColor_cd");
                    //Header.cboStyle_cd = moValidate.oRecordset.sField("sStyle_cd");

                    if (moUtility.IsEmpty(Header.txtDescription))
                    {
                        Header.txtDescription = moValidate.oRecordset.sField("sDescription");
                    }
                    if (moUtility.IsEmpty(Header.txtLabel))
                    {
                        Header.txtLabel = moValidate.oRecordset.sField("sLabel");
                    }
                }
            }

            mbPrimaryEntered_fl = moUtility.IsNonEmpty(Header.txtKey_id);

            return FormPostEvent();
        }

        private bool txtVendor_cd_Changed()
        {
            if (Header.txtVendor_cd == Header.Tag.txtVendor_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.
            
            modCommonUtility.CleanCode(ref Header.txtVendor_cd);

            if (moUtility.IsNonEmpty(Header.txtVendor_cd))
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                else if (moValidate.IsValidVendorCode(Header.txtVendor_cd) == false)
                {
                    FormShowMessage(Header.txtVendor_cd + User.Language.oMessage.IS_INVALID);
                    Header.txtVendor_cd = Header.Tag.txtVendor_cd;
                    FormSetFocus("txtVendor_cd");
                }

            }

            return FormPostEvent();
        }

        private bool txtWebClass_cd_Changed()
        {
            if (Header.txtWebClass_cd == Header.Tag.txtWebClass_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            modCommonUtility.CleanCode(ref Header.txtWebClass_cd);

            if (moUtility.IsEmpty(Header.txtWebClass_cd))
            {

            }
            else if (moValidate.IsValidWebClassCode(Header.txtWebClass_cd) == false)
            {
                FormShowMessage(Header.txtWebClass_cd + User.Language.oMessage.IS_INVALID);
                Header.txtWebClass_cd = Header.Tag.txtWebClass_cd;
            }

            return FormPostEvent();
        }

        private bool cboTax_cd_Changed()
        {
            if (Header.cboTax_cd == Header.Tag.cboTax_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.txtKey_id) || moUtility.IsEmpty(Header.cboTax_cd))
            {

            }
            else if (moDatabase.iSalesTax_typ == GlobalVar.goConstant.TAX_VAT_TYPE_NUM)
            {
                if (moValidate.IsValidAPTaxCode(Header.cboTax_cd) == false)
                {
                    FormShowMessage("This code should exist in purchase tax of A/P, also.");
                    Header.cboTax_cd = Header.Tag.cboTax_cd;
                }
            }

            return FormPostEvent();
        }

        private bool cboIVUnit_cd_Changed()
        {
            if (Header.cboIVUnit_cd == Header.Tag.cboIVUnit_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsNonEmpty(Header.cboIVUnit_cd))
            {
                if (moUtility.IsEmpty(Header.cboPurchaseUnit_cd))
                {
                    Header.cboPurchaseUnit_cd = Header.cboIVUnit_cd;
                }

                if (moUtility.IsEmpty(Header.cboSellUnit_cd))
                {
                    Header.cboSellUnit_cd = Header.cboIVUnit_cd;
                }
            }

            return FormPostEvent();
        }

        private bool txtSmallPictureFile_nm_Changed()
        {
            if (Header.txtSmallPictureFile_nm == Header.Tag.txtSmallPictureFile_nm)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            ShowSmallPicture();

            return FormPostEvent();
        }

        private bool cmdShowQuantity_Clicked()
        {
            FormPreEvent();

            if (FormOpenDatabase() == false)
            {
                mbShowQuantity_fl = false;
                return false;
            }
            else if (ShowQuantity() == false)
            {
                mbShowQuantity_fl = false;
                return false;
            }

            mbShowQuantity_fl = true;
            return true;

        }

        private bool chkAll_fl_Clicked()
        {
            if (chkAll_fl)
            {
                cmdUnSelectAll_Clicked();
            }
            else
            {
                cmdSelectAll_Clicked();
            }

            return FormPostEvent();
        }

        private bool cmdUnSelectAll_Clicked()
        {
            foreach (var det in moMatrix.Grid)
            {
                det.chkInclude_fl = false;
                det.Col_0 = GlobalVar.goConstant.CHECKED_OFF.ToString();
            }

            FormRecreateDetail(moMatrix);

            return FormPostEvent();
        }

        private bool cmdSelectAll_Clicked()
        {
            foreach (var det in moMatrix.Grid)
            {
                if (moUtility.IsNonEmpty(det.Col_1))
                {
                    det.chkInclude_fl = true;
                    det.Col_0 = GlobalVar.goConstant.CHECKED_ON.ToString();
                }
                else
                {
                    det.chkInclude_fl = false;
                    det.Col_0 = GlobalVar.goConstant.CHECKED_OFF.ToString();
                }
            }

            FormRecreateDetail(moMatrix);

            return FormPostEvent();
        }

        private bool cmdRefreshMatrix_Clicked()
        {
            FormPreEvent();

            cmdRefreshMatrix_Verified();

            return FormPostEvent();
        }

        private bool cmdGenerateMatrixCodes_Clicked()
        {
            FormPreEvent();

            cmdGenerateMatrixCodes_Verified();

            return FormPostEvent();
        }

        private bool cmdSaveMatrix_Clicked()
        {
            int items_saved = 0;

            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moPage.bNew_fl)                                  // This will let the user change the ID if it is brand new record.
            {
                FormShowMessage(User.Language.oMessage.SAVE_RECORD_FIRST);
                return false;
            }
            else
            {
                Header.cboStatus_typ = GlobalVar.goIVConstant.OPEN_ITEM_NUM;
            }
            if (cmdSaveMatrix_Verified(ref items_saved))
            {
                SaveItemMatrixOptions();
                FormShowMessage(items_saved.ToString() + User.Language.oMessage.ITEMS_SAVED, false);
                FormClearDetail();
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Verified()
        {
            bool return_value = false;
            clsRecordset cur_set;
            string key_id = "";

            try
            {
                Header.txtKey_id = modCommonUtility.CleanCode(Header.txtKey_id);
                key_id = Header.txtKey_id;

                if (Header.txtKey_id == Header.Tag.txtKey_id)
                {
                    return true;
                }
                else if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormClear();
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    FormClear();
                    FormShowMessage(User.Language.oMessage.CONNECTION_HAS_FAILED);
                    return false;
                }

                cur_set = new clsRecordset(ref moDatabase);

                if (FormFindRecord(ref cur_set))
                {
                    FormShow(cur_set);
                }
                else
                {
                    if (moPage.bNew_fl == false)                                  // This will let the user change the ID if it is brand new record.
                    {
                        FormClear();
                        Header.txtKey_id = key_id;
                    }
                    else
                    {
                        Header.cboStatus_typ = GlobalVar.goIVConstant.OPEN_ITEM_NUM;
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtKey_id_Verified)");
            }

            return return_value;
        }

        private bool CustomField_Changed(Models.clsCustomField.clsGrid cur_item)
        {
            FormPreEvent();

            if (moCustomFields.ValidateValue(moDatabase, cur_item) == false)
            {
                FormShowMessage(moCustomFields.GetErrorMessage());
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdQuantity_Clicked()
        {
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";

            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            o_session.SetSessionValues(moDatabase, User, ref session_id, Header.txtKey_id);

            FormOpenPDF("Quantity/" + session_id);

            return FormPostEvent();
        }

        private bool cmdSummary_Clicked()
        {
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";

            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            o_session.SetSessionValues(moDatabase, User, ref session_id, Header.txtKey_id);

            FormOpenPDF("ItemHistory/" + session_id);

            return FormPostEvent();
        }

        private bool cmdPurchaseHistoty_Clicked()
        {
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";

            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            o_session.SetSessionValues(moDatabase, User, ref session_id, Header.txtKey_id);

            FormOpenPDF("PurchaseHistory/" + session_id);

            return FormPostEvent();
        }

        private bool cmdSalesHistoty_Clicked()
        {
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";

            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            o_session.SetSessionValues(moDatabase, User, ref session_id, Header.txtKey_id);

            FormOpenPDF("SalesHistory/" + session_id);

            return FormPostEvent();
        }

        private bool cmdArrivalSchedule_Clicked()
        {
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";

            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            o_session.SetSessionValues(moDatabase, User, ref session_id, Header.txtKey_id);

            FormOpenPDF("OrderArrival/" + session_id);

            return FormPostEvent();
        }

        private bool cmdSerial_Clicked()
        {
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";

            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            o_session.SetSessionValues(moDatabase, User, ref session_id, Header.txtKey_id);

            FormOpenPDF("Serial/" + session_id);

            return FormPostEvent();
        }

        private bool cmdCustomerItem_Clicked()
        {
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";

            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            o_session.SetSessionValues(moDatabase, User, ref session_id, Header.txtKey_id);

            FormOpenPDF("ItemCustomer/" + session_id);

            return FormPostEvent();
        }

        private bool cmdVendorItem_Clicked()
        {
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";

            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            o_session.SetSessionValues(moDatabase, User, ref session_id, Header.txtKey_id);

            FormOpenPDF("ItemVendor/" + session_id);

            return FormPostEvent();
        }

        private bool cmdRefreshMatrix_Verified()
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
                for (row_num = 0; row_num < moMatrix.Data.GetLength(1); row_num++)
                {

                    if (MatrixHeader.chkCopyLabel_fl)
                    {
                        moMatrix.Data[MATRIX_LABEL_COL, row_num] = Header.txtLabel;
                    }
                    else
                    {
                        moMatrix.Data[MATRIX_LABEL_COL, row_num] = "";
                    }

                    if (MatrixHeader.chkCopyDescription_fl)
                    {
                        moMatrix.Data[MATRIX_DESC_COL, row_num] = Header.txtDescription;
                    }
                    else
                    {
                        moMatrix.Data[MATRIX_DESC_COL, row_num] = "";
                    }

                    //if (MatrixHeader.chkCopyCode_fl)
                    //{
                    //    moMatrix.Data[MATRIX_ITEM_COL, row_num] = Header.txtPrimary_cd;
                    //}
                    //else
                    //{
                    //    moMatrix.Data[MATRIX_ITEM_COL, row_num] = "";
                    //}

                    if (MatrixHeader.chkCopyUnitPrice_fl)
                    {
                        moMatrix.Data[MATRIX_UNIT_PRICE_COL, row_num] = Header.txtSellUnitPrice_amt;
                    }
                    else
                    {
                        moMatrix.Data[MATRIX_UNIT_PRICE_COL, row_num] = "";
                    }

                    moMatrix.Data[MATRIX_SELECT_COL, row_num] = GlobalVar.goConstant.CHECKED_ON.ToString();
                }

                FormRecreateGrid(moMatrix);
                cmdSelectAll_Clicked();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (cmdRefreshMatrix_Verified)");
            }
            return return_value;
        }

        private bool cmdGenerateMatrixCodes_Verified()
        {
            bool return_value = false;
            int row_num = 0;
            clsRecordset size_set = new clsRecordset(ref moDatabase);
            clsRecordset color_set = new clsRecordset(ref moDatabase);
            clsRecordset extra_set = new clsRecordset(ref moDatabase); // will have one of manufacturer, brand, model, style
            string item_code = "";
            string item_label = "";
            string item_desc = "";
            string[,] matrix_data = null;
            int line_num = 0;
            string extra_field_name = "";
            string extra_field_value = "";
            int extra_field_col = 0;
            bool enter_extra_loop_fl = false;
            int total_combo = 0;
            int max_row = 0;

            try
            {
                msCodeSeparator = MatrixHeader.cboCodeSeparator;

                if (moUtility.IsEmpty(msCodeSeparator))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER + @User.Language.oCaption.CODE + " " + User.Language.oCaption.SEPARATOR);
                    FormSetFocus("cboCodeSeparator");
                    return false;
                }
                else if (msCodeSeparator == User.Language.oString.STR_NONE)
                {
                    msCodeSeparator = "";
                }

                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                
                if (!MatrixHeader.chkUseColor_fl && !MatrixHeader.chkUseSize_fl && !MatrixHeader.chkUseStyle_fl && !MatrixHeader.chkUseModel_fl && !MatrixHeader.chkUseBrand_fl && !MatrixHeader.chkUseManufacturer_fl)
                {
                    FormShowMessage("Please, check at least one option.");
                    return false;
                }

                if (color_set.CreateSnapshot("SELECT sColor_cd FROM tblIVColor ORDER BY sColor_cd") == false)
                {
                    return false;
                }
                if (size_set.CreateSnapshot("SELECT sSize_cd FROM tblIVSize ORDER BY sSize_cd") == false)
                {
                    return false;
                }

                // IMPORTANT
                //       In addition to the combination of size/color, ONLY on another can be combined.  extra_set will carry it.
                //
                extra_field_name = "";
                extra_field_value = "";
                extra_field_col = -1;

                if (MatrixHeader.chkUseStyle_fl)
                {
                    if (extra_set.CreateSnapshot("SELECT sStyle_cd FROM tblIVStyle ORDER BY sStyle_cd") == false)
                    {
                        return false;
                    }
                    else if (extra_set.EOF() == false)
                    {
                        extra_field_name = "sStyle_cd";
                        extra_field_col = MATRIX_STYLE_COL;
                    }
                }
                else if (MatrixHeader.chkUseModel_fl)
                {
                    if (extra_set.CreateSnapshot("SELECT sModel_cd FROM tblIVModel ORDER BY sModel_cd") == false)
                    {
                        return false;
                    }
                    else if (extra_set.EOF() == false)
                    {
                        extra_field_name = "sModel_cd";
                        extra_field_col = MATRIX_MODEL_COL;
                    }
                }
                else if (MatrixHeader.chkUseBrand_fl)
                {
                    if (extra_set.CreateSnapshot("SELECT sBrand_cd FROM tblIVBrand ORDER BY sBrand_cd") == false)
                    {
                        return false;
                    }
                    else if (extra_set.EOF() == false)
                    {
                        extra_field_name = "sBrand_cd";
                        extra_field_col = MATRIX_BRAND_COL;
                    }
                }
                else if (MatrixHeader.chkUseManufacturer_fl)
                {
                    if (extra_set.CreateSnapshot("SELECT sManufacturer_cd FROM tblIVManufacturer ORDER BY sManufacturer_cd") == false)
                    {
                        return false;
                    }
                    else if (extra_set.EOF() == false)
                    {
                        extra_field_name = "sManufacturer_cd";
                        extra_field_col = MATRIX_MANUFACTURER_COL;
                    }
                }

                if (color_set.EOF() && size_set.EOF() && extra_set.EOF())
                {
                    FormShowMessage(User.Language.oMessage.NO_RECORDS_FOUND);
                    return false;
                }

                total_combo = 1;
                if (color_set.RecordCount() > 0)
                {
                    total_combo *= color_set.RecordCount();
                }
                if (size_set.RecordCount() > 0)
                {
                    total_combo *= size_set.RecordCount();
                }
                if (extra_set.RecordCount() > 0)
                {
                    total_combo *= extra_set.RecordCount();
                }

                moUtility.ResizeDim(ref matrix_data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, total_combo + 100);
                max_row = -1;

                if (!MatrixHeader.chkUseColor_fl && !MatrixHeader.chkUseSize_fl && extra_set.RecordCount() > 0)
                {

                    while (extra_set.EOF() == false)
                    {

                        extra_field_value = extra_set.sField(extra_field_name);

                        item_code = Header.txtPrimary_cd + msCodeSeparator + extra_field_value;
                        item_label = Header.txtLabel + " " + extra_field_value;
                        item_desc = Header.txtDescription + " " + extra_field_value;

                        max_row += 1;
                        matrix_data[MATRIX_ITEM_COL, max_row] = item_code;
                        matrix_data[MATRIX_LABEL_COL, max_row] = item_label;
                        matrix_data[MATRIX_DESC_COL, max_row] = item_desc;
                        matrix_data[extra_field_col, max_row] = extra_field_value;

                        extra_set.MoveNext();

                    }

                }
                else if (color_set.RecordCount() > 0 && size_set.RecordCount() > 0 && MatrixHeader.chkUseColor_fl && MatrixHeader.chkUseSize_fl)
                {

                    enter_extra_loop_fl = true;

                    while (extra_set.EOF() == false || enter_extra_loop_fl)
                    {

                        if (extra_set.EOF() == false)
                        {
                            extra_field_value = extra_set.sField(extra_field_name);
                        }
                        else
                        {
                            extra_field_value = "";
                        }

                        color_set.MoveFirst();

                        while (color_set.EOF() == false)
                        {

                            size_set.MoveFirst();

                            while (size_set.EOF() == false)
                            {

                                item_code = Header.txtPrimary_cd + msCodeSeparator + extra_field_value + color_set.sField("sColor_cd") + msCodeSeparator + size_set.sField("sSize_cd");
                                item_label = Header.txtLabel + " " + extra_field_value + color_set.sField("sColor_cd") + msCodeSeparator + size_set.sField("sSize_cd");
                                item_desc = Header.txtDescription + " " + extra_field_value + color_set.sField("sColor_cd") + msCodeSeparator + size_set.sField("sSize_cd");

                                max_row += 1;
                                matrix_data[MATRIX_ITEM_COL, max_row] = item_code;
                                matrix_data[MATRIX_LABEL_COL, max_row] = item_label;
                                matrix_data[MATRIX_DESC_COL, max_row] = item_desc;
                                matrix_data[MATRIX_COLOR_COL, max_row] = color_set.sField("sColor_cd");
                                matrix_data[MATRIX_SIZE_COL, max_row] = size_set.sField("sSize_cd");

                                if (extra_field_col > 0 && !extra_set.EOF())
                                {
                                    matrix_data[extra_field_col, max_row] = extra_field_value;
                                }

                                size_set.MoveNext();

                            }

                            color_set.MoveNext();

                        }

                        if (extra_set.EOF() == false)
                        {
                            extra_set.MoveNext();
                        }
                        if (extra_set.EOF())
                        {
                            enter_extra_loop_fl = false;
                        }

                    }

                }
                else if (color_set.RecordCount() > 0 && MatrixHeader.chkUseColor_fl)
                {

                    enter_extra_loop_fl = true;

                    while (extra_set.EOF() == false || enter_extra_loop_fl)
                    {

                        if (extra_set.EOF() == false)
                        {
                            extra_field_value = extra_set.sField(extra_field_name);
                        }
                        else
                        {
                            extra_field_value = "";
                        }

                        color_set.MoveFirst();

                        while (color_set.EOF() == false)
                        {

                            item_code = Header.txtPrimary_cd + msCodeSeparator + extra_field_value + color_set.sField("sColor_cd");
                            item_label = Header.txtLabel + " " + extra_field_value + color_set.sField("sColor_cd");
                            item_desc = Header.txtDescription + " " + extra_field_value + color_set.sField("sColor_cd");

                            max_row += 1;
                            matrix_data[MATRIX_ITEM_COL, max_row] = item_code;
                            matrix_data[MATRIX_LABEL_COL, max_row] = item_label;
                            matrix_data[MATRIX_DESC_COL, max_row] = item_desc;
                            matrix_data[MATRIX_COLOR_COL, max_row] = color_set.sField("sColor_cd");

                            if (extra_field_col > 0 && !extra_set.EOF())
                            {
                                matrix_data[extra_field_col, max_row] = extra_field_value;
                            }

                            color_set.MoveNext();

                        }

                        if (extra_set.EOF() == false)
                        {
                            extra_set.MoveNext();
                        }
                        if (extra_set.EOF())
                        {
                            enter_extra_loop_fl = false;
                        }

                    }

                }
                else if (size_set.RecordCount() > 0 && MatrixHeader.chkUseSize_fl)
                {

                    enter_extra_loop_fl = true;

                    while (extra_set.EOF() == false || enter_extra_loop_fl)
                    {

                        if (extra_set.EOF() == false)
                        {
                            extra_field_value = extra_set.sField(extra_field_name);
                        }
                        else
                        {
                            extra_field_value = "";
                        }

                        size_set.MoveFirst();

                        while (size_set.EOF() == false)
                        {

                            item_code = Header.txtPrimary_cd + msCodeSeparator + extra_field_value + size_set.sField("sSize_cd");
                            item_label = Header.txtLabel + " " + extra_field_value + size_set.sField("sSize_cd");
                            item_desc = Header.txtDescription + " " + extra_field_value + size_set.sField("sSize_cd");

                            max_row += 1;
                            matrix_data[MATRIX_ITEM_COL, max_row] = item_code;
                            matrix_data[MATRIX_LABEL_COL, max_row] = item_label;
                            matrix_data[MATRIX_DESC_COL, max_row] = item_desc;
                            matrix_data[MATRIX_SIZE_COL, max_row] = size_set.sField("sSize_cd");

                            if (extra_field_col > 0 && !extra_set.EOF())
                            {
                                matrix_data[extra_field_col, max_row] = extra_field_value;
                            }

                            size_set.MoveNext();

                        }

                        if (extra_set.EOF() == false)
                        {
                            extra_set.MoveNext();
                        }
                        if (extra_set.EOF())
                        {
                            enter_extra_loop_fl = false;
                        }

                    }

                }

                if (max_row < 0)
                {
                    FormShowMessage(User.Language.oMessage.NO_RECORDS_FOUND);
                    return false;
                }

                moUtility.ResizeDim(ref moMatrix.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, max_row);

                for (line_num = 0; line_num <= max_row; line_num++)
                {

                    if (line_num >= matrix_data.GetLength(1))
                    {
                        break;
                    }

                    moMatrix.Data[MATRIX_ITEM_COL, line_num] = matrix_data[MATRIX_ITEM_COL, line_num];

                    if (MatrixHeader.chkCopyLabel_fl)
                    {
                        moMatrix.Data[MATRIX_LABEL_COL, line_num] = matrix_data[MATRIX_LABEL_COL, line_num];
                    }
                    if (MatrixHeader.chkCopyDescription_fl)
                    {
                         moMatrix.Data[MATRIX_DESC_COL, line_num] = matrix_data[MATRIX_DESC_COL, line_num];
                    }
                    if (MatrixHeader.chkCopyUnitPrice_fl)
                    {
                        moMatrix.Data[MATRIX_UNIT_PRICE_COL, line_num] = Header.txtSellUnitPrice_amt;
                    }

                    if (MatrixHeader.chkUseSize_fl)
                    {
                        moMatrix.Data[MATRIX_SIZE_COL, line_num] = matrix_data[MATRIX_SIZE_COL, line_num];
                    }
                    if (MatrixHeader.chkUseColor_fl)
                    {
                        moMatrix.Data[MATRIX_COLOR_COL, line_num] = matrix_data[MATRIX_COLOR_COL, line_num];
                    }
                    if (extra_field_col >= 0)
                    {
                        moMatrix.Data[extra_field_col, line_num] = matrix_data[extra_field_col, line_num];
                    }

                    moMatrix.Data[MATRIX_SELECT_COL, line_num] = GlobalVar.goConstant.CHECKED_ON.ToString();
                }

                FormRecreateGrid(moMatrix);
                cmdSelectAll_Clicked();
                chkAll_fl = true;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (cmdGenerateMatrixCodes_Verified)");
            }

            return return_value;
        }

        private bool cmdSaveMatrix_Verified(ref int items_saved)
        {
            bool return_value = false;
            string item_code = "";
            int row_num = 0;

            try
            {
                items_saved = 0;

                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                // If data has changed, then check if it is ok to save.
                //
                if (FormCheck() == false)
                {
                    return return_value;
                }

                // chkInclude_fl is not sync'ed so that it needs to be set to Col_0, here.
                //
                foreach (var det in moMatrix.Grid)
                {
                    if (det.chkInclude_fl)
                    {
                        det.Col_0 = GlobalVar.goConstant.CHECKED_ON.ToString();
                    }
                    else
                    {
                        det.Col_0 = GlobalVar.goConstant.CHECKED_OFF.ToString();
                    }
                }
                FormRecreateDetail(moMatrix);

                for (row_num = 0; row_num < moMatrix.Data.GetLength(1); row_num++)
                {
                    item_code = modCommonUtility.CleanCode(moMatrix.Data[MATRIX_ITEM_COL, row_num]);

                    if (moUtility.ToInteger(moMatrix.Data[MATRIX_SELECT_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON && moUtility.IsNonEmpty(item_code))
                    {
                        if (moUtility.IsEmpty(moMatrix.Data[MATRIX_LABEL_COL, row_num]) || moUtility.IsEmpty(moMatrix.Data[MATRIX_DESC_COL, row_num]))
                        {
                            FormShowMessage(User.Language.oCaption.LABEL + "/" + User.Language.oCaption.DESCRIPTION + User.Language.oMessage.IS_REQUIRED);
                            return false;
                        }
                    }
                }

                for (row_num = 0; row_num < moMatrix.Data.GetLength(1); row_num++)
                {
                    item_code = modCommonUtility.CleanCode(moMatrix.Data[MATRIX_ITEM_COL, row_num]);

                    if (moUtility.ToInteger(moMatrix.Data[MATRIX_SELECT_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON && moUtility.IsNonEmpty(item_code) && item_code != Header.txtPrimary_cd)
                    {
                        if (moValidate.IsValidItemCode(item_code) == false)
                        {
                            if (moDatabase.TransactionBegin() == false)
                            {
                                FormShowMessage();
                                return false;
                            }
                            else if (FormSaveHeader(moValidate.oRecordset) == false)
                            {
                                FormShowMessage();
                                moDatabase.TransactionRollback();
                                return false;
                            }

                            moItem.sItem_cd = item_code;
                            moItem.sPrimary_cd = Header.txtPrimary_cd;
                            moItem.iItem_typ = GlobalVar.goIVConstant.REGULAR_ITEM_NUM; // Matrix items are inventory items
                            moItem.bNew_fl = true;

                            moItem.sLabel = moUtility.EvalQuote(moMatrix.Data[MATRIX_LABEL_COL, row_num]);
                            moItem.sDescription = moUtility.EvalQuote(moMatrix.Data[MATRIX_DESC_COL, row_num]);
                            moItem.mSellUnitPrice_amt = moMoney.ToNumMoney(moUtility.EvalQuote(moMatrix.Data[MATRIX_UNIT_PRICE_COL, row_num]));
                            moItem.sManufacturer_cd = moMatrix.Data[MATRIX_MANUFACTURER_COL, row_num];
                            moItem.sBrand_cd = moMatrix.Data[MATRIX_BRAND_COL, row_num];
                            moItem.sModel_cd = moMatrix.Data[MATRIX_MODEL_COL, row_num];
                            moItem.sStyle_cd = moMatrix.Data[MATRIX_STYLE_COL, row_num];
                            moItem.sSize_cd = moMatrix.Data[MATRIX_SIZE_COL, row_num];
                            moItem.sColor_cd = moMatrix.Data[MATRIX_COLOR_COL, row_num];

                            if (moItem.SaveItem() == false)
                            {
                                FormShowMessage();
                                moDatabase.TransactionRollback();
                                return false;
                            }
                            else if (moDatabase.TransactionCommit() == false)
                            {
                                FormShowMessage();
                                moDatabase.TransactionRollback();
                                return false;
                            }

                            items_saved += 1;
                        }

                        moValidate.oRecordset.Release();
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (cmdSaveMatrix_Verified)");
            }

            return return_value;
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool cmdAddMoreMatrixLines_Clicked()
        {
            FormPreEvent();

            if (moMatrix.AddMoreRows(10))
            {
                FormShowMessage();
                FormRecreateGrid(moMatrix);
                return false;
            }

            return FormPostEvent();
        }

        private bool btnMatrixSelect_Clicked(Models.clsSpreadsheet.clsGrid cur_item)
        {
            FormPreEvent();

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

        private string GetSearchCriteria()
        {
            string return_value = "";

            if (Header.cboItem_typ > 0)
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iItem_typ = " + Header.cboItem_typ.ToString();
            }
            if (moUtility.IsNonEmpty(Header.cboCommission_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sCommission_cd = '" + Header.cboCommission_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboGroup_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sGroup_cd = '" + Header.cboGroup_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboBox_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sBox_cd = '" + Header.cboBox_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboStyle_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sStyle_cd = '" + Header.cboStyle_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboSet_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sSet_cd = '" + Header.cboSet_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboSimilarity_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sSimilarity_cd = '" + Header.cboSimilarity_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboColor_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sColor_cd = '" + Header.cboColor_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboSize_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sSize_cd = '" + Header.cboSize_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboModel_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sModel_cd = '" + Header.cboModel_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboBrand_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sBrand_cd = '" + Header.cboBrand_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboManufacturer_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sManufacturer_cd = '" + Header.cboManufacturer_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboWarranty_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sWarranty_cd = '" + Header.cboWarranty_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboSale_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sSale_cd = '" + Header.cboSale_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboEvent_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sEvent_cd = '" + Header.cboEvent_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboSellUnit_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sSellUnit_cd = '" + Header.cboSellUnit_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboPurchaseUnit_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sPurchaseUnit_cd = '" + Header.cboPurchaseUnit_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboIVUnit_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sIVUnit_cd = '" + Header.cboIVUnit_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboClass_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sClass_cd = '" + Header.cboClass_cd + "'";
            }
            if (moUtility.IsNonEmpty(Header.cboTax_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sTax_cd = '" + Header.cboTax_cd + "'";
            }
            //If goUtility.ToInteger(optTrack_typ) > 0 Then
            //return_value = return_value & goUtility.IIf(return_value <> "", " AND ", "").ToString() & "iTrackSales_typ = " & optTrack_typ
            //End If
            if (Header.chkKit_fl && Header.optAssembly_typ > 0)
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iKit_typ = " + Header.optAssembly_typ.ToString();
            }
            if (moUtility.IsNonEmpty(Header.txtWebClass_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sWebClass_cd LIKE '" + moUtility.EvalQuote(Header.txtWebClass_cd) + "%'";
            }
            if (moUtility.IsNonEmpty(Header.txtPrimary_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sPrimary_cd LIKE '" + moUtility.EvalQuote(Header.txtPrimary_cd) + "%'";
            }
            if (moUtility.IsNonEmpty(Header.txtDescription))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sDescription LIKE '" + moUtility.EvalQuote(Header.txtDescription) + "%'";
            }
            if (moUtility.IsNonEmpty(Header.txtLabel))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sLabel LIKE '" + moUtility.EvalQuote(Header.txtLabel) + "%'";
            }
            if (moUtility.IsNonEmpty(Header.txtVendor_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sPreferredVendor_cd = '" + moUtility.EvalQuote(Header.txtVendor_cd) + "'";
            }
            if (moUtility.IsNonEmpty(Header.txtManufacturerItem_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sManufacturerItem_cd = '" + moUtility.EvalQuote(Header.txtManufacturerItem_cd) + "'";
            }
            if (moUtility.IsNonEmpty(Header.txtUPC_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sUPC_cd LIKE '" + moUtility.EvalQuote(Header.txtUPC_cd) + "%'";
            }
            if (moUtility.IsNonEmpty(Header.txtSKU_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sSKU_cd LIKE '" + moUtility.EvalQuote(Header.txtSKU_cd) + "%'";
            }
            if (moUtility.IsNonEmpty(Header.txtAltItem_cd))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sAltItem_cd LIKE '" + moUtility.EvalQuote(Header.txtAltItem_cd) + "%'";
            }
            if (moMoney.ToNumMoney(Header.txtSalePrice_amt) != 0)
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "mSalePrice_amt = " + moMoney.ToNumMoney(Header.txtSalePrice_amt).ToString();
            }
            if (moMoney.ToNumMoney(Header.txtSellUnitPrice_amt) != 0)
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "mSellUnitPrice_amt = " + moMoney.ToNumMoney(Header.txtSellUnitPrice_amt).ToString();
            }
            if (moMoney.ToNumMoney(Header.txtStdCost_amt) != 0)
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "mStdCost_amt = " + moMoney.ToNumMoney(Header.txtStdCost_amt).ToString();
            }
            if (moMoney.ToNumMoney(Header.txtFreight_amt) != 0)
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "mFreight_amt = " + moMoney.ToNumMoney(Header.txtFreight_amt).ToString();
            }

            if (moMoney.ToNumMoney(Header.txtLength) != 0)
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "fLength = " + moMoney.ToNumMoney(Header.txtLength).ToString();
            }
            if (moMoney.ToNumMoney(Header.txtWidth) != 0)
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "fWidth = " + moMoney.ToNumMoney(Header.txtWidth).ToString();
            }
            if (moMoney.ToNumMoney(Header.txtHeight) != 0)
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "fHeight = " + moMoney.ToNumMoney(Header.txtHeight).ToString();
            }
            if (moMoney.ToNumMoney(Header.txtWeight) != 0)
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "fWeight = " + moMoney.ToNumMoney(Header.txtWeight).ToString();
            }


            if (Header.chkTaxable_fl)
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iTaxable_fl=1";
            }
            if (moUtility.IsNonEmpty(Header.txtSortKey2))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sSortKey2 LIKE '" + moUtility.EvalQuote(Header.txtSortKey2) + "%'";
            }
            if (moUtility.IsNonEmpty(Header.txtSortKey1))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sSortKey1 LIKE '" + moUtility.EvalQuote(Header.txtSortKey1) + "%'";
            }

            if (Header.cboStatus_typ > 0)
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iStatus_typ = " + Header.cboStatus_typ.ToString();
            }

            if (Header.chkConsignment_typ)
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iConsignment_typ > 0";
            }

            // CUSTOM FIELDS
            //
            if (moUtility.IsNonEmpty(moCustomFields.GetSearchList(moDatabase)))
            {
                return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + moCustomFields.GetSearchList(moDatabase);
            }

            return return_value;

        }
        private bool ShowQuantity()
        {
            bool return_value = false;
            string[] field_list = new string[] { "sLocation_cd", "fAvailable_qty", "fOnHand_qty", "fOnOrder_qty", "(fCommToOrder_qty + fCommToInvoice_qty + fCommToDM_qty + fCommToTransfer_qty) AS fCommitted_qty", "fInRepair_qty"};
            string where_clause = "";

            try
            {
                where_clause = " sItem_cd = '" + Header.txtKey_id + "'";

                if (moQuantity.Show(moDatabase, moPage, "tblIVItemQty", field_list, where_clause, "sLocation_cd, sItem_cd") == false)
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (ShowQuantity)");
            }

            return return_value;
        }

        public bool ShowSmallPicture()
        {
            bool return_value = false;
            string file_name = null;

            try
            {

                //if (moUtility.IsNonEmpty(Header.txtKey_id))
                //{
                //    file_name = moUtility.STrim(Header.txtSmallPictureFile_nm);
                //    if ((moUtility.IsNonEmpty(file_name)) && Header.chkShowPicture)
                //    {
                //        if (!GlobalVar.goFile.FileExists(moDatabase.uDirectory.sWebInventoryImageDirectory_nm + "\\" + file_name))
                //        {
                //            FormShowMessage("File does not exist: " + file_name);
                //            imgSmallPicture.ImageUrl = "";
                //            return false;
                //        }
                //        file_name = GlobalVar.goFile.GetVertualPath(moDatabase.uDirectory.sWebInventoryImageDirectory_nm) + "\\" + file_name;
                //        imgSmallPicture.ImageUrl = file_name;
                //        imgSmallPicture.Visible = true;
                //    }
                //    else
                //    {
                //        imgSmallPicture.Visible = false;
                //    }
                //}
                //else
                //{
                //    imgSmallPicture.Visible = false;
                //}

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (ShowSmallPicture)");
            }

            return return_value;
        }

        private void HandleFileSelected(IFileListEntry[] files)
        {
            try
            {
                // Name: FileToUpload.Name
                // Size in bytes: FileToUpload.Size
                // Last modified date: FileToUpload.LastModified.ToShortDateString()
                // Content type (not always supplied by the browser): FileToUpload.Type
                //
                FileToUpload = files.FirstOrDefault();

                if (FileToUpload == null)
                {
                    return;
                }

                lblFileToUpload = FileToUpload.Name;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (HandleFileSelected)");
            }

        }

        async Task cmdUploadFile_Clicked()
        {
            var ms = new System.IO.MemoryStream();
            string file_name = "";

            if (FileToUpload == null || moUtility.IsEmpty(lblFileToUpload))
            {
                FormShowMessage("Select a file to upload using 'Browse/Choose File' button.");
                return;
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            try
            {
                if (FormOpenDatabase() == false)            // Necessary to get moDatabase.uDirectory.sEtcDirectory_nm
                {
                    return;
                }

                await FileToUpload.Data.CopyToAsync(ms);

                Header.txtSmallPictureFile_nm = lblFileToUpload;
                file_name = moDatabase.uDirectory.sWebInventoryImageDirectory_nm + "\\" + Header.txtSmallPictureFile_nm;
                System.IO.File.WriteAllBytes(file_name, ms.ToArray());

                // Display the image.
                //
                Header.chkShowPicture_fl = true;
                msItemImageFile_nm = modGeneralUtility.GetVirtualFileName(file_name, true);

                FormShowMessage(User.Language.oCaption.UPLOAD_FILE + " " + User.Language.oString.STR_DONE, false);

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (cmdUploadFile_Clicked)");
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);
        }

        public bool GetItemMatrixOptions()
        {
            bool return_value = false;
            string sql_str = "";
            string app_name = modConstant.ITEM_MATRIX + Header.txtKey_id;

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                if (moUtility.IsEmpty(app_name))
                {
                    return true;
                }

                sql_str = "SELECT * ";
                sql_str += " FROM  tblGOSecurityOption";
                sql_str += " WHERE sApp_nm = '" + app_name + "'";
                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                while (cur_set.EOF() == false)
                {
                    if (moUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.ITEM_MATRIX_COPY_LABEL)
                    {
                        MatrixHeader.chkCopyLabel_fl = (cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON);
                    }
                    else if (moUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.ITEM_MATRIX_COPY_DESCRIPTION)
                    {
                        MatrixHeader.chkCopyDescription_fl = (cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON);
                    }
                    else if (moUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.ITEM_MATRIX_COPY_UNIT_PRICE)
                    {
                        MatrixHeader.chkCopyUnitPrice_fl = (cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON);
                    }
                    else if (moUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.ITEM_MATRIX_USE_SIZE)
                    {
                        MatrixHeader.chkUseSize_fl = (cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON);
                    }
                    else if (moUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.ITEM_MATRIX_USE_COLOR)
                    {
                        MatrixHeader.chkUseColor_fl = (cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON);
                    }
                    else if (moUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.ITEM_MATRIX_USE_STYLE)
                    {
                        MatrixHeader.chkUseStyle_fl = (cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON);
                    }
                    else if (moUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.ITEM_MATRIX_USE_MODEL)
                    {
                        MatrixHeader.chkUseModel_fl = (cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON);
                    }
                    else if (moUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.ITEM_MATRIX_USE_BRAND)
                    {
                        MatrixHeader.chkUseBrand_fl = (cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON);
                    }
                    else if (moUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.ITEM_MATRIX_USE_MANUFACTURER)
                    {
                        MatrixHeader.chkUseManufacturer_fl = (cur_set.iField("iOptionValue") == GlobalVar.goConstant.CHECKED_ON);
                    }
                    else if (moUtility.STrim(cur_set.sField("sOption_nm")) == modConstant.ITEM_MATRIX_CODE_SEPARATOR)
                    {
                        MatrixHeader.cboCodeSeparator = cur_set.sField("sOptionValue");
                    }

                    cur_set.MoveNext();
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (GetItemMatrixOptions)");
            }

            return return_value;
        }

        private bool SaveItemMatrixOptions()
        {
            bool return_value = false;
            string sql_str = "";
            string app_name = modConstant.ITEM_MATRIX + Header.txtKey_id;

            try
            {
                if (moUtility.IsEmpty(app_name))
                {
                    return false;
                }

                sql_str = "DELETE FROM  tblGOSecurityOption";
                sql_str += " WHERE sApp_nm = '" + app_name + "'";
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                sql_str = "INSERT INTO tblGOSecurityOption(";
                sql_str += "sApp_nm";
                sql_str += ",sOption_nm";
                sql_str += ",iOptionValue";
                sql_str += ",sOptionValue";
                sql_str += ") VALUES (";
                sql_str += "'" + app_name + "'";
                sql_str += ",'" + modConstant.ITEM_MATRIX_COPY_LABEL + "'";
                sql_str += "," + (MatrixHeader.chkCopyLabel_fl? 1 : 0).ToString();
                sql_str += ",''";
                sql_str += ")";
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                sql_str = "INSERT INTO tblGOSecurityOption(";
                sql_str += "sApp_nm";
                sql_str += ",sOption_nm";
                sql_str += ",iOptionValue";
                sql_str += ",sOptionValue";
                sql_str += ") VALUES (";
                sql_str += "'" + app_name + "'";
                sql_str += ",'" + modConstant.ITEM_MATRIX_COPY_DESCRIPTION + "'";
                sql_str += "," + (MatrixHeader.chkCopyDescription_fl ? 1 : 0).ToString();
                sql_str += ",''";
                sql_str += ")";
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                sql_str = "INSERT INTO tblGOSecurityOption(";
                sql_str += "sApp_nm";
                sql_str += ",sOption_nm";
                sql_str += ",iOptionValue";
                sql_str += ",sOptionValue";
                sql_str += ") VALUES (";
                sql_str += "'" + app_name + "'";
                sql_str += ",'" + modConstant.ITEM_MATRIX_COPY_UNIT_PRICE + "'";
                sql_str += "," + (MatrixHeader.chkCopyUnitPrice_fl ? 1 : 0).ToString();
                sql_str += ",''";
                sql_str += ")";
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                sql_str = "INSERT INTO tblGOSecurityOption(";
                sql_str += "sApp_nm";
                sql_str += ",sOption_nm";
                sql_str += ",iOptionValue";
                sql_str += ",sOptionValue";
                sql_str += ") VALUES (";
                sql_str += "'" + app_name + "'";
                sql_str += ",'" + modConstant.ITEM_MATRIX_USE_SIZE + "'";
                sql_str += "," + (MatrixHeader.chkUseSize_fl ? 1 : 0).ToString();
                sql_str += ",''";
                sql_str += ")";
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                sql_str = "INSERT INTO tblGOSecurityOption(";
                sql_str += "sApp_nm";
                sql_str += ",sOption_nm";
                sql_str += ",iOptionValue";
                sql_str += ",sOptionValue";
                sql_str += ") VALUES (";
                sql_str += "'" + app_name + "'";
                sql_str += ",'" + modConstant.ITEM_MATRIX_USE_COLOR + "'";
                sql_str += "," + (MatrixHeader.chkUseColor_fl ? 1 : 0).ToString();
                sql_str += ",''";
                sql_str += ")";
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                sql_str = "INSERT INTO tblGOSecurityOption(";
                sql_str += "sApp_nm";
                sql_str += ",sOption_nm";
                sql_str += ",iOptionValue";
                sql_str += ",sOptionValue";
                sql_str += ") VALUES (";
                sql_str += "'" + app_name + "'";
                sql_str += ",'" + modConstant.ITEM_MATRIX_USE_STYLE + "'";
                sql_str += "," + (MatrixHeader.chkUseStyle_fl ? 1 : 0).ToString();
                sql_str += ",''";
                sql_str += ")";
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                sql_str = "INSERT INTO tblGOSecurityOption(";
                sql_str += "sApp_nm";
                sql_str += ",sOption_nm";
                sql_str += ",iOptionValue";
                sql_str += ",sOptionValue";
                sql_str += ") VALUES (";
                sql_str += "'" + app_name + "'";
                sql_str += ",'" + modConstant.ITEM_MATRIX_USE_MODEL + "'";
                sql_str += "," + (MatrixHeader.chkUseModel_fl ? 1 : 0).ToString();
                sql_str += ",''";
                sql_str += ")";
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                sql_str = "INSERT INTO tblGOSecurityOption(";
                sql_str += "sApp_nm";
                sql_str += ",sOption_nm";
                sql_str += ",iOptionValue";
                sql_str += ",sOptionValue";
                sql_str += ") VALUES (";
                sql_str += "'" + app_name + "'";
                sql_str += ",'" + modConstant.ITEM_MATRIX_USE_BRAND + "'";
                sql_str += "," + (MatrixHeader.chkUseBrand_fl ? 1 : 0).ToString();
                sql_str += ",''";
                sql_str += ")";
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                sql_str = "INSERT INTO tblGOSecurityOption(";
                sql_str += "sApp_nm";
                sql_str += ",sOption_nm";
                sql_str += ",iOptionValue";
                sql_str += ",sOptionValue";
                sql_str += ") VALUES (";
                sql_str += "'" + app_name + "'";
                sql_str += ",'" + modConstant.ITEM_MATRIX_USE_MANUFACTURER + "'";
                sql_str += "," + (MatrixHeader.chkUseManufacturer_fl ? 1 : 0).ToString();
                sql_str += ",''";
                sql_str += ")";
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                sql_str = "INSERT INTO tblGOSecurityOption(";
                sql_str += "sApp_nm";
                sql_str += ",sOption_nm";
                sql_str += ",iOptionValue";
                sql_str += ",sOptionValue";
                sql_str += ") VALUES (";
                sql_str += "'" + app_name + "'";
                sql_str += ",'" + modConstant.ITEM_MATRIX_CODE_SEPARATOR + "'";
                sql_str += ",0"; 
                sql_str += ",'" + MatrixHeader.cboCodeSeparator + "'";
                sql_str += ")";
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SaveItemMatrixOptions)");
            }

            return return_value;
        }

        private bool CreateSearchHTML()
        {
            bool return_value = false;
            string html_file = "";
            string[] header_list = null;

            clsSpreadsheet o_search = new clsSpreadsheet();

            try
            {
                if (ShowSearchPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moSearch, ref o_search, ref header_list) == false)      // Listing & Search both share PrepListingDownload()
                {
                    return false;
                }

                html_file = moInquiry.CreateHTML(ref moDatabase, moPage.Title, o_search, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(html_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(html_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateSearchHTML)");
            }

            return return_value;
        }


        private bool CreateSearchExcel()
        {
            bool return_value = false;
            string csv_file = "";
            string[] header_list = null;

            clsSpreadsheet o_search = new clsSpreadsheet();

            try
            {
                if (ShowSearchPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moSearch, ref o_search, ref header_list) == false)
                {
                    return false;
                }

                csv_file = moInquiry.CreateCSV(ref moDatabase, moPage.Title, o_search, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(csv_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(csv_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateSearchExcel)");
            }

            return return_value;
        }

        private bool PrepListingDownload(clsEntitySearch o_listing, ref clsSpreadsheet o_spread, ref string[] header_list)
        {
            bool return_value = false;
            int row_num = 0;
            int i = 0;

            try
            {
                moUtility.ResizeDim(ref o_spread.Data, 7 + moCustomization.iTotalFields, o_listing.Grid.Count - 1);

                foreach (var lst in o_listing.Grid)
                {
                    i = 0;
                    miUDF_num = 0;

                    o_spread.Data[i++, row_num] = lst.Code;
                    o_spread.Data[i++, row_num] = lst.Description;
                    o_spread.Data[i++, row_num] = lst.ExtraCol_1;
                    o_spread.Data[i++, row_num] = lst.ExtraCol_2;
                    o_spread.Data[i++, row_num] = lst.ExtraCol_3;
                    o_spread.Data[i++, row_num] = lst.ExtraCol_4;
                    o_spread.Data[i++, row_num] = lst.ExtraCol_5;
                    o_spread.Data[i++, row_num] = lst.ExtraCol_6;

                    if (moCustomization.iTotalFields > 0)
                    {
                        foreach (var udf in moCustomFields.Grid)
                        {
                            if (moCustomization.iTotalFields > miUDF_num)
                            {
                                o_spread.Data[i++, row_num] = moSearch.CustomFields[miUDF_num++, lst.Row_num];
                            }
                        }
                    }

                    row_num += 1;
                }

                moUtility.ResizeDim(ref header_list, i - 1);
                i = 0;

                header_list[i++] = User.Language.oCaption.CODE;
                header_list[i++] = User.Language.oCaption.DESCRIPTION;
                header_list[i++] = User.Language.oCaption.CLASS;
                header_list[i++] = User.Language.oCaption.GROUP;
                header_list[i++] = User.Language.oCaption.COMMISSION;
                header_list[i++] = User.Language.oCaption.PRIMARY_ITEM;
                header_list[i++] = User.Language.oCaption.SELL_UNIT_CODE;
                header_list[i++] = User.Language.oCaption.UNIT_PRICE;

                if (moCustomization.iTotalFields > 0)
                {
                    foreach (var udf in moCustomFields.Grid)
                    {
                        header_list[i++] = udf.Caption;
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PrepListingDownload)");
            }

            return return_value;
        }


    }
}
