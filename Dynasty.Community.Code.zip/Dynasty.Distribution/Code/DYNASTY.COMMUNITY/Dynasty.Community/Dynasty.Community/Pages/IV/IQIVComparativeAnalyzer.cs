﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Collections;

using Dynasty.Database;
using Dynasty.ASP.Models;

namespace Dynasty.ASP.Pages.IV
{
    public partial class IQIVComparativeAnalyzer
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<Invoice> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private clsPage moPage;                                                               // Keeps the current page/record info & status
        private clsView moView;                                                               // View/Tab info
        private clsZoom moZoom;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    if (moPage.bNew_fl)
                    {
                        moPage.bReadOnly_fl = false;
                    }
                    else
                    {
                        moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                    }
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        private bool ShowNavigation
        {
            get
            {
                return true;
            }
        }

        private bool ShowPrinter
        {
            get
            {
                return (moPage.iCurrentView == VIEW_SUMMARY || moPage.iCurrentView == VIEW_DETAIL || moPage.iCurrentView == VIEW_BREAKDOWN);
            }
        }


        private bool ComparisonDisabled
        {
            get { return (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_YEARLY || Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_QTD || Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_YTD); }
        }


        private bool Visualize
        {
            get { return (moPage.iCurrentView == VIEW_CHART); }
        }

        private bool EnableChart
        {
            get { return (moUtility.IsNonEmpty(msSummaryCaption) && SelectedList.Count <= 1); }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // These are instantiated in FormInit().
        private clsGeneral moGeneral;
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsMoney moMoney;
        private clsSession moSession;
        private clsSpreadsheet moSummary;
        private clsInquiry moInquiry;
        private clsPagination moSummaryPagination;

        // Pagination
        //
        private List<clsCombobox> PageLoadOptionList = new List<clsCombobox>();

        private List<clsCombobox> AvailableList = new List<clsCombobox>();
        private List<clsCombobox> SelectedList = new List<clsCombobox>();

        private List<clsCombobox> QueryTypeList = new List<clsCombobox>();
        private List<clsCombobox> ItemTypeList = new List<clsCombobox>();
        private List<clsCombobox> GroupCodeList = new List<clsCombobox>();
        private List<clsCombobox> LocationCodeList = new List<clsCombobox>();
        private List<clsCombobox> ClassCodeList = new List<clsCombobox>();

        private List<clsCombobox> InterestGroupCodeList = new List<clsCombobox>();

        private List<clsCombobox> EventCodeList = new List<clsCombobox>();
        private List<clsCombobox> SaleCodeList = new List<clsCombobox>();
        private List<clsCombobox> ManufacturerCodeList = new List<clsCombobox>();

        private List<clsCombobox> BrandCodeList = new List<clsCombobox>();

        private List<clsCombobox> ModelCodeList = new List<clsCombobox>();
        private List<clsCombobox> StyleCodeList = new List<clsCombobox>();
        private List<clsCombobox> ColorCodeList = new List<clsCombobox>();
        private List<clsCombobox> SizeCodeList = new List<clsCombobox>();

        private List<clsCombobox> ComparisonPeriodList = new List<clsCombobox>();
        private List<clsCombobox> PeriodList = new List<clsCombobox>();


        private string msPeriodsCaption = "";

        private string msSummaryCaption = "";

        private string msSelectClause = "";                             // Item list in SELET clause
        private string msWhereClause = "";                              // combination of FROM and WHERE clauses
        private string msGroupingClause = "";                              // Item list in GROP BY clause

        private string[] msGroupingItems = null;

        private int miSummaryTotalColumns = 0;

        private int VIEW_CRITERIA
        {
            get { return moView.MAIN_PAGE_NUM;  }
        }
        private int VIEW_SUMMARY
        {
            get { return moView.SECOND_PAGE_NUM; }
        }
        private int VIEW_DETAIL
        {
            get { return moView.THIRD_PAGE_NUM; }
        }
        private int VIEW_BREAKDOWN
        {
            get { return moView.FOURTH_PAGE_NUM; }
        }
        private int VIEW_CHART
        {
            get { return moView.CHART_PAGE_NUM; }
        }

        private const int COMPARISON_TYPE_CONSECUTIVE = 1;
        private const int COMPARISON_TYPE_SAME_PERIOD = 2;

        private const string STR_ITEM = "Item";
        private const string STR_INTEREST_GROUP = "Interest Group";
        private const string STR_LOCATION = "Location";
        private const string STR_GROUP = "Group";
        private const string STR_CLASS = "Class";
        private const string STR_PROMO_SALE = "Promo Sale";
        private const string STR_REGULAR_SALE = "Regular Sale";

        private const int PERIOD_COL = 0;

        private string msManufacturerCaption = "";
        private string msBrandCaption = "";
        private string msModelCaption = "";
        private string msStyleCaption = "";
        private string msSizeCaption = "";
        private string msColorCaption = "";

        private bool mbEntityIncluded_fl = false;
        
        private bool chkAll_fl = false;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader
        {
            // Listing of UI items on the header
            //
            public string cboQuery_typ = "";
            public string cboItem_typ = "";
            public string cboGroup_cd = "";
            public string cboLocation_cd = "";
            public string cboClass_cd = "";
            public string cboInterestGroup_cd = "";

            public string cboEvent_cd = "";
            public string cboSale_cd = "";
            public string cboManufacturer_cd = "";
            public string cboBrand_cd = "";
            public string cboModel_cd = "";
            public string cboStyle_cd = "";
            public string cboColor_cd = "";
            public string cboSize_cd = "";

            public string cboPeriodFrom_dt = "";
            public string cboComparisonPeriods = "";

            public string txtItem_cd = "";

            public string cboAvailable = "";
            public string cboSelected = "";

            public int optPeriod_typ = clsInquiry.PERIOD_TYPE_MONTHLY;
            public int optComparison_typ = COMPARISON_TYPE_CONSECUTIVE;
            public int optQueryBy = clsInquiry.QUERY_BY_QTY;

            public bool chkConsignmentOnly_fl = false;
            public string txtVendor_cd = "";                    // Preferred vendor in item master

            // For pagination
            //
            public string lblSummaryRecordsFound = "";
            public string lblDetailRecordsFound = "";
            public string cboMaxLinesPerPage = "";

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag
            {
                public string cboQuery_typ = "";
                public string cboItem_typ = "";
                public string cboGroup_cd = "";
                public string cboLocation_cd = "";
                public string cboClass_cd = "";
                public string cboInterestGroup_cd = "";
                public string txtVendor_cd = "";                    // Preferred vendor in item master

                public string txtItem_cd = "";

                public string cboAvailable = "";
                public string cboSelected = "";

                public int optPeriod_typ = clsInquiry.PERIOD_TYPE_MONTHLY;
                public int optComparison_typ = COMPARISON_TYPE_CONSECUTIVE;
                public int optQueryBy = clsInquiry.QUERY_BY_QTY;

            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()
            {
                Tag.cboQuery_typ = cboQuery_typ;
                Tag.cboItem_typ = cboItem_typ;
                Tag.cboGroup_cd = cboGroup_cd;
                Tag.cboClass_cd = cboClass_cd;
                Tag.cboLocation_cd = cboLocation_cd;
                Tag.cboInterestGroup_cd = cboInterestGroup_cd;

                Tag.txtItem_cd = txtItem_cd;
                Tag.txtVendor_cd = txtVendor_cd;

                Tag.optPeriod_typ = optPeriod_typ;
                Tag.optComparison_typ = optComparison_typ;
                Tag.optQueryBy = optQueryBy;
            }
        }
        private clsHeader Header = new clsHeader();

        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            moSession.RemoveSession(moDatabase);        // Delete the session file.

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            // If user uses date-picker, we need to change the date field.
            //
            if (User.bUseDatePicker_fl && moUtility.SLeft(field_name, 3) == "msk" && moUtility.SRight(field_name, 3) == "_dt")
            {
                field_name = moUtility.SReplace(field_name, "msk", "dt");
            }
            JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        
        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            FormSyncDates(User.bUseDatePicker_fl);
            
            if (FormCheckSecurity() == false)
            {
                return false;
            }

            if (moUtility.IsEmpty(Header.cboQuery_typ))
            {
                FormShowMessage(User.Language.oMessage.PLEASE_ENTER + User.Language.oCaption.QUERY_TYPE);
                FormSetFocus("cboQuery_typ");
                return false;
            }
            if (moUtility.IsEmpty(Header.cboPeriodFrom_dt))
            {
                FormShowMessage(User.Language.oMessage.PLEASE_ENTER + User.Language.oCaption.PERIOD_FROM);
                FormSetFocus("cboPeriodFrom_dt");
                return false;
            }
            if ( moUtility.ToInteger(Header.cboComparisonPeriods) == 0)
            {
                FormShowMessage(User.Language.oMessage.PLEASE_ENTER + User.Language.oCaption.FOR_THE_LAST);
                FormSetFocus("cboComparisonPeriods");
                return false;
            }

            return true;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearDetail();
            FormClearExtra();

            return true;
        }

        private bool FormClearDetail()                                                             // Clear the detail.
        {
            
            moSummary.Clear();
            miSummaryTotalColumns = 1;
            moUtility.ResizeDim(ref moSummary.FieldName, miSummaryTotalColumns - 1);

            moUtility.ResizeDim(ref moSummary.Caption, miSummaryTotalColumns - 1);

            ClearBreakdown();

            return true;
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {
           
            return true;
        }

        private bool FormClearMessage()
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            moPage.bInDialog_fl = true;         // Meaning a dialog started

            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    moPage.bInDialog_fl = false;            // Meaning a dialog is enidng with Cancel button
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }

                Modal.Release();                                                                   // Release this call and proceed.
            }

            moPage.bInDialog_fl = false;            // Meaning a dialog is enidng with Cancel button
            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new clsPage();
            moView = new clsView();
            moZoom = new clsZoom();
            moSummary = new clsSpreadsheet();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moMoney = new clsMoney(ref moDatabase);
            moSession = new clsSession();
            moInquiry = new clsInquiry();
            moSummaryPagination = new Models.clsPagination();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.IVMENU_NAME;
            moPage.Title = User.Language.oCaption.COMPARATIVE + " " + User.Language.oCaption.INVENTORY_ANALYZER;
            moPage.iScreen_typ = GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;

            // sRestrictionClause will need to change as some conditions change, which is done in ResetRestrictionClause().
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormInitHeader();
            FormInitDetail();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitDetail()                                                              // Initialize the page at loading.  Only once.
        {
            // Detail table name.
            //
            moPage.sDetailTable_nm = "";

            FormClearDetail();

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = "";
            moPage.sKeyField_nm = "";

            return true;
        }

        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {

            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            // FormSave() & FormCheck() use the plain textbox whose name starts with "msk"
            // dt* variables are only to interact with UI.  Internally, msk* fields are used.
            //
            FormSyncDates(User.bUseDatePicker_fl);


            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback

            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;
            ArrayList item_list = new ArrayList();

            try
            {
                if (FormReceiveValues() == false)                    // All pages that use session value need to capture it here before FormOpenDatabase()
                {
                    return false;
                }
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                msManufacturerCaption = moDatabase.uSecurity.sManufacturerCaption;
                msBrandCaption = moDatabase.uSecurity.sBrandCaption;
                msModelCaption = moDatabase.uSecurity.sModelCaption;
                msStyleCaption = moDatabase.uSecurity.sStyleCaption;
                msSizeCaption = moDatabase.uSecurity.sSizeCaption;
                msColorCaption = moDatabase.uSecurity.sColorCaption;

                // Pagination
                //
                modLoadUtility.LoadMaxPageOptions(ref PageLoadOptionList);
                Header.cboMaxLinesPerPage = "40";

                modLoadUtility.LoadInventoryItemType(ref moDatabase, ref ItemTypeList);
                modLoadUtility.LoadItemGroupCode(ref moDatabase, ref GroupCodeList);
                modLoadUtility.LoadItemClassCode(ref moDatabase, ref ClassCodeList);
                modLoadUtility.LoadLocationCode(ref moDatabase, ref LocationCodeList);
                modLoadUtility.LoadIVInterestGroup(ref moDatabase, ref InterestGroupCodeList);

                modLoadUtility.LoadEventCode(ref moDatabase, ref EventCodeList);
                modLoadUtility.LoadSaleCode(ref moDatabase, ref SaleCodeList);
                modLoadUtility.LoadManufacturer(ref moDatabase, ref ManufacturerCodeList);
                modLoadUtility.LoadBrand(ref moDatabase, ref BrandCodeList);
                modLoadUtility.LoadModel(ref moDatabase, ref ModelCodeList);
                modLoadUtility.LoadStyle(ref moDatabase, ref StyleCodeList);
                modLoadUtility.LoadColor(ref moDatabase, ref ColorCodeList);
                modLoadUtility.LoadSize(ref moDatabase, ref SizeCodeList);

                if (moDatabase.iCurBusiness_typ == GlobalVar.goConstant.SERVICE_BUSINESS_NUM)
                {
                    Header.cboItem_typ = GlobalVar.goIVConstant.SERVICE_ITEM_NUM.ToString();
                }
                else
                {
                    Header.cboItem_typ = GlobalVar.goIVConstant.REGULAR_ITEM_NUM.ToString();
                }

                modLoadUtility.LoadConsecutiveNumbers(ref moDatabase, ref ComparisonPeriodList, 24);

                item_list.Clear();
                item_list.Add(new clsComboBoxItem(clsInquiry.REPORT_NET_SALES, clsInquiry.REPORT_NET_SALES));
                item_list.Add(new clsComboBoxItem(clsInquiry.REPORT_SALES, clsInquiry.REPORT_SALES));
                item_list.Add(new clsComboBoxItem(clsInquiry.REPORT_SALES_RETURN, clsInquiry.REPORT_SALES_RETURN));
                item_list.Add(new clsComboBoxItem("-", "-"));
                item_list.Add(new clsComboBoxItem(clsInquiry.REPORT_NET_PURCHASE, clsInquiry.REPORT_NET_PURCHASE));
                item_list.Add(new clsComboBoxItem(clsInquiry.REPORT_PURCHASE, clsInquiry.REPORT_PURCHASE));
                item_list.Add(new clsComboBoxItem(clsInquiry.REPORT_PURCHASE_RETURN, clsInquiry.REPORT_PURCHASE_RETURN));
                item_list.Add(new clsComboBoxItem("-", "-"));
                item_list.Add(new clsComboBoxItem(clsInquiry.REPORT_ASJUSTMENT, clsInquiry.REPORT_ASJUSTMENT));
                item_list.Add(new clsComboBoxItem(clsInquiry.REPORT_SPOILAGE, clsInquiry.REPORT_SPOILAGE));
                item_list.Add(new clsComboBoxItem("-", "-"));
                item_list.Add(new clsComboBoxItem(clsInquiry.REPORT_NET_TRANSFER, clsInquiry.REPORT_NET_TRANSFER));
                item_list.Add(new clsComboBoxItem(clsInquiry.REPORT_TRANSFER_IN, clsInquiry.REPORT_TRANSFER_IN));
                item_list.Add(new clsComboBoxItem(clsInquiry.REPORT_TRANSFER_OUT, clsInquiry.REPORT_TRANSFER_OUT));
                modWebLoadUtility.LoadComboBox(ref QueryTypeList, item_list);
                Header.cboQuery_typ = clsInquiry.REPORT_NET_SALES;
                cboQuery_typ_Clicked();

                item_list.Clear();
                item_list.Add(new clsComboBoxItem(STR_ITEM, STR_ITEM));
                // item_list.Add(new clsComboBoxItem(STR_INTEREST_GROUP, STR_INTEREST_GROUP));     04/19/2021    Creates JOIN issue
                item_list.Add(new clsComboBoxItem(STR_LOCATION, STR_LOCATION));
                item_list.Add(new clsComboBoxItem(STR_GROUP, STR_GROUP));
                item_list.Add(new clsComboBoxItem(STR_CLASS, STR_CLASS));
                item_list.Add(new clsComboBoxItem(STR_PROMO_SALE, STR_PROMO_SALE));
                item_list.Add(new clsComboBoxItem(STR_REGULAR_SALE, STR_REGULAR_SALE));
                item_list.Add(new clsComboBoxItem(msManufacturerCaption, msManufacturerCaption));
                item_list.Add(new clsComboBoxItem(msBrandCaption, msBrandCaption));
                item_list.Add(new clsComboBoxItem(msModelCaption, msModelCaption));
                item_list.Add(new clsComboBoxItem(msStyleCaption, msStyleCaption));
                item_list.Add(new clsComboBoxItem(msColorCaption, msColorCaption));
                item_list.Add(new clsComboBoxItem(msSizeCaption, msSizeCaption));
                modWebLoadUtility.LoadComboBox(ref AvailableList, item_list);

                optPeriod_typ_Clicked(clsInquiry.PERIOD_TYPE_MONTHLY);

                // Initialize Tab captions.
                //
                msSummaryCaption = "";

                User.bConnected_fl = true;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormReArrangeDetail()                                                         // Arrange(show/hide, enable/disable) the columns in the detail(grid)
        {
            return true;
        }

        private bool FormReArrangeHeader()                                                         //  Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormReceiveValues()
        {
            // If connected already, return true.  This means this page came through the menu system.
            //
            if (moUtility.IsNonEmpty(User.sServer_nm) || moDatabase.IsConnected())
            {
                return true;
            }

            // Otherwise, need to login with the info passed from the calling page.
            //
            if (modGeneralUtility.GetPassedParameters(StarterValue, User, moSession) == false)
            {
                FormShowMessage(User.Language.oMessage.PLEASE_LOG_IN_FIRST);
                return false;
            }

            moPage.sInitialKey_id = moSession.Value.Entity;

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            return true;
        }

        private bool FormSwitchView(int cur_page = -1)                                                              // Switch the tab-pages
        {

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            moView.SwitchView(moPage, cur_page);

            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moZoom.Caller == "txtItem_cd")
            {
                if (moZoom.Inventory(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            if (moZoom.Caller == "txtVendor_cd")
            {
                if (moZoom.Vendor(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }


        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            FormCancel();
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            FormExit();
            return true;
        }

        private bool btnPrint_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateHTML();

            return FormPostEvent();
        }

        private bool btnExcel_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateExcel();

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewCriteria_Clicked()
        {
            FormPreEvent();
            FormSwitchView(VIEW_CRITERIA);

            return true;
        }

        private bool cmdViewSummary_Clicked()
        {
            FormPreEvent();

            FormSwitchView(VIEW_SUMMARY);
            return true;

        }

        private bool cmdViewDetail_Clicked()
        {
            FormPreEvent();

            FormSwitchView(VIEW_DETAIL);

            return true;
        }

        private bool cmdViewChart_Clicked()
        {
            FormPreEvent();

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (GetChart() == false)
            {
                return false;
            }

            FormSwitchView(VIEW_CHART);

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================


        private bool btnZoomSelect_Clicked(clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                code_selected = cur_item.Col_0;

                if (moZoom.Caller == "txtItem_cd")
                {
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    Header.txtItem_cd = code_selected;
                    return txtItem_cd_Changed();
                }
                if (moZoom.Caller == "txtVendor_cd")
                {
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    Header.txtVendor_cd = code_selected;
                    return txtVendor_cd_Changed();
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }


        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }

        private bool btnZoomOnVendor_cd_Clicked()
        {
            string where_clause = "";

            FormPreEvent();

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtVendor_cd", -1, -1, moView.MAIN_PAGE_NUM, "sVendor_cd", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }
        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        private bool txtItem_cd_Changed()
        {
            Header.txtItem_cd = modCommonUtility.CleanCode(Header.txtItem_cd);

            if (Header.txtItem_cd == Header.Tag.txtItem_cd)
            {
                return true;
            }

            if (moPage.bInDialog_fl == false)
            {
                FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.
            }

            if (moUtility.IsNonEmpty(Header.txtItem_cd))
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                if (moValidate.IsValidItemCode(Header.txtItem_cd) == false)
                {
                    FormShowMessage(Header.txtItem_cd + User.Language.oMessage.IS_INVALID);
                    Header.txtItem_cd = Header.Tag.txtItem_cd;
                    return false;
                }
            }

            FormClearDetail();

            return FormPostEvent();
        }


        private bool btnZoomOnItem_cd_Clicked()
        {
            string where_clause = "";

            FormPreEvent();

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtItem_cd", -1, -1, moView.MAIN_PAGE_NUM, "sItem_cd", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdShowNow_Clicked()
        {
            FormPreEvent();

            if (FormCheck() == false)
            {
                return false;
            }

            if (moUtility.IsEmpty(Header.cboBrand_cd) && moUtility.IsEmpty(Header.cboClass_cd) && moUtility.IsEmpty(Header.cboColor_cd)
             && moUtility.IsEmpty(Header.cboEvent_cd) && moUtility.IsEmpty(Header.cboGroup_cd) && moUtility.IsEmpty(Header.cboInterestGroup_cd)
             && moUtility.IsEmpty(Header.cboManufacturer_cd) && moUtility.IsEmpty(Header.cboModel_cd) && moUtility.IsEmpty(Header.cboSize_cd)
             && moUtility.IsEmpty(Header.cboSale_cd) && moUtility.IsEmpty(Header.cboStyle_cd) && moUtility.IsEmpty(Header.txtItem_cd) && moUtility.ToInteger(Header.cboComparisonPeriods) > 5)
            {
                if (CreateClauses(true) && mbEntityIncluded_fl)
                {
                    if (FormDialog(cmdShowNow_Clicked, 100, User.Language.oMessage.THIS_MAY_TAKE_WHILE + User.Language.oMessage.WOULD_LIKE_PROCEED) == false)
                    {
                        return false;
                    }
                }
            }

            moSummaryPagination.Clear();

            if (ShowSummary())       
            {
                FormSwitchView(VIEW_SUMMARY);
            }

            return FormPostEvent();
        }

        private bool cboQuery_typ_Clicked()
        {
            if (Header.cboQuery_typ == Header.Tag.cboQuery_typ)
            {
                return true;
            }

            FormPreEvent();

            return FormPostEvent();
        }

        private bool cmdInclude_Clicked()
        {

            FormPreEvent();

            if (moUtility.IsNonEmpty(Header.cboAvailable))
            {
                modWebLoadUtility.AddItemToComboBox(ref SelectedList, Header.cboAvailable, modCommonUtility.GetComboText(AvailableList, Header.cboAvailable));
            }

            return FormPostEvent();
        }
        private bool cmdExclude_Clicked()
        {

            FormPreEvent();

            if (moUtility.IsNonEmpty(Header.cboSelected))
            {
                modWebLoadUtility.RemoveItemFromComboBox(ref SelectedList, Header.cboSelected);
                Header.cboSelected = "";          // Because it is gone now.
            }

            return FormPostEvent();
        }

        private bool cmdSummaryPreviousPage_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            moSummaryPagination.PreviousPage_Clicked(RePagination);

            return FormPostEvent();
        }

        private bool cmdSummaryNextPage_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            moSummaryPagination.NextPage_Clicked(RePagination);

            return FormPostEvent();
        }

        private bool cmdSummaryPage_Clicked(int link_num)
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            moSummaryPagination.Link_Clicked(link_num);
            GetDataPaginated(moSummary, moSummaryPagination) ;

            return FormPostEvent();
        }

        public void RearrangePageLinks(Models.clsPagination cur_page, string[,] data,  ref int first_row, ref int last_row)
        {
            int page_num = 0;

            if (moUtility.ToInteger(Header.cboMaxLinesPerPage) == 0)
            {
                first_row = 0;
                last_row = data.GetUpperBound(1);
                return;
            }

            page_num = cur_page.CurrentPage;

            if (cur_page.ArrangeLinks(data.GetLength(1), moUtility.ToInteger(Header.cboMaxLinesPerPage), ref first_row, ref last_row, ref page_num) == false)
            {
                FormShowMessage();
                return;
            }

            cur_page.CurrentPage = page_num;
        }

        public bool optPeriod_typ_Clicked(int period_type)
        {
            FormPreEvent();

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            Header.cboPeriodFrom_dt = "";

            if (period_type == clsInquiry.PERIOD_TYPE_YEARLY)
            {
                Header.optPeriod_typ = clsInquiry.PERIOD_TYPE_YEARLY;
				modLoadUtility.LoadFiscalYear(ref moDatabase, ref PeriodList);
                modLoadUtility.LoadConsecutiveNumbers(ref moDatabase, ref ComparisonPeriodList, 24);
            }
            else if (period_type == clsInquiry.PERIOD_TYPE_QUARTERLY)
            {
                Header.optPeriod_typ = clsInquiry.PERIOD_TYPE_QUARTERLY;
				modLoadUtility.LoadFiscalQuarters(ref moDatabase, ref PeriodList, true, true, true);
                modLoadUtility.LoadConsecutiveNumbers(ref moDatabase, ref ComparisonPeriodList, 24);
            }
            else if (period_type == clsInquiry.PERIOD_TYPE_YTD)
            {
                Header.optPeriod_typ = clsInquiry.PERIOD_TYPE_YTD;
				modLoadUtility.LoadCalendarMonthID(ref PeriodList);
                modLoadUtility.LoadConsecutiveNumbers(ref moDatabase, ref ComparisonPeriodList, 24);
            }
            else if (period_type == clsInquiry.PERIOD_TYPE_QTD)
            {
                Header.optPeriod_typ = clsInquiry.PERIOD_TYPE_QTD;
				modLoadUtility.LoadCalendarMonthID(ref PeriodList);
                modLoadUtility.LoadConsecutiveNumbers(ref moDatabase, ref ComparisonPeriodList, 24);
            }
            else if (period_type == clsInquiry.PERIOD_TYPE_WEEKLY)
            {
                Header.optPeriod_typ = clsInquiry.PERIOD_TYPE_WEEKLY;
                modLoadUtility.LoadCalendarWeeks(ref moDatabase, ref PeriodList, false, true);
                modLoadUtility.LoadConsecutiveNumbers(ref moDatabase, ref ComparisonPeriodList, 52);
            }
            else
            {
                Header.optPeriod_typ = clsInquiry.PERIOD_TYPE_MONTHLY;
                modLoadUtility.LoadCalendarMonthID(ref PeriodList);
                Header.cboPeriodFrom_dt = moUtility.GetMonth(moGeneral.CurrentDate()).ToString();
                modLoadUtility.LoadConsecutiveNumbers(ref moDatabase, ref ComparisonPeriodList, 36);
            }

            AdjustComparisonType();

            return FormPostEvent();
        }

        public bool optComparison_typ_Clicked(int comparison_type)
        {
            FormPreEvent();

            if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_YEARLY)
            {
                Header.optComparison_typ = COMPARISON_TYPE_CONSECUTIVE;
            }
            else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_QTD || Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_YTD)
            {
                Header.optComparison_typ = COMPARISON_TYPE_SAME_PERIOD;
            }
            else 
            {
                Header.optComparison_typ = comparison_type;
            }

            AdjustComparisonType();

            return FormPostEvent();
        }
        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================


        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else.
        //                                   
        //  ===============================================================================================================================================================================================================================

        private bool chkAll_fl_Clicked()
        {
            if (chkAll_fl)
            {
                cmdUnSelectAll_Clicked();
            }
            else
            {
                cmdSelectAll_Clicked();
            }

            return FormPostEvent();
        }


        private bool cmdUnSelectAll_Clicked()
        {

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            foreach (var det in moSummary.Grid)
            {
                det.chkInclude_fl = false;
            }

            return FormPostEvent();
        }

        private bool cmdSelectAll_Clicked()
        {

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            foreach (var det in moSummary.Grid)
            {
                if (moUtility.IsNonEmpty(det.Col_0) && moUtility.SUCase(det.Col_0) != moUtility.SUCase(User.Language.oCaption.TOTAL))
                {
                    det.chkInclude_fl = true;
                }
            }

            return FormPostEvent();
        }


        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        private bool txtVendor_cd_Changed()
        {
            Header.txtVendor_cd = modCommonUtility.CleanCode(Header.txtVendor_cd);

            if (Header.txtVendor_cd == Header.Tag.txtVendor_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moUtility.IsNonEmpty(Header.txtVendor_cd))
            {
                if (moValidate.IsValidVendorCode(Header.txtVendor_cd) == false)
                {
                    FormShowMessage(Header.txtVendor_cd + User.Language.oMessage.IS_INVALID);
                    Header.txtVendor_cd = Header.Tag.txtVendor_cd;
                }
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================


        private void ClearBreakdown()
        {
            msSummaryCaption = "";
            miSummaryTotalColumns = 0;
            moSummary.Grid.Clear();
        }

        private bool CreateClauses(bool check_grouping_only = false)
        {
            bool return_value = false;
            int i = 0;

            mbEntityIncluded_fl = false;

            msGroupingClause = "";
            msSelectClause = "";
            msWhereClause = "";

            if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_YEARLY || Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_YTD || Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_QTD)
            {
                msGroupingClause = "sFiscalYear";
            }
            else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_QUARTERLY)
            {
                if (Header.optComparison_typ == clsInquiry.COMPARISON_TYPE_SAME_PERIOD_OF_YEAR)
                {
                    msGroupingClause = "sFiscalYear";
                }
                else
                {
                    msGroupingClause = "sQuarter";
                }
            }
            else
            {
                msGroupingClause = "iPeriodBegin_dt";
            }

            if (SelectedList.Count == 0)
            {
                moUtility.ResizeDim(ref msGroupingItems, 0);
                msGroupingItems[PERIOD_COL] = msGroupingClause;
            }
            else
            {
                moUtility.ResizeDim(ref msGroupingItems, SelectedList.Count);
                msGroupingItems[PERIOD_COL] = msGroupingClause;
                i = 1;

                foreach (var det in SelectedList)
                {
                    msGroupingItems[i] = "";

                    if (det.Value == STR_ITEM)
                    {
                        msGroupingItems[i] = "i.sItem_cd + ' : ' + i.sLabel";
                        mbEntityIncluded_fl = true;
                    }
                    else if (det.Value == STR_INTEREST_GROUP)
                    {
                        msGroupingItems[i] = "g.sInterestGroup_cd";
                    }
                    else if (det.Value == STR_LOCATION)
                    {
                        msGroupingItems[i] = "b.sLocation_cd";
                    }
                    else if (det.Value == STR_GROUP)
                    {
                        msGroupingItems[i] = "i.sGroup_cd";
                    }
                    else if (det.Value == STR_CLASS)
                    {
                        msGroupingItems[i] = "i.sClass_cd";
                    }
                    else if (det.Value == STR_PROMO_SALE)
                    {
                        msGroupingItems[i] = "i.sEvent_cd";
                    }
                    else if (det.Value == STR_REGULAR_SALE)
                    {
                        msGroupingItems[i] = "i.sSale_cd";
                    }
                    else if (det.Value == msManufacturerCaption)
                    {
                        msGroupingItems[i] = "i.sManufacturer_cd";
                    }
                    else if (det.Value == msBrandCaption)
                    {
                        msGroupingItems[i] = "i.sBrand_cd";
                    }
                    else if (det.Value == msModelCaption)
                    {
                        msGroupingItems[i] = "i.sModel_cd";
                    }
                    else if (det.Value == msStyleCaption)
                    {
                        msGroupingItems[i] = "i.sStyle_cd";
                    }
                    else if (det.Value == msColorCaption)
                    {
                        msGroupingItems[i] = "i.sColor_cd";
                    }
                    else if (det.Value == msSizeCaption)
                    {
                        msGroupingItems[i] = "i.sSize_cd";
                    }

                    if (moUtility.IsNonEmpty(msGroupingItems[i]))
                    {
                        msGroupingClause += moUtility.IIf(moUtility.IsNonEmpty(msGroupingClause), ", ", "").ToString() + msGroupingItems[i];
                    }

                    i += 1;
                }

            }

            if (check_grouping_only)
            {
                return true;
            }

            msWhereClause = " FROM ";
            if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_WEEKLY)
            {
                msWhereClause += " tblIVBalanceWeekly";
            }
            //else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_DAILY)
            //{
            //    msWhereClause += " tblIVTransactionDet";
            //}
            else
            {
                msWhereClause += " tblIVBalance";
            }
            msWhereClause += " b INNER JOIN tblIVItem i ON (b.sItem_cd = i.sItem_cd";

            if (Header.chkConsignmentOnly_fl)
            {
                msWhereClause += " AND i.iConsignment_typ > 0";
            }
            if (moUtility.IsNonEmpty(Header.txtVendor_cd))
            {
                msWhereClause += " AND i.sPreferredVendor_cd = '" + Header.txtVendor_cd + "'";
            }

            msWhereClause += " )";

            if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_MONTHLY)
            {
                msWhereClause += moInquiry.SelectMonths(ref moDatabase, Header.optComparison_typ, Header.cboPeriodFrom_dt, moUtility.ToInteger(Header.cboComparisonPeriods));
            }
            else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_QUARTERLY)
            {
                msWhereClause += moInquiry.SelectQuarters(ref moDatabase, Header.optComparison_typ, Header.cboPeriodFrom_dt, moUtility.ToInteger(Header.cboComparisonPeriods));
            }
            else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_QTD)
            {
                msWhereClause += moInquiry.SelectQTD(ref moDatabase, Header.optComparison_typ, Header.cboPeriodFrom_dt, moUtility.ToInteger(Header.cboComparisonPeriods));
            }
            else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_YEARLY)
            {
                msWhereClause += moInquiry.SelectYears(ref moDatabase, Header.optComparison_typ, Header.cboPeriodFrom_dt, moUtility.ToInteger(Header.cboComparisonPeriods));
            }
            else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_YTD)
            {
                msWhereClause += moInquiry.SelectYTD(ref moDatabase, Header.optComparison_typ, Header.cboPeriodFrom_dt, moUtility.ToInteger(Header.cboComparisonPeriods));
            }
            else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_WEEKLY)
            {
                msWhereClause += moInquiry.SelectWeeks(ref moDatabase, Header.optComparison_typ, Header.cboPeriodFrom_dt, moUtility.ToInteger(Header.cboComparisonPeriods), modCommonUtility.GetComboText(PeriodList, Header.cboPeriodFrom_dt));
            }
            else
            {
                return return_value;
            }


            if (moUtility.IsNonEmpty(Header.txtItem_cd))
            {
                msWhereClause += " AND b.sItem_cd = '" + Header.txtItem_cd + "'";
            }
            else
            {
                if (moUtility.ToInteger(Header.cboItem_typ) > 0)
                {
                    msWhereClause += " AND i.iItem_typ = " + moUtility.ToInteger(Header.cboItem_typ).ToString();
                }
                else
                {
                    msWhereClause += " AND i.iItem_typ IN (" + moUtility.InventoryItemTypeList() + ")";
                }

                if (moUtility.IsNonEmpty(Header.cboInterestGroup_cd))
                {
                    msWhereClause += " AND b.sItem_cd IN (SELECT sItem_cd FROM tblIVInterestGroupDet WHERE sInterestGroup_cd = '" + Header.cboInterestGroup_cd + "')";
                }
                if (moUtility.IsNonEmpty(Header.cboBrand_cd))
                {
                    msWhereClause += " AND i.sBrand_cd = '" + Header.cboBrand_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboColor_cd))
                {
                    msWhereClause += " AND i.sColor_cd = '" + Header.cboColor_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboEvent_cd))
                {
                    msWhereClause += " AND i.sEvent_cd = '" + Header.cboEvent_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboGroup_cd))
                {
                    msWhereClause += " AND i.sGroup_cd = '" + Header.cboGroup_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboClass_cd))
                {
                    msWhereClause += " AND i.sClass_cd = '" + Header.cboClass_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboManufacturer_cd))
                {
                    msWhereClause += " AND i.sManufacturer_cd = '" + Header.cboManufacturer_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboModel_cd))
                {
                    msWhereClause += " AND i.sModel_cd = '" + Header.cboModel_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboSale_cd))
                {
                    msWhereClause += " AND i.sSale_cd = '" + Header.cboSale_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboSize_cd))
                {
                    msWhereClause += " AND i.sSize_cd = '" + Header.cboSize_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboStyle_cd))
                {
                    msWhereClause += " AND i.sStyle_cd = '" + Header.cboStyle_cd + "'";
                }
            }
            if (moUtility.IsNonEmpty(Header.cboLocation_cd))
            {
                msWhereClause += " AND b.sLocation_cd = '" + Header.cboLocation_cd + "'";
            }
            else
            {
                msWhereClause += " AND b.sLocation_cd <> '" + GlobalVar.goConstant.FOR_ALL + "'";
            }


            return true;
        }

        private bool ShowSummary()
        {
            bool return_value = false;
            string sql_str = "";
            string page_title = "";
            string tmp = "";
            int i = 0;
            string net_generator = "";
            int total_rows = 0;

            try
            {
                msSummaryCaption = "";
                miSummaryTotalColumns = 0;
                moSummary.Clear();

                if (CreateClauses() == false)
                {
                    return false;
                }
                if (SelectedList.Count == 0)
                {
                    sql_str = msSelectClause;
                    moUtility.ResizeDim(ref msGroupingItems, 0);
                    msGroupingItems[PERIOD_COL] = msGroupingClause;
                }
                else
                {
                    for (i = 1; i < msGroupingItems.GetLength(0); i++)
                    {
                        if (moUtility.IsNonEmpty(msGroupingItems[i]))
                        {
                            tmp = moUtility.STrim(moUtility.SRight(msGroupingItems[i], moUtility.SLength(msGroupingItems[i]) - moUtility.SInStr(msGroupingItems[i], ".")));
                            msSummaryCaption += moUtility.IIf(i == 1, "", ", ").ToString() + moUtility.SMid(tmp, 2, moUtility.SInStr(tmp, "_") - 2);
                        }
                    }
                }

                page_title = Header.cboQuery_typ;
                //txtChartTitle = page_title;

                if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_YEARLY)
                {
                    page_title += ": Yearly";
                }
                else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_YTD)
                {
                    page_title += ": YTD";
                }
                else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_QTD)
                {
                    page_title += ": QTD";
                }
                else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_QUARTERLY)
                {
                    page_title += ": Quarterly";
                }
                else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_MONTHLY)
                {
                    page_title += ": Monthly";
                }
                else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_WEEKLY)
                {
                    page_title += ": Weekly";
                }
                else
                {
                    return return_value;
                }

                page_title += " summary " + moUtility.IIf(moUtility.IsNonEmpty(msSummaryCaption), " by " + msSummaryCaption, "").ToString();
                //txtChartSubTitle = moUtility.STrim(moUtility.SReplace(moUtility.SReplace(page_title, txtChartTitle, ""), ":", ""));

                if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_YEARLY)
                {
                    page_title += " for the last " + Header.cboComparisonPeriods + " years from " + Header.cboPeriodFrom_dt;
                }
                else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_YTD)
                {
                    page_title += " for " + Header.cboPeriodFrom_dt + " for the last " + Header.cboComparisonPeriods + " years.";
                }
                else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_QTD)
                {
                    if (Header.optComparison_typ == clsInquiry.COMPARISON_TYPE_CONSECUTIVE)
                    {
                        page_title += " for the last " + Header.cboComparisonPeriods + " quarters from " + Header.cboPeriodFrom_dt + ".";
                    }
                    else
                    {
                        page_title += " for " + Header.cboPeriodFrom_dt + " for the last " + Header.cboComparisonPeriods + " years.";
                    }
                }
                else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_QUARTERLY)
                {
                    if (Header.optComparison_typ == clsInquiry.COMPARISON_TYPE_CONSECUTIVE)
                    {
                        page_title += " for the last " + Header.cboComparisonPeriods + " quarters from " + Header.cboPeriodFrom_dt + ".";
                    }
                    else
                    {
                        page_title += " for " + Header.cboPeriodFrom_dt + " for the last " + Header.cboComparisonPeriods + " years.";
                    }
                }
                else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_MONTHLY)
                {
                    tmp = Microsoft.VisualBasic.DateAndTime.MonthName(moUtility.ToInteger(Header.cboPeriodFrom_dt));
                    if (Header.optComparison_typ == clsInquiry.COMPARISON_TYPE_CONSECUTIVE)
                    {
                        page_title += " for the last " + Header.cboComparisonPeriods + " months from " + tmp + ".";
                    }
                    else
                    {
                        page_title += " for " + tmp + " for the last " + Header.cboComparisonPeriods + " years.";
                    }
                }
                else
                {
                    if (Header.optComparison_typ == clsInquiry.COMPARISON_TYPE_CONSECUTIVE)
                    {
                        page_title += " for the last " + Header.cboComparisonPeriods + " weeks from " + Header.cboPeriodFrom_dt + ".";
                    }
                    else
                    {
                        page_title += " for " + Header.cboPeriodFrom_dt + " for the last " + Header.cboComparisonPeriods + " years.";
                    }
                }

                msSummaryCaption = page_title;


                net_generator = "((iTransaction_typ - XXX) * (-2) + 1)"; // Will make sales = (+1) and returns = (-1)
                if (Header.cboQuery_typ == clsInquiry.REPORT_NET_SALES)
                {
                    net_generator = moUtility.SReplace(net_generator, "XXX", GlobalVar.goConstant.TRX_IV_SALES_TYPE.ToString());
                }
                else if (Header.cboQuery_typ == clsInquiry.REPORT_NET_PURCHASE)
                {
                    net_generator = moUtility.SReplace(net_generator, "XXX", GlobalVar.goConstant.TRX_IV_PURCHASE_TYPE.ToString());
                }
                else if (Header.cboQuery_typ == clsInquiry.REPORT_NET_TRANSFER)
                {
                    net_generator = moUtility.SReplace(net_generator, "XXX", GlobalVar.goConstant.TRX_TRANSFER_IN_TYPE.ToString());
                }
                else
                {
                    net_generator = "1";
                }


                sql_str = "SELECT " + msGroupingClause + "";


                if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_DAILY)
                {
                    if (Header.cboQuery_typ == clsInquiry.REPORT_NET_SALES || Header.cboQuery_typ == clsInquiry.REPORT_NET_PURCHASE || Header.cboQuery_typ == clsInquiry.REPORT_NET_TRANSFER)
                    {
                        if (Header.optQueryBy == clsInquiry.QUERY_BY_QTY)
                        {
                            sql_str += ", SUM(fInIVUnit_qty * " + net_generator + ") AS fNetSalesQty";
                        }
                        else if (Header.optQueryBy == clsInquiry.QUERY_BY_PROFIT)
                        {
                            sql_str += ", SUM((mTotal_amt - mTotalCost_amt) * " + net_generator + ") AS mProfitAmt"; // Only for sales
                        }
                        else
                        {
                            sql_str += ", SUM(mTotal_amt * " + net_generator + ") AS mNetSalesAmt";
                        }
                    }
                    else // every thing else
                    {
                        if (Header.optQueryBy == clsInquiry.QUERY_BY_QTY)
                        {
                            sql_str += ", SUM(fInIVUnit_qty) AS fSalesQty";
                        }
                        else
                        {
                            sql_str += ", SUM(mTotal_amt) AS mSalesAmt";
                        }
                    }

                    if (Header.cboQuery_typ == clsInquiry.REPORT_SALES_RETURN)
                    {
                        sql_str = moUtility.SReplace(sql_str, "Sales", "SalesReturn");
                    }
                    else if (Header.cboQuery_typ == clsInquiry.REPORT_PURCHASE || Header.cboQuery_typ == clsInquiry.REPORT_NET_PURCHASE)
                    {
                        sql_str = moUtility.SReplace(sql_str, "Sales", "Purchase");
                    }
                    else if (Header.cboQuery_typ == clsInquiry.REPORT_PURCHASE_RETURN)
                    {
                        sql_str = moUtility.SReplace(sql_str, "Sales", "PurchaseReturn");
                    }
                    else if (Header.cboQuery_typ == clsInquiry.REPORT_ASJUSTMENT)
                    {
                        sql_str = moUtility.SReplace(sql_str, "Sales", "Adjustment");
                    }
                    else if (Header.cboQuery_typ == clsInquiry.REPORT_SPOILAGE)
                    {
                        sql_str = moUtility.SReplace(sql_str, "Sales", "Spoilage");
                    }
                    else if (Header.cboQuery_typ == clsInquiry.REPORT_NET_TRANSFER)
                    {
                        sql_str = moUtility.SReplace(sql_str, "Sales", "Transfer");
                    }
                    else if (Header.cboQuery_typ == clsInquiry.REPORT_TRANSFER_IN)
                    {
                        sql_str = moUtility.SReplace(sql_str, "Sales", "TransferIn");
                    }
                    else if (Header.cboQuery_typ == clsInquiry.REPORT_TRANSFER_OUT)
                    {
                        sql_str = moUtility.SReplace(sql_str, "Sales", "TransferOut");
                    }
                    else // Sales
                    {
                        // Already good
                    }

                }
                else
                {
                    if (Header.cboQuery_typ == clsInquiry.REPORT_NET_SALES)
                    {
                        if (Header.optQueryBy == clsInquiry.QUERY_BY_QTY)
                        {
                            sql_str += ", SUM(fSales_qty - fSalesReturn_qty) AS fNetSalesQty";
                        }
                        else if (Header.optQueryBy == clsInquiry.QUERY_BY_PROFIT)
                        {
                            sql_str += ", SUM(mSales_amt - mSalesReturn_amt - mCGS_amt) AS mProfitAmt";
                        }
                        else
                        {
                            sql_str += ", SUM(mSales_amt - mSalesReturn_amt) AS mNetSalesAmt";
                        }
                    }
                    else if (Header.cboQuery_typ == clsInquiry.REPORT_SALES)
                    {
                        if (Header.optQueryBy == clsInquiry.QUERY_BY_QTY)
                        {
                            sql_str += ", SUM(fSales_qty) AS fSalesQty";
                        }
                        else if (Header.optQueryBy == clsInquiry.QUERY_BY_PROFIT)
                        {
                            //sql_str &= ", SUM(mSales_amt - mSalesReturn_amt - mCGS_amt) AS mProfitAmt"
                        }
                        else
                        {
                            sql_str += ", SUM(mSales_amt) AS mSalesAmt";
                        }
                    }
                    else if (Header.cboQuery_typ == clsInquiry.REPORT_SALES_RETURN)
                    {
                        if (Header.optQueryBy == clsInquiry.QUERY_BY_QTY)
                        {
                            sql_str += ", SUM(fSalesReturn_qty) AS fSalesQty";
                        }
                        else if (Header.optQueryBy == clsInquiry.QUERY_BY_PROFIT)
                        {
                            //sql_str &= ", SUM(mSales_amt - mSalesReturn_amt - mCGS_amt) AS mProfitAmt"
                        }
                        else
                        {
                            sql_str += ", SUM(mSalesReturn_amt) AS mSalesAmt";
                        }
                    }
                    else if (Header.cboQuery_typ == clsInquiry.REPORT_NET_PURCHASE)
                    {
                        if (Header.optQueryBy == clsInquiry.QUERY_BY_QTY)
                        {
                            sql_str += ", SUM(fPurchase_qty - fPurchaseReturn_qty) AS fNetPurchaseQty";
                        }
                        else // By amount
                        {
                            sql_str += ", SUM(mPurchase_amt - mPurchaseReturn_amt) AS mNetPurchaseAmt";
                        }
                    }
                    else if (Header.cboQuery_typ == clsInquiry.REPORT_PURCHASE)
                    {
                        if (Header.optQueryBy == clsInquiry.QUERY_BY_QTY)
                        {
                            sql_str += ", SUM(fPurchase_qty) AS fPurchaseQty";
                        }
                        else // By amount
                        {
                            sql_str += ", SUM(mPurchase_amt) AS mPurchaseAmt";
                        }
                    }
                    else if (Header.cboQuery_typ == clsInquiry.REPORT_PURCHASE_RETURN)
                    {
                        if (Header.optQueryBy == clsInquiry.QUERY_BY_QTY)
                        {
                            sql_str += ", SUM(fPurchaseReturn_qty) AS fPurchaseReturnQty";
                        }
                        else // By amount
                        {
                            sql_str += ", SUM(mPurchaseReturn_amt) AS mPurchaseReturnAmt";
                        }
                    }
                    else if (Header.cboQuery_typ == clsInquiry.REPORT_ASJUSTMENT)
                    {
                        if (Header.optQueryBy == clsInquiry.QUERY_BY_QTY)
                        {
                            sql_str += ", SUM(fAdjust_qty) AS fAdjustmentQty";
                        }
                        else // By amount
                        {
                            sql_str += ", SUM(mAdjust_amt) AS mAdjustmentAmt";
                        }
                    }
                    else if (Header.cboQuery_typ == clsInquiry.REPORT_SPOILAGE)
                    {
                        if (Header.optQueryBy == clsInquiry.QUERY_BY_QTY)
                        {
                            sql_str += ", SUM(fSpoilage_qty) AS fSpoilageQty";
                        }
                        else // By amount
                        {
                            sql_str += ", SUM(mSpoilage_amt) AS mSpoilageAmt";
                        }
                    }
                    else if (Header.cboQuery_typ == clsInquiry.REPORT_NET_TRANSFER)
                    {
                        if (Header.optQueryBy == clsInquiry.QUERY_BY_QTY)
                        {
                            sql_str += ", SUM(fTransferIn_qty - fTransferOut_qty) AS fNetTransferQty";
                        }
                        else // By amount
                        {
                            sql_str += ", SUM(mTransferIn_amt - mTransferOut_amt) AS mNetTransferAmt";
                        }
                    }
                    else if (Header.cboQuery_typ == clsInquiry.REPORT_TRANSFER_IN)
                    {
                        if (Header.optQueryBy == clsInquiry.QUERY_BY_QTY)
                        {
                            sql_str += ", SUM(fTransferIn_qty) AS fTransferInQty";
                        }
                        else // By amount
                        {
                            sql_str += ", SUM(mTransferIn_amt) AS mTransferInAmt";
                        }
                    }
                    else if (Header.cboQuery_typ == clsInquiry.REPORT_TRANSFER_OUT)
                    {
                        if (Header.optQueryBy == clsInquiry.QUERY_BY_QTY)
                        {
                            sql_str += ", SUM(fTransferOut_qty) AS fTransferOutQty";
                        }
                        else // By amount
                        {
                            sql_str += ", SUM(mTransferOut_amt) AS mTransferOutAmt";
                        }
                    }
                }

                if (moUtility.IsNonEmpty(msGroupingClause))
                {
                    sql_str += msWhereClause + " GROUP BY " + msGroupingClause + " ORDER BY " + msGroupingClause;
                }
                else
                {
                    sql_str += msWhereClause;
                }

                if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_DAILY)
                {
                    sql_str = moUtility.SReplace(sql_str, "sLocation_cd", "sFromLocation_cd");
                }

                if (moSummaryPagination.EntireData == null)
                {
                    if (GetData(moSummary, sql_str, moSummaryPagination) == false)
                    {
                        return false;
                    }

                    Header.lblSummaryRecordsFound = moSummaryPagination.EntireData.GetLength(1) + " " + User.Language.oMessage.RECORDS_FOUND;
                }
                else
                {
                    if (GetDataPaginated(moSummary, moSummaryPagination) == false)
                    {
                        return false;
                    }
                }


                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (ShowSummary)");
            }

            return return_value;
        }

        private bool RePagination()
        {
            if (GetDataPaginated(moSummary, moSummaryPagination) == false)
            {
                return false;
            }

            return true;
        }

        // This is to diplasy a paginated set of records
        //
        private bool GetDataPaginated(Models.clsSpreadsheet cur_sheet,  Models.clsPagination cur_page = null)
        {
            bool return_value = false;
            int row_num = 0;
            int col_num = 0;
            int first_row = 0;
            int last_row = 0;

            try
            {
                if (cur_page.EntireData == null)
                {
                    return false;
                }

                RearrangePageLinks(cur_page, cur_page.EntireData, ref first_row, ref last_row);
                last_row = last_row - first_row;

                if (cur_page.EntireData.GetLength(1) - first_row <= moUtility.ToInteger(Header.cboMaxLinesPerPage))
                {
                    cur_sheet.iTotalRows = cur_page.EntireData.GetLength(1) - first_row;
                }
                else if ((last_row - row_num + 1) < moUtility.ToInteger(Header.cboMaxLinesPerPage))
                {
                    cur_sheet.iTotalRows = last_row - row_num + 1;
                }
                else
                {
                    cur_sheet.iTotalRows = moUtility.ToInteger(Header.cboMaxLinesPerPage);
                }

                moUtility.ResizeDim(ref cur_sheet.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, cur_sheet.iTotalRows - 1);

                for (row_num = 0; row_num < cur_sheet.iTotalRows; row_num++)
                {
                    for (col_num = 0; col_num < cur_sheet.FieldName.GetLength(0); col_num++)
                    {
                        cur_sheet.Data[col_num, row_num] = cur_page.EntireData[col_num, row_num + first_row];
                    }
                }

                cur_sheet.RecreateGrid();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (GetDataPaginated)");
            }

            return return_value;
        }

        // This is to create
        private bool GetData(Models.clsSpreadsheet cur_sheet, string sql_str, Models.clsPagination cur_page = null)
        {
            bool return_value = false;
            int first_row = 0;
            int last_row = 0;

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }
                if (cur_set.EOF())
                {
                    FormShowMessage(User.Language.oMessage.NO_RECORDS_FOUND);
                    return false;
                }
                if (cur_set.RecordCount() > 5000)
                {
                    FormShowMessage(User.Language.oMessage.TOO_MANY_RECORDS_FOUND + ". " + User.Language.oMessage.ADD_MORE_SELECTIVE_CONDITIONS);
                    return false;
                }

                // This will the full set of data.
                //
                if (cur_page.GetComparativeData(ref moDatabase, cur_sheet, cur_page, cur_set, Header.optPeriod_typ, msGroupingItems, PERIOD_COL, ref miSummaryTotalColumns, SelectedList, null, "") == false) 
                {
                    FormShowMessage();
                    return false;
                }

                RearrangePageLinks(cur_page, cur_page.EntireData, ref first_row, ref last_row);

                // Show one page.
                //
                if (GetDataPaginated(cur_sheet, cur_page) == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (GetData)");
            }

            return return_value;
        }


        private bool CreateHTML()
        {
            bool return_value = false;
            string html_file = "";

            try
            {
                if (moPage.iCurrentView == VIEW_SUMMARY)
                {
                    html_file = moInquiry.CreateHTML(ref moDatabase, moPage.Title, moSummary, miSummaryTotalColumns, moSummary.Caption);
                }

                if (moUtility.IsEmpty(html_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(html_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateHTML)");
            }

            return return_value;
        }


        private bool CreateExcel()
        {
            bool return_value = false;
            string csv_file = "";

            try
            {
                if (moPage.iCurrentView == VIEW_SUMMARY)
                {
                    csv_file = moInquiry.CreateCSV(ref moDatabase, moPage.Title, moSummary, miSummaryTotalColumns, moSummary.Caption);
                }

                if (moUtility.IsEmpty(csv_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(csv_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateExcel)");
            }

            return return_value;
        }

        private void AdjustComparisonType()
        {

            if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_YEARLY)
            {
                Header.optComparison_typ = clsInquiry.COMPARISON_TYPE_CONSECUTIVE;
                msPeriodsCaption = User.Language.oString.STR_YEARS;
            }
            else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_YTD)
            {
                Header.optComparison_typ = clsInquiry.COMPARISON_TYPE_SAME_PERIOD_OF_YEAR;
                msPeriodsCaption = User.Language.oString.STR_YEARS;
            }
            else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_QTD)
            {
                Header.optComparison_typ = clsInquiry.COMPARISON_TYPE_SAME_PERIOD_OF_YEAR;
                if (Header.optComparison_typ == clsInquiry.COMPARISON_TYPE_SAME_PERIOD_OF_YEAR)
                {
                    msPeriodsCaption = User.Language.oString.STR_YEARS;
                }
                else
                {
                    msPeriodsCaption = User.Language.oString.STR_QUARTERS;
                }
            }
            else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_QUARTERLY)
            {
                if (Header.optComparison_typ == clsInquiry.COMPARISON_TYPE_SAME_PERIOD_OF_YEAR)
                {
                    msPeriodsCaption = User.Language.oString.STR_YEARS;
                }
                else
                {
                    msPeriodsCaption = User.Language.oString.STR_QUARTERS;
                }
            }
            else if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_WEEKLY)
            {
                if (Header.optComparison_typ == clsInquiry.COMPARISON_TYPE_SAME_PERIOD_OF_YEAR)
                {
                    msPeriodsCaption = User.Language.oString.STR_YEARS;
                }
                else
                {
                    msPeriodsCaption = User.Language.oString.STR_WEEKS;
                }
            }
            else // if (Header.optPeriod_typ == clsInquiry.PERIOD_TYPE_MONTHLY)
            {
                if (Header.optComparison_typ == clsInquiry.COMPARISON_TYPE_SAME_PERIOD_OF_YEAR)
                {
                    msPeriodsCaption = User.Language.oString.STR_YEARS;
                }
                else
                {
                    msPeriodsCaption = User.Language.oString.STR_MONTHS;
                }
            }
        }

        // ------------------------------------------------------------------------------------------------------------------------------------
        // VISUALIZATION SECTION
        // Redzen Chart  https://blazor.radzen.com/line-chart
        // ------------------------------------------------------------------------------------------------------------------------------------

        private clsRadzenChart[] Chart = new clsRadzenChart[1];

        private bool GetChart()
        {
            bool return_value = false;
            string[,] chart_data = null;
            int total_row = 0;
            int row_num = 0;
            int col_num = 0;

            try
            {
                foreach (var det in moSummary.Grid)
                {
                    if (det.chkInclude_fl)
                    {
                        total_row += 1;
                    }
                }

                if (total_row == 0)
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_SELECT_ITEMS);
                    return false;
                }
                if (total_row > 20)
                {
                    FormShowMessage(User.Language.oMessage.MAX_LINES_ALLOWED_IS + "20.");
                    return false;
                }

                moUtility.ResizeDim(ref chart_data, moSummary.Data.GetUpperBound(0), total_row - 1);
                total_row = 0;

                foreach (var det in moSummary.Grid)
                {
                    if (det.chkInclude_fl)
                    {
                        for (col_num = 0; col_num < moSummary.Data.GetLength(0); col_num++)
                        {
                            chart_data[col_num, total_row] = moSummary.Data[col_num, det.Row_num];
                        }
                        total_row += 1;
                    }
                }

                if (modRadzen.GetLineChartData(ref moDatabase, ref Chart, chart_data, moSummary.Caption, miSummaryTotalColumns, total_row, (SelectedList.Count == 0)) == false)
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;
            }
            catch(Exception ex)
            {
                FormShowMessage(ex.Message + " (GetChart())");
            }

            return return_value;
        }

        string FormatValue(object value)
        {
            return modRadzen.FormatValue(value);
        }

        string FormatAsMonth(object value)
        {
            return modRadzen.FormatAsMonth(value);
        }
        // ------------------------------------------------------------------------------------------------------------------------------------
        // END OF VISUALIZATION SECTION
        // ------------------------------------------------------------------------------------------------------------------------------------


    }
}
