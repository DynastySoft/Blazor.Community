﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;

using Dynasty.Database;
using Dynasty.Report;
using Dynasty.Local;
using Dynasty.ASP.Models;

namespace Dynasty.ASP.Pages.AP
{
    public partial class CashPayment
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<BinGenerator> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;
        private Models.clsListingPayment moListing;
        private Models.clsListingPayment moSearch;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        private bool ShowNavigation
        {
            get
            {
                return (moPage.iCurrentView != moView.ZOOM_PAGE_NUM && moPage.iCurrentView != moView.PRINT_PAGE_NUM);
            }
        }

        private bool ShowSearchPrinter
        {
            get
            {
                return (mbSearchInitiated_fl && mbSearchPopulated_fl);
            }
        }


        private bool ShowListingPrinter
        {
            get
            {
                return (mbListingInitiated_fl && mbListingPopulated_fl);
            }
        }

        private bool ValidToPrint
        {
            get
            {
                return (moUtility.ToInteger(Header.cboStatus_typ) != GlobalVar.goConstant.VOID_TRX_NUM);
            }
        }
        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsMoney moMoney;
        private clsBatch moBatch;

        private Models.clsPaymentDetail moDetail;
        private clsTransactionPayment moTransactionPayment;
        private clsCashPayment moCashPayment;
        private clsReportViewer moReport;
        private Models.clsCustomField moCustomFields;
        private clsVendor moVendor;
        private clsDeposit moDeposit;
        private Models.clsSession moSession;
        private clsInquiry moInquiry;

        private List<Models.clsCombobox> PaymentTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> FundCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> StatusTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> DocumentNumberList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CashAccountList = new List<Models.clsCombobox>();

        private string msFund_cd = "";
        private string msReport_id = "";

        private string msHoldStatusMessage = "";
        private int miVendorBalance_typ = 0;
        private bool mbPaymentEntered_fl = false;
        public decimal mmTotalDiscount_amt = 0;

        // After-fact transaction
        // When this option is on, user can enter a transaction number less than the current system number.
        //
        private bool chkAfterFact_fl = false;

        public bool UseMemo
        {
            get { return (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM); }
        }

        public bool BalanceForward
        {
            get { return (miVendorBalance_typ == GlobalVar.goAPConstant.FORWARD_VENDOR_NUM); }
        }

        private string DocumentLabel
        {
            get
            {
                if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.CHECK_TYPE_NUM)
                {
                    return User.Language.oString.STR_CHECK_NUM;
                }
                else if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.WIRE_TRANSFER_TYPE_NUM)
                {
                    return User.Language.oString.STR_EFT_NUM;
                }
                else if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM)
                {
                    return User.Language.oString.STR_DEBIT_MEMO;
                }
                else
                {
                    return User.Language.oString.STR_DOCUMENT_NUM;
                }
            }
        }

        public bool UseComboboxForCashAccount
        {
            get { return ((moDatabase.CommunityVersion || moDatabase.uSecurity.bUseComboboxForCashAccount_fl) && UseBankAccount); }
        }

        public bool UseBankAccount
        {
            get { return (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.CHECK_TYPE_NUM || moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.WIRE_TRANSFER_TYPE_NUM); }
        }

        public bool UseCashAccount
        {
            get { return (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.CASH_TYPE_NUM); }
        }

        // Listing options
        //
        private List<Models.clsCombobox> ListingByList = new List<Models.clsCombobox>();
        private string cboListingBy = "";
        private bool mbListingInitiated_fl = false;
        private bool mbListingPopulated_fl = false;

        // Search options
        //
        private string cboSearchYear = "";
        private bool mbSearchInitiated_fl = false;
        private bool mbSearchPopulated_fl = false;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================

        private class clsHeader
        {
            public string txtKey_id = "";
            public string cboFund_cd = "";
            public string txtPaid_amt = "";
            public string txtVendor_cd = "";
            public string txtDescription = "";
            public string txtReference = "";
            public string mskCashAcct_cd = "";
            public string txtDocument_num = "";
            public string txtFace_nm = "";
            public string cboStatus_typ = "";
            public string cboPayment_typ = "";
            public string lblVendor_nm = "";
            public string lblTotalUsed_amt = "";
            public string lblNewBalanceDue_amt = "";
            public string lblTotalBalance_amt = "";
            public string lblPayTo_cd = "";
            public string txtBatch_num = "";
            public string cboDocument_num = "";

            public string txtUserApproved_cd = "";
            public string txtToApprove_num = "";

            public string lblTolerance_amt = "";

            // Listing of UI items on the header
            //

            public string mskApply_dt = "";
            public string mskEntry_dt = "";
            public DateTime? dtApply_dt = null;
            public DateTime? dtEntry_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag
            {
                public string txtKey_id = "";
                public string cboFund_cd = "";
                public string txtPaid_amt = "";
                public string txtVendor_cd = "";
                public string txtReference = "";
                public string mskCashAcct_cd = "";
                public string txtDocument_num = "";
                public string txtFace_nm = "";
                public string cboStatus_typ = "";
                public string cboPayment_typ = "";
                public string cboDocument_num = "";
                public string lblVendor_nm = "";

                public string mskApply_dt = "";
                public string mskEntry_dt = "";
                public DateTime? dtApply_dt = null;
                public DateTime? dtEntry_dt = null;
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()
            {
                Tag.txtKey_id = txtKey_id;
                Tag.cboFund_cd = cboFund_cd;
                Tag.txtPaid_amt = txtPaid_amt;
                Tag.txtVendor_cd = txtVendor_cd;
                Tag.txtReference = txtReference;
                Tag.mskCashAcct_cd = mskCashAcct_cd;
                Tag.txtDocument_num = txtDocument_num;
                Tag.cboStatus_typ = cboStatus_typ;
                Tag.cboPayment_typ = cboPayment_typ;
                Tag.cboDocument_num = cboDocument_num;
                Tag.lblVendor_nm = lblVendor_nm;                // Do not delete

                Tag.mskApply_dt = mskApply_dt;
                Tag.dtApply_dt = dtApply_dt;
                Tag.mskEntry_dt = mskEntry_dt;
                Tag.dtEntry_dt = dtEntry_dt;
            }
        }
        private clsHeader Header = new clsHeader();

        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            moSession.RemoveSession(moDatabase);        // Delete the session file.

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            // If user uses date-picker, we need to change the date field.
            //
            if (User.bUseDatePicker_fl && moUtility.SLeft(field_name, 3) == "msk" && moUtility.SRight(field_name, 3) == "_dt")
            {
                field_name = moUtility.SReplace(field_name, "msk", "dt");
            }

            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows(int lines_to_add = 0)
        {

            return true;
        }

        private bool FormCalculateTotal()
        {

            return true;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {

            if (FormCheckSecurity() == false)
            {
                return false;
            }
            if (FormCheckHeader() == false)
            {
                return false;
            }

            if (moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.VOID_TRX_NUM)
            {
                return true;
            }

            if (FormCheckDetail() == false)
            {
                return false;
            }
            if (FormCheckExtra() == false)
            {
                return false;
            }

            return true;
        }

        private bool FormCheckDetail()
        {
            bool return_value = false;
            int row_num;

            try
            {
                FormRecreateDetail();       // Need to make sure moDetail.Data[] has the latest.

                // Check if the split payments are paid ok.
                //
                for (row_num = 1; row_num < moDetail.Data.GetLength(1); row_num++)
                {
                    if (moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num]) >= moDatabase.mSmallestMoney_amt
                        && moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL, row_num] == moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL, row_num - 1]
                        && moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num - 1]) < moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.BALANCE_DUE_COL, row_num - 1]))
                    {
                        FormShowMessage(User.Language.oMessage.IMPROPER_SPLIT_PAYMENT_FOUND + " - " + User.Language.oString.STR_VOUCHER + "(" + moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL, row_num] + ")");
                        return false;
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckDetail)");
            }

            return return_value;
        }

        private bool FormCheckExtra()                                                              // validate extra other than the header and detail.
        {
            bool return_value = false;
            string sql_str = "";
            decimal amt_unused = 0;

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.CHECK_TYPE_NUM)
                {
                    sql_str = "SELECT * FROM tblAPPaymentUnposted ";
                    sql_str += " WHERE iTransaction_typ = " + moPage.iTransaction_typ.ToString() + " AND iTransaction_num <> " + Header.txtKey_id;
                    sql_str += " AND sCashAcct_cd = '" + Header.mskCashAcct_cd + "' AND sDocument_num = '" + Header.txtDocument_num + "'";
                    sql_str += " AND iCash_typ = " + moUtility.ToInteger(Header.cboPayment_typ).ToString();
                    if (cur_set.CreateSnapshot(sql_str) == false)
                    {
                        FormShowMessage();
                        return false;
                    }
                    else if (cur_set.EOF())
                    {
                        sql_str = moUtility.SReplace(sql_str, "tblAPPaymentUnposted", "tblAPPayment");
                        if (!cur_set.CreateSnapshot(sql_str))
                        {
                            FormShowMessage();
                            return false;
                        }
                    }
                    if (cur_set.RecordCount() > 0)
                    {
                        FormShowMessage("CHK# " + Header.txtDocument_num + User.Language.oMessage.IS_ALREADY_USED_BY + User.Language.oString.STR_PAYMENT + "# " + cur_set.iField("iTransaction_num").ToString() + ".");
                        return false;
                    }
                }

                // 06/19/2018 Negative vouchers/Invoices - we allow Negative vouchers/Invoices from now on.
                //If moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.OPEN_TRX_NUM And moMoney.ToNumMoney(txtPaid_amt.Text) < moDatabase.mSmallestMoney_amt Then
                if (moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.OPEN_TRX_NUM && moMoney.ToNumMoney(Header.txtPaid_amt) < 0)
                {
                    FormShowMessage(User.Language.oMessage.PAYMENT_SHOULD_BE_POSITIVE);
                    return false;
                }

                if (moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.OPEN_TRX_NUM && moUtility.ToInteger(Header.cboPayment_typ) != GlobalVar.goConstant.MEMO_TYPE_NUM 
                    && moMoney.ToNumMoney(Header.txtPaid_amt) > moMoney.ToNumMoney(Header.lblTotalUsed_amt))
                {

                    if (moMoney.ToNumMoney(Header.txtPaid_amt) <= 0)
                    {
                        FormShowMessage(User.Language.oMessage.YOU_CANNOT_SAVE_THIS_RECORD);
                        return return_value;
                    }

                    if (moUtility.ToInteger(Header.cboPayment_typ) != GlobalVar.goConstant.MEMO_TYPE_NUM && moMoney.ToNumMoney(Header.txtPaid_amt) > moMoney.ToNumMoney(Header.lblTotalUsed_amt))
                    {
                        amt_unused = moMoney.ToNumMoney(Header.txtPaid_amt) - moMoney.ToNumMoney(Header.lblTotalUsed_amt);

                        if (BalanceForward == false)
                        {
                            if (moPage.bInPrinting_fl)
                            {
                                if (FormDialog(btnPrint_Clicked, 1000, User.Language.oMessage.UNUSED_AMT_GOES_TO_DEPOSIT + " ($" + moMoney.ToStrMoney(amt_unused) + ").") == false)
                                {
                                    return false;
                                }
                            }
                            else
                            {
                                if (FormDialog(btnSave_Clicked, 1000, User.Language.oMessage.UNUSED_AMT_GOES_TO_DEPOSIT + " ($" + moMoney.ToStrMoney(amt_unused) + ").") == false)
                                {
                                    return false;
                                }
                            }
                        }
                    }
                }

                // Custom fields
                //
                if (moCustomFields.CheckValues(moDatabase) == false)
                {
                    FormShowMessage(moCustomFields.GetErrorMessage());
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckExtra)");
            }

            return return_value;
        }

        private bool FormCheckHeader()                                                             // validate the header data.
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
                FormSyncDates(User.bUseDatePicker_fl);

                // GENERIC VALIDATIONS FOR ALL TRASNACTIONS
                //
                msFund_cd = GlobalVar.goFund.GetSelectedFundCodeToSave(ref moDatabase, Header.cboFund_cd);
                FormSyncDates(User.bUseDatePicker_fl);

                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormShowMessage(User.Language.oString.STR_TRANSACTION_NUMBER + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("txtKey_id");
                    return false;
                }
                if (moDatabase.bFundAccounting_fl && moUtility.IsEmpty(msFund_cd))
                {
                    FormShowMessage(User.Language.oCaption.FUND_CODE + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("cboFund_cd");
                    return false;
                }
                if (moUtility.ToInteger(Header.cboStatus_typ) == 0)
                {
                    FormShowMessage(User.Language.oMessage.STATUS_HAS_TO_BE_SELECTED);
                    FormSetFocus("cboStatus_typ");
                    return false;
                }
                if (moUtility.IsBlankDate(Header.mskEntry_dt))
                {
                    FormShowMessage(User.Language.oMessage.ENTRY_DATE_IS_REQUIRED);
                    FormSetFocus("mskEntry_dt");
                    return false;
                }
                if (modCommonUtility.ValidEntryDate(ref moDatabase, ref Header.mskEntry_dt) == false)
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_A_VALID_DATE_ENTERED);
                    FormSetFocus("mskEntry_dt");
                    return false;
                }

                // In order to simplify the commitment mechanism, clear the money field.
                //
                if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM && moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.VOID_TRX_NUM)
                {
                    Header.txtPaid_amt = "";
                    Header.lblTotalUsed_amt = "";
                    Header.cboPayment_typ = "";
                    Header.txtDocument_num = "";
                    Header.txtVendor_cd = "";
                    FormClearDetail();
                    Header.mskApply_dt = Header.mskEntry_dt;
                    FormSyncDates(false);
                    return true;
                }
                if (moUtility.ToInteger(Header.cboStatus_typ) != GlobalVar.goConstant.OPEN_TRX_NUM)
                {
                    if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM && moMoney.ToNumMoney(Header.txtPaid_amt) > moMoney.ToNumMoney(Header.lblTotalUsed_amt)) // do not delete this.
                    {
                        Header.txtPaid_amt = Header.lblTotalUsed_amt;
                    }
                    if (moUtility.IsEmpty(Header.mskApply_dt))
                    {
                        Header.mskApply_dt = Header.mskEntry_dt;
                        FormSyncDates(false);
                    }
                    return true;
                }

                if (moUtility.IsBlankDate(Header.mskApply_dt))
                {
                    FormShowMessage(User.Language.oCaption.APPLY_DATE + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("mskApply_dt");
                    return false;
                }
                if (modCommonUtility.ValidApplyDate(ref moDatabase, ref Header.mskApply_dt) == false)
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_A_VALID_DATE_APPLIED);
                    FormSetFocus("mskApply_dt");
                    return false;
                }

                Header.txtDocument_num = moUtility.EvalQuote(moUtility.STrim(Header.txtDocument_num));

                if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM && moUtility.ToInteger(Header.txtDocument_num) <= 0)
                {
                    Header.txtDocument_num = "";
                }

                // Because the memo amount is committed for HOLD status, vendor code is require for holding
                //
                if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM && moUtility.IsEmpty(Header.txtVendor_cd))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_A_VENDOR_CODE);
                    FormSetFocus("txtVendor_cd");
                    return false;
                }
                if (moUtility.ToInteger(Header.cboPayment_typ) == 0)
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_SELECT_A_PAYMENT_TYPE);
                    return false;
                // ElseIf moMoney.ToNumMoney(Header.txtPaid_amt) <= 0 Then   ' 06/19/2018 Negative vouchers/Invoices - we allow Negative vouchers/Invoices from now on.
                }
                else if (moMoney.ToNumMoney(Header.txtPaid_amt) < 0) // This will allow the write-off with discount without actual payment.
                {
                    FormShowMessage(User.Language.oMessage.PAYMENT_SHOULD_BE_POSITIVE);
                    FormSetFocus("txtPaid_amt");
                    return false;
                }
                else if (moMoney.ToNumMoney(Header.txtPaid_amt) < moMoney.ToNumMoney(Header.lblTotalUsed_amt))
                {
                    FormShowMessage(User.Language.oMessage.PAYMENT_IS_OVER_APPLIED);
                    FormSetFocus("txtPaid_amt");
                    return false;
                }

                if (moUtility.IsEmpty(Header.mskCashAcct_cd))
                {
                    if (UseComboboxForCashAccount)
                    {
                        FormShowMessage(User.Language.oMessage.PLEASE_SELECT_A_BANK_ACCOUNT);
                        FormSetFocus("cboCashAcct_cd");
                    }
                    else
                    {
                        FormShowMessage(User.Language.oMessage.PLEASE_ENTER_AN_ACCOUNT_CODE);
                        FormSetFocus("mskCashAcct_cd");
                    }
                    return false;
                }

                if (moUtility.QualifiedTenderForCheckRegister(moUtility.ToInteger(Header.cboPayment_typ)))
                {
                    if (moUtility.IsEmpty(Header.txtDocument_num))
                    {
                        FormShowMessage(User.Language.oMessage.PLEASE_ENTER_THE_DOCUMENTCHECK_NUMBER);
                        FormSetFocus("txtDocument_num");
                        return false;
                    }
                    else if (Header.txtDocument_num != moUtility.ToInteger(Header.txtDocument_num).ToString() || moUtility.ToInteger(Header.txtDocument_num) <= 0)
                    {
                        FormShowMessage(DocumentLabel + User.Language.oMessage.IS_INVALID);
                        FormSetFocus("txtDocument_num");
                        return false;
                    }
                }


                //  If this using deposit amount, used-amount should equal payment-amount.
                //  Otherwise, send the delta amount to the deposit account.
                //
                if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM)
                {
                    Header.txtPaid_amt = Header.lblTotalUsed_amt;
                }


                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckHeader)");
            }

            return return_value;
        }

        private bool FormCheckConcurrency(clsRecordset cur_set)                                    // Check if someone has changed this record while it is open in this session.
        {

            return true;
        }

        private bool FormCheckToDelete()
        {
            
            return true;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearDetail();
            FormClearExtra();

            return true;
        }

        private bool FormClearDetail()                                                             // Clear the detail.
        {
            moDetail.iTotalRows = 1; // User.iLinesToIncrease;
            moUtility.ResizeDim(ref moDetail.Data, Models.clsPaymentDetail.TOTAL_COLUMNS - 1, moDetail.iTotalRows - 1);

            FormRecreateGrid();

            return true;
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            msHoldStatusMessage = "";
            miVendorBalance_typ = 0;
            mbPaymentEntered_fl = false;
            mmTotalDiscount_amt = 0;
            DocumentNumberList.Clear();
            moVendor.ClearVendor();

            // Custom Fields
            //
            moCustomFields.ClearGrid();

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {
            Header.txtKey_id = "";
            Header.cboStatus_typ = "";
            Header.txtPaid_amt = "";
            Header.txtVendor_cd = "";
            Header.txtDescription = "";
            Header.txtReference = "";
            Header.mskCashAcct_cd = "";
            Header.txtDocument_num = "";
            Header.txtFace_nm = "";
            Header.cboPayment_typ = "";
            Header.lblVendor_nm = "";
            Header.lblTotalUsed_amt = "";
            Header.lblNewBalanceDue_amt = "";
            Header.lblTotalBalance_amt = "";
            Header.lblPayTo_cd = "";
            Header.txtBatch_num = "";
            Header.cboDocument_num = "";

            Header.txtUserApproved_cd = "";
            Header.txtToApprove_num = "";

            Header.lblTolerance_amt = "";

            Header.mskApply_dt = "";
            Header.mskEntry_dt = "";
            FormSyncDates(false);

            return true;
        }

        private bool FormClearMessage()
        {
            moPage.Message.Clear();

            return true;
        }

        public bool FormCommitTransaction()
        {

            bool return_value = false;

            return_value = moDeposit.CommitPayment(ref moDatabase, moPage.iTransaction_typ, GlobalVar.goUtility.ToInteger(Header.txtKey_id), GlobalVar.goUtility.ToInteger(Header.cboStatus_typ)
                , GlobalVar.goUtility.ToInteger(Header.cboPayment_typ), Header.txtVendor_cd, moDatabase.sCurrency_cd, GlobalVar.goUtility.ToInteger(Header.txtDocument_num), moMoney.ToNumMoney(Header.lblTotalUsed_amt));

            return return_value;

        }


        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            moPage.bInDialog_fl = true;         // Meaning a dialog started

            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    moPage.bInDialog_fl = false;            // Meaning a dialog is enidng with Cancel button
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }

                Modal.Release();                                                                   // Release this call and proceed.
            }

            moPage.bInDialog_fl = false;            // Meaning a dialog is enidng with Cancel button
            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id) || moPage.bNew_fl)
                {
                    FormClear();
                    return true;
                }
                else if (FormCheckToDelete() == false)
                {
                    return false;
                }

                // Transaction begins here.
                //
                if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }

                if (modFormUtility.RecordDelete(ref moDatabase, moPage.iScreen_typ, Header.txtKey_id, moPage.sKeyField_nm, moPage.sTable_nm, moPage.sDetailTable_nm, moPage.sRestrictionClause, moPage.iTransaction_typ) == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }
                else if (FormDeleteExtra() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }

                // Transaction ends here.
                //
                if (moDatabase.TransactionCommit() == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDelete)");
                moDatabase.TransactionRollback();
                return_value = false;
            }

            return return_value;
        }

        private bool FormDeleteExtra()
        {

            return true;
        }

        private bool FormEnableBatch(bool switch_fl = true)
        {

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (switch_fl)
            {
                moBatch.ToggleBatch(ref moDatabase);
            }

            User.bBatchEnabled_fl = moDatabase.AllowBatchEntry();
            User.iBatch_num = moDatabase.CurrentBatch;

            moBatch.ShowBatch(moDatabase);

            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormFindRecord(ref clsRecordset cur_set, int matching_type = 0)
        {
            bool return_value = false;

            matching_type = (int)(moUtility.IIf(matching_type > 0, matching_type, GlobalVar.goConstant.MATCHING_RECORD_TYPE));
            return_value = modFormUtility.RecordRead(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sTable_nm, moPage.sKeyField_nm, moPage.sPreviousKey_id, moPage.sRestrictionClause, ref matching_type);

            return return_value;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListingPayment();
            moSearch = new Models.clsListingPayment();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moMoney = new clsMoney(ref moDatabase);
            moBatch = new clsBatch();

            moDetail = new Models.clsPaymentDetail();
            moTransactionPayment = new clsTransactionPayment(ref moDatabase);
            moCashPayment = new clsCashPayment(ref moDatabase);
            moReport = new clsReportViewer();
            moCustomFields = new Models.clsCustomField();
            moVendor = new clsVendor(ref moDatabase);
            moDeposit = new clsDeposit();
            moSession = new Models.clsSession();
            moInquiry = new clsInquiry();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.APMENU_NAME;
            moPage.Title = User.Language.oCaption.CASH_PAYMENT_ENTRY;
            moPage.iScreen_typ = GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE;
            moPage.iTransaction_typ = GlobalVar.goConstant.TRX_PAYMENT_TYPE;

            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormInitHeader();
            FormInitDetail();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitDetail()                                                              // Initialize the page at loading.  Only once.
        {
            // Detail table name.
            //
            moPage.sDetailTable_nm = "tblAPPaymentDetUnposted";

            moUtility.ResizeDim(ref moDetail.Data, Models.clsPaymentDetail.TOTAL_COLUMNS - 1, 0);    // These initializations are necessary

            FormClearDetail();

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = "tblAPPaymentUnposted";
            moPage.sKeyField_nm = "iTransaction_num";

            return true;
        }

        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {
            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            // FormSave() & FormCheck() use the plain box whose name starts with "msk"
            // dt* variables are only to interact with UI.  Internally, msk* fields are used.
            //
            FormSyncDates(User.bUseDatePicker_fl);

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();
            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtApply_dt, ref Header.mskApply_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtEntry_dt, ref Header.mskEntry_dt, use_date_picker);

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback

            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;
            clsCustomization custom_fields = new clsCustomization(ref moDatabase);

            try
            {
                if (FormReceiveValues() == false)                    // All pages that use session value need to capture it here before FormOpenDatabase()
                {
                    return false;
                }
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                modLoadUtility.LoadPaymentType(ref moDatabase, ref PaymentTypeList, false, false, false, false,false,false, moDatabase.uProgram.bBRExist_fl);   // If B/R is incorported, cash payment is not allowed
                modLoadUtility.LoadStatusType(ref moDatabase, ref StatusTypeList);

                modLoadUtility.LoadListingBy(ref moDatabase, ref ListingByList, moPage.iTransaction_typ, User);

                if (moDatabase.uSecurity.bUseComboboxForCashAccount_fl)
                {
                    modLoadUtility.LoadBankAccount(ref moDatabase, ref CashAccountList, false, false);
                }

                FormEnableBatch(false);

                // Custom Fields
                //
                if (custom_fields.ReadCustomInfo(moPage.iTransaction_typ, ""))
                {
                    moCustomFields.CreateGrid(custom_fields.sField_nm, custom_fields.sCaptions, custom_fields.bRequired);
                }

                if (moUtility.IsNonEmpty(moPage.sInitialKey_id))
                {
                    Header.txtKey_id = moPage.sInitialKey_id;
                    txtKey_id_Changed();
                }

                User.bConnected_fl = true;

                FormSwitchView(moView.MAIN_PAGE_NUM);
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormMove(int record_move_direction)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormClear();

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            if (FormFindRecord(ref cur_set, record_move_direction) == false)
            {
                return false;
            }

            FormShow(cur_set);
            return true;

        }

        private bool FormPostSave()
        {
            // If this is a transaction page, and transaction number has changed, let the user know.
            //
            if (moPage.sPreviousKey_id != Header.txtKey_id)
            {
                FormShowMessage(User.Language.oMessage.TRX_NUM_HAS_CHANGED_TO + "  " + Header.txtKey_id, false);
            }

            moPage.sPreviousKey_id = Header.txtKey_id;

            return true;
        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostTransactionRealtime()
        {
            int number_failed = 0;
            string posting_error = "";

            if (moDatabase.bRealTimeMode == false || moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.HOLD_TRX_NUM)
            {
                return true;
            }

            if (moGeneral.ApplyDateIsOkToPost(moGeneral.ToNumDate(Header.mskApply_dt), false) == false)
            {
                FormShowMessage(Header.mskApply_dt + User.Language.oMessage.IS_INVALID_FOR_POSTING);
                return false;
            }

            if (modPostUtility.PostOneTransaction(ref moDatabase, 0, 0, moGeneral.ToNumDate(Header.mskApply_dt), moGeneral.ToNumDate(Header.mskApply_dt)
                                , moUtility.ToInteger(Header.txtKey_id), moUtility.ToInteger(Header.txtKey_id), moPage.iTransaction_typ, posting_error, false, ref number_failed) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {
            // Put some extra validation against the existing record
            // before saving the current modification.
            //

            if (chkAfterFact_fl)
            {
                // A.f.t. transactions should have a number non-existing number less than the current transaction number in the system.
                // Duplicate entry will be checked in clsVoucher.
                //
                if (moPage.bNew_fl)
                {
                    if (moUtility.ToInteger(Header.txtKey_id) >= modGeneralUtility.ReadNextTransactionNumber(ref moDatabase, moPage.iTransaction_typ))
                    {
                        FormShowMessage(Header.txtKey_id + User.Language.oMessage.IS_INVALID);
                        return false;
                    }
                }
            }
            else if (modGeneralUtility.CheckTransactionNumber(ref moDatabase, moPage.bNew_fl, moPage.iScreen_typ, moPage.iTransaction_typ, ref Header.txtKey_id) == false)
            {
                return false;
            }

            // Someone could have saved with the same number.
            //
            if (moPage.bNew_fl && Header.txtKey_id != moPage.sPreviousKey_id)
            {
                cur_set.Release();
            }

            // moVoucher.oSerial = moSerial;

            return true;
        }
        private bool FormPrint()
        {
            bool return_value = false;

            if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.CHECK_TYPE_NUM)
            {
                return PrintCheck();
            }

            // All other payment methods need to print R/A so that it has to be saved first.
            //
            if (FormSave(true) == false)   
            {
                return false;
            }

            return PrintRemittanceAdvice();
        }


        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormRecreateDetail()
        {
            if (moDetail.RecreateDetail() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateDetailLine(Models.clsPaymentDetail.clsGrid cur_item, int row_num = -1)
        {
            if (moDetail.RecreateDetailLine(cur_item, row_num) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateGrid()
        {
            if (moDetail.RecreateGrid() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }
        private bool FormReceiveValues()
        {
            // If connected already, return true.  This means this page came through the menu system.
            //
            if (moUtility.IsNonEmpty(User.sServer_nm) || moDatabase.IsConnected())
            {
                return true;
            }

            // Otherwise, need to login with the info passed from the calling page.
            //
            if (modGeneralUtility.GetPassedParameters(StarterValue, User, moSession) == false)
            {
                FormShowMessage(User.Language.oMessage.PLEASE_LOG_IN_FIRST);
                return false;
            }

            moPage.sInitialKey_id = moSession.Value.Entity;

            return true;
        }

        private bool FormSave(bool from_printing_fl)
        {
            bool return_value = false;
            clsRecordset cur_set;

            try
            {
                if (FormOpenDatabase() == false)                     // Has to come before FormCheck()
                {
                    return false;
                }

                //  Skip this if called from printing because it is already done.
                //
                if (from_printing_fl ==  false)
                {
                    if (FormCheck() == false)                       
                    {
                        return false;
                    }
                }

                moPage.sPreviousKey_id = Header.txtKey_id;
                cur_set = new clsRecordset(ref moDatabase);

                if (modFormUtility.RecordOpen(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sRestrictionClause, moPage.sTable_nm, moPage.sKeyField_nm) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormCheckConcurrency(cur_set) == false)
                {
                    return false;
                }
                else if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormPreSave(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormCommitTransaction() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveHeader(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveExtra(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveDetail() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (moCashPayment.SaveTransaction(ref cur_set) == false)
                {
                    FormShowMessage();
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormPostTransactionRealtime() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (moDatabase.TransactionCommit() == false)
                {
                    FormShowMessage();
                    moDatabase.TransactionRollback();
                    return false;
                }

                FormPostSave();

                return_value = true;

            }
            catch (Exception ex)
            {

                FormShowMessage(ex.Message + " (FormSave)");
                moDatabase.TransactionRollback();

            }

            return return_value;
        }

        private bool FormSaveDetail()
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
                return_value = SyncCashPayment();
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveDetail)");
            }

            return return_value;
        }

        private bool FormSaveExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {

                mbListingInitiated_fl = false;                  // Will let the listing refresh

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormSaveHeader(clsRecordset cur_set)
        {
            bool return_value = false;
            string sql_str = null;

            try
            {

                moCashPayment.bNew_fl = (moPage.bNew_fl || cur_set.EOF());

                // This is for Concurrency check to go smooth.
                // If someone calls FormSave() without going thru the whole saving routine that
                // clears the screen, and save again later, then FormCheckConcurrency() will raise an error
                // because the record in the database has been updated but moPage.Original.dtLastUpdate_dt still has the old timestamp.
                //
                moPage.Original.sLastUpdate_id = moDatabase.sUser_cd;
                moPage.Original.dtLastUpdate_dt = DateTime.Now;

                moCashPayment.iTransaction_typ = moPage.iTransaction_typ;
                moCashPayment.iTransaction_num = moUtility.ToInteger(Header.txtKey_id);
                moCashPayment.sFund_cd = GlobalVar.goFund.GetSelectedFundCodeToSave(ref moDatabase, Header.cboFund_cd);
                moCashPayment.iStatus_typ = moUtility.ToInteger(Header.cboStatus_typ);
                moCashPayment.iCash_typ = moUtility.ToInteger(Header.cboPayment_typ);
                moCashPayment.iBatch_num = moUtility.IIf(moPage.bNew_fl, moDatabase.iBatch_num, moUtility.ToInteger(Header.txtBatch_num));
                moCashPayment.iApply_dt = moGeneral.ToNumDate(Header.mskApply_dt);
                moCashPayment.iEntry_dt = moGeneral.ToNumDate(Header.mskEntry_dt);
                moCashPayment.mPaid_amt = moMoney.ToNumMoney(Header.txtPaid_amt);
                moCashPayment.mUsed_amt = moMoney.ToNumMoney(Header.lblTotalUsed_amt);
                moCashPayment.sVendor_cd = Header.txtVendor_cd;
                moCashPayment.sDescription = Header.txtDescription;
                moCashPayment.sReference = Header.txtReference;
                moCashPayment.sCashAcct_cd = Header.mskCashAcct_cd;
                moCashPayment.sDocument_num = Header.txtDocument_num;
                moCashPayment.sOnDocument_nm = Header.txtFace_nm;
                moCashPayment.sPayTo_cd = Header.lblPayTo_cd;
                moCashPayment.sUserApproved_cd = Header.txtUserApproved_cd;
                moCashPayment.iToApprove_num = moUtility.ToInteger(Header.txtToApprove_num);
                moCashPayment.sVendor_nm = Header.lblVendor_nm;

                // Attach the custom field list
                //
                moCashPayment.CustomFieldList = moCustomFields.GetFieldList();
                moCashPayment.CustomValueList = moCustomFields.GetValueList(moDatabase);
                moCashPayment.CustomUpdateList = moCustomFields.GetUpdateList(moDatabase);

                moCashPayment.sCreator_id = moPage.Original.sLastUpdate_id;
                moCashPayment.sLastUpdate_id = moPage.Original.sLastUpdate_id;
                moCashPayment.dtLastUpdate_dt = moPage.Original.dtLastUpdate_dt;


                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveHeader)");
            }

            return return_value;
        }

        private bool FormSearch()
        {
            string search_detail = "";
            string where_clause = GetSearchCriteria();

            if (moUtility.IsEmpty(where_clause))
            {
                where_clause = search_detail;
            }
            else
            {
                where_clause += moUtility.IIf(moUtility.IsNonEmpty(search_detail), " AND ", "") + search_detail;
            }

            if (moUtility.IsEmpty(where_clause))
            {
                FormShowMessage(User.Language.oMessage.PLEASE_ENTER_THE_SEARCH_CRITERIA_ON_THE_MAIN_ENTRY_TAB);
                return false;
            }


            mbSearchPopulated_fl = false;

            where_clause = moUtility.IIf(moUtility.IsNonEmpty(moPage.sRestrictionClause), moPage.sRestrictionClause, "iTransaction_typ = " + moPage.iTransaction_typ.ToString()) + " AND " + where_clause;

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            //where_clause = modCommonUtility.AddCommonTransactionSearchClause(where_clause, moPage.iTransaction_typ, cboSearchYear);

            if (moSearch.Show(moDatabase, moPage, where_clause) == false)
            {
                FormShowMessage();
                return false;
            }

            mbSearchInitiated_fl = true;
            mbSearchPopulated_fl = (moSearch.Grid.Count > 0);

            if (mbSearchPopulated_fl == false)
            {
                FormShowMessage(User.Language.oMessage.NO_MATCHING_RECORDS_FOUND);
            }

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {
            if (FormShowHeader(cur_set) == false)
            {
                return false;
            }
            else if (FormShowExtra(cur_set) == false)
            {
                return false;
            }
            else if (FormShowDetail() == false)
            {
                return false;
            }

            FormReArrangeHeader();

            return true;
        }

        private bool FormShowDetail()
        {
            bool return_value = false; ;
            string sql_str = "";
            int row_num = 0;
            decimal disc_avail = 0;
            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                FormClearDetail();

                sql_str = "SELECT p.*, c.sFund_cd, c.iDue_dt, c.sYourReference, c.iInvoice_dt FROM tblAPPaymentDetUnposted p ";
                sql_str += " LEFT JOIN tblAPCharge c ON (p.iAppliedTransaction_typ = c.iTransaction_typ AND p.iAppliedTransaction_num = c.iTransaction_num)";
                sql_str += " WHERE p.iTransaction_typ = " + moPage.iTransaction_typ.ToString();
                sql_str += " AND p.iTransaction_num = " + Header.txtKey_id;
                sql_str += " ORDER BY p.iDetail_num";
                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    return false;
                }
                else if (cur_set.EOF())
                {
                    return true;
                }

                moDetail.iTotalRows = cur_set.RecordCount();
                moUtility.ResizeDim(ref moDetail.Data, Models.clsPaymentDetail.TOTAL_COLUMNS - 1, moDetail.iTotalRows - 1);

                for (row_num = 0; row_num < moDetail.Data.GetLength(1); row_num++)
                {
                    moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, row_num] = GlobalVar.goConstant.CHECKED_ON.ToString();

                    moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL, row_num] = cur_set.iField("iAppliedTransaction_num").ToString();
                    moDetail.Data[Models.clsPaymentDetail.TOTAL_AMT_COL, row_num] = moMoney.ToStrMoney(cur_set.mField("mTotal_amt"));
                    moDetail.Data[Models.clsPaymentDetail.TOTAL_PAID_COL, row_num] = moMoney.ToStrMoney(cur_set.mField("mPaid_amt"));
                    moDetail.Data[Models.clsPaymentDetail.BALANCE_DUE_COL, row_num] = moMoney.ToStrMoney(cur_set.mField("mDue_amt"));
                    moDetail.Data[Models.clsPaymentDetail.DISC_AVAIL_COL, row_num] = moMoney.ToStrMoney(cur_set.mField("mDiscAvail_amt"));
                    moDetail.Data[Models.clsPaymentDetail.DISC_TAKEN_COL, row_num] = moMoney.ToStrMoney(cur_set.mField("mDiscGiven_amt"));
                    moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num] = moMoney.ToStrMoney(cur_set.mField("mCurPayment_amt"));
                    moDetail.Data[Models.clsPaymentDetail.TOTAL_RETURNED_COL, row_num] = moMoney.ToStrMoney(cur_set.mField("mReturned_amt"));
                    moDetail.Data[Models.clsPaymentDetail.DUE_DATE_COL, row_num] = moGeneral.ToStrDate(cur_set.iField("iDue_dt"));
                    moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_DATE_COL, row_num] = moGeneral.ToStrDate(cur_set.iField("iInvoice_dt"));
                    moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_TYPE_COL, row_num] = cur_set.iField("iAppliedTransaction_typ").ToString();
                    moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_DETAIL_COL, row_num] = cur_set.iField("iAppliedTransactionDetail_num").ToString();
                    moDetail.Data[Models.clsPaymentDetail.INVOICE_NUM_COL, row_num] = cur_set.sField("sYourReference");

                    cur_set.MoveNext();
                }

                FormRecreateGrid();
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormShowDetail)");
            }

            return return_value;
        }

        private bool FormShowExtra(clsRecordset cur_set)
        {
            bool return_value = false;
            string tmp = "";
            clsApproval o_approval = new clsApproval(ref moDatabase);

            try
            {
                moPage.Clear();
                moPage.PreserveTimestamp(cur_set);
                moPage.bNew_fl = false;

                // This is where bReadOnly_fl & bReserved_fl are set according to the nature of the current record.
                //

                mbPaymentEntered_fl = true;

                msHoldStatusMessage = GlobalVar.goStatus.HoldingStatusTypeText(cur_set.iField("iHoldStatus_typ"));

                if (cur_set.iField("iHoldStatus_typ") > 0)
                {
                    msHoldStatusMessage += o_approval.GetPendidngStatus(cur_set.iField("iTransaction_typ"), cur_set.iField("iTransaction_num"));
                }

                moVendor.ClearVendor();

                if (!moVendor.GetVendor(Header.txtVendor_cd, true))
                {
                    FormShowMessage(Header.txtVendor_cd + User.Language.oMessage.IS_INVALID);
                    Header.txtVendor_cd = "";
                }
                else
                {
                    Header.lblVendor_nm = moVendor.sVendor_nm;
                    Header.lblTotalBalance_amt = moMoney.ToStrMoney(moVendor.mBalanceDue_amt);
                }

                miVendorBalance_typ = moVendor.iBalance_typ;

                if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM)
                {
                    if (GetMemoAvailable())
                    {
                        Header.cboDocument_num = moUtility.IIf(moUtility.IsEmpty(Header.txtDocument_num) || Header.txtDocument_num == User.Language.oString.STR_DEPOSIT, "0", Header.txtDocument_num);
                        tmp = Header.lblTotalUsed_amt;
                        cboDocument_num_Clicked();
                        Header.lblTotalUsed_amt = tmp;
                    }
                }

                if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM)
                {
                    mbPaymentEntered_fl = true; // the amount is fixed.
                }
                else
                {
                    mbPaymentEntered_fl = false; // Since we are making a payment, the amount is not fixed, most likely.
                }

                moPage.sPreviousKey_id = Header.txtKey_id;
                Header.Preserve();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
            }

            return return_value;
        }

        private bool FormShowHeader(clsRecordset cur_set)
        {
            Header.txtKey_id = cur_set.sField(moPage.sKeyField_nm);
            Header.cboStatus_typ = cur_set.iField("iStatus_typ").ToString();
            Header.cboFund_cd = GlobalVar.goFund.GetSelectedFundCodeToDisplay(ref moDatabase, cur_set.sField("sFund_cd"));

            Header.cboPayment_typ = cur_set.iField("iCash_typ").ToString();
            Header.txtBatch_num = cur_set.iField("iBatch_num").ToString();
            Header.mskApply_dt = moGeneral.ToStrDate(cur_set.iField("iApply_dt"));
            Header.mskEntry_dt = moGeneral.ToStrDate(cur_set.iField("iEntry_dt"));
            Header.txtPaid_amt = moMoney.ToStrMoney(cur_set.mField("mPaid_amt"));
            Header.lblTotalUsed_amt = moMoney.ToStrMoney(cur_set.mField("mUsed_amt"));
            Header.txtVendor_cd = cur_set.sField("sVendor_cd");
            Header.txtDescription = cur_set.sField("sDescription");
            Header.txtReference = cur_set.sField("sReference");
            Header.mskCashAcct_cd = cur_set.sField("sCashAcct_cd");
            Header.txtDocument_num = cur_set.sField("sDocument_num");
            Header.txtFace_nm = cur_set.sField("sOnDocument_nm");

            Header.txtUserApproved_cd = cur_set.sField("sUserApproved_cd");
            Header.txtToApprove_num = cur_set.iField("iToApprove_num").ToString();

            FormSyncDates(false);

            // Custom Fields
            //
            moCustomFields.SetValues(moDatabase, cur_set);

            return true;
        }

        private bool FormShowListing()
        {
            string where_clause = "";


            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (mbListingInitiated_fl)
            {
                return true;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moListing.Show(moDatabase, moPage, where_clause, cboListingBy) == false)
            {
                FormShowMessage();
                return false;
            }

            mbListingInitiated_fl = true;
            mbListingPopulated_fl = (moListing.Grid.Count > 0);

            return true;

        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);

            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moZoom.Caller == "txtVendor_cd")
            {
                if (moZoom.Vendor(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            else if (moZoom.Caller == "mskCashAcct_cd")
            {
                if (moZoom.Account(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
                {
                    return false;
                }
            }

            FormCancel();
            return true;
        }

        private bool btnDelete_Clicked()
        {
            FormPreEvent();

            if (FormDialog(btnDelete_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_DELETE) == false)
            {
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (FormDelete() == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }

        private bool btnFirst_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnFirst_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.FIRST_RECORD_TYPE);
        }

        private bool btnLast_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnLast_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.LAST_RECORD_TYPE);
        }

        private bool btnNext_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnNext_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.NEXT_RECORD_TYPE);
        }

        private bool btnPrevious_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnPrevious_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.PREVIOUS_RECORD_TYPE);
        }

        private bool btnSave_Clicked()
        {
            FormPreEvent();

            if (moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.VOID_TRX_NUM)
            {
                if (FormDialog(btnSave_Clicked, 10, User.Language.oMessage.ARE_YOU_SURE_TO_VOID) == false)
                {
                    return false;
                }
            }

            if (FormSave(false) == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        private bool btnPrint_Clicked()
        {
            if (moPage.bInDialog_fl == false)           // While in dialog, do not call FormPreEvent() which will remove the possible message displayed in printing process
            {
                FormPreEvent();
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormRecreateDetail();                       // Make sure Data[] and Grid are in Sync

            // This flag sould be set before FormCheck() because of FormDialog() called in in FormCheck().
            //
            moPage.bInPrinting_fl = true;

            // Should save/print for the first time only.  When comming back from dialog, need to skip.
            //
            if (Modal.ReturningTo(10000) == false)
            {
                if (FormCheck() == false)
                {
                    return false;
                }

                if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.CHECK_TYPE_NUM && moMoney.ToNumMoney(Header.txtPaid_amt) > 10000000)
                {
                    FormShowMessage(User.Language.oMessage.MAX_AMOUNT_YOU_CAN_PRINT_IS + " 10,000,000.");     // Cannot print more than this on the check.
                    return false;
                }

                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

                if (FormPrint() == false)
                {
                    return false;
                }
            }

            if (FormDialog(btnPrint_Clicked, 10000, User.Language.oMessage.IS_PRINTED_OK) == false)
            {
                return false;
            }

            if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.CHECK_TYPE_NUM)                  // All other types are already saved in PrintRemittanceAdvice().
            {
                if (FormSave(true) == false)
                {
                    return false;
                }
            }

            moPage.bNew_fl = false;
            moPage.bInPrinting_fl = false;

            FormSwitchView(moView.MAIN_PAGE_NUM);

            FormClear();

            return FormPostEvent();
        }

        private bool cmdCancelOnSearch_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return FormPostEvent();
        }

        private bool btnSearchToPrint_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateSearchHTML();

            return FormPostEvent();
        }

        private bool btnSearchToExcel_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateSearchExcel();

            return FormPostEvent();
        }

        private bool btnListingToPrint_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateListingHTML();

            return FormPostEvent();
        }

        private bool btnListingToExcel_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateListingExcel();

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewHeader_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool cmdViewListing_Clicked()
        {
            FormPreEvent();

            if (FormShowListing() == false)
            {
                return false;
            }

            FormSwitchView(moView.LISTING_PAGE_NUM);
            return true;

        }

        private bool cmdViewSearch_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.SEARCH_PAGE_NUM);

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnListingSelect_Clicked(Models.clsListingPayment.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.ToInteger(cur_item.Transaction_num) <= 0)   // May have a string such as TOTAL
            {
                return false;
            }

            FormClear();
            Header.Tag.txtKey_id = "";
            Header.txtKey_id = cur_item.Transaction_num;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnSearchSelect_Clicked(Models.clsListingPayment.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.IsEmpty(cur_item.Transaction_num))
            {
                return false;
            }

            FormClear();
            Header.txtKey_id = cur_item.Transaction_num;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                code_selected = cur_item.Col_0;

                if (moZoom.Caller == "txtVendor_cd")
                {
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    Header.txtVendor_cd = code_selected;
                    return txtVendor_cd_Changed();
                }
                else if (moZoom.Caller == "mskCashAcct_cd")
                {
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    Header.mskCashAcct_cd = code_selected;
                    return mskCashAcct_cd_Changed();
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }

        private bool btnZoomOnKey_id_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdSearch_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormSearch() == false)
            {
                return false;
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool cmdNew_Clicked()
        {
            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (chkAfterFact_fl)            // For A.F.T, New button should be disabled.
            {
                return false;
            }

            FormClear();

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            // Get the next transaction number.  This would not consume the number.  FormSave() will consume the number.
            //
            Header.txtKey_id = modGeneralUtility.ReadNextTransactionNumber(ref moDatabase, moPage.iTransaction_typ).ToString();

            if (moUtility.ToInteger(Header.txtKey_id) > 0)
            {
                Header.cboStatus_typ = GlobalVar.goConstant.OPEN_TRX_NUM.ToString();
                Header.mskEntry_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                Header.mskApply_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                FormSyncDates(false);
            }
            else
            {
                FormShowMessage();
                Header.txtKey_id = "";
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return FormPostEvent();
        }
        private bool txtKey_id_Changed()
        {
            if (Header.txtKey_id == Header.Tag.txtKey_id)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (txtKey_id_Verified() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool mskCashAcct_cd_Changed()
        {
            Header.mskCashAcct_cd = modCommonUtility.CleanCode(Header.mskCashAcct_cd);

            if (Header.mskCashAcct_cd == Header.Tag.mskCashAcct_cd)
            {
                return true;
            }

            if (moPage.bInDialog_fl == false)
            {
                FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.
            }

            if (moUtility.IsEmpty(Header.mskCashAcct_cd) || moUtility.IsEmpty(Header.txtKey_id))
            {
                Header.txtDocument_num = "";
                return true;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moValidate.IsValidActualAcctCode(Header.mskCashAcct_cd) ==  false)
            {
                FormShowMessage(Header.mskCashAcct_cd + User.Language.oMessage.IS_INVALID);
                Header.mskCashAcct_cd = Header.Tag.mskCashAcct_cd;
                return false;
            }

            if (moUtility.ToInteger(Header.cboPayment_typ) > 0 && moUtility.IsNonEmpty(Header.txtVendor_cd))
            {
                if (moUtility.QualifiedTenderForCheckRegister(moUtility.ToInteger(Header.cboPayment_typ)))
                {
                    Header.txtDocument_num = moTransactionPayment.GetNextCheckNumber(Header.mskCashAcct_cd, moUtility.ToInteger(Header.cboPayment_typ)).ToString();
                    if (moDatabase.IsErrorFound())
                    {
                        FormShowMessage();
                        Header.mskCashAcct_cd = Header.Tag.mskCashAcct_cd;
                        FormSetFocus("mskCashAcct_cd");
                        return false;
                    }
                }
            }

            return FormPostEvent();
        }

        private bool txtVendor_cd_Changed()
        {
            Header.txtVendor_cd = modCommonUtility.CleanCode(Header.txtVendor_cd);

            if (Header.txtVendor_cd == Header.Tag.txtVendor_cd)
            {
                return true;
            }

            if (moPage.bInDialog_fl == false)
            {
                FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.
            }

            FormClearDetail();

            if (txtVendor_cd_Verified() == false)
            {
                if (moPage.bInDialog_fl == false)
                {
                    Header.txtVendor_cd = Header.Tag.txtVendor_cd;
                    Header.lblVendor_nm = Header.Tag.lblVendor_nm;
                    FormSetFocus("txtVendor_cd");
                }
                return false;
            }

            return FormPostEvent();
        }

        private bool txtPaid_amt_Changed()
        {
            string save_payment = "";

            if (moMoney.ToNumMoney(Header.txtPaid_amt) > 0 )
            {
                Header.txtPaid_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.txtPaid_amt));
                mbPaymentEntered_fl = true;
            }
            else
            {
                Header.txtPaid_amt = "";
                mbPaymentEntered_fl = false;
            }

            if (Header.txtPaid_amt == Header.Tag.txtPaid_amt || moUtility.IsEmpty(Header.txtKey_id))
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (miVendorBalance_typ == GlobalVar.goAPConstant.FORWARD_VENDOR_NUM && moUtility.IsNonEmpty(Header.txtVendor_cd))
            {
                AutoApplyPayment();
            }
            else
            {
                save_payment = Header.txtPaid_amt;
                Header.txtPaid_amt = "";
                AutoApplyPayment();                     // This will clear the payments
                Header.txtPaid_amt = save_payment;
            }

            return FormPostEvent();
        }

        private bool cboCashAcct_cd_Clicked()
        {
            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return true; // In search mode
            }

            if (Header.mskCashAcct_cd == Header.Tag.mskCashAcct_cd)
            {
                return true;
            }

            return mskCashAcct_cd_Changed();
        }
        private bool cboPayment_typ_Clicked()
        {
            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return true; // In search mode
            }

            if (Header.cboPayment_typ == Header.Tag.cboPayment_typ)
            {
                return true;
            }

            FormPreEvent();

            if (moUtility.ToInteger(Header.cboPayment_typ) == 0)
            {
                Header.mskCashAcct_cd = "";
                Header.txtPaid_amt = "";        // moMoney.ToStrMoney(0)
                Header.cboDocument_num = "";
                Header.txtDocument_num = "";
                DocumentNumberList.Clear();
                return FormPostEvent();
            }

            // If changed to/from credit memo, clear the amount paid.  Memo is a bit different from others
            //
            if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM || moUtility.ToInteger(Header.Tag.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM)
            {
                Header.txtPaid_amt = "";
                AutoApplyPayment();                     // This will clear the payments
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (cboPayment_typ_Verified() == false)
            {
                if (moPage.bInDialog_fl == false)
                {
                    Header.cboPayment_typ = Header.Tag.cboPayment_typ;
                    Header.txtDocument_num = Header.Tag.txtDocument_num;
                    Header.mskCashAcct_cd = Header.Tag.mskCashAcct_cd;
                }
                return false;
            }

            return FormPostEvent();
        }

        private bool cboDocument_num_Clicked()
        {
            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return true; // In search mode
            }

            if (Header.cboDocument_num == Header.Tag.cboDocument_num)
            {
                return true;
            }
            
            FormPreEvent();

            Header.lblTotalUsed_amt = "";

            if (moUtility.IsEmpty(Header.cboDocument_num))
            {
                mbPaymentEntered_fl = false;
                Header.txtDocument_num = "";
                Header.txtPaid_amt = "";
                txtPaid_amt_Changed();
            }
            else
            {
                mbPaymentEntered_fl = true;
                Header.txtDocument_num = moUtility.SLeftOf(modCommonUtility.GetComboText(DocumentNumberList, Header.cboDocument_num), GlobalVar.goConstant.ITEM_CODE_SEPARATOR);
                Header.txtPaid_amt = moUtility.SRightOf(modCommonUtility.GetComboText(DocumentNumberList, Header.cboDocument_num), GlobalVar.goConstant.ITEM_CODE_SEPARATOR);
            }

            CalculateTotals();

            return FormPostEvent();
        }

        private bool dtApply_dt_Changed()
        {
            if (Header.dtApply_dt == Header.Tag.dtApply_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtApply_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtApply_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtApply_dt) == false)
            {
                Header.dtApply_dt = Header.Tag.dtApply_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtApply_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskApply_dt_Changed()
        {
            if (Header.mskApply_dt == Header.Tag.mskApply_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskApply_dt) == false)
            {
                Header.mskApply_dt = Header.Tag.mskApply_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskApply_dt");
                return false;
            }

            return FormPostEvent();
        }


        private bool dtEntry_dt_Changed()
        {
            if (Header.dtEntry_dt == Header.Tag.dtEntry_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtEntry_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtEntry_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtEntry_dt) == false)
            {
                Header.dtEntry_dt = Header.Tag.dtEntry_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtEntry_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskEntry_dt_Changed()
        {
            if (Header.mskEntry_dt == Header.Tag.mskEntry_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskEntry_dt) == false)
            {
                Header.mskEntry_dt = Header.Tag.mskEntry_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskEntry_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool btnAccount_cd_Clicked()
        {
            string where_clause = "";

            FormPreEvent();
            
            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "mskCashAcct_cd", -1, -1, moView.MAIN_PAGE_NUM, "sAccount_cd", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool btnZoomOnVendor_cd_Clicked()
        {
            string where_clause = "";

            FormPreEvent();

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtVendor_cd", -1, -1, moView.MAIN_PAGE_NUM, "sVendor_cd", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdApplyPayment_Clicked()
        {
            FormPreEvent();

            if (moMoney.ToNumMoney(Header.txtPaid_amt) > moDatabase.mSmallestMoney_amt)
            {
                if (AutoApplyPayment())
                {
                }
            }
            else
            {
                if (AutoCalcTotalDue())
                {
                }
            }

            return FormPostEvent();
        }


        private bool cmdUnSelectAll_Clicked()
        {
            foreach (var det in moDetail.Grid)
            {
                det.chkInclude_fl = false;
                det.txtCurrentPayment_amt = "";
            }

            FormRecreateDetail();
            CalculateTotals();

            return FormPostEvent();
        }

        private bool cmdSelectAll_Clicked()
        {
            foreach (var det in moDetail.Grid)
            {
                det.chkInclude_fl = true;
                det.txtCurrentPayment_amt = det.txtBalanceDue_amt;
            }

            FormRecreateDetail();
            CalculateTotals();

            return FormPostEvent();
        }


        private bool cmdCancelOnPrint_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.MAIN_PAGE_NUM);
            return FormPostEvent();
        }

        private bool cmdOKOnPrint_Clicked()
        {
            FormPreEvent();

            cmdOKOnPrint_Verified();

            return FormPostEvent();
        }

        private bool cmdShowAllOpenInvoices_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsNonEmpty(Header.txtKey_id))
            {
                if (moUtility.IsEmpty(Header.txtVendor_cd))
                {
				    FormShowMessage(User.Language.oMessage.ENTER_VEND_CODE_FIRST);
                    FormShowMessage();
                    return FormPostEvent();
                }
                if (moUtility.IsEmpty(Header.mskApply_dt))
                {
                    Header.mskApply_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                }
                
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                FindOpenInvoices(Header.txtVendor_cd, moGeneral.ToNumDate(Header.mskApply_dt));
                CalculateTotals();

            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Verified()
        {
            bool return_value = false;
            clsRecordset cur_set;
            string key_id = "";

            try
            {
                if (moUtility.ToInteger(Header.txtKey_id) > 0)
                {
                    Header.txtKey_id = moUtility.ToInteger(Header.txtKey_id).ToString();
                }
                else
                {
                    Header.txtKey_id = "";
                }

                key_id = Header.txtKey_id;

                if (Header.txtKey_id == Header.Tag.txtKey_id)
                {
                    return true;
                }
                else if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormClear();
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    FormClear();
                    FormShowMessage(User.Language.oMessage.CONNECTION_HAS_FAILED);
                    return false;
                }

                cur_set = new clsRecordset(ref moDatabase);

                if (FormFindRecord(ref cur_set))
                {
                    FormShow(cur_set);
                }
                else
                {
                    if (chkAfterFact_fl == false)
                    {
                        FormClear();
                        Header.txtKey_id = key_id;
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtKey_id_Verified)");
            }

            return return_value;
        }

        private bool txtVendor_cd_Verified()
        {
            bool return_value = false;
            string sql_str = "";

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                FormClearDetail();

                moVendor.ClearVendor();
                DocumentNumberList.Clear();

                if (moUtility.IsEmpty(Header.txtVendor_cd))
                {
                    Header.lblVendor_nm = "";
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                if (moValidate.IsValidVendorCode(Header.txtVendor_cd) == false)
                {
                    FormShowMessage(Header.txtVendor_cd + User.Language.oMessage.IS_INVALID);
                    return false;
                }

                Header.lblVendor_nm = moValidate.oRecordset.sField("sVendor_nm");

                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    return true;
                }

                sql_str = "SELECT COUNT(*) AS iCount FROM tblAPPaymentUnposted";
                sql_str += " WHERE iTransaction_typ =" + GlobalVar.goConstant.TRX_PAYMENT_TYPE;
                sql_str += " AND iTransaction_num <> " + Header.txtKey_id;
                sql_str += " AND sVendor_cd = '" + Header.txtVendor_cd + "'";

                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (cur_set.iField("iCount") > 0)
                {
                    if (FormDialog(txtVendor_cd_Changed, 1000, User.Language.oMessage.UNPOSTED_PAYMENT_EXISTS_WOULD_LIKE_TO_PROCEED) == false)
                    {
                        return false;
                    }
                }
                cur_set.Release();


                if (moVendor.GetVendor(Header.txtVendor_cd, true, "", true) == false)
                {
                    FormShowMessage(Header.txtVendor_cd + User.Language.oMessage.IS_INVALID);
                    moVendor.iBalance_typ = 0;
                    Header.txtVendor_cd = "";
                    Header.lblVendor_nm = "";
                    Header.lblPayTo_cd = "";
                }
                else if (moVendor.IsValidForTransaction(moPage.iTransaction_typ) == false)
                {
                    FormShowMessage(Header.txtVendor_cd + User.Language.oMessage.IS_INVALID_FOR_THIS_TRX);
                    Header.txtVendor_cd = "";
                    Header.lblVendor_nm = "";
                    return false;
                }
                else
                {
                    Header.lblVendor_nm = moVendor.sVendor_nm;
                    Header.lblPayTo_cd = moUtility.IIf(moVendor.sPayTo_cd != "", moVendor.sPayTo_cd, moVendor.sVendor_cd).ToString();
                    Header.lblTotalBalance_amt = moMoney.ToStrMoney(moVendor.mBalanceDue_amt);
                    Header.lblNewBalanceDue_amt = Header.lblTotalBalance_amt;
                    Header.cboFund_cd = "";
                    miVendorBalance_typ = moVendor.iBalance_typ;
                    mbPaymentEntered_fl = false;

                    Header.lblTotalUsed_amt = moMoney.ToStrMoney(0);
                    Header.txtPaid_amt = "";

                    //  If there is any open voucher, open them up.
                    //  Otherwise, just proceed.
                    //
                    FindOpenInvoices(Header.txtVendor_cd, moGeneral.ToNumDate(Header.mskApply_dt));

                    // If there exists credit/deposit, use it.
                    //
                    if (moVendor.mDeposit_amt + moVendor.mDM_amt >= moDatabase.mSmallestMoney_amt)
                    {
                        Header.Tag.cboPayment_typ = "";
                        Header.cboPayment_typ = GlobalVar.goConstant.MEMO_TYPE_NUM.ToString();
                    }
                    else if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM)
                    {
                        Header.cboPayment_typ = "";
                    }

                    cboPayment_typ_Clicked(); // This will take care of deposit/memo amount
                    txtPaid_amt_Changed();

                }

                moValidate.oRecordset.Release();
                FormReArrangeHeader();
                CalculateTotals();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtVendor_cd_Verified)");
            }

            return return_value;
        }

        private bool cboPayment_typ_Verified()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtVendor_cd))
                {
                    FormShowMessage(User.Language.oMessage.ENTER_VEND_CODE_FIRST);
                    FormSetFocus("txtVendor_cd");
                    return false;
                }
                else if (moVendor.GetVendor(Header.txtVendor_cd, true) == false)
                {
                    FormShowMessage(Header.txtVendor_cd + User.Language.oMessage.IS_INVALID);
                    Header.txtVendor_cd = Header.Tag.txtVendor_cd;
                    return false;
                }

                if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM)
                {
                    if (GetMemoAvailable() == false)
                    {
                        FormShowMessage(User.Language.oMessage.NO_CREDIT_IS_AVAILABLE);
                        DocumentNumberList.Clear();
                        return false;
                    }
                }


                if (moUtility.IsNonEmpty(moVendor.sVendor_cd))
                {
                    Header.mskCashAcct_cd = moVendor.GetCashAccountCode(moUtility.ToInteger(Header.cboPayment_typ));
                    if (moUtility.QualifiedTenderForCheckRegister(moUtility.ToInteger(Header.cboPayment_typ)))
                    {
                        Header.txtDocument_num = moTransactionPayment.GetNextCheckNumber(Header.mskCashAcct_cd, moUtility.ToInteger(Header.cboPayment_typ)).ToString();
                    }
                }
                else
                {
                    Header.mskCashAcct_cd = "";
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (cboPayment_typ_Verified)");
            }

            return return_value;
        }

        private bool cmdOKOnPrint_Verified()
        {
            int new_check_num = 0;
            int row_num = 0;

            
            return FormPostEvent();
        }

        private bool CustomField_Changed(Models.clsCustomField.clsGrid cur_item)
        {
            FormPreEvent();

            if (moCustomFields.ValidateValue(moDatabase, cur_item) == false)
            {
                FormShowMessage(moCustomFields.GetErrorMessage());
                return false;
            }

            return FormPostEvent();
        }

        private bool cboListingBy_Clicked()
        {
            mbListingInitiated_fl = false;                  // Will let the listing refresh

            FormShowListing();

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        private bool DetailInclude_fl_Clicked(Models.clsPaymentDetail.clsGrid cur_item)
        {
            FormPreEvent();

            // VERY IMPORTTANT -----------------------------------------------------------------------------------------------------
            //
            // This event kickes in before the value of chkInclude_fl changes.
            // (cur_item.chkInclude_fl == true) means that the current value of chkInclude_fl is TRUE, and it will change to FALSE when it returns to UI.
            //
            if (cur_item.chkInclude_fl)
            {
                cur_item.txtCurrentPayment_amt = "";
                moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, cur_item.Row_num] = GlobalVar.goConstant.CHECKED_OFF.ToString();
            }
            else
            {
                cur_item.txtCurrentPayment_amt = moMoney.ToStrMoney(ActualAmountDue(cur_item));     
                moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, cur_item.Row_num] = GlobalVar.goConstant.CHECKED_ON.ToString();

                // If total amount to pay is entered by user, make sure not to make over-payment
                //
                if (mbPaymentEntered_fl)
                {
                    if (moMoney.ToNumMoney(cur_item.txtCurrentPayment_amt) > (moMoney.ToNumMoney(Header.txtPaid_amt) - moMoney.ToNumMoney(Header.lblTotalUsed_amt)))
                    {
                        cur_item.txtCurrentPayment_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.txtPaid_amt) - moMoney.ToNumMoney(Header.lblTotalUsed_amt));
                    }
                }

                if (moMoney.ToNumMoney(cur_item.txtCurrentPayment_amt) == 0)        // Do not use '<='. Should include negative vouchers.
                {
                    cur_item.txtCurrentPayment_amt = "";
                }
            }

            CalculateCurrentRow(cur_item, true);

            // FormRecreateDetailLine(cur_item);   DO NOT CALL THIS.  IT WILL MESS UP SYNC BECAUSE OF THE REASON COMMENTED ABOVE.
            // Update moDetail.Data[] manually as needed here instead.
            //
            moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, cur_item.Row_num] = cur_item.txtCurrentPayment_amt;
            moDetail.Data[Models.clsPaymentDetail.DISC_TAKEN_COL, cur_item.Row_num] = cur_item.txtDiscountTaken_amt;

            CalculateTotals();

            return FormPostEvent();
        }

        private bool DetailPayment_Changed(Models.clsPaymentDetail.clsGrid cur_item)
        {
            if (moMoney.ToNumMoney(cur_item.txtCurrentPayment_amt) > 0)
            {
                cur_item.txtCurrentPayment_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(cur_item.txtCurrentPayment_amt));
            }
            else
            {
                cur_item.txtCurrentPayment_amt = "";
            }

            if (moMoney.ToNumMoney(cur_item.txtCurrentPayment_amt) ==  moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, cur_item.Row_num]))
            {
                return true;
            }

            FormPreEvent();

            if (DetailPayment_Verified(cur_item) == false)
            {
                cur_item.txtCurrentPayment_amt = moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, cur_item.Row_num];
                return false;
            }

            FormRecreateDetailLine(cur_item);
            CalculateTotals();

            return FormPostEvent();
        }

        private bool DetailDiscount_Changed(Models.clsPaymentDetail.clsGrid cur_item)
        {
            if (moMoney.ToNumMoney(cur_item.txtDiscountAvailable_amt) > 0)
            {
                cur_item.txtDiscountAvailable_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(cur_item.txtDiscountAvailable_amt));
            }
            else
            {
                cur_item.txtDiscountAvailable_amt = "";
            }

            if (moMoney.ToNumMoney(cur_item.txtDiscountAvailable_amt) == moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.DISC_AVAIL_COL, cur_item.Row_num]))
            {
                return true;
            }

            FormPreEvent();

            if (DetailDiscount_Verified(cur_item) == false)
            {
                cur_item.txtDiscountAvailable_amt = moDetail.Data[Models.clsPaymentDetail.DISC_AVAIL_COL, cur_item.Row_num];
                return false;
            }

            FormRecreateDetailLine(cur_item);
            CalculateTotals();
            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        private bool DetailPayment_Verified(Models.clsPaymentDetail.clsGrid cur_item)
        {
            //  Payment should not exceed "amount due + discount amount available"
            //
            if (moMoney.ToNumMoney(cur_item.txtBalanceDue_amt) > 0 && moMoney.ToNumMoney(cur_item.txtCurrentPayment_amt) < 0)
            {
                cur_item.txtCurrentPayment_amt = moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, cur_item.Row_num];
                FormShowMessage(User.Language.oMessage.NEGATIVE_VALUE_NOT_ALLOWED);
                return false;
            }
            else if (moMoney.ToNumMoney(cur_item.txtCurrentPayment_amt) > (ActualAmountDue(cur_item)))
            {
                cur_item.txtCurrentPayment_amt = moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, cur_item.Row_num];
                FormShowMessage(User.Language.oMessage.PAYMENT_CANNOT_EXCEED_AMT_DUE);
                return false;
            }

            cur_item.txtCurrentPayment_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(cur_item.txtCurrentPayment_amt));
            CalculateCurrentRow(cur_item);

            return true;
        }

        private bool DetailDiscount_Verified(Models.clsPaymentDetail.clsGrid cur_item)
        {
            bool return_value = false;

            decimal amt_new_disc = 0;
            decimal amt_due = 0;
            decimal amt_total = 0;
            decimal amt_returned = 0;
            decimal amt_prev_paid = 0;
            double tax_retainable_pc = 0;

            amt_prev_paid = moMoney.ToNumMoney(cur_item.txtPreviousPaid_amt);
            amt_total = moMoney.ToNumMoney(cur_item.txtTotal_amt);
            amt_returned = moMoney.ToNumMoney(cur_item.txtPreviousReturned_amt);
            amt_due = amt_total - amt_returned - amt_prev_paid;
            amt_new_disc = moMoney.ToNumMoney(cur_item.txtDiscountAvailable_amt);

            // IMPORTANT FOR TAX-RETAINED:
            // When a discount is made, do not recalculate the tax_retained.
            // When invoice is posted, the tax is pertty much set, and the payment discount is a payment nego between buyer and seller,
            // and it is not a invoice nego.  If they need to change the invoice amount, they need to use credit memo.
            //
            if (amt_total < 0)
            {
                // 06/19/2018  Negative vouchers/ invoices are implemenetd
                amt_new_disc = 0;
            }
            else if (amt_new_disc < 0)
            {
                cur_item.txtDiscountAvailable_amt = moDetail.Data[Models.clsPaymentDetail.DISC_AVAIL_COL, cur_item.Row_num];
                FormShowMessage(User.Language.oMessage.NEGATIVE_VALUE_NOT_ALLOWED);
                return return_value;
            }
            else if (amt_new_disc > amt_due)
            {
                cur_item.txtDiscountAvailable_amt = moDetail.Data[Models.clsPaymentDetail.DISC_AVAIL_COL, cur_item.Row_num];
                FormShowMessage(User.Language.oMessage.DISC_CANNOT_EXCEED_AMOUNT_DUE);
                return return_value;
            }

            cur_item.txtDiscountAvailable_amt = moMoney.ToStrMoney(amt_new_disc);
            CalculateCurrentRow(cur_item);

            if (cur_item.chkInclude_fl)
            {
                cur_item.txtCurrentPayment_amt = moMoney.ToStrMoney(ActualAmountDue(cur_item));
                CalculateCurrentRow(cur_item);
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================
        private string GetSearchCriteria()
        {
            string return_value = "";

            try
            {

                if (moUtility.IsNonEmpty(Header.mskEntry_dt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "iEntry_dt = " + moGeneral.ToNumDate(Header.mskEntry_dt).ToString();
                }
                if (moUtility.IsNonEmpty(Header.mskApply_dt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "iApply_dt = " + moGeneral.ToNumDate(Header.mskApply_dt).ToString();
                }
                if (moUtility.ToInteger(Header.cboStatus_typ) > 0)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "iStatus_typ = " + Header.cboStatus_typ;
                }
                if (moUtility.IsNonEmpty(Header.txtVendor_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sVendor_cd = '" + moUtility.EvalQuote(Header.txtVendor_cd) + "'";
                }
                if (moUtility.IsNonEmpty(Header.txtDescription))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sDescription LIKE '" + moUtility.EvalQuote(Header.txtDescription) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtReference))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sReference LIKE '" + moUtility.EvalQuote(Header.txtReference) + "%'";
                }
                if (moUtility.ToInteger(Header.cboPayment_typ) > 0)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "iCash_typ =" + Header.cboPayment_typ;
                }
                if (moUtility.IsNonEmpty(Header.txtDocument_num))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sDocument_num LIKE '" + moUtility.EvalQuote(Header.txtDocument_num) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtFace_nm))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sOnDocument_nm LIKE '" + moUtility.EvalQuote(Header.txtFace_nm) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtPaid_amt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "mPaid_amt =" + moMoney.ToNumMoney(Header.txtPaid_amt).ToString();
                }
                if (moUtility.IsNonEmpty(Header.mskCashAcct_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sCashAcct_cd = '" + moUtility.EvalQuote(Header.mskCashAcct_cd) + "'";
                }

                if (moUtility.IsNonEmpty(Header.cboFund_cd))
                {
                    if (Header.cboFund_cd == clsNPConstant.FUND_ORGANIZATION_CODE)
                    {
                        return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sFund_cd = ''";
                    }
                    else
                    {
                        return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sFund_cd = '" + GlobalVar.goFund.GetSelectedFundCodeToSave(ref moDatabase, Header.cboFund_cd) + "'";
                    }
                }

                // CUSTOM FIELDS
                //
                if (moUtility.IsNonEmpty(moCustomFields.GetSearchList(moDatabase)))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + moCustomFields.GetSearchList(moDatabase);
                }

                return return_value;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (GetSearchCriteria)");
            }

            return return_value;
        }

        public bool CalculateTotals()
        {
            int row_num = 0;
            decimal total_paid = 0;
            decimal tax_retained = 0;

            for (row_num = 0; row_num < moDetail.Data.GetLength(1); row_num++)
            {
                if (moUtility.ToInteger(moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON) 
                {
                    tax_retained += moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.PREPAID_TAX_AMT_COL, row_num]);
                    total_paid += moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num]);
                    mmTotalDiscount_amt += moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.DISC_TAKEN_COL, row_num]);
                }

                // If the amount is too large, return false.
                //
                if (moMoney.TooLargeDollar(total_paid))
                {
                    FormShowMessage(User.Language.oMessage.TOO_LARGE_DOLLAR);
                    return false;
                }
            }

            Header.lblTotalUsed_amt = moMoney.ToStrMoney(total_paid);


            if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM)
            {
                // Do not change txtPaid_amt
            }
            else if (!mbPaymentEntered_fl)
            {
                Header.txtPaid_amt = Header.lblTotalUsed_amt;
            }

            // Open balance does not go below zero because the exceeding amount will
            // will go to on-acct if there is any.
            //
            if ((moMoney.ToNumMoney(Header.lblTotalBalance_amt) - total_paid - tax_retained - mmTotalDiscount_amt) > 0)
            {
                Header.lblNewBalanceDue_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.lblTotalBalance_amt) - total_paid - tax_retained - mmTotalDiscount_amt);
            }
            else
            {
                Header.lblNewBalanceDue_amt = moMoney.ToStrMoney(0);
            }


            if (moMoney.ToNumMoney(Header.lblTotalUsed_amt) == 0)
            {
                Header.lblTotalUsed_amt = "";
            }

            return true;
        }

        // COMMENT:  - This calculation should be based on the detail grid instead of
        //           array because this routine is called before the current line is
        //           saved in the array.
        //           - Example of this Function would be to calculate the extended
        //           price of each detail line in an invoice.
        //
        public bool CalculateCurrentRow(Models.clsPaymentDetail.clsGrid cur_item, bool do_not_update_include_column = false)
        {

            bool return_value = false;

            decimal cur_paid = 0;
            decimal balance_due = 0;
            decimal amt_invoice = 0;
            decimal amt_returned = 0;
            decimal disk_taken = 0;
            decimal amt_prev_paid = 0;
            decimal amt_unposted = 0;
            decimal disc_avail = 0;
            decimal open_balance = 0;
            decimal tax_retainable = 0;

            amt_invoice = moMoney.ToNumMoney(cur_item.txtTotal_amt);
            amt_returned = moMoney.ToNumMoney(cur_item.txtPreviousReturned_amt);
            amt_prev_paid = moMoney.ToNumMoney(cur_item.txtPreviousPaid_amt);
            disc_avail = moMoney.ToNumMoney(cur_item.txtDiscountAvailable_amt);
            amt_unposted = moMoney.ToNumMoney(cur_item.txtUnposted_amt);
            cur_paid = moMoney.ToNumMoney(cur_item.txtCurrentPayment_amt);
            tax_retainable = moMoney.ToNumMoney(cur_item.txtPrePaidTax_amt);

            open_balance = amt_invoice - amt_returned - amt_prev_paid - tax_retainable;

            // Find the balance due of this invoice.
            //
            balance_due = open_balance - disc_avail;
            cur_item.txtBalanceDue_amt = moMoney.ToStrMoney(moMoney.RoundToMoney(balance_due));

            // - Check if any discount is given.  This is only possible if this invoice
            // is paid off at this moment.
            // - Use tolerance amount.
            //
            if ((balance_due <= (amt_unposted + cur_paid)) && (amt_unposted + cur_paid <= balance_due))
            {
                disk_taken = balance_due - cur_paid - amt_unposted + disc_avail;
            }
            else
            {
                disk_taken = 0;
            }

            cur_item.txtDiscountTaken_amt = moMoney.ToStrMoney(moMoney.RoundToMoney(disk_taken));

            // When this is called from DetailInclude_Clicked(), crashes.
            //
            if (do_not_update_include_column == false)
            {
                if (Math.Abs(cur_paid) > 0) // 06/19/2018 Negative vouchers/imvoices are implemented
                {
                    cur_item.chkInclude_fl = true;
                }
                else
                {
                    cur_item.chkInclude_fl = false;
                }
            }

            return true;
        }

        private bool PrintRemittanceAdvice()
        {
            bool return_value = false;
            string sql_str = null;
            string pdf_file = "";

            try
            {
                moReport.InitReport(moUtility.GetServerName(ref moDatabase), moUtility.GetDatabaseName(ref moDatabase), moUtility.GetDBUser(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_ID), moUtility.GetDBPassword(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_PASSWORD), moDatabase.uDirectory.sPDFDirectory_nm, true, GlobalVar.gbUsePDFFileForReport_fl);
                moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\ap" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "611ra.rpt", moUtility.GetCustomReportFolder(ref moDatabase));

                sql_str = "({tblAPPaymentUnposted.iTransaction_typ} = " + GlobalVar.goConstant.TRX_PAYMENT_TYPE.ToString() + ")";
                sql_str += " AND ({tblAPPaymentUnposted.iTransaction_num} = " + moUtility.ToInteger(Header.txtKey_id).ToString() + ")";

                moReport.SetSelectionFormula(modCommonReportUtility.CleanupFormula(sql_str));

                if (!modCommonReportUtility.SetCompanyInReport(ref moDatabase, "frmCashPayment", ref moReport))
                {
                    return return_value;
                }

                if (moReport.PrintReport(ref moDatabase, GlobalVar.goConstant.PRINT_TO_PDF, ref pdf_file) == false)
                {
                    FormShowMessage(moReport.GetErrorMessage());
                    return false;
                }

                if (moUtility.IsEmpty(pdf_file) || modWebReportUtility.PDFFound(pdf_file) == false)
                {
                    FormShowMessage(User.Language.oMessage.REPORT_SERVER_NOT_RESPONDING);
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(pdf_file, true));

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message);
            }

            return return_value;
        }

        public bool PrintCheck()
        {
            bool return_value = false;
            string[,] payment_info = null;
            int i = 0;
            string vend_name = "";
            string vend_addr2 = "";
            string vend_addr1 = "";
            string vend_addr3 = "";
            int row_num = 0;
            string sql_str = null;
            string pdf_file = "";
            long report_id = 0;

            int check_num = moUtility.ToInteger(Header.txtDocument_num);

            clsCashDisbursement o_cd = new clsCashDisbursement();
            clsPrintCheck o_check = new clsPrintCheck(ref moDatabase);

            report_id = o_cd.GetLatestPrintID(moDatabase, moDatabase.sUser_cd) + 1;
            moUtility.ResizeDim(ref o_cd.sDetailData, clsCashDisbursement.TOTAL_COLUMNS - 1, moDetail.Data.GetLength(1) - 1);

            try
            {
                row_num = 0;
                for (i = 0; i < moDetail.Data.GetLength(1); i++)
                {
                    if (moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, i]) != 0)
                    {
                        o_cd.sDetailData[clsCashDisbursement.INCLUDE_COL, row_num] = GlobalVar.goConstant.CHECKED_ON.ToString();
                        o_cd.sDetailData[clsCashDisbursement.VENDOR_CODE_COL, row_num] = Header.txtVendor_cd;
                        o_cd.sDetailData[clsCashDisbursement.APPLIED_TRX_NUM_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL, i];
                        o_cd.sDetailData[clsCashDisbursement.INVOICE_NUM_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.INVOICE_NUM_COL, i];
                        o_cd.sDetailData[clsCashDisbursement.DUE_DATE_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.DUE_DATE_COL, i];
                        o_cd.sDetailData[clsCashDisbursement.TOTAL_AMT_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.TOTAL_AMT_COL, i];
                        o_cd.sDetailData[clsCashDisbursement.TOTAL_PAID_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.TOTAL_PAID_COL, i];
                        o_cd.sDetailData[clsCashDisbursement.BALANCE_DUE_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.TOTAL_AMT_COL, i];
                        o_cd.sDetailData[clsCashDisbursement.DISC_AVAIL_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.DISC_AVAIL_COL, i];
                        o_cd.sDetailData[clsCashDisbursement.DISC_TAKEN_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.DISC_TAKEN_COL, i];
                        o_cd.sDetailData[clsCashDisbursement.TOTAL_RETURNED_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.TOTAL_RETURNED_COL, i];
                        o_cd.sDetailData[clsCashDisbursement.APPLIED_TRX_DATE_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_DATE_COL, i];
                        o_cd.sDetailData[clsCashDisbursement.APPLIED_TRX_TYPE_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_TYPE_COL, i];
                        o_cd.sDetailData[clsCashDisbursement.APPLIED_TRX_DETAIL_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_DETAIL_COL, i];
                        o_cd.sDetailData[clsCashDisbursement.CUR_PAYMENT_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, i];
                        o_cd.sDetailData[clsCashDisbursement.CHECK_NUM_COL, row_num] = "";
                        o_cd.sDetailData[clsCashDisbursement.CHECK_NUM_COMBINED_COL, row_num] = "";
                        row_num += 1;
                    }
                }

                // If a deposit check is printed, need to add extra line for the amount going to be a deposit.
                //
                if (moMoney.ToNumMoney(Header.txtPaid_amt) > moMoney.ToNumMoney(Header.lblTotalUsed_amt))
                {
                    row_num += 1;
                }
                else if (row_num == 0)
                {
                    FormShowMessage(User.Language.oMessage.NO_SELECTIONS_FOUND);
                    return false;
                }

                moUtility.ResizeDimPreserved(ref o_cd.sDetailData, o_cd.sDetailData.GetUpperBound(0), row_num - 1);

                if (moMoney.ToNumMoney(Header.txtPaid_amt) > moMoney.ToNumMoney(Header.lblTotalUsed_amt))
                {
                    o_cd.sDetailData[clsCashDisbursement.INCLUDE_COL, row_num - 1] = GlobalVar.goConstant.CHECKED_ON.ToString();
                    o_cd.sDetailData[clsCashDisbursement.VENDOR_CODE_COL, row_num - 1] = Header.txtVendor_cd;
                    o_cd.sDetailData[clsCashDisbursement.APPLIED_TRX_NUM_COL, row_num - 1] = User.Language.oString.STR_DEPOSIT;
                    o_cd.sDetailData[clsCashDisbursement.CUR_PAYMENT_COL, row_num - 1] = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.txtPaid_amt) - moMoney.ToNumMoney(Header.lblTotalUsed_amt));
                }

                o_check.ClearReport(0);

                if (o_cd.PrepForPrinting(ref moDatabase, ref check_num, moGeneral.ToNumDate(Header.mskApply_dt), Header.mskCashAcct_cd, false, report_id, GlobalVar.goConstant.CHECK_TYPE_NUM, 0) == false)
                {
                    FormShowMessage();
                    return return_value;
                }

                moReport.InitReport(moUtility.GetServerName(ref moDatabase), moUtility.GetDatabaseName(ref moDatabase), moUtility.GetDBUser(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_ID)
                    , moUtility.GetDBPassword(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_PASSWORD), moDatabase.uDirectory.sPDFDirectory_nm, true, true);

                moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\" + modCommonUtility.GetDummyCheckFileName(ref moDatabase), moUtility.GetCustomReportFolder(ref moDatabase));

                sql_str = "{tblTMPReport.iReport_num} = " + report_id.ToString();
                sql_str += " AND {tblTMPReport.sLastUpdate_id} = '" + moDatabase.sUser_cd + "'";
                moReport.SetSelectionFormula(modCommonReportUtility.CleanupFormula(sql_str));

                if (moReport.PrintReport(ref moDatabase, GlobalVar.goConstant.PRINT_TO_PDF, ref pdf_file) == false)
                {
                    FormShowMessage(moReport.GetErrorMessage());
                    return false;
                }

                if (moUtility.IsEmpty(pdf_file) || modWebReportUtility.PDFFound(pdf_file) == false)
                {
                    FormShowMessage(User.Language.oMessage.REPORT_SERVER_NOT_RESPONDING);
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(pdf_file, true));

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PrintCheck)");
            }

            return return_value;
        }

        private bool SyncCashPayment()
        {
            bool return_value = false;

            int row_num = 0;

            try
            {
                // This will sync moCashPayment with moDetail.Data for processing.
                // This should take place before clsCashPayment processing.
                //
                moUtility.ResizeDim(ref moCashPayment.sDetailData, clsCashPayment.TOTAL_COLUMNS - 1, moDetail.Data.GetUpperBound(1));

                for (row_num = 0; row_num <= moCashPayment.sDetailData.GetUpperBound(1); row_num++)
                {
                    moCashPayment.sDetailData[clsCashPayment.INCLUDE_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, row_num];
                    moCashPayment.sDetailData[clsCashPayment.APPLIED_TRX_NUM_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL, row_num];
                    moCashPayment.sDetailData[clsCashPayment.APPLIED_TRX_TYPE_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_TYPE_COL, row_num];
                    moCashPayment.sDetailData[clsCashPayment.APPLIED_TRX_DETAIL_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_DETAIL_COL, row_num];
                    moCashPayment.sDetailData[clsCashPayment.TOTAL_AMT_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.TOTAL_AMT_COL, row_num];
                    moCashPayment.sDetailData[clsCashPayment.TOTAL_PAID_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.TOTAL_PAID_COL, row_num];
                    moCashPayment.sDetailData[clsCashPayment.TOTAL_RETURNED_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.TOTAL_RETURNED_COL, row_num];
                    moCashPayment.sDetailData[clsCashPayment.APPLIED_TRX_DATE_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_DATE_COL, row_num];
                    moCashPayment.sDetailData[clsCashPayment.DUE_DATE_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.DUE_DATE_COL, row_num];
                    moCashPayment.sDetailData[clsCashPayment.INVOICE_NUM_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.INVOICE_NUM_COL, row_num];
                    moCashPayment.sDetailData[clsCashPayment.DISC_AVAIL_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.DISC_AVAIL_COL, row_num];
                    moCashPayment.sDetailData[clsCashPayment.BALANCE_DUE_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.BALANCE_DUE_COL, row_num];
                    moCashPayment.sDetailData[clsCashPayment.CUR_PAYMENT_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num];
                    moCashPayment.sDetailData[clsCashPayment.DISC_TAKEN_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.DISC_TAKEN_COL, row_num];
                    moCashPayment.sDetailData[clsCashPayment.AMT_UNPOSTED_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.AMT_UNPOSTED_COL, row_num];
                }


                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SyncCashPayment)");
            }

            return return_value;
        }

        //  PURPOSE:  To apply the peceipt to the individual vouchers.
        //
        public bool AutoApplyPayment()
        {
            bool return_value = false;
            int row_num = 0;
            decimal tot_due = 0;
            decimal tot_disc = 0;
            decimal amt_disc = 0;
            decimal amt_due = 0;
            decimal tot_left = 0;
            decimal tot_used = 0;

            try
            {
                tot_left = moMoney.ToNumMoney(Header.txtPaid_amt);
                row_num = 0;
                tot_due = 0;
                tot_disc = 0;

                while (row_num < moDetail.Data.GetLength(1))
                {
                    if (moUtility.ToInteger(moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL, row_num]) <= 0)
                    {
                        break;
                    }

                    if (moMoney.ToNumMoney(Header.txtPaid_amt) > 0 && moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.TOTAL_AMT_COL, row_num]) < 0) // 06/19/2018 Negative vouchers/invoices
                    {

                        amt_due = moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.TOTAL_AMT_COL, row_num]);
                        moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.TOTAL_AMT_COL, row_num];
                        moDetail.Data[Models.clsPaymentDetail.DISC_AVAIL_COL, row_num] = "";
                        moDetail.Data[Models.clsPaymentDetail.DISC_TAKEN_COL, row_num] = "";
                        tot_left = moMoney.RoundToMoney(tot_left - amt_due);

                        moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, row_num] = GlobalVar.goConstant.CHECKED_ON.ToString();

                    }
                    else if (tot_left >= moDatabase.mSmallestMoney_amt)
                    {
                        amt_due = ActualAmountDue(row_num);
                        amt_disc = moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.DISC_AVAIL_COL, row_num]);

                        if (tot_left >= amt_due)
                        {
                            moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num] = moMoney.ToStrMoney(amt_due);
                            moDetail.Data[Models.clsPaymentDetail.DISC_TAKEN_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.DISC_AVAIL_COL, row_num];
                            tot_left = moMoney.RoundToMoney(tot_left - amt_due);
                            tot_disc = moMoney.RoundToMoney(tot_disc + amt_disc);
                        }
                        else if (tot_left + moMoney.ToNumMoney(Header.lblTolerance_amt) >= amt_due)
                        {
                            moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num] = moMoney.ToStrMoney(tot_left);
                            moDetail.Data[Models.clsPaymentDetail.DISC_TAKEN_COL, row_num] = moMoney.ToStrMoney(moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.DISC_AVAIL_COL, row_num]) + (amt_due - tot_left));
                            tot_left = 0;
                            tot_disc = tot_disc + moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.DISC_TAKEN_COL, row_num]);
                        }
                        else
                        {
                            moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num] = moMoney.ToStrMoney(tot_left);
                            moDetail.Data[Models.clsPaymentDetail.DISC_TAKEN_COL, row_num] = Convert.ToString(0);
                            tot_left = 0;
                        }
                        moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, row_num] = GlobalVar.goConstant.CHECKED_ON.ToString();
                    }
                    else
                    {
                        moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num] = Convert.ToString(0);
                        moDetail.Data[Models.clsPaymentDetail.DISC_TAKEN_COL, row_num] = Convert.ToString(0);
                        moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, row_num] = GlobalVar.goConstant.CHECKED_OFF.ToString();
                    }

                    row_num = row_num + 1;

                }

                tot_used = moMoney.ToNumMoney(Header.txtPaid_amt) - tot_left;
                Header.lblTotalUsed_amt = moMoney.ToStrMoney(tot_used);

                // Open balance does not go below zero because the exceeding amount will
                // will go to on-acct if there is any.
                //
                if ((moMoney.ToNumMoney(Header.lblTotalBalance_amt) - tot_used - tot_disc) >= moDatabase.mSmallestMoney_amt)
                {
                    Header.lblNewBalanceDue_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.lblTotalBalance_amt) - tot_used - tot_disc);
                }
                else
                {
                    Header.lblNewBalanceDue_amt = "0";
                }

                mmTotalDiscount_amt = tot_disc;

                FormRecreateGrid();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (AutoApplyPayment)");
            }

            return return_value;
        }

        //  Purpose:  To calculate the total due when the user processes the AUTO button
        //
        public bool AutoCalcTotalDue()
        {
            bool return_value = false;
            int row_num = 0;
            decimal tot_due = 0;
            decimal tot_disc = 0;

            try
            {

                row_num = moDetail.Data.GetUpperBound(1);
                tot_due = 0;
                tot_disc = 0;

                while (row_num >= 0)
                {
                    if (moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.BALANCE_DUE_COL, row_num]) < 0) // 06/19/2018 Negative vouchers/invoices
                    {
                        moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, row_num] = GlobalVar.goConstant.CHECKED_ON.ToString();
                    }
                    else if (moDatabase.mSmallestMoney_amt <= (ActualAmountDue(row_num) + moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.DISC_AVAIL_COL, row_num])))
                    {
                        moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, row_num] = GlobalVar.goConstant.CHECKED_ON.ToString();
                    }

                    tot_due = ActualAmountDue(row_num) + tot_due;
                    tot_disc = moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.DISC_AVAIL_COL, row_num]) + tot_disc;
                    moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num] = moMoney.ToStrMoney(ActualAmountDue(row_num));
                    moDetail.Data[Models.clsPaymentDetail.DISC_TAKEN_COL, row_num] = moDetail.Data[Models.clsPaymentDetail.DISC_AVAIL_COL, row_num];
                    row_num -= 1;

                    // If the amount is too large, return false.
                    //
                    if (moMoney.TooLargeDollar(tot_due))
                    {
                        FormShowMessage(User.Language.oMessage.TOO_LARGE_DOLLAR);
                        return false;
                    }
                }

                FormRecreateGrid();

                Header.txtPaid_amt = moMoney.ToStrMoney(tot_due);
                Header.lblTotalUsed_amt = moMoney.ToStrMoney(tot_due);

                // Open balance does not go below zero because the exceeding amount will
                // will go to on-acct if there is any.
                //
                if ((moMoney.ToNumMoney(Header.lblTotalBalance_amt) - tot_due - tot_disc) > moDatabase.mSmallestMoney_amt)
                {
                    Header.lblNewBalanceDue_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.lblTotalBalance_amt) - tot_due - tot_disc);
                }
                else
                {
                    Header.lblNewBalanceDue_amt = "0";
                }

                mmTotalDiscount_amt = tot_disc;

                return_value = true;
            }
            catch (Exception ex)
            {

                FormShowMessage(ex.Message + " (AutoCalcTotalDue)");

            }

            return return_value;
        }

        public decimal ActualAmountDue(int cur_row)
        {
            decimal return_value = 0;

            try
            {
                if (moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.TOTAL_AMT_COL, cur_row]) < 0 && moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.BALANCE_DUE_COL, cur_row]) < 0)
                {
                    return_value = moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.BALANCE_DUE_COL, cur_row]) - moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.AMT_UNPOSTED_COL, cur_row]);
                }
                else if (moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.BALANCE_DUE_COL, cur_row]) > moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.AMT_UNPOSTED_COL, cur_row]))
                {
                    return_value = moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.BALANCE_DUE_COL, cur_row]) - moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.AMT_UNPOSTED_COL, cur_row]);
                }
                else
                {
                    return_value = 0;
                }
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (ActualAmountDue)");
            }

            return return_value;
        }


        public decimal ActualAmountDue(Models.clsPaymentDetail.clsGrid cur_item)
        {
            decimal return_value = 0;

            try
            {
                if (moMoney.ToNumMoney(cur_item.txtTotal_amt) < 0 && moMoney.ToNumMoney(cur_item.txtBalanceDue_amt) < 0)
                {
                    return_value = moMoney.ToNumMoney(cur_item.txtBalanceDue_amt) - moMoney.ToNumMoney(cur_item.txtUnposted_amt);
                }
                else if (moMoney.ToNumMoney(cur_item.txtBalanceDue_amt) > moMoney.ToNumMoney(cur_item.txtUnposted_amt))
                {
                    return_value = moMoney.ToNumMoney(cur_item.txtBalanceDue_amt) - moMoney.ToNumMoney(cur_item.txtUnposted_amt);
                }
                else
                {
                    return_value = 0;
                }
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (ActualAmountDue)");
            }

            return return_value;
        }

        // PURPOSE:  To find the open invoices for this vendor and put them in
        //           the grid.
        //
        public bool FindOpenInvoices(string vend_code, int apply_date)
        {

            bool return_value = false;
            int row_num = 0;
            string sql_str = "";
            decimal disc_avail = 0;
            clsRecordset cur_set = null;
            clsRecordset unposted_set = null;
            decimal amt_unposted = 0;
            decimal amt_returned = 0;
            decimal amt_paid = 0;
            int unposted_found = 0;
            int payment_found = 0;
            int return_found = 0;

            try
            {
                unposted_found = 0;
                payment_found = 0;
                return_found = 0;

                unposted_set = new clsRecordset(ref moDatabase);
                cur_set = new clsRecordset(ref moDatabase);

                sql_str = "SELECT iAppliedTransaction_num, iAppliedTransactionDetail_num, SUM(mCurPayment_amt + mDiscGiven_amt) AS mTotalUnposted_amt ";
                sql_str += " FROM tblAPPaymentDetUnposted WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_PAYMENT_TYPE.ToString();
                sql_str += " AND iTransaction_num <> " + moUtility.ToInteger(Header.txtKey_id).ToString();
                sql_str += " AND iTransaction_num IN ( SELECT iTransaction_num FROM tblAPPaymentUnposted WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_PAYMENT_TYPE.ToString() + " AND sVendor_cd = '" + Header.txtVendor_cd + "' AND iStatus_typ = " + GlobalVar.goConstant.OPEN_TRX_NUM.ToString() + " )";
                sql_str += " GROUP BY iAppliedTransaction_num, iAppliedTransactionDetail_num";
                sql_str += " ORDER BY iAppliedTransaction_num, iAppliedTransactionDetail_num";
                if (unposted_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                if (moCashPayment.CreateOpenVoucherSet(ref cur_set, moUtility.ToInteger(Header.txtKey_id), vend_code, Header.cboFund_cd) == false)
                {
                    FormShowMessage();
                    return false;
                }

                moDetail.iTotalRows = cur_set.RecordCount();
                moUtility.ResizeDim(ref moDetail.Data, Models.clsPaymentDetail.TOTAL_COLUMNS - 1, moDetail.iTotalRows - 1);

                for (row_num = 0; row_num < moDetail.Data.GetLength(1); row_num++)
                {
                    moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, row_num] = GlobalVar.goConstant.CHECKED_OFF.ToString();

                    if (moDatabase.bFundAccounting_fl && moUtility.IsEmpty(cur_set.sField("sFund_cd").ToString()))
                    {
                        moDetail.Data[Models.clsPaymentDetail.FUND_CODE_COL, row_num] = clsNPConstant.FUND_ORGANIZATION_CODE;
                    }
                    else
                    {
                        moDetail.Data[Models.clsPaymentDetail.FUND_CODE_COL, row_num] = cur_set.sField("sFund_cd");
                    }

                    amt_returned = cur_set.mField("mReturned_amt") - cur_set.mField("mRestockCharge_amt") + cur_set.mField("mAdjusted_amt");
                    amt_paid = cur_set.mField("mPaid_amt");

                    if (amt_returned > 0M)
                    {
                        return_found += 1;
                    }
                    if (amt_paid > 0M)
                    {
                        payment_found += 1;
                    }

                    moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL, row_num] = cur_set.iField("iTransaction_num").ToString();
                    moDetail.Data[Models.clsPaymentDetail.TOTAL_AMT_COL, row_num] = moMoney.ToStrMoney(cur_set.mField("mTotal_amt"));
                    moDetail.Data[Models.clsPaymentDetail.TOTAL_PAID_COL, row_num] = moMoney.ToStrMoney(amt_paid);
                    moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num] = "";
                    moDetail.Data[Models.clsPaymentDetail.TOTAL_RETURNED_COL, row_num] = moMoney.ToStrMoney(amt_returned);
                    moDetail.Data[Models.clsPaymentDetail.DUE_DATE_COL, row_num] = moGeneral.ToStrDate(cur_set.iField("iDue_dt"));
                    moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_DATE_COL, row_num] = moGeneral.ToStrDate(cur_set.iField("iInvoice_dt"));
                    moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_TYPE_COL, row_num] = cur_set.iField("iTransaction_typ").ToString();
                    moDetail.Data[Models.clsPaymentDetail.INVOICE_NUM_COL, row_num] = cur_set.sField("sYourReference");
                    moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_DETAIL_COL, row_num] = cur_set.iField("iDetail_num").ToString();

                    if (unposted_set.FindRecord("iAppliedTransaction_num", "iAppliedTransactionDetail_num", cur_set.iField("iTransaction_num").ToString(), cur_set.iField("iDetail_num").ToString()))
                    {
                        amt_unposted = unposted_set.mField("mTotalUnposted_amt");
                        moDetail.Data[Models.clsPaymentDetail.AMT_UNPOSTED_COL, row_num] = moMoney.ToStrMoney(amt_unposted);
                        unposted_found += 1;
                    }
                    else
                    {
                        amt_unposted = 0;
                        moDetail.Data[Models.clsPaymentDetail.AMT_UNPOSTED_COL, row_num] = "";
                    }

                    //  Check if there is a discount available for early receipt.
                    //
                    if (cur_set.mField("mDue_amt") > 0 && cur_set.iField("iDiscountDue_dt") >= apply_date) // 06/19/2018 Negative vouchers/Invoices - we allow Negative vouchers/Invoices from now on.
                    {
                        disc_avail = cur_set.mField("mDiscountAvailable_amt");

                        if (disc_avail > 0 && cur_set.mField("mReturned_amt") > 0)
                        {
                            disc_avail = moMoney.RoundToMoney(cur_set.mField("mDiscountAvailable_amt") * (cur_set.mField("mTotal_amt") - cur_set.mField("mReturned_amt")) / cur_set.mField("mTotal_amt"));
                        }

                        if (disc_avail >= cur_set.mField("mDue_amt"))
                        {
                            moDetail.Data[Models.clsPaymentDetail.DISC_AVAIL_COL, row_num] = moMoney.ToStrMoney(cur_set.mField("mDue_amt"));
                            moDetail.Data[Models.clsPaymentDetail.BALANCE_DUE_COL, row_num] = "";
                        }
                        else
                        {
                            moDetail.Data[Models.clsPaymentDetail.DISC_AVAIL_COL, row_num] = moMoney.ToStrMoney(disc_avail);
                            moDetail.Data[Models.clsPaymentDetail.BALANCE_DUE_COL, row_num] = moMoney.ToStrMoney(cur_set.mField("mDue_amt") - disc_avail); // - amt_unposted) Taken care of in ActualAmountDue()
                        }

                        moDetail.Data[Models.clsPaymentDetail.DISC_TAKEN_COL, row_num] = "";
                    }
                    else
                    {
                        moDetail.Data[Models.clsPaymentDetail.BALANCE_DUE_COL, row_num] = moMoney.ToStrMoney(cur_set.mField("mDue_amt")); // - amt_unposted) Taken care of in ActualAmountDue()
                        moDetail.Data[Models.clsPaymentDetail.DISC_AVAIL_COL, row_num] = "";
                        if (cur_set.mField("mDue_amt") > 0)
                        {
                            moDetail.Data[Models.clsPaymentDetail.DISC_TAKEN_COL, row_num] = moMoney.ToStrMoney(cur_set.mField("mDiscForEarlyPaid_amt"));
                        }
                        else
                        {
                            moDetail.Data[Models.clsPaymentDetail.DISC_TAKEN_COL, row_num] = "";
                        }
                    }

                    cur_set.MoveNext();
                }

                FormRecreateGrid();
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FindOpenInvoices)");
            }

            return return_value;
        }

        public bool GetMemoAvailable()
        {
            bool return_value = false;

            DocumentNumberList.Clear();

            if (moUtility.IsEmpty(Header.txtVendor_cd))
            {
                Header.cboDocument_num = "";
                return false;
            }
            if (moVendor.mDM_amt < moDatabase.mSmallestMoney_amt && moVendor.mDeposit_amt < moDatabase.mSmallestMoney_amt)
            {
                return false;
            }

            modLoadUtility.LoadVendorMemo(ref moDatabase, ref DocumentNumberList, Header.txtVendor_cd, moUtility.ToInteger(Header.txtKey_id)
                , moUtility.ToInteger(Header.txtDocument_num), moDatabase.sCurrency_cd);

            return_value = (DocumentNumberList.Count() > 1);

            return return_value;

        }

        private bool CreateSearchHTML()
        {
            bool return_value = false;
            string html_file = "";
            string[] header_list = null;

            clsSpreadsheet o_search = new clsSpreadsheet();

            try
            {
                if (ShowSearchPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moSearch, ref o_search, ref header_list) == false)      // Listing & Search both share PrepListingDownload()
                {
                    return false;
                }

                html_file = moInquiry.CreateHTML(ref moDatabase, moPage.Title, o_search, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(html_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(html_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateSearchHTML)");
            }

            return return_value;
        }


        private bool CreateSearchExcel()
        {
            bool return_value = false;
            string csv_file = "";
            string[] header_list = null;

            clsSpreadsheet o_search = new clsSpreadsheet();

            try
            {
                if (ShowSearchPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moSearch, ref o_search, ref header_list) == false)
                {
                    return false;
                }

                csv_file = moInquiry.CreateCSV(ref moDatabase, moPage.Title, o_search, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(csv_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(csv_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateSearchExcel)");
            }

            return return_value;
        }

        private bool PrepListingDownload(clsListingPayment o_listing, ref clsSpreadsheet o_spread, ref string[] header_list)
        {
            bool return_value = false;
            int row_num = 0;
            int i = 0;

            try
            {
                moUtility.ResizeDim(ref o_spread.Data, 10, o_listing.Grid.Count - 1);

                foreach (var lst in o_listing.Grid)
                {
                    i = 0;

                    o_spread.Data[i++, row_num] = lst.Transaction_num;
                    o_spread.Data[i++, row_num] = lst.Status_typ;
                    o_spread.Data[i++, row_num] = lst.Entry_dt;
                    o_spread.Data[i++, row_num] = lst.Apply_dt;
                    o_spread.Data[i++, row_num] = lst.Cash_typ;
                    o_spread.Data[i++, row_num] = lst.Entity_cd;
                    //o_spread.Data[i++, row_num] = lst.Entity_nm;
                    o_spread.Data[i++, row_num] = lst.Document_num;
                    o_spread.Data[i++, row_num] = lst.Reference;
                    o_spread.Data[i++, row_num] = lst.Paid_amt;
                    o_spread.Data[i++, row_num] = lst.Used_amt;
                    o_spread.Data[i++, row_num] = lst.Description;

                    row_num += 1;
                }

                moUtility.ResizeDim(ref header_list, i - 1);
                i = 0;

                header_list[i++] = User.Language.oCaption.NUMBER;
                header_list[i++] = User.Language.oCaption.STATUS;
                header_list[i++] = User.Language.oCaption.ENTRY_DATE;
                header_list[i++] = User.Language.oCaption.APPLY_DATE;
                header_list[i++] = User.Language.oCaption.PAYMENT_TYPE;
                header_list[i++] = User.Language.oCaption.VENDOR;
                //header_list[i++] = User.Language.oCaption.NAME;
                header_list[i++] = User.Language.oCaption.DOCCHECK_NUM;
                header_list[i++] = User.Language.oCaption.REFERENCE;
                header_list[i++] = User.Language.oCaption.PAID;
                header_list[i++] = User.Language.oCaption.USED;
                header_list[i++] = User.Language.oCaption.DESCRIPTION;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PrepListingDownload)");
            }

            return return_value;
        }

        private bool CreateListingHTML()
        {
            bool return_value = false;
            string html_file = "";
            string[] header_list = null;

            clsSpreadsheet o_listing = new clsSpreadsheet();

            try
            {
                if (ShowListingPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moListing, ref o_listing, ref header_list) == false)
                {
                    return false;
                }

                html_file = moInquiry.CreateHTML(ref moDatabase, moPage.Title, o_listing, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(html_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(html_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateListingHTML)");
            }

            return return_value;
        }


        private bool CreateListingExcel()
        {
            bool return_value = false;
            string csv_file = "";
            string[] header_list = null;

            clsSpreadsheet o_listing = new clsSpreadsheet();

            try
            {
                if (ShowListingPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moListing, ref o_listing, ref header_list) == false)
                {
                    return false;
                }

                csv_file = moInquiry.CreateCSV(ref moDatabase, moPage.Title, o_listing, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(csv_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(csv_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateListingExcel)");
            }

            return return_value;
        }

    }
}
