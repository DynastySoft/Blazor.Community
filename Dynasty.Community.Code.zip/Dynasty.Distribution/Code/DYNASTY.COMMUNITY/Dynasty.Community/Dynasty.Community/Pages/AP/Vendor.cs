﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Local;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Dynasty.ASP.Shared;
using Dynasty.ASP.Models;

namespace Dynasty.ASP.Pages.AP
{
    public partial class Vendor
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<Vendor> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;                                                               
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;
        private Models.clsSpreadsheet moSpreadsheet;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl || moPage.Original.iStatus_typ == GlobalVar.goAPConstant.CLOSED_VENDOR_NUM);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        private bool ShowSearchPrinter
        {
            get
            {
                return (mbSearchInitiated_fl && mbSearchPopulated_fl);
            }
        }
        
        private int miUDF_num = 0;

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsIntegrity moIntegrity;
        private clsMoney moMoney;
        private clsVendor moVendor;
        private clsColumns moColumns;
        private Models.clsCustomField moCustomFields;
        private Models.clsSession moSession;
        private Models.clsContact moExtraContact;
        private clsContactManager moContactManager;
        private clsInquiry moInquiry;
        private clsCustomization moCustomization;

        private string txtSearchBalance_amt;
        private string txtSearchDeposit_amt;
        private string cboSearchBalanceOperator;
        private string cboSearchDepositOperator;

        private List<Models.clsCombobox> OperatorTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ContactTypeList = new List<Models.clsCombobox>();

        private List<Models.clsCombobox> ClassCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> GroupCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> PostingCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> TermsCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> TaxCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> AgentCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CountryCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CurrencyCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> FOBCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> VendorTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> PaymentTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> StatusTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> BalanceTypeList = new List<Models.clsCombobox>();

        private List<Models.clsCombobox> ContactHourList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ContactMinuteList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ContactAMPMList = new List<Models.clsCombobox>();

        private bool mbShowExtraContact_fl = false;

        // Search options
        //
        private bool mbSearchInitiated_fl = false;
        private bool mbSearchPopulated_fl = false;

        private int miOriginalBalance_typ = 0;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader                   
        {
            // Listing of UI items on the header
            //
            public string txtKey_id = "";
            public string txtVendor_nm = "";
            public string txtAddress1 = "";
            public string txtAddress2 = "";
            public string txtAddress3 = "";
            public string txtCity = "";
            public string txtState = "";
            public string txtZipCode = "";
            public string txtFax = "";
            public string txtPhone1 = "";
            public string txtPhone2 = "";
            public string txtPayTo_cd = "";
            public string txtContact_nm = "";
            public string txtContactPhone = "";
            public string txtAttention_nm = "";
            public string txtEmailAddress = "";

            public string txtSortKey1 = "";
            public string txtSortKey2 = "";
            public string txtAccount_num = "";
            public string txtReseller_num = "";
            public string txtCreated_dt = "";

            public string txtCreditLimit_amt = "";
            public string lblDeposit_amt = "";
            public string lblBalanceDue_amt = "";
            public string lblCreditAvailable_amt = "";

            public string txtComment = "";
            public string txtWebSite = "";
            public string txtNextTime = "";
            public string txtNextRemark = "";
            public string txtLastTime = "";
            public string txtLastRemark = "";
            public string lblLastEmail_dt = "";
            public string lblLastEmailTopic = "";
            public string lblTotalEmails_num = "";
            public string lblLastEmailUser_id = "";
            public string lblLastEmail_id = "";

            public string cboClass_cd = "";
            public string cboGroup_cd = "";
            public string cboPosting_cd = "";
            public string cboTerms_cd = "";
            public string cboTax_cd = "";
            public string cboAgent_cd = "";
            public string cboCountry_cd = "";
            public string cboCurrency_cd = "";
            public string cboFOB_cd = "";
            public string cboVendor_typ = "";
            public string cboPayment_typ = "";
            public string cboStatus_typ = "";
            public string cboBalance_typ = "";

            public bool chkCreditLimit_fl = false;
            public bool chk1099_fl = false;
            public bool chkConsignment_fl = false;
            public bool chkExcludeInCD_fl = false;
            public bool chkImport_fl = false;

            public string cboNextContactHour = "";
            public string cboNextContacMinute = "";
            public string cboNextContactAMPM = "";
            public string cboLastContactHour = "";
            public string cboLastContacMinute = "";
            public string cboLastContactAMPM = "";

            // Datetime component is not very user-friendly, yet, as of VS2019.
            // For better understanding this, read the comment on bUseDatePicker_fl in clsUser.
            //
            public string mskNext_dt = "";
            public string mskLast_dt = "";
            public DateTime? dtNext_dt = null;
            public DateTime? dtLast_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag                                                                     
            {
                public string txtKey_id  = "";
                public string cboClass_cd = "";
                public string txtPayTo_cd  = "";
                public string txtCreditLimit_amt = "";
                public string mskNext_dt = "";
                public string mskLast_dt = "";
                public DateTime? dtNext_dt = null;
                public DateTime? dtLast_dt = null;
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()                                                                  
            {
                Tag.txtKey_id = txtKey_id;
                Tag.cboClass_cd = cboClass_cd;
                Tag.txtPayTo_cd = txtPayTo_cd;
                Tag.txtCreditLimit_amt = txtCreditLimit_amt;
                Tag.mskNext_dt = mskNext_dt;
                Tag.mskLast_dt = mskLast_dt;
                Tag.dtNext_dt = dtNext_dt;
                Tag.dtLast_dt = dtLast_dt;
            }
        }
        private clsHeader Header = new clsHeader();                                                 


        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;                        
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            moSession.RemoveSession(moDatabase);        // Delete the session file.

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows()
        {

            return true;
        }

        private bool FormCalculateTotal()
        {

            return true;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            if (FormCheckSecurity() == false)
            {
                return false;
            }
            else if (FormCheckHeader() == false)
            {
                return false;
            }
            else if (FormCheckExtra() == false)
            {
                return false;
            }

            return true;
        }

        private bool FormCheckExtra()                                                              // validate extra other than the header and detail.
        {
            bool return_value = false;

            try
            {

                // Custom fields
                //
                if (moCustomFields.CheckValues(moDatabase) == false)
                {
                    FormShowMessage(moCustomFields.GetErrorMessage());
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckExtra)");
            }

            return return_value;
        }

        private bool FormCheckHeader()                                                             // validate the header data.
        {
            bool return_value = false;

            try
            {
                Header.txtVendor_nm = moUtility.EvalQuote(moUtility.STrim(Header.txtVendor_nm));

                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormShowMessage(User.Language.oCaption.CODE + User.Language.oMessage.IS_REQUIRED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("txtKey_id");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.txtVendor_nm))
                {
                    FormShowMessage(User.Language.oMessage.VENDOR_NAME_REQUIRED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("txtVendor_nm");
                    return false;
                }
                else if (moUtility.ToInteger(Header.cboStatus_typ) == 0)
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_SELECT_A_STATUS_TYPE);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboStatus_typ");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboClass_cd))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_SELECT_A_CLASS_CODE);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboClass_cd");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboTax_cd))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_SELECT_A_TAX_CODE);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboTax_cd");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboPosting_cd))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_SELECT_A_POSTING_CODE);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboPosting_cd");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboTerms_cd))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_SELECT_A_TERMS_CODE);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboTerms_cd");
                    return false;
                }

                if (moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goAPConstant.CLOSED_VENDOR_NUM)
                {
                    if (moMoney.ToNumMoney(Header.lblBalanceDue_amt) > 0 || moMoney.ToNumMoney(Header.lblDeposit_amt) > 0)
                    {
                        FormShowMessage(User.Language.oMessage.YOU_CANNOT_CLOSE_ACCOUNT_WITH_OUTSTANDING_BALANCE);
                        FormSwitchView(moView.MAIN_PAGE_NUM);
                        return false;
                    }

                    return true;
                }

                if (moUtility.IsEmpty(Header.txtAccount_num))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_ + User.Language.oCaption.OUR_ACCT_NUM);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("txtAccount_num");
                    return false;
                }

                if (moUtility.IsEmpty(Header.cboBalance_typ))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_SELECT_A_BALANCE_TYPE);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboBalance_typ");
                    return false;
                }

                // 05/21/2023
                // If balance & deposit both exist, other balance types cannot change to B/F type because of different posting behaviors
                //
                if ((moMoney.ToNumMoney(Header.lblBalanceDue_amt) != 0 && moMoney.ToNumMoney(Header.lblDeposit_amt) != 0)
                && miOriginalBalance_typ != GlobalVar.goAPConstant.FORWARD_VENDOR_NUM && moUtility.ToInteger(Header.cboBalance_typ) == GlobalVar.goAPConstant.FORWARD_VENDOR_NUM)
                {
                    FormShowMessage(User.Language.oMessage.YOU_CANNOT_CHANGE_BALANCE_TYPE + " " + User.Language.oMessage.BALANCE_NEEDS_TO_BE_CLEARED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboBalance_typ");
                    return false;
                }

                if (Header.chkConsignment_fl && moUtility.ToInteger(Header.cboBalance_typ) != GlobalVar.goAPConstant.FORWARD_VENDOR_NUM)
                {
                    FormShowMessage(User.Language.oMessage.BALANCE_TYPE_OF_CONSIGNMENT_VENDOR_SHOULD_BE_BALANCE_FORWARD);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboBalance_typ");
                    return false;
                }

                Header.txtState = moUtility.STrim(moUtility.EvalQuote(Header.txtState));

                if (moUtility.SLength(Header.txtState) <= 2)
                {
                    Header.txtState = moUtility.SUCase(Header.txtState);
                }

                Header.txtAddress3 = moUtility.SLeft(Header.txtCity + ", " + Header.txtState + " " + Header.txtZipCode, moUtility.ToInteger(Length.ADDRESS));
                Header.txtAddress3 = moUtility.IIf(moUtility.STrim(Header.txtAddress3) == ",", "", Header.txtAddress3);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckHeader)");
            }

            return return_value;
        }

        private bool FormCheckConcurrency(clsRecordset cur_set)                                    // Check if someone has changed this record while it is open in this session.
        {
            if (cur_set.IsNonEmpty()) 
            {
                if (moPage.bNew_fl)
                {
                    // If someone has created a record with the same key
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.DUPLICATE_IS_FOUND + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                    moPage.bNew_fl = false;
                }
                else if (moPage.CheckForConcurrency(cur_set) == false)
                {
                    // If someone has updated this record in the meantime.
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        private bool FormCheckToDelete()
        {
            clsIntegrity o_integrity = new clsIntegrity(ref moDatabase);

            if (FormCheckSecurity() == false)
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }
            else if (modFormUtility.IsReservedRecord(ref moDatabase, Header.txtKey_id, moPage.bReserved_fl))
            {
                FormShowMessage(User.Language.oMessage.RESERVED_RECORD_IS_NOT_ALLOWED_TO_DELETE);
                return false;
            }
            else if (o_integrity.IsReferenced(moPage.sModule_id, moPage.sKeyField_nm, Header.txtKey_id))
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }

            return true;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearExtra();

            return true;
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            miOriginalBalance_typ = 0;

            mbShowExtraContact_fl = false;
            FormReArrangeHeader();

            // Custom Fields
            //
            moCustomFields.ClearGrid();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {
            Header.txtKey_id = "";
            Header.txtVendor_nm = "";
            Header.txtAddress1 = "";
            Header.txtAddress2 = "";
            Header.txtAddress3 = "";
            Header.txtCity = "";
            Header.txtState = "";
            Header.txtZipCode = "";
            Header.txtFax = "";
            Header.txtPhone1 = "";
            Header.txtPhone2 = "";
            Header.txtPayTo_cd = "";
            Header.txtContact_nm = "";
            Header.txtContactPhone = "";
            Header.txtAttention_nm = "";
            Header.txtEmailAddress = "";

            Header.txtSortKey1 = "";
            Header.txtSortKey2 = "";
            Header.txtAccount_num = "";
            Header.txtReseller_num = "";
            Header.txtCreated_dt = "";

            Header.txtCreditLimit_amt = "";
            Header.lblDeposit_amt = "";
            Header.lblBalanceDue_amt = "";
            Header.lblCreditAvailable_amt = "";

            Header.txtNextTime = "";
            Header.txtNextRemark = "";
            Header.txtLastTime = "";
            Header.txtLastRemark = "";
            Header.txtComment = "";
            Header.txtWebSite = "";
            Header.lblLastEmail_dt = "";
            Header.lblLastEmailTopic = "";
            Header.lblTotalEmails_num = "";
            Header.lblLastEmailUser_id = "";
            Header.lblLastEmail_id = "";

            Header.cboClass_cd = "";
            Header.cboGroup_cd = "";
            Header.cboPosting_cd = "";
            Header.cboTerms_cd = "";
            Header.cboTax_cd = "";
            Header.cboAgent_cd = "";
            Header.cboCountry_cd = "";
            Header.cboCurrency_cd = "";
            Header.cboFOB_cd = "";
            Header.cboVendor_typ = "";
            Header.cboPayment_typ = "";
            Header.cboStatus_typ = "";
            Header.cboBalance_typ = "";

            Header.chkCreditLimit_fl = false;
            Header.chk1099_fl = false;
            Header.chkConsignment_fl = false;
            Header.chkExcludeInCD_fl = false;
            Header.chkImport_fl = false;

            Header.cboNextContactHour = "";
            Header.cboNextContacMinute = "00";
            Header.cboNextContactAMPM = "";
            Header.cboLastContactHour = "";
            Header.cboLastContacMinute = "00";
            Header.cboLastContactAMPM = "";

            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            //
            Header.mskNext_dt = "";
            Header.mskLast_dt = "";
            FormSyncDates(false);

            return true;
        }

        private bool FormClearMessage()                                                            
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id) || moPage.bNew_fl)
                {
                    FormClear();
                    return true;
                }
                else if (FormCheckToDelete() == false)
                {
                    return false;
                }

                // Transaction begins here.
                //
                if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }

                if (modFormUtility.RecordDelete(ref moDatabase, moPage.iScreen_typ, Header.txtKey_id, moPage.sKeyField_nm, moPage.sTable_nm, moPage.sDetailTable_nm, moPage.sRestrictionClause, moPage.iTransaction_typ) == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }
                else if (FormDeleteExtra() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }

                // Transaction ends here.
                //
                if (moDatabase.TransactionCommit() == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDelete)");
                moDatabase.TransactionRollback();
                return_value = false;
            }

            return return_value;
        }

        private bool FormDeleteExtra()
        {
            if (moIntegrity.DeleteDependantsOfVendor(Header.txtKey_id) == false)
            {
                return false;
            }

            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormFindRecord(ref clsRecordset cur_set, int matching_type = 0)
        {
            bool return_value = false;

            matching_type = (int)(moUtility.IIf(matching_type > 0, matching_type, GlobalVar.goConstant.MATCHING_RECORD_TYPE));
            return_value = modFormUtility.RecordRead(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sTable_nm, moPage.sKeyField_nm, moPage.sPreviousKey_id, moPage.sRestrictionClause, ref matching_type);

            return return_value;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();
            moSearch = new Models.clsEntitySearch();
            moSpreadsheet = new Models.clsSpreadsheet();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moCustomFields = new Models.clsCustomField();
            moSession = new Models.clsSession();
            moContactManager = new clsContactManager();
            moInquiry = new clsInquiry();
            moCustomization = new clsCustomization(ref moDatabase);

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.APMENU_NAME;
            moPage.Title = User.Language.oCaption.VENDOR;
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            if (moUtility.IsSupervisor(moDatabase) == false)
            {
                moPage.sRestrictionClause += moUtility.IIf(moUtility.IsEmpty(moPage.sRestrictionClause), "", " AND ") + "(sAgent_cd = '" + moDatabase.sUser_cd + "' OR sAgent_cd = '' OR sAgent_cd IS NULL)";
            }

            // This page-specific objects.
            //
            moIntegrity = new clsIntegrity(ref moDatabase) ;
            moVendor = new clsVendor(ref moDatabase);
            moMoney = new clsMoney(ref moDatabase);
            moColumns = new clsColumns();

            moExtraContact = new Models.clsContact();

            Modal.Release();

            FormInitHeader();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = "tblAPVendor"; 
            moPage.sKeyField_nm = "sVendor_cd";
            moPage.iTransaction_typ= 0;
            moPage.sKeyDescription = "sVendor_nm";                                                
            moPage.sReference = "sCity";

            return true;
        }

        private bool FormPostEvent()
        {
            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            // FormSave() & FormCheck() use the plain textbox whose name starts with "msk"
            // dt* variables are only to interact with UI.  Internally, msk* fields are used.
            //
            FormSyncDates(User.bUseDatePicker_fl);
            
            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback
            
            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;

            try
            {
                if (FormReceiveValues() == false)                    // All pages that use session value need to capture it here before FormOpenDatabase()
                {
                    return false;
                }
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                modLoadUtility.LoadVendorStatusType(ref moDatabase, ref StatusTypeList);
                modLoadUtility.LoadVendorClassCode(ref moDatabase, ref ClassCodeList);
                modLoadUtility.LoadVendorTaxCode(ref moDatabase, ref TaxCodeList);
                modLoadUtility.LoadVendorTermsCode(ref moDatabase, ref TermsCodeList);
                modLoadUtility.LoadVendorPostingCode(ref moDatabase, ref PostingCodeList);
                modLoadUtility.LoadVendorBalanceType(ref moDatabase, ref BalanceTypeList);
                modLoadUtility.LoadCountryCode(ref moDatabase, ref CountryCodeList);
                modLoadUtility.LoadVendorGroupCode(ref moDatabase, ref GroupCodeList);
                modLoadUtility.LoadAPAgent(ref moDatabase, ref AgentCodeList);
                modLoadUtility.LoadCurrencyCode(ref moDatabase, ref CurrencyCodeList);
                modLoadUtility.LoadFOB(ref moDatabase, ref FOBCodeList);
                modLoadUtility.LoadEntityType(ref VendorTypeList);
                modLoadUtility.LoadPaymentType(ref moDatabase, ref PaymentTypeList, false, true, false, false, true);

                modLoadUtility.LoadComparisonOperators(ref OperatorTypeList);
                modLoadUtility.LoadContactPointTypes(ref ContactTypeList);

                modLoadUtility.LoadHours(ref ContactHourList);
                modLoadUtility.LoadMinutes(ref ContactMinuteList);
                modLoadUtility.LoadAMPM(ref ContactAMPMList);

                // Custom Fields
                //
                if (moCustomization.ReadCustomInfo(0, User.Language.oString.STR_VENDOR))
                {
                    moCustomFields.CreateGrid(moCustomization.sField_nm, moCustomization.sCaptions, moCustomization.bRequired);
                }

                if (moUtility.IsNonEmpty(moPage.sInitialKey_id))
                {
                    Header.txtKey_id = moPage.sInitialKey_id;
                    txtKey_id_Changed();
                }

                User.bConnected_fl = true;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormMove(int record_move_direction)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormClear();

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            if (FormFindRecord(ref cur_set, record_move_direction) == false)
            {
                return false;
            }

            FormShow(cur_set);
            return true;

        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostSave()
        {
            // If this is a transaction page, and transaction number has changed, let the user know.
            //
            if (moPage.sPreviousKey_id != Header.txtKey_id)
            {
                FormShowMessage(User.Language.oMessage.TRX_NUM_HAS_CHANGED_TO + "  " + Header.txtKey_id, false);
            }

            moPage.sPreviousKey_id = Header.txtKey_id;

            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {

            moContactManager.SetTime(ref Header.txtNextTime, Header.cboNextContactHour, Header.cboNextContacMinute, Header.cboNextContactAMPM);
            moContactManager.SetTime(ref Header.txtLastTime, Header.cboLastContactHour, Header.cboLastContacMinute, Header.cboLastContactAMPM);

            return true;
        }

        private bool FormReArrangeHeader()                                                              // Arrange(show/hide, enable/disable) the fields in the header section
        {
            
            return true;
        }

        private bool FormReceiveValues()
        {
            // If connected already, return true.  This means this page came through the menu system.
            //
            if (moUtility.IsNonEmpty(User.sServer_nm) || moDatabase.IsConnected())
            {
                return true;
            }

            // Otherwise, need to login with the info passed from the calling page.
            //
            if (modGeneralUtility.GetPassedParameters(StarterValue, User, moSession) == false)
            {
                FormShowMessage(User.Language.oMessage.PLEASE_LOG_IN_FIRST);
                return false;
            }

            moPage.sInitialKey_id = moSession.Value.Entity;

            return true;
        }
        private bool FormSave()
        {
            bool return_value = false;
            clsRecordset cur_set;

            try
            {
                if (FormOpenDatabase() == false)                     // Has to come before FormCheck()
                {
                    return false;
                }
                else if (FormCheck() == false)                       // Check if data is ok to save.
                {
                    return false;
                }

                moPage.sPreviousKey_id = Header.txtKey_id;
                cur_set = new clsRecordset(ref moDatabase);

                if (modFormUtility.RecordOpen(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sRestrictionClause, moPage.sTable_nm, moPage.sKeyField_nm) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormCheckConcurrency(cur_set) == false)
                {
                    return false;
                }
                else if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormPreSave(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveHeader(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveExtra(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (!moVendor.SaveVendor())
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (moDatabase.TransactionCommit() == false)
                {
                    FormShowMessage();
                    moDatabase.TransactionRollback();
                    return false;
                }

                FormPostSave();
                    
                return_value = true;

            }
            catch (Exception ex)
            {

                FormShowMessage(ex.Message + " (FormSave)");
                moDatabase.TransactionRollback();

            }

            return return_value;
        }

        private bool FormSaveExtra(clsRecordset cur_set)
        {
            bool return_value = false;
            int i = 0;

            try
            {

                if (mbShowExtraContact_fl && moExtraContact.iTotalRows > 0)
                {
                    moUtility.ResizeDim(ref moVendor.sContacts, moColumns.Contact.TOTAL_COL_NUM - 1, moExtraContact.iTotalRows - 1);

                    i = 0;
                    foreach (var det in moExtraContact.Grid)
                    {
                        moVendor.sContacts[moColumns.Contact.TYPE_COL, i] = det.Type;
                        moVendor.sContacts[moColumns.Contact.NAME_COL, i] = det.Name;
                        moVendor.sContacts[moColumns.Contact.PHONE1_COL, i] = det.Phone1;
                        moVendor.sContacts[moColumns.Contact.PHONE2_COL, i] = det.Phone2;
                        moVendor.sContacts[moColumns.Contact.FAX_COL, i] = det.Fax;
                        moVendor.sContacts[moColumns.Contact.EMAIL_COL, i] = det.Email;
                        moVendor.sContacts[moColumns.Contact.TITLE_COL, i] = det.Title;
                        moVendor.sContacts[moColumns.Contact.COMMENT_COL, i] = det.Comment;
                        i++;
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormSaveHeader(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {

                moVendor.bNew_fl = (moPage.bNew_fl|| cur_set.EOF());

                // This is for Concurrency check to go smooth.
                // If someone calls FormSave() without going thru the whole saving routine that
                // clears the screen, and save again later, then FormCheckConcurrency() will raise an error
                // because the record in the database has been updated but moPage.Original.dtLastUpdate_dt still has the old timestamp.
                //
                moPage.Original.sLastUpdate_id = moDatabase.sUser_cd;
                moPage.Original.dtLastUpdate_dt = DateTime.Now;

                moVendor.sVendor_cd = Header.txtKey_id;
                moVendor.sVendor_nm = moUtility.EvalQuote(Header.txtVendor_nm);
                moVendor.sAddress1 = moUtility.EvalQuote(Header.txtAddress1);
                moVendor.sAddress2 = moUtility.EvalQuote(Header.txtAddress2);
                moVendor.sAddress3 = moUtility.EvalQuote(Header.txtAddress3);
                moVendor.sCity = moUtility.EvalQuote(Header.txtCity);
                moVendor.sState = moUtility.EvalQuote(Header.txtState);
                moVendor.sZipCode = moUtility.EvalQuote(Header.txtZipCode);
                moVendor.sCountry_cd = Header.cboCountry_cd;
                moVendor.sPhone1 = moUtility.EvalQuote(Header.txtPhone1);
                moVendor.sPhone2 = moUtility.EvalQuote(Header.txtPhone2);
                moVendor.sFax = moUtility.EvalQuote(Header.txtFax);
                moVendor.sSortKey1 = moUtility.EvalQuote(Header.txtSortKey1);
                moVendor.sSortKey2 = moUtility.EvalQuote(Header.txtSortKey2);
                moVendor.sAttention_nm = moUtility.EvalQuote(Header.txtAttention_nm);
                moVendor.sContact_nm = moUtility.EvalQuote(Header.txtContact_nm);
                moVendor.sContactPhone = moUtility.EvalQuote(Header.txtContactPhone);
                moVendor.sEmailAddress = moUtility.EvalQuote(Header.txtEmailAddress);
                moVendor.mCreditLimit_amt = moMoney.ToNumMoney(Header.txtCreditLimit_amt);
                moVendor.iStatus_typ = moUtility.ToInteger(Header.cboStatus_typ);
                moVendor.iBalance_typ = moUtility.ToInteger(Header.cboBalance_typ);
                moVendor.sTheirCustomer_cd = moUtility.EvalQuote(Header.txtAccount_num);
                moVendor.sReseller_num = moUtility.EvalQuote(Header.txtReseller_num);
                moVendor.sPayTo_cd = moUtility.EvalQuote(Header.txtPayTo_cd);
                moVendor.sCurrency_cd = Header.cboCurrency_cd;
                moVendor.sClass_cd = Header.cboClass_cd;
                moVendor.sTerms_cd = Header.cboTerms_cd;
                moVendor.sTax_cd = Header.cboTax_cd;
                moVendor.sPosting_cd = Header.cboPosting_cd;
                moVendor.sAgent_cd = Header.cboAgent_cd;
                moVendor.sFob_cd = Header.cboFOB_cd;
                moVendor.sGroup_cd = Header.cboGroup_cd;
                moVendor.iVendor_typ = moUtility.ToInteger(Header.cboVendor_typ);
                moVendor.iPayment_typ = moUtility.ToInteger(Header.cboPayment_typ);
                moVendor.sComment = moUtility.EvalQuote(Header.txtComment);

                moVendor.iCheckCrLimit_fl = moUtility.IIf(Header.chkCreditLimit_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moVendor.i1099_fl = moUtility.IIf(Header.chk1099_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moVendor.iConsignment_fl = moUtility.IIf(Header.chkConsignment_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moVendor.iExcludeInCD_fl = moUtility.IIf(Header.chkExcludeInCD_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF);
                moVendor.iImport_fl = moUtility.IIf(Header.chkImport_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF);

                moVendor.iNext_dt = moGeneral.ToNumDate(Header.mskNext_dt);
                moVendor.sNextTime = moUtility.EvalQuote(Header.txtNextTime);
                moVendor.iLast_dt = moGeneral.ToNumDate(Header.mskLast_dt);
                moVendor.sLastTime = moUtility.EvalQuote(Header.txtLastTime);
                moVendor.sNextRemark = moUtility.EvalQuote(Header.txtNextRemark);
                moVendor.sLastRemark = moUtility.EvalQuote(Header.txtLastRemark);
                moVendor.sWebSite = moUtility.EvalQuote(Header.txtWebSite);

                // Attach the custom field list
                //
                moVendor.CustomFieldList = moCustomFields.GetFieldList();
                moVendor.CustomValueList = moCustomFields.GetValueList(moDatabase);
                moVendor.CustomUpdateList = moCustomFields.GetUpdateList(moDatabase);

                moVendor.sLastUpdate_id = moPage.Original.sLastUpdate_id;
                moVendor.dtLastUpdate_dt = moPage.Original.dtLastUpdate_dt;

                moVendor.bContactUpdated_fl = mbShowExtraContact_fl;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveHeader)");
            }

            return return_value;
        }

        private bool FormSearch()
        {
            string search_str = GetSearchCriteria();

            if (moUtility.IsEmpty(search_str))
            {
                FormShowMessage(User.Language.oMessage.PLEASE_ENTER_THE_SEARCH_CRITERIA_ON_THE_MAIN_ENTRY_TAB);
                return false;
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            mbSearchPopulated_fl = false;

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moSearch.Show(moDatabase, moPage, search_str, "sAgent_cd", "mBalanceDue_amt", "mDeposit_amt", "mDM_amt", "sAttention_nm", "sPhone1", "sEmailAddress", "sContact_nm", "sContactPhone", "", moCustomization.sField_nm) == false)
            {
                FormShowMessage();
                return false;
            }

            mbSearchInitiated_fl = true;
            mbSearchPopulated_fl = (moSearch.Grid.Count > 0);

            if (mbSearchPopulated_fl == false)
            {
                FormShowMessage(User.Language.oMessage.NO_MATCHING_RECORDS_FOUND);
            }

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {
            if (FormShowHeader(cur_set) == false)
            {
                return false;
            }
            else if (FormShowExtra(cur_set) == false)
            {
                return false;
            }

            FormReArrangeHeader();

            return true;
        }

        private bool FormShowExtra(clsRecordset cur_set)
        {
            bool return_value = false;
            decimal deposit_amt = 0;

            try
            {
                moPage.Clear();
                moPage.PreserveTimestamp(cur_set);
                moPage.PreserveOriginal(cur_set);
                moPage.bNew_fl = false;

                miOriginalBalance_typ = cur_set.iField("iBalance_typ");

                deposit_amt = cur_set.mField("mDeposit_amt") + cur_set.mField("mDM_amt");

                if ((deposit_amt) > -moDatabase.mSmallestMoney_amt)
                {
                    Header.lblDeposit_amt = moMoney.ToStrMoney(deposit_amt);
                }
                else
                {
                    Header.lblDeposit_amt = "(" + moMoney.ToStrMoney(Math.Abs(deposit_amt)) + ")";
                }

                if ((cur_set.mField("mBalanceDue_amt")) > -moDatabase.mSmallestMoney_amt)
                {
                    Header.lblBalanceDue_amt = moMoney.ToStrMoney(cur_set.mField("mBalanceDue_amt"));
                }
                else
                {
                    Header.lblBalanceDue_amt = "(" + moMoney.ToStrMoney(Math.Abs(cur_set.mField("mBalanceDue_amt"))) + ")";
                }

                txtCreditLimit_amt_Verified();

                moPage.sPreviousKey_id = Header.txtKey_id;
                Header.Preserve();
                mbShowExtraContact_fl = false;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowHeader(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                Header.txtKey_id = cur_set.sField(moPage.sKeyField_nm);
                Header.txtVendor_nm = cur_set.sField("sVendor_nm");
                Header.txtAddress1 = cur_set.sField("sAddress1");
                Header.txtAddress2 = cur_set.sField("sAddress2");
                Header.txtCity = cur_set.sField("sCity");
                Header.txtState = cur_set.sField("sState");
                Header.txtZipCode = cur_set.sField("sZipCode");
                Header.txtPhone1 = cur_set.sField("sPhone1");
                Header.txtPhone2 = cur_set.sField("sPhone2");
                Header.txtFax = cur_set.sField("sFax");
                Header.txtContact_nm = cur_set.sField("sContact_nm");
                Header.txtContactPhone = cur_set.sField("sContactPhone");
                Header.txtAttention_nm = cur_set.sField("sAttention_nm");

                Header.txtPayTo_cd = cur_set.sField("sPayTo_cd");
                Header.txtSortKey1 = cur_set.sField("sSortKey1");
                Header.txtSortKey2 = cur_set.sField("sSortKey2");
                Header.txtAccount_num = cur_set.sField("sTheirCustomer_cd");
                Header.txtReseller_num = cur_set.sField("sReseller_num");
                Header.txtCreditLimit_amt = moMoney.ToStrMoney(cur_set.mField("mCreditLimit_amt"));

                Header.chkCreditLimit_fl = (cur_set.iField("iChkCrLimit_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chk1099_fl = (cur_set.iField("i1099_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkConsignment_fl = (cur_set.iField("iConsignment_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkExcludeInCD_fl = (cur_set.iField("iExcludeInCD_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkImport_fl = (cur_set.iField("iImport_fl") == GlobalVar.goConstant.FLAG_ON);

                Header.txtNextTime = cur_set.sField("sNextTime");
                Header.txtNextRemark = cur_set.sField("sNextRemark");
                Header.txtLastRemark = cur_set.sField("sLastRemark");
                Header.txtLastTime = cur_set.sField("sLastTime");

                Header.txtComment = cur_set.sField("sComment");
                Header.txtEmailAddress = cur_set.sField("sEmailAddress");
                Header.txtWebSite = cur_set.sField("sWebSite");

                Header.txtCreated_dt = moGeneral.ToStrDate(cur_set.iField("iCreated_dt"));
                Header.lblLastEmail_dt = moGeneral.ToStrDate(cur_set.iField("iLastEmail_dt"));
                Header.lblLastEmailTopic = cur_set.sField("sLastEmailTopic");
                Header.lblTotalEmails_num = cur_set.iField("iTotalEmails_num").ToString();
                Header.lblLastEmailUser_id = cur_set.sField("sLastEmailUser_id");
                Header.lblLastEmail_id = cur_set.sField("sLastEmail_id");

                Header.cboBalance_typ = cur_set.iField("iBalance_typ").ToString();
                Header.cboStatus_typ = cur_set.iField("iStatus_typ").ToString();
                Header.cboClass_cd = cur_set.sField("sClass_cd");
                Header.cboGroup_cd = cur_set.sField("sGroup_cd");
                Header.cboPosting_cd = cur_set.sField("sPosting_cd");
                Header.cboTerms_cd = cur_set.sField("sTerms_cd");
                Header.cboTax_cd = cur_set.sField("sTax_cd");
                Header.cboAgent_cd = cur_set.sField("sAgent_cd");
                Header.cboCountry_cd = cur_set.sField("sCountry_cd");
                Header.cboCurrency_cd = cur_set.sField("sCurrency_cd");
                Header.cboFOB_cd = cur_set.sField("sFob_cd");
                Header.cboVendor_typ = cur_set.iField("iVendor_typ").ToString();
                Header.cboPayment_typ = cur_set.iField("iPayment_typ").ToString();

                Header.txtNextTime = cur_set.sField("sNextTime");
                moContactManager.GetTime(Header.txtNextTime, ref Header.cboNextContactHour, ref Header.cboNextContacMinute, ref Header.cboNextContactAMPM);

                Header.txtLastTime = cur_set.sField("sLastTime");
                moContactManager.GetTime(Header.txtLastTime, ref Header.cboLastContactHour, ref Header.cboLastContacMinute, ref Header.cboLastContactAMPM);

                // Custom Fields
                //
                moCustomFields.SetValues(moDatabase, cur_set);

                // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
                // Make sure both, dt* and msk*, are sync'ed.
                //
                Header.mskLast_dt = moGeneral.ToStrDate(cur_set.iField("iLast_dt"));
                Header.mskNext_dt = moGeneral.ToStrDate(cur_set.iField("iNext_dt"));
                FormSyncDates(false);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowHeader)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtLast_dt, ref Header.mskLast_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtNext_dt, ref Header.mskNext_dt, use_date_picker);

            return true;
        }

        private bool FormShowListing()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moListing.Show(moDatabase, moPage) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            moView.SwitchView(moPage, cur_page);

            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moZoom.Caller == "txtKey_id")
            {
                if (moZoom.Vendor(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            else if (moZoom.Caller == "txtPayTo_cd")
            {
                if (moZoom.Vendor(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }


            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormClear();
                return true;
            }

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
                {
                    return false;
                }
            }

            FormCancel();
            return true;
        }

        private bool btnDelete_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormClear();
                return true;
            }

            if (FormDialog(btnDelete_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_DELETE) == false)
            {
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (FormDelete() == false)
            {
                return false;
            }
            
            FormClear();
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormExit();
                return true;
            }

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }

        private bool btnFirst_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnFirst_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.FIRST_RECORD_TYPE);
        }

        private bool btnLast_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnLast_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.LAST_RECORD_TYPE);
        }

        private bool btnNext_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnNext_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.NEXT_RECORD_TYPE);
        }

        private bool btnPrevious_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnPrevious_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.PREVIOUS_RECORD_TYPE);
        }

        private bool btnSave_Clicked()
        {
            FormPreEvent();

            if (moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goAPConstant.CLOSED_VENDOR_NUM)
            {
                if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.SURE_TO_CLOSE_THIS_ACCOUNT) == false)
                {
                    return false;
                }
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormSave() == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        private bool btnSearchToPrint_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateSearchHTML();

            return FormPostEvent();
        }

        private bool btnSearchToExcel_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateSearchExcel();

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewHeader_Clicked()
        {
            FormPreEvent();       
            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }
        private bool cmdViewContact_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.CONTACT_INFO_PAGE_NUM);

            return true;

        }
        private bool cmdViewEmailHistory_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.EMAIL_HISTORY_PAGE_NUM);

            return true;

        }

        private bool cmdViewSearch_Clicked()
        {
            FormPreEvent();       
            FormSwitchView(moView.SEARCH_PAGE_NUM);

            return true;

        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnListingSelect_Clicked(Models.clsListing.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.IsEmpty(cur_item.Code))
            {
                return false;
            }

            FormClear();
            Header.txtKey_id = cur_item.Code;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }
        private bool btnSearchSelect_Clicked(Models.clsEntitySearch.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.IsEmpty(cur_item.Code))
            {
                return false;
            }

            FormClear();
            Header.txtKey_id = cur_item.Code;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                if (moUtility.IsEmpty(cur_item.Col_0))
                {
                    return false;
                }

                code_selected = cur_item.Col_0;

                if (moZoom.Caller == "txtKey_id")
                {
                    Header.txtKey_id = code_selected;
                    if (txtKey_id_Changed() == false)
                    {
                        return false;
                    }
                }
                else if (moZoom.Caller == "txtPayTo_cd")
                {
                    if (code_selected == Header.txtKey_id)
                    {
                        FormShowMessage(code_selected + User.Language.oMessage.IS_NOT_ALLOWED);
                        return false;
                    }

                    Header.txtPayTo_cd = code_selected;
                }

                FormSwitchView(moZoom.iView);

                return_value = FormPostEvent();
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }

        private bool cmdSearch_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            FormSearch();

            return FormPostEvent();
        }

        private bool btnZoomOnKey_id_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtKey_id", -1, -1, moView.MAIN_PAGE_NUM, moPage.sKeyField_nm, "") == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }
        private bool btnZoomOnPayTo_cd_Clicked()
        {
            FormPreEvent();

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtPayTo_cd", -1, -1, moView.MAIN_PAGE_NUM, moPage.sKeyField_nm, "") == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdPurchasesHistory_Clicked()
        {
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            o_session.SetSessionValues(moDatabase, User, ref session_id, Header.txtKey_id);

            FormOpenPDF("VendorPurchaseHistory/" + session_id);

            return FormPostEvent();
        }

        private bool cmdBalanceHistory_Clicked()
        {
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            o_session.SetSessionValues(moDatabase, User, ref session_id, Header.txtKey_id);

            FormOpenPDF("VendorBalanceHistory/" + session_id);

            return FormPostEvent();
        }

        private bool cmdMemoHistory_Clicked()
        {
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            o_session.SetSessionValues(moDatabase, User, ref session_id, Header.txtKey_id);

            FormOpenPDF("VendorMemoHistory/" + session_id);

            return FormPostEvent();
        }


        private bool cmdOpenVouchers_Clicked()
        {
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            o_session.SetSessionValues(moDatabase, User, ref session_id, Header.txtKey_id);

            FormOpenPDF("OpenVouchers/" + session_id);

            return FormPostEvent();
        }


        private bool cmdOrders_Clicked()
        {
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            o_session.SetSessionValues(moDatabase, User, ref session_id, Header.txtKey_id);

            FormOpenPDF("ShowPurchaseOrders/" + session_id);

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Changed()
        {
            if (Header.txtKey_id == Header.Tag.txtKey_id)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (txtKey_id_Verified() == false)
            {
                return false;
            }

            if (moPage.bNew_fl)
            {
                Header.cboStatus_typ = GlobalVar.goAPConstant.ACTIVE_VENDOR_NUM.ToString();
                Header.cboBalance_typ = GlobalVar.goAPConstant.OPEN_VENDOR_NUM.ToString();
                Header.cboClass_cd = moDatabase.uDefaultValue.sAPClass_cd;
                Header.cboPosting_cd = moDatabase.uDefaultValue.sAPPosting_cd;
                Header.cboTax_cd = moDatabase.uDefaultValue.sAPTax_cd;
                Header.cboTerms_cd = moDatabase.uDefaultValue.sAPTerms_cd;
                cboClass_cd_Changed();      // May have class specific posting code
            }

            return FormPostEvent();
        }

        private bool txtPayTo_cd_Changed()
        {
            if (Header.txtPayTo_cd == Header.Tag.txtPayTo_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (txtPayTo_cd_Verified() == false)
            {
                Header.txtPayTo_cd = Header.Tag.txtPayTo_cd;
                FormSetFocus("txtPayTo_cd");
                return false;
            }

            return FormPostEvent();
        }

        private bool cboClass_cd_Changed()
        {
            if (Header.cboClass_cd == Header.Tag.cboClass_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (cboClass_cd_Verified() == false)
            {
                Header.cboClass_cd = Header.Tag.cboClass_cd;
                FormSetFocus("cboClass_cd");
                return false;
            }

            FormReArrangeHeader();

            return FormPostEvent();
        }

        private bool txtCreditLimit_amt_Changed()
        {
            if (Header.txtCreditLimit_amt == Header.Tag.txtCreditLimit_amt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (txtCreditLimit_amt_Verified() == false)
            {
                Header.txtCreditLimit_amt = Header.Tag.txtCreditLimit_amt;
                FormSetFocus("txtCreditLimit_amt");
                return false;
            }

            return FormPostEvent();

        }

        private bool cmdMoveToHistory_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
				FormShowMessage(User.Language.oMessage.ENTER_CUST_CODE_FIRST);
                return false;
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (SaveContactHistory() == false)
            {
                return false;
            }

            FormShowMessage(User.Language.oString.STR_COMPLETE, false);

            return FormPostEvent();
        }

        private bool cmdShowContactHistory_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormShowMessage(User.Language.oMessage.ENTER_CUST_CODE_FIRST);
                return false;
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (ShowContactHistory() == false)
            {
                return false;
            }

            FormSwitchView(moView.CONTACT_HISTORY_PAGE_NUM);

            return FormPostEvent();
        }

        private bool cmdMoreContacts_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormShowMessage(User.Language.oMessage.ENTER_CUST_CODE_FIRST);
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            moVendor.sVendor_cd = Header.txtKey_id;

            if (moVendor.GetContactInfo() == false)
            {
                FormShowMessage();
                return false;
            }
            else if (moExtraContact.Show(moDatabase, moPage, moVendor.sContacts) == false)
            {
                FormShowMessage();
                return false;
            }

            mbShowExtraContact_fl = true;

            return FormPostEvent();
        }

        private bool dtLast_dt_Changed()
        {
            if (Header.dtLast_dt == Header.Tag.dtLast_dt)
            {
                return true;
            }

            FormPreEvent();                                                                     // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtLast_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtLast_dt);   // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtLast_dt) == false)
            {
                Header.dtLast_dt = Header.Tag.dtLast_dt;
                FormShowMessage(User.Language.oCaption.LAST_CONTACT_DATE + User.Language.oMessage.IS_INVALID);
                FormSetFocus("dtLast_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskLast_dt_Changed()
        {
            if (Header.mskLast_dt == Header.Tag.mskLast_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.IsValidDate(Header.mskLast_dt) == false)
            {
                Header.mskLast_dt = Header.Tag.mskLast_dt;
                FormShowMessage(User.Language.oCaption.LAST_CONTACT_DATE + User.Language.oMessage.IS_INVALID);
                FormSetFocus("mskLast_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtNext_dt_Changed()
        {
            if (Header.dtNext_dt == Header.Tag.dtNext_dt)
            {
                return true;
            }

            FormPreEvent();                                                                     // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtNext_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtNext_dt);   // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtNext_dt) == false)
            {
                Header.dtNext_dt = Header.Tag.dtNext_dt;
                FormShowMessage(User.Language.oCaption.NEXT_CONTACT_DATE + User.Language.oMessage.IS_INVALID);
                FormSetFocus("dtNext_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskNext_dt_Changed()
        {
            if (Header.mskNext_dt == Header.Tag.mskNext_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.IsValidDate(Header.mskNext_dt) == false)
            {
                Header.mskNext_dt = Header.Tag.mskNext_dt;
                FormShowMessage(User.Language.oCaption.NEXT_CONTACT_DATE + User.Language.oMessage.IS_INVALID);
                FormSetFocus("mskNext_dt");
                return false;
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Verified()
        {
            bool return_value = false;
            clsRecordset cur_set;
            string key_id = "";

            try
            {
                Header.txtKey_id = modCommonUtility.CleanCode(Header.txtKey_id);
                key_id = Header.txtKey_id;

                if (Header.txtKey_id == Header.Tag.txtKey_id)
                {
                    return true;
                }
                else if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormClear();
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    FormClear();
                    FormShowMessage(User.Language.oMessage.CONNECTION_HAS_FAILED);
                    return false;
                }

                cur_set = new clsRecordset(ref moDatabase);

                if (FormFindRecord(ref cur_set))
                {
                    FormShow(cur_set);
                }
                else
                {
                    if (moPage.bNew_fl == false)                                  // This will let the user change the ID if it is brand new record.
                    {
                        FormClear();
                        Header.txtKey_id = key_id;
                    }
                }

                FormReArrangeHeader();
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtKey_id_Verified)");
            }

            return return_value;
        }
        private bool txtPayTo_cd_Verified()
        {

            Header.txtPayTo_cd = modCommonUtility.CleanCode(Header.txtPayTo_cd);

            if (moUtility.IsEmpty(Header.txtPayTo_cd))
            {
                return true;
            }
            else if (Header.txtPayTo_cd == Header.txtKey_id)
            {
                FormShowMessage(Header.txtPayTo_cd + User.Language.oMessage.IS_NOT_ALLOWED);
                return false;
            }
            
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moValidate.IsValidVendorCode(Header.txtPayTo_cd) == false)
            {
                FormShowMessage(Header.txtPayTo_cd + User.Language.oMessage.DOES_NOT_EXIST);
                return false;
            }
            else if (moValidate.oRecordset.iField("iShipTo_fl") == GlobalVar.goConstant.FLAG_ON) // IsValidVendorCode() populates moValidate.oRecordset.
            {
                FormShowMessage(User.Language.oMessage.BILL_TO_CODE_NOT_QUALIFIED);
                return false;
            }

            return true;
        }

        private bool cboClass_cd_Verified()
        {

            if (moUtility.IsEmpty(Header.cboClass_cd))
            {
                return true;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moValidate.IsValidAPClassCode(Header.cboClass_cd))
            {
                if (moUtility.IsNonEmpty(moValidate.oRecordset.sField("sPosting_cd")))
                {
                    Header.cboPosting_cd = moValidate.oRecordset.sField("sPosting_cd");
                }
                else if (moUtility.IsNonEmpty(moDatabase.uDefaultValue.sPosting_cd))
                {
                    Header.cboPosting_cd = moDatabase.uDefaultValue.sPosting_cd;
                }
            }

            return true;
        }
        private bool txtCreditLimit_amt_Verified()
        {
            Header.txtCreditLimit_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.txtCreditLimit_amt));

            if ((moMoney.ToNumMoney(Header.txtCreditLimit_amt) + moMoney.ToNumMoney(Header.lblDeposit_amt)) <= moMoney.ToNumMoney(Header.lblBalanceDue_amt))
            {
                Header.lblCreditAvailable_amt = moMoney.ToStrMoney(0);
            }
            else
            {
                Header.lblCreditAvailable_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.txtCreditLimit_amt) + moMoney.ToNumMoney(Header.lblDeposit_amt) - moMoney.ToNumMoney(Header.lblBalanceDue_amt));
            }

            return true;
        }

        private bool CustomField_Changed(Models.clsCustomField.clsGrid cur_item)
        {
            FormPreEvent();

            if (moCustomFields.ValidateValue(moDatabase, cur_item) == false)
            {
                FormShowMessage(moCustomFields.GetErrorMessage());
                return false;
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        private bool btnContactDelete_Clicked(Models.clsContact.clsGrid cur_item)
        {
            FormPreEvent();

            return DeleteCurrentContactRow(cur_item);

        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================
        
        private bool DeleteCurrentContactRow(Models.clsContact.clsGrid cur_item)
        {
            bool return_value = false;
            int old_num = cur_item.Row_num;

            try
            {
                if (modDetailUtility.DeleteCurrentRow(ref moDatabase, ref moExtraContact.Data, cur_item.Row_num) == false)
                {
                    FormShowMessage();
                    moExtraContact.CreateGrid(ref moDatabase);
                    return false;
                }

                moExtraContact.Grid.RemoveAt(cur_item.Row_num);
                moExtraContact.Grid.Where(i => i.Row_num >= old_num).Select(i => { i.Row_num -= 1; return i; }).ToList();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (DeleteCurrentContactRow)");
                moExtraContact.CreateGrid(ref moDatabase);
            }

            return return_value;
        }

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

        private string GetSearchCriteria()
        {

            string return_value = "";

            try
            {
                if (moUtility.ToInteger(Header.cboBalance_typ) > 0)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iBalance_typ=" + Header.cboBalance_typ;
                }
                if (moUtility.ToInteger(Header.cboStatus_typ) > 0)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iStatus_typ=" + Header.cboStatus_typ;
                }
                if (moUtility.IsNonEmpty(Header.txtSortKey2))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sSortKey2 LIKE '" + moUtility.EvalQuote(Header.txtSortKey2) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtSortKey1))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sSortKey1 LIKE '" + moUtility.EvalQuote(Header.txtSortKey1) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtPayTo_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sPayTo_cd='" + moUtility.EvalQuote(Header.txtPayTo_cd) + "'";
                }
                if (Header.chkConsignment_fl)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iConsignment_fl > 0";
                }
                if (Header.chk1099_fl)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "i1099_fl=1";
                }
                if (Header.chkCreditLimit_fl)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iChkCrLimit_fl=1";
                }
                if (Header.chkExcludeInCD_fl)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iExcludeInCD_fl=1";
                }
                if (Header.chkImport_fl)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iImport_fl=1";
                }
                if (moUtility.IsNonEmpty(Header.cboClass_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sClass_cd='" + Header.cboClass_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboGroup_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sGroup_cd='" + Header.cboGroup_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboPosting_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sPosting_cd='" + Header.cboPosting_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboTerms_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sTerms_cd='" + Header.cboTerms_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboTax_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sTax_cd='" + Header.cboTax_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboAgent_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sAgent_cd='" + Header.cboAgent_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboCountry_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sCountry_cd='" + Header.cboCountry_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboCurrency_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sCurrency_cd='" + Header.cboCurrency_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.txtAccount_num))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sTheirCustomer_cd LIKE '" + moUtility.EvalQuote(Header.txtAccount_num) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtReseller_num))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sReseller_num LIKE '" + moUtility.EvalQuote(Header.txtReseller_num) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtContactPhone))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sContactPhone LIKE '" + moUtility.EvalQuote(Header.txtContactPhone) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtContact_nm))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sContact_nm LIKE '" + moUtility.EvalQuote(Header.txtContact_nm) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtFax))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sFax LIKE '" + moUtility.EvalQuote(Header.txtFax) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtPhone2))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sPhone2 LIKE '" + moUtility.EvalQuote(Header.txtPhone2) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtAttention_nm))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sAttention_nm LIKE '" + moUtility.EvalQuote(Header.txtAttention_nm) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtPhone1))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sPhone1 LIKE '" + moUtility.EvalQuote(Header.txtPhone1) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtVendor_nm))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sVendor_nm LIKE '" + moUtility.EvalQuote(Header.txtVendor_nm) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtAddress2))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sAddress2 LIKE '" + moUtility.EvalQuote(Header.txtAddress2) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtAddress1))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sAddress1 LIKE '" + moUtility.EvalQuote(Header.txtAddress1) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtZipCode))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sZipCode LIKE '" + moUtility.EvalQuote(Header.txtZipCode) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtState))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sState LIKE '" + moUtility.EvalQuote(Header.txtState) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtCity))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sCity LIKE '" + moUtility.EvalQuote(Header.txtCity) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtNextTime))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sNextTime LIKE '" + moUtility.EvalQuote(Header.txtNextTime) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtNextRemark))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sNextRemark LIKE '" + moUtility.EvalQuote(Header.txtNextRemark) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtLastRemark))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sLastRemark LIKE '" + moUtility.EvalQuote(Header.txtLastRemark) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtLastTime))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sLastTime LIKE '" + moUtility.EvalQuote(Header.txtLastTime) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.mskLast_dt) && moGeneral.IsValidDate(Header.mskLast_dt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iLast_dt=" + moGeneral.ToNumDate(Header.mskLast_dt);
                }
                if (moUtility.IsNonEmpty(Header.mskNext_dt) && moGeneral.IsValidDate(Header.mskNext_dt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iNext_dt=" + moGeneral.ToNumDate(Header.mskNext_dt);
                }
                if (moUtility.IsNonEmpty(Header.txtComment))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sComment LIKE '" + moUtility.EvalQuote(Header.txtComment) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtEmailAddress))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sEmailAddress LIKE '" + moUtility.EvalQuote(Header.txtEmailAddress) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtWebSite))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sWebSite LIKE '" + moUtility.EvalQuote(Header.txtWebSite) + "%'";
                }

                if (moUtility.IsNonEmpty(cboSearchBalanceOperator))  
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "mBalanceDue_amt " + cboSearchBalanceOperator + " " + moMoney.ToNumMoney(txtSearchBalance_amt).ToString();
                }
                if (moUtility.IsNonEmpty(cboSearchDepositOperator))   
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "(mDeposit_amt + mDM_amt) " + cboSearchDepositOperator + " " + moMoney.ToNumMoney(txtSearchDeposit_amt).ToString();
                }

                // CUSTOM FIELDS
                //
                if (moUtility.IsNonEmpty(moCustomFields.GetSearchList(moDatabase)))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + moCustomFields.GetSearchList(moDatabase);
                }

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (GetSearchCriteria)");
            }

            return return_value;
        }

        private bool SaveContactHistory()
        {
            bool return_value = false;
            int next_num = 0;
            clsRecordset cur_set = null;
            string sql_str = "";

            try
            {
                cur_set = new clsRecordset(ref moDatabase);

                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    return false;
                }

                moContactManager.SetTime(ref Header.txtNextTime, Header.cboNextContactHour, Header.cboNextContacMinute, Header.cboNextContactAMPM);
                moContactManager.SetTime(ref Header.txtLastTime, Header.cboLastContactHour, Header.cboLastContacMinute, Header.cboLastContactAMPM);

                if (moGeneral.IsValidDate(Header.mskLast_dt) || moUtility.IsNonEmpty(moUtility.STrim(Header.txtLastRemark)))
                {
                    sql_str = "SELECT MAX(iDetail_num) AS iMaxNum FROM tblGOContact";
                    sql_str += " WHERE sModule_id = '" + clsAPConstant.MODULE_ID + "'";
                    sql_str += " AND sClient_cd = '" + Header.txtKey_id + "'";
                    if (cur_set.CreateSnapshot(sql_str) == false)
                    {
                        FormShowMessage();
                        return false;
                    }
                    else if (cur_set.EOF())
                    {
                        next_num = 1;
                    }
                    else
                    {
                        next_num = cur_set.iField("iMaxNum") + 1;
                    }

                    cur_set.Release();

                    sql_str = "INSERT INTO tblGOContact(";
                    sql_str += "sModule_id";
                    sql_str += ",sClient_cd";
                    sql_str += ",iDetail_num";
                    sql_str += ",iTime_dt";
                    sql_str += ",sRemark";
                    sql_str += ",sLastUpdate_id";
                    sql_str += ",dtLastUpdate_dt";
                    sql_str += ") VALUES (";
                    sql_str += "'" + clsAPConstant.MODULE_ID + "'";
                    sql_str += ",'" + Header.txtKey_id + "'";
                    sql_str += "," + next_num;
                    sql_str += "," + moGeneral.ToNumDate(Header.mskLast_dt);
                    sql_str += ",'" + moUtility.SLeft(Header.cboLastContactHour + ":" + Header.cboLastContacMinute + " " + Header.cboLastContactAMPM + " " + Header.txtLastRemark + "'", 255);
                    sql_str += ",'" + moDatabase.sUser_cd + "'";
                    sql_str += "," + moDatabase.CreateDatetimeValue(DateTime.Now);
                    sql_str += ")";

                    if (moDatabase.ExecuteSQL(sql_str) == false)
                    {
                        FormShowMessage();
                        return false;
                    }

                    Header.mskLast_dt = moUtility.GetEmptyMaskedDate();
                    Header.txtLastRemark = "";
                    Header.txtLastTime = "";

                }

                sql_str = "UPDATE tblAPVendor SET";
                sql_str += " iNext_dt = 0";
                sql_str += ",sNextTime = ''";
                sql_str += ",sNextRemark = ''";
                sql_str += ",iLast_dt = " + moUtility.IIf(moUtility.IsBlankDate(Header.mskNext_dt), 0, moGeneral.ToNumDate(Header.mskNext_dt)).ToString();
                sql_str += ",sLastTime = '" + Header.txtNextTime + "'";
                sql_str += ",sLastRemark = '" + moUtility.EvalQuote(Header.txtNextRemark) + "'";
                sql_str += " WHERE sVendor_cd = '" + Header.txtKey_id + "'";
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                // Reset the date/time
                //
                Header.txtLastTime = Header.txtNextTime;
                Header.mskLast_dt = Header.mskNext_dt;
                Header.txtLastRemark = Header.txtNextRemark;
                Header.cboLastContactHour = Header.cboNextContactHour;
                Header.cboLastContacMinute = Header.cboNextContacMinute;
                Header.cboLastContactAMPM = Header.cboNextContactAMPM;

                Header.txtNextTime = "";
                Header.mskNext_dt = moUtility.GetEmptyMaskedDate();
                Header.txtNextRemark = "";
                Header.cboNextContactHour = "";
                Header.cboNextContacMinute = "";
                Header.cboNextContactAMPM = "";

                FormSyncDates(false);

                cur_set.Release();
                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SaveContactHistory)");
            }

            return return_value;
        }

        private bool ShowContactHistory()
        {
            bool return_value = false;
            string[] field_list = new string[] { "iTime_dt", "sRemark", "sLastUpdate_id" };
            string where_clause = "";

            try
            {
                where_clause = " sModule_id = '" + clsAPConstant.MODULE_ID +  "' AND sClient_cd = '" + Header.txtKey_id + "'";

                if (moSpreadsheet.Show(moDatabase, moPage, "tblGOContact", field_list, where_clause, "iDetail_num DESC") == false)
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (ShowContactHistory)");
            }

            return return_value;
        }

        private bool PrepSearchDownload(ref clsSpreadsheet o_search, ref string[] header_list)
        {
            bool return_value = false;
            int row_num = 0;
            int i = 0;

            try
            {

                moUtility.ResizeDim(ref o_search.Data, 11 + moCustomization.iTotalFields, moSearch.Grid.Count - 1);

                foreach (var lst in moSearch.Grid)
                {
                    i = 0;
                    miUDF_num = 0;

                    o_search.Data[i++, row_num] = lst.Code;
                    o_search.Data[i++, row_num] = lst.Description;
                    o_search.Data[i++, row_num] = lst.Reference;
                    o_search.Data[i++, row_num] = lst.ExtraCol_1;
                    o_search.Data[i++, row_num] = lst.ExtraCol_2;
                    o_search.Data[i++, row_num] = lst.ExtraCol_3;
                    o_search.Data[i++, row_num] = lst.ExtraCol_4;
                    o_search.Data[i++, row_num] = lst.ExtraCol_5;
                    o_search.Data[i++, row_num] = lst.ExtraCol_6;
                    o_search.Data[i++, row_num] = lst.ExtraCol_7;
                    o_search.Data[i++, row_num] = lst.ExtraCol_8;
                    o_search.Data[i++, row_num] = lst.ExtraCol_9;

                    if (moCustomization.iTotalFields > 0)
                    {
                        foreach (var udf in moCustomFields.Grid)
                        {
                            if (moCustomization.iTotalFields > miUDF_num)
                            {
                                o_search.Data[i++, row_num] = moSearch.CustomFields[miUDF_num++, lst.Row_num];
                            }
                        }
                    }

                    row_num += 1;
                }

                moUtility.ResizeDim(ref header_list, i - 1);
                i = 0;

                header_list[i++] = User.Language.oCaption.VENDOR;
                header_list[i++] = User.Language.oCaption.NAME;
                header_list[i++] = User.Language.oCaption.CITY;
                header_list[i++] = User.Language.oCaption.AGENT;
                header_list[i++] = User.Language.oCaption.BALANCE;
                header_list[i++] = User.Language.oCaption.DEPOSIT;
                header_list[i++] = User.Language.oCaption.CREDIT;
                header_list[i++] = User.Language.oCaption.ATTENTION;
                header_list[i++] = User.Language.oCaption.PHONE + " 1";
                header_list[i++] = User.Language.oCaption.EMAIL_ADDRESS;
                header_list[i++] = User.Language.oCaption.CONTACT;
                header_list[i++] = User.Language.oCaption.CONTACT_PHONE;

                if (moCustomization.iTotalFields > 0)
                {
                    foreach (var udf in moCustomFields.Grid)
                    {
                        header_list[i++] = udf.Caption;
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PrepSearchDownload)");
            }

            return return_value;
        }

        private bool CreateSearchHTML()
        {
            bool return_value = false;
            string html_file = "";
            string[] header_list = null;

            clsSpreadsheet o_search = new clsSpreadsheet();

            try
            {
                if (ShowSearchPrinter == false)
                {
                    return true;
                }

                if (PrepSearchDownload(ref o_search, ref header_list) == false)
                {
                    return false;
                }

                html_file = moInquiry.CreateHTML(ref moDatabase, moPage.Title, o_search, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(html_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(html_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateSearchHTML)");
            }

            return return_value;
        }


        private bool CreateSearchExcel()
        {
            bool return_value = false;
            string csv_file = "";
            string[] header_list = null;

            clsSpreadsheet o_search = new clsSpreadsheet();

            try
            {
                if (ShowSearchPrinter == false)
                {
                    return true;
                }

                if (PrepSearchDownload(ref o_search, ref header_list) == false)
                {
                    return false;
                }

                csv_file = moInquiry.CreateCSV(ref moDatabase, moPage.Title, o_search, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(csv_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(csv_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateSearchExcel)");
            }

            return return_value;
        }

    }
}
