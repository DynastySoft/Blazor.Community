﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Local;
using Dynasty.Report;
using Dynasty.ASP.Models;

namespace Dynasty.ASP.Pages.AP
{
    public partial class LookupVoucher
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<Voucher> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;                                                               
        private Models.clsListingCharge moListing;
        private Models.clsListingCharge moSearch;
        private Models.clsSpreadsheet moSpreadsheet;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        private bool ShowNavigation
        {
            get
            {
                return (moPage.iCurrentView != moView.ZOOM_PAGE_NUM && moPage.iCurrentView != moView.ORDER_PAGE_NUM && moPage.iCurrentView != moView.MATRIX_PAGE_NUM && moPage.iCurrentView != moView.PRINT_PAGE_NUM);          
            }
        }

        private bool ShowHeader
        {
            get
            {
                return ((User.IsMobile == false && (moPage.iCurrentView == moView.MAIN_PAGE_NUM || moPage.iCurrentView == moView.DETAIL_PAGE_NUM || moPage.iCurrentView == moView.PAYMENT_PAGE_NUM
                    || moPage.iCurrentView == moView.COMMISSION_PAGE_NUM || moPage.iCurrentView == moView.OPTIONS_PAGE_NUM )) 
                    || (User.IsMobile && (moPage.iCurrentView == moView.MAIN_PAGE_NUM)));
            }
        }

        private bool ShowSearchPrinter
        {
            get
            {
                return (mbSearchInitiated_fl && mbSearchPopulated_fl);
            }
        }


        private bool ShowListingPrinter
        {
            get
            {
                return (mbListingInitiated_fl && mbListingPopulated_fl);
            }
        }

        private bool InventoryBusiness
        {
            get
            {
                return (moDatabase.iCurBusiness_typ == GlobalVar.goConstant.INVENTORY_BUSINESS_NUM);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // These are instantiated in FormInit().
        private clsGeneral moGeneral;                                                               
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsMoney moMoney;
        private clsCurrency moCurrency;
        private clsVoucher moVoucher;
        private clsVendor moVendor;
        private clsTransactionPayment moTransactionPayment;
        private clsJobCost moJobCost;
        private clsPaymentSchedule moPaymentSchedule;
        private Models.clsChargeDetail moDetail;
        private Models.clsCustomField moCustomFields;
        private Models.clsSession moSession;
        private Models.clsSpreadsheet moHistory;

        private clsSerial moSerial;
        private clsSerialUtility moSerialUtility;

        private clsReportViewer moReport;
        private clsInquiry moInquiry;

        private List<Models.clsCombobox> StatusTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> JobCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> FundCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> LocationCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> TaxCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ViaCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> PriceCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> AgentCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> TermsCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> FOBCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> PostingCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> DunnCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> IntervalTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> RecurTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> BillToCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> PaymentTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CalendarYearList = new List<Models.clsCombobox>();

        private string msDefaultRestrictionClause = "";
        private string msFund_cd = "";
        private string msHoldStatusMessage = "";

        private decimal mmPriceExchange_rt = 0;
        private decimal mmExchange_rt = 0;
        private decimal mmSaleExchange_rt = 0;

        // miMatrixColumn counts column when matrix is populated 
        //
        private int miMatrixColumn = 0;


        // For invoice printing
        //
        private string cboReport_typ = "";
        private bool chkSendEmail_fl = false;
        private string txtEmailRecipient = "";

        // Listing options
        //
        private List<Models.clsCombobox> ListingByList = new List<Models.clsCombobox>();
        private string cboListingBy = "";
        private bool mbListingInitiated_fl = false;
        private bool mbListingPopulated_fl = false;

        // Search options
        //
        private string cboSearchYear = "";
        private bool mbSearchInitiated_fl = false;
        private bool mbSearchPopulated_fl = false;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader                   
        {
            // Listing of UI items on the header
            //
            public string txtKey_id = "";
            public string txtTransaction_num = "";
            public string cboStatus_typ = "";
            public string cboFund_cd = "";
            public string cboLocation_cd = "";

            public string txtVendor_cd = "";
            public string txtVendor_nm = "";
            public string txtVendorAttn = "";
            public string txtVendorAddress1 = "";
            public string txtVendorAddress2 = "";
            public string txtVendorAddress3 = "";
            public string txtYourReference = "";
            public string txtOurReference = "";
            public string txtComment = "";
            public string txtOrder_num = "";
            public string txtWeight = "";
            public string txtTotal_amt = "";
            public string txtTax_pc = "";
            public string txtNonTaxable_amt = "";
            public string txtTaxable_amt = "";
            public string txtTax_amt = "";
            public string txtDiscount_amt = "";
            public string txtFreight_amt = "";
            public string txtPaid_amt = "";
            public string txtDue_amt = "";
            public string cboRecur_typ = "";
            public string txtRecurTo_num = "";
            public string txtBillTo_cd = "";
            public string txtBillTo_nm = "";
            public string txtBillToAttn = "";
            public string txtBillToAddress1 = "";
            public string txtBillToAddress2 = "";
            public string txtBillToAddress3 = "";
            public string txtBatch_num = "0";
            public string txtPrinted_num = "0";
            public string txtFreightTax_amt = "";
            public string txtCost_amt = "";
            public string txtAdjusted_amt = "";

            public string txtBillToCity = "";
            public string txtBillToState = "";
            public string txtBillToZipCode = "";
            public string txtBillToCountry_cd = "";
            public string txtBillToPhone = "";
            public string txtBillToFax = "";
            public string txtUserApproved_cd = "";
            public string txtToApprove_num = "";

            public string txtRemaining_amt = "";

            public string cboJob_cd = "";
            public string cboTax_cd = "";
            public string cboVia_cd = "";
            public string cboAgent_cd = "";
            public string cboTerms_cd = "";
            public string cboFOB_cd = "";
            public string cboPosting_cd = "";
            public string cboDunn_cd = "";
            public string cboBillTo_cd = "";

            public bool chkRecur_fl = false;

            // Payment schedule
            //
            public string txtSplit_num = "";
            public string cboInterval_typ = "";
            public string mskStarting_dt = "";
            public DateTime? dtStarting_dt = null;

            // Datetime component is not very user-friendly, yet, as of VS2019.
            // For better understanding this, read the comment on bUseDatePicker_fl in clsUser.
            //
            public string mskEntry_dt = "";
            public string mskApply_dt = "";
            public string mskToRecur_dt = "";
            public string mskReceived_dt = "";
            public string mskRequired_dt = "";
            public string mskDue_dt = "";
            public string mskInvoice_dt = "";

            public DateTime? dtEntry_dt = null;
            public DateTime? dtApply_dt = null;
            public DateTime? dtToRecur_dt = null;
            public DateTime? dtReceived_dt = null;
            public DateTime? dtRequired_dt = null;
            public DateTime? dtDue_dt = null;
            public DateTime? dtInvoice_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag                                                                     
            {
                public string txtKey_id  = "";
                public string cboStatus_typ = "";
                public string cboFund_cd = "";
                public string cboLocation_cd = "";
                public string cboTax_cd = "";
                public string cboBillTo_cd = "";
                public string cboAgent_cd = "";
                public string txtVendor_cd = "";
                public string txtOrder_num = "";
                public string txtFreight_amt = "";

                public string txtMultiOrder_num = "";
                public string txtPOSItem_cd = "";
                public string txtMatrixItem_cd = "";

                public string mskEntry_dt = "";
                public string mskApply_dt = "";
                public string mskToRecur_dt = "";
                public string mskReceived_dt = "";
                public string mskRequired_dt = "";
                public string mskDue_dt = "";
                public string mskStarting_dt = "";
                public string mskInvoice_dt = "";

                public DateTime? dtEntry_dt = null;
                public DateTime? dtApply_dt = null;
                public DateTime? dtToRecur_dt = null;
                public DateTime? dtReceived_dt = null;
                public DateTime? dtRequired_dt = null;
                public DateTime? dtDue_dt = null;
                public DateTime? dtStarting_dt = null;
                public DateTime? dtInvoice_dt = null;
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()                                                                  
            {
                Tag.txtKey_id = txtKey_id;
                Tag.cboStatus_typ = cboStatus_typ;
                Tag.cboFund_cd = cboFund_cd;
                Tag.cboLocation_cd = cboLocation_cd;
                Tag.cboTax_cd = cboTax_cd;
                Tag.cboBillTo_cd = cboBillTo_cd;
                Tag.cboAgent_cd = cboAgent_cd;
                Tag.txtVendor_cd = txtVendor_cd;
                Tag.txtOrder_num = txtOrder_num;
                Tag.txtFreight_amt = txtFreight_amt;

                Tag.mskEntry_dt = mskEntry_dt;
                Tag.mskApply_dt = mskApply_dt;
                Tag.mskToRecur_dt = mskToRecur_dt;
                Tag.mskReceived_dt = mskReceived_dt;
                Tag.mskRequired_dt = mskRequired_dt;
                Tag.mskDue_dt = mskDue_dt;
                Tag.mskInvoice_dt = mskInvoice_dt;

                Tag.dtEntry_dt = dtEntry_dt;
                Tag.dtApply_dt = dtApply_dt;
                Tag.dtToRecur_dt = dtToRecur_dt;
                Tag.dtReceived_dt = dtReceived_dt;
                Tag.dtRequired_dt = dtRequired_dt;
                Tag.dtDue_dt = dtDue_dt;
                Tag.dtInvoice_dt = dtInvoice_dt;

                Tag.mskStarting_dt = mskStarting_dt;
                Tag.dtStarting_dt = dtStarting_dt;

            }
        }
        private clsHeader Header = new clsHeader();

        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;                        
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            moSession.RemoveSession(moDatabase);        // Delete the session file.

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            // If user uses date-picker, we need to change the date field.
            //
            if (User.bUseDatePicker_fl && moUtility.SLeft(field_name, 3) == "msk" && moUtility.SRight(field_name, 3) == "_dt")
            {
                field_name = moUtility.SReplace(field_name, "msk", "dt");
            }
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows(int lines_to_add = 0)
        {
            if (lines_to_add <= 0)
            {
                lines_to_add = User.iLinesToIncrease;
            }

            if (moDetail.AddMoreRows(lines_to_add))
            {
                FormShowMessage();
                FormRecreateGrid();
                return false;
            }

            return true;
        }

        private bool FormCalculateCurrentRow(Models.clsChargeDetail.clsGrid cur_item)
        {
            bool return_value = false;
            int cur_row = 0;

            try
            {

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCalculateCurrentRow)");
            }

            return return_value;
        }

        private bool FormCalculateDue()
        {
            bool return_value = false;
            decimal amt_total = 0;
            decimal amt_paid = 0;

            try
            {
               
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "FormCalculateDue");
            }

            return return_value;
        }
        private bool FormCalculateTotal(decimal amt_tax = 0)
        {
            bool return_value = false;

            try
            {
                
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCalculateTotal)");
            }

            return return_value;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            
            return true;
        }

        private bool FormCheckDetail()                                                             // validate Detail for saving.
        {

            return true;
        }


        private bool FormCheckExtra()                                                              // validate extra other than the header and detail.
        {
            bool return_value = false;
            decimal total_amt = 0;
            string entity_code = "";

            try
            {
                

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckExtra)");
            }

            return return_value;
        }

        private bool FormCheckHeader()                                                             // validate the header data.
        {
            bool return_value = false;

            try
            {
                
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckHeader)");
            }

            return return_value;
        }

        private bool FormCheckConcurrency(clsRecordset cur_set)                                    // Check if someone has changed this record while it is open in this session.
        {
            if (cur_set.IsNonEmpty()) 
            {
                if (moPage.bNew_fl)
                {
                    // Let it go.  FormPreSave() will take care of this case.
                }
                else if (moPage.CheckForConcurrency(cur_set) == false)
                {
                    // If someone has updated this record in the meantime.
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                }
            }
            else if (moPage.bNew_fl == false)
            {
                // If current record is missing, it could have been posted by someone.
                // Need to make sure it does not exist in the posted table.
                //
                if (moValidate.IsValidTransaction(moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id), false))
                {
                    FormShowMessage(User.Language.oMessage.THIS_TRX_EXISTS_AND_HAS_BEEN_POSTED_ALREADY);
                    return false;
                }
            }

            return true;
        }

        private bool FormCheckToDelete()
        {
            clsIntegrity o_integrity = new clsIntegrity(ref moDatabase);

            if (FormCheckSecurity() == false)
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }
            else if (modFormUtility.IsReservedRecord(ref moDatabase, Header.txtKey_id, moPage.bReserved_fl))
            {
                FormShowMessage(User.Language.oMessage.RESERVED_RECORD_IS_NOT_ALLOWED_TO_DELETE);
                return false;
            }
            else if (o_integrity.IsReferenced(moPage.sModule_id, moPage.sKeyField_nm, Header.txtKey_id))
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }

            return true;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearDetail();
            FormClearExtra();

            return true;
        }

        private bool FormClearDetail()                                                             // Clear the detail.
        {
            moDetail.iNextLine_id = 1;
            moDetail.iTotalRows = User.iLinesToIncrease;
            moUtility.ResizeDim(ref moDetail.Data, Models.clsChargeDetail.TOTAL_COLUMNS - 1, moDetail.iTotalRows - 1);
            
            return FormRecreateGrid();
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            Header.txtRemaining_amt = "";

            mmPriceExchange_rt = 0;
            mmExchange_rt = 0;
            mmSaleExchange_rt = 0;

            msFund_cd = "";
            msHoldStatusMessage = "";

            chkSendEmail_fl = false;
            txtEmailRecipient = "";

            JobCodeList.Clear();            // Job is vendor-dependant

            moTransactionPayment = new clsTransactionPayment(ref moDatabase);

            moJobCost.Grid.Clear();
            moPaymentSchedule.CreateGrid();
            moHistory.Clear();

            // Custom Fields
            //
            moCustomFields.ClearGrid();

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {
            Header.txtKey_id = "";
            Header.cboFund_cd = "";
            Header.cboStatus_typ = "";
            Header.cboLocation_cd = "";
            Header.txtComment = "";

            Header.txtVendor_cd = "";
            Header.txtVendor_nm = "";
            Header.txtVendorAttn = "";
            Header.txtVendorAddress1 = "";
            Header.txtVendorAddress2 = "";
            Header.txtVendorAddress3 = "";
            Header.txtYourReference = "";
            Header.txtOurReference = "";
            Header.txtComment = "";
            Header.txtOrder_num = "";
            Header.txtWeight = "";
            Header.txtTotal_amt = "";
            Header.txtTax_pc = "";
            Header.txtNonTaxable_amt = "";
            Header.txtTaxable_amt = "";
            Header.txtTax_amt = "";
            Header.txtDiscount_amt = "";
            Header.txtFreight_amt = "";
            Header.txtPaid_amt = "";
            Header.txtDue_amt = "";
            Header.txtRecurTo_num = "";
            Header.txtBillTo_cd = "";
            Header.txtBillTo_nm = "";
            Header.txtBillToAttn = "";
            Header.txtBillToAddress1 = "";
            Header.txtBillToAddress2 = "";
            Header.txtBillToAddress3 = "";
            Header.txtTransaction_num = "";
            Header.txtBatch_num = "0";
            Header.txtPrinted_num = "0";
            Header.txtFreightTax_amt = "";

            Header.txtBillToCity = "";
            Header.txtBillToState = "";
            Header.txtBillToZipCode = "";
            Header.txtBillToCountry_cd = "";
            Header.txtBillToPhone = "";
            Header.txtBillToFax = "";
            Header.txtUserApproved_cd = "";
            Header.txtToApprove_num = "";
            Header.txtAdjusted_amt = "";
            Header.txtCost_amt = "";

            Header.cboJob_cd = "";
            Header.cboTax_cd = "";
            Header.cboVia_cd = "";
            Header.cboAgent_cd = "";
            Header.cboTerms_cd = "";
            Header.cboFOB_cd = "";
            Header.cboPosting_cd = "";
            Header.cboDunn_cd = "";
            Header.cboRecur_typ = "";
            Header.cboBillTo_cd = "";

            Header.chkRecur_fl = false;

            Header.txtSplit_num = "";
            Header.cboInterval_typ = "";

            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            //
            Header.mskEntry_dt = "";
            Header.mskApply_dt = "";
            Header.mskToRecur_dt = "";
            Header.mskReceived_dt = "";
            Header.mskRequired_dt = "";
            Header.mskDue_dt = "";
            Header.mskInvoice_dt = "";
            Header.mskStarting_dt = "";
            FormSyncDates(false);

            return true;
        }

        private bool FormClearMessage()                                                            
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            moPage.bInDialog_fl = true;         // Meaning a dialog started

            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    moPage.bInDialog_fl = false;            // Meaning a dialog is enidng with Cancel button
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }

                Modal.Release();                                                                   // Release this call and proceed.
            }

            moPage.bInDialog_fl = false;            // Meaning a dialog is enidng with Cancel button
            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id) || moPage.bNew_fl)
                {
                    FormClear();
                    return true;
                }
                else if (FormCheckToDelete() == false)
                {
                    return false;
                }

                // Transaction begins here.
                //
                if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }

                if (modFormUtility.RecordDelete(ref moDatabase, moPage.iScreen_typ, Header.txtKey_id, moPage.sKeyField_nm, moPage.sTable_nm, moPage.sDetailTable_nm, moPage.sRestrictionClause, moPage.iTransaction_typ) == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }
                else if (FormDeleteExtra() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }

                // Transaction ends here.
                //
                if (moDatabase.TransactionCommit() == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDelete)");
                moDatabase.TransactionRollback();
                return_value = false;
            }

            return return_value;
        }

        private bool FormDeleteExtra()
        {

            return true;
        }

        private bool FormDeleteCurrentRow(Models.clsChargeDetail.clsGrid cur_item)
        {
            bool return_value = false;
            int old_num = cur_item.Row_num;

            try
            {
                if (moDetail.DeleteCurrentRow(cur_item) == false)
                {
                    FormShowMessage();
                    FormRecreateGrid();
                    return false;
                }
                if (FormCalculateTotal() == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDeleteCurrentRow)");
                FormRecreateGrid();
            }

            return return_value;
        }

        private bool FormEnableBatch(bool switch_fl = true)
        {
            

            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormFindRecord(ref clsRecordset cur_set, int matching_type = 0)
        {
            bool return_value = false;

            matching_type = (int)(moUtility.IIf(matching_type > 0, matching_type, GlobalVar.goConstant.MATCHING_RECORD_TYPE));
            return_value = modFormUtility.RecordRead(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sTable_nm, moPage.sKeyField_nm, moPage.sPreviousKey_id, moPage.sRestrictionClause, ref matching_type);

            return return_value;
        }


        public bool FormCheckExchangeRate(int apply_date = 0)
        {
            bool return_value = false;
            decimal old_exchange_rate = mmSaleExchange_rt; // DO NOT change to Double because of comparison issue
            decimal old_price_exchange_rate = mmPriceExchange_rt;

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                mmSaleExchange_rt = 1;
                mmPriceExchange_rt = 1;
                return return_value;
            }
            else if (moUtility.IsEmpty(Header.mskApply_dt) && apply_date == 0)
            {
                mmSaleExchange_rt = 1;
                mmPriceExchange_rt = 1;
                return return_value;
            }

            if (apply_date == 0)
            {
                apply_date = moGeneral.ToNumDate(Header.mskApply_dt);
            }
            if (apply_date == 0)
            {
                apply_date = moGeneral.CurrentDate();
            }

            moCurrency.GetSaleExchangeRate(moDatabase.sCurrency_cd, ref mmSaleExchange_rt, ref mmPriceExchange_rt, apply_date);

            if ((old_exchange_rate != mmSaleExchange_rt) || (old_price_exchange_rate != mmPriceExchange_rt))
            {
                return_value = true;
            }

            return return_value;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListingCharge();
            moSpreadsheet = new Models.clsSpreadsheet();
            moSearch = new Models.clsListingCharge();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moMoney = new clsMoney(ref moDatabase);
            moCurrency = new clsCurrency(ref moDatabase);
            moVoucher = new clsVoucher(ref moDatabase);
            moVendor = new clsVendor(ref moDatabase);
            moTransactionPayment = new clsTransactionPayment(ref moDatabase);
            moJobCost = new clsJobCost(ref moDatabase);
            moPaymentSchedule = new clsPaymentSchedule();
            moDetail = new Models.clsChargeDetail(GlobalVar.goConstant.TRX_PURCHASE_TYPE);
            moCustomFields = new Models.clsCustomField() ;
            moSession = new Models.clsSession();
            moHistory = new Models.clsSpreadsheet();

            moSerial = new clsSerial(ref moDatabase);
            moSerialUtility = new clsSerialUtility();

            moReport = new clsReportViewer();
            moInquiry = new clsInquiry();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.APMENU_NAME;
            moPage.Title = User.Language.oCaption.LOOKUP_VOUCHER;
            moPage.iScreen_typ = GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE;
            moPage.iTransaction_typ = GlobalVar.goConstant.TRX_PURCHASE_TYPE;
            moPage.iJournal_typ = 0;

            // sRestrictionClause will need to change as some conditions change, which is done in ResetRestrictionClause().
            // moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);
            msDefaultRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);
            ResetRestrictionClause();

            Modal.Release();

            FormInitHeader();
            FormInitDetail();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitDetail()                                                              // Initialize the page at loading.  Only once.
        {
            // Detail table name.
            //
            moPage.sDetailTable_nm = "tblAPChargeDet";

            moUtility.ResizeDim(ref moDetail.Data, Models.clsChargeDetail.TOTAL_COLUMNS - 1, 0);    // These initializations are necessary
            moUtility.ResizeDim(ref moDetail.FieldName, Models.clsChargeDetail.TOTAL_COLUMNS - 1);  // Models.clsChargeDetail.TOTAL_COLUMNS should be large enough to cover all transactions

            moDetail.FieldName[Models.clsChargeDetail.ITEM_CODE_COL] = moVoucher.sDetailFieldNames[clsVoucher.ITEM_CODE_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.LOCATION_COL] = moVoucher.sDetailFieldNames[clsVoucher.LOCATION_COL]; 

            moDetail.FieldName[Models.clsChargeDetail.ITEM_MANUFACTURER_COL] = moVoucher.sDetailFieldNames[clsVoucher.ITEM_MANUFACTURER_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.ITEM_BRAND_COL] = moVoucher.sDetailFieldNames[clsVoucher.ITEM_BRAND_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.ITEM_MODEL_COL] = moVoucher.sDetailFieldNames[clsVoucher.ITEM_MODEL_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.ITEM_STYLE_COL] = moVoucher.sDetailFieldNames[clsVoucher.ITEM_STYLE_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.ITEM_COLOR_COL] = moVoucher.sDetailFieldNames[clsVoucher.ITEM_COLOR_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.ITEM_SIZE_COL] = moVoucher.sDetailFieldNames[clsVoucher.ITEM_SIZE_COL]; 

            moDetail.FieldName[Models.clsChargeDetail.DESCRIPTION_COL] = moVoucher.sDetailFieldNames[clsVoucher.DESCRIPTION_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.UNIT_CODE_COL] = moVoucher.sDetailFieldNames[clsVoucher.UNIT_CODE_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.QTY_SHIPPED_COL] = moVoucher.sDetailFieldNames[clsVoucher.QTY_SHIPPED_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.QTY_ORDERED_COL] = moVoucher.sDetailFieldNames[clsVoucher.QTY_ORDERED_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.QTY_PREV_RETURN_COL] = "fReturned_qty";
            moDetail.FieldName[Models.clsChargeDetail.QTY_BACKORDER_COL] = moVoucher.sDetailFieldNames[clsVoucher.QTY_BACKORDER_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.UNIT_PRICE_COL] = moVoucher.sDetailFieldNames[clsVoucher.UNIT_PRICE_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.AMT_EXTENDED_COL] = moVoucher.sDetailFieldNames[clsVoucher.AMT_EXTENDED_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.DISC_PERC_COL] = moVoucher.sDetailFieldNames[clsVoucher.DISC_PERC_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.TAX_CODE_COL] = moVoucher.sDetailFieldNames[clsVoucher.TAX_CODE_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.FULL_ACCT_CODE_COL] = moVoucher.sDetailFieldNames[clsVoucher.FULL_ACCT_CODE_COL]; 

            moDetail.FieldName[Models.clsChargeDetail.AMT_TAX_COL] = moVoucher.sDetailFieldNames[clsVoucher.AMT_TAX_COL];  
            moDetail.FieldName[Models.clsChargeDetail.TAX_PERC_COL] = moVoucher.sDetailFieldNames[clsVoucher.TAX_PERC_COL];  
            moDetail.FieldName[Models.clsChargeDetail.TOTAL_COST_COL] = moVoucher.sDetailFieldNames[clsVoucher.TOTAL_COST_COL];  
            moDetail.FieldName[Models.clsChargeDetail.ITEM_TYPE_COL] = moVoucher.sDetailFieldNames[clsVoucher.ITEM_TYPE_COL];  
            moDetail.FieldName[Models.clsChargeDetail.AMT_DISC_COL] = moVoucher.sDetailFieldNames[clsVoucher.AMT_DISC_COL];  
            moDetail.FieldName[Models.clsChargeDetail.JOB_CODE_COL] = moVoucher.sDetailFieldNames[clsVoucher.JOB_CODE_COL];  
            moDetail.FieldName[Models.clsChargeDetail.ORDER_NUM_COL] = moVoucher.sDetailFieldNames[clsVoucher.ORDER_NUM_COL];  
            moDetail.FieldName[Models.clsChargeDetail.LINE_ID_COL] = moVoucher.sDetailFieldNames[clsVoucher.LINE_ID_COL];
            moDetail.FieldName[Models.clsChargeDetail.ITEM_TYPE_COL] = moVoucher.sDetailFieldNames[clsVoucher.ITEM_TYPE_COL];

            FormClearDetail();

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = "tblAPCharge"; 
            moPage.sKeyField_nm = "itransaction_num";

            return true;
        }

        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {

            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            // FormSave() & FormCheck() use the plain textbox whose name starts with "msk"
            // dt* variables are only to interact with UI.  Internally, msk* fields are used.
            //
            FormSyncDates(User.bUseDatePicker_fl);


            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback
            
            return true;
        }

        private bool FormInsertNewRow(Models.clsChargeDetail.clsGrid cur_item)
        {
            bool return_value = false;
            int old_num = cur_item.Row_num;

            try
            {
                if (moDetail.InsertNewRow(cur_item) == false)
                {
                    FormShowMessage();
                    FormRecreateGrid();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormInsertNewRow)");
                FormRecreateGrid();
            }

            return return_value;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;
            clsCustomization custom_fields = new clsCustomization(ref moDatabase);

            try
            {
                if (FormReceiveValues() == false)                    // All pages that use session value need to capture it here before FormOpenDatabase()
                {
                    return false;
                }
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                modLoadUtility.LoadLocationCode(ref moDatabase, ref LocationCodeList);
                modLoadUtility.LoadPostedStatusType(ref moDatabase, ref StatusTypeList);
                modLoadUtility.LoadJobCode(ref moDatabase, ref JobCodeList);
                modLoadUtility.LoadFundCode(ref moDatabase, ref FundCodeList, moGeneral.CurrentDate(), GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE); // Need to load fund whether it is fund accouning or not
                modLoadUtility.LoadRecurringType(ref moDatabase, ref RecurTypeList);
                modLoadUtility.LoadAPDunnCode(ref moDatabase, ref DunnCodeList);
                modLoadUtility.LoadAPTaxCode(ref moDatabase, ref TaxCodeList);
                modLoadUtility.LoadViaCode(ref moDatabase, ref ViaCodeList);
                modLoadUtility.LoadAPAgent(ref moDatabase, ref AgentCodeList);
                modLoadUtility.LoadAPTermsCode(ref moDatabase, ref TermsCodeList);
                modLoadUtility.LoadAPPostingCode(ref moDatabase, ref PostingCodeList);
                modLoadUtility.LoadFOB(ref moDatabase, ref FOBCodeList);
                modLoadUtility.LoadSplitPaymentFrequency(ref IntervalTypeList);
                modLoadUtility.LoadPaymentType(ref moDatabase, ref PaymentTypeList, false, true, true, false, true, true);

                modLoadUtility.LoadListingBy(ref moDatabase, ref ListingByList, moPage.iTransaction_typ, User);
                modLoadUtility.LoadCalendarYear(ref CalendarYearList);
                cboSearchYear = moGeneral.CurrentYear().ToString();

                FormEnableBatch(false);

                ResetRestrictionClause();                                       // Has to set here after database connection.

                // Custom Fields
                //
                if (custom_fields.ReadCustomInfo(moPage.iTransaction_typ, ""))
                {
                    moCustomFields.CreateGrid(custom_fields.sField_nm, custom_fields.sCaptions, custom_fields.bRequired);
                }

                if (moUtility.IsNonEmpty(moPage.sInitialKey_id))
                {
                    Header.txtKey_id = moPage.sInitialKey_id;
                    txtKey_id_Changed();
                }

                User.bConnected_fl = true;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormMove(int record_move_direction)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormClear();

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            if (FormFindRecord(ref cur_set, record_move_direction) == false)
            {
                return false;
            }

            FormShow(cur_set);
            return true;

        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostSave()
        {
            // If this is a transaction page, and transaction number has changed, let the user know.
            //
            if (moPage.sPreviousKey_id != Header.txtKey_id)
            {
                FormShowMessage(User.Language.oMessage.TRX_NUM_HAS_CHANGED_TO + "  " + Header.txtKey_id, false);
            }

            moPage.sPreviousKey_id = Header.txtKey_id;

            return true;
        }

        private bool FormPostTransactionRealtime()
        {
            
            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {
            
            return true;
        }

        private bool FormReArrangeDetail()                                                         // Arrange(show/hide, enable/disable) the columns in the detail(grid)
        {
            return true;
        }

        private bool FormReArrangeHeader()                                                         //  Arrange(show/hide, enable/disable) the fields in the header section
        {
            Lock.Clear();


            return true;
        }

        private bool FormRecreateDetail()                                                           //  Sync moDetail.Data with moDetail.Grid for the items that do not have event-handler ONLY.
        {
            if (moDetail.RecreateDetail() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateDetailLine(Models.clsChargeDetail.clsGrid cur_item, int row_num = -1)
        {
            if (moDetail.RecreateDetailLine(cur_item, row_num) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateGrid()                                                             //  Create moDetail.Grid according to moDetail.Data
        {
            if (moDetail.RecreateGrid() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormReceiveValues()
        {
            // If connected already, return true.  This means this page came through the menu system.
            //
            if (moUtility.IsNonEmpty(User.sServer_nm) || moDatabase.IsConnected())
            {
                return true;
            }

            // Otherwise, need to login with the info passed from the calling page.
            //
            if (modGeneralUtility.GetPassedParameters(StarterValue, User, moSession) == false)
            {
                FormShowMessage(User.Language.oMessage.PLEASE_LOG_IN_FIRST);
                return false;
            }

            moPage.sInitialKey_id = moSession.Value.Entity;

            return true;
        }

        private bool FormSave()
        {
            return true;
        }

        private bool FormSaveDetail()
        {
            return true;
        }

        private bool FormSaveExtra(clsRecordset cur_set)
        {
            return true;
        }

        private bool FormSaveHeader(clsRecordset cur_set)
        {
            return true;
        }

        private bool FormSearch()
        {
            string search_detail = modCommonUtility.GetTransactionDetailSearchCriteria(moDetail.Grid, moPage.sDetailTable_nm, moPage.iTransaction_typ, Models.clsChargeDetail.ITEM_CODE_COL, moUtility.ToInteger(Header.txtOrder_num));
            string where_clause = GetSearchCriteria();

            if (moUtility.IsEmpty(where_clause))
            {
                where_clause = search_detail;
            }
            else
            {
                where_clause += moUtility.IIf(moUtility.IsNonEmpty(search_detail), " AND ", "") + search_detail;
            }

            if (moUtility.IsEmpty(where_clause))
            {
                FormShowMessage(User.Language.oMessage.PLEASE_ENTER_THE_SEARCH_CRITERIA_ON_THE_MAIN_ENTRY_TAB);
                return false;
            }

            mbSearchPopulated_fl = false;

            where_clause = moUtility.IIf(moUtility.IsNonEmpty(moPage.sRestrictionClause), moPage.sRestrictionClause, "iTransaction_typ = " + moPage.iTransaction_typ.ToString()) + " AND " + where_clause;

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            where_clause = modCommonUtility.AddCommonTransactionSearchClause(where_clause, moPage.iTransaction_typ, cboSearchYear);

            if (moSearch.Show(moDatabase, moPage, where_clause) == false)
            {
                FormShowMessage();
                return false;
            }

            mbSearchInitiated_fl = true;
            mbSearchPopulated_fl = (moSearch.Grid.Count > 0);

            if (mbSearchPopulated_fl == false)
            {
                FormShowMessage(User.Language.oMessage.NO_MATCHING_RECORDS_FOUND);
            }

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {
            if (FormShowHeader(cur_set) == false)
            {
                return false;
            }
            else if (FormShowDetail() == false)
            {
                return false;
            }
            else if (FormShowExtra(cur_set) == false)
            {
                return false;
            }

            FormReArrangeHeader();
            FormReArrangeDetail();

            return true;
        }

        private bool FormShowDetail()
        {
            bool return_value = false;
            int row_num = 0;

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                FormClearDetail();

                if (modDetailUtility.GetDetail(ref moDatabase, moPage.Title, Header.txtKey_id, moPage.sKeyField_nm, ref moDetail.iTotalRows, moPage.sDetailTable_nm, moPage.iTransaction_typ, moDetail.FieldName, ref moDetail.Data) == false)
                {
                    FormShowMessage();
                    return false;
                }

                moDetail.iNextLine_id = modCommonUtility.GetNextLineId(moDetail.Data, Models.clsChargeDetail.LINE_ID_COL);

                if (false == moSerialUtility.ReadSerialData(ref moDatabase, ref moSerial, ref moDetail.Data, moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id)))
                {
                    FormShowMessage();
                    return false;
                }

                if (FormRecreateGrid() == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowDetail)");
            }

            return return_value;
        }

        private bool FormShowExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                moPage.Clear();
                moPage.PreserveTimestamp(cur_set);
                moPage.PreserveOriginal(cur_set);
                moPage.bNew_fl = false;

                // This is where bReadOnly_fl & bReserved_fl are set according to the nature of the current record.
                //
                moJobCost.Grid.Clear();

                if (GetPaymentSchedule() == false)
                {
                    return false;
                }

                moPage.sPreviousKey_id = Header.txtKey_id;
                Header.Preserve();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowHeader(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                Header.txtKey_id = cur_set.sField(moPage.sKeyField_nm);
                Header.txtTransaction_num = cur_set.sField("sTransaction_num");
                Header.cboStatus_typ = cur_set.iField("iStatus_typ").ToString();
                Header.cboFund_cd = GlobalVar.goFund.GetSelectedFundCodeToDisplay(ref moDatabase, cur_set.sField("sFund_cd"));

                Header.txtVendor_cd = cur_set.sField("sVendor_cd");
                modLoadUtility.LoadJobCode(ref moDatabase, ref JobCodeList, Header.txtVendor_cd);

                Header.cboJob_cd = cur_set.sField("sJob_cd");
                Header.txtYourReference = cur_set.sField("sYourReference");
                Header.txtOurReference = cur_set.sField("sReference");
                Header.cboLocation_cd = cur_set.sField("sLocation_cd");
                Header.cboDunn_cd = cur_set.sField("sDunn_cd");
                Header.txtComment = cur_set.sField("sComment");
                Header.cboTax_cd = cur_set.sField("sTax_cd");

                if (cur_set.iField("iOrder_num") > 0)
                {
                    Header.txtOrder_num = cur_set.iField("iOrder_num").ToString();
                }
                else
                {
                    Header.txtOrder_num = "";
                }
                Header.cboVia_cd = cur_set.sField("sVia_cd");
                Header.cboAgent_cd = cur_set.sField("sAgent_cd");
                Header.cboTerms_cd = cur_set.sField("sTerms_cd");
                Header.cboFOB_cd = cur_set.sField("sFob_cd");
                Header.txtVendorAttn = cur_set.sField("sVendorAttn");
                Header.txtVendorAddress3 = cur_set.sField("sVendorAddress3");
                Header.txtVendorAddress2 = cur_set.sField("sVendorAddress2");
                Header.txtVendorAddress1 = cur_set.sField("sVendorAddress1");
                Header.txtVendor_nm = cur_set.sField("sVendor_nm");

                Header.txtTotal_amt = moMoney.ToStrMoney(cur_set.mField("mTotal_amt"));
                Header.txtTax_pc = cur_set.mField("fTax_pc").ToString();
                Header.txtNonTaxable_amt = moMoney.ToStrMoney(cur_set.mField("mNonTaxable_amt"));
                Header.txtTaxable_amt = moMoney.ToStrMoney(cur_set.mField("mTaxable_amt"));
                Header.txtTax_amt = moMoney.ToStrMoney(cur_set.mField("mTax_amt"));
                Header.txtDiscount_amt = moMoney.ToStrMoney(cur_set.mField("mDiscForEarlyPaid_amt"));
                Header.txtPaid_amt = moMoney.ToStrMoney(cur_set.mField("mPaid_amt"));
                Header.txtDue_amt = moMoney.ToStrMoney(cur_set.mField("mDue_amt"));
                Header.cboPosting_cd = cur_set.sField("sPosting_cd");
                Header.txtBatch_num = cur_set.iField("iBatch_num").ToString();
                Header.txtPrinted_num = cur_set.iField("iPrinted_num").ToString();
                Header.txtBillToAttn = cur_set.sField("sBillToAttn");
                Header.txtBillToAddress3 = cur_set.sField("sBillToAddress3");
                Header.txtBillToAddress2 = cur_set.sField("sBillToAddress2");
                Header.txtBillToAddress1 = cur_set.sField("sBillToAddress1");
                Header.txtBillTo_nm = cur_set.sField("sBillTo_nm");
                Header.cboFund_cd = GlobalVar.goFund.GetSelectedFundCodeToDisplay(ref moDatabase, cur_set.sField("sFund_cd").ToString());
                Header.txtFreightTax_amt = cur_set.mField("mFreightTax_amt").ToString();
                Header.txtCost_amt = moMoney.ToStrMoney(cur_set.mField("mIVCost_amt"));

                if (Math.Abs(cur_set.mField("mAdjusted_amt")) >= moDatabase.mSmallestMoney_amt || Math.Abs(cur_set.mField("mReturned_amt")) >= moDatabase.mSmallestMoney_amt)
                {
                    Header.txtAdjusted_amt = moMoney.ToStrMoney(cur_set.mField("mAdjusted_amt") + cur_set.mField("mReturned_amt"));
                }

                Header.cboRecur_typ = cur_set.iField("iRecurring_typ").ToString();
                Header.txtRecurTo_num = cur_set.iField("iToRecur_num").ToString();

                if (cur_set.iField("iRecurring_typ") > 0 && (cur_set.iField("iToRecur_num") > 0 || cur_set.iField("iToRecur_dt") > 0)) 
                {
                    Header.chkRecur_fl = true;
                }
                else
                {
                    Header.chkRecur_fl = false;
                    Header.cboRecur_typ = "";
                    Header.txtRecurTo_num = "";
                }

                if (cur_set.mField("fWeight") > 0)
                {
                    Header.txtWeight = cur_set.mField("fWeight").ToString();
                }
                else
                {
                    Header.txtWeight = "";
                }

                if (cur_set.mField("mFreight_amt") > 0)
                {
                    Header.txtFreight_amt = moMoney.ToStrMoney(cur_set.mField("mFreight_amt"));
                }
                else
                {
                    Header.txtFreight_amt = "";
                }

                Header.txtBillToFax = cur_set.sField("sBillToFax");
                Header.txtBillToPhone = cur_set.sField("sBillToPhone");
                Header.txtBillToCountry_cd = cur_set.sField("sBillToCountry_cd");
                Header.txtBillToZipCode = cur_set.sField("sBillToZipCode");
                Header.txtBillToState = cur_set.sField("sBillToState");
                Header.txtBillToCity = cur_set.sField("sBillToCity");
                Header.txtBillTo_cd = cur_set.sField("sBillTo_cd");
                Header.txtUserApproved_cd = cur_set.sField("sUserApproved_cd");
                Header.txtToApprove_num = cur_set.iField("iToApprove_num").ToString();

                // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
                // Make sure both, dt* and msk*, are sync'ed.
                //
                Header.mskEntry_dt = moGeneral.ToStrDate(cur_set.iField("iEntry_dt"));
                Header.mskApply_dt = moGeneral.ToStrDate(cur_set.iField("iApply_dt"));
                Header.mskReceived_dt = moGeneral.ToStrDate(cur_set.iField("iReceived_dt"));
                Header.mskRequired_dt = moGeneral.ToStrDate(cur_set.iField("iRequired_dt"));
                Header.mskToRecur_dt = moGeneral.ToStrDate(cur_set.iField("iToRecur_dt"));
                Header.mskDue_dt = moGeneral.ToStrDate(cur_set.iField("iDue_dt"));
                Header.mskInvoice_dt = moGeneral.ToStrDate(cur_set.iField("iInvoice_dt"));

                // Custom Fields
                //
                moCustomFields.SetValues(moDatabase, cur_set);

                FormSyncDates(false);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowHeader)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowListing()
        {
            string where_clause = "(mDue_amt >= 0.01 OR mDue_amt <= -0.01)";

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (mbListingInitiated_fl)
            {
                return true;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moListing.Show(moDatabase, moPage, where_clause, cboListingBy) == false)
            {
                FormShowMessage();
                return false;
            }

            mbListingInitiated_fl = true;
            mbListingPopulated_fl = (moListing.Grid.Count > 0);

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtApply_dt, ref Header.mskApply_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtEntry_dt, ref Header.mskEntry_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtRequired_dt, ref Header.mskRequired_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtReceived_dt, ref Header.mskReceived_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtDue_dt, ref Header.mskDue_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtInvoice_dt, ref Header.mskInvoice_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtToRecur_dt, ref Header.mskToRecur_dt, use_date_picker);

            // Payment schedule
            //
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtStarting_dt, ref Header.mskStarting_dt, use_date_picker);

            return true;
        }

        private bool FormSwitchView(int cur_page = -1)                                                              // Switch the tab-pages
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            moView.SwitchView(moPage, cur_page);

            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moZoom.Caller == "txtVendor_cd")
            {
                if (moZoom.Vendor(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            else if (moZoom.Caller == "txtOrder_num")
            {
                if (moZoom.Code(ref moDatabase, "tblPOTransaction", "sComment") == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            else if (moZoom.iColumn == Models.clsChargeDetail.ITEM_CODE_COL)
            {
                if (moZoom.Inventory(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            else if (moZoom.iColumn == Models.clsChargeDetail.FULL_ACCT_CODE_COL)
            {
                if (moZoom.Account(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormClear();
                return true;
            }

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
                {
                    return false;
                }
            }

            FormCancel();
            return true;
        }

        private bool btnCopy_Clicked()
        {
            

            return true;
        }


        private bool btnDelete_Clicked()
        {
            FormPreEvent();

            // We do not delete the transactions.
            
            FormClear();
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            FormExit();
            return true;
        }

        private bool btnFirst_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnFirst_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.FIRST_RECORD_TYPE);
        }

        private bool btnLast_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnLast_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.LAST_RECORD_TYPE);
        }

        private bool btnNext_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnNext_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.NEXT_RECORD_TYPE);
        }

        private bool btnPrevious_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnPrevious_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.PREVIOUS_RECORD_TYPE);
        }

        private bool btnSave_Clicked()
        {
            FormPreEvent();

            if (FormSave() == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        private bool btnSearchToPrint_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateSearchHTML();

            return FormPostEvent();
        }

        private bool btnSearchToExcel_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateSearchExcel();

            return FormPostEvent();
        }

        private bool btnListingToPrint_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateListingHTML();

            return FormPostEvent();
        }

        private bool btnListingToExcel_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateListingExcel();

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewHeader_Clicked()
        {
            FormPreEvent();                                                                           
            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool cmdViewListing_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormShowListing() == false)
            {
                return false;
            }

            FormSwitchView(moView.LISTING_PAGE_NUM);
            return true;

        }

        private bool cmdViewDetail_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.DETAIL_PAGE_NUM);

            return true;
        }

        private bool cmdViewMatrix_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.MATRIX_PAGE_NUM);

            return true;
        }

        private bool cmdViewMultiOrder_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.ORDER_PAGE_NUM);

            return true;
        }

        private bool cmdViewPayment_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.PAYMENT_PAGE_NUM);

            return true;
        }

        private bool cmdViewCommission_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.COMMISSION_PAGE_NUM);

            return true;
        }

        private bool cmdViewOptions_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.OPTIONS_PAGE_NUM);

            return true;
        }

        private bool cmdViewSearch_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.SEARCH_PAGE_NUM);

            return true;
        }

        private bool cmdViewHistory_Clicked()
        {
            FormPreEvent();

            ShowHistory();
            FormSwitchView(moView.HISTORY_PAGE_NUM);

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnListingSelect_Clicked(Models.clsListingCharge.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.ToInteger(cur_item.Transaction_num) <= 0)   // May have a string such as TOTAL
            {
                return false;
            }

            FormClear();
            Header.txtKey_id = cur_item.Transaction_num;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnSearchSelect_Clicked(Models.clsListingCharge.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.IsEmpty(cur_item.Transaction_num))
            {
                return false;
            }

            FormClear();
            Header.txtKey_id = cur_item.Transaction_num;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnHistorySelect_Clicked(Models.clsSpreadsheet.clsGrid cur_item)
        {
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";

            FormPreEvent();

            if (moUtility.IsEmpty(cur_item.Col_0) || moUtility.ToInteger(cur_item.Col_10) == 0)
            {
                return false;
            }

            o_session.SetSessionValues(moDatabase, User, ref session_id, cur_item.Col_1);

            if (moUtility.ToInteger(cur_item.Col_10) == GlobalVar.goConstant.TRX_DM_TYPE)
            {
                FormOpenPDF("LookupDebitMemo/" + session_id);
            }
            else if (moUtility.ToInteger(cur_item.Col_10) == GlobalVar.goConstant.TRX_PAYMENT_TYPE)
            {
                FormOpenPDF("LookupCashPayment/" + session_id);
            }

            return true;
        }

        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                if (moUtility.IsEmpty(cur_item.Col_0))
                {
                    return false;
                }

                code_selected = cur_item.Col_0;

                if (moZoom.Caller == "txtVendor_cd")
                {
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    Header.txtVendor_cd = code_selected;
                    return txtVendor_cd_Changed();
                }
                else if (moZoom.Caller == "txtOrder_num")
                {
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    Header.txtOrder_num = code_selected;
                    return txtOrder_num_Changed();
                }

                // Detail.Grid.Single(i => i.Row_num == moZoom.iRow).txtItem_cd = cur_item.Col_0;
                // Detail.Data[moZoom.iColumn, moZoom.iRow] = cur_item.Col_0;

                Models.clsChargeDetail.clsGrid detail_item = moDetail.Grid.Single(i => i.Row_num == moZoom.iRow);

                if (moZoom.iColumn == Models.clsChargeDetail.ITEM_CODE_COL)
                {
                    FormSwitchView(moView.DETAIL_PAGE_NUM);
                    detail_item.txtItem_cd = code_selected;
                    return DetailItem_cd_Changed(detail_item);
                }
                else if (moZoom.iColumn == Models.clsChargeDetail.FULL_ACCT_CODE_COL)
                {
                    FormSwitchView(moView.DETAIL_PAGE_NUM);
                    detail_item.mskGLAccount_cd = code_selected;
                    return DetailAccount_cd_Changed(detail_item);
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }

        private bool cmdSearch_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            FormSearch();

            return FormPostEvent();
        }

        private bool btnZoomOnVendor_cd_Clicked()
        {
            string where_clause = "";

            FormPreEvent();

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtVendor_cd", -1, -1, moView.MAIN_PAGE_NUM, "sVendor_cd", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool btnZoomOnOrder_num_Clicked()
        {
            string where_clause = "";

            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtVendor_cd))
            {
                FormShowMessage(User.Language.oMessage.ENTER_CUST_CODE_FIRST);
                return false;
            }

            where_clause = "iTransaction_typ = " + GlobalVar.goConstant.TRX_SO_TYPE.ToString() + " AND sVendor_cd = '" + Header.txtVendor_cd + "'";

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtOrder_num", -1, -1, moView.MAIN_PAGE_NUM, "iTransaction_num", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }
        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Changed()
        {
            if (Header.txtKey_id == Header.Tag.txtKey_id)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (txtKey_id_Verified() == false)
            {
                
            }

            return FormPostEvent();
        }

        private bool dtEntry_dt_Changed()
        {
            if (Header.dtEntry_dt == Header.Tag.dtEntry_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtEntry_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtEntry_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtEntry_dt) == false)
            {
                Header.dtEntry_dt = Header.Tag.dtEntry_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtEntry_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskEntry_dt_Changed()
        {
            if (Header.mskEntry_dt == Header.Tag.mskEntry_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskEntry_dt) == false)
            {
                Header.mskEntry_dt = Header.Tag.mskEntry_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskEntry_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtApply_dt_Changed()
        {
            if (Header.dtApply_dt == Header.Tag.dtApply_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtApply_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtApply_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtApply_dt) == false)
            {
                Header.dtApply_dt = Header.Tag.dtApply_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtApply_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskApply_dt_Changed()
        {
            if (Header.mskApply_dt == Header.Tag.mskApply_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskApply_dt) == false)
            {
                Header.mskApply_dt = Header.Tag.mskApply_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskApply_dt");
                return false;
            }

            return FormPostEvent();
        }


        private bool dtRequired_dt_Changed()
        {
            if (Header.dtRequired_dt == Header.Tag.dtRequired_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtRequired_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtRequired_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtRequired_dt) == false)
            {
                Header.dtRequired_dt = Header.Tag.dtRequired_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtRequired_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskRequired_dt_Changed()
        {
            if (Header.mskRequired_dt == Header.Tag.mskRequired_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskRequired_dt) == false)
            {
                Header.mskRequired_dt = Header.Tag.mskRequired_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskRequired_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtReceived_dt_Changed()
        {
            if (Header.dtReceived_dt == Header.Tag.dtReceived_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtReceived_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtReceived_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtReceived_dt) == false)
            {
                Header.dtReceived_dt = Header.Tag.dtReceived_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtReceived_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskReceived_dt_Changed()
        {
            if (Header.mskReceived_dt == Header.Tag.mskReceived_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskReceived_dt) == false)
            {
                Header.mskReceived_dt = Header.Tag.mskReceived_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskReceived_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtInvoice_dt_Changed()
        {
            if (Header.dtInvoice_dt == Header.Tag.dtInvoice_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtInvoice_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtInvoice_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtInvoice_dt) == false)
            {
                Header.dtInvoice_dt = Header.Tag.dtInvoice_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtInvoice_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskInvoice_dt_Changed()
        {
            if (Header.mskInvoice_dt == Header.Tag.mskInvoice_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskInvoice_dt) == false)
            {
                Header.mskInvoice_dt = Header.Tag.mskInvoice_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskInvoice_dt");
                return false;
            }

            return FormPostEvent();
        }


        private bool dtDue_dt_Changed()
        {
            if (Header.dtDue_dt == Header.Tag.dtDue_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtDue_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtDue_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtDue_dt) == false)
            {
                Header.dtDue_dt = Header.Tag.dtDue_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtDue_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskDue_dt_Changed()
        {
            if (Header.mskDue_dt == Header.Tag.mskDue_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskDue_dt) == false)
            {
                Header.mskDue_dt = Header.Tag.mskDue_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskDue_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtToRecur_dt_Changed()
        {
            if (Header.dtToRecur_dt == Header.Tag.dtToRecur_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtToRecur_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtToRecur_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtToRecur_dt) == false)
            {
                Header.dtToRecur_dt = Header.Tag.dtToRecur_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtToRecur_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskToRecur_dt_Changed()
        {
            if (Header.mskToRecur_dt == Header.Tag.mskToRecur_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskToRecur_dt) == false)
            {
                Header.mskToRecur_dt = Header.Tag.mskToRecur_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskToRecur_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtStarting_dt_Changed()
        {
            if (Header.dtStarting_dt == Header.Tag.dtStarting_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtStarting_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtStarting_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtStarting_dt) == false)
            {
                Header.dtStarting_dt = Header.Tag.dtStarting_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtStarting_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskStarting_dt_Changed()
        {
            if (Header.mskStarting_dt == Header.Tag.mskStarting_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskStarting_dt) == false)
            {
                Header.mskStarting_dt = Header.Tag.mskStarting_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskStarting_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool txtVendor_cd_Changed()
        {
            Header.txtVendor_cd = modCommonUtility.CleanCode(Header.txtVendor_cd);

            if (Header.txtVendor_cd == Header.Tag.txtVendor_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moUtility.IsNonEmpty(Header.txtVendor_cd))
            {
                if (moValidate.IsValidVendorCode(Header.txtVendor_cd) == false)
                {
                    FormShowMessage(Header.txtVendor_cd + User.Language.oMessage.IS_INVALID);
                }
            }

            return FormPostEvent();
        }

        private bool cboTax_cd_Clicked()
        {
            if (Header.cboTax_cd == Header.Tag.cboTax_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.


            return FormPostEvent();
        }

        private bool txtOrder_num_Changed()
        {
            if (moUtility.ToInteger(Header.txtOrder_num) > 0)
            {
                Header.txtOrder_num = moUtility.ToInteger(Header.txtOrder_num).ToString();
            }
            else
            {
                Header.txtOrder_num = "";
            }

            if (Header.txtOrder_num == Header.Tag.txtOrder_num)
            {
                return true;
            }

            FormPreEvent();

            return FormPostEvent();
        }
        
        private bool cmdPaymentSchedule_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.PAYMENT_SCHEDULE_PAGE_NUM);

            return FormPostEvent();
        }

        private bool cmdCreatePaymentSchedule_Clicked()
        {
            FormPreEvent();

            if (cmdCreatePaymentSchedule_Verified() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdSavePaymentSchedule_Clicked()
        {
            FormPreEvent();

            if (moUtility.ToInteger(Header.cboStatus_typ) != GlobalVar.goConstant.POSTED_TRX_NUM)
            {
                FormShowMessage(User.Language.oMessage.THIS_IS_NOT_ALLOWED_FOR_AN_INVOICE_WITH_THIS_STATUS_TYPE);
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (CheckPaymentSchedule() == false)
            {
                return false;
            }
            if (SavePaymentSchedule() == false)
            {
                return false;
            }

            Header.txtRemaining_amt = "";

            FormShowMessage(User.Language.oMessage.SAVING_DONE, false);
            return FormPostEvent();
        }

        private bool cmdCancelOnSearch_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Verified()
        {
            bool return_value = false;
            clsRecordset cur_set;
            string key_id = "";

            try
            {
                if (moUtility.ToInteger(Header.txtKey_id) > 0)
                {
                    Header.txtKey_id = moUtility.ToInteger(Header.txtKey_id).ToString();
                }
                else
                {
                    Header.txtKey_id = "";
                }

                key_id = Header.txtKey_id;

                if (Header.txtKey_id == Header.Tag.txtKey_id)
                {
                    return true;
                }
                else if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormClear();
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    FormClear();
                    FormShowMessage(User.Language.oMessage.CONNECTION_HAS_FAILED);
                    return false;
                }

                cur_set = new clsRecordset(ref moDatabase);

                if (FormFindRecord(ref cur_set))
                {
                    FormShow(cur_set);
                }
                else
                {
                    FormShowMessage(Header.txtKey_id + User.Language.oMessage.IS_NOT_FOUND);
                    FormClear();
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtKey_id_Verified)");
            }

            return return_value;
        }

        private bool cmdCreatePaymentSchedule_Verified()
        {
            bool return_value = false;
            string[,] detail_data = null;

            try
            {
                if (moMoney.ToNumMoney(Header.txtTotal_amt) <= 0)
                {
                    moPaymentSchedule.CreateGrid();
                    return true;
                }

                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    return false;
                }
                else if (moUtility.IsEmpty(Header.mskApply_dt))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_DATE_APPLIED);
                    return false;
                }
                else if (moUtility.ToInteger(Header.txtSplit_num) == 0 || moUtility.IsEmpty(Header.cboInterval_typ))
                {
                    FormShowMessage("Please, enter the number of payments and interval.");
                    return false;
                }

                if (moUtility.IsEmpty(Header.mskStarting_dt))
                {
                    Header.mskStarting_dt = Header.mskApply_dt;
                }

                moUtility.ResizeDim(ref detail_data, GlobalVar.goConstant.SPLIT_PAYMENT_TOTAL_DETAIL_COL - 1, 0);

                if (moPaymentSchedule.CreateSchedule(ref moDatabase, ref detail_data, moPage.iTransaction_typ, moMoney.ToNumMoney(Header.txtTotal_amt)
                    , moUtility.ToInteger(Header.txtSplit_num), moUtility.ToInteger(Header.cboInterval_typ), moGeneral.ToNumDate(Header.mskStarting_dt)) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (moPaymentSchedule.RecreateGrid(detail_data) == false)
                {
                    FormShowMessage(moPaymentSchedule.GetErrorMessage());
                    return false;
                }

                CalculatePaymentSchedule();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (cmdCreatePaymentSchedule_Verified)");
            }

            return return_value;
        }

        private bool CustomField_Changed(Models.clsCustomField.clsGrid cur_item)
        {
            FormPreEvent();

            if (moCustomFields.ValidateValue(moDatabase, cur_item) == false)
            {
                FormShowMessage(moCustomFields.GetErrorMessage());
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdSourceJournal_Clicked()
        {
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            if (moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.VOID_TRX_NUM)
            {
                FormShowMessage(User.Language.oMessage.RECORD_IS_NOT_QUALIFIED);
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moValidate.IsValidInGLJournal(moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id)) == false)
            {
                FormShowMessage(User.Language.oMessage.NO_RECORDS_FOUND);
                return false;
            }

            o_session.SetSessionValues(moDatabase, User, ref session_id, moValidate.oRecordset.iField("iTransaction_num").ToString());

            FormOpenPDF("LookupJournal/" + session_id);

            return FormPostEvent();
        }

        private bool cboListingBy_Clicked()
        {
            mbListingInitiated_fl = false;

            FormShowListing();

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else.
        //                                   
        //  ===============================================================================================================================================================================================================================

        private bool btnZoomOnDetailItem_Clicked(Models.clsChargeDetail.clsGrid cur_item)
        {
            FormPreEvent();

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "", Models.clsChargeDetail.ITEM_CODE_COL, cur_item.Row_num, moView.DETAIL_PAGE_NUM, "sItem_cd", "") == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool DetailItem_cd_Changed(Models.clsChargeDetail.clsGrid cur_item)
        {
            cur_item.txtItem_cd = modCommonUtility.CleanCode(cur_item.txtItem_cd);

            if (cur_item.txtItem_cd == moDetail.Data[Models.clsChargeDetail.ITEM_CODE_COL, cur_item.Row_num])         
            {
                return true;                            
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moUtility.IsNonEmpty(cur_item.txtItem_cd))
            {
                if (moValidate.IsValidItemCode(cur_item.txtItem_cd) == false)
                {
                    FormShowMessage(cur_item.txtItem_cd + User.Language.oMessage.IS_INVALID);
                }
            }

            return FormPostEvent();
        }

        private bool DetailAccount_cd_Changed(Models.clsChargeDetail.clsGrid cur_item)
        {
            cur_item.mskGLAccount_cd = modCommonUtility.CleanCode(cur_item.mskGLAccount_cd);

            if (cur_item.mskGLAccount_cd == moDetail.Data[Models.clsChargeDetail.FULL_ACCT_CODE_COL, cur_item.Row_num])
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moUtility.IsNonEmpty(cur_item.mskGLAccount_cd))
            {
                if (moValidate.IsValidActualAcctCode(cur_item.mskGLAccount_cd) == false)
                {
                    FormShowMessage(cur_item.mskGLAccount_cd + User.Language.oMessage.IS_INVALID);
                }
            }

            return FormPostEvent();
        }

        private bool PaymentScheduleAmount_Changed(clsPaymentSchedule.clsGrid cur_iem)
        {
            FormPreEvent();

            if (moUtility.IsNonEmpty(cur_iem.txtDue_amt))
            {
                cur_iem.txtDue_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(cur_iem.txtDue_amt));
            }

            if ((moMoney.ToNumMoney(cur_iem.txtReturned_amt) + moMoney.ToNumMoney(cur_iem.txtPaid_amt) + moMoney.ToNumMoney(cur_iem.txtDue_amt)) > 0)
            {
                cur_iem.txtTotal_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(cur_iem.txtReturned_amt) + moMoney.ToNumMoney(cur_iem.txtPaid_amt) + moMoney.ToNumMoney(cur_iem.txtDue_amt));
            }
            else
            {
                cur_iem.txtTotal_amt = "";
            }

            CalculatePaymentSchedule();

            return FormPostEvent();
        }

        private bool PaymentScheduleDiscount_Changed(clsPaymentSchedule.clsGrid cur_iem)
        {
            FormPreEvent();

            if (moUtility.IsNonEmpty(cur_iem.txtDiscount_amt))
            {
                cur_iem.txtDiscount_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(cur_iem.txtDiscount_amt));
            }

            return FormPostEvent();
        }

        private bool PaymentScheduleDueDate_Changed(clsPaymentSchedule.clsGrid cur_iem)
        {
            FormPreEvent();

            if (moGeneral.ValidDate(ref cur_iem.txtDue_dt, true) == false)
            {
                cur_iem.txtDue_dt = "";
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                return false;
            }

            return FormPostEvent();
        }

        private bool PaymentScheduleDiscountDate_Changed(clsPaymentSchedule.clsGrid cur_iem)
        {
            FormPreEvent();

            if (moGeneral.ValidDate(ref cur_iem.txtDiscount_dt, true) == false)
            {
                cur_iem.txtDiscount_dt = "";
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdAddMoreScheduleLines_Clicked()
        {
            FormPreEvent();

            moPaymentSchedule.AddMoreRows();

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

        public bool ResetRestrictionClause()
        {
            moPage.sRestrictionClause = msDefaultRestrictionClause;

            return true;
        }

        public bool CheckPaymentSchedule()
        {
            int discount_date = 0;
            int due_date = 0;
            decimal discount_amt = 0;
            decimal amt_total_splited = 0;

            if (moMoney.ToNumMoney(Header.txtDue_amt) <= 0)
            {
                FormShowMessage(Header.txtKey_id + User.Language.oMessage.HAS_BEEN_PAID_OFF_ALREADY);
                return false;
            }
            else if (moValidate.IsValidAPTermsCode(Header.cboTerms_cd))
            {
                Header.mskDue_dt = moGeneral.ToStrDate(moUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, moGeneral.ToNumDate(Header.mskApply_dt), moValidate.oRecordset.iField("iDueDays")));
                discount_date = moUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, moGeneral.ToNumDate(Header.mskApply_dt), moValidate.oRecordset.iField("iDiscountDays"));
                discount_amt = moGeneral.CalculatePaymentDiscount(moMoney.ToNumMoney(Header.txtTaxable_amt) + moMoney.ToNumMoney(Header.txtNonTaxable_amt), moMoney.ToNumMoney(Header.txtTax_amt), moMoney.ToNumMoney(Header.txtFreightTax_amt), moMoney.ToNumMoney(Header.txtFreight_amt), moValidate.oRecordset.mField("fDiscount_pc"), (moUtility.ToValue(Header.txtTax_pc) < 0));
            }
            else // not expected at all
            {
                FormShowMessage(User.Language.oString.STR_TERMS_CODE + "(" + Header.cboTerms_cd + ")" + User.Language.oMessage.IS_INVALID);
                return false;
            }

            due_date = moGeneral.ToNumDate(Header.mskDue_dt);

            if (moMoney.ToNumMoney(Header.txtRemaining_amt) != 0)
            {
                FormShowMessage("Payment schedule is not set up properly.");
                return false;
            }

            if (moPaymentSchedule.RecreateDetail(ref moVoucher.sSplitPayment) == false)
            {
                FormShowMessage(moPaymentSchedule.GetErrorMessage());
                return false;
            }
            if (moPaymentSchedule.CheckSchedule(ref moDatabase, ref moVoucher.sSplitPayment, moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id), moMoney.ToNumMoney(Header.txtDue_amt)  // Do not use txtDue_amt
                , ref amt_total_splited, ref due_date, discount_amt, discount_date, moMoney.ToNumMoney(Header.txtPaid_amt)) == false)
            {
                FormShowMessage();
                return false;
            }
            if (moPaymentSchedule.RecreateGrid(moVoucher.sSplitPayment) == false)           // Amounts could have been adjusted in moPaymentSchedule.CheckSchedule()
            {
                FormShowMessage();
                return false;
            }

            Header.mskDue_dt = moGeneral.ToStrDate(due_date);
            FormSyncDates(false);
            return true;
        }

        public bool CalculatePayment()
        {
            int i = 0;
            decimal amt_paid = 0;

            foreach (var det in moTransactionPayment.Grid)
            {
                det.txtPaid_amt = moMoney.ToStrMoney(Math.Abs(moMoney.ToNumMoney(det.txtPaid_amt)));
                amt_paid += moMoney.ToNumMoney(det.txtPaid_amt);

            }

            Header.txtPaid_amt = moMoney.ToStrMoney(amt_paid);

            return FormCalculateDue();
        }

        public bool CalculatePaymentSchedule()
        {
            decimal amt_due = 0;
            int due_date = 0;

            foreach (var det in moPaymentSchedule.Grid)
            {
                amt_due += moMoney.ToNumMoney(det.txtDue_amt);

                if (moGeneral.ToNumDate(det.txtDue_dt) > due_date)
                {
                    due_date = moGeneral.ToNumDate(det.txtDue_dt);
                }
            }

            Header.txtRemaining_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.txtDue_amt) - amt_due);  // Do not use txtTotal_amt

            //if (moUtility.IsEmpty(Header.mskDue_dt) || moGeneral.ToNumDate(Header.mskDue_dt) < due_date) 
            if (due_date > 0)
            {
                Header.mskDue_dt = moGeneral.ToStrDate(due_date);
                FormSyncDates(false);
            }

            return true;
        }

        private bool GetPaymentSchedule()
        {
            moPaymentSchedule.CreateGrid(10);

            if (moPaymentSchedule.GetPaymentSchedule(ref moDatabase, moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id)) == false)
            {
                FormShowMessage(moPaymentSchedule.GetErrorMessage());
                return false;
            }

            Header.txtRemaining_amt = "";

            return true;
        }

        private bool SavePaymentSchedule()
        {
            if (moPaymentSchedule.RecreateDetail(ref moVoucher.sSplitPayment) == false)
            {
                FormShowMessage(moPaymentSchedule.GetErrorMessage());
                return false;
            }

            if (moDatabase.TransactionBegin() == false)
            {
                FormShowMessage();
                return false;
            }
            if (moPaymentSchedule.SaveSchedule(ref moDatabase, ref moVoucher.sSplitPayment, moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id), moGeneral.ToNumDate(Header.mskApply_dt)
                , moGeneral.ToNumDate(Header.mskInvoice_dt), Header.txtVendor_cd, moUtility.ToInteger(Header.cboStatus_typ)) == false)
            {
                FormShowMessage(moPaymentSchedule.GetErrorMessage());
                moDatabase.TransactionRollback();
                return false;
            }
            if (moDatabase.TransactionCommit() == false)
            {
                FormShowMessage();
                moDatabase.TransactionRollback();
                return false;
            }

            return true;
        }

        public int GetStartingRowInMainTable()
        {

            int return_value = 0;
            int row_num = 0;

            try
            {
                FormRecreateDetail();

                return_value = -1;
                for (row_num = moDetail.Data.GetUpperBound(1); row_num >= 0; row_num--)
                {
                    if (moUtility.IsNonEmpty(moDetail.Data[Models.clsChargeDetail.ITEM_CODE_COL, row_num]) || moUtility.IsNonEmpty(moDetail.Data[Models.clsChargeDetail.DESCRIPTION_COL, row_num]) 
                        || moMoney.ToNumMoney(moDetail.Data[Models.clsChargeDetail.UNIT_PRICE_COL, row_num]) != 0)
                    {
                        return_value = row_num;
                        break;
                    }
                }

                return_value += 1;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (GetStartingRowInMainTable)");
            }

            return return_value;
        }

        private bool SecurityLock()
        {
            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            else if (moUtility.ToInteger(Header.txtOrder_num) > 0)
            {
                return true;
            }

            return false;
        }

        private bool PriceLock()
        {
            

            return false;
        }

        private string GetSearchCriteria()
        {
            string return_value = null;

            try
            {
                Header.txtTransaction_num = moUtility.EvalQuote(Header.txtTransaction_num);

                if (moUtility.IsNonEmpty(Header.txtTransaction_num))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sTransaction_num LIKE '" + Header.txtTransaction_num + "%'";
                }

                if (moUtility.IsNonEmpty(Header.mskEntry_dt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iEntry_dt = " + moGeneral.ToNumDate(Header.mskEntry_dt);
                }
                if (moUtility.IsNonEmpty(Header.mskApply_dt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iApply_dt = " + moGeneral.ToNumDate(Header.mskApply_dt);
                }
                if (moUtility.IsNonEmpty(Header.mskRequired_dt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iRequired_dt = " + moGeneral.ToNumDate(Header.mskRequired_dt);
                }
                if (moUtility.IsNonEmpty(Header.mskReceived_dt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iReceived_dt = " + moGeneral.ToNumDate(Header.mskReceived_dt);
                }
                if (!moUtility.IsEmpty(Header.mskDue_dt))
                {
                    return_value += moUtility.IIf(!moUtility.IsEmpty(return_value), " AND ", "").ToString() + "iDue_dt = " + moGeneral.ToNumDate(Header.mskDue_dt);
                }
                if (!moUtility.IsEmpty(Header.mskInvoice_dt))
                {
                    return_value += moUtility.IIf(!moUtility.IsEmpty(return_value), " AND ", "").ToString() + "iInvoice_dt = " + moGeneral.ToNumDate(Header.mskInvoice_dt);
                }
                if (moUtility.ToInteger(Header.cboStatus_typ) > 0)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iStatus_typ = " + Header.cboStatus_typ;
                }
                if (moUtility.IsNonEmpty(Header.txtVendor_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sVendor_cd = '" + moUtility.EvalQuote(Header.txtVendor_cd) + "'";
                }
                if (moUtility.IsNonEmpty(Header.txtVendor_nm))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sVendor_nm LIKE '" + moUtility.EvalQuote(Header.txtVendor_nm) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtVendorAddress1))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sVendorAddress1 LIKE '" + moUtility.EvalQuote(Header.txtVendorAddress1) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtVendorAddress2))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sVendorAddress2 LIKE '" + moUtility.EvalQuote(Header.txtVendorAddress2) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtVendorAddress3))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sVendorAddress3 LIKE '" + moUtility.EvalQuote(Header.txtVendorAddress3) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtVendorAttn))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sVendorAttn LIKE '" + moUtility.EvalQuote(Header.txtVendorAttn) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtBillTo_nm))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sBillTo_nm LIKE '" + moUtility.EvalQuote(Header.txtBillTo_nm) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtBillToAddress1))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sBillToAddress1 LIKE '" + moUtility.EvalQuote(Header.txtBillToAddress1) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtBillToAddress2))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sBillToAddress2 LIKE '" + moUtility.EvalQuote(Header.txtBillToAddress2) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtBillToAddress3))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sBillToAddress3 LIKE '" + moUtility.EvalQuote(Header.txtBillToAddress3) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtBillToAttn))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sBillToAttn LIKE '" + moUtility.EvalQuote(Header.txtBillToAttn) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtOurReference))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sReference LIKE '" + moUtility.EvalQuote(Header.txtOurReference) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtYourReference))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sYourReference LIKE '" + moUtility.EvalQuote(Header.txtYourReference) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtComment))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sComment LIKE '" + moUtility.EvalQuote(Header.txtComment) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.cboFOB_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sFob_cd LIKE '" + moUtility.EvalQuote(Header.cboFOB_cd) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.cboDunn_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sDunn_cd = '" + Header.cboDunn_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboTax_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sTax_cd = '" + Header.cboTax_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboVia_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sVia_cd = '" + Header.cboVia_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboTerms_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sTerms_cd = '" + Header.cboTerms_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboAgent_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sAgent_cd = '" + Header.cboAgent_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboLocation_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sLocation_cd = '" + Header.cboLocation_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboJob_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sJob_cd = '" + Header.cboJob_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboFund_cd))
                {
                    if (Header.cboFund_cd == clsNPConstant.FUND_ORGANIZATION_CODE)
                    {
                        return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sFund_cd = ''";
                    }
                    else
                    {
                        return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sFund_cd = '" + GlobalVar.goFund.GetSelectedFundCodeToSave(ref moDatabase, Header.cboFund_cd) + "'";
                    }
                }

                return return_value;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (GetSearchCriteria)");
                return_value = "";
            }

            return return_value;

        }

        private bool ShowHistory()
        {
            string sql_str = "";
            int row_num = 0;

            clsRecordset payment_set = new clsRecordset(ref moDatabase);
            clsRecordset memo_set = new clsRecordset(ref moDatabase);

            moHistory.Clear();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return true;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            sql_str = "SELECT * FROM tblAPPaymentDet WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_PAYMENT_TYPE.ToString() + " AND iAppliedTransaction_typ = " + GlobalVar.goConstant.TRX_PURCHASE_TYPE.ToString() + " AND iAppliedTransaction_num = " + Header.txtKey_id + " ORDER BY iApply_dt";
            if (payment_set.CreateSnapshot(sql_str) == false)
            {
                FormShowMessage();
                return false;
            }

            sql_str = "SELECT * FROM tblAPCharge WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_DM_TYPE.ToString() + " AND iOrder_num = " + Header.txtKey_id + " ORDER BY iApply_dt";
            if (memo_set.CreateSnapshot(sql_str) == false)
            {
                FormShowMessage();
                return false;
            }

            if (payment_set.RecordCount() + memo_set.RecordCount() == 0)
            {
                return true;
            }

            moUtility.ResizeDim(ref moHistory.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, payment_set.RecordCount() + memo_set.RecordCount() - 1);

            row_num = 0;

            while (payment_set.EOF() == false)
            {
                moHistory.Data[0, row_num] = moUtility.GetTransactionTypeText(moDatabase, payment_set.iField("iTransaction_typ"));
                if (payment_set.iField("iStatus_typ") == GlobalVar.goConstant.SP_TRX_NUM)
                {
                    moHistory.Data[0, row_num] += "/" + GlobalVar.goConstant.SP_TRX;
                }
                moHistory.Data[1, row_num] = payment_set.iField("iTransaction_num").ToString();
                moHistory.Data[2, row_num] = moGeneral.ToStrDate(payment_set.iField("iApply_dt"));
                moHistory.Data[3, row_num] = moMoney.ToStrMoney(payment_set.mField("mPaid_amt"));

                moHistory.Data[10, row_num] = payment_set.iField("iTransaction_typ").ToString();

                payment_set.MoveNext();
                row_num += 1;
            }

            while (memo_set.EOF() == false)
            {
                moHistory.Data[0, row_num] = moUtility.GetTransactionTypeText(moDatabase, memo_set.iField("iTransaction_typ"));
                moHistory.Data[1, row_num] = memo_set.iField("iTransaction_num").ToString();
                moHistory.Data[2, row_num] = moGeneral.ToStrDate(memo_set.iField("iApply_dt"));
                moHistory.Data[3, row_num] = moMoney.ToStrMoney(memo_set.mField("mTotal_amt"));     // Do not use mDue_amt

                moHistory.Data[10, row_num] = memo_set.iField("iTransaction_typ").ToString();

                memo_set.MoveNext();
                row_num += 1;
            }

            moHistory.RecreateGrid();

            return true;
        }

        private bool CreateSearchHTML()
        {
            bool return_value = false;
            string html_file = "";
            string[] header_list = null;

            clsSpreadsheet o_search = new clsSpreadsheet();

            try
            {
                if (ShowSearchPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moSearch, ref o_search, ref header_list) == false)      // Listing & Search both share PrepListingDownload()
                {
                    return false;
                }

                html_file = moInquiry.CreateHTML(ref moDatabase, moPage.Title, o_search, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(html_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(html_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateSearchHTML)");
            }

            return return_value;
        }


        private bool CreateSearchExcel()
        {
            bool return_value = false;
            string csv_file = "";
            string[] header_list = null;

            clsSpreadsheet o_search = new clsSpreadsheet();

            try
            {
                if (ShowSearchPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moSearch, ref o_search, ref header_list) == false)
                {
                    return false;
                }

                csv_file = moInquiry.CreateCSV(ref moDatabase, moPage.Title, o_search, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(csv_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(csv_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateSearchExcel)");
            }

            return return_value;
        }

        private bool PrepListingDownload(clsListingCharge o_listing, ref clsSpreadsheet o_spread, ref string[] header_list)
        {
            bool return_value = false;
            int row_num = 0;
            int i = 0;

            try
            {
                moUtility.ResizeDim(ref o_spread.Data, 13, o_listing.Grid.Count - 1);

                foreach (var lst in o_listing.Grid)
                {
                    i = 0;

                    o_spread.Data[i++, row_num] = lst.Transaction_num;
                    o_spread.Data[i++, row_num] = lst.Status_typ;
                    o_spread.Data[i++, row_num] = lst.Entry_dt;
                    o_spread.Data[i++, row_num] = lst.Apply_dt;
                    o_spread.Data[i++, row_num] = lst.Due_dt;
                    o_spread.Data[i++, row_num] = lst.Entity_cd;
                    o_spread.Data[i++, row_num] = lst.Entity_nm;
                    o_spread.Data[i++, row_num] = lst.Agent_cd;
                    o_spread.Data[i++, row_num] = lst.Terms_cd;
                    o_spread.Data[i++, row_num] = lst.Reference;
                    o_spread.Data[i++, row_num] = lst.Total_amt;
                    o_spread.Data[i++, row_num] = lst.Paid_amt;
                    o_spread.Data[i++, row_num] = lst.Due_amt;
                    o_spread.Data[i++, row_num] = lst.Comment;

                    row_num += 1;
                }

                moUtility.ResizeDim(ref header_list, i - 1);
                i = 0;

                header_list[i++] = User.Language.oCaption.NUMBER;
                header_list[i++] = User.Language.oCaption.STATUS;
                header_list[i++] = User.Language.oCaption.ENTRY_DATE;
                header_list[i++] = User.Language.oCaption.APPLY_DATE;
                header_list[i++] = User.Language.oCaption.REQUIRED;
                header_list[i++] = User.Language.oCaption.VENDOR;
                header_list[i++] = User.Language.oCaption.NAME;
                header_list[i++] = User.Language.oCaption.AGENT;
                header_list[i++] = User.Language.oCaption.TERMS;
                header_list[i++] = User.Language.oCaption.REFERENCE;
                header_list[i++] = User.Language.oCaption.TOTAL_AMT;
                header_list[i++] = User.Language.oCaption.PAID;
                header_list[i++] = User.Language.oCaption.DUE;
                header_list[i++] = User.Language.oCaption.COMMENT;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PrepListingDownload)");
            }

            return return_value;
        }

        private bool CreateListingHTML()
        {
            bool return_value = false;
            string html_file = "";
            string[] header_list = null;

            clsSpreadsheet o_listing = new clsSpreadsheet();

            try
            {
                if (ShowListingPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moListing, ref o_listing, ref header_list) == false)
                {
                    return false;
                }

                html_file = moInquiry.CreateHTML(ref moDatabase, moPage.Title, o_listing, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(html_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(html_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateListingHTML)");
            }

            return return_value;
        }


        private bool CreateListingExcel()
        {
            bool return_value = false;
            string csv_file = "";
            string[] header_list = null;

            clsSpreadsheet o_listing = new clsSpreadsheet();

            try
            {
                if (ShowListingPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moListing, ref o_listing, ref header_list) == false)
                {
                    return false;
                }

                csv_file = moInquiry.CreateCSV(ref moDatabase, moPage.Title, o_listing, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(csv_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(csv_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateListingExcel)");
            }

            return return_value;
        }

    }
}
