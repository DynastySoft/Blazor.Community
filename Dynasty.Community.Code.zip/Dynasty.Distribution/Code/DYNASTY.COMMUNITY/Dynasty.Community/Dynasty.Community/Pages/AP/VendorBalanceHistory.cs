﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP.Pages.AP
{
    public partial class VendorBalanceHistory
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<BinGenerator> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;                                                               
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        public bool InitialRendering { get; set; } = true;

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsMoney moMoney;
        private clsBalanceHistory moBalanceHistory;

        private Models.clsSpreadsheet moSummary;
        private Models.clsSession moSession;

        private List<Models.clsCombobox> FiscalYearList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> FiscalPeriodList = new List<Models.clsCombobox>();

        public const int APPLY_DATE_COL = 0;
        public const int TRANS_TYPE_TEXT_COL = 1;
        public const int TRANS_NUM_COL = 2;
        public const int CURRENCY_CODE_COL = 3;
        public const int FOREIGN_AMT_COL = 4;
        public const int AMOUNT_COL = 5;
        public const int PAY_DISC_COL = 6;
        public const int RESTOCK_CHG_COL = 7;
        public const int BALANCE_COL = 8;
        public const int ON_ACCT_COL = 9;
        public const int TRANS_TYPE_COL = 10;
        public const int COMMENT_COL = 11;

        public const int TOTAL_COLUMNS = 12;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================

        private class clsHeader                   
        {
            // Listing of UI items on the header
            //
            public string cboFiscalYear = "";
            public string lblVendor_cd = "";
            public string lblVendor_nm = "";

            // Listing of UI items on the header
            //
            public string mskEntry_dt = "";
            public string mskFrom_dt = "";
            public string mskThru_dt = "";

            public DateTime? dtEntry_dt = null;
            public DateTime? dtFrom_dt = null;
            public DateTime? dtThru_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag
            {
                public string cboFiscalYear = "";

                public string mskEntry_dt = "";
                public string mskFrom_dt = "";
                public string mskThru_dt = "";

                public DateTime? dtEntry_dt = null;
                public DateTime? dtFrom_dt = null;
                public DateTime? dtThru_dt = null;
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()                                                                  
            {
                Tag.cboFiscalYear = cboFiscalYear;

                Tag.mskEntry_dt = mskEntry_dt;
                Tag.mskFrom_dt = mskFrom_dt;
                Tag.mskThru_dt = mskThru_dt;

                Tag.dtEntry_dt = dtEntry_dt;
                Tag.dtFrom_dt = dtFrom_dt;
                Tag.dtThru_dt = dtThru_dt;
            }
        }
        private clsHeader Header = new clsHeader();

        private Boolean mbFCFound_fl = false;

        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================

        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }

            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;                        
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();                      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            moSession.RemoveSession(moDatabase);        // Delete the session file as rendering completes.

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            // If user uses date-picker, we need to change the date field.
            //
            if (User.bUseDatePicker_fl && moUtility.SLeft(field_name, 3) == "msk" && moUtility.SRight(field_name, 3) == "_dt")
            {
                field_name = moUtility.SReplace(field_name, "msk", "dt");
            }

            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows(int lines_to_add = 0)
        {
           
            return true;
        }

        private bool FormCalculateTotal()
        {

            return true;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {

            return true;
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            return true;
        }

        private bool FormClearDetail()                                                                   // Clear the entire page.
        {

            moUtility.ResizeDim(ref moSummary.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, 0);
            FormRecreateGrid(moSummary);

            return true;
        }

        private bool FormClearHeader()                                                                   // Clear the entire page.
        {
            return true;
        }

        private bool FormClearMessage()                                                            
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            
            return true;
        }

        private bool FormDeleteExtra()
        {

            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moMoney = new clsMoney(ref moDatabase);
            moSummary = new Models.clsSpreadsheet();
            moBalanceHistory = new clsBalanceHistory();
            moSession = new Models.clsSession();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.ARMENU_NAME;
            moPage.Title = "";
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormInitHeader();
            FormInitDetail();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitDetail()                                                              // Initialize the page at loading.  Only once.
        {
            // Detail table name.
            //
            moPage.sDetailTable_nm = "";

            moUtility.ResizeDim(ref moSummary.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, 0);

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = ""; 
            moPage.sKeyField_nm = "";
            moPage.iTransaction_typ= 0; 

            return true;
        }

        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {
            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            // FormSave() & FormCheck() use the plain box whose name starts with "msk"
            // dt* variables are only to interact with UI.  Internally, msk* fields are used.
            //
            FormSyncDates(User.bUseDatePicker_fl);

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtEntry_dt, ref Header.mskEntry_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtFrom_dt, ref Header.mskFrom_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtThru_dt, ref Header.mskThru_dt, use_date_picker);

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback
            
            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;
            ArrayList array_list = new ArrayList();

            try
            {
                FormSwitchView(moView.MAIN_PAGE_NUM);

                // Since this page does not go through the menu system, we need to get the login info that is sent from the calling page.
                //
                if (FormReceiveValues() == false)
                {
                    User.bConnected_fl = true;                      // So that the message will show.
                    return false;
                }
                if (FormOpenDatabase() == false)
                {
                    User.bConnected_fl = true;                      // So that the message will show.
                    return false;
                }

                modLoadUtility.LoadFiscalYear(ref moDatabase, ref FiscalYearList, false, false, false);

                Header.lblVendor_cd = moSession.Value.Entity;

                if (moValidate.IsValidVendorCode(Header.lblVendor_cd))
                {
                    Header.lblVendor_nm = moValidate.oRecordset.sField("sVendor_nm");
                }
                Header.cboFiscalYear = moDatabase.sCurFiscalYear;
                cboFiscalYear_Clicked();

                User.bConnected_fl = true;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormMove(int record_move_direction)
        {
            return true;
        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostSave()
        {
            
            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {

            return true;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormReceiveValues()
        {
            // If connected already, return true.  This means this page came through the menu system.
            //
            if (moUtility.IsNonEmpty(User.sServer_nm) || moDatabase.IsConnected())
            {
                return true;
            }

            // Otherwise, need to login with the info passed from the calling page.
            //
            if (modGeneralUtility.GetPassedParameters(StarterValue, User, moSession) == false)
            {
                FormShowMessage(User.Language.oMessage.PLEASE_LOG_IN_FIRST);
                return false;
            }

            moPage.sInitialKey_id = moSession.Value.Entity;

            return true;
        }

        private bool FormRecreateDetail(Models.clsSpreadsheet cur_spread)     
        {
            if (cur_spread.RecreateDetail() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateDetailLine(Models.clsSpreadsheet.clsGrid cur_item, int row_num = -1)
        {
            if (moSummary.RecreateDetailLine(cur_item, row_num) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateGrid(Models.clsSpreadsheet cur_spread)                                                  
        {
            if (cur_spread.RecreateGrid() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {

            FormReArrangeHeader();

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);

            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moZoom.Caller == "txtVendor_cd")
            {
                if (moZoom.Vendor(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            else if (moZoom.Caller == "txtItem_cd" || moZoom.Caller == "txtItemThru_cd")
            {
                if (moZoom.Inventory(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
                {
                    return false;
                }
            }

            FormCancel();
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        
        private bool cmdViewMain_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.MAIN_PAGE_NUM);
            return FormPostEvent();
        }

        private bool cmdViewSalesDetail_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.DETAIL_PAGE_NUM);
            return FormPostEvent();
        }

        private bool cmdViewReceiptDetail_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.SECOND_PAGE_NUM);
            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnListingSelect_Clicked(Models.clsListing.clsGrid cur_item)
        {
            FormPreEvent();


            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
               
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }
        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        private bool cboFiscalYear_Clicked()
        {
            FormPreEvent();

            if (Header.cboFiscalYear == Header.Tag.cboFiscalYear)
            {
                return true;
            }
            FormClearDetail();

            if (moUtility.IsEmpty(Header.cboFiscalYear))
            {
                return true;
            }

            ShowSummary();

            return FormPostEvent();
        }

        private bool dtFrom_dt_Changed()
        {
            if (Header.dtFrom_dt == Header.Tag.dtFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtFrom_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtFrom_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtFrom_dt) == false)
            {
                Header.dtFrom_dt = Header.Tag.dtFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtFrom_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskFrom_dt_Changed()
        {
            if (Header.mskFrom_dt == Header.Tag.mskFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskFrom_dt) == false)
            {
                Header.mskFrom_dt = Header.Tag.mskFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskFrom_dt");
                return false;
            }

            return FormPostEvent();
        }


        private bool dtThru_dt_Changed()
        {
            if (Header.dtThru_dt == Header.Tag.dtThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtThru_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtThru_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtThru_dt) == false)
            {
                Header.dtThru_dt = Header.Tag.dtThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskThru_dt_Changed()
        {
            if (Header.mskThru_dt == Header.Tag.mskThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskThru_dt) == false)
            {
                Header.mskThru_dt = Header.Tag.mskThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool btnSelectSummary_Clicked(Models.clsSpreadsheet.clsGrid cur_item)
        {
            int trx_type = 0;
            int trx_num = 0;
            string page_name = "";

            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";

            FormPreEvent();

            trx_type = moUtility.ToInteger(moSummary.Data[TRANS_TYPE_COL, cur_item.Row_num]);
            trx_num = moUtility.ToInteger(moSummary.Data[TRANS_NUM_COL, cur_item.Row_num]);

            if (trx_num <= 0)
            {
                return FormPostEvent();
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE)
            {
                page_name = "LookupVoucher";
            }
            else if (trx_type == GlobalVar.goConstant.TRX_DM_TYPE)
            {
                page_name = "LookupDebitMemo";
            }
            else if (trx_type == GlobalVar.goConstant.TRX_PAYMENT_TYPE)
            {
                page_name = "LookupCashPayment";
            }
            else if (trx_type == GlobalVar.goConstant.TRX_STOP_PAYMENT_TYPE)
            {
                page_name = "LookupStopPayment";
            }
            else
            {
                return false;
            }

            if (moUtility.IsNonEmpty(cur_item.Col_3) && cur_item.Col_3 != moDatabase.sCurrency_cd && moDatabase.uProgram.bMCExist_fl)
            {
                page_name = "MC" + page_name;
            }

            o_session.SetSessionValues(moDatabase, User, ref session_id, trx_num.ToString());
            FormOpenPDF(page_name + "/" + session_id);

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

        private bool ShowSummary()
        {
            bool return_value = false;
            int row_num = 0;
            bool foreign_trx_fl = false;
            string[,] balance_data = null;

            try
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                FormClearDetail();

                if (!GlobalVar.goBalanceHistory.GetBalanceHistory(ref moDatabase, ref balance_data, clsAPConstant.MODULE_ID, Header.lblVendor_cd, Header.cboFiscalYear, ref foreign_trx_fl))
                {
                    return false;
                }

                if (balance_data == null)
                {
                    return true;
                }

                moUtility.ResizeDim(ref moSummary.Data, moSummary.Data.GetUpperBound(0), balance_data.GetUpperBound(1));

                for (row_num = 0; row_num < balance_data.GetLength(1); row_num++)
                {
                    moSummary.Data[APPLY_DATE_COL, row_num] = balance_data[clsBalanceHistory.APPLY_DATE_COL, row_num];
                    moSummary.Data[TRANS_TYPE_TEXT_COL, row_num] = balance_data[clsBalanceHistory.TRANS_TYPE_TEXT_COL, row_num];
                    moSummary.Data[TRANS_TYPE_COL, row_num] = balance_data[clsBalanceHistory.TRANS_TYPE_COL, row_num];
                    moSummary.Data[TRANS_NUM_COL, row_num] = balance_data[clsBalanceHistory.TRANS_NUM_COL, row_num];
                    moSummary.Data[CURRENCY_CODE_COL, row_num] = balance_data[clsBalanceHistory.CURRENCY_CODE_COL, row_num];
                    moSummary.Data[FOREIGN_AMT_COL, row_num] = balance_data[clsBalanceHistory.FOREIGN_AMT_COL, row_num];
                    moSummary.Data[AMOUNT_COL, row_num] = balance_data[clsBalanceHistory.AMOUNT_COL, row_num];
                    moSummary.Data[PAY_DISC_COL, row_num] = balance_data[clsBalanceHistory.PAY_DISC_COL, row_num];
                    moSummary.Data[RESTOCK_CHG_COL, row_num] = balance_data[clsBalanceHistory.RESTOCK_CHG_COL, row_num];
                    moSummary.Data[BALANCE_COL, row_num] = balance_data[clsBalanceHistory.BALANCE_COL, row_num];
                    moSummary.Data[ON_ACCT_COL, row_num] = balance_data[clsBalanceHistory.ON_ACCT_COL, row_num];
                    moSummary.Data[COMMENT_COL, row_num] = balance_data[clsBalanceHistory.COMMENT_COL, row_num];

                    if (moUtility.IsNonEmpty(moSummary.Data[CURRENCY_CODE_COL, row_num]) && moSummary.Data[CURRENCY_CODE_COL, row_num] != moDatabase.sCurrency_cd)
                    {
                        mbFCFound_fl = true;
                    }
                }

                FormRecreateGrid(moSummary);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (ShowSummary)");
            }

            return true;
        }

    }
}
