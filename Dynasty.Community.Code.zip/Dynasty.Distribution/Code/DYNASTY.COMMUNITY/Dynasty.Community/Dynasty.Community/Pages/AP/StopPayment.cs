﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;

using Dynasty.Database;
using Dynasty.Report;
using Dynasty.Local;
using Dynasty.ASP.Models;

namespace Dynasty.ASP.Pages.AP
{
    public partial class StopPayment
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<BinGenerator> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;
        private Models.clsListingPayment moListing;
        private Models.clsListingPayment moSearch;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        private bool ShowNavigation
        {
            get
            {
                return (moPage.iCurrentView != moView.ZOOM_PAGE_NUM && moPage.iCurrentView != moView.PRINT_PAGE_NUM);
            }
        }

        private bool ShowSearchPrinter
        {
            get
            {
                return (mbSearchInitiated_fl && mbSearchPopulated_fl);
            }
        }


        private bool ShowListingPrinter
        {
            get
            {
                return (mbListingInitiated_fl && mbListingPopulated_fl);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsMoney moMoney;
        private clsBatch moBatch;

        private Models.clsPaymentDetail moDetail;
        private clsTransactionPayment moTransactionPayment;
        private clsDeposit moDeposit;
        private clsReportViewer moReport;
        private Models.clsCustomField moCustomFields;
        private clsVendor moVendor;
        private Models.clsSession moSession;
        private clsInquiry moInquiry;

        private List<Models.clsCombobox> PaymentTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> FundCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> StatusTypeList = new List<Models.clsCombobox>();

        private string msFund_cd = "";
        private string msReport_id = "";

        private string msHoldStatusMessage = "";
        private string msDocumentLabel = "";

        // After-fact transaction
        // When this option is on, user can enter a transaction number less than the current system number.
        //
        private bool chkAfterFact_fl = false;

        public bool DisableDocument
        {
            get
            {
                return (moUtility.ToInteger(Header.txtKey_id) > 0 && moUtility.ToInteger(Header.txtPayment_num) > 0 && (Header.optRefund_fl == false));
            }
        }

        // Listing options
        //
        private List<Models.clsCombobox> ListingByList = new List<Models.clsCombobox>();
        private string cboListingBy = "";
        private bool mbListingInitiated_fl = false;
        private bool mbListingPopulated_fl = false;

        // Search options
        //
        private string cboSearchYear = "";
        private bool mbSearchInitiated_fl = false;
        private bool mbSearchPopulated_fl = false;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================

        private class clsHeader
        {
            public string txtKey_id = "";
            public string cboFund_cd = "";
            public string txtPaid_amt = "";
            public string txtVendor_cd = "";
            public string lblVendor_nm = "";
            public string txtReference = "";
            public string txtDescription = "";
            public string mskCashAcct_cd = "";
            public string txtDocument_num = "";
            public string cboStatus_typ = "";
            public string cboPayment_typ = "";
            public string txtBatch_num = "";
            public string txtPayment_num = "";
            public bool optRefund_fl = false;

            public string txtUserApproved_cd = "";
            public string txtToApprove_num = "";

            // Listing of UI items on the header
            //

            public string mskApply_dt = "";
            public string mskEntry_dt = "";
            public DateTime? dtApply_dt = null;
            public DateTime? dtEntry_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag
            {
                public string txtKey_id = "";
                public string cboFund_cd = "";
                public string txtPaid_amt = "";
                public string txtVendor_cd = "";
                public string lblVendor_nm = "";
                public string txtReference = "";
                public string txtDescription = "";
                public string mskCashAcct_cd = "";
                public string txtDocument_num = "";
                public string cboStatus_typ = "";
                public string cboPayment_typ = "";
                public string txtBatch_num = "";
                public string txtPayment_num = "";
                public bool optRefund_fl = false;

                public string mskApply_dt = "";
                public string mskEntry_dt = "";
                public DateTime? dtApply_dt = null;
                public DateTime? dtEntry_dt = null;
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()
            {
                Tag.txtKey_id = txtKey_id;
                Tag.cboFund_cd = cboFund_cd;
                Tag.txtPaid_amt = txtPaid_amt;
                Tag.txtVendor_cd = txtVendor_cd;
                Tag.txtVendor_cd = txtVendor_cd;
                Tag.lblVendor_nm = lblVendor_nm;
                Tag.mskCashAcct_cd = mskCashAcct_cd;
                Tag.txtReference = txtReference;
                Tag.txtDocument_num = txtDocument_num;
                Tag.cboStatus_typ = cboStatus_typ;
                Tag.cboPayment_typ = cboPayment_typ;
                Tag.txtPayment_num = txtPayment_num;
                Tag.optRefund_fl = optRefund_fl;

                Tag.mskApply_dt = mskApply_dt;
                Tag.dtApply_dt = dtApply_dt;
                Tag.mskEntry_dt = mskEntry_dt;
                Tag.dtEntry_dt = dtEntry_dt;
            }
        }
        private clsHeader Header = new clsHeader();

        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            moSession.RemoveSession(moDatabase);        // Delete the session file.

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            // If user uses date-picker, we need to change the date field.
            //
            if (User.bUseDatePicker_fl && moUtility.SLeft(field_name, 3) == "msk" && moUtility.SRight(field_name, 3) == "_dt")
            {
                field_name = moUtility.SReplace(field_name, "msk", "dt");
            }

            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows(int lines_to_add = 0)
        {

            return true;
        }

        private bool FormCalculateTotal()
        {

            return true;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {

            if (FormCheckSecurity() == false)
            {
                return false;
            }
            if (FormCheckHeader() == false)
            {
                return false;
            }
            if (FormCheckDetail() == false)
            {
                return false;
            }
            if (FormCheckExtra() == false)
            {
                return false;
            }

            return true;
        }

        private bool FormCheckDetail()
        {
            bool return_value = false;
            int row_num;

            try
            {
                // Check if the split payments are paid ok.
                //
                for (row_num = 1; row_num < moDetail.Data.GetLength(1); row_num++)
                {
                    if (moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num]) >= moDatabase.mSmallestMoney_amt
                        && moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL, row_num] == moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL, row_num - 1]
                        && moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num - 1]) < moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.BALANCE_DUE_COL, row_num - 1]))
                    {
                        FormShowMessage(User.Language.oMessage.IMPROPER_SPLIT_PAYMENT_FOUND + " - " + User.Language.oString.STR_INVOICE + "(" + moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL, row_num] + ")");
                        return false;
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckDetail)");
            }

            return return_value;
        }

        private bool FormCheckExtra()                                                              // validate extra other than the header and detail.
        {
            bool return_value = false;
            string sql_str = "";
            decimal amt_unused = 0;

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {

                // Custom fields
                //
                if (moCustomFields.CheckValues(moDatabase) == false)
                {
                    FormShowMessage(moCustomFields.GetErrorMessage());
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckExtra)");
            }

            return return_value;
        }

        private bool FormCheckHeader()                                                             // validate the header data.
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
                FormSyncDates(User.bUseDatePicker_fl);

                // GENERIC VALIDATIONS FOR ALL TRASNACTIONS
                //
                msFund_cd = GlobalVar.goFund.GetSelectedFundCodeToSave(ref moDatabase, Header.cboFund_cd);
                FormSyncDates(User.bUseDatePicker_fl);

                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormShowMessage(User.Language.oString.STR_TRANSACTION_NUMBER + @User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("txtKey_id");
                    return false;
                }
                if (moDatabase.bFundAccounting_fl && moUtility.IsEmpty(msFund_cd))
                {
                    FormShowMessage(User.Language.oCaption.FUND_CODE + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("cboFund_cd");
                    return false;
                }
                if (moUtility.ToInteger(Header.cboStatus_typ) == 0)
                {
                    FormShowMessage(User.Language.oMessage.STATUS_HAS_TO_BE_SELECTED);
                    FormSetFocus("cboStatus_typ");
                    return false;
                }
                if (moUtility.IsBlankDate(Header.mskEntry_dt))
                {
                    FormShowMessage(User.Language.oMessage.ENTRY_DATE_IS_REQUIRED);
                    FormSetFocus("mskEntry_dt");
                    return false;
                }
                if (modCommonUtility.ValidEntryDate(ref moDatabase, ref Header.mskEntry_dt) == false)
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_A_VALID_DATE_ENTERED);
                    FormSetFocus("mskEntry_dt");
                    return false;
                }

                if (moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.VOID_TRX_NUM)
                {
                    Header.txtPayment_num = "";
                    Header.mskCashAcct_cd = "";
                    Header.txtDocument_num = "";
                    Header.txtPaid_amt = "";
                    FormClearDetail();
                    Header.mskApply_dt = Header.mskEntry_dt;
                    FormSyncDates(false);
                    return true;
                }

                if (moUtility.ToInteger(Header.cboStatus_typ) != GlobalVar.goConstant.OPEN_TRX_NUM)
                {
                    if (moUtility.IsEmpty(Header.mskApply_dt))
                    {
                        Header.mskApply_dt = Header.mskEntry_dt;
                        FormSyncDates(false);
                    }
                    return true;
                }

                if (moUtility.IsBlankDate(Header.mskApply_dt))
                {
                    FormShowMessage(User.Language.oCaption.APPLY_DATE + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("mskApply_dt");
                    return false;
                }
                if (modCommonUtility.ValidApplyDate(ref moDatabase, ref Header.mskApply_dt) == false)
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_A_VALID_DATE_APPLIED);
                    FormSetFocus("mskApply_dt");
                    return false;
                }

                if (moUtility.IsEmpty(Header.txtVendor_cd))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_A_VENDOR_CODE);
                    FormSetFocus("txtVendor_cd");
                    return false;
                }

                if (Header.optRefund_fl == false && moUtility.ToInteger(Header.txtPayment_num) <= 0)
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_A_PAYMENT_NUMBER);
                    FormSetFocus("txtPayment_num");
                    return false;
                }

                if (Header.optRefund_fl) //Refund
                {
                    if (moMoney.ToNumMoney(Header.txtPaid_amt) <= 0)
                    {
                        FormShowMessage(User.Language.oMessage.PAYMENT_SHOULD_BE_POSITIVE);
                        Header.txtPaid_amt = "";
                        FormSetFocus("txtPaid_amt");
                        return false;
                    }

                    if (moUtility.ToInteger(Header.cboPayment_typ) == 0)
                    {
                        FormShowMessage(User.Language.oMessage.PLEASE_SELECT_THE_PAYMENT_TYPE);
                        return false;
                    }
                    else if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM)
                    {
                        FormShowMessage(User.Language.oMessage.THIS_PAYMENT_TYPE_IS_NOT_ALLOWED);
                        Header.cboPayment_typ = "";
                        FormSetFocus("cboPayment_typ");
                        return false;
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckHeader)");
            }

            return return_value;
        }

        private bool FormCheckConcurrency(clsRecordset cur_set)                                    // Check if someone has changed this record while it is open in this session.
        {

            return true;
        }

        private bool FormCheckToDelete()
        {
            
            return true;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearDetail();
            FormClearExtra();

            return true;
        }

        private bool FormClearDetail()                                                             // Clear the detail.
        {
            moDetail.iTotalRows = 1; // User.iLinesToIncrease;
            moUtility.ResizeDim(ref moDetail.Data, Models.clsPaymentDetail.TOTAL_COLUMNS - 1, moDetail.iTotalRows - 1);

            FormRecreateGrid();

            return true;
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            msHoldStatusMessage = "";
            msDocumentLabel = @User.Language.oString.STR_DOCUMENT_NUM;

            // Custom Fields
            //
            moCustomFields.ClearGrid();

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {
            Header.txtKey_id = "";
            Header.cboStatus_typ = "";
            Header.txtPaid_amt = "";
            Header.txtVendor_cd = "";
            Header.txtDescription = "";
            Header.mskCashAcct_cd = "";
            Header.txtDocument_num = "";
            Header.txtReference = "";
            Header.cboPayment_typ = "";
            Header.lblVendor_nm = "";
            Header.txtBatch_num = "";
            Header.txtPayment_num = "";
            Header.optRefund_fl = false;

            Header.txtUserApproved_cd = "";
            Header.txtToApprove_num = "";

            Header.mskApply_dt = "";
            Header.mskEntry_dt = "";
            FormSyncDates(false);

            return true;
        }

        private bool FormClearMessage()
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            moPage.bInDialog_fl = true;         // Meaning a dialog started

            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    moPage.bInDialog_fl = false;            // Meaning a dialog is enidng with Cancel button
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }

                Modal.Release();                                                                   // Release this call and proceed.
            }

            moPage.bInDialog_fl = false;            // Meaning a dialog is enidng with Cancel button
            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormCommitTransaction()
        {
            string[,] memo_list = null;
            int row_num = 0;

            moUtility.ResizeDim(ref memo_list, 1, moDetail.Data.GetLength(1));  // do not use -1 because of non-refund

            if (Header.optRefund_fl)
            {
                for (row_num = 0; row_num < moDetail.Data.GetLength(1); row_num++)
                {
                    if ((moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num]) > 0) && moUtility.ToInteger(moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, row_num]) > 0)
                    {
                        memo_list[0, row_num] = moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL, row_num];
                        memo_list[1, row_num] = moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num];
                    }
                }

                if (moDeposit.CommitRefund(ref moDatabase, moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id), moUtility.ToInteger(Header.cboStatus_typ), memo_list, Header.optRefund_fl, Header.txtVendor_cd, moDatabase.sCurrency_cd) == false)
                {
                    FormShowMessage();
                    return false;
                }
            }

            return true;
        }

        private bool FormDelete()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id) || moPage.bNew_fl)
                {
                    FormClear();
                    return true;
                }
                else if (FormCheckToDelete() == false)
                {
                    return false;
                }

                // Transaction begins here.
                //
                if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }

                if (modFormUtility.RecordDelete(ref moDatabase, moPage.iScreen_typ, Header.txtKey_id, moPage.sKeyField_nm, moPage.sTable_nm, moPage.sDetailTable_nm, moPage.sRestrictionClause, moPage.iTransaction_typ) == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }
                else if (FormDeleteExtra() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }

                // Transaction ends here.
                //
                if (moDatabase.TransactionCommit() == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDelete)");
                moDatabase.TransactionRollback();
                return_value = false;
            }

            return return_value;
        }

        private bool FormDeleteExtra()
        {

            return true;
        }

        private bool FormEnableBatch(bool switch_fl = true)
        {

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (switch_fl)
            {
                moBatch.ToggleBatch(ref moDatabase);
            }

            User.bBatchEnabled_fl = moDatabase.AllowBatchEntry();
            User.iBatch_num = moDatabase.CurrentBatch;

            moBatch.ShowBatch(moDatabase);

            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormFindRecord(ref clsRecordset cur_set, int matching_type = 0)
        {
            bool return_value = false;

            matching_type = (int)(moUtility.IIf(matching_type > 0, matching_type, GlobalVar.goConstant.MATCHING_RECORD_TYPE));
            return_value = modFormUtility.RecordRead(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sTable_nm, moPage.sKeyField_nm, moPage.sPreviousKey_id, moPage.sRestrictionClause, ref matching_type);

            return return_value;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListingPayment();
            moSearch = new Models.clsListingPayment();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moMoney = new clsMoney(ref moDatabase);
            moBatch = new clsBatch();

            moDetail = new Models.clsPaymentDetail();
            moTransactionPayment = new clsTransactionPayment(ref moDatabase);
            moDeposit = new clsDeposit();
            moReport = new clsReportViewer();
            moCustomFields = new Models.clsCustomField();
            moVendor = new clsVendor(ref moDatabase);
            moSession = new Models.clsSession();
            moInquiry = new clsInquiry();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.APMENU_NAME;
            moPage.Title = User.Language.oCaption.STOP_PAYMENT_ENTRY;
            moPage.iScreen_typ = GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE;
            moPage.iTransaction_typ = GlobalVar.goConstant.TRX_STOP_PAYMENT_TYPE;

            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormInitHeader();
            FormInitDetail();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitDetail()                                                              // Initialize the page at loading.  Only once.
        {
            // Detail table name.
            //
            moPage.sDetailTable_nm = "tblAPPaymentDetUnposted";

            moUtility.ResizeDim(ref moDetail.Data, Models.clsPaymentDetail.TOTAL_COLUMNS - 1, 0);    // These initializations are necessary

            moUtility.ResizeDim(ref moDetail.FieldName, Models.clsPaymentDetail.TOTAL_COLUMNS - 1);
            moDetail.FieldName[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL] = "iAppliedTransaction_num";
            moDetail.FieldName[Models.clsPaymentDetail.CUR_PAYMENT_COL] = "mCurPayment_amt";

            FormClearDetail();

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = "tblAPPaymentUnposted";
            moPage.sKeyField_nm = "iTransaction_num";

            return true;
        }

        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {
            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            // FormSave() & FormCheck() use the plain box whose name starts with "msk"
            // dt* variables are only to interact with UI.  Internally, msk* fields are used.
            //
            FormSyncDates(User.bUseDatePicker_fl);

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();
            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtApply_dt, ref Header.mskApply_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtEntry_dt, ref Header.mskEntry_dt, use_date_picker);

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback

            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;
            clsCustomization custom_fields = new clsCustomization(ref moDatabase);

            try
            {
                if (FormReceiveValues() == false)                    // All pages that use session value need to capture it here before FormOpenDatabase()
                {
                    return false;
                }
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                modLoadUtility.LoadPaymentType(ref moDatabase, ref PaymentTypeList, false, false, false, false,false,false, moDatabase.uProgram.bBRExist_fl);   // If B/R is incorported, cash payment is not allowed
                modLoadUtility.LoadStatusType(ref moDatabase, ref StatusTypeList);

                modLoadUtility.LoadListingBy(ref moDatabase, ref ListingByList, moPage.iTransaction_typ, User);

                //Header.mskApply_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                //Header.mskEntry_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                //FormSyncDates(false);

                msDocumentLabel = @User.Language.oString.STR_DOCUMENT_NUM;

                FormEnableBatch(false);

                // Custom Fields
                //
                if (custom_fields.ReadCustomInfo(moPage.iTransaction_typ, ""))
                {
                    moCustomFields.CreateGrid(custom_fields.sField_nm, custom_fields.sCaptions, custom_fields.bRequired);
                }

                if (moUtility.IsNonEmpty(moPage.sInitialKey_id))
                {
                    Header.txtKey_id = moPage.sInitialKey_id;
                    txtKey_id_Changed();
                }

                FormSwitchView(moView.MAIN_PAGE_NUM);
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormMove(int record_move_direction)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormClear();

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            if (FormFindRecord(ref cur_set, record_move_direction) == false)
            {
                return false;
            }

            FormShow(cur_set);
            return true;

        }

        private bool FormPostSave()
        {
            // If this is a transaction page, and transaction number has changed, let the user know.
            //
            if (moPage.sPreviousKey_id != Header.txtKey_id)
            {
                FormShowMessage(User.Language.oMessage.TRX_NUM_HAS_CHANGED_TO + "  " + Header.txtKey_id, false);
            }

            moPage.sPreviousKey_id = Header.txtKey_id;

            return true;
        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostTransactionRealtime()
        {
            int number_failed = 0;
            string posting_error = "";

            if (moDatabase.bRealTimeMode == false || moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.HOLD_TRX_NUM)
            {
                return true;
            }

            if (moGeneral.ApplyDateIsOkToPost(moGeneral.ToNumDate(Header.mskApply_dt), false) == false)
            {
                FormShowMessage(Header.mskApply_dt + User.Language.oMessage.IS_INVALID_FOR_POSTING);
                return false;
            }

            if (modPostUtility.PostOneTransaction(ref moDatabase, 0, 0, moGeneral.ToNumDate(Header.mskApply_dt), moGeneral.ToNumDate(Header.mskApply_dt)
                                , moUtility.ToInteger(Header.txtKey_id), moUtility.ToInteger(Header.txtKey_id), moPage.iTransaction_typ, posting_error, false, ref number_failed) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {
            // Put some extra validation against the existing record
            // before saving the current modification.
            //

            if (chkAfterFact_fl)
            {
                // A.f.t. transactions should have a number non-existing number less than the current transaction number in the system.
                // Duplicate entry will be checked in clsInvoice.
                //
                if (moPage.bNew_fl)
                {
                    if (moUtility.ToInteger(Header.txtKey_id) >= modGeneralUtility.ReadNextTransactionNumber(ref moDatabase, moPage.iTransaction_typ))
                    {
                        FormShowMessage(Header.txtKey_id + User.Language.oMessage.IS_INVALID);
                        return false;
                    }
                }
            }
            else if (modGeneralUtility.CheckTransactionNumber(ref moDatabase, moPage.bNew_fl, moPage.iScreen_typ, moPage.iTransaction_typ, ref Header.txtKey_id) == false)
            {
                return false;
            }

            // Someone could have saved with the same number.
            //
            if (moPage.bNew_fl && Header.txtKey_id != moPage.sPreviousKey_id)
            {
                cur_set.Release();
            }

            // moInvoice.oSerial = moSerial;

            return true;
        }
        private bool FormPrint()
        {

            return true;
        }


        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormRecreateDetail()
        {
            if (moDetail.RecreateDetail() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateDetailLine(Models.clsPaymentDetail.clsGrid cur_item, int row_num = -1)
        {
            if (moDetail.RecreateDetailLine(cur_item, row_num) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateGrid()
        {
            if (moDetail.RecreateGrid() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormReceiveValues()
        {
            // If connected already, return true.  This means this page came through the menu system.
            //
            if (moUtility.IsNonEmpty(User.sServer_nm) || moDatabase.IsConnected())
            {
                return true;
            }

            // Otherwise, need to login with the info passed from the calling page.
            //
            if (modGeneralUtility.GetPassedParameters(StarterValue, User, moSession) == false)
            {
                FormShowMessage(User.Language.oMessage.PLEASE_LOG_IN_FIRST);
                return false;
            }

            moPage.sInitialKey_id = moSession.Value.Entity;

            return true;
        }

        private bool FormSave(bool from_printing_fl)
        {
            bool return_value = false;
            clsRecordset cur_set;

            try
            {
                if (FormOpenDatabase() == false)                     // Has to come before FormCheck()
                {
                    return false;
                }

                //  Skip this if called from printing because it is already done.
                //
                if (from_printing_fl ==  false)
                {
                    if (FormCheck() == false)                       
                    {
                        return false;
                    }
                }

                moPage.sPreviousKey_id = Header.txtKey_id;
                cur_set = new clsRecordset(ref moDatabase);

                if (modFormUtility.RecordOpen(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sRestrictionClause, moPage.sTable_nm, moPage.sKeyField_nm) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormCheckConcurrency(cur_set) == false)
                {
                    return false;
                }
                else if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormPreSave(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormCommitTransaction() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveHeader(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveExtra(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveDetail() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormPostTransactionRealtime() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (moDatabase.TransactionCommit() == false)
                {
                    FormShowMessage();
                    moDatabase.TransactionRollback();
                    return false;
                }

                FormPostSave();

                return_value = true;

            }
            catch (Exception ex)
            {

                FormShowMessage(ex.Message + " (FormSave)");
                moDatabase.TransactionRollback();

            }

            return return_value;
        }

        private bool FormSaveDetail()
        {
            bool return_value = false;

            int col_num = 0;
            int row_num = 0;
            string field_list = "";
            string value_list = "";
            string sql_str = "";

            clsRecordset cur_set = new clsRecordset(ref moDatabase);
            clsRecordset size_set = new clsRecordset(ref moDatabase);

            try
            {
                // Only refund has the details.
                //
                if (Header.optRefund_fl == false)
                {
                    return true;
                }

                if (modDetailUtility.PreSaveDetail(ref moDatabase, ref size_set, ref field_list, moPage.iTransaction_typ, Header.txtKey_id, moPage.sKeyField_nm, moPage.sDetailTable_nm, moDetail.FieldName, Models.clsPaymentDetail.TOTAL_COLUMNS) == false)
                {
                    FormShowMessage();
                    return false;
                }

                // Add extra field names
                // These should match the extra field values listed down blow.
                //
                field_list += ",iApply_dt";
                field_list += ",iEntry_dt";
                field_list += ",iStatus_typ";
                field_list += ",iAppliedTransaction_typ";

                for (row_num = 0; row_num <= moDetail.Data.GetUpperBound(1); row_num++)
                {
                    // Create the value list.
                    //
                    value_list = moGeneral.EncloseField(moPage.sKeyField_nm, Header.txtKey_id);
                    if (moPage.iTransaction_typ > 0)
                    {
                        value_list += "," + moPage.iTransaction_typ;
                    }
                    value_list += "," + (row_num + 1).ToString();

                    if (moUtility.ToInteger(moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, row_num]) > 0 && moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num]) > 0)
                    {
                        for (col_num = 0; col_num < Models.clsPaymentDetail.TOTAL_COLUMNS; col_num++)
                        {
                            if (moUtility.IsNonEmpty(moDetail.FieldName[col_num]))      // Attach if field name exist.
                            {
                                value_list += "," + moGeneral.EncloseField(moDetail.FieldName[col_num], moDetail.Data[col_num, row_num], size_set.Size(moDetail.FieldName[col_num]));
                            }
                        }

                        // Add extra field values that are not in Data[]
                        // These should match the extra field names listed at the top.
                        //
                        value_list += "," + moGeneral.ToNumDate(Header.mskApply_dt);
                        value_list += "," + moGeneral.ToNumDate(Header.mskEntry_dt);
                        value_list += "," + moUtility.ToInteger(Header.cboStatus_typ).ToString();
                        value_list += "," + GlobalVar.goConstant.TRX_DM_TYPE.ToString();

                        sql_str = "INSERT INTO " + moPage.sDetailTable_nm + "(";
                        sql_str += field_list;
                        sql_str += ") VALUES(" + value_list + ")";

                        if (moDatabase.ExecuteSQL(sql_str) == false)
                        {
                            FormShowMessage();
                            return false;
                        }
                    }
                }

                // Over the internet, it has been noticed that saving details may go south without error message.
                // Since refund commits the amount, it has to be checked here that the details total matches the header amount
                // Do not rely on CheckTransactionDetails_sp in G/L posting.  Amount-committed cannot be recovered so that it has to be done here.
                //
                if (Header.optRefund_fl && moMoney.ToNumMoney(Header.txtPaid_amt) > 0 && moUtility.ToInteger(Header.cboStatus_typ) != GlobalVar.goConstant.VOID_TRX_NUM)
                {
                    sql_str = "SELECT SUM(mCurPayment_amt) AS mTotal_amt FROM tblAPPaymentDetUnposted WHERE iTransaction_typ = " + moPage.iTransaction_typ.ToString() + " AND iTransaction_num = " + Header.txtKey_id;

                    if (cur_set.CreateSnapshot(sql_str) == false)
                    {
                        FormShowMessage();
                        return false;
                    }
                    else if (cur_set.mField("mTotal_amt") != moMoney.ToNumMoney(Header.txtPaid_amt))
                    {
                        FormShowMessage(User.Language.oMessage.TOTAL_AMOUNTS_DO_NOT_MATCH);
                        return false;
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveDetail)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormSaveExtra(clsRecordset cur_set)
        {
            bool return_value = false;
            string extra_log = "";
            string comment_str = "";
            string bank_code = "";

            try
            {

                // MAIN TABLE UPDATE SECTION.
                //
                //extra_log = "PAYMENT NO:" + Header.txtPayment_num;
                //extra_log += " TYPE:" + moUtility.IIf(Header.optRefund_fl == false, User.Language.oString.STR_NSF, User.Language.oString.STR_REFUND);
                //extra_log += " PAYMENT TYPE:" + modCommonUtility.GetComboText(PaymentTypeList, Header.cboPayment_typ);
                //extra_log += " DOC.NUM:" + Header.txtDocument_num;
                //if (moGeneral.SaveTransactionHistory(ref moDatabase, moPage.bNew_fl, moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id)
                //    , moUtility.ToInteger(Header.cboStatus_typ), moGeneral.ToNumDate(Header.mskEntry_dt), moGeneral.ToNumDate(Header.mskApply_dt), Header.txtVendor_cd
                //    , Header.mskCashAcct_cd, moMoney.ToNumMoney(Header.txtPaid_amt), extra_log, "", "", "", "", "", 0M, 0M, 0M, 0M, 0M, Header.lblVendor_nm) == false)
                //{
                //    return return_value;
                //}

                //// OTHER TABLE UPDATE SECTION.
                ////
                //comment_str = User.Language.oString.STR_NSF + ":" + Header.txtDescription;
                //bank_code = moTransactionPayment.GetBankCode(Header.mskCashAcct_cd);

                //if (!moTransactionPayment.UpdateCheckNumber(GlobalVar.goConstant.TRX_STOP_PAYMENT_TYPE, Header.mskCashAcct_cd, Header.txtDocument_num, moUtility.ToInteger(Header.cboPayment_typ), Header.optRefund_fl))
                //{
                //    return false;
                //}

                mbListingInitiated_fl = false;                  // Will let the listing refresh

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormSaveHeader(clsRecordset cur_set)
        {
            bool return_value = false;
            string sql_str = null;

            try
            {


                // This is for Concurrency check to go smooth.
                // If someone calls FormSave() without going thru the whole saving routine that
                // clears the screen, and save again later, then FormCheckConcurrency() will raise an error
                // because the record in the database has been updated but moPage.Original.dtLastUpdate_dt still has the old timestamp.
                //
                moPage.Original.sLastUpdate_id = moDatabase.sUser_cd;
                moPage.Original.dtLastUpdate_dt = DateTime.Now;


                if (moPage.bNew_fl)
                {
                    sql_str = "INSERT INTO " + moPage.sTable_nm + " (";
                    sql_str += moPage.sKeyField_nm;
                    sql_str += ",iBatch_num";
                    sql_str += ",iStatus_typ";
                    sql_str += ",sCreator_id";
                    sql_str += ",iTransaction_typ";
                    sql_str += ",iRefund_fl";
                    sql_str += ",sDescription";
                    sql_str += ",iEntry_dt";
                    sql_str += ",iPayment_num";
                    sql_str += ",sDocument_num";
                    sql_str += ",sVendor_cd";
                    sql_str += ",sOnDocument_nm";
                    sql_str += ",mPaid_amt";
                    sql_str += ",iCash_typ";
                    sql_str += ",sCashAcct_cd";
                    sql_str += ",iApply_dt";
                    sql_str += ",sReference";
                    sql_str += ",sLastUpdate_id";
                    sql_str += ",dtLastUpdate_dt";
                    sql_str += ") VALUES (";
                    sql_str += moUtility.ToInteger(Header.txtKey_id);
                    sql_str += "," + moDatabase.iBatch_num.ToString();
                    sql_str += "," + Header.cboStatus_typ;
                    sql_str += ",'" + moDatabase.sUser_cd + "'";
                    sql_str += "," + moPage.iTransaction_typ.ToString();
                    sql_str += "," + moUtility.IIf(Header.optRefund_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtDescription) + "'";
                    sql_str += "," + moGeneral.ToNumDate(Header.mskEntry_dt);
                    sql_str += "," + moUtility.ToInteger(Header.txtPayment_num);
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtDocument_num) + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtVendor_cd) + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.lblVendor_nm) + "'";
                    sql_str += "," + moMoney.ToNumMoney(Header.txtPaid_amt);
                    sql_str += "," + moUtility.ToInteger(Header.cboPayment_typ).ToString();
                    sql_str += ",'" + moUtility.EvalQuote(Header.mskCashAcct_cd) + "'";
                    sql_str += "," + moGeneral.ToNumDate(Header.mskApply_dt);
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtReference) + "'";
                    sql_str += ",'" + moDatabase.sUser_cd + "'";
                    sql_str += "," + moDatabase.CreateDatetimeValue(moPage.Original.dtLastUpdate_dt);
                    sql_str += ")";
                }
                else
                {
                    sql_str = "UPDATE " + moPage.sTable_nm + " SET";
                    sql_str += " iStatus_typ = " + Header.cboStatus_typ;
                    sql_str += ",iRefund_fl = " + moUtility.IIf(Header.optRefund_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
                    sql_str += ",sDescription = '" + moUtility.EvalQuote(Header.txtDescription) + "'";
                    sql_str += ",iEntry_dt = " + moGeneral.ToNumDate(Header.mskEntry_dt);
                    sql_str += ",iPayment_num = " + moUtility.ToInteger(Header.txtPayment_num);
                    sql_str += ",sDocument_num = '" + moUtility.EvalQuote(Header.txtDocument_num) + "'";
                    sql_str += ",sVendor_cd = '" + moUtility.EvalQuote(Header.txtVendor_cd) + "'";
                    sql_str += ",sOnDocument_nm = '" + moUtility.EvalQuote(Header.lblVendor_nm) + "'";
                    sql_str += ",mPaid_amt = " + moMoney.ToNumMoney(Header.txtPaid_amt);
                    sql_str += ",iCash_typ = " + moUtility.ToInteger(Header.cboPayment_typ).ToString();
                    sql_str += ",sCashAcct_cd = '" + moUtility.EvalQuote(Header.mskCashAcct_cd) + "'";
                    sql_str += ",iApply_dt = " + moGeneral.ToNumDate(Header.mskApply_dt);
                    sql_str += ",sReference = '" + moUtility.EvalQuote(Header.txtReference) + "'";
                    sql_str += ",sLastUpdate_id = '" + moDatabase.sUser_cd + "'";
                    sql_str += ",dtLastUpdate_dt = " + moDatabase.CreateDatetimeValue(moPage.Original.dtLastUpdate_dt);
                    sql_str += " WHERE iTransaction_typ = " + moPage.iTransaction_typ.ToString();
                    sql_str += " AND iTransaction_num = " + Header.txtKey_id;
                }

                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveHeader)");
            }

            return return_value;
        }

        private bool FormSearch()
        {
            string search_detail = "";
            string where_clause = GetSearchCriteria();

            if (moUtility.IsEmpty(where_clause))
            {
                where_clause = search_detail;
            }
            else
            {
                where_clause += moUtility.IIf(moUtility.IsNonEmpty(search_detail), " AND ", "") + search_detail;
            }

            if (moUtility.IsEmpty(where_clause))
            {
                FormShowMessage(User.Language.oMessage.PLEASE_ENTER_THE_SEARCH_CRITERIA_ON_THE_MAIN_ENTRY_TAB);
                return false;
            }


            mbSearchPopulated_fl = false;

            where_clause = moUtility.IIf(moUtility.IsNonEmpty(moPage.sRestrictionClause), moPage.sRestrictionClause, "iTransaction_typ = " + moPage.iTransaction_typ.ToString()) + " AND " + where_clause;

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            //where_clause = modCommonUtility.AddCommonTransactionSearchClause(where_clause, moPage.iTransaction_typ, cboSearchYear);

            if (moSearch.Show(moDatabase, moPage, where_clause) == false)
            {
                FormShowMessage();
                return false;
            }

            mbSearchInitiated_fl = true;
            mbSearchPopulated_fl = (moSearch.Grid.Count > 0);

            if (mbSearchPopulated_fl == false)
            {
                FormShowMessage(User.Language.oMessage.NO_MATCHING_RECORDS_FOUND);
            }

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {
            if (FormShowHeader(cur_set) == false)
            {
                return false;
            }
            else if (FormShowExtra(cur_set) == false)
            {
                return false;
            }
            else if (FormShowDetail() == false)
            {
                return false;
            }

            FormReArrangeHeader();

            return true;
        }

        private bool FormShowDetail()
        {
            bool return_value = false; ;
            string sql_str = "";
            int row_num = 0;
            decimal disc_avail = 0;
            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                FormClearDetail();

                sql_str = "SELECT p.iAppliedTransaction_num, m.iApply_dt, m.sYourReference, (m.mDue_amt - m.mCommitted_amt + p.mCurPayment_amt) AS mBalance_amt, p.mCurPayment_amt";
                sql_str += " FROM tblAPPaymentDetUnposted p LEFT JOIN tblAPCharge m "; // do not use INNER JOIN because iAppliedTransaction_num is 0 for cash-deposit
                sql_str += " ON (p.iAppliedTransaction_num = m.iTransaction_num AND p.iAppliedTransaction_typ = m.iTransaction_typ)";
                sql_str += " WHERE p.iTransaction_typ = " + moPage.iTransaction_typ.ToString();
                sql_str += " AND p.iTransaction_num = " + Header.txtKey_id;
                sql_str += " ORDER BY p.iDetail_num";
                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    return false;
                }
                else if (cur_set.EOF())
                {
                    return true;
                }

                moDetail.iTotalRows = cur_set.RecordCount();
                moUtility.ResizeDim(ref moDetail.Data, Models.clsPaymentDetail.TOTAL_COLUMNS - 1, moDetail.iTotalRows - 1);

                for (row_num = 0; row_num < moDetail.Data.GetLength(1); row_num++)
                {
                    moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, row_num] = GlobalVar.goConstant.CHECKED_ON.ToString();

                    if (cur_set.iField("iAppliedTransaction_num") > 0)
                    {
                        moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL, row_num] = cur_set.iField("iAppliedTransaction_num").ToString();
                        moDetail.Data[Models.clsPaymentDetail.REFERENCE_COL, row_num] = cur_set.sField("sYourReference");
                        moDetail.Data[Models.clsPaymentDetail.BALANCE_DUE_COL, row_num] = moMoney.ToStrMoney(cur_set.mField("mBalance_amt"));
                    }
                    else
                    {
                        moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL, row_num] = "";
                        moDetail.Data[Models.clsPaymentDetail.REFERENCE_COL, row_num] = User.Language.oString.STR_USE_DEPOSIT;
                        moDetail.Data[Models.clsPaymentDetail.BALANCE_DUE_COL, row_num] = moMoney.ToStrMoney(moVendor.mDeposit_amt + cur_set.mField("mCurPayment_amt"));
                    }

                    moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_DATE_COL, row_num] = moGeneral.ToStrDate(cur_set.iField("iApply_dt"));
                    moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num] = moMoney.ToStrMoney(cur_set.mField("mCurPayment_amt"));

                    cur_set.MoveNext();
                }

                FormRecreateGrid();
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormShowDetail)");
            }

            return return_value;
        }

        private bool FormShowExtra(clsRecordset cur_set)
        {
            bool return_value = false;
            string tmp = "";
            clsApproval o_approval = new clsApproval(ref moDatabase);

            try
            {
                moPage.Clear();
                moPage.PreserveTimestamp(cur_set);
                moPage.bNew_fl = false;

                // This is where bReadOnly_fl & bReserved_fl are set according to the nature of the current record.
                //

                msHoldStatusMessage = GlobalVar.goStatus.HoldingStatusTypeText(cur_set.iField("iHoldStatus_typ"));

                if (cur_set.iField("iHoldStatus_typ") > 0)
                {
                    msHoldStatusMessage += o_approval.GetPendidngStatus(cur_set.iField("iTransaction_typ"), cur_set.iField("iTransaction_num"));
                }


                moVendor.ClearVendor();

                // Voided ones may not have vendor code.
                //
                if (moUtility.IsNonEmpty(Header.txtVendor_cd))
                {
                    if (!moVendor.GetVendor(Header.txtVendor_cd, true))
                    {
                        FormShowMessage(Header.txtVendor_cd + User.Language.oMessage.IS_INVALID);
                        Header.txtVendor_cd = "";
                    }
                    else
                    {
                        Header.lblVendor_nm = moVendor.sVendor_nm;
                    }
                }

                moPage.sPreviousKey_id = Header.txtKey_id;
                Header.Preserve();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
            }

            return return_value;
        }

        private bool FormShowHeader(clsRecordset cur_set)
        {
            Header.txtKey_id = cur_set.sField(moPage.sKeyField_nm);
            Header.cboStatus_typ = cur_set.iField("iStatus_typ").ToString();
            Header.cboFund_cd = GlobalVar.goFund.GetSelectedFundCodeToDisplay(ref moDatabase, cur_set.sField("sFund_cd"));

            if (cur_set.iField("iPayment_num") > 0)
            {
                Header.txtPayment_num = cur_set.iField("iPayment_num").ToString();
            }
            else
            {
                Header.txtPayment_num = "";
            }

            Header.cboPayment_typ = cur_set.iField("iCash_typ").ToString();
            Header.optRefund_fl = (cur_set.iField("iRefund_fl") == GlobalVar.goConstant.CHECKED_ON);
            Header.txtBatch_num = cur_set.iField("iBatch_num").ToString();
            Header.mskApply_dt = moGeneral.ToStrDate(cur_set.iField("iApply_dt"));
            Header.mskEntry_dt = moGeneral.ToStrDate(cur_set.iField("iEntry_dt"));
            Header.txtPaid_amt = moMoney.ToStrMoney(cur_set.mField("mPaid_amt"));
            Header.txtVendor_cd = cur_set.sField("sVendor_cd");
            Header.txtDescription = cur_set.sField("sDescription");
            Header.mskCashAcct_cd = cur_set.sField("sCashAcct_cd");
            Header.txtDocument_num = cur_set.sField("sDocument_num");
            Header.txtReference = cur_set.sField("sReference");

            Header.txtUserApproved_cd = cur_set.sField("sUserApproved_cd");
            Header.txtToApprove_num = cur_set.iField("iToApprove_num").ToString();

            FormSyncDates(false);

            // Custom Fields
            //
            moCustomFields.SetValues(moDatabase, cur_set);

            return true;
        }

        private bool FormShowListing()
        {
            string where_clause = "";

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (mbListingInitiated_fl)
            {
                return true;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moListing.Show(moDatabase, moPage, where_clause, cboListingBy) == false)
            {
                FormShowMessage();
                return false;
            }

            mbListingInitiated_fl = true;
            mbListingPopulated_fl = (moListing.Grid.Count > 0);

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);

            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moZoom.Caller == "txtVendor_cd")
            {
                if (moZoom.Vendor(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            else if (moZoom.Caller == "mskCashAcct_cd")
            {
                if (moZoom.Account(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            else if (moZoom.Caller == "txtPayment_num")
            {
                if (moZoom.Code(ref moDatabase, "tblAPPayment", "sVendor_cd") == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
                {
                    return false;
                }
            }

            FormCancel();
            return true;
        }

        private bool btnDelete_Clicked()
        {
            FormPreEvent();

            if (FormDialog(btnDelete_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_DELETE) == false)
            {
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (FormDelete() == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }

        private bool btnFirst_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnFirst_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.FIRST_RECORD_TYPE);
        }

        private bool btnLast_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnLast_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.LAST_RECORD_TYPE);
        }

        private bool btnNext_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnNext_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.NEXT_RECORD_TYPE);
        }

        private bool btnPrevious_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnPrevious_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.PREVIOUS_RECORD_TYPE);
        }

        private bool btnSave_Clicked()
        {
            FormPreEvent();

            if (FormSave(false) == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        private bool btnPrint_Clicked()
        {
            if (moPage.bInDialog_fl == false)           // While in dialog, do not call FormPreEvent() which will remove the possible message displayed in printing process
            {
                FormPreEvent();
            }

            // At this point, we only print check, no remittance advise for EDF
            //
            if (moUtility.ToInteger(Header.cboPayment_typ) != GlobalVar.goConstant.CHECK_TYPE_NUM || moUtility.ToInteger(Header.cboStatus_typ) != GlobalVar.goConstant.OPEN_TRX_NUM)
            {
                FormShowMessage(User.Language.oMessage.YOU_CAN_ONLY_PRINT_CHECK_WITH_OPEN_STATUS);
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormRecreateDetail();                       // Make sure Data[] and Grid are in Sync

            // This flag sould be set before FormCheck() because of FormDialog() called in in FormCheck().
            //
            moPage.bInPrinting_fl = true;

            // Should save/print for the first time only.  When comming back from dialog, need to skip.
            //
            if (Modal.ReturningTo(10000) == false)
            {
                if (FormCheck() == false)
                {
                    return false;
                }
                
                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

                if (FormPrint() == false)
                {
                    return false;
                }
            }

            if (FormDialog(btnPrint_Clicked, 10000, User.Language.oMessage.IS_PRINTED_OK) == false)
            {
                return false;
            }

            if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.CHECK_TYPE_NUM)                  // All other types are already saved in PrintRemittanceAdvice().
            {
                if (FormSave(true) == false)
                {
                    return false;
                }
            }

            moPage.bNew_fl = false;
            moPage.bInPrinting_fl = false;

            FormSwitchView(moView.MAIN_PAGE_NUM);

            FormClear();

            return FormPostEvent();
        }

        private bool cmdCancelOnSearch_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return FormPostEvent();
        }

        private bool btnSearchToPrint_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateSearchHTML();

            return FormPostEvent();
        }

        private bool btnSearchToExcel_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateSearchExcel();

            return FormPostEvent();
        }

        private bool btnListingToPrint_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateListingHTML();

            return FormPostEvent();
        }

        private bool btnListingToExcel_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateListingExcel();

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewHeader_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool cmdViewListing_Clicked()
        {
            FormPreEvent();

            if (FormShowListing() == false)
            {
                return false;
            }

            FormSwitchView(moView.LISTING_PAGE_NUM);
            return true;

        }

        private bool cmdViewSearch_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.SEARCH_PAGE_NUM);

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnListingSelect_Clicked(Models.clsListingPayment.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.ToInteger(cur_item.Transaction_num) <= 0)   // May have a string such as TOTAL
            {
                return false;
            }

            FormClear();
            Header.Tag.txtKey_id = "";
            Header.txtKey_id = cur_item.Transaction_num;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnSearchSelect_Clicked(Models.clsListingPayment.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.IsEmpty(cur_item.Transaction_num))
            {
                return false;
            }

            FormClear();
            Header.txtKey_id = cur_item.Transaction_num;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                code_selected = cur_item.Col_0;

                if (moZoom.Caller == "txtVendor_cd")
                {
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    Header.txtVendor_cd = code_selected;
                    return txtVendor_cd_Changed();
                }
                else if (moZoom.Caller == "mskCashAcct_cd")
                {
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    Header.mskCashAcct_cd = code_selected;
                    return mskCashAcct_cd_Changed();
                }
                else if (moZoom.Caller == "txtPayment_num")
                {
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    Header.txtPayment_num = code_selected;
                    return txtPayment_num_Changed();
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }

        private bool btnZoomOnKey_id_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdSearch_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormSearch() == false)
            {
                return false;
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool cmdNew_Clicked()
        {
            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (chkAfterFact_fl)            // For A.F.T, New button should be disabled.
            {
                return false;
            }

            FormClear();

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            // Get the next transaction number.  This would not consume the number.  FormSave() will consume the number.
            //
            Header.txtKey_id = modGeneralUtility.ReadNextTransactionNumber(ref moDatabase, moPage.iTransaction_typ).ToString();

            if (moUtility.ToInteger(Header.txtKey_id) > 0)
            {
                Header.cboStatus_typ = GlobalVar.goConstant.OPEN_TRX_NUM.ToString();
                Header.mskEntry_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                Header.mskApply_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                FormSyncDates(false);
            }
            else
            {
                FormShowMessage();
                Header.txtKey_id = "";
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return FormPostEvent();
        }
        private bool txtKey_id_Changed()
        {
            if (Header.txtKey_id == Header.Tag.txtKey_id)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (txtKey_id_Verified() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool mskCashAcct_cd_Changed()
        {
            Header.mskCashAcct_cd = modCommonUtility.CleanCode(Header.mskCashAcct_cd);

            if (Header.mskCashAcct_cd == Header.Tag.mskCashAcct_cd)
            {
                return true;
            }

            if (moPage.bInDialog_fl == false)
            {
                FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.
            }

            if (moUtility.IsEmpty(Header.mskCashAcct_cd) || moUtility.IsEmpty(Header.txtKey_id))
            {
                Header.txtDocument_num = "";
                return true;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moValidate.IsValidActualAcctCode(Header.mskCashAcct_cd) ==  false)
            {
                FormShowMessage(Header.mskCashAcct_cd + User.Language.oMessage.IS_INVALID);
                Header.mskCashAcct_cd = Header.Tag.mskCashAcct_cd;
                return false;
            }

            //if (moUtility.ToInteger(Header.cboPayment_typ) > 0 && moUtility.IsNonEmpty(Header.txtVendor_cd))
            //{
            //    if (moUtility.QualifiedTenderForCheckRegister(moUtility.ToInteger(Header.cboPayment_typ)))
            //    {
            //        Header.txtDocument_num = moTransactionPayment.GetNextCheckNumber(Header.mskCashAcct_cd, moUtility.ToInteger(Header.cboPayment_typ)).ToString();
            //        if (moDatabase.IsErrorFound())
            //        {
            //            FormShowMessage();
            //            Header.mskCashAcct_cd = Header.Tag.mskCashAcct_cd;
            //            FormSetFocus("mskCashAcct_cd");
            //            return false;
            //        }
            //    }
            //}

            return FormPostEvent();
        }

        private bool txtDocument_num_Changed()
        {
            Header.txtDocument_num = moUtility.EvalQuote(Header.txtDocument_num);

            if (Header.txtDocument_num == Header.Tag.txtDocument_num)
            {
                return true;
            }

            if (moPage.bInDialog_fl == false)
            {
                FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.
            }

            if (txtDocument_num_Verified() == false)
            {
                if (moPage.bInDialog_fl == false)
                {
                    Header.txtDocument_num = Header.Tag.txtDocument_num;
                }
                return false;
            }

            return FormPostEvent();
        }

        private bool txtVendor_cd_Changed()
        {
            Header.txtVendor_cd = modCommonUtility.CleanCode(Header.txtVendor_cd);

            if (Header.txtVendor_cd == Header.Tag.txtVendor_cd)
            {
                return true;
            }

            if (moPage.bInDialog_fl == false)
            {
                FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.
            }

            FormClearDetail();

            if (txtVendor_cd_Verified() == false)
            {
                if (moPage.bInDialog_fl == false)
                {
                    Header.txtVendor_cd = Header.Tag.txtVendor_cd;
                    Header.lblVendor_nm = Header.Tag.lblVendor_nm;
                    Header.cboPayment_typ = "";
                    Header.txtDocument_num = "";
                }
                return false;
            }

            return FormPostEvent();
        }

        private bool cboPayment_typ_Clicked()
        {
            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return true; // In search mode
            }

            if (Header.cboPayment_typ == Header.Tag.cboPayment_typ)
            {
                return true;
            }

            FormPreEvent();

            if (moUtility.ToInteger(Header.cboPayment_typ) == 0)
            {
                msDocumentLabel = User.Language.oString.STR_DOCUMENT_NUM;
                Header.mskCashAcct_cd = "";
                Header.txtDocument_num = "";
                Header.cboPayment_typ = "";
                Header.txtPaid_amt = "";
                Header.txtVendor_cd = "";
                Header.lblVendor_nm = "";

                return FormPostEvent();
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (cboPayment_typ_Verified() == false)
            {
                if (moPage.bInDialog_fl == false)
                {
                    Header.cboPayment_typ = Header.Tag.cboPayment_typ;
                    Header.txtDocument_num = Header.Tag.txtDocument_num;
                }
                return false;
            }

            return FormPostEvent();
        }

        private bool txtPayment_num_Changed()
        {
            if (moUtility.ToInteger(Header.txtPayment_num) <= 0)
            {
                Header.txtPayment_num = "";
            }
            else
            {
                Header.txtPayment_num = moUtility.ToInteger(Header.txtPayment_num).ToString();
            }

            if (Header.txtPayment_num == Header.Tag.txtPayment_num)
            {
                return true;
            }

            FormPreEvent();

            if (txtPayment_num_Verified() == false)
            {
                if (moPage.bInDialog_fl == false)
                {
                    Header.txtPayment_num = Header.Tag.txtPayment_num;
                }
            }
            return FormPostEvent();
        }

        private bool optStopPayment_fl_Clicked()
        {
            FormPreEvent();
            Header.optRefund_fl = false;

            Header.txtPayment_num = "";
            Header.txtDocument_num = "";
            Header.txtVendor_cd = "";
            Header.lblVendor_nm = "";
            Header.cboPayment_typ = "";
            Header.mskCashAcct_cd = "";
            Header.txtPaid_amt = "";

            FormClearDetail();

            return FormPostEvent();
        }

        private bool optRefund_fl_Clicked()
        {
            FormPreEvent();
            Header.optRefund_fl = true;

            Header.txtPayment_num = "";
            Header.txtDocument_num = "";
            Header.txtVendor_cd = "";
            Header.lblVendor_nm = "";
            Header.cboPayment_typ = "";
            Header.mskCashAcct_cd = "";
            Header.txtPaid_amt = "";

            return FormPostEvent();
        }

        private bool dtApply_dt_Changed()
        {
            if (Header.dtApply_dt == Header.Tag.dtApply_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtApply_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtApply_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtApply_dt) == false)
            {
                Header.dtApply_dt = Header.Tag.dtApply_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtApply_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskApply_dt_Changed()
        {
            if (Header.mskApply_dt == Header.Tag.mskApply_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskApply_dt) == false)
            {
                Header.mskApply_dt = Header.Tag.mskApply_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskApply_dt");
                return false;
            }

            return FormPostEvent();
        }


        private bool dtEntry_dt_Changed()
        {
            if (Header.dtEntry_dt == Header.Tag.dtEntry_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtEntry_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtEntry_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtEntry_dt) == false)
            {
                Header.dtEntry_dt = Header.Tag.dtEntry_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtEntry_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskEntry_dt_Changed()
        {
            if (Header.mskEntry_dt == Header.Tag.mskEntry_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskEntry_dt) == false)
            {
                Header.mskEntry_dt = Header.Tag.mskEntry_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskEntry_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool btnAccount_cd_Clicked()
        {
            string where_clause = "";

            FormPreEvent();
            
            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "mskCashAcct_cd", -1, -1, moView.MAIN_PAGE_NUM, "sAccount_cd", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool btnZoomOnPayment_num_Clicked()
        {
            string where_clause = "";

            FormPreEvent();

            where_clause = " iTransaction_typ = " + GlobalVar.goConstant.TRX_PAYMENT_TYPE;
            where_clause += " AND iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM;
            where_clause += " AND iApply_dt >= " + moUtility.AddToDate(GlobalVar.goConstant.YEAR_TYPE, moGeneral.CurrentDate(), -1);
            if (moUtility.IsNonEmpty(Header.txtVendor_cd))
            {
                where_clause += " AND sVendor_cd = '" + Header.txtVendor_cd + "'";
            }

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtPayment_num", -1, -1, moView.MAIN_PAGE_NUM, "iTransaction_num", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }
            return FormPostEvent();
        }
        private bool btnZoomOnVendor_cd_Clicked()
        {
            string where_clause = "";

            FormPreEvent();

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtVendor_cd", -1, -1, moView.MAIN_PAGE_NUM, "sVendor_cd", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdUnSelectAll_Clicked()
        {
            foreach (var det in moDetail.Grid)
            {
                det.chkInclude_fl = false;
                det.txtCurrentPayment_amt = "";
            }

            FormRecreateDetail();
            CalculateTotals();

            return FormPostEvent();
        }

        private bool cmdSelectAll_Clicked()
        {
            foreach (var det in moDetail.Grid)
            {
                det.chkInclude_fl = true;
                det.txtCurrentPayment_amt = det.txtBalanceDue_amt;
            }

            FormRecreateDetail();
            CalculateTotals();

            return FormPostEvent();
        }


        private bool cmdCancelOnPrint_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.MAIN_PAGE_NUM);
            return FormPostEvent();
        }

        private bool cmdOKOnPrint_Clicked()
        {
            FormPreEvent();

            cmdOKOnPrint_Verified();

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Verified()
        {
            bool return_value = false;
            clsRecordset cur_set;
            string key_id = "";

            try
            {
                if (moUtility.ToInteger(Header.txtKey_id) > 0)
                {
                    Header.txtKey_id = moUtility.ToInteger(Header.txtKey_id).ToString();
                }
                else
                {
                    Header.txtKey_id = "";
                }

                key_id = Header.txtKey_id;

                if (Header.txtKey_id == Header.Tag.txtKey_id)
                {
                    return true;
                }
                else if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormClear();
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    FormClear();
                    FormShowMessage(User.Language.oMessage.CONNECTION_HAS_FAILED);
                    return false;
                }

                cur_set = new clsRecordset(ref moDatabase);

                if (FormFindRecord(ref cur_set))
                {
                    FormShow(cur_set);
                }
                else
                {
                    if (chkAfterFact_fl == false)
                    {
                        FormClear();
                        Header.txtKey_id = key_id;
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtKey_id_Verified)");
            }

            return return_value;
        }

        private bool txtDocument_num_Verified()
        {
            bool return_value = false;
            string sql_str = null;
            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {

                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    return true;
                }
                else if (moUtility.IsEmpty(Header.txtDocument_num))
                {
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    return false;
                }


                // For refund, need to makre sure the check number is valid.
                //
                if (Header.optRefund_fl)
                {
                    if (moUtility.IsEmpty(Header.txtVendor_cd))
                    {
                        FormShowMessage(User.Language.oMessage.ENTER_VEND_CODE_FIRST);
                        return false;
                    }
                    if (moUtility.ToInteger(Header.cboPayment_typ) == 0)
                    {
                        FormShowMessage(User.Language.oMessage.SELECT_PAYMENT_TYPE);
                        return false;
                    }

                    if (moUtility.QualifiedTenderForCheckRegister(moUtility.ToInteger(Header.cboPayment_typ)))
                    {
                        if (moUtility.SLength(Header.txtDocument_num) > 8)
                        {
                            Header.txtDocument_num = moUtility.SLeft(Header.txtDocument_num, 8);
                        }
                        if (moUtility.ToInteger(Header.txtDocument_num) > 0)
                        {
                            Header.txtDocument_num = moUtility.ToInteger(Header.txtDocument_num).ToString();        // Only accept ineteger
                        }
                        else
                        {
                            FormShowMessage(msDocumentLabel + User.Language.oMessage.IS_INVALID);
                            return false;
                        }
                    }

                    //if (moUtility.QualifiedTenderForCheckRegister(moUtility.ToInteger(Header.cboPayment_typ)))
                    //{
                    //    if (moValidate.IsValidCheckNumber(Header.txtDocument_num, Header.mskCashAcct_cd, "", moUtility.ToInteger(Header.cboPayment_typ))) // Check number exist.
                    //    {
                    //        FormShowMessage(Header.txtDocument_num + User.Language.oMessage.ALREADY_EXISTS);
                    //        return false;
                    //    }
                    //}

                    return true;
                }

                // Bring up the cash payment with the same document number.
                //
                sql_str = "SELECT iTransaction_num FROM tblAPPayment";
                sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_PAYMENT_TYPE;
                sql_str += " AND sDocument_num = '" + moUtility.EvalQuote(Header.txtDocument_num) + "'";

                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage(cur_set.GetErrorMessage());
                    return false;
                }
                else if (cur_set.EOF() == false)
                {
                    Header.txtPayment_num = cur_set.iField("iTransaction_num").ToString();
                    txtPayment_num_Changed();
                    cur_set.Release();
                    return true;
                }

                // Check for the cash payment starting with the document number.
                //
                sql_str = "SELECT iTransaction_num FROM tblAPPayment";
                sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_PAYMENT_TYPE;
                sql_str += " AND sDocument_num LIKE '" + moUtility.EvalQuote(Header.txtDocument_num) + "%'";

                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage(cur_set.GetErrorMessage());
                    return false;
                }
                else if (cur_set.EOF())
                {
                    FormShowMessage(Header.txtDocument_num + User.Language.oMessage.IS_INVALID);
                    return false;
                }

                Header.txtPayment_num = cur_set.iField("iTransaction_num").ToString();
                txtPayment_num_Changed();
                cur_set.Release();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(Header.txtDocument_num_TextChanged)");
            }

            return return_value;
        }

        private bool txtVendor_cd_Verified()
        {
            bool return_value = false;
            string sql_str = "";

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                FormClearDetail();

                if (moUtility.IsEmpty(Header.txtVendor_cd))
                {
                    Header.lblVendor_nm = "";
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                if (moValidate.IsValidVendorCode(Header.txtVendor_cd) == false)
                {
                    FormShowMessage(Header.txtVendor_cd + User.Language.oMessage.IS_INVALID);
                    return false;
                }

                Header.lblVendor_nm = moValidate.oRecordset.sField("sVendor_nm");

                if (moUtility.IsEmpty(Header.txtKey_id) || Header.optRefund_fl == false)
                {
                    return true;
                }

                if (moVendor.UnpostedRefundExists(moUtility.ToInteger(Header.txtKey_id), Header.txtVendor_cd)) // to simplify the refund process. otherwise, there could be double refund for cash-deposit.
                {
                    FormShowMessage(User.Language.oMessage.UNPOSTED_REFUND_EXISTS + "(" + Header.txtVendor_cd + ")");
                    return false;
                }

                if (moVendor.GetVendor(Header.txtVendor_cd, true, moDatabase.sCurrency_cd, true) == false)
                {
                    FormShowMessage(Header.txtVendor_cd + User.Language.oMessage.DOES_NOT_EXIST);
                    return false;
                }
                else if (moVendor.IsValidForTransaction(moPage.iTransaction_typ) == false)
                {
                    FormShowMessage(Header.txtVendor_cd + User.Language.oMessage.IS_INVALID_FOR_THIS_TRX);
                    Header.txtVendor_cd = "";
                    Header.lblVendor_nm = "";
                    return false;
                }

                FindOpenMemos();

                moValidate.oRecordset.Release();
                FormReArrangeHeader();
                CalculateTotals();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtVendor_cd_Verified)");
            }

            return return_value;
        }
        private bool txtPayment_num_Verified()
        {
            bool return_value = false;
            string sql_str = "";
            string payment_list = "";
            clsDeposit o_deposit = new clsDeposit();
            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    return true;
                }
                if (moUtility.ToInteger(Header.txtPayment_num) == 0)
                {
                    Header.txtVendor_cd = "";
                    txtVendor_cd_Changed();
                    return true;
                }
                if (Header.optRefund_fl)
                {
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                if (moUtility.IsNonEmpty(Header.txtPayment_num))
                {
                    // Check if there is NSF for this receit.
                    //
                    sql_str = "SELECT iTransaction_num FROM tblAPPaymentUnposted";
                    sql_str += " WHERE iTransaction_typ =" + moPage.iTransaction_typ.ToString();
                    sql_str += " AND iTransaction_num <> " + Header.txtKey_id;
                    sql_str += " AND iPayment_num = " + Header.txtPayment_num;
                    // sql_str += " AND iStatus_typ <> " + GlobalVar.goConstant.VOID_TRX_NUM.ToString();

                    if (cur_set.CreateSnapshot(sql_str) == false)
                    {
                        Header.txtPayment_num = "";
                        Header.txtVendor_cd = "";
                        txtVendor_cd_Changed();
                        FormShowMessage();
                        FormSetFocus("txtPayment_num");
                        return false;
                    }
                    else if (cur_set.EOF() == false)
                    {
                        Header.txtPayment_num = "";
                        Header.txtVendor_cd = "";
                        txtVendor_cd_Changed();
                        FormShowMessage(User.Language.oMessage.UNPOSTED_NSF_EXISTS + "(#" + cur_set.iField("iTransaction_num") + ")");
                        FormSetFocus("txtPayment_num");
                        cur_set.Release();
                        return false;
                    }

                    cur_set.Release();

                    sql_str = "SELECT iTransaction_num FROM tblAPPayment";
                    sql_str += " WHERE iTransaction_typ =" + moPage.iTransaction_typ.ToString();
                    sql_str += " AND iPayment_num = " + Header.txtPayment_num;
                    sql_str += " AND iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM;
                    if (cur_set.CreateSnapshot(sql_str) == false)
                    {
                        Header.txtPayment_num = "";
                        Header.txtVendor_cd = "";
                        txtVendor_cd_Changed();
                        FormShowMessage();
                        FormSetFocus("txtPayment_num");
                        return false;
                    }
                    else if (cur_set.EOF() == false)
                    {
                        Header.txtPayment_num = "";
                        Header.txtVendor_cd = "";
                        txtVendor_cd_Changed();
                        FormShowMessage(Header.txtPayment_num + User.Language.oMessage.HAS_BEEN_STOPPED_ALREADY + "(#" + cur_set.iField("iTransaction_num") + ")");
                        FormSetFocus("txtPayment_num");
                        cur_set.Release();
                        return false;
                    }

                    cur_set.Release();

                    sql_str = "SELECT * FROM tblAPMCPayment";
                    sql_str += " WHERE iTransaction_typ =" + GlobalVar.goConstant.TRX_PAYMENT_TYPE;
                    sql_str += " AND iTransaction_num = " + Header.txtPayment_num;
                    if (cur_set.CreateSnapshot(sql_str) == false)
                    {
                        Header.txtPayment_num = "";
                        Header.txtVendor_cd = "";
                        txtVendor_cd_Changed();
                        FormShowMessage();
                        FormSetFocus("txtPayment_num");
                        return false;
                    }
                    else if (cur_set.RecordCount() > 0)
                    {
                        Header.txtPayment_num = "";
                        Header.txtVendor_cd = "";
                        txtVendor_cd_Changed();
                        FormShowMessage(User.Language.oMessage.FOREIGN_TRANSACTION_IS_NOT_ALLOWED);
                        FormSetFocus("txtPayment_num");
                        cur_set.Release();
                        return false;
                    }

                    cur_set.Release();

                    if (moValidate.IsValidPayment(moUtility.ToInteger(Header.txtPayment_num)) == false)
                    {
                        Header.txtPayment_num = "";
                        Header.txtVendor_cd = "";
                        txtVendor_cd_Changed();
                        FormShowMessage(Header.txtPayment_num + User.Language.oMessage.IS_INVALID);
                        FormSetFocus("txtPayment_num");
                        moValidate.oRecordset.Release();
                        return false;
                    }

                    // If the original receipt was not using C/M or deposit, and there were over-payment,
                    // then need to check the over-paid amount is not used for other payments.
                    // 
                    if (moValidate.oRecordset.iField("iCash_typ") != GlobalVar.goConstant.MEMO_TYPE_NUM)
                    {
                        if (o_deposit.GetVendorDeposit(ref moDatabase, moValidate.oRecordset.sField("sVendor_cd"), "") < (moValidate.oRecordset.mField("mPaid_amt") - moValidate.oRecordset.mField("mUsed_amt")))
                        {
                            // If the deposit has been consumed already, find which payments used it.
                            //
                            sql_str = "SELECT * FROM tblAPPayment";
                            sql_str += " WHERE iTransaction_typ =" + GlobalVar.goConstant.TRX_PAYMENT_TYPE.ToString();
                            sql_str += " AND iEntry_dt >= " + moValidate.oRecordset.iField("iEntry_dt").ToString();
                            sql_str += " AND iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM;
                            sql_str += " AND iCash_typ = " + GlobalVar.goConstant.MEMO_TYPE_NUM.ToString();
                            sql_str += " AND sVendor_cd = '" + moValidate.oRecordset.sField("sVendor_cd") + "'";
                            sql_str += " AND sDocument_num = ''"; // if used cash deposit.
                            if (cur_set.CreateSnapshot(sql_str) == false)
                            {
                                Header.txtPayment_num = "";
                                Header.txtVendor_cd = "";
                                txtVendor_cd_Changed();
                                FormShowMessage();
                                FormSetFocus("txtPayment_num");
                                cur_set.Release();
                                return false;
                            }

                            payment_list = "";
                            while (cur_set.EOF() == false)
                            {
                                payment_list += moUtility.IIf(moUtility.IsEmpty(payment_list), "", ", ") + cur_set.iField("iTransaction_num");
                                cur_set.MoveNext();
                            }

                            if (moUtility.IsEmpty(payment_list))
                            {
                                payment_list = User.Language.oMessage.DEPOSIT_HAS_BEEN_ALLOCATED_ALREADY;
                            }
                            else
                            {
                                payment_list = User.Language.oMessage.DEPOSIT_HAS_BEEN_ALLOCATED_ALREADY + " " + User.Language.oMessage.FOLLOWING_PAYMENTS_ALLOCATED_DEPOSIT + payment_list;
                            }
                            payment_list += " " + User.Language.oMessage.PAYMENTS_NEED_TO_BE_STOPPED_TO_CANCEL_DEPOSIT;

                            Header.txtPayment_num = "";
                            Header.txtVendor_cd = "";
                            txtVendor_cd_Changed();
                            FormShowMessage(payment_list);
                            FormSetFocus("txtPayment_num");
                            return false;
                        }
                    }

                    CopyPaymentToNSF(moUtility.ToInteger(Header.txtPayment_num));   // This must be called only when moValidate is open.
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtPayment_num_Verified)");
            }

            return return_value;
        }

        private bool cboPayment_typ_Verified()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtVendor_cd))
                {
                    FormShowMessage(User.Language.oMessage.ENTER_VEND_CODE_FIRST);
                    FormSetFocus("txtVendor_cd");
                    return true;
                }
                if (moVendor.GetVendor(Header.txtVendor_cd, true) == false)
                {
                    FormShowMessage(Header.txtVendor_cd + User.Language.oMessage.IS_INVALID);
                    Header.txtVendor_cd = Header.Tag.txtVendor_cd;
                    Header.txtPaid_amt = "";
                    FormSetFocus("txtVendor_cd");
                    return false;
                }

                if (Header.optRefund_fl && moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM)
                {
                    FormShowMessage(User.Language.oMessage.INVALID_VALUE_SELECTED);
                    return false;
                }
                if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.CHECK_TYPE_NUM)
                {
                    msDocumentLabel = User.Language.oString.STR_CHECK_NUM;
                }
                else if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.WIRE_TRANSFER_TYPE_NUM)
                {
                    msDocumentLabel = User.Language.oString.STR_EFT_NUM;
                }
                else if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM)
                {
                    msDocumentLabel = User.Language.oString.STR_CREDIT_MEMO;
                }
                else
                {
                    msDocumentLabel = User.Language.oString.STR_DOCUMENT_NUM;
                }

                if (moUtility.IsNonEmpty(moVendor.sVendor_cd))
                {
                    Header.mskCashAcct_cd = moVendor.GetCashAccountCode(moUtility.ToInteger(Header.cboPayment_typ));
                }
                else
                {
                    Header.mskCashAcct_cd = "";
                }

                //if (moUtility.IsNonEmpty(Header.mskCashAcct_cd))
                //{
                //    if (moUtility.QualifiedTenderForCheckRegister(moUtility.ToInteger(Header.cboPayment_typ)))
                //    {
                //        Header.txtDocument_num = moTransactionPayment.GetNextCheckNumber(Header.mskCashAcct_cd, moUtility.ToInteger(Header.cboPayment_typ)).ToString();

                //    }
                //}

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (cboPayment_typ_Verified)");
            }

            return return_value;
        }

        private bool cmdOKOnPrint_Verified()
        {
            int new_check_num = 0;
            int row_num = 0;

            
            return FormPostEvent();
        }

        private bool CustomField_Changed(Models.clsCustomField.clsGrid cur_item)
        {
            FormPreEvent();

            if (moCustomFields.ValidateValue(moDatabase, cur_item) == false)
            {
                FormShowMessage(moCustomFields.GetErrorMessage());
                return false;
            }

            return FormPostEvent();
        }

        private bool cboListingBy_Clicked()
        {
            FormShowListing();

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        private bool DetailInclude_fl_Clicked(Models.clsPaymentDetail.clsGrid cur_item)
        {
            FormPreEvent();

            // VERY IMPORTTANT -----------------------------------------------------------------------------------------------------
            //
            // This event kickes in before the value of chkInclude_fl changes.
            // (cur_item.chkInclude_fl == true) means that the current value of chkInclude_fl is TRUE, and it will change to FALSE when it returns to UI.
            //
            if (cur_item.chkInclude_fl)
            {
                cur_item.txtCurrentPayment_amt = "";
                moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, cur_item.Row_num] = GlobalVar.goConstant.CHECKED_OFF.ToString();
            }
            else
            {
                cur_item.txtCurrentPayment_amt = moDetail.Data[Models.clsPaymentDetail.BALANCE_DUE_COL, cur_item.Row_num];
                moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, cur_item.Row_num] = GlobalVar.goConstant.CHECKED_ON.ToString();
            }


            // FormRecreateDetailLine(cur_item);   DO NOT CALL THIS.  IT WILL MESS UP SYNC BECAUSE OF THE REASON COMMENTED ABOVE.
            // Update moDetail.Data[] manually as needed here instead.
            //
            moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, cur_item.Row_num] = cur_item.txtCurrentPayment_amt;
            moDetail.Data[Models.clsPaymentDetail.DISC_TAKEN_COL, cur_item.Row_num] = cur_item.txtDiscountTaken_amt;

            CalculateTotals();

            return FormPostEvent();
        }

        private bool DetailPayment_Changed(Models.clsPaymentDetail.clsGrid cur_item)
        {
            if (moMoney.ToNumMoney(cur_item.txtCurrentPayment_amt) > 0)
            {
                cur_item.txtCurrentPayment_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(cur_item.txtCurrentPayment_amt));
            }
            else
            {
                cur_item.txtCurrentPayment_amt = "";
            }

            if (moMoney.ToNumMoney(cur_item.txtCurrentPayment_amt) ==  moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, cur_item.Row_num]))
            {
                return true;
            }

            FormPreEvent();

            if (DetailPayment_Verified(cur_item) == false)
            {
                cur_item.txtCurrentPayment_amt = moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, cur_item.Row_num];
                return false;
            }

            cur_item.chkInclude_fl = (moMoney.ToNumMoney(cur_item.txtCurrentPayment_amt) > 0);

            FormRecreateDetailLine(cur_item);
            CalculateTotals();

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        private bool DetailPayment_Verified(Models.clsPaymentDetail.clsGrid cur_item)
        {
            if (moMoney.ToNumMoney(cur_item.txtCurrentPayment_amt) > moMoney.ToNumMoney(cur_item.txtBalanceDue_amt))
            {
                FormShowMessage(User.Language.oMessage.PAYMENT_CANNOT_EXCEED_AMT_DUE);
                return false;
            }

            cur_item.txtCurrentPayment_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(cur_item.txtCurrentPayment_amt));

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================
        private string GetSearchCriteria()
        {
            string return_value = "";

            try
            {

                if (moUtility.IsNonEmpty(Header.mskEntry_dt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "iEntry_dt = " + moGeneral.ToNumDate(Header.mskEntry_dt).ToString();
                }
                if (moUtility.IsNonEmpty(Header.mskApply_dt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "iApply_dt = " + moGeneral.ToNumDate(Header.mskApply_dt).ToString();
                }
                if (moUtility.ToInteger(Header.cboStatus_typ) > 0)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "iStatus_typ = " + Header.cboStatus_typ;
                }
                if (moUtility.IsNonEmpty(Header.txtVendor_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sVendor_cd = '" + moUtility.EvalQuote(Header.txtVendor_cd) + "'";
                }
                if (moUtility.IsNonEmpty(Header.txtDescription))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sDescription LIKE '" + moUtility.EvalQuote(Header.txtDescription) + "%'";
                }
                if (moUtility.ToInteger(Header.cboPayment_typ) > 0)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "iCash_typ =" + Header.cboPayment_typ;
                }
                if (moUtility.IsNonEmpty(Header.txtDocument_num))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sDocument_num LIKE '" + moUtility.EvalQuote(Header.txtDocument_num) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtReference))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sReference LIKE '" + moUtility.EvalQuote(Header.txtReference) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtPaid_amt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "mPaid_amt =" + moMoney.ToNumMoney(Header.txtPaid_amt).ToString();
                }
                if (moUtility.IsNonEmpty(Header.mskCashAcct_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sCashAcct_cd = '" + moUtility.EvalQuote(Header.mskCashAcct_cd) + "'";
                }
                if (moUtility.ToInteger(Header.txtPayment_num) > 0)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "iPayment_num =" + moUtility.ToInteger(Header.txtPayment_num).ToString();
                }
                if (Header.optRefund_fl)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "iRefund_fl = 1";
                }

                if (moUtility.IsNonEmpty(Header.cboFund_cd))
                {
                    if (Header.cboFund_cd == clsNPConstant.FUND_ORGANIZATION_CODE)
                    {
                        return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sFund_cd = ''";
                    }
                    else
                    {
                        return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sFund_cd = '" + GlobalVar.goFund.GetSelectedFundCodeToSave(ref moDatabase, Header.cboFund_cd) + "'";
                    }
                }

                return return_value;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (GetSearchCriteria)");
            }

            return return_value;
        }

        public bool CalculateTotals()
        {
            int row_num = 0;
            decimal total_paid = 0;
            decimal tax_retained = 0;

            for (row_num = 0; row_num < moDetail.Data.GetLength(1); row_num++)
            {
                if (moUtility.ToInteger(moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON) 
                {
                    total_paid += moMoney.ToNumMoney(moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num]);
                }

                // If the amount is too large, return false.
                //
                if (moMoney.TooLargeDollar(total_paid))
                {
                    FormShowMessage(User.Language.oMessage.TOO_LARGE_DOLLAR);
                    return false;
                }
            }

            Header.txtPaid_amt = moMoney.ToStrMoney(total_paid);

            return true;
        }

        public bool CopyPaymentToNSF(int payment_num)
        {

            Header.txtVendor_cd = moValidate.oRecordset.sField("sVendor_cd");

            if (moVendor.GetVendor(Header.txtVendor_cd, true, moValidate.oRecordset.sField("sCurrency_cd")))
            {
                Header.lblVendor_nm = moVendor.sVendor_nm;
            }
            else
            {
                Header.lblVendor_nm = "";
            }

            Header.txtPayment_num = payment_num.ToString();
            Header.cboPayment_typ = moValidate.oRecordset.iField("iCash_typ").ToString();
            Header.mskCashAcct_cd = moUtility.IIf(moValidate.oRecordset.sField("sCashAcct_cd") == "", moGeneral.GetEmptyMaskedGLAccountCode(), moValidate.oRecordset.sField("sCashAcct_cd")).ToString();
            Header.txtDocument_num = moValidate.oRecordset.sField("sDocument_num");
            Header.txtPaid_amt = moMoney.ToStrMoney(moValidate.oRecordset.mField("mPaid_amt"));

            moValidate.oRecordset.Release();

            return true;
        }

        public bool FindOpenMemos()
        {
            bool return_value = false;
            int row_num = 0;
            string sql_str = "";
            decimal disc_avail = 0;
            clsRecordset cur_set = null;

            try
            {
                FormClearDetail();

                cur_set = new clsRecordset(ref moDatabase);

                if (CreateOpenMemoSet(ref cur_set) == false)
                {
                    return return_value;
                }

                moDetail.iTotalRows = cur_set.RecordCount() + moUtility.IIf((moVendor.mDeposit_amt > 0), 1, 0);

                moUtility.ResizeDim(ref moDetail.Data, Models.clsPaymentDetail.TOTAL_COLUMNS - 1, moDetail.iTotalRows - 1);

                row_num = 0;

                if (moVendor.mDeposit_amt > 0)
                {
                    moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, row_num] = GlobalVar.goConstant.CHECKED_OFF.ToString();

                    moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL, row_num] = "";
                    moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_DATE_COL, row_num] = "";
                    moDetail.Data[Models.clsPaymentDetail.REFERENCE_COL, row_num] = User.Language.oString.STR_DEPOSIT;
                    moDetail.Data[Models.clsPaymentDetail.BALANCE_DUE_COL, row_num] = moMoney.ToStrMoney(moVendor.mDeposit_amt);

                    row_num = 1;
                }

                while (cur_set.EOF() == false)
                {
                    moDetail.Data[Models.clsPaymentDetail.INCLUDE_COL, row_num] = GlobalVar.goConstant.CHECKED_OFF.ToString();

                    moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL, row_num] = cur_set.iField("iTransaction_num").ToString();
                    moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_DATE_COL, row_num] = moGeneral.ToStrDate(cur_set.iField("iApply_dt"));
                    moDetail.Data[Models.clsPaymentDetail.REFERENCE_COL, row_num] = cur_set.sField("sYourReference");
                    moDetail.Data[Models.clsPaymentDetail.BALANCE_DUE_COL, row_num] = moMoney.ToStrMoney(cur_set.mField("mBalance_amt"));

                    cur_set.MoveNext();
                    row_num += 1;
                }

                FormRecreateGrid();
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FindOpenMemos)");
            }

            return return_value;
        }

        // PURPOSE:  To create the snapshot of the open invoices for a Vendor.
        //
        public bool CreateOpenMemoSet(ref clsRecordset cur_set)
        {
            bool return_value = false;
            string sql_str = null;

            try
            {
                //  Select all the open invoices.
                //
                sql_str = "SELECT iTransaction_num, iApply_dt, sYourReference, (mDue_amt - mCommitted_amt) AS mBalance_amt";
                sql_str += " FROM tblAPCharge";
                sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_DM_TYPE.ToString();
                sql_str += " AND iOrder_num = 0"; // non-voucher specific memo only.
                sql_str += " AND iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM.ToString();
                sql_str += " AND sVendor_cd = '" + Header.txtVendor_cd + "'";
                sql_str += " AND ((mDue_amt - mCommitted_amt) >= 0.01)";
                sql_str += " ORDER BY iTransaction_num";

                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(CreateOpenMemoSet)");
            }

            return return_value;
        }

        private bool CreateSearchHTML()
        {
            bool return_value = false;
            string html_file = "";
            string[] header_list = null;

            clsSpreadsheet o_search = new clsSpreadsheet();

            try
            {
                if (ShowSearchPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moSearch, ref o_search, ref header_list) == false)      // Listing & Search both share PrepListingDownload()
                {
                    return false;
                }

                html_file = moInquiry.CreateHTML(ref moDatabase, moPage.Title, o_search, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(html_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(html_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateSearchHTML)");
            }

            return return_value;
        }


        private bool CreateSearchExcel()
        {
            bool return_value = false;
            string csv_file = "";
            string[] header_list = null;

            clsSpreadsheet o_search = new clsSpreadsheet();

            try
            {
                if (ShowSearchPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moSearch, ref o_search, ref header_list) == false)
                {
                    return false;
                }

                csv_file = moInquiry.CreateCSV(ref moDatabase, moPage.Title, o_search, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(csv_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(csv_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateSearchExcel)");
            }

            return return_value;
        }

        private bool PrepListingDownload(clsListingPayment o_listing, ref clsSpreadsheet o_spread, ref string[] header_list)
        {
            bool return_value = false;
            int row_num = 0;
            int i = 0;

            try
            {
                moUtility.ResizeDim(ref o_spread.Data, 10, o_listing.Grid.Count - 1);

                foreach (var lst in o_listing.Grid)
                {
                    i = 0;

                    o_spread.Data[i++, row_num] = lst.Transaction_num;
                    o_spread.Data[i++, row_num] = lst.Status_typ;
                    o_spread.Data[i++, row_num] = lst.Entry_dt;
                    o_spread.Data[i++, row_num] = lst.Apply_dt;
                    o_spread.Data[i++, row_num] = lst.Cash_typ;
                    o_spread.Data[i++, row_num] = lst.Payment_num;
                    o_spread.Data[i++, row_num] = lst.Entity_cd;
                    //o_spread.Data[i++, row_num] = lst.Entity_nm;
                    o_spread.Data[i++, row_num] = lst.Document_num;
                    o_spread.Data[i++, row_num] = lst.Reference;
                    o_spread.Data[i++, row_num] = lst.Paid_amt;
                    o_spread.Data[i++, row_num] = lst.Description;

                    row_num += 1;
                }

                moUtility.ResizeDim(ref header_list, i - 1);
                i = 0;

                header_list[i++] = User.Language.oCaption.NUMBER;
                header_list[i++] = User.Language.oCaption.STATUS;
                header_list[i++] = User.Language.oCaption.ENTRY_DATE;
                header_list[i++] = User.Language.oCaption.APPLY_DATE;
                header_list[i++] = User.Language.oCaption.PAYMENT_TYPE;
                header_list[i++] = User.Language.oCaption.PAYMENT_NUM;
                header_list[i++] = User.Language.oCaption.VENDOR;
                //header_list[i++] = User.Language.oCaption.NAME;
                header_list[i++] = User.Language.oCaption.DOCCHECK_NUM;
                header_list[i++] = User.Language.oCaption.REFERENCE;
                header_list[i++] = User.Language.oCaption.PAID;
                header_list[i++] = User.Language.oCaption.DESCRIPTION;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PrepListingDownload)");
            }

            return return_value;
        }

        private bool CreateListingHTML()
        {
            bool return_value = false;
            string html_file = "";
            string[] header_list = null;

            clsSpreadsheet o_listing = new clsSpreadsheet();

            try
            {
                if (ShowListingPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moListing, ref o_listing, ref header_list) == false)
                {
                    return false;
                }

                html_file = moInquiry.CreateHTML(ref moDatabase, moPage.Title, o_listing, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(html_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(html_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateListingHTML)");
            }

            return return_value;
        }


        private bool CreateListingExcel()
        {
            bool return_value = false;
            string csv_file = "";
            string[] header_list = null;

            clsSpreadsheet o_listing = new clsSpreadsheet();

            try
            {
                if (ShowListingPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moListing, ref o_listing, ref header_list) == false)
                {
                    return false;
                }

                csv_file = moInquiry.CreateCSV(ref moDatabase, moPage.Title, o_listing, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(csv_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(csv_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateListingExcel)");
            }

            return return_value;
        }

    }
}
