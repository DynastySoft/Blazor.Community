﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Local;
using Dynasty.Report;

namespace Dynasty.ASP.Pages.GL
{
    public partial class Expense
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<Expense> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;                                                               
        private Models.clsListingTransaction moListing;
        private Models.clsSpreadsheet moSpreadsheet;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        private bool AssetTransaction
        {
            get
            {
                return ((moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_FA_SERVICE_TYPE_NUM)
                || (moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_FA_PAYMENT_TYPE_NUM)
                || (moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_FA_INSURANCE_TYPE_NUM));
            }
        }
        private bool InternalCostTransaction
        {
            get
            {
                return ((moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_INTERNAL_SALE_COST_TYPE_NUM)
                || (moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_INTERNAL_PURCHASE_COST_TYPE_NUM)
                || (moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_INTERNAL_CONSIGNMENT_COST_TYPE_NUM));
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsMoney moMoney;
        private clsTransactionPayment moTransactionPayment;
        private clsReportViewer moReport;

        private List<Models.clsCombobox> FundCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> TaxCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CashTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ServiceCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> StatusTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> JobCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CashAcctCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ExpenseAcctCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ExpenseTypeList = new List<Models.clsCombobox>();

        private bool mbEntityVisible_fl = false;
        private bool mbServiceVisible_fl = false;
        private bool mbCashEnabled_fl = true;

        // Listing options
        //
        private List<Models.clsCombobox> ListingByList = new List<Models.clsCombobox>();
        private string cboListingBy = "";
        private bool mbListingInitiated_fl = false;
        private bool mbListingPopulated_fl = false;

        // Search options
        //
        private string cboSearchYear = "";
        private bool mbSearchInitiated_fl = false;
        private bool mbSearchPopulated_fl = false;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader                   
        {
            // Listing of UI items on the header
            //
            public string txtKey_id = "";
            public string txtDescription = "";

            public string txtTransaction_amt = "";
            public string txtReference = "";
            public string txtEntity_cd = "";
            public string txtCheck_num = "";
            public string txtPayTo_nm = "";
            public string txtPayToAddress1 = "";
            public string txtPayToAddress2 = "";
            public string txtPayToAddress3 = "";
            public string txtOrder_num = "";

            public string lblTax_amt = "";
            public string lblCompany_nm = "";
            public string lblStrAmount = "";
            public string lblEntity_cd = "";
            public string lblCheck_num = "";

            public string cboTax_cd = "";
            public string cboCash_typ = "";
            public string cboService_cd = "";
            public string cboStatus_typ = "";
            public string cboJob_cd = "";
            public string cboCashAcct_cd = "";
            public string cboExpenseAcct_cd = "";
            public string cboFund_cd = "";
            public string cboExpense_typ = "";

            // Datetime component is not very user-friendly, yet, as of VS2019.
            // For better understanding this, read the comment on bUseDatePicker_fl in clsUser.
            //
            public string mskEntry_dt = "";
            public DateTime? dtEntry_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag                                                                     
            {
                public string txtKey_id  = "";
                public string txtEntity_cd = "";
                public string txtTransaction_amt = "";
                public string cboExpense_typ = "";
                public string cboCash_typ = "";
                public string cboCashAcct_cd = "";
                public string cboTax_cd = "";
                public string txtOrder_num = "";

                public string mskEntry_dt = "";
                public DateTime? dtEntry_dt = null;
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()                                                                  
            {
                Tag.txtKey_id = txtKey_id;
                Tag.txtEntity_cd = txtEntity_cd;
                Tag.txtTransaction_amt = txtTransaction_amt;
                Tag.cboExpense_typ = cboExpense_typ;
                Tag.cboCash_typ = cboCash_typ;
                Tag.cboCashAcct_cd = cboCashAcct_cd;
                Tag.cboTax_cd = cboTax_cd;
                Tag.txtOrder_num = txtOrder_num;

                Tag.mskEntry_dt = mskEntry_dt;
                Tag.dtEntry_dt = dtEntry_dt;
            }
        }
        private clsHeader Header = new clsHeader();                                                 


        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;                        
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            // If user uses date-picker, we need to change the date field.
            //
            if (User.bUseDatePicker_fl && moUtility.SLeft(field_name, 3) == "msk" && moUtility.SRight(field_name, 3) == "_dt")
            {
                field_name = moUtility.SReplace(field_name, "msk", "dt");
            }
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows()
        {

            return true;
        }

        private bool FormCalculateTotal()
        {

            return true;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            if (FormCheckSecurity() == false)
            {
                return false;
            }
            else if (FormCheckHeader() == false)
            {
                return false;
            }
            else if (FormCheckExtra() == false)
            {
                return false;
            }

            return true;
        }

        private bool FormCheckExtra()                                                              // validate extra other than the header and detail.
        {
            bool return_value = false;

            try
            {

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckExtra)");
            }

            return return_value;
        }

        private bool FormCheckHeader()                                                             // validate the header data.
        {
            bool return_value = false;

            try
            {
                if (InternalCostTransaction == false)
                {
                    Header.txtOrder_num = "";
                }
                if (mbEntityVisible_fl == false)
                {
                    Header.txtEntity_cd = "";
                }
                if (mbServiceVisible_fl == false)
                {
                    Header.cboService_cd = "";
                }

                if (moUtility.QualifiedTenderForCheckRegister(moUtility.ToInteger(Header.cboCash_typ))) 
                {
                    if (moUtility.ToInteger(Header.txtCheck_num) <= 0)
                    {
                        Header.txtCheck_num = "";
                    }
                    else 
                    {
                        Header.txtCheck_num = moUtility.ToInteger(Header.txtCheck_num).ToString();
                    }
                }

                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormShowMessage(User.Language.oCaption.CODE + @User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("txtKey_id");
                    return false;
                }
                else if (moUtility.ToInteger(Header.cboStatus_typ) == 0)
                {
                    FormShowMessage(User.Language.oMessage.STATUS_HAS_TO_BE_SELECTED);
                    FormSetFocus("cboStatus_typ");
                    return false;
                }
                else if (moUtility.IsBlankDate(Header.mskEntry_dt))
                {
                    FormShowMessage(User.Language.oMessage.ENTRY_DATE_IS_REQUIRED);
                    FormSetFocus("mskEntry_dt");
                    return false;
                }
                else if (moUtility.ToInteger(Header.cboStatus_typ) != GlobalVar.goConstant.OPEN_TRX_NUM)
                {
                    return true;
                }
               
                
                if (modCommonUtility.ValidApplyDate(ref moDatabase, ref Header.mskEntry_dt) == false)
                {
                    FormShowMessage(User.Language.oMessage.ENTRY_DATE_IS_INVALID);
                    Header.mskEntry_dt = moUtility.GetEmptyMaskedDate();
                    FormSetFocus("mskEntry_dt");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboExpense_typ))
                {
                    FormShowMessage(User.Language.oCaption.EXPENSE_TYPE + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("cboExpense_typ");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboExpenseAcct_cd))
                {
                    FormShowMessage(User.Language.oMessage.EXPENSE_ACCOUNT_HAS_TO_BE_SELECTED);
                    FormSetFocus("cboExpenseAcct_cd");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboCashAcct_cd))
                {
                    FormShowMessage(User.Language.oMessage.CASH_ACCOUNT_HAS_TO_BE_SELECTED);
                    FormSetFocus("cboCashAcct_cd");
                    return false;
                }
                else if (moUtility.ToInteger(Header.cboCash_typ) == 0)
                {
                    FormShowMessage(User.Language.oMessage.SELECT_PAYMENT_TYPE);
                    FormSetFocus("cboCash_typ");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboTax_cd))
                {
                    FormShowMessage(User.Language.oCaption.TAX_CODE + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("cboTax_cd");
                    return false;
                }
                else if (moMoney.ToNumMoney(Header.txtTransaction_amt) < moDatabase.mSmallestMoney_amt)
                {
                    FormShowMessage(User.Language.oMessage.POSITIVE_AMOUNT_HAS_TO_BE_ENTERED);
                    FormSetFocus("txtTransaction_amt");
                    return false;
                }
                else if (moUtility.QualifiedTenderForCheckRegister(moUtility.ToInteger(Header.cboCash_typ)) && moUtility.IsEmpty(Header.txtCheck_num))
                {
                    FormShowMessage(Header.lblCheck_num + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("txtCheck_num");
                    return false;
                }

                if (moDatabase.bFundAccounting_fl && moUtility.IsEmpty(Header.cboFund_cd))
                {
                    FormShowMessage(User.Language.oMessage.SELECT_FUND_CODE);
                    FormSetFocus("cboFund_cd");
                    return false;
                }
                

                // QUICK_EXPENSE_FA_SERVICE_TYPE_NUM, QUICK_EXPENSE_FA_PAYMENT_TYPE_NUM & QUICK_EXPENSE_FA_INSURANCE_TYPE_NUM do not require txtEntity_cd
                // because if they utilize the group codes for those, txtEntity_cd is meaningless.  If it is the case, they leave txtEntity_cd empty and enter the other info only.
                // 
                if (moUtility.IsEmpty(Header.txtEntity_cd) && (moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_EMPLOYEE_TYPE_NUM))
                {
                    FormShowMessage(Header.lblEntity_cd + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("txtEntity_cd");
                    return false;
                }

                if (moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_FA_SERVICE_TYPE_NUM 
                    && mbServiceVisible_fl && moUtility.IsEmpty(Header.cboService_cd))
                {
                    FormShowMessage(@User.Language.oCaption.SERVICE_CODE + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("cboService_cd");
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckHeader)");
            }

            return return_value;
        }

        private bool FormCheckConcurrency(clsRecordset cur_set)                                    // Check if someone has changed this record while it is open in this session.
        {
            if (cur_set.IsNonEmpty()) 
            {
                if (moPage.bNew_fl)
                {
                    // Let it go.  FormPreSave() will take care of this case.
                }
                else if (moPage.CheckForConcurrency(cur_set) == false)
                {
                    // If someone has updated this record in the meantime.
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                }
            }
            else if (moPage.bNew_fl == false)
            {
                // If current record is missing, it could have been posted by someone.
                // Need to make sure it does not exist in the posted table.
                //
                if (moValidate.IsValidTransaction(moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id), false))
                {
                    FormShowMessage(User.Language.oMessage.THIS_TRX_EXISTS_AND_HAS_BEEN_POSTED_ALREADY);
                    return false;
                }
            }

            return true;
        }

        private bool FormCheckToDelete()
        {
            clsIntegrity o_integrity = new clsIntegrity(ref moDatabase);

            if (FormCheckSecurity() == false)
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }
            else if (modFormUtility.IsReservedRecord(ref moDatabase, Header.txtKey_id, moPage.bReserved_fl))
            {
                FormShowMessage(User.Language.oMessage.RESERVED_RECORD_IS_NOT_ALLOWED_TO_DELETE);
                return false;
            }
            else if (o_integrity.IsReferenced(moPage.sModule_id, moPage.sKeyField_nm, Header.txtKey_id))
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }

            return true;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearExtra();

            return true;
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            mbServiceVisible_fl = false;
            mbEntityVisible_fl = false;
            mbCashEnabled_fl = true;

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {
            Header.txtKey_id = "";
            Header.txtDescription = "";

            Header.txtReference = "";
            Header.txtTransaction_amt = "";
            Header.txtEntity_cd = "";
            Header.txtCheck_num = "";
            Header.lblTax_amt = "";
            Header.lblStrAmount = "";
            Header.txtPayTo_nm = "";
            Header.txtPayToAddress1 = "";
            Header.txtPayToAddress2 = "";
            Header.txtPayToAddress3 = "";
            Header.txtOrder_num = "";

            Header.lblCheck_num = User.Language.oCaption.CHECK_NUMBER;

            Header.cboTax_cd = "";
            Header.cboCash_typ = "";
            Header.cboService_cd = "";
            Header.cboStatus_typ = "";
            Header.cboJob_cd = "";
            Header.cboCashAcct_cd = "";
            Header.cboExpenseAcct_cd = "";
            Header.cboFund_cd = "";
            Header.cboExpense_typ = "";

            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            //
            Header.mskEntry_dt = "";
            FormSyncDates(false);

            return true;
        }

        private bool FormClearMessage()                                                            
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id) || moPage.bNew_fl)
                {
                    FormClear();
                    return true;
                }
                else if (FormCheckToDelete() == false)
                {
                    return false;
                }

                // Transaction begins here.
                //
                if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }

                if (modFormUtility.RecordDelete(ref moDatabase, moPage.iScreen_typ, Header.txtKey_id, moPage.sKeyField_nm, moPage.sTable_nm, moPage.sDetailTable_nm, moPage.sRestrictionClause, moPage.iTransaction_typ) == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }
                else if (FormDeleteExtra() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }

                // Transaction ends here.
                //
                if (moDatabase.TransactionCommit() == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDelete)");
                moDatabase.TransactionRollback();
                return_value = false;
            }

            return return_value;
        }

        private bool FormDeleteExtra()
        {

            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormFindRecord(ref clsRecordset cur_set, int matching_type = 0)
        {
            bool return_value = false;

            matching_type = (int)(moUtility.IIf(matching_type > 0, matching_type, GlobalVar.goConstant.MATCHING_RECORD_TYPE));
            return_value = modFormUtility.RecordRead(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sTable_nm, moPage.sKeyField_nm, moPage.sPreviousKey_id, moPage.sRestrictionClause, ref matching_type);

            return return_value;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListingTransaction();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moMoney = new clsMoney(ref moDatabase);
            moTransactionPayment = new clsTransactionPayment(ref moDatabase);
            moReport = new clsReportViewer();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.GLMENU_NAME;
            moPage.Title = User.Language.oCaption.QUICK_EXPENSE_ENTRY;
            moPage.iTransaction_typ= GlobalVar.goConstant.TRX_EXPENSE_TYPE;
            moPage.iScreen_typ = GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE;

            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormInitHeader();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = "tblGLExpenseUnposted"; 
            moPage.sKeyField_nm = "iTransaction_num";

            Header.lblCheck_num = User.Language.oCaption.CHECK_NUMBER;

            return true;
        }

        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {


            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            // FormSave() & FormCheck() use the plain textbox whose name starts with "msk"
            // dt* variables are only to interact with UI.  Internally, msk* fields are used.
            //
            FormSyncDates(User.bUseDatePicker_fl);

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback
            
            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;

            try 
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                modLoadUtility.LoadFundCode(ref moDatabase, ref FundCodeList, moGeneral.CurrentDate(), GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE); // Need to load fund whether it is fund accouning or not
                modLoadUtility.LoadStatusType(ref moDatabase, ref StatusTypeList);

                modLoadUtility.LoadExpenseType(ref moDatabase, ref ExpenseAcctCodeList, false);
                modLoadUtility.LoadBankAccount(ref moDatabase, ref CashAcctCodeList, true);
                modLoadUtility.LoadJobCode(ref moDatabase, ref JobCodeList);
                modLoadUtility.LoadVATCode(ref moDatabase, ref TaxCodeList, false);
                modLoadUtility.LoadQuickPaymentType(ref moDatabase, ref CashTypeList);
                modLoadUtility.LoadQuickExpenseType(ref ExpenseTypeList);
                modLoadUtility.LoadFAServiceCode(ref moDatabase, ref ServiceCodeList, true);

                Header.lblCompany_nm = moDatabase.uCompany.sName;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormMove(int record_move_direction)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormClear();

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            if (FormFindRecord(ref cur_set, record_move_direction) == false)
            {
                return false;
            }

            FormShow(cur_set);
            return true;

        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostTransactionRealtime()
        {
            int gltrx_num = 0;
            clsPostGL o_postGL = new clsPostGL(ref moDatabase);

            if (moGeneral.ApplyDateIsOkToPost(moGeneral.ToNumDate(Header.mskEntry_dt), false) == false)
            {
                FormShowMessage(Header.mskEntry_dt + User.Language.oMessage.IS_INVALID_FOR_POSTING);
                return false;
            }

            if (moUtility.ToInteger(Header.cboStatus_typ) != GlobalVar.goConstant.HOLD_TRX_NUM)
            {
                if (o_postGL.PostQuickExpense(moUtility.ToInteger(Header.txtKey_id), ref gltrx_num) == false)
                {
                    FormShowMessage();
                    return false;
                }
            }

            return true;
        }

        private bool FormPostSave()
        {
            // If this is a transaction page, and transaction number has changed, let the user know.
            //
            if (moPage.sPreviousKey_id != Header.txtKey_id)
            {
                FormShowMessage(User.Language.oMessage.TRX_NUM_HAS_CHANGED_TO + "  " + Header.txtKey_id, false);
            }

            moPage.sPreviousKey_id = Header.txtKey_id;

            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {

            // Put some extra validation against the existing record
            // before saving the current modification.
            //
            if (moPage.bNew_fl == false && cur_set.IsNonEmpty())    // Both goUtility.ToInteger(txtNew_fl.Text) and cur_set.Empty() should be checked : DO NOT CHANGE.
            {

            }
            else if (modGeneralUtility.CheckTransactionNumber(ref moDatabase, moPage.bNew_fl, moPage.iScreen_typ, moPage.iTransaction_typ, ref Header.txtKey_id) == false)
            {
                return false;
            }

            // Someone could have saved with the same number.
            //
            if (moPage.bNew_fl && Header.txtKey_id != moPage.sPreviousKey_id)
            {
                cur_set.Release();
            }

            return true;
        }

        private bool FormPrint()
        {
            bool return_value = false;
            string report_name = "";
            string pdf_file = "";
            clsFile o_file = new clsFile();
            DateTime stime_started = DateTime.Now;
            clsMail o_mail = new clsMail(ref moDatabase);

            try
            {
                if (FormOpenDatabase() == false)        // Do not delete this
                {
                    return false;
                }

                moReport.InitReport(moUtility.GetServerName(ref moDatabase), moUtility.GetDatabaseName(ref moDatabase), moUtility.GetDBUser(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_ID)
                                    , moUtility.GetDBPassword(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_PASSWORD), moDatabase.uDirectory.sPDFDirectory_nm, true, true);

                moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\" + modCommonUtility.GetDummyCheckFileName(ref moDatabase), GlobalVar.goUtility.GetCustomReportFolder(ref moDatabase));

                if (SetReportSelection() == false)
                {
                    return false;
                }

                if (moReport.PrintReport(ref moDatabase, GlobalVar.goConstant.PRINT_TO_PDF, ref pdf_file) == false)
                {
                    FormShowMessage(moReport.GetErrorMessage());
                    return false;
                }

                if (moUtility.IsEmpty(pdf_file) || modWebReportUtility.PDFFound(pdf_file) == false)
                {
                    FormShowMessage(User.Language.oMessage.REPORT_SERVER_NOT_RESPONDING);
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(pdf_file, true));

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormPrint)");
            }

            return return_value;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormSave()
        {
            bool return_value = false;
            clsRecordset cur_set;

            try
            {
                if (FormOpenDatabase() == false)                     // Has to come before FormCheck()
                {
                    return false;
                }
                else if (FormCheck() == false)                       // Check if data is ok to save.
                {
                    return false;
                }

                moPage.sPreviousKey_id = Header.txtKey_id;
                cur_set = new clsRecordset(ref moDatabase);

                if (modFormUtility.RecordOpen(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sRestrictionClause, moPage.sTable_nm, moPage.sKeyField_nm) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormCheckConcurrency(cur_set) == false)
                {
                    return false;
                }
                else if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormPreSave(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveHeader(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveExtra(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormPostTransactionRealtime() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (moDatabase.TransactionCommit() == false)
                {
                    FormShowMessage();
                    moDatabase.TransactionRollback();
                    return false;
                }

                FormPostSave();
                    
                return_value = true;

            }
            catch (Exception ex)
            {

                FormShowMessage(ex.Message + " (FormSave)");
                moDatabase.TransactionRollback();

            }

            return return_value;
        }

        private bool FormSaveExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormSaveHeader(clsRecordset cur_set)
        {
            bool return_value = false;
            string sql_str = null;

            try
            {
                if (moPage.bNew_fl)
                {
                    sql_str = "INSERT INTO " + moPage.sTable_nm + " (";
                    sql_str += moPage.sKeyField_nm;
                    sql_str += ",sFund_cd";
                    sql_str += ",iStatus_typ";
                    sql_str += ",iEntry_dt";
                    sql_str += ",sDescription";

                    sql_str += ",sReference";
                    sql_str += ",sJob_cd";
                    sql_str += ",sCashAcct_cd";
                    sql_str += ",sExpenseAcct_cd";
                    sql_str += ",mTransaction_amt";
                    sql_str += ",iExpense_typ";
                    sql_str += ",sEntity_cd";
                    sql_str += ",sService_cd";
                    sql_str += ",sDocument_num";
                    sql_str += ",sTax_cd";
                    sql_str += ",mTax_amt";
                    sql_str += ",iCash_typ";
                    sql_str += ",sEntity_nm";
                    sql_str += ",sAddress1";
                    sql_str += ",sAddress2";
                    sql_str += ",sAddress3";
                    sql_str += ",iOrder_num";

                    sql_str += ",sLastUpdate_id";
                    sql_str += ",dtLastUpdate_dt";
                    sql_str += ") VALUES (";
                    sql_str += " " + moUtility.ToInteger(Header.txtKey_id).ToString();
                    sql_str += ",'" + GlobalVar.goFund.GetSelectedFundCodeToSave(ref moDatabase, Header.cboFund_cd) + "'";
                    sql_str += "," + Header.cboStatus_typ;
                    sql_str += "," + moGeneral.ToNumDate(Header.mskEntry_dt);
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtDescription) + "'";

                    sql_str += ",'" + moUtility.EvalQuote(Header.txtReference) + "'";
                    sql_str += ",'" + Header.cboJob_cd + "'";
                    sql_str += ",'" + Header.cboCashAcct_cd + "'";
                    sql_str += ",'" + Header.cboExpenseAcct_cd + "'";
                    sql_str += "," + moMoney.ToNumMoney(Header.txtTransaction_amt).ToString();
                    sql_str += "," + moUtility.ToInteger(Header.cboExpense_typ).ToString();
                    sql_str += ",'" + Header.txtEntity_cd + "'";
                    sql_str += ",'" + Header.cboService_cd + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtCheck_num) + "'";
                    sql_str += ",'" + Header.cboTax_cd + "'";
                    sql_str += "," + moMoney.ToNumMoney(Header.lblTax_amt).ToString();
                    sql_str += "," + moUtility.ToInteger(Header.cboCash_typ).ToString();
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtPayTo_nm) + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtPayToAddress1) + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtPayToAddress2) + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtPayToAddress3) + "'";
                    sql_str += "," + moUtility.ToInteger(Header.txtOrder_num).ToString();

                    sql_str += ",'" + moDatabase.sUser_cd + "'";
                    sql_str += "," + moDatabase.CreateDatetimeValue(DateTime.Now);
                    sql_str += ")";
                }
                else
                {
                    sql_str = "UPDATE " + moPage.sTable_nm + " SET";
                    sql_str += " sFund_cd = '" + GlobalVar.goFund.GetSelectedFundCodeToSave(ref moDatabase, Header.cboFund_cd) + "'";
                    sql_str += ",iStatus_typ = " + Header.cboStatus_typ;
                    sql_str += ",iEntry_dt = " + moGeneral.ToNumDate(Header.mskEntry_dt);
                    sql_str += ",sDescription = '" + moUtility.EvalQuote(Header.txtDescription) + "'";

                    sql_str += ",sReference = '" + moUtility.EvalQuote(Header.txtReference) + "'";
                    sql_str += ",sJob_cd = '" + Header.cboJob_cd + "'";
                    sql_str += ",sCashAcct_cd = '" + Header.cboCashAcct_cd + "'";
                    sql_str += ",sExpenseAcct_cd = '" + Header.cboExpenseAcct_cd + "'";
                    sql_str += ",mTransaction_amt = " + moMoney.ToNumMoney(Header.txtTransaction_amt).ToString();
                    sql_str += ",iExpense_typ = " + moUtility.ToInteger(Header.cboExpense_typ).ToString();
                    sql_str += ",sEntity_cd = '" + Header.txtEntity_cd + "'";
                    sql_str += ",sService_cd = '" + Header.cboService_cd + "'";
                    sql_str += ",sDocument_num = '" + moUtility.EvalQuote(Header.txtCheck_num) + "'";
                    sql_str += ",sTax_cd = '" + Header.cboTax_cd + "'";
                    sql_str += ",mTax_amt = " + moMoney.ToNumMoney(Header.lblTax_amt).ToString();
                    sql_str += ",iCash_typ = " + moUtility.ToInteger(Header.cboCash_typ).ToString();
                    sql_str += ",sEntity_nm = '" + moUtility.EvalQuote(Header.txtPayTo_nm) + "'";
                    sql_str += ",sAddress1 = '" + moUtility.EvalQuote(Header.txtPayToAddress1) + "'";
                    sql_str += ",sAddress2 = '" + moUtility.EvalQuote(Header.txtPayToAddress2) + "'";
                    sql_str += ",sAddress3 = '" + moUtility.EvalQuote(Header.txtPayToAddress3) + "'";
                    sql_str += ",iOrder_num = " + moUtility.ToInteger(Header.txtOrder_num).ToString();

                    sql_str += ",sLastUpdate_id = '" + moDatabase.sUser_cd + "'";
                    sql_str += ",dtLastUpdate_dt = " + moDatabase.CreateDatetimeValue(DateTime.Now);
                    sql_str += " WHERE " + moPage.sKeyField_nm + " = " + moUtility.ToInteger(Header.txtKey_id).ToString();
                }

                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveHeader)");
            }

            return return_value;
        }

        private bool FormSearch()
        {

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {
            if (FormShowHeader(cur_set) == false)
            {
                return false;
            }
            else if (FormShowExtra(cur_set) == false)
            {
                return false;
            }

            FormReArrangeHeader();

            return true;
        }

        private bool FormShowExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                moPage.Clear();
                moPage.PreserveTimestamp(cur_set);
                moPage.PreserveOriginal(cur_set);
                moPage.bNew_fl = false;

                if (moValidate.IsValidPettyCashAccount(Header.cboCashAcct_cd) && moUtility.ToInteger(Header.cboCash_typ) == GlobalVar.goConstant.CASH_TYPE_NUM)
                {
                    mbCashEnabled_fl = false;
                }
                else
                {
                    mbCashEnabled_fl = true;
                }

                cboExpense_typ_Verified();

                // This is where bReadOnly_fl & bReserved_fl are set according to the nature of the current record.
                //
                moPage.bReserved_fl = (cur_set.iField("iReserved_fl") == GlobalVar.goConstant.FLAG_ON);

                moPage.sPreviousKey_id = Header.txtKey_id;
                Header.Preserve();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowHeader(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                Header.txtKey_id = cur_set.sField(moPage.sKeyField_nm);
                Header.txtDescription = cur_set.sField("sDescription");

                Header.txtReference = cur_set.sField("sReference");
                Header.txtTransaction_amt = moMoney.ToStrMoney((cur_set.mField("mTransaction_amt")));
                Header.txtEntity_cd = cur_set.sField("sEntity_cd");
                Header.txtCheck_num = cur_set.sField("sDocument_num");
                Header.lblTax_amt = moMoney.ToStrMoney(cur_set.mField("mTax_amt"));
                
                Header.cboStatus_typ = cur_set.iField("iStatus_typ").ToString();
                Header.cboJob_cd = cur_set.sField("sJob_cd");
                Header.cboCashAcct_cd = cur_set.sField("sCashAcct_cd");
                Header.cboExpenseAcct_cd = cur_set.sField("sExpenseAcct_cd");
                Header.cboFund_cd = GlobalVar.goFund.GetSelectedFundCodeToDisplay(ref moDatabase, cur_set.sField("sFund_cd"));
                Header.cboExpense_typ = cur_set.iField("iExpense_typ").ToString();
                Header.cboService_cd = cur_set.sField("sService_cd");
                Header.cboTax_cd = cur_set.sField("sTax_cd");
                Header.cboCash_typ = cur_set.iField("iCash_typ").ToString();

                Header.txtPayTo_nm = cur_set.sField("sEntity_nm");
                Header.txtPayToAddress1 = cur_set.sField("sAddress1");
                Header.txtPayToAddress2 = cur_set.sField("sAddress2");
                Header.txtPayToAddress3 = cur_set.sField("sAddress3");

                if (cur_set.iField("iOrder_num") > 0)
                {
                    Header.txtOrder_num = cur_set.iField("iOrder_num").ToString();
                }

                Header.lblStrAmount = moMoney.PrintDollarAmount(moMoney.ToNumMoney(Header.txtTransaction_amt));

                // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
                // Make sure both, dt* and msk*, are sync'ed.
                //
                Header.mskEntry_dt = moGeneral.ToStrDate(cur_set.iField("iEntry_dt"));
                FormSyncDates(false);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowHeader)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowListing()
        {
            string where_clause = "";

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moListing.Show(moDatabase, moPage, where_clause, cboListingBy) == false)
            {
                return false;
            }

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtEntry_dt, ref Header.mskEntry_dt, use_date_picker);

            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moZoom.Caller == "txtEntity_cd")
            {
                if (moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_EMPLOYEE_TYPE_NUM)
                {
                    if (moZoom.Employee(ref moDatabase) == false)
                    {
                        FormShowMessage(null, (moZoom.bShowOptionBar == false));
                        return false;
                    }
                }
                else if (AssetTransaction)
                {
                    if (moZoom.Code(ref moDatabase, "tblFAAsset", "sAsset_nm") == false)
                    {
                        FormShowMessage(null, (moZoom.bShowOptionBar == false));
                        return false;
                    }
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormClear();
                return true;
            }

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
                {
                    return false;
                }
            }

            FormCancel();
            return true;
        }

        private bool btnDelete_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormClear();
                return true;
            }

            if (FormDialog(btnDelete_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_DELETE) == false)
            {
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (FormDelete() == false)
            {
                return false;
            }
            
            FormClear();
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormExit();
                return true;
            }

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }

        private bool btnFirst_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnFirst_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.FIRST_RECORD_TYPE);
        }

        private bool btnLast_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnLast_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.LAST_RECORD_TYPE);
        }

        private bool btnNext_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnNext_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.NEXT_RECORD_TYPE);
        }

        private bool btnPrevious_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnPrevious_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.PREVIOUS_RECORD_TYPE);
        }

        private bool btnSave_Clicked()
        {
            FormPreEvent();

            if (moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.VOID_TRX_NUM)
            {
                if (FormDialog(btnSave_Clicked, 10, User.Language.oMessage.ARE_YOU_SURE_TO_VOID) == false)
                {
                    return false;
                }
            }

            if (moDatabase.bRealTimeMode == false && moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.OPEN_TRX_NUM)        // In realtime mode, no need to ask
            {
                if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.THIS_WILL_POST_TO_GL_NOW + User.Language.oMessage.WOULD_LIKE_PROCEED) == false)
                {
                    return false;
                }
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormSave() == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        private bool btnPrint_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            moPage.bInPrinting_fl = true;

            // Should save/print for the first time only.  When comming back from dialog, need to skip.
            //
            if (Modal.ReturningTo(3000) == false)
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                if (FormCheck() == false)
                {
                    moPage.bInPrinting_fl = false;
                    return false;
                }

                if (FormPrint() == false)
                {
                    return false;
                }
            }

            if (FormDialog(btnPrint_Clicked, 3000, User.Language.oMessage.IS_PRINTED_OK) == false)
            {
                moPage.bInPrinting_fl = false;
                return false;
            }

            if (FormSave() == false)
            {
                moPage.bInPrinting_fl = false;
                return false;
            }

            moPage.bInPrinting_fl = false;
            FormClear();

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewHeader_Clicked()
        {
            FormPreEvent();                                                                           
            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool cmdViewListing_Clicked()
        {
            FormPreEvent();       
            
            if (FormShowListing() == false)
            {
                return false;
            }

            FormSwitchView(moView.LISTING_PAGE_NUM);
            return true;

        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnListingSelect_Clicked(Models.clsListingTransaction.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.IsEmpty(cur_item.Transaction_num))
            {
                return false;
            }

            FormClear();
            Header.txtKey_id = cur_item.Transaction_num;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                code_selected = cur_item.Col_0;

                if (moZoom.Caller == "txtEntity_cd")
                {
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    Header.txtEntity_cd = code_selected;
                    return txtEntity_cd_Changed();
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }
        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool cmdNew_Clicked()
        {
            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            FormClear();

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            // Get the next transaction number.  This would not consume the number.  FormSave() will consume the number.
            //
            Header.txtKey_id = modGeneralUtility.ReadNextTransactionNumber(ref moDatabase, moPage.iTransaction_typ).ToString();

            if (moUtility.ToInteger(Header.txtKey_id) > 0)
            {
                Header.cboStatus_typ = GlobalVar.goConstant.HOLD_TRX_NUM.ToString();
                Header.mskEntry_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                FormSyncDates(false);
            }
            else
            {
                FormShowMessage();
                Header.txtKey_id = "";
            }

            return FormPostEvent();
        }

        private bool txtKey_id_Changed()
        {
            if (Header.txtKey_id == Header.Tag.txtKey_id)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (txtKey_id_Verified() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool dtEntry_dt_Changed()
        {
            if (Header.dtEntry_dt == Header.Tag.dtEntry_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtEntry_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtEntry_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtEntry_dt) == false)
            {
                Header.dtEntry_dt = Header.Tag.dtEntry_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtEntry_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskEntry_dt_Changed()
        {
            if (Header.mskEntry_dt == Header.Tag.mskEntry_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskEntry_dt) == false)
            {
                Header.mskEntry_dt = Header.Tag.mskEntry_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskEntry_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool txtEntity_cd_Changed()
        {
            Header.txtEntity_cd = modCommonUtility.CleanCode(Header.txtEntity_cd);

            if (Header.txtEntity_cd == Header.Tag.txtEntity_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsNonEmpty(Header.txtEntity_cd))
            {
                if (txtEntity_cd_Verified() == false)
                {
                    Header.txtEntity_cd = Header.Tag.txtEntity_cd;
                    return false;
                }
            }

            return FormPostEvent();
        }

        private bool btnZoomOnEntity_cd_Clicked()
        {
            string where_clause = "";

            FormPreEvent();

            if (moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_EMPLOYEE_TYPE_NUM)
            {

                if (moZoom.Init(moPage, "txtEntity_cd", -1, -1, moView.MAIN_PAGE_NUM, "sEmployee_cd", "", where_clause) == false)
                {
                    FormShowMessage("Invalid Zoom.Init() is called.");
                    return false;
                }
            }
            else if (AssetTransaction)
            {

                if (moZoom.Init(moPage, "txtEntity_cd", -1, -1, moView.MAIN_PAGE_NUM, "sAsset_cd", "", where_clause) == false)
                {
                    FormShowMessage("Invalid Zoom.Init() is called.");
                    return false;
                }
            }
            else
            {
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }
        private bool txtTransaction_amt_Changed()
        {
            Header.txtTransaction_amt =moMoney.ToStrMoney(moMoney.ToNumMoney(Header.txtTransaction_amt));

            if (Header.txtTransaction_amt == Header.Tag.txtTransaction_amt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moDatabase.mMaxQuick_amt > 0 && moMoney.ToNumMoney(Header.txtTransaction_amt) > moDatabase.mMaxQuick_amt)
            {
                FormShowMessage(User.Language.oMessage.QUICK_TRANSACTION_AMT_CANNOT_EXCEED + moMoney.ToStrMoney(moDatabase.mMaxQuick_amt));
                Header.txtTransaction_amt = Header.Tag.txtTransaction_amt;
                return false;
            }

            Header.lblStrAmount = moMoney.PrintDollarAmount(moMoney.ToNumMoney(Header.txtTransaction_amt));

            cboTax_cd_Verified();

            return FormPostEvent();
        }

        private bool cboExpense_typ_Clicked()
        {
            if (Header.cboExpense_typ == Header.Tag.cboExpense_typ)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            Header.lblEntity_cd = "";          // DO NOT move this to cboExpense_typ_Verified() because cboExpense_typ_Verified() is also called from FormShowExtra()
            Header.txtEntity_cd = "";

            if (cboExpense_typ_Verified() == false)
            {
                Header.cboExpense_typ = Header.Tag.cboExpense_typ;
                return false;
            }

            return FormPostEvent();
        }

        private bool cboCash_typ_Clicked()
        {
            if (Header.cboCash_typ == Header.Tag.cboCash_typ)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moUtility.ToInteger(Header.cboCash_typ) > 0)
            {
                if (moUtility.IsNonEmpty(Header.cboCashAcct_cd) && moUtility.ToInteger(Header.cboCash_typ) == GlobalVar.goConstant.CHECK_TYPE_NUM)
                {
                    Header.txtCheck_num = moTransactionPayment.GetNextCheckNumber(Header.cboCashAcct_cd, moUtility.ToInteger(Header.cboCash_typ)).ToString();
                }
                else
                {
                    Header.txtCheck_num = "";
                }

                if (moUtility.ToInteger(Header.cboCash_typ) == GlobalVar.goConstant.WIRE_TRANSFER_TYPE_NUM)
                {
                    Header.lblCheck_num = User.Language.oString.STR_EFT_NUM;
                }
                else
                {
                    Header.lblCheck_num = User.Language.oCaption.CHECK_NUMBER;
                }
            }

            return FormPostEvent();
        }

        private bool cboCashAcct_cd_Clicked()
        {
            if (Header.cboCashAcct_cd == Header.Tag.cboCashAcct_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            mbCashEnabled_fl = true;

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moUtility.IsEmpty(Header.cboCashAcct_cd))
            {

            }
            else if (moValidate.IsValidPettyCashAccount(Header.cboCashAcct_cd))
            {
                Header.cboCash_typ = GlobalVar.goConstant.CASH_TYPE_NUM.ToString();
                mbCashEnabled_fl = false;
                Header.txtCheck_num = "";
            }
            else
            {
                if (moValidate.IsValidCheckingAccount(Header.cboCashAcct_cd) && moUtility.ToInteger(Header.cboCash_typ) == GlobalVar.goConstant.CHECK_TYPE_NUM)
                {
                    Header.txtCheck_num = moTransactionPayment.GetNextCheckNumber(Header.cboCashAcct_cd, moUtility.ToInteger(Header.cboCash_typ)).ToString();
                }
                else
                {
                    Header.txtCheck_num = "";
                }
                mbCashEnabled_fl = true;
            }

            return FormPostEvent();
        }

        private bool cboTax_cd_Clicked()
        {
            if (Header.cboTax_cd == Header.Tag.cboTax_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (cboTax_cd_Verified() == false)
            {
                Header.cboTax_cd = Header.Tag.cboTax_cd;
                return false;
            }

            return FormPostEvent();
        }

        private bool txtOrder_num_Changed()
        {
            if (moUtility.ToInteger(Header.txtOrder_num) > 0)
            {
                Header.txtOrder_num = moUtility.ToInteger(Header.txtOrder_num).ToString();
            }
            else
            {
                Header.txtOrder_num = "";
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Verified()
        {
            bool return_value = false;
            clsRecordset cur_set;
            string key_id = "";

            try
            {
                Header.txtKey_id = modCommonUtility.CleanCode(Header.txtKey_id);
                key_id = Header.txtKey_id;

                if (Header.txtKey_id == Header.Tag.txtKey_id)
                {
                    return true;
                }
                else if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormClear();
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    FormClear();
                    FormShowMessage(User.Language.oMessage.CONNECTION_HAS_FAILED);
                    return false;
                }

                cur_set = new clsRecordset(ref moDatabase);

                if (FormFindRecord(ref cur_set))
                {
                    FormShow(cur_set);
                }
                else
                {
                    cmdNew_Clicked();
                    FormShowMessage(key_id + User.Language.oMessage.IS_NOT_FOUND);
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtKey_id_Verified)");
            }

            return return_value;
        }

        private bool txtEntity_cd_Verified()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_EMPLOYEE_TYPE_NUM)
            {
                if (!moValidate.IsValidEmployeeCode(Header.txtEntity_cd))
                {
                    FormShowMessage(Header.txtEntity_cd + User.Language.oMessage.IS_INVALID);
                    Header.txtEntity_cd = "";
                    FormSetFocus(Header.txtEntity_cd);
                    return false;
                }
                Header.txtPayTo_nm = moValidate.oRecordset.sField("sEmployee_nm");
                Header.txtPayToAddress1 = moValidate.oRecordset.sField("sAddress1");
                Header.txtPayToAddress2 = moValidate.oRecordset.sField("sAddress2");
                Header.txtPayToAddress3 = moValidate.oRecordset.sField("sCity") + ", " + moValidate.oRecordset.sField("sState") + " " + moValidate.oRecordset.sField("sZipCode");
            }
            else if (AssetTransaction)
            {
                if (!moValidate.IsValidAssetCode(Header.txtEntity_cd))
                {
                    FormShowMessage(Header.txtEntity_cd + User.Language.oMessage.IS_INVALID);
                    Header.txtEntity_cd = "";
                    FormSetFocus(Header.txtEntity_cd);
                    return false;
                }
                if (moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_FA_PAYMENT_TYPE_NUM)
                {
                    if (moValidate.oRecordset.sField("sPaymentAcct_cd") != "")
                    {
                        Header.cboExpenseAcct_cd = moValidate.oRecordset.sField("sPaymentAcct_cd");
                    }
                    if (moValidate.oRecordset.mField("mLeasePayment_amt") >= moDatabase.mSmallestMoney_amt) // Repect the payment on the asset master.
                    {
                        Header.txtTransaction_amt = moMoney.ToStrMoney(moValidate.oRecordset.mField("mLeasePayment_amt"));
                        txtTransaction_amt_Changed();
                    }
                    Header.txtPayTo_nm = moValidate.oRecordset.sField("sLeaseCompany_nm");
                    Header.txtPayToAddress1 = moValidate.oRecordset.sField("sLeaseCompanyAddress1");
                    Header.txtPayToAddress2 = moValidate.oRecordset.sField("sLeaseCompanyAddress2");
                }
                else if (moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_FA_INSURANCE_TYPE_NUM)
                {
                    if (moValidate.oRecordset.sField("sInsuranceExpenseAcct_cd") != "")
                    {
                        Header.cboExpenseAcct_cd = moValidate.oRecordset.sField("sInsuranceExpenseAcct_cd");
                    }
                    if (moValidate.oRecordset.mField("mPremium_amt") >= moDatabase.mSmallestMoney_amt) // Repect the payment on the asset master.
                    {
                        Header.txtTransaction_amt = moMoney.ToStrMoney(moValidate.oRecordset.mField("mPremium_amt"));
                        txtTransaction_amt_Changed();
                    }
                    Header.txtPayTo_nm = moValidate.oRecordset.sField("sInsuranceCompany_nm");
                    Header.txtPayToAddress1 = moValidate.oRecordset.sField("sInsuranceCompanyAddress1");
                    Header.txtPayToAddress2 = moValidate.oRecordset.sField("sInsuranceCompanyAddress2");
                }
                else if (moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_FA_SERVICE_TYPE_NUM)
                {
                    if (moValidate.oRecordset.sField("sExpenseAcct_cd") != "")
                    {
                        Header.cboExpenseAcct_cd = moValidate.oRecordset.sField("sExpenseAcct_cd");
                    }
                    if (moValidate.oRecordset.mField("mServiceContract_amt") >= moDatabase.mSmallestMoney_amt) // Repect the payment on the asset master.
                    {
                        Header.txtTransaction_amt = moMoney.ToStrMoney(moValidate.oRecordset.mField("mServiceContract_amt"));
                        txtTransaction_amt_Changed();
                    }
                    Header.txtPayTo_nm = moValidate.oRecordset.sField("sServiceCompany_nm");
                    Header.txtPayToAddress1 = moValidate.oRecordset.sField("sServiceCompanyAddress1");
                    Header.txtPayToAddress2 = moValidate.oRecordset.sField("sServiceCompanyAddress2");
                }
            }
            else
            {
                Header.txtEntity_cd = "";
            }

            return true;
        }
        private bool cboExpense_typ_Verified()
        {
            mbEntityVisible_fl = false;
            mbServiceVisible_fl = false;

            if (moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_EMPLOYEE_TYPE_NUM)
            {
                Header.lblEntity_cd = User.Language.oString.STR_EMPLOYEE;
                mbEntityVisible_fl = true;
            }
            else if (AssetTransaction)
            {
                Header.lblEntity_cd = User.Language.oString.STR_ASSET_CODE;
                mbEntityVisible_fl = true;
                if (moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_FA_SERVICE_TYPE_NUM)
                {
                    mbServiceVisible_fl = true;
                }
            }

            return true;
        }

        private bool cboTax_cd_Verified()
        {
            decimal amt_trx = 0;
            decimal amt_tax = 0;
            decimal tax_pc = 0;

            Header.lblTax_amt = "";

            if (moUtility.IsEmpty(Header.cboTax_cd))
            {
                Header.lblTax_amt = "";
            }
            else if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moValidate.IsValidVATCode(Header.cboTax_cd, false))
            {
                tax_pc = -(Math.Abs(moValidate.oRecordset.mField("fTotalTax_pc"))); // could be a negative for tax included. We will treat all as included here.
            }

            if (moMoney.ToNumMoney(Header.txtTransaction_amt) >= moDatabase.mSmallestMoney_amt)
            {
                if (moGeneral.CalcSalesTax(moMoney.ToNumMoney(Header.txtTransaction_amt), tax_pc, ref amt_tax, true)) // moDatabase.bIncludeTaxInTaxableTotal_fl) Then
                {
                    Header.lblTax_amt = moMoney.ToStrMoney(amt_tax);
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

        private bool SetReportSelection()
        {
            bool return_value = false;
			bool save_status = false;
            string sql_str = "";
            string[,] payment_info = null;
            long report_id = moUtility.GetReportProcessID();

            clsPrintCheck o_check = new clsPrintCheck(ref moDatabase);

            GlobalVar.goUtility.ResizeDim(ref payment_info, 6, 2);

            try
            {
                payment_info[0, 0] = GlobalVar.goConstant.QE_JOURNAL;
                payment_info[1, 0] = Header.txtKey_id;
                payment_info[2, 0] = Header.txtTransaction_amt;
                payment_info[3, 0] = ""; // Discount taken.

                save_status = moDatabase.uSecurity.bPrintDetailsOnCheckStub_fl;
                moDatabase.uSecurity.bPrintDetailsOnCheckStub_fl = false;

                o_check.ClearReport(0);
                o_check.InitCheck(report_id.ToString(), report_id);

                if (o_check.PrintOneBRCheck(ref payment_info, Header.mskEntry_dt, Header.txtCheck_num, Header.txtTransaction_amt, Header.lblStrAmount, Header.txtPayTo_nm
                    , Header.txtPayToAddress1, Header.txtPayToAddress2, Header.txtPayToAddress3, Header.cboCashAcct_cd, Header.txtDescription) == false)
                {
                    FormShowMessage();
				    moDatabase.uSecurity.bPrintDetailsOnCheckStub_fl = save_status;
                    return false;
                }

                sql_str = "{tblTMPReport.iReport_num} = " + report_id.ToString();
                sql_str += " AND {tblTMPReport.sLastUpdate_id} = '" + moDatabase.sUser_cd + "'";
                moReport.SetSelectionFormula(modCommonReportUtility.CleanupFormula(sql_str));

                moDatabase.uSecurity.bPrintDetailsOnCheckStub_fl = save_status;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SetReportSelection)");
            }

            return return_value;
        }

    }
}
