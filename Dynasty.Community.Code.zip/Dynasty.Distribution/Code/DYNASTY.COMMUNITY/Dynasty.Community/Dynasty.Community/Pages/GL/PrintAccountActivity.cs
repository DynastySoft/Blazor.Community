﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Report;
using Dynasty.Local;
using System.Collections;

namespace Dynasty.ASP.Pages.GL
{
    public partial class PrintAccountActivity
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<MarkUp> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;
        private Models.clsSpreadsheet moSpreadsheet;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsReportViewer moReport;

        private List<Models.clsCombobox> ReportTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> AccountGroupList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> InterestGroupList = new List<Models.clsCombobox>();

        private const int DAILY_ACTIVITY = 1; // Should match the values of optActivityType
        private const int PERIODIC_ACTIVITY = 2;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader
        {
            public string cboReport_typ = "";
            public string cboAccountGroup_typ = "";
            public string cboInterestGroup_cd = "";
            public string txtAccount_cd = "";

            public bool optSummary_fl = true;
            public bool chkSummarize_fl = false;

            // Datetime component is not very user-friendly, yet, as of VS2019.
            // For better understanding this, read the comment on bUseDatePicker_fl in clsUser.
            //
            public string mskApplyFrom_dt = "";
            public string mskApplyThru_dt = "";

            public string mskEntryFrom_dt = "";
            public string mskEntryThru_dt = "";

            public DateTime? dtApplyFrom_dt = null;
            public DateTime? dtApplyThru_dt = null;

            public DateTime? dtEntryFrom_dt = null;
            public DateTime? dtEntryThru_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag
            {
                public string cboReport_typ = "";
                public string txtAccount_cd = "";

                public string mskApplyFrom_dt = "";
                public string mskApplyThru_dt = "";

                public string mskEntryFrom_dt = "";
                public string mskEntryThru_dt = "";

                public DateTime? dtApplyFrom_dt = null;
                public DateTime? dtApplyThru_dt = null;

                public DateTime? dtEntryFrom_dt = null;
                public DateTime? dtEntryThru_dt = null;

            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()
            {
                Tag.cboReport_typ = cboReport_typ;
                Tag.txtAccount_cd = txtAccount_cd;

                Tag.mskApplyFrom_dt = mskApplyFrom_dt;
                Tag.mskApplyThru_dt = mskApplyThru_dt;

                Tag.mskEntryFrom_dt = mskEntryFrom_dt;
                Tag.mskEntryThru_dt = mskEntryThru_dt;

                Tag.dtApplyFrom_dt = dtApplyFrom_dt;
                Tag.dtApplyThru_dt = dtApplyThru_dt;

                Tag.dtEntryFrom_dt = dtEntryFrom_dt;
                Tag.dtEntryThru_dt = dtEntryThru_dt;

            }
        }
        private clsHeader Header = new clsHeader();


        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        private void FormDownloadFile(string file_name)                                // Download a file.
        {
            Models.JSFunction.DownloadFile(JSRuntime, moPage, User.sWebSite, file_name);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            bool return_value = false;
            int date_to_use = 0;
            string sql_str = null;
            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            if (FormCheckSecurity() == false)
            {
                return false;
            }

            try
            {
                FormSyncDates(User.bUseDatePicker_fl);

                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                if (Header.cboReport_typ == User.Language.oCaption.PERIODIC)
                {
                    Header.mskEntryFrom_dt = "";
                    Header.mskEntryThru_dt = "";
                    FormSyncDates(false);

                    if (moUtility.IsEmpty(Header.mskApplyFrom_dt) && moUtility.IsEmpty(Header.mskApplyThru_dt)) 
                    {
                        Header.mskApplyFrom_dt = moGeneral.ToStrDate(moDatabase.iCurPeriodBegin_dt);
                        Header.mskApplyThru_dt = moGeneral.ToStrDate(moDatabase.iCurPeriodEnd_dt);
                    }

                    FormSyncDates(false);
                }

                // Need to enter at least one condition.
                //
                if (moUtility.IsEmpty(Header.mskApplyFrom_dt) && moUtility.IsEmpty(Header.mskApplyThru_dt) && moUtility.IsEmpty(Header.mskEntryFrom_dt) && moUtility.IsEmpty(Header.mskEntryThru_dt))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_A_VALID_SELECTION_RANGE);
                    if (User.bUseDatePicker_fl)
                    {
                        FormSetFocus("dtApplyFrom_dt");
                    }
                    else
                    {
                        FormSetFocus("mskApplyFrom_dt");
                    }
                    return false;
                }

                if (Header.cboReport_typ == User.Language.oCaption.PERIODIC)
                {
                    // By now, we know one of these two are valid.
                    //
                    if (moGeneral.ToNumDate(Header.mskApplyFrom_dt) > 0)
                    {
                        date_to_use = moGeneral.ToNumDate(Header.mskApplyFrom_dt);
                    }
                    else
                    {
                        date_to_use = moGeneral.ToNumDate(Header.mskApplyThru_dt);
                    }

                    sql_str = "SELECT * FROM tblGLPeriodDet WHERE " + date_to_use.ToString() + " BETWEEN iPeriodBegin_dt AND iPeriodEnd_dt";

                    if (!cur_set.CreateSnapshot(sql_str))
                    {
                        FormShowMessage();
                        return false;
                    }
                    else if (cur_set.EOF())
                    {
                        FormShowMessage(moGeneral.ToStrDate(date_to_use) + User.Language.oMessage.IS_INVALID);
                        Header.mskApplyFrom_dt = "";
                        Header.mskApplyThru_dt = "";
                        FormSetFocus("mskApplyFrom_dt");
                        FormSyncDates(false);
                        return false;
                    }

                    Header.mskApplyFrom_dt = moGeneral.ToStrDate(cur_set.iField("iPeriodBegin_dt"));
                    Header.mskApplyThru_dt = moGeneral.ToStrDate(cur_set.iField("iPeriodEnd_dt"));
                    FormSyncDates(false);
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheck)");
            }

            return return_value;
        }

        private bool FormCheckSecurity()
        {
            return modSecurity.SystemPrintSecurityCheck(ref moDatabase, moPage);
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {

            return true;
        }

        private bool FormClearMessage()
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moReport = new clsReportViewer();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.GLMENU_NAME;
            moPage.Title = User.Language.oCaption.PRINT_ACTIVITY + " - " + User.Language.oCaption.GL;
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormPostEvent()
        {

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback

            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;
            ArrayList item_list = new ArrayList();

            try
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                item_list.Add(new clsComboBoxItem(User.Language.oCaption.DAILY, User.Language.oCaption.DAILY));
                item_list.Add(new clsComboBoxItem(User.Language.oCaption.PERIODIC, User.Language.oCaption.PERIODIC));
                modWebLoadUtility.LoadComboBox(ref ReportTypeList, item_list);
                Header.cboReport_typ = User.Language.oCaption.DAILY;

                modLoadUtility.LoadAccountSubGroup(ref moDatabase, ref AccountGroupList);
                modLoadUtility.LoadGLInterestGroup(ref moDatabase, ref InterestGroupList);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }


        private bool FormPrint(int print_type)
        {
            bool return_value = false;
            string pdf_file = "";
            clsFile o_file = new clsFile();
            DateTime stime_started = DateTime.Now;
            clsMail o_mail = new clsMail(ref moDatabase);

            try
            {
                if (FormOpenDatabase() == false)        // Do not delete this
                {
                    return false;
                }

                moReport.InitReport(moUtility.GetServerName(ref moDatabase), moUtility.GetDatabaseName(ref moDatabase), moUtility.GetDBUser(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_ID)
                                    , moUtility.GetDBPassword(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_PASSWORD), moDatabase.uDirectory.sPDFDirectory_nm, true, true);


                if (modCommonReportUtility.SetCompanyInReport(ref moDatabase, "PrintAccountActivity", ref moReport) == false)
                {
                    FormShowMessage();
                    return false;
                }
                if (SetReportSelection() == false)
                {
                    return false;
                }
                if (SetReportFile() == false)
                {
                    return false;
                }

                if (moReport.PrintReport(ref moDatabase, print_type, ref pdf_file) == false)
                {
                    FormShowMessage(moReport.GetErrorMessage());
                    return false;
                }

                if (moUtility.IsEmpty(pdf_file) || modWebReportUtility.PDFFound(pdf_file) == false)
                {
                    FormShowMessage(User.Language.oMessage.REPORT_SERVER_NOT_RESPONDING);
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(pdf_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormPrint)");
            }

            return return_value;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtApplyFrom_dt, ref Header.mskApplyFrom_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtEntryFrom_dt, ref Header.mskEntryFrom_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtApplyThru_dt, ref Header.mskApplyThru_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtEntryThru_dt, ref Header.mskEntryThru_dt, use_date_picker);

            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moZoom.Caller == "txtAccount_cd")
            {
                if (moZoom.Account(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }


        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }


        private bool btnPrint_Clicked()
        {
            FormPreEvent();

            if (FormCheck())
            {
                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
                FormPrint(GlobalVar.goConstant.PRINT_TO_PDF);
            }

            return FormPostEvent();
        }

        private bool btnExcel_Clicked()
        {
            FormPreEvent();

            if (FormCheck())
            {
                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
                FormPrint(GlobalVar.goConstant.PRINT_TO_EXCEL);
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewHeader_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                if (moUtility.IsEmpty(cur_item.Col_0))
                {
                    return false;
                }

                code_selected = cur_item.Col_0;

                if (moZoom.Caller == "txtAccount_cd")
                {
                    Header.txtAccount_cd = code_selected;
                    txtAccount_cd_Changed();
                }

                FormSwitchView(moZoom.iView);
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }

        private bool btnZoomOnAccount_cd_Clicked()
        {
            FormPreEvent();

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtAccount_cd", -1, -1, moView.MAIN_PAGE_NUM, "sAccount_cd", "") == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);   // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        private bool txtAccount_cd_Changed()
        {
            Header.txtAccount_cd = modCommonUtility.CleanCode(Header.txtAccount_cd);

            if (Header.txtAccount_cd == Header.Tag.txtAccount_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsNonEmpty(Header.txtAccount_cd))
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                if (moValidate.IsValidActualAcctCode(Header.txtAccount_cd) == false)
                {
                    FormShowMessage(Header.txtAccount_cd + User.Language.oMessage.IS_INVALID);
                    Header.txtAccount_cd = Header.Tag.txtAccount_cd;
                }
            }

            return FormPostEvent();
        }

        private bool dtApplyFrom_dt_Changed()
        {
            if (Header.dtApplyFrom_dt == Header.Tag.dtApplyFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtApplyFrom_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtApplyFrom_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtApplyFrom_dt) == false)
            {
                Header.dtApplyFrom_dt = Header.Tag.dtApplyFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtApplyFrom_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskApplyFrom_dt_Changed()
        {
            if (Header.mskApplyFrom_dt == Header.Tag.mskApplyFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskApplyFrom_dt) == false)
            {
                Header.mskApplyFrom_dt = Header.Tag.mskApplyFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskApplyFrom_dt");
                return false;
            }

            return FormPostEvent();
        }
        private bool dtApplyThru_dt_Changed()
        {
            if (Header.dtApplyThru_dt == Header.Tag.dtApplyThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtApplyThru_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtApplyThru_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtApplyThru_dt) == false)
            {
                Header.dtApplyThru_dt = Header.Tag.dtApplyThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtApplyThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskApplyThru_dt_Changed()
        {
            if (Header.mskApplyThru_dt == Header.Tag.mskApplyThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskApplyThru_dt) == false)
            {
                Header.mskApplyThru_dt = Header.Tag.mskApplyThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskApplyThru_dt");
                return false;
            }

            return FormPostEvent();
        }


        private bool dtEntryFrom_dt_Changed()
        {
            if (Header.dtEntryFrom_dt == Header.Tag.dtEntryFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtEntryFrom_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtEntryFrom_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtEntryFrom_dt) == false)
            {
                Header.dtEntryFrom_dt = Header.Tag.dtEntryFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtEntryFrom_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskEntryFrom_dt_Changed()
        {
            if (Header.mskEntryFrom_dt == Header.Tag.mskEntryFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskEntryFrom_dt) == false)
            {
                Header.mskEntryFrom_dt = Header.Tag.mskEntryFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskEntryFrom_dt");
                return false;
            }

            return FormPostEvent();
        }
        private bool dtEntryThru_dt_Changed()
        {
            if (Header.dtEntryThru_dt == Header.Tag.dtEntryThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtEntryThru_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtEntryThru_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtEntryThru_dt) == false)
            {
                Header.dtEntryThru_dt = Header.Tag.dtEntryThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtEntryThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskEntryThru_dt_Changed()
        {
            if (Header.mskEntryThru_dt == Header.Tag.mskEntryThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskEntryThru_dt) == false)
            {
                Header.mskEntryThru_dt = Header.Tag.mskEntryThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskEntryThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

        private bool SetReportSelection()
        {
            bool return_value = false;
			long process_id = 0;
            string sql_str = "";
            string tmp = "";
            int group_from = 0;
            int group_thru = 0;
            int j = 0;

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                sql_str = "";
                if (moUtility.IsNonEmpty(Header.mskEntryFrom_dt))
                {
                    sql_str += " AND ({tblGLTransactionDet.iEntry_dt} >= " + moGeneral.ToNumDate(Header.mskEntryFrom_dt).ToString() + ")";
                }
                if (moUtility.IsNonEmpty(Header.mskEntryThru_dt))
                {
                    sql_str += " AND ({tblGLTransactionDet.iEntry_dt} <= " + moGeneral.ToNumDate(Header.mskEntryThru_dt).ToString() + ")";
                }
                if (moUtility.IsNonEmpty(Header.mskApplyFrom_dt))
                {
                    sql_str += " AND ({tblGLTransactionDet.iApply_dt} >= " + moGeneral.ToNumDate(Header.mskApplyFrom_dt).ToString() + ")";
                }
                if (moUtility.IsNonEmpty(Header.mskApplyThru_dt))
                {
                    sql_str += " AND ({tblGLTransactionDet.iApply_dt} <= " + moGeneral.ToNumDate(Header.mskApplyThru_dt).ToString() + ")";
                }

                sql_str += " AND ({tblGLTransactionDet.iStatus_typ} <> " + GlobalVar.goConstant.VOID_TRX_NUM.ToString() + ")";
                sql_str += " AND ({tblGLAccount.iSummary_typ} = " + GlobalVar.goGLConstant.ACTUAL_TYPE_NUM.ToString() + ")";

                if (moUtility.IsNonEmpty(Header.cboAccountGroup_typ))
                {
                    if ((moUtility.ToInteger(Header.cboAccountGroup_typ) % 100) > 0)
                    {
                        group_from = moUtility.ToInteger(Header.cboAccountGroup_typ);
                        group_thru = group_from;
                    }
                    else
                    {
                        group_from = moUtility.ToInteger(Header.cboAccountGroup_typ);
                        group_thru = group_from + 99;
                    }
                    sql_str += " AND ({tblGLAccount.iGroup_typ} >= " + group_from + ")";
                    sql_str += " AND ({tblGLAccount.iGroup_typ} <= " + group_thru + ")";
                }

                if (moUtility.IsNonEmpty(Header.cboInterestGroup_cd))
                {
                    if (!cur_set.CreateSnapshot("SELECT sAccount_cd FROM tblGLInterestGroupDet WHERE sInterestGroup_cd = '" + Header.cboInterestGroup_cd + "'"))
                    {
                        FormShowMessage();
                        return false;
                    }
                    else if (cur_set.RecordCount() > 0)
                    {
                        sql_str += " AND (";
                        for (j = 0; j < cur_set.RecordCount(); j++)
                        {
                            sql_str += moUtility.IIf(j > 0, " OR ", "") + " ({tblGLAccount.sAccount_cd} = '" + cur_set.sField("sAccount_cd") + "')";
                            cur_set.MoveNext();
                        }
                        sql_str += " )";
                    }
                }

                if (moUtility.IsNonEmpty(Header.txtAccount_cd))
                {
                    sql_str += " AND ({tblGLAccount.sAccount_cd} = '" + Header.txtAccount_cd + "')";
                }

                if (Header.cboReport_typ == User.Language.oCaption.PERIODIC)
                {
                    sql_str += " AND ({tblGLBalance.iPeriodEnd_dt} = " + moGeneral.ToNumDate(Header.mskApplyThru_dt) + ")";
                }

                moReport.SetSelectionFormula(modCommonReportUtility.CleanupFormula(sql_str));

                moReport.SetFormula("min_apply_date", Header.mskApplyFrom_dt);
                moReport.SetFormula("max_apply_date", Header.mskApplyThru_dt);
                moReport.SetFormula("min_entry_date", Header.mskEntryFrom_dt);
                moReport.SetFormula("max_entry_date", Header.mskEntryThru_dt);
                moReport.SetFormula("acct_range", Header.txtAccount_cd);
                moReport.SetFormula("time", moUtility.SFormat(DateTime.Now, "hh:mm tt"));

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SetReportSelection)");
            }

            return return_value;
        }

        private bool SetReportFile()
        {
            bool return_value = false;

            try
            {
                if (Header.cboReport_typ == User.Language.oCaption.DAILY) 
                {
                    if (Header.optSummary_fl)
                    {
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "402as.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                    }
                    else
                    {
                        if (Header.chkSummarize_fl)
                        {
                            moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "403a.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                        }
                        else
                        {
                            moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "401a.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                        }
                    }
                }
                else
                {
                    if (Header.optSummary_fl)
                    {
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "405pas.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                    }
                    else
                    {
                        if (Header.chkSummarize_fl)
                        {
                            moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "406pa.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                        }
                        else
                        {
                            moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "404pa.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                        }
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SetReportFile)");
            }

            return return_value;
        }
    }
}
