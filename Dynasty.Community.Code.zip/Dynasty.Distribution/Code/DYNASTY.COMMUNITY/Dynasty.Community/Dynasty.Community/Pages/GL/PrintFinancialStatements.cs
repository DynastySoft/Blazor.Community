﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Report;
using Dynasty.Local;
using System.Collections;

namespace Dynasty.ASP.Pages.GL
{
    public partial class PrintFinancialStatements
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<MarkUp> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;
        private Models.clsSpreadsheet moSpreadsheet;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsReportViewer moReport;

        private List<Models.clsCombobox> StatementTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> PeriodTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> PeriodEndList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> FiscalYearList = new List<Models.clsCombobox>();

        private List<Models.clsCombobox> SegmentList1 = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> SegmentList2 = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> SegmentList3 = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> SegmentList4 = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> SegmentList5 = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> SegmentList6 = new List<Models.clsCombobox>();

		private bool HidePeriodType
        {
			get { return (Header.cboStatement_typ == GlobalVar.goGLConstant.STATEMENT_BALANCE_SHEET); }
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader
        {
            public string cboStatement_typ = "";
            public string cboPeriod_typ = "";
            public string cboPeriodEnd_dt = "";
            public string cboFiscalYear = "";
            public string cboSegment1 = "";
            public string cboSegment2 = "";
            public string cboSegment3 = "";
            public string cboSegment4 = "";
            public string cboSegment5 = "";
            public string cboSegment6 = "";

            public string labSegment1 = "";
            public string labSegment2 = "";
            public string labSegment3 = "";
            public string labSegment4 = "";
            public string labSegment5 = "";
            public string labSegment6 = "";

            public string labPeriodEnd_dt = "";

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag
            {
                public string cboStatement_typ = "";
                public string cboPeriod_typ = "";
                public string cboPeriodEnd_dt = "";
                public string cboFiscalYear = "";
                public string cboSegment1 = "";
                public string cboSegment2 = "";
                public string cboSegment3 = "";
                public string cboSegment4 = "";
                public string cboSegment5 = "";
                public string cboSegment6 = "";
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()
            {
                Tag.cboStatement_typ = cboStatement_typ;
                Tag.cboPeriod_typ = cboPeriod_typ;
                Tag.cboPeriodEnd_dt = cboPeriodEnd_dt;
                Tag.cboFiscalYear = cboFiscalYear;
                Tag.cboSegment1 = cboSegment1;
                Tag.cboSegment2 = cboSegment2;
                Tag.cboSegment3 = cboSegment3;
                Tag.cboSegment4 = cboSegment4;
                Tag.cboSegment5 = cboSegment5;
                Tag.cboSegment6 = cboSegment6;
            }
        }
        private clsHeader Header = new clsHeader();


        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }

            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        private void FormDownloadFile(string file_name)                                // Download a file.
        {
            Models.JSFunction.DownloadFile(JSRuntime, moPage, User.sWebSite, file_name);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            bool return_value = false;
            bool segment_exists = false;

            if (FormCheckSecurity() == false)
            {
                return false;
            }

            try
            {
				if (moUtility.IsEmpty(Header.cboStatement_typ))
				{
					FormShowMessage(User.Language.oMessage.PLEASE_ENTER + " " + User.Language.oCaption.STATEMENT_TYPE);
					FormSetFocus("cboStatement_typ");
					return false;
				}
				else if (moUtility.IsEmpty(Header.cboFiscalYear))
				{
					FormShowMessage(User.Language.oMessage.PLEASE_ENTER + " " + User.Language.oCaption.REPORT_YEAR);
					FormSetFocus("cboFiscalYear");
					return false;
				}
				else if ((HidePeriodType == false) && moUtility.IsEmpty(Header.cboPeriod_typ))
				{
					FormShowMessage(User.Language.oMessage.PLEASE_ENTER + " " + User.Language.oCaption.PERIOD_TYPE);
					FormSetFocus("cboPeriod_typ");
					return false;
				}
				else if (moUtility.IsEmpty(Header.cboPeriodEnd_dt))
				{
					FormShowMessage(User.Language.oMessage.PLEASE_ENTER + " " + User.Language.oCaption.PERIOD);
					FormSetFocus("cboPeriodEnd_dt");
					return false;
				}

				segment_exists = false;

				if (segment_exists && moUtility.IsEmpty(Header.cboSegment6))
				{
					FormShowMessage(User.Language.oMessage.PLEASE_ENTER + " " + Header.labSegment6);
					FormSetFocus("cboSegment6");
					return false;
				}
				else if (moUtility.IsNonEmpty(Header.cboSegment6))
				{
					segment_exists = true;
				}

				if (segment_exists && moUtility.IsEmpty(Header.cboSegment5))
				{
					FormShowMessage(User.Language.oMessage.PLEASE_ENTER + " " + Header.labSegment5);
					FormSetFocus("cboSegment5");
					return false;
				}
				else if (moUtility.IsNonEmpty(Header.cboSegment5))
				{
					segment_exists = true;
				}

				if (segment_exists && moUtility.IsEmpty(Header.cboSegment4))
				{
					FormShowMessage(User.Language.oMessage.PLEASE_ENTER + " " + Header.labSegment4);
					FormSetFocus("cboSegment4");
					return false;
				}
				else if (moUtility.IsNonEmpty(Header.cboSegment4))
				{
					segment_exists = true;
				}

				if (segment_exists && moUtility.IsEmpty(Header.cboSegment3))
				{
					FormShowMessage(User.Language.oMessage.PLEASE_ENTER + " " + Header.labSegment3);
					FormSetFocus("cboSegment3");
					return false;
				}
				else if (moUtility.IsNonEmpty(Header.cboSegment3))
				{
					segment_exists = true;
				}

				if (segment_exists && moUtility.IsEmpty(Header.cboSegment2))
				{
					FormShowMessage(User.Language.oMessage.PLEASE_ENTER + " " + Header.labSegment2);
					FormSetFocus("cboSegment2");
					return false;
				}
				else if (moUtility.IsNonEmpty(Header.cboSegment2))
				{
					segment_exists = true;
				}

				if (segment_exists && moUtility.IsEmpty(Header.cboSegment1))
				{
					FormShowMessage(User.Language.oMessage.PLEASE_ENTER + " " + Header.labSegment1);
					FormSetFocus("cboSegment1");
					return false;
				}
				else if (moUtility.IsNonEmpty(Header.cboSegment1))
				{
					segment_exists = true;
				}

				return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheck)");
            }

            return return_value;
        }

        private bool FormCheckSecurity()
        {
            return modSecurity.SystemPrintSecurityCheck(ref moDatabase, moPage);
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {

            return true;
        }

        private bool FormClearMessage()
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moReport = new clsReportViewer();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.GLMENU_NAME;
            moPage.Title = User.Language.oCaption.PRINT_FINANCIAL_STATEMENTS;
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

			Header.labPeriodEnd_dt = User.Language.oCaption.PERIOD;

			Modal.Release();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormPostEvent()
        {

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback

            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;
            ArrayList item_list = new ArrayList();

            try
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                modLoadUtility.LoadFinancialStatements(ref StatementTypeList, moDatabase.CommunityVersion);
                modLoadUtility.LoadIncomeStatement(ref PeriodTypeList, true);
                modLoadUtility.LoadFiscalYear(ref moDatabase, ref FiscalYearList);
                
                LoadPeriod();

                modLoadUtility.LoadSegmentOptions(ref moDatabase, ref SegmentList1, ref SegmentList2, ref SegmentList3, ref SegmentList4, ref SegmentList5, ref SegmentList6
                    , ref Header.labSegment1, ref Header.labSegment2, ref Header.labSegment3, ref Header.labSegment4, ref Header.labSegment5, ref Header.labSegment6);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }


        private bool FormPrint(int print_type)
        {
            bool return_value = false;
            string pdf_file = "";
            clsFile o_file = new clsFile();
            DateTime stime_started = DateTime.Now;
            clsMail o_mail = new clsMail(ref moDatabase);

            try
            {
                if (FormOpenDatabase() == false)        // Do not delete this
                {
                    return false;
                }

                moReport.InitReport(moUtility.GetServerName(ref moDatabase), moUtility.GetDatabaseName(ref moDatabase), moUtility.GetDBUser(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_ID)
                                    , moUtility.GetDBPassword(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_PASSWORD), moDatabase.uDirectory.sPDFDirectory_nm, true, true);


                if (modCommonReportUtility.SetCompanyInReport(ref moDatabase, "frmPrintFinancialReports", ref moReport) == false)
                {
                    FormShowMessage();
                    return false;
                }
                if (SetReportSelection() == false)
                {
                    return false;
                }

                if (moReport.PrintReport(ref moDatabase, print_type, ref pdf_file) == false)
                {
                    FormShowMessage(moReport.GetErrorMessage());
                    return false;
                }

                if (moUtility.IsEmpty(pdf_file) || modWebReportUtility.PDFFound(pdf_file) == false)
                {
                    FormShowMessage(User.Language.oMessage.REPORT_SERVER_NOT_RESPONDING);
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(pdf_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormPrint)");
            }

            return return_value;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moZoom.Caller == "txtAccountFrom_cd" || moZoom.Caller == "txtAccountThru_cd")
            {
                if (moZoom.Account(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }


        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }


        private bool btnPrint_Clicked()
        {
            FormPreEvent();

            if (FormCheck())
            {
                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
                FormPrint(GlobalVar.goConstant.PRINT_TO_PDF);
            }

            return FormPostEvent();
        }

        private bool btnExcel_Clicked()
        {
            FormPreEvent();

            if (FormCheck())
            {
                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
                FormPrint(GlobalVar.goConstant.PRINT_TO_EXCEL);
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewHeader_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                if (moUtility.IsEmpty(cur_item.Col_0))
                {
                    return false;
                }

                code_selected = cur_item.Col_0;

                FormSwitchView(moZoom.iView);
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }

        private bool btnZoomOnFrom_cd_Clicked()
        {
            FormPreEvent();

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtAccountFrom_cd", -1, -1, moView.MAIN_PAGE_NUM, "sAccount_cd", "") == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);   // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return true;
        }

        private bool btnZoomOnThru_cd_Clicked()
        {
            FormPreEvent();

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtAccountThru_cd", -1, -1, moView.MAIN_PAGE_NUM, "sAccount_cd", "") == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);   // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool cboStatement_typ_Clicked()
        {
			if (Header.cboStatement_typ == Header.Tag.cboStatement_typ)
			{
				return true;
			}

			FormPreEvent();

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            cboStatement_typ_Verified();

			return FormPostEvent();
        }

        private bool cboFiscalYear_Clicked()
        {
			if (Header.cboFiscalYear == Header.Tag.cboFiscalYear)
            {
				return true;
            }

			FormPreEvent();

			if (FormOpenDatabase() == false)
            {
                return false;
            }

            LoadPeriod();

			Header.cboPeriodEnd_dt = "";        // Do not delete this

			return FormPostEvent();
        }

        private bool cboPeriod_typ_Clicked()
        {
			if (Header.cboPeriod_typ == Header.Tag.cboPeriod_typ)
			{
				return true;
			}

			FormPreEvent();

			if (FormOpenDatabase() == false)
            {
                return false;
            }

            LoadPeriod();

			Header.cboPeriodEnd_dt = "";        // Do not delete this

			return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        private bool cboStatement_typ_Verified()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.cboStatement_typ))
                {
                    return true;
                }

                //labCashFlowMessage.Visible = Header.cboStatement_typ == GlobalVar.goGLConstant.STATEMENT_CASH_FLOW;

                if (Header.cboStatement_typ == GlobalVar.goGLConstant.STATEMENT_BALANCE_SHEET)
                {
                    Header.labPeriodEnd_dt = User.Language.oString.STR_AS_OF;
                }
                else
                {
                    Header.labPeriodEnd_dt = User.Language.oString.STR_PERIOD;
                }

                if (moUtility.IsEmpty(Header.cboFiscalYear))
                {
                    Header.cboFiscalYear = moDatabase.sCurFiscalYear;
                }

                LoadPeriod();

                PeriodTypeList.Clear();

				if (Header.cboStatement_typ == GlobalVar.goGLConstant.STATEMENT_INCOME)
                {
                    modLoadUtility.LoadIncomeStatement(ref PeriodTypeList, true);
                }
                else
                {
                    modLoadUtility.LoadIncomeStatement(ref PeriodTypeList, false);
                }

                Header.cboPeriod_typ = GlobalVar.goConstant.YEAR_TYPE.ToString();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (Header.cboStatement_typ_Verified)");
            }

            return return_value;
        }

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

        private bool SetReportSelection()
        {
            bool return_value = false;
			long process_id = 0;
            string sql_str = "";

            try
            {
                process_id = moUtility.GetReportProcessID();


                if (Header.cboStatement_typ == GlobalVar.goGLConstant.STATEMENT_INCOME)
                {
                    if (!SetSelectionForIncomeStatement())
                    {
                        return false;
                    }
                }
                else if (Header.cboStatement_typ == GlobalVar.goGLConstant.STATEMENT_CASH_FLOW)
                {
                    if (!SetSelectionForCashFlow())
                    {
                        return false;
                    }
                }
                else if (Header.cboStatement_typ == GlobalVar.goGLConstant.STATEMENT_BALANCE_SHEET)
				{
                    if (!SetSelectionForBalanceSheet())
                    {
                        return false;
                    }
                }
                else if (Header.cboStatement_typ == GlobalVar.goGLConstant.STATEMENT_COMPARATIVE_INCOME)
                {
                    if (!SetSelectionForComparativeIncomeStatement())
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SetReportSelection)");
            }

            return return_value;
        }

		private bool SetSelectionForIncomeStatement()
		{

			bool return_value = false;
			string sql_str = null;
			string segment = null;
			string segment_clause = null;
			string file_name = null;
			string period_begin = null;
			long process_id = 0;
			bool segment_fl = false;
			bool small_chart_fl = false;
			clsRecordset cur_set = new clsRecordset(ref moDatabase);
			clsFinancials o_finacials = new clsFinancials();

			try
			{

				process_id = moUtility.GetReportProcessID();

				segment_fl = false;
				if (moUtility.IsNonEmpty(Header.cboSegment1) || moUtility.IsNonEmpty(Header.cboSegment2) || moUtility.IsNonEmpty(Header.cboSegment3) || moUtility.IsNonEmpty(Header.cboSegment4) 
					|| moUtility.IsNonEmpty(Header.cboSegment5) || moUtility.IsNonEmpty(Header.cboSegment6))
				{
					segment_fl = true;
				}

				// The regular I/S & B/S reports expects all actual accounts on level 2 or lower(meaning larger number).
				// We do not expect any actual accounts on level 1.
				// If there is, we need to do some extra work for those accounts.
				//
				sql_str = " SELECT COUNT(iAcctLevel) AS iCount";
				sql_str += " FROM tblGLAccount";
				sql_str += " WHERE iGroup_typ >= 4000";
				sql_str += " AND iGroup_typ < 6000";
				sql_str += " AND iAcctLevel = 1";
				sql_str += " AND iSummary_typ = " + GlobalVar.goGLConstant.ACTUAL_TYPE_NUM;
				if (!cur_set.CreateSnapshot(sql_str))
				{
					if (moDatabase.IsErrorFound()) // IsErrorFound() will preserve the messages if exist. 5/22/2016
					{
						FormShowMessage();
					}
					return return_value;
				}
				small_chart_fl = (cur_set.iField("iCount") > 0);

				segment = "";
				segment_clause = "";

				if (small_chart_fl || segment_fl)
				{

					if (!o_finacials.CreateSegmentedFinancials(ref moDatabase, true, ref segment, process_id, Header.cboSegment1, Header.cboSegment2, Header.cboSegment3, Header.cboSegment4
						, Header.cboSegment5, Header.cboSegment6))
					{
						return return_value;
					}

				}

				modGeneralUtility.RunEvents();

				sql_str = "{tblGLBalance.sFiscalYear} = '" + Header.cboFiscalYear + "'";

				if (moUtility.ToInteger(Header.cboPeriod_typ) == GlobalVar.goConstant.MONTH_TYPE)
				{
					sql_str += " AND Abs({tblGLBalance.mPeriodNet_amt}) >= " + moDatabase.mSmallestMoney_amt.ToString();
				}
				else if (moUtility.ToInteger(Header.cboPeriod_typ) == GlobalVar.goConstant.QUARTER_TYPE)
				{
					sql_str += " AND Abs({tblGLBalance.mQuarterNet_amt}) >= " + moDatabase.mSmallestMoney_amt.ToString();
				}
				else
				{
					sql_str += " AND Abs({tblGLBalance.mYearNet_amt}) >= " + moDatabase.mSmallestMoney_amt.ToString();
				}
				sql_str += " AND {tblGLAccount.iGroup_typ} >= 4000";
				sql_str += " AND {tblGLAccount.iGroup_typ} < 6000";
				sql_str += " AND {tblGLBalance.iPeriodEnd_dt} = " + Header.cboPeriodEnd_dt;
				sql_str += " AND {tblGLAccount.iAcctLevel} = 1";
				if (small_chart_fl || segment_fl)
				{
					sql_str += " AND {tblComparativeBalance.iProcess_id} = " + process_id.ToString();
					sql_str += " AND {tblComparativeBalance.sLastUpdate_id} = '" + moDatabase.sUser_cd + "'";
				}

				moReport.SetSelectionFormula(modCommonReportUtility.CleanupFormula(sql_str));

				moReport.SetFormula("monthly_type", GlobalVar.goConstant.MONTH_TYPE.ToString(), "");
				moReport.SetFormula("quarterly_type", GlobalVar.goConstant.QUARTER_TYPE.ToString(), "");
				moReport.SetFormula("yearly_type", GlobalVar.goConstant.YEAR_TYPE.ToString(), "");

				period_begin = Header.cboPeriodEnd_dt;
				if (moUtility.ToInteger(Header.cboPeriod_typ) == GlobalVar.goConstant.MONTH_TYPE)
				{
					period_begin = moUtility.SLeft(period_begin, 6) + "01";
				}
				else if (moUtility.ToInteger(Header.cboPeriod_typ) == GlobalVar.goConstant.QUARTER_TYPE)
				{
					period_begin = moUtility.SLeft(period_begin, 4) + moUtility.SRight("0" + (moUtility.ToValue(moUtility.SMid(period_begin, 5, 2)) - 2).ToString(), 2) + "01";
				}
				else
				{
					period_begin = moUtility.SLeft(period_begin, 4) + "0101";
				}
				period_begin = moGeneral.ToStrDate(moUtility.ToInteger(period_begin));

				moReport.SetFormula("min_date", period_begin);
				moReport.SetFormula("max_date", moGeneral.ToStrDate(moUtility.ToInteger(Header.cboPeriodEnd_dt)));
				moReport.SetFormula("report_type", Header.cboPeriod_typ, "");
				moReport.SetFormula("time", moUtility.SFormat(DateTime.Now, "hh:mm tt"));
				moReport.SetFormula("pc_code", moUtility.IIf(moUtility.IsEmpty(segment), "None", segment).ToString());

				if (moUtility.ToInteger(Header.cboPeriod_typ) == GlobalVar.goConstant.MTD_YTD_TYPE)
				{
					file_name = moUtility.IIf(small_chart_fl || segment_fl, "510isseg.rpt", "509is.rpt");
				}
				else
				{
					file_name = moUtility.IIf(small_chart_fl || segment_fl, "507isseg.rpt", "507is.rpt");
				}

				moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + file_name, moUtility.GetCustomReportFolder(ref moDatabase));

				return_value = true;
			}
			catch (Exception ex)
			{
				FormShowMessage(ex.Message + "(SetSelectionForIncomeStatement)");
			}

			return return_value;
		}

		private bool SetSelectionForCashFlow()
		{

			bool return_value = false;
			string sql_str = null;
			string segment = null;
			string segment_clause = null;
			string period_begin = null;
			long process_id = 0;
			bool segment_fl = false;
			bool small_chart_fl = false;
			clsRecordset cur_set = new clsRecordset(ref moDatabase);
			decimal ce_amount = 0M;

			try
			{

				segment_fl = false;

				if (moUtility.IsNonEmpty(Header.cboSegment1) || moUtility.IsNonEmpty(Header.cboSegment2) || moUtility.IsNonEmpty(Header.cboSegment3) || moUtility.IsNonEmpty(Header.cboSegment4) 
					|| moUtility.IsNonEmpty(Header.cboSegment5) || moUtility.IsNonEmpty(Header.cboSegment6))
				{
					segment_fl = true;
				}

				segment_clause = "";
				segment = "";

				if (moUtility.IsNonEmpty(Header.cboSegment1))
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment1 = '" + Header.cboSegment1 + "'";
					segment += " " + Header.cboSegment1;
				}
				else
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment1 = '" + GlobalVar.goConstant.FOR_ALL + "'";
				}
				if (moUtility.IsNonEmpty(Header.cboSegment2))
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment2 = '" + Header.cboSegment2 + "'";
					segment += " " + Header.cboSegment2;
				}
				else
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment2 = '" + GlobalVar.goConstant.FOR_ALL + "'";
				}
				if (moUtility.IsNonEmpty(Header.cboSegment3))
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment3 = '" + Header.cboSegment3 + "'";
					segment += " " + Header.cboSegment3;
				}
				else
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment3 = '" + GlobalVar.goConstant.FOR_ALL + "'";
				}
				if (moUtility.IsNonEmpty(Header.cboSegment4))
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment4 = '" + Header.cboSegment4 + "'";
					segment += " " + Header.cboSegment4;
				}
				else
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment4 = '" + GlobalVar.goConstant.FOR_ALL + "'";
				}
				if (moUtility.IsNonEmpty(Header.cboSegment5))
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment5 = '" + Header.cboSegment5 + "'";
					segment += " " + Header.cboSegment5;
				}
				else
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment5 = '" + GlobalVar.goConstant.FOR_ALL + "'";
				}
				if (moUtility.IsNonEmpty(Header.cboSegment6))
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment6 = '" + Header.cboSegment6 + "'";
					segment += " " + Header.cboSegment6;
				}
				else
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment6 = '" + GlobalVar.goConstant.FOR_ALL + "'";
				}

				segment = moUtility.STrim(segment);
				process_id = moUtility.GetReportProcessID();

				if (!moDatabase.ExecuteSQL("DELETE FROM tblComparativeBalance WHERE sLastUpdate_id = '" + moDatabase.sUser_cd + "' AND iProcess_id <= " + process_id.ToString()))
				{
					if (moDatabase.IsErrorFound()) // IsErrorFound() will preserve the messages if exist. 5/22/2016
					{
						FormShowMessage();
					}
					return return_value;
				}

				modGeneralUtility.RunEvents();

				sql_str = "INSERT INTO tblComparativeBalance(sAccount_cd, iGroup_typ, iAcctLevel, iProcess_id, sLastUpdate_id, sAccount_nm, iCFSPrimary_id)";
				sql_str += " SELECT a.sAccount_cd, a.iGroup_typ, a.iAcctLevel, " + process_id.ToString() + ", '" + moDatabase.sUser_cd + "', a.sDescription, a.iCFSPrimary_id";
				if (segment_fl)
				{
					sql_str += " FROM tblGLAccount a LEFT JOIN tblGLSegmentedAccount s ON a.sAccount_cd = s.sAccount_cd";
				}
				else
				{
					sql_str += " FROM tblGLAccount a";
				}
				sql_str += " WHERE a.iCFSPrimary_id > 0";

				if (segment_fl) // Segment will dominate
				{
					sql_str += " AND " + segment_clause;
				}
				if (!moDatabase.ExecuteSQL(sql_str))
				{
					if (moDatabase.IsErrorFound()) // IsErrorFound() will preserve the messages if exist. 5/22/2016
					{
						FormShowMessage();
					}
					return return_value;
				}

				modGeneralUtility.RunEvents();

				// To delay Crystal Report for seconds because, sometimes, it gets data before it is created.
				//
				if (GlobalVar.goConstant.DB_ACCESS_TYPE == moDatabase.CurrentDatabaseType())
				{
					modGeneralUtility.WaitFor(3);
				}

				modGeneralUtility.RunEvents();

				sql_str = "SELECT b.* FROM tblGLBalance b INNER JOIN tblGLAccount a ON b.sAccount_cd = a.sAccount_cd";
				sql_str += " WHERE b.sFiscalYear = '" + Header.cboFiscalYear + "'";

				sql_str += " AND b.iPeriodEnd_dt = " + Header.cboPeriodEnd_dt;
				sql_str += " AND (a.iGroup_typ = " + GlobalVar.goGLConstant.CURRENT_EARNING_NUM.ToString() + " AND a.iAcctLevel = 1)";
				if (!cur_set.CreateSnapshot(sql_str))
				{
					if (moDatabase.IsErrorFound()) // IsErrorFound() will preserve the messages if exist. 5/22/2016
					{
						FormShowMessage();
					}
					return return_value;
				}
				else if (cur_set.EOF())
				{
					FormShowMessage(User.Language.oMessage.EARNING_IS_NOT_SETUP);
					return return_value;
				}

				sql_str = "{tblGLBalance.sFiscalYear} = '" + Header.cboFiscalYear + "'";

				if (moUtility.ToInteger(Header.cboPeriod_typ) == GlobalVar.goConstant.MONTH_TYPE)
				{
					sql_str += " AND Abs({tblGLBalance.mPeriodNet_amt}) >= " + moDatabase.mSmallestMoney_amt.ToString();
					ce_amount = cur_set.mField("mPeriodNet_amt");
				}
				else if (moUtility.ToInteger(Header.cboPeriod_typ) == GlobalVar.goConstant.QUARTER_TYPE)
				{
					sql_str += " AND Abs({tblGLBalance.mQuarterNet_amt}) >= " + moDatabase.mSmallestMoney_amt.ToString();
					ce_amount = cur_set.mField("mQuarterNet_amt");
				}
				else
				{
					sql_str += " AND Abs({tblGLBalance.mYearNet_amt}) >= " + moDatabase.mSmallestMoney_amt.ToString();
					ce_amount = cur_set.mField("mYearNet_amt");
				}
				//sql_str &= " AND {tblGLAccount.iCFSPrimary_id} > 0"
				sql_str += " AND {tblGLBalance.iPeriodEnd_dt} = " + Header.cboPeriodEnd_dt;
				sql_str += " AND {tblComparativeBalance.iProcess_id} = " + process_id.ToString();
				sql_str += " AND {tblComparativeBalance.sLastUpdate_id} = '" + moDatabase.sUser_cd + "'";

				moReport.SetSelectionFormula(modCommonReportUtility.CleanupFormula(sql_str));

				moReport.SetFormula("ce_amount", ce_amount.ToString(), "");
				moReport.SetFormula("monthly_type", GlobalVar.goConstant.MONTH_TYPE.ToString(), "");
				moReport.SetFormula("quarterly_type", GlobalVar.goConstant.QUARTER_TYPE.ToString(), "");
				moReport.SetFormula("yearly_type", GlobalVar.goConstant.YEAR_TYPE.ToString(), "");
				moReport.SetFormula("last_group_id_for_cash", GlobalVar.goGLConstant.CASH_REGISTER_CASH_NUM.ToString(), "");

				period_begin = Header.cboPeriodEnd_dt;
				if (moUtility.ToInteger(Header.cboPeriod_typ) == GlobalVar.goConstant.MONTH_TYPE)
				{
					period_begin = moUtility.SLeft(period_begin, 6) + "01";
				}
				else if (moUtility.ToInteger(Header.cboPeriod_typ) == GlobalVar.goConstant.QUARTER_TYPE)
				{
					period_begin = moUtility.SLeft(period_begin, 4) + moUtility.SRight("0" + (moUtility.ToValue(moUtility.SMid(period_begin, 5, 2)) - 2).ToString(), 2) + "01";
				}
				else
				{
					period_begin = moUtility.SLeft(period_begin, 4) + "0101";
				}
				period_begin = moGeneral.ToStrDate(moUtility.ToInteger(period_begin));

				moReport.SetFormula("min_date", period_begin);
				moReport.SetFormula("max_date", moGeneral.ToStrDate(moUtility.ToInteger(Header.cboPeriodEnd_dt)));
				moReport.SetFormula("report_type", Header.cboPeriod_typ, "");
				moReport.SetFormula("time", moUtility.SFormat(DateTime.Now, "hh:mm tt"));
				moReport.SetFormula("pc_code", moUtility.IIf(moUtility.IsEmpty(segment), "None", segment).ToString());
				moReport.SetFormula("operating_activity_num", GlobalVar.goGLConstant.CF_OPERATING_ACTIVITY_NUM.ToString());
				moReport.SetFormula("financing_activity_num", GlobalVar.goGLConstant.CF_FINANCING_ACTIVITY_NUM.ToString());
				moReport.SetFormula("investing_activity_num", GlobalVar.goGLConstant.CF_INVESTING_ACTIVITY_NUM.ToString());

				moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "511cf.rpt", moUtility.GetCustomReportFolder(ref moDatabase));

				return_value = true;
			}
			catch (Exception ex)
			{
				FormShowMessage(ex.Message + "(SetSelectionForCashFlow)");
			}

			return return_value;
		}

		private bool SetSelectionForBalanceSheet()
		{

			bool return_value = false;
			string sql_str = null;
			string segment = null;
			string segment_clause = null;
			string period_begin = null;
			long process_id = 0;
			bool segment_fl = false;
			bool small_chart_fl = false;
			clsRecordset cur_set = new clsRecordset(ref moDatabase);
			clsFinancials o_finacials = new clsFinancials();

			try
			{

				segment_fl = false;
				if (moUtility.IsNonEmpty(Header.cboSegment1) || moUtility.IsNonEmpty(Header.cboSegment2) || moUtility.IsNonEmpty(Header.cboSegment3) || moUtility.IsNonEmpty(Header.cboSegment4) 
					|| moUtility.IsNonEmpty(Header.cboSegment5) || moUtility.IsNonEmpty(Header.cboSegment6))
				{
					segment_fl = true;
				}

				// The regular I/S & B/S reports expects all actual accounts on level 2 or lower(meaning larger number).
				// We do not expect any actual accounts on level 1.
				// If there is, we need to do some extra work for those accounts.
				//
				sql_str = " SELECT COUNT(iAcctLevel) AS iCount";
				sql_str += " FROM tblGLAccount";
				sql_str += " WHERE iGroup_typ >= 1000";
				sql_str += " AND iGroup_typ < 4000";
				sql_str += " AND iAcctLevel = 1";
				sql_str += " AND iSummary_typ = " + GlobalVar.goGLConstant.ACTUAL_TYPE_NUM;
				if (!cur_set.CreateSnapshot(sql_str))
				{
					if (moDatabase.IsErrorFound()) // IsErrorFound() will preserve the messages if exist. 5/22/2016
					{
						FormShowMessage();
					}
					return return_value;
				}
				small_chart_fl = (cur_set.iField("iCount") > 0);
				process_id = moUtility.GetReportProcessID();

				segment = "";
				segment_clause = "";

				if (small_chart_fl || segment_fl)
				{

					if (!o_finacials.CreateSegmentedFinancials(ref moDatabase, false, ref segment, process_id, Header.cboSegment1, Header.cboSegment2, Header.cboSegment3, Header.cboSegment4
						, Header.cboSegment5, Header.cboSegment6))
					{
						if (moDatabase.IsErrorFound()) // IsErrorFound() will preserve the messages if exist. 5/22/2016
						{
							FormShowMessage();
						}
						return return_value;
					}

				}

				modGeneralUtility.RunEvents();

				sql_str = "{tblGLBalance.sFiscalYear} = '" + Header.cboFiscalYear + "'";

				sql_str += " AND Abs({tblGLBalance.mBalance_amt}) >= " + moDatabase.mSmallestMoney_amt.ToString();
				sql_str += " AND {tblGLAccount.iGroup_typ} >= 1000";
				sql_str += " AND {tblGLAccount.iGroup_typ} < 4000";
				sql_str += " AND {tblGLBalance.iPeriodEnd_dt} = " + Header.cboPeriodEnd_dt;
				sql_str += " AND {tblGLAccount.iAcctLevel} = 1";
				if (small_chart_fl || segment_fl)
				{
					sql_str += " AND {tblComparativeBalance.iProcess_id} = " + process_id.ToString();
					sql_str += " AND {tblComparativeBalance.sLastUpdate_id} = '" + moDatabase.sUser_cd + "'";
				}

				moReport.SetSelectionFormula(modCommonReportUtility.CleanupFormula(sql_str));

				moReport.SetFormula("monthly_type", GlobalVar.goConstant.MONTH_TYPE.ToString(), "");
				moReport.SetFormula("quarterly_type", GlobalVar.goConstant.QUARTER_TYPE.ToString(), "");
				moReport.SetFormula("yearly_type", GlobalVar.goConstant.YEAR_TYPE.ToString(), "");

				moReport.SetFormula("max_date", moGeneral.ToStrDate(moUtility.ToInteger(Header.cboPeriodEnd_dt)));
				moReport.SetFormula("report_type", GlobalVar.goConstant.YEAR_TYPE.ToString(), "");
				moReport.SetFormula("time", moUtility.SFormat(DateTime.Now, "hh:mm tt"));
				moReport.SetFormula("pc_code", moUtility.IIf(moUtility.IsEmpty(segment), "None", segment).ToString());

				moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + moUtility.IIf(small_chart_fl || segment_fl, "508bsseg.rpt", "508bs.rpt"), moUtility.GetCustomReportFolder(ref moDatabase));

				return_value = true;
			}
			catch (Exception ex)
			{
				FormShowMessage(ex.Message + "(SetSelectionForBalanceSheet)");
			}

			return return_value;
		}

		private bool SetSelectionForComparativeIncomeStatement()
		{

			bool return_value = false;
			string sql_str = null;
			string segment = null;
			string segment_clause = null;
			string field_name = null;
			string year1 = null;
			string year2 = null;
			string year3 = null;
			string year4 = null;
			string year5 = null;
			string period_begin = null;
			long process_id = 0;
			bool segment_fl = false;
			bool small_chart_fl = false;
			clsRecordset cur_set = new clsRecordset(ref moDatabase);

			try
			{

				segment_fl = false;
				if (moUtility.IsNonEmpty(Header.cboSegment1) || moUtility.IsNonEmpty(Header.cboSegment2) || moUtility.IsNonEmpty(Header.cboSegment3) || moUtility.IsNonEmpty(Header.cboSegment4) 
					|| moUtility.IsNonEmpty(Header.cboSegment5) || moUtility.IsNonEmpty(Header.cboSegment6))
				{
					segment_fl = true;
				}

				if (moUtility.IsNonEmpty(Header.cboSegment1))
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment1 = '" + Header.cboSegment1 + "'";
					segment += " " + Header.cboSegment1;
				}
				else
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment1 = '" + GlobalVar.goConstant.FOR_ALL + "'";
				}
				if (moUtility.IsNonEmpty(Header.cboSegment2))
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment2 = '" + Header.cboSegment2 + "'";
					segment += " " + Header.cboSegment2;
				}
				else
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment2 = '" + GlobalVar.goConstant.FOR_ALL + "'";
				}
				if (moUtility.IsNonEmpty(Header.cboSegment3))
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment3 = '" + Header.cboSegment3 + "'";
					segment += " " + Header.cboSegment3;
				}
				else
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment3 = '" + GlobalVar.goConstant.FOR_ALL + "'";
				}
				if (moUtility.IsNonEmpty(Header.cboSegment4))
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment4 = '" + Header.cboSegment4 + "'";
					segment += " " + Header.cboSegment4;
				}
				else
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment4 = '" + GlobalVar.goConstant.FOR_ALL + "'";
				}
				if (moUtility.IsNonEmpty(Header.cboSegment5))
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment5 = '" + Header.cboSegment5 + "'";
					segment += " " + Header.cboSegment5;
				}
				else
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment5 = '" + GlobalVar.goConstant.FOR_ALL + "'";
				}
				if (moUtility.IsNonEmpty(Header.cboSegment6))
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment6 = '" + Header.cboSegment6 + "'";
					segment += " " + Header.cboSegment6;
				}
				else
				{
					segment_clause += moUtility.IIf(!moUtility.IsEmpty(segment_clause), " AND ", " ").ToString() + "s.sSegment6 = '" + GlobalVar.goConstant.FOR_ALL + "'";
				}
				segment = moUtility.STrim(segment);
				process_id = moUtility.GetReportProcessID();
				if (!moDatabase.ExecuteSQL("DELETE FROM tblComparativeBalance WHERE sLastUpdate_id = '" + moDatabase.sUser_cd + "' AND iProcess_id <= " + process_id.ToString()))
				{
					if (moDatabase.IsErrorFound()) // IsErrorFound() will preserve the messages if exist. 5/22/2016
					{
						FormShowMessage();
					}
					return return_value;
				}
				modGeneralUtility.RunEvents();
				sql_str = "INSERT INTO tblComparativeBalance(sAccount_cd, iGroup_typ, iAcctLevel, iProcess_id, sLastUpdate_id, sAccount_nm)";
				sql_str += " SELECT a.sAccount_cd, (a.iGroup_typ / 100), a.iAcctLevel, " + process_id.ToString() + ", '" + moDatabase.sUser_cd + "', a.sDescription";
				if (segment_fl)
				{
					sql_str += " FROM tblGLAccount a LEFT JOIN tblGLSegmentedAccount s ON a.sAccount_cd = s.sAccount_cd";
				}
				else
				{
					sql_str += " FROM tblGLAccount a";
				}
				sql_str += " WHERE a.iGroup_typ >= 4000";
				sql_str += " AND a.iGroup_typ < 6000";
				if (segment_fl) // Segment will dominate
				{
					sql_str += " AND " + segment_clause;
				}
				else // If there is any actual accounts on level 1, need to add them because they do not have subsidiary accounts on the level 2.
				{
					sql_str += " AND ((a.iAcctLevel = 2 ) OR (a.iAcctLevel = 1 AND a.iSummary_typ = " + GlobalVar.goGLConstant.ACTUAL_TYPE_NUM + "))";
				}
				if (!moDatabase.ExecuteSQL(sql_str))
				{
					if (moDatabase.IsErrorFound()) // IsErrorFound() will preserve the messages if exist. 5/22/2016
					{
						FormShowMessage();
					}
					return return_value;
				}

				modGeneralUtility.RunEvents();

				// In Access SQL, ((a.iGroup_typ / 100) * 100) generates unexpected result so that it has to be seperated into two steps.
				//
				if (!moDatabase.ExecuteSQL("UPDATE tblComparativeBalance SET iGroup_typ = (iGroup_typ * 100) WHERE iProcess_id = " + process_id.ToString() + " AND sLastUpdate_id = '" + moDatabase.sUser_cd + "'"))
				{
					return return_value;
				}

				modGeneralUtility.RunEvents();

				if (moUtility.ToInteger(Header.cboPeriod_typ) == GlobalVar.goConstant.MONTH_TYPE)
				{
					field_name = "mPeriodNet_amt";
				}
				else if (moUtility.ToInteger(Header.cboPeriod_typ) == GlobalVar.goConstant.QUARTER_TYPE)
				{
					field_name = "mQuarterNet_amt";
				}
				else
				{
					field_name = "mYearNet_amt";
				}

				if (!CreateComparativeBalance(field_name, process_id, ref year1, ref year2, ref year3, ref year4, ref year5))
				{
					return return_value;
				}

				// To delay Crystal Report for seconds because, sometimes, it gets data before it is created.
				//
				if (GlobalVar.goConstant.DB_ACCESS_TYPE == moDatabase.CurrentDatabaseType())
				{
					modGeneralUtility.WaitFor(3);
				}

				modGeneralUtility.RunEvents();

				sql_str = " {tblGLAccount.iGroup_typ} >= 4000";
				sql_str += " AND {tblGLAccount.iGroup_typ} < 6000";
				sql_str += " AND {tblGLAccount.iAcctLevel} = 1";
				sql_str += " AND {tblComparativeBalance.iProcess_id} = " + process_id.ToString();
				sql_str += " AND {tblComparativeBalance.sLastUpdate_id} = '" + moDatabase.sUser_cd + "'";

				moReport.SetSelectionFormula(modCommonReportUtility.CleanupFormula(sql_str));

				moReport.SetFormula("monthly_type", GlobalVar.goConstant.MONTH_TYPE.ToString(), "");
				moReport.SetFormula("quarterly_type", GlobalVar.goConstant.QUARTER_TYPE.ToString(), "");
				moReport.SetFormula("yearly_type", GlobalVar.goConstant.YEAR_TYPE.ToString(), "");
				moReport.SetFormula("year", moUtility.IIf(moUtility.IsEmpty(year1), "N/A", year1).ToString(), "'");
				moReport.SetFormula("year1", moUtility.IIf(moUtility.IsEmpty(year2), "N/A", year2).ToString(), "'");
				moReport.SetFormula("year2", moUtility.IIf(moUtility.IsEmpty(year3), "N/A", year3).ToString(), "'");
				moReport.SetFormula("year3", moUtility.IIf(moUtility.IsEmpty(year4), "N/A", year4).ToString(), "'");
				moReport.SetFormula("year4", moUtility.IIf(moUtility.IsEmpty(year5), "N/A", year5).ToString(), "'");

				period_begin = Header.cboPeriodEnd_dt;
				if (moUtility.ToInteger(Header.cboPeriod_typ) == GlobalVar.goConstant.MONTH_TYPE)
				{
					period_begin = moUtility.SLeft(period_begin, 6) + "01";
				}
				else if (moUtility.ToInteger(Header.cboPeriod_typ) == GlobalVar.goConstant.QUARTER_TYPE)
				{
					period_begin = moUtility.SLeft(period_begin, 4) + moUtility.SRight("0" + (moUtility.ToValue(moUtility.SMid(period_begin, 5, 2)) - 2).ToString(), 2) + "01";
				}
				else
				{
					period_begin = moUtility.SLeft(period_begin, 4) + "0101";
				}
				period_begin = moGeneral.ToStrDate(moUtility.ToInteger(period_begin));

				moReport.SetFormula("min_date", period_begin);
				moReport.SetFormula("max_date", moGeneral.ToStrDate(moUtility.ToInteger(Header.cboPeriodEnd_dt)));
				moReport.SetFormula("time", moUtility.SFormat(DateTime.Now, "hh:mm tt"));
				moReport.SetFormula("pc_code", moUtility.IIf(moUtility.IsEmpty(segment), "None", segment).ToString());

				moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "506ci.rpt", moUtility.GetCustomReportFolder(ref moDatabase));

				return_value = true;
			}
			catch (Exception ex)
			{
				FormShowMessage(ex.Message + "(SetSelectionForComparativeIncomeStatement)");
			}

			return return_value;
		}

		public bool CreateComparativeBalance(string field_name, long process_id, ref string year1, ref string year2, ref string year3, ref string year4, ref string year5)
		{

			bool return_value = false;
			string sql_str = null;
			int i = 0;
			int cur_year = 0;
			int base_year = 0;
			int cur_period = 0;
            int year_index = -1;

			try
			{

				base_year = moUtility.ToInteger(Header.cboFiscalYear);
                year_index = modCommonUtility.GetComboIndex(FiscalYearList, Header.cboFiscalYear);

                for (i = year_index; i < FiscalYearList.Count(); i++)
				{

					cur_year = base_year - (i - year_index);
					cur_period = Convert.ToInt32(cur_year * 10000 + moUtility.ToInteger(moUtility.SRight(Header.cboPeriodEnd_dt, 4)));

					if ((i - year_index) == 0)
					{
						year1 = cur_year.ToString();
					}
					else if ((i - year_index) == 1)
					{
						year2 = cur_year.ToString();
					}
					else if ((i - year_index) == 2)
					{
						year3 = cur_year.ToString();
					}
					else if ((i - year_index) == 3)
					{
						year4 = cur_year.ToString();
					}
					else if ((i - year_index) == 4)
					{
						year5 = cur_year.ToString();
					}
					else
					{
						break;
					}

					if (moDatabase.CurrentDatabaseType() == GlobalVar.goConstant.DB_ACCESS_TYPE)
					{
						sql_str = "UPDATE tblComparativeBalance c LEFT JOIN tblGLBalance b ON (c.sAccount_cd = b.sAccount_cd)";
						sql_str += " SET mBalance_amt" + (i - year_index).ToString() + " = b." + field_name;
						sql_str += " WHERE b.sFiscalYear = '" + cur_year.ToString() + "'";
						sql_str += " AND b.iPeriodEnd_dt = " + cur_period.ToString();
						sql_str += " AND c.iProcess_id = " + process_id.ToString();
						sql_str += " AND c.sLastUpdate_id = '" + moDatabase.sUser_cd + "'";

					}
					else if (moDatabase.CurrentDatabaseType() == GlobalVar.goConstant.DB_ORACLE_TYPE)
					{
						sql_str = "UPDATE tblComparativeBalance c";
						sql_str += " SET mBalance_amt" + (i - year_index).ToString() + " = b." + field_name;
						sql_str += " WHERE EXISTS ( SELECT * FROM tblGLBalance b";
						sql_str += " WHERE c.sAccount_cd = b.sAccount_cd";

						sql_str += " AND b.sFiscalYear = '" + cur_year.ToString() + "'";
						sql_str += " AND b.iPeriodEnd_dt = " + cur_period.ToString();
						sql_str += " AND c.iProcess_id = " + process_id.ToString();
						sql_str += " AND c.sLastUpdate_id = '" + moDatabase.sUser_cd + "')";
					}
					else if (moDatabase.CurrentDatabaseType() == GlobalVar.goConstant.DB_MYSQL_TYPE)
					{
						sql_str = "UPDATE tblComparativeBalance c, tblGLBalance b ";
						sql_str += " SET c.mBalance_amt" + (i - year_index).ToString() + " = b." + field_name;
						sql_str += " WHERE c.sAccount_cd = b.sAccount_cd";
						sql_str += " AND b.sFiscalYear = '" + cur_year.ToString() + "'";

						sql_str += " AND b.iPeriodEnd_dt = " + cur_period.ToString();
						sql_str += " AND c.iProcess_id = " + process_id.ToString();
						sql_str += " AND c.sLastUpdate_id = '" + moDatabase.sUser_cd + "'";
					}
					else // SQL Server
					{
						sql_str = "UPDATE tblComparativeBalance ";
						sql_str += " SET mBalance_amt" + (i - year_index).ToString() + " = b." + field_name;
						sql_str += " FROM tblComparativeBalance c ";
						sql_str += " LEFT JOIN tblGLBalance b ON c.sAccount_cd = b.sAccount_cd";
						sql_str += " WHERE b.sFiscalYear = '" + cur_year.ToString() + "'";

						sql_str += " AND b.iPeriodEnd_dt = " + cur_period.ToString();
						sql_str += " AND c.iProcess_id = " + process_id.ToString();
						sql_str += " AND c.sLastUpdate_id = '" + moDatabase.sUser_cd + "'";
					}
					if (!moDatabase.ExecuteSQL(sql_str))
					{
                        FormShowMessage();
                        return return_value;
					}

				}

				return_value = true;
			}
			catch (Exception ex)
			{
				FormShowMessage(ex.Message + "(CreateComparativeBalance)");
			}

			return return_value;
		}


		private bool LoadPeriod()
        {
            bool return_value = false;

            try
            {
                PeriodEndList.Clear();

                if (moUtility.IsEmpty(Header.cboFiscalYear) || moUtility.IsEmpty(Header.cboStatement_typ))
                {
                    return  false;
                }

                if (moUtility.ToInteger(Header.cboPeriod_typ) == GlobalVar.goConstant.QUARTER_TYPE)
                {
                    modLoadUtility.LoadQuarterlyPeriodEnd(ref moDatabase, ref PeriodEndList, Header.cboFiscalYear, true);
                }
                else
                {
                    modLoadUtility.LoadPeriodEnd(ref moDatabase, ref PeriodEndList, Header.cboFiscalYear, false, true);
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (LoadPeriod)");
            }

            return return_value;
        }

    }
}
