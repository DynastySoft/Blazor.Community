﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Report;
using Dynasty.Local;
using System.Collections;

namespace Dynasty.ASP.Pages.GL
{
    public partial class PrintGLJournal
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<MarkUp> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;
        private Models.clsSpreadsheet moDetail;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        private bool QuickExpense
        {
            get
            {
                return (Header.cboTransaction_typ == User.Language.oCaption.QUICK_EXPENSE);
            }
        }
        private bool QuickIncome
        {
            get
            {
                return (Header.cboTransaction_typ == User.Language.oCaption.QUICK_INCOME);
            }
        }

        private bool RegularJournal
        {
            get
            {
                return (QuickExpense == false && QuickIncome == false);
            }
        }

        private bool InternalCost
        {
            get
            {
                return (moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_INTERNAL_PURCHASE_COST_TYPE_NUM
                        || moUtility.ToInteger(Header.cboExpense_typ) == GlobalVar.goGLConstant.QUICK_EXPENSE_INTERNAL_SALE_COST_TYPE_NUM);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsReportViewer moReport;

        private List<Models.clsCombobox> TransactionTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> JournalCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ExpenseTypeList = new List<Models.clsCombobox>();

        private const int ORDER_BY_TRX_NUM = 1;
        private const int ORDER_BY_ENTRY_DATE = 2;
        private const int ORDER_BY_APPLY_DATE = 3;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader
        {
            public string cboTransaction_typ = "";
            public string cboJournal_cd = "";
            public string cboExpense_typ = "";

            public int optSortOrder_typ = ORDER_BY_TRX_NUM;

            public bool chkVoidedOnly_fl = false;
            public bool chkGroupByOrder_fl = false;

            public string txtTransactionFrom_num = "";
            public string txtTransactionThru_num = "";
            public string txtReferenceFrom = "";
            public string txtReferenceThru = "";

            // Datetime component is not very user-friendly, yet, as of VS2019.
            // For better understanding this, read the comment on bUseDatePicker_fl in clsUser.
            //
            public string mskEntryFrom_dt = "";
            public string mskApplyFrom_dt = "";

            public string mskEntryThru_dt = "";
            public string mskApplyThru_dt = "";

            public DateTime? dtEntryFrom_dt = null;
            public DateTime? dtApplyFrom_dt = null;

            public DateTime? dtEntryThru_dt = null;
            public DateTime? dtApplyThru_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag
            {
                public string cboTransaction_typ = "";
                public string cboJournal_cd = "";
                public string cboExpense_typ = "";

                public string txtTransactionFrom_num = "";
                public string txtTransactionThru_num = "";
                public string txtReferenceFrom = "";
                public string txtReferenceThru = "";

                public string mskEntryFrom_dt = "";
                public string mskApplyFrom_dt = "";

                public string mskEntryThru_dt = "";
                public string mskApplyThru_dt = "";

                public DateTime? dtEntryFrom_dt = null;
                public DateTime? dtApplyFrom_dt = null;

                public DateTime? dtEntryThru_dt = null;
                public DateTime? dtApplyThru_dt = null;

            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()
            {
                Tag.cboTransaction_typ = cboTransaction_typ;
                Tag.cboJournal_cd = cboJournal_cd;
                Tag.cboExpense_typ = cboExpense_typ;

                Tag.txtTransactionFrom_num = txtTransactionFrom_num;
                Tag.txtTransactionThru_num = txtTransactionThru_num;
                Tag.txtReferenceFrom = txtReferenceFrom;
                Tag.txtReferenceThru = txtReferenceThru;

                Tag.mskEntryFrom_dt = mskEntryFrom_dt;
                Tag.mskApplyFrom_dt = mskApplyFrom_dt;

                Tag.mskEntryThru_dt = mskEntryThru_dt;
                Tag.mskApplyThru_dt = mskApplyThru_dt;

                Tag.dtEntryFrom_dt = dtEntryFrom_dt;
                Tag.dtApplyFrom_dt = dtApplyFrom_dt;

                Tag.dtEntryThru_dt = dtEntryThru_dt;
                Tag.dtApplyThru_dt = dtApplyThru_dt;

            }
        }
        private clsHeader Header = new clsHeader();


        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        private void FormDownloadFile(string file_name)                                             // Download a file.
        {
            Models.JSFunction.DownloadFile(JSRuntime, moPage, User.sWebSite, file_name);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            bool return_value = false;

            if (FormCheckSecurity() == false)
            {
                return false;
            }

            try
            {
                FormSyncDates(User.bUseDatePicker_fl);

                Header.txtReferenceFrom = moUtility.EvalQuote(Header.txtReferenceFrom);
                Header.txtReferenceThru = moUtility.EvalQuote(Header.txtReferenceThru);

                if (moUtility.IsEmpty(Header.cboTransaction_typ))
                {
                    FormShowMessage(User.Language.oMessage.SELECT_ONE_OPTION_FOR + User.Language.oCaption.TRANSACTION_TYPE);
                    FormSetFocus("cboTransaction_typ");
                    return false;
                }

                if(QuickExpense && moUtility.ToInteger(Header.cboExpense_typ) == 0)
                {
                    FormShowMessage(User.Language.oMessage.SELECT_ONE_OPTION_FOR + User.Language.oCaption.EXPENSE_TYPE);
                    FormSetFocus("cboExpense_typ");
                    return false;
                }

                // Need to enter at least one condition for posted transactions.
                //
                if (moUtility.IsEmpty(Header.mskApplyFrom_dt) && moUtility.IsEmpty(Header.mskApplyThru_dt)
                && moUtility.IsEmpty(Header.mskEntryFrom_dt) && moUtility.IsEmpty(Header.mskEntryThru_dt)
                && moUtility.IsEmpty(Header.txtTransactionFrom_num) && moUtility.IsEmpty(Header.txtTransactionThru_num)
                && moUtility.IsEmpty(Header.txtReferenceFrom) && moUtility.IsEmpty(Header.txtReferenceThru))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_A_VALID_SELECTION_RANGE);

                    if (QuickExpense)
                    {
                        if (User.bUseDatePicker_fl)
                        {
                            FormSetFocus("dtEntryFrom_dt");
                        }
                        else
                        {
                            FormSetFocus("mskEntryFrom_dt");
                        }
                    }
                    else
                    {
                        if (User.bUseDatePicker_fl)
                        {
                            FormSetFocus("dtApplyFrom_dt");
                        }
                        else
                        {
                            FormSetFocus("mskApplyFrom_dt");
                        }
                    }

                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheck)");
            }

            return return_value;
        }

        private bool FormCheckSecurity()
        {
            return modSecurity.SystemPrintSecurityCheck(ref moDatabase, moPage);
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            moDetail.iTotalRows = 1;
            moUtility.ResizeDim(ref moDetail.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, moDetail.iTotalRows - 1);

            return true;
        }

        private bool FormClearMessage()
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();
            moDetail = new Models.clsSpreadsheet();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moReport = new clsReportViewer();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.GLMENU_NAME;
            moPage.Title = User.Language.oCaption.PRINT_GL_JOURNALS;
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormPostEvent()
        {

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback

            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;
            ArrayList item_list = new ArrayList();

            try
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                if (moDatabase.CommunityVersion == false)
                {
                    item_list.Add(new clsComboBoxItem(User.Language.oCaption.UNPOSTED, User.Language.oCaption.UNPOSTED));
                }
                item_list.Add(new clsComboBoxItem(User.Language.oCaption.POSTED, User.Language.oCaption.POSTED));
                item_list.Add(new clsComboBoxItem(User.Language.oCaption.QUICK_EXPENSE, User.Language.oCaption.QUICK_EXPENSE));
                item_list.Add(new clsComboBoxItem(User.Language.oCaption.QUICK_INCOME, User.Language.oCaption.QUICK_INCOME));
                modWebLoadUtility.LoadComboBox(ref TransactionTypeList, item_list);

                modLoadUtility.LoadJournalCode(ref moDatabase, ref JournalCodeList);
                modLoadUtility.LoadQuickExpenseType(ref ExpenseTypeList);

                Header.cboTransaction_typ = User.Language.oCaption.UNPOSTED;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }


        private bool FormPrint(int print_type)
        {
            bool return_value = false;
            string pdf_file = "";
            clsFile o_file = new clsFile();
            DateTime stime_started = DateTime.Now;
            clsMail o_mail = new clsMail(ref moDatabase);

            try
            {
                if (FormOpenDatabase() == false)        // Do not delete this
                {
                    return false;
                }

                moReport.InitReport(moUtility.GetServerName(ref moDatabase), moUtility.GetDatabaseName(ref moDatabase), moUtility.GetDBUser(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_ID)
                                    , moUtility.GetDBPassword(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_PASSWORD), moDatabase.uDirectory.sPDFDirectory_nm, true, true);


                if (modCommonReportUtility.SetCompanyInReport(ref moDatabase, "frmPrintGLJournal", ref moReport) == false)
                {
                    FormShowMessage();
                    return false;
                }
                if (SetReportSelection() == false)
                {
                    return false;
                }

                if (moReport.PrintReport(ref moDatabase, print_type, ref pdf_file) == false)
                {
                    FormShowMessage(moReport.GetErrorMessage());
                    return false;
                }

                if (moUtility.IsEmpty(pdf_file) || modWebReportUtility.PDFFound(pdf_file) == false)
                {
                    FormShowMessage(User.Language.oMessage.REPORT_SERVER_NOT_RESPONDING);
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(pdf_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormPrint)");
            }

            return return_value;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormRecreateDetail()                                                           //  Sync moDetail.Data with moDetail.Grid for the items that do not have event-handler ONLY.
        {
            if (moDetail.RecreateDetail() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateDetailLine(Models.clsSpreadsheet.clsGrid cur_item, int row_num = -1)
        {
            if (moDetail.RecreateDetailLine(cur_item, row_num) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateGrid()                                                             //  Create moDetail.Grid according to moDetail.Data
        {
            if (moDetail.RecreateGrid() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtApplyFrom_dt, ref Header.mskApplyFrom_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtEntryFrom_dt, ref Header.mskEntryFrom_dt, use_date_picker);

            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtApplyThru_dt, ref Header.mskApplyThru_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtEntryThru_dt, ref Header.mskEntryThru_dt, use_date_picker);

            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moZoom.Caller == "txtCustomer_cd")
            {
                if (moZoom.Customer(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }


        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }


        private bool btnPrint_Clicked()
        {
            FormPreEvent();

            if (FormCheck())
            {
                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
                FormPrint(GlobalVar.goConstant.PRINT_TO_PDF);
            }

            return FormPostEvent();
        }

        private bool btnExcel_Clicked()
        {
            FormPreEvent();

            if (FormCheck())
            {
                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
                FormPrint(GlobalVar.goConstant.PRINT_TO_EXCEL);
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        
        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                if (moUtility.IsEmpty(cur_item.Col_0))
                {
                    return false;
                }

                code_selected = cur_item.Col_0;

                FormSwitchView(moZoom.iView);
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool cboTransaction_typ_Clicked()
        {
            if (Header.cboTransaction_typ == Header.Tag.cboTransaction_typ)
            {
                return true;
            }

            if (QuickExpense || QuickIncome)
            {
                Header.optSortOrder_typ = ORDER_BY_TRX_NUM;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            return FormPostEvent();
        }

        private bool dtEntryFrom_dt_Changed()
        {
            if (Header.dtEntryFrom_dt == Header.Tag.dtEntryFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtEntryFrom_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtEntryFrom_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtEntryFrom_dt) == false)
            {
                Header.dtEntryFrom_dt = Header.Tag.dtEntryFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtEntryFrom_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskEntryFrom_dt_Changed()
        {
            if (Header.mskEntryFrom_dt == Header.Tag.mskEntryFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskEntryFrom_dt) == false)
            {
                Header.mskEntryFrom_dt = Header.Tag.mskEntryFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskEntryFrom_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtApplyFrom_dt_Changed()
        {
            if (Header.dtApplyFrom_dt == Header.Tag.dtApplyFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtApplyFrom_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtApplyFrom_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtApplyFrom_dt) == false)
            {
                Header.dtApplyFrom_dt = Header.Tag.dtApplyFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtApplyFrom_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskApplyFrom_dt_Changed()
        {
            if (Header.mskApplyFrom_dt == Header.Tag.mskApplyFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskApplyFrom_dt) == false)
            {
                Header.mskApplyFrom_dt = Header.Tag.mskApplyFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskApplyFrom_dt");
                return false;
            }

            return FormPostEvent();
        }


        private bool dtEntryThru_dt_Changed()
        {
            if (Header.dtEntryThru_dt == Header.Tag.dtEntryThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtEntryThru_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtEntryThru_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtEntryThru_dt) == false)
            {
                Header.dtEntryThru_dt = Header.Tag.dtEntryThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtEntryThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskEntryThru_dt_Changed()
        {
            if (Header.mskEntryThru_dt == Header.Tag.mskEntryThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskEntryThru_dt) == false)
            {
                Header.mskEntryThru_dt = Header.Tag.mskEntryThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskEntryThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtApplyThru_dt_Changed()
        {
            if (Header.dtApplyThru_dt == Header.Tag.dtApplyThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtApplyThru_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtApplyThru_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtApplyThru_dt) == false)
            {
                Header.dtApplyThru_dt = Header.Tag.dtApplyThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtApplyThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskApplyThru_dt_Changed()
        {
            if (Header.mskApplyThru_dt == Header.Tag.mskApplyThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskApplyThru_dt) == false)
            {
                Header.mskApplyThru_dt = Header.Tag.mskApplyThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskApplyThru_dt");
                return false;
            }

            return FormPostEvent();
        }


        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

        private bool SetReportSelection()
        {
            bool return_value = false;
			long process_id = 0;
            string sql_str = "";
            string report_name = "";
            string report_type = "";

            try
            {
                process_id = moUtility.GetReportProcessID();

                if (QuickExpense)
                {
                    SetSelectionForExpense();
                    moReport.SetFormula("expense_title", modCommonUtility.GetComboText(ExpenseTypeList, Header.cboExpense_typ));
                }
                else if (QuickIncome)
                {
                    SetSelectionForIncome();
                    moReport.SetFormula("income_title", User.Language.oCaption.QUICK_INCOME);
                }
                else if (Header.cboTransaction_typ == User.Language.oCaption.UNPOSTED)
                {
                    SetSelectionForUnposted();
                }
                else
                {
                    SetSelectionForPosted();
                }

                moReport.SetFormula("min_apply_date", Header.mskApplyFrom_dt);
                moReport.SetFormula("max_apply_date", Header.mskApplyThru_dt);
                moReport.SetFormula("min_entry_date", Header.mskEntryFrom_dt);
                moReport.SetFormula("max_entry_date", Header.mskEntryThru_dt);
                moReport.SetFormula("min_reference", Header.txtReferenceFrom);
                moReport.SetFormula("max_reference", Header.txtReferenceThru);
                moReport.SetFormula("min_journal_code", Header.cboJournal_cd);
                moReport.SetFormula("max_journal_code", Header.cboJournal_cd);
                moReport.SetFormula("min_trx", Header.txtTransactionFrom_num);
                moReport.SetFormula("max_trx", Header.txtTransactionThru_num);

                moReport.SetFormula("time", moUtility.SFormat(DateTime.Now, "hh:mm tt"));

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SetReportSelection)");
            }

            return return_value;
        }

        private bool SetSelectClause(string table_name, ref string sql_str)
        {
            bool return_value = false;

            try
            {
                // By eliminating the filtering cases, increase the performance.
                //
                if (moUtility.ToInteger(Header.txtTransactionFrom_num) > 0)
                {
                    sql_str += " AND ({" + table_name + ".iTransaction_num} >= " + moUtility.ToInteger(Header.txtTransactionFrom_num).ToString() + ")";
                }
                if (moUtility.ToInteger(Header.txtTransactionThru_num) > 0)
                {
                    sql_str += " AND ({" + table_name + ".iTransaction_num} <= " + moUtility.ToInteger(Header.txtTransactionThru_num).ToString() + ")";
                }
                if (moGeneral.ToNumDate(Header.mskEntryFrom_dt) > 0)
                {
                    sql_str += " AND ({" + table_name + ".iEntry_dt} >= " + moGeneral.ToNumDate(Header.mskEntryFrom_dt).ToString() + ")";
                }
                if (moGeneral.ToNumDate(Header.mskEntryThru_dt) > 0)
                {
                    sql_str += " AND ({" + table_name + ".iEntry_dt} <= " + moGeneral.ToNumDate(Header.mskEntryThru_dt) + ")";
                }
                if (moUtility.IsNonEmpty(Header.txtReferenceFrom))
                {
                    sql_str += " AND ({" + table_name + ".sReference} >= '" + moUtility.EvalQuote(Header.txtReferenceFrom) + "')";
                }
                if (moUtility.IsNonEmpty(Header.txtReferenceThru))
                {
                    sql_str += " AND ({" + table_name + ".sReference} <= '" + moUtility.EvalQuote(Header.txtReferenceThru) + "')";
                }

                if (QuickExpense)
                {
                    sql_str += " AND ({" + table_name + ".iExpense_typ} = " + moUtility.ToInteger(Header.cboExpense_typ).ToString() + ")";
                }
                else
                {
                    if (moGeneral.ToNumDate(Header.mskApplyFrom_dt) > 0)
                    {
                        sql_str += " AND ({" + table_name + ".iApply_dt} >= " + moGeneral.ToNumDate(Header.mskApplyFrom_dt).ToString() + ")";
                    }
                    if (moGeneral.ToNumDate(Header.mskApplyThru_dt) > 0)
                    {
                        sql_str += " AND ({" + table_name + ".iApply_dt} <= " + moGeneral.ToNumDate(Header.mskApplyThru_dt).ToString() + ")";
                    }
                    if (moUtility.IsNonEmpty(Header.cboJournal_cd))
                    {
                        sql_str += " AND ({" + table_name + ".sJournal_cd} = '" + Header.cboJournal_cd + "')";
                    }
                }

                if (Header.chkVoidedOnly_fl)
                {
                    sql_str += " AND ({" + table_name + ".iStatus_typ}=" + GlobalVar.goConstant.VOID_TRX_NUM.ToString() + ") ";
                }
                else
                {
                    sql_str += " AND ({" + table_name + ".iStatus_typ} <> " + GlobalVar.goConstant.VOID_TRX_NUM.ToString() + ") ";
                }

                if (moUtility.IsNonEmpty(modCommonUtility.GetSelectSecurityClause(moDatabase, table_name, true)))
                {
                    sql_str += " AND " + modCommonUtility.GetSelectSecurityClause(moDatabase, table_name, true);
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SetSelectClause)");
            }

            return return_value;
        }

        private bool SetSelectionForExpense()
        {
            bool return_value = false;
            string sql_str = null;

            try
            {
                if (InternalCost && Header.chkGroupByOrder_fl)
                {
                    moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "312no.rpt", GlobalVar.goUtility.GetCustomReportFolder(ref moDatabase));
                }
                else
                {
                    moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "311n.rpt", GlobalVar.goUtility.GetCustomReportFolder(ref moDatabase));
                }

                SetSelectClause("tblGLExpense", ref sql_str);
                moReport.SetSelectionFormula(modCommonReportUtility.CleanupFormula(sql_str));

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SetSelectionForExpense)");
            }

            return return_value;
        }

        private bool SetSelectionForIncome()
        {
            bool return_value = false;
            string sql_str = null;

            try
            {
                moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "313n.rpt", GlobalVar.goUtility.GetCustomReportFolder(ref moDatabase));

                SetSelectClause("tblGLIncome", ref sql_str);
                moReport.SetSelectionFormula(modCommonReportUtility.CleanupFormula(sql_str));

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SetSelectionForIncome)");
            }

            return return_value;
        }

        private bool SetSelectionForPosted()
        {
            bool return_value = false;
            string sql_str = null;

            try
            {
                SetSelectClause("tblGLTransaction", ref sql_str);
                moReport.SetSelectionFormula(modCommonReportUtility.CleanupFormula(sql_str));

                switch (Header.optSortOrder_typ)
                {
                    case ORDER_BY_TRX_NUM: // Sort by trx num
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "301j.rpt", GlobalVar.goUtility.GetCustomReportFolder(ref moDatabase));
                        break;
                    case ORDER_BY_ENTRY_DATE: // Sort by entry date
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "302je.rpt", GlobalVar.goUtility.GetCustomReportFolder(ref moDatabase));
                        break;
                    case ORDER_BY_APPLY_DATE: // Sort by apply date
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "303ja.rpt", GlobalVar.goUtility.GetCustomReportFolder(ref moDatabase));
                        break;
                    default:

                        break;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SetSelectionForPosted)");
            }

            return return_value;
        }

        public bool SetSelectionForUnposted()
        {
            bool return_value = false;
            string sql_str = null;

            try
            {
                SetSelectClause("tblGLTransactionUnposted", ref sql_str);
                moReport.SetSelectionFormula(modCommonReportUtility.CleanupFormula(sql_str));

                switch (Header.optSortOrder_typ)
                {
                    case ORDER_BY_TRX_NUM: // Sort by trx num
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "201u.rpt", GlobalVar.goUtility.GetCustomReportFolder(ref moDatabase));
                        break;
                    case ORDER_BY_ENTRY_DATE: // Sort by entry date
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "202ue.rpt", GlobalVar.goUtility.GetCustomReportFolder(ref moDatabase));
                        break;
                    case ORDER_BY_APPLY_DATE: // Sort by apply date
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\gl" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "203ua.rpt", GlobalVar.goUtility.GetCustomReportFolder(ref moDatabase));
                        break;
                    default:
                        break;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SetSelectionForUnposted)");
            }

            return return_value;
        }

    }
}
