﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Report;
using Dynasty.Local;
using System.Collections;

namespace Dynasty.ASP.Pages.SO
{
    public partial class PrintSOQuotes
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<MarkUp> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;
        private Models.clsSpreadsheet moDetail;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsReportViewer moReport;

        private List<Models.clsCombobox> SelectionTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> SalesrepCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CurrencyCodeList = new List<Models.clsCombobox>();

        private const int REPORT_TYPE_SUMMARY = 1;
        private const int REPORT_TYPE_DETAIL = 2;
        private const int REPORT_TYPE_DAILY = 3;
        private const int REPORT_TYPE_MONTHLY = 4;
        private const int REPORT_TYPE_GL_SUMMARY = 5;
        private const int REPORT_TYPE_GL_DETAIL = 6;

        private const int BY_TRX_NUM = 1;
        private const int BY_DATE_ENTERED = 2;
        private const int BY_DATE_APPROVED = 3;
        private const int BY_DATE_ORDERED = 4;
        private const int BY_DATE_REQUIRED = 5;
        private const int BY_CUSTOMER = 6;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader
        {
            public string cboSelection_typ = "";
            public string txtCustomer_cd = "";
            public string cboSalesrep_cd = "";

            // Multi-currency
            //
            public string cboCurrency_cd = "";

            public int optReport_typ = REPORT_TYPE_SUMMARY;
            public int optGroupOrder_typ = BY_TRX_NUM;

            public bool chkOpen_fl = false;
            public bool chkHold_fl = false;
            public bool chkVoid_fl = false;
            public bool chkApproved_fl = false;
            public bool chkOrdered_fl = false;

            public string txtTransactionFrom_num = "";
            public string txtTransactionThru_num = "";
            public string txtReferenceFrom = "";
            public string txtReferenceThru = "";

            // Datetime component is not very user-friendly, yet, as of VS2019.
            // For better understanding this, read the comment on bUseDatePicker_fl in clsUser.
            //
            public string mskEntryFrom_dt = "";
            public string mskApprovedFrom_dt = "";
            public string mskShippedFrom_dt = "";
            public string mskRequiredFrom_dt = "";

            public string mskEntryThru_dt = "";
            public string mskApprovedThru_dt = "";
            public string mskShippedThru_dt = "";
            public string mskRequiredThru_dt = "";

            public DateTime? dtEntryFrom_dt = null;
            public DateTime? dtApprovedFrom_dt = null;
            public DateTime? dtShippedFrom_dt = null;
            public DateTime? dtRequiredFrom_dt = null;

            public DateTime? dtEntryThru_dt = null;
            public DateTime? dtApprovedThru_dt = null;
            public DateTime? dtShippedThru_dt = null;
            public DateTime? dtRequiredThru_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag
            {
                public string cboSelection_typ = "";
                public string txtCustomer_cd = "";
                public string cboSalesrep_cd = "";

                public string txtTransactionFrom_num = "";
                public string txtTransactionThru_num = "";
                public string txtReferenceFrom = "";
                public string txtReferenceThru = "";

                public string mskEntryFrom_dt = "";
                public string mskApprovedFrom_dt = "";
                public string mskShippedFrom_dt = "";
                public string mskRequiredFrom_dt = "";

                public string mskEntryThru_dt = "";
                public string mskApprovedThru_dt = "";
                public string mskShippedThru_dt = "";
                public string mskRequiredThru_dt = "";

                public DateTime? dtEntryFrom_dt = null;
                public DateTime? dtApprovedFrom_dt = null;
                public DateTime? dtShippedFrom_dt = null;
                public DateTime? dtRequiredFrom_dt = null;

                public DateTime? dtEntryThru_dt = null;
                public DateTime? dtApprovedThru_dt = null;
                public DateTime? dtShippedThru_dt = null;
                public DateTime? dtRequiredThru_dt = null;

            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()
            {
                Tag.cboSelection_typ = cboSelection_typ;
                Tag.txtCustomer_cd = txtCustomer_cd;
                Tag.cboSalesrep_cd = cboSalesrep_cd;

                Tag.txtTransactionFrom_num = txtTransactionFrom_num;
                Tag.txtTransactionThru_num = txtTransactionThru_num;
                Tag.txtReferenceFrom = txtReferenceFrom;
                Tag.txtReferenceThru = txtReferenceThru;

                Tag.mskEntryFrom_dt = mskEntryFrom_dt;
                Tag.mskApprovedFrom_dt = mskApprovedFrom_dt;
                Tag.mskShippedFrom_dt = mskShippedFrom_dt;
                Tag.mskRequiredFrom_dt = mskRequiredFrom_dt;

                Tag.mskEntryThru_dt = mskEntryThru_dt;
                Tag.mskApprovedThru_dt = mskApprovedThru_dt;
                Tag.mskShippedThru_dt = mskShippedThru_dt;
                Tag.mskRequiredThru_dt = mskRequiredThru_dt;

                Tag.dtEntryFrom_dt = dtEntryFrom_dt;
                Tag.dtApprovedFrom_dt = dtApprovedFrom_dt;
                Tag.dtShippedFrom_dt = dtShippedFrom_dt;
                Tag.dtRequiredFrom_dt = dtRequiredFrom_dt;

                Tag.dtEntryThru_dt = dtEntryThru_dt;
                Tag.dtApprovedThru_dt = dtApprovedThru_dt;
                Tag.dtShippedThru_dt = dtShippedThru_dt;
                Tag.dtRequiredThru_dt = dtRequiredThru_dt;
            }
        }
        private clsHeader Header = new clsHeader();


        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        private void FormDownloadFile(string file_name)                                             // Download a file.
        {
            Models.JSFunction.DownloadFile(JSRuntime, moPage, User.sWebSite, file_name);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            bool return_value = false;

            if (FormCheckSecurity() == false)
            {
                return false;
            }

            try
            {
                FormSyncDates(User.bUseDatePicker_fl);

                Header.txtReferenceFrom = moUtility.EvalQuote(Header.txtReferenceFrom);
                Header.txtReferenceThru = moUtility.EvalQuote(Header.txtReferenceThru);

                if (moUtility.IsEmpty(Header.cboSelection_typ))
                {
                    FormShowMessage(User.Language.oMessage.SELECT_ONE_OPTION_FOR + User.Language.oCaption.SELECTION_TYPE);
                    FormSetFocus("cboSelection_typ");
                    return false;
                }

                // 12/31/2019  More status
                //
                //if (!Header.chkOpen_fl && !Header.chkHold_fl && !Header.chkVoid_fl && !Header.chkOrdered_fl && !Header.chkApproved_fl)
                //{
                //    FormShowMessage(User.Language.oMessage.PLEASE_SELECT_A_STATUS_TYPE);
                //    return return_value;
                //}

                // Need to enter at least one condition.
                //
                if (moUtility.IsEmpty(Header.mskApprovedFrom_dt) && moUtility.IsEmpty(Header.mskApprovedThru_dt)
                && moUtility.IsEmpty(Header.mskRequiredFrom_dt) && moUtility.IsEmpty(Header.mskRequiredThru_dt)
                && moUtility.IsEmpty(Header.mskEntryFrom_dt) && moUtility.IsEmpty(Header.mskEntryThru_dt)
                && moUtility.IsEmpty(Header.txtTransactionFrom_num) && moUtility.IsEmpty(Header.txtTransactionThru_num)
                && moUtility.IsEmpty(Header.txtReferenceFrom) && moUtility.IsEmpty(Header.txtReferenceThru)
                && moUtility.IsEmpty(Header.txtCustomer_cd) && moUtility.IsEmpty(Header.cboSalesrep_cd))
                {
					FormShowMessage(User.Language.oMessage.PLEASE_ENTER_A_VALID_SELECTION_RANGE);
                    if (User.bUseDatePicker_fl)
                    {
                        FormSetFocus("dtEntryThru_dt");
                    }
                    else
                    {
                        FormSetFocus("mskEntryThru_dt");
                    }
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheck)");
            }

            return return_value;
        }

        private bool FormCheckSecurity()
        {
            return modSecurity.SystemPrintSecurityCheck(ref moDatabase, moPage);
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            moDetail.iTotalRows = 1;
            moUtility.ResizeDim(ref moDetail.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, moDetail.iTotalRows - 1);

            return true;
        }

        private bool FormClearMessage()
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();
            moDetail = new Models.clsSpreadsheet();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moReport = new clsReportViewer();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.SOMENU_NAME;
            moPage.Title = User.Language.oCaption.PRINT_QUOTE_JOURNALS;
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormPostEvent()
        {

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback

            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;
            ArrayList item_list = new ArrayList();

            try
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                item_list.Add(new clsComboBoxItem(User.Language.oCaption.SUMMARY, User.Language.oCaption.SUMMARY));
                item_list.Add(new clsComboBoxItem(User.Language.oCaption.DETAIL, User.Language.oCaption.DETAIL));
                modWebLoadUtility.LoadComboBox(ref SelectionTypeList, item_list);

                modLoadUtility.LoadCurrencyCode(ref moDatabase, ref CurrencyCodeList);
                modLoadUtility.LoadSalespersonCode(ref moDatabase, ref SalesrepCodeList);

                if (moUtility.IsSalesStaff(moDatabase))
                {
                    Header.cboSalesrep_cd = moDatabase.sUser_cd;
                }

                Header.cboSelection_typ = User.Language.oCaption.SUMMARY;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }


        private bool FormPrint(int print_type)
        {
            bool return_value = false;
            string pdf_file = "";
            clsFile o_file = new clsFile();
            DateTime stime_started = DateTime.Now;
            clsMail o_mail = new clsMail(ref moDatabase);

            try
            {
                if (FormOpenDatabase() == false)        // Do not delete this
                {
                    return false;
                }

                moReport.InitReport(moUtility.GetServerName(ref moDatabase), moUtility.GetDatabaseName(ref moDatabase), moUtility.GetDBUser(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_ID)
                                    , moUtility.GetDBPassword(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_PASSWORD), moDatabase.uDirectory.sPDFDirectory_nm, true, true);


                if (modCommonReportUtility.SetCompanyInReport(ref moDatabase, "frmPrintSOQuotes", ref moReport) == false)
                {
                    FormShowMessage();
                    return false;
                }
                if (SetReportSelection() == false)
                {
                    return false;
                }
                if (SetReportFile() == false)
                {
                    return false;
                }

                if (moReport.PrintReport(ref moDatabase, print_type, ref pdf_file) == false)
                {
                    FormShowMessage(moReport.GetErrorMessage());
                    return false;
                }

                if (moUtility.IsEmpty(pdf_file) || modWebReportUtility.PDFFound(pdf_file) == false)
                {
                    FormShowMessage(User.Language.oMessage.REPORT_SERVER_NOT_RESPONDING);
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(pdf_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormPrint)");
            }

            return return_value;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormRecreateDetail()                                                           //  Sync moDetail.Data with moDetail.Grid for the items that do not have event-handler ONLY.
        {
            if (moDetail.RecreateDetail() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateDetailLine(Models.clsSpreadsheet.clsGrid cur_item, int row_num = -1)
        {
            if (moDetail.RecreateDetailLine(cur_item, row_num) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateGrid()                                                             //  Create moDetail.Grid according to moDetail.Data
        {
            if (moDetail.RecreateGrid() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtApprovedFrom_dt, ref Header.mskApprovedFrom_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtEntryFrom_dt, ref Header.mskEntryFrom_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtRequiredFrom_dt, ref Header.mskRequiredFrom_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtShippedFrom_dt, ref Header.mskShippedFrom_dt, use_date_picker);

            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtApprovedThru_dt, ref Header.mskApprovedThru_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtEntryThru_dt, ref Header.mskEntryThru_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtRequiredThru_dt, ref Header.mskRequiredThru_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtShippedThru_dt, ref Header.mskShippedThru_dt, use_date_picker);

            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moZoom.Caller == "txtCustomer_cd")
            {
                if (moZoom.Customer(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }


        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }


        private bool btnPrint_Clicked()
        {
            FormPreEvent();

            if (FormCheck())
            {
                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
                FormPrint(GlobalVar.goConstant.PRINT_TO_PDF);
            }

            return FormPostEvent();
        }

        private bool btnExcel_Clicked()
        {
            FormPreEvent();

            if (FormCheck())
            {
                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
                FormPrint(GlobalVar.goConstant.PRINT_TO_EXCEL);
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        
        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                if (moUtility.IsEmpty(cur_item.Col_0))
                {
                    return false;
                }

                code_selected = cur_item.Col_0;

                if (moZoom.Caller == "txtCustomer_cd")
                {
                    Header.txtCustomer_cd = code_selected;
                    txtCustomer_cd_Changed();
                }

                FormSwitchView(moZoom.iView);
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }

        private bool btnZoomOnCustomer_cd_Clicked()
        {
            string where_clause = "";

            FormPreEvent();

            if (FormOpenDatabase() == false)                // Necessary to make moDatabase.sUser_cd valid
            {
                return false;
            }
            if (moUtility.IsSalesStaff(moDatabase))
            {
                where_clause = "sSalesrep_cd = '" + moDatabase.sUser_cd + "'";
            }

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtCustomer_cd", -1, -1, moView.MAIN_PAGE_NUM, "sCustomer_cd", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);   // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool cboSelection_typ_Clicked()
        {
            if (Header.cboSelection_typ == Header.Tag.cboSelection_typ)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            return FormPostEvent();
        }

        private bool txtCustomer_cd_Changed()
        {
            Header.txtCustomer_cd = modCommonUtility.CleanCode(Header.txtCustomer_cd);

            if (Header.txtCustomer_cd == Header.Tag.txtCustomer_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsNonEmpty(Header.txtCustomer_cd))
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                if (moValidate.IsValidCustomerCode(Header.txtCustomer_cd) == false)
                {
                    FormShowMessage(Header.txtCustomer_cd + User.Language.oMessage.IS_INVALID);
                    Header.txtCustomer_cd = Header.Tag.txtCustomer_cd;
                    return FormPostEvent();
                }
                else
                {
                    if (moUtility.IsSalesStaff(moDatabase))
                    {
                        if (moValidate.oRecordset.sField("sSalesrep_cd") != moDatabase.sUser_cd)
                        {
                            FormShowMessage(Header.txtCustomer_cd + User.Language.oMessage.IS_NOT_ACCESSIBLE);
                            Header.txtCustomer_cd = Header.Tag.txtCustomer_cd;
                            return FormPostEvent();
                        }
                    }
                }
            }

            return FormPostEvent();
        }

        private bool dtEntryFrom_dt_Changed()
        {
            if (Header.dtEntryFrom_dt == Header.Tag.dtEntryFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtEntryFrom_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtEntryFrom_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtEntryFrom_dt) == false)
            {
                Header.dtEntryFrom_dt = Header.Tag.dtEntryFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtEntryFrom_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskEntryFrom_dt_Changed()
        {
            if (Header.mskEntryFrom_dt == Header.Tag.mskEntryFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskEntryFrom_dt) == false)
            {
                Header.mskEntryFrom_dt = Header.Tag.mskEntryFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskEntryFrom_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtApprovedFrom_dt_Changed()
        {
            if (Header.dtApprovedFrom_dt == Header.Tag.dtApprovedFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtApprovedFrom_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtApprovedFrom_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtApprovedFrom_dt) == false)
            {
                Header.dtApprovedFrom_dt = Header.Tag.dtApprovedFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtApprovedFrom_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskApprovedFrom_dt_Changed()
        {
            if (Header.mskApprovedFrom_dt == Header.Tag.mskApprovedFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskApprovedFrom_dt) == false)
            {
                Header.mskApprovedFrom_dt = Header.Tag.mskApprovedFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskApprovedFrom_dt");
                return false;
            }

            return FormPostEvent();
        }


        private bool dtRequiredFrom_dt_Changed()
        {
            if (Header.dtRequiredFrom_dt == Header.Tag.dtRequiredFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtRequiredFrom_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtRequiredFrom_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtRequiredFrom_dt) == false)
            {
                Header.dtRequiredFrom_dt = Header.Tag.dtRequiredFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtRequiredFrom_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskRequiredFrom_dt_Changed()
        {
            if (Header.mskRequiredFrom_dt == Header.Tag.mskRequiredFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskRequiredFrom_dt) == false)
            {
                Header.mskRequiredFrom_dt = Header.Tag.mskRequiredFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskRequiredFrom_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtShippedFrom_dt_Changed()
        {
            if (Header.dtShippedFrom_dt == Header.Tag.dtShippedFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtShippedFrom_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtShippedFrom_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtShippedFrom_dt) == false)
            {
                Header.dtShippedFrom_dt = Header.Tag.dtShippedFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtShippedFrom_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskShippedFrom_dt_Changed()
        {
            if (Header.mskShippedFrom_dt == Header.Tag.mskShippedFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskShippedFrom_dt) == false)
            {
                Header.mskShippedFrom_dt = Header.Tag.mskShippedFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskShippedFrom_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtEntryThru_dt_Changed()
        {
            if (Header.dtEntryThru_dt == Header.Tag.dtEntryThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtEntryThru_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtEntryThru_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtEntryThru_dt) == false)
            {
                Header.dtEntryThru_dt = Header.Tag.dtEntryThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtEntryThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskEntryThru_dt_Changed()
        {
            if (Header.mskEntryThru_dt == Header.Tag.mskEntryThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskEntryThru_dt) == false)
            {
                Header.mskEntryThru_dt = Header.Tag.mskEntryThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskEntryThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtApprovedThru_dt_Changed()
        {
            if (Header.dtApprovedThru_dt == Header.Tag.dtApprovedThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtApprovedThru_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtApprovedThru_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtApprovedThru_dt) == false)
            {
                Header.dtApprovedThru_dt = Header.Tag.dtApprovedThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtApprovedThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskApprovedThru_dt_Changed()
        {
            if (Header.mskApprovedThru_dt == Header.Tag.mskApprovedThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskApprovedThru_dt) == false)
            {
                Header.mskApprovedThru_dt = Header.Tag.mskApprovedThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskApprovedThru_dt");
                return false;
            }

            return FormPostEvent();
        }


        private bool dtRequiredThru_dt_Changed()
        {
            if (Header.dtRequiredThru_dt == Header.Tag.dtRequiredThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtRequiredThru_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtRequiredThru_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtRequiredThru_dt) == false)
            {
                Header.dtRequiredThru_dt = Header.Tag.dtRequiredThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtRequiredThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskRequiredThru_dt_Changed()
        {
            if (Header.mskRequiredThru_dt == Header.Tag.mskRequiredThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskRequiredThru_dt) == false)
            {
                Header.mskRequiredThru_dt = Header.Tag.mskRequiredThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskRequiredThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtShippedThru_dt_Changed()
        {
            if (Header.dtShippedThru_dt == Header.Tag.dtShippedThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtShippedThru_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtShippedThru_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtShippedThru_dt) == false)
            {
                Header.dtShippedThru_dt = Header.Tag.dtShippedThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtShippedThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskShippedThru_dt_Changed()
        {
            if (Header.mskShippedThru_dt == Header.Tag.mskShippedThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskShippedThru_dt) == false)
            {
                Header.mskShippedThru_dt = Header.Tag.mskShippedThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskShippedThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

        private bool SetReportSelection()
        {
            bool return_value = false;
			long process_id = 0;
            string sql_str = "";
            string period_from = "";
            string period_thru = "";

            try
            {
                process_id = moUtility.GetReportProcessID();

                SetSelectClause("tblSOTransaction", ref sql_str);

                sql_str = "{tblSOTransaction.iTransaction_typ} = " + GlobalVar.goConstant.TRX_QUOTE_TYPE + sql_str;
                if (moUtility.IsNonEmpty(Header.cboCurrency_cd))
                {
                    sql_str += " AND ({tblSOTransaction.sCurrency_cd} = '" + Header.cboCurrency_cd + "')";
                }

                moReport.SetSelectionFormula(modCommonReportUtility.CleanupFormula(sql_str));

                if (Header.optGroupOrder_typ == BY_DATE_APPROVED)
                {
                    moReport.SetFormula("min_date", Header.mskApprovedFrom_dt);
                    moReport.SetFormula("max_date", Header.mskApprovedThru_dt);
                }
                else
                {
                    moReport.SetFormula("min_date", Header.mskEntryFrom_dt);
                    moReport.SetFormula("max_date", Header.mskEntryThru_dt);
                }

                moReport.SetFormula("min_code", Header.txtCustomer_cd);
                moReport.SetFormula("max_code", Header.txtCustomer_cd);
                moReport.SetFormula("time", moUtility.SFormat(DateTime.Now, "hh:mm tt"));

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SetReportSelection)");
            }

            return return_value;
        }

        private bool SetReportFile()
        {
            bool return_value = false;

            try
            {
                if (Header.cboSelection_typ == User.Language.oCaption.DETAIL)
                {
                    if (Header.optGroupOrder_typ == BY_TRX_NUM)
                    {
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\so" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "221dn.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                    }
                    else if (Header.optGroupOrder_typ == BY_DATE_ENTERED)
                    {
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\so" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "222de.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                    }
                    else if (Header.optGroupOrder_typ == BY_DATE_APPROVED)
                    {
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\so" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "223da.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                    }
                    else if (Header.optGroupOrder_typ == BY_DATE_REQUIRED)
                    {
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\so" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "224dq.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                    }
                    else if (Header.optGroupOrder_typ == BY_DATE_ORDERED)
                    {
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\so" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "225do.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                    }
                    else // If optCustomer Then
                    {
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\so" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "226dc.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                    }
                }
                else // Summary
                {
                    if (Header.optGroupOrder_typ == BY_TRX_NUM)
                    {
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\so" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "227sn.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                    }
                    else if (Header.optGroupOrder_typ == BY_DATE_ENTERED)
                    {
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\so" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "228se.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                    }
                    else if (Header.optGroupOrder_typ == BY_DATE_APPROVED)
                    {
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\so" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "229sa.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                    }
                    else if (Header.optGroupOrder_typ == BY_DATE_REQUIRED)
                    {
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\so" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "230sq.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                    }
                    else if (Header.optGroupOrder_typ == BY_DATE_ORDERED)
                    {
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\so" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "231so.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                    }
                    else // If optCustomer Then
                    {
                        moReport.SetFileName(moDatabase.uDirectory.sReportDirectory_nm + "\\so" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "232sc.rpt", moUtility.GetCustomReportFolder(ref moDatabase));
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SetReportFile)");
            }

            return return_value;
        }

        private bool SetSelectClause(string table_name, ref string sql_str)
        {
            bool return_value = false;
            string check_str = "";

            try
            {
                // By eliminating the filtering cases, increase the performance.
                //
                if (moUtility.ToInteger(Header.txtTransactionFrom_num) > 0)
                {
                    sql_str += " AND ({" + table_name + ".iTransaction_num} >= " + moUtility.ToInteger(Header.txtTransactionFrom_num).ToString() + ")";
                }
                if (moUtility.ToInteger(Header.txtTransactionThru_num) > 0)
                {
                    sql_str += " AND ({" + table_name + ".iTransaction_num} <= " + moUtility.ToInteger(Header.txtTransactionThru_num).ToString() + ")";
                }
                if (moGeneral.ToNumDate(Header.mskEntryFrom_dt) > 0)
                {
                    sql_str += " AND ({" + table_name + ".iEntry_dt} >= " + moGeneral.ToNumDate(Header.mskEntryFrom_dt).ToString() + ")";
                }
                if (moGeneral.ToNumDate(Header.mskEntryThru_dt) > 0)
                {
                    sql_str += " AND ({" + table_name + ".iEntry_dt} <= " + moGeneral.ToNumDate(Header.mskEntryThru_dt) + ")";
                }
                if (moGeneral.ToNumDate(Header.mskApprovedFrom_dt) > 0)
                {
                    sql_str += " AND ({" + table_name + ".iApply_dt} >= " + moGeneral.ToNumDate(Header.mskApprovedFrom_dt).ToString() + ")";
                }
                if (moGeneral.ToNumDate(Header.mskApprovedThru_dt) > 0)
                {
                    sql_str += " AND ({" + table_name + ".iApply_dt} <= " + moGeneral.ToNumDate(Header.mskApprovedThru_dt).ToString() + ")";
                }
                if (moGeneral.ToNumDate(Header.mskRequiredFrom_dt) > 0)
                {
                    sql_str += " AND ({" + table_name + ".iRequired_dt} >= " + moGeneral.ToNumDate(Header.mskRequiredFrom_dt).ToString() + ")";
                }
                if (moGeneral.ToNumDate(Header.mskRequiredThru_dt) > 0)
                {
                    sql_str += " AND ({" + table_name + ".iRequired_dt} <= " + moGeneral.ToNumDate(Header.mskRequiredThru_dt).ToString() + ")";
                }
                if (moUtility.IsNonEmpty(Header.txtReferenceFrom))
                {
                    sql_str += " AND ({" + table_name + ".sReference} >= '" + Header.txtReferenceFrom + "')";
                }
                if (moUtility.IsNonEmpty(Header.txtReferenceThru))
                {
                    sql_str += " AND ({" + table_name + ".sReference} <= '" + Header.txtReferenceThru + "')";
                }
                if (moUtility.IsNonEmpty(Header.cboSalesrep_cd))
                {
                    sql_str += " AND ({" + table_name + ".sSalesrep_cd} = '" + Header.cboSalesrep_cd + "')";
                }
                if (moUtility.IsNonEmpty(Header.txtCustomer_cd))
                {
                    sql_str += " AND ({" + table_name + ".sCustomer_cd} = '" + Header.txtCustomer_cd + "')";
                }

                if (Header.optGroupOrder_typ == BY_DATE_ORDERED)
                {
                    sql_str += " AND ({" + table_name + ".iShipped_dt} > 0)";
                }
                if (Header.optGroupOrder_typ == BY_DATE_APPROVED)
                {
                    sql_str += " AND ({" + table_name + ".iApply_dt} > 0)";
                }

                if (Header.chkOpen_fl == true)
                {
                    check_str += moUtility.IIf(moUtility.IsEmpty(check_str), "", " OR ").ToString() + "{" + table_name + ".iStatus_typ} = " + GlobalVar.goConstant.OPEN_TRX_NUM.ToString();
                }

                if (Header.chkVoid_fl == true)
                {
                    check_str += moUtility.IIf(moUtility.IsEmpty(check_str), "", " OR ").ToString() + "{" + table_name + ".iStatus_typ} = " + GlobalVar.goConstant.VOID_TRX_NUM.ToString();
                }

                if (Header.chkHold_fl == true)
                {
                    check_str += moUtility.IIf(moUtility.IsEmpty(check_str), "", " OR ").ToString() + "{" + table_name + ".iStatus_typ} = " + GlobalVar.goConstant.HOLD_TRX_NUM.ToString();
                }

                if (Header.chkOrdered_fl == true)
                {
                    check_str += moUtility.IIf(moUtility.IsEmpty(check_str), "", " OR ").ToString() + "{" + table_name + ".iStatus_typ} = " + GlobalVar.goConstant.ORDERED_TRX_NUM.ToString();
                }
                if (Header.chkApproved_fl == true)
                {
                    check_str += moUtility.IIf(moUtility.IsEmpty(check_str), "", " OR ").ToString() + "{" + table_name + ".iStatus_typ} = " + GlobalVar.goConstant.APPROVED_TRX_NUM.ToString();
                }

                if (moUtility.IsNonEmpty(check_str))
                {
                    sql_str += " AND (" + check_str + ")";
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SetSelectClause)");
            }

            return return_value;
        }

    }
}
