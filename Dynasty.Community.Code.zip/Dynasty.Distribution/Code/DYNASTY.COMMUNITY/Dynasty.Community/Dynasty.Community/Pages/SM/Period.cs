﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Local;
using System.Data;

namespace Dynasty.ASP.Pages.SM
{
    public partial class Period
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<Period> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;                                                               
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;
        private Models.clsSpreadsheet moSpreadsheet;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsSetupAdvisor moSetupAdvisor;

        private List<Models.clsCombobox> MonthList = new List<Models.clsCombobox>();

        private int miTotalPeriods = 0;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader                   
        {
            // Listing of UI items on the header
            //
            public string txtKey_id = "";
            public string txtDescription = "";
            public string cboFirstMonth = "";
            public string txtStatus_typ = "0";

            public int optPeriods = 0;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag                                                                     
            {
                public string txtKey_id { get; set; } = "";
                public string cboFirstMonth = "";
                public int optPeriods = 0;
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()                                                                  
            {
                Tag.txtKey_id = txtKey_id;
                Tag.cboFirstMonth = cboFirstMonth;
                Tag.optPeriods = optPeriods;
            }
        }
        private clsHeader Header = new clsHeader();                                                 

        private class clsDetail
        {
            public string[] FieldName;                                                              // Keeps the main detail field names;
            public string[,] Data;                                                                  // Keeps the main detail data.  Mirror image of clsGrid will be maintained for faster validation/calculation
            public int iTotalRows = 0;                                                              // Total number of rows.  Must be equal to Data.GetLength(1), not Data.GetUpper(1)

            public class clsGrid
            {
                public int Row_num { get; set; } = 0;                                               // 0-based row number. This will identify each row.
                public string txtPeriod { get; set; } = "";
                public string txtBegin_dt { get; set; } = "";
                public string txtEnd_dt { get; set; } = "";
                public string txtQtr { get; set; } = "";
            }
            public List<clsGrid> Grid = new List<clsGrid>();
        }
        private clsDetail Detail = new clsDetail();                                     


        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;                        
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows()
        {
            bool return_value = false;
            int row_num = 0;
            const int lines_to_add = 5;

            try
            {
                moUtility.ResizeDimPreserved(ref Detail.Data, Detail.Data.GetUpperBound(0), Detail.Data.GetUpperBound(1) + lines_to_add);

                for (row_num = 0; row_num < lines_to_add; row_num++)
                {
                    Detail.Grid.Add(new clsDetail.clsGrid { Row_num = Detail.iTotalRows, txtPeriod = "", txtBegin_dt = "", txtEnd_dt = "", txtQtr = "" });
                    Detail.iTotalRows += 1;
                }
                
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormAddMoreRows)");
                FormRecreateGrid();
            }

            return return_value;
        }

        private bool FormCalculateTotal()
        {
            decimal total_amt = 0;
            int row_num;


            // Calculate the totals needed
            //

            return true;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            if (FormCheckSecurity() == false)
            {
                return false;
            }
            else if (FormRecreateDetail() == false)
            {
                return false;
            }
            else if (FormCheckHeader() == false)
            {
                return false;
            }
            else if (FormCheckDetail() == false)
            {
                return false;
            }
            else if (FormCheckExtra() == false)
            {
                return false;
            }

            return true;
        }

        private bool FormCheckDetail()                                                             // validate Detail for saving.
        {
            bool return_value = false;
            int tot_periods = 0;
            int row_num = 0;
            int col_num = 0;

            try
            {
                if (FormRecreateDetail() == false)
                {
                    return false;
                }

                //if (Header.optPeriods <= 13)
                //{
                //    tot_periods = Header.optPeriods;
                //}
                //else
                //{
                for (tot_periods = Detail.Data.GetLength(1) - 1; tot_periods >= 0; tot_periods--)
                {
                    if (moUtility.IsNonEmpty(moUtility.STrim(Detail.Data[clsSetupAdvisor.PERIOD_NAME_COL, tot_periods]))
                        || moUtility.IsNonEmpty(moUtility.STrim(Detail.Data[clsSetupAdvisor.PERIOD_BEGIN_COL, tot_periods]))
                        || moUtility.IsNonEmpty(moUtility.STrim(Detail.Data[clsSetupAdvisor.PERIOD_END_COL, tot_periods]))
                        || moUtility.IsNonEmpty(moUtility.STrim(Detail.Data[clsSetupAdvisor.PERIOD_QUARTER_COL, tot_periods])))
                    {
                        break;
                    }
                }
                //}

                if (tot_periods < 1)
                {
                    FormShowMessage(User.Language.oMessage.PERIOD_IS_NOT_SETUP_PROPERLY);
                    return false;
                }

                for (row_num = 0; row_num < tot_periods; row_num++)    
                {
                    if (moUtility.IsEmpty(moUtility.STrim(Detail.Data[clsSetupAdvisor.PERIOD_NAME_COL, row_num])))
                    {
                        FormShowMessage(User.Language.oMessage.PERIOD_NAME_CANNOT_BE_BLANK);
                        col_num = clsSetupAdvisor.PERIOD_NAME_COL;
                        return false;
                    }
                    else if (moUtility.IsEmpty(moUtility.STrim(Detail.Data[clsSetupAdvisor.PERIOD_BEGIN_COL, row_num])))
                    {
                        FormShowMessage(User.Language.oMessage.PERIOD_IS_NOT_SETUP_PROPERLY);
                        col_num = clsSetupAdvisor.PERIOD_NAME_COL;
                        return false; 
                    }
                    else if (moUtility.IsEmpty(moUtility.STrim(Detail.Data[clsSetupAdvisor.PERIOD_END_COL, row_num])))
                    {
                        FormShowMessage(User.Language.oMessage.PERIOD_IS_NOT_SETUP_PROPERLY);
                        col_num = clsSetupAdvisor.PERIOD_NAME_COL;
                        return false;
                    }
                    else if (moUtility.ToInteger(Detail.Data[clsSetupAdvisor.PERIOD_QUARTER_COL, row_num]) <= 0)
                    {
                        FormShowMessage(User.Language.oMessage.PERIOD_IS_NOT_SETUP_PROPERLY);
                        col_num = clsSetupAdvisor.PERIOD_NAME_COL;
                        return false;
                    }
                    else if (moGeneral.ToNumDate(Detail.Data[clsSetupAdvisor.PERIOD_BEGIN_COL, row_num]) >= moGeneral.ToNumDate(Detail.Data[clsSetupAdvisor.PERIOD_END_COL, row_num]))
                    {
                        FormShowMessage(User.Language.oMessage.PERIOD_IS_NOT_SETUP_PROPERLY);
                        col_num = clsSetupAdvisor.PERIOD_BEGIN_COL;
                        return false; 
                    }
                    else if (row_num > 0)
                    {
                        if (moGeneral.ToNumDate(Detail.Data[clsSetupAdvisor.PERIOD_END_COL, row_num - 1]) >= moGeneral.ToNumDate(Detail.Data[clsSetupAdvisor.PERIOD_BEGIN_COL, row_num]))
                        {
                            FormShowMessage(User.Language.oMessage.PERIOD_IS_NOT_SETUP_PROPERLY);
                            col_num = clsSetupAdvisor.PERIOD_END_COL;
                            return false;
                        }
                        else if (moUtility.ToInteger(Detail.Data[clsSetupAdvisor.PERIOD_QUARTER_COL, row_num - 1]) > moUtility.ToInteger(Detail.Data[clsSetupAdvisor.PERIOD_QUARTER_COL, row_num]))
                        {
                            FormShowMessage(User.Language.oMessage.PERIOD_IS_NOT_SETUP_PROPERLY);
                            col_num = clsSetupAdvisor.PERIOD_QUARTER_COL;
                            return false;
                        }
                    }
                }

                if (366 < Math.Abs(moGeneral.DateDifference(Detail.Data[clsSetupAdvisor.PERIOD_BEGIN_COL, 0], Detail.Data[clsSetupAdvisor.PERIOD_END_COL, row_num - 1])))
                {
                    FormShowMessage(User.Language.oMessage.FISCAL_YEAR_CANNOT_EXCEED_366);
                    return false;
                }

                // Check if the first period overlaps the previous years.
                //
                if (moValidate.IsValidRecord("SELECT * FROM tblGLPeriodDet WHERE sFiscalYear <> '" + Header.txtKey_id + "' AND " + moGeneral.ToNumDate(Detail.Data[clsSetupAdvisor.PERIOD_BEGIN_COL, 0]) + " BETWEEN iPeriodBegin_dt AND iPeriodEnd_dt"))
                {
                    FormShowMessage(moGeneral.ToNumDate(Detail.Data[clsSetupAdvisor.PERIOD_BEGIN_COL, 0]) + User.Language.oCaption.APPEARS_IN + moValidate.oRecordset.sField("sFiscalYear"));
                    return false;
                }

                miTotalPeriods = tot_periods;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckDetail)");
            }

            return return_value;
        }

        private bool FormCheckExtra()                                                              // validate extra other than the header and detail.
        {
            bool return_value = false;

            try
            {

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckExtra)");
            }

            return return_value;
        }

        private bool FormCheckHeader()                                                             // validate the header data.
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormShowMessage(User.Language.oCaption.CODE + @User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("txtKey_id");
                    return false;
                }
                if (moUtility.SLength(moUtility.STrim(Header.txtKey_id)) < 4)
                {
                    FormShowMessage(User.Language.oMessage.FISCAL_YEAR_SHOULD_BE_4_DIGITS);
                    FormSetFocus("txtKey_id");
                    return false;
                }
                else if (Math.Abs(moUtility.ToInteger(Header.txtKey_id) - moUtility.ToInteger(moUtility.SFormat(DateTime.Now, "yyyy"))) >= 100)
                {
                    FormShowMessage(User.Language.oMessage.FISCAL_YEAR_IS_INVALID);
                    FormSetFocus("txtKey_id");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboFirstMonth))
                {
                    FormShowMessage(User.Language.oCaption.FIRST_MONTH + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("cboFirstMonth");
                    return false;
                }
                else if (Header.optPeriods == 0)
                {
                    FormShowMessage(User.Language.oMessage.TOTAL_PERIOD_SHOULD_BE_SPECIFIED);
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckHeader)");
            }

            return return_value;
        }

        private bool FormCheckConcurrency(clsRecordset cur_set)                                    // Check if someone has changed this record while it is open in this session.
        {
            if (cur_set.IsNonEmpty()) 
            {
                if (moPage.bNew_fl)
                {
                    // If someone has created a record with the same key
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.DUPLICATE_IS_FOUND + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                    moPage.bNew_fl = false;
                }
                else if (moPage.CheckForConcurrency(cur_set) == false)
                {
                    // If someone has updated this record in the meantime.
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        private bool FormCheckToDelete()
        {
            clsIntegrity o_integrity = new clsIntegrity(ref moDatabase);

            if (FormCheckSecurity() == false)
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }
            else if (modFormUtility.IsReservedRecord(ref moDatabase, Header.txtKey_id, moPage.bReserved_fl))
            {
                FormShowMessage(User.Language.oMessage.RESERVED_RECORD_IS_NOT_ALLOWED_TO_DELETE);
                return false;
            }
            else if (o_integrity.IsReferenced(moPage.sModule_id, moPage.sKeyField_nm, Header.txtKey_id))
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }

            return true;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearDetail();
            FormClearExtra();

            return true;
        }

        private bool FormClearDetail()                                                             // Clear the detail.
        {
            int row_num = 0;

            Detail.iTotalRows = moUtility.IIf(moDatabase.iTotalPeriods_num > 0, moDatabase.iTotalPeriods_num, 12);
            moUtility.ResizeDim(ref Detail.Data, clsSetupAdvisor.TOTAL_COLUMNS - 1, Detail.iTotalRows - 1);
            
            if (Detail.iTotalRows == 12)
            {
                Header.optPeriods = 12;
            }
            else if (Detail.iTotalRows == 13)
            {
                Header.optPeriods = 13;
            }
            else 
            {
                Header.optPeriods = 0;
            }

            for (row_num = 0; row_num < Detail.iTotalRows; row_num++)
            {
                Detail.Data[clsSetupAdvisor.PERIOD_NAME_COL, row_num] = (row_num +1).ToString();
                Detail.Data[clsSetupAdvisor.PERIOD_QUARTER_COL, row_num] = ((int)(row_num / 3) + 1).ToString();
            }

            return FormRecreateGrid();
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();
            moPage.bReadOnly_fl = false;

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {
            Header.txtKey_id = "";
            Header.txtDescription = "";
            Header.txtStatus_typ = "";
            Header.cboFirstMonth = "";
            Header.optPeriods = 12;

            return true;
        }

        private bool FormClearMessage()                                                            
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }

                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id) || moPage.bNew_fl)
                {
                    FormClear();
                    return true;
                }
                else if (FormCheckToDelete() == false)
                {
                    return false;
                }

                // Transaction begins here.
                //
                if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }

                if (modFormUtility.RecordDelete(ref moDatabase, moPage.iScreen_typ, Header.txtKey_id, moPage.sKeyField_nm, moPage.sTable_nm, moPage.sDetailTable_nm, moPage.sRestrictionClause, moPage.iTransaction_typ) == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }
                else if (FormDeleteExtra() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }

                // Transaction ends here.
                //
                if (moDatabase.TransactionCommit() == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDelete)");
                moDatabase.TransactionRollback();
                return_value = false;
            }

            return return_value;
        }

        private bool FormDeleteExtra()
        {

            return true;
        }

        private bool FormDeleteCurrentRow(clsDetail.clsGrid cur_item)
        {
            bool return_value = false;
            int old_num = cur_item.Row_num;

            try
            {
                if (modDetailUtility.DeleteCurrentRow(ref moDatabase, ref Detail.Data, cur_item.Row_num) == false)
                {
                    FormShowMessage();
                    FormRecreateGrid();
                    return false;
                }

                Detail.Grid.RemoveAt(cur_item.Row_num);
                Detail.Grid.Where(i => i.Row_num >= old_num).Select(i => { i.Row_num -= 1; return i; }).ToList();

                Detail.iTotalRows -= 1;

                if (FormCalculateTotal() == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDeleteCurrentRow)");
                FormRecreateGrid();
            }

            return return_value;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormFindRecord(ref clsRecordset cur_set, int matching_type = 0)
        {
            bool return_value = false;

            matching_type = (int)(moUtility.IIf(matching_type > 0, matching_type, GlobalVar.goConstant.MATCHING_RECORD_TYPE));
            return_value = modFormUtility.RecordRead(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sTable_nm, moPage.sKeyField_nm, moPage.sPreviousKey_id, moPage.sRestrictionClause, ref matching_type);

            return return_value;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moSetupAdvisor = new clsSetupAdvisor(ref moDatabase);

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.SMMENU_NAME;
            moPage.Title = User.Language.oCaption.PERIOD;
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormInitHeader();
            FormInitDetail();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitDetail()                                                              // Initialize the page at loading.  Only once.
        {
            // Detail table name.
            //
            moPage.sDetailTable_nm = "tblGLPeriodDet";

            // Field names of detail table.
            //
            moUtility.ResizeDim(ref Detail.FieldName, clsSetupAdvisor.TOTAL_COLUMNS - 1);

            Detail.FieldName[clsSetupAdvisor.PERIOD_NAME_COL] = "sPeriod_nam";
            Detail.FieldName[clsSetupAdvisor.PERIOD_BEGIN_COL] = "iPeriodBegin_dt";
            Detail.FieldName[clsSetupAdvisor.PERIOD_END_COL] = "iPeriodEnd_dt";
            Detail.FieldName[clsSetupAdvisor.PERIOD_QUARTER_COL] = "iQuarter";

            FormClearDetail();

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = "tblGLPeriod"; 
            moPage.sKeyField_nm = "sFiscalYear";
            moPage.iTransaction_typ= 0; 

            return true;
        }

        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback
            
            return true;
        }

        private bool FormInsertNewRow(clsDetail.clsGrid cur_item)
        {
            bool return_value = false;
            int old_num = cur_item.Row_num;

            try
            {
                if (modDetailUtility.InsertNewRow(ref moDatabase, ref Detail.Data, cur_item.Row_num) == false)
                {
                    FormShowMessage();
                    FormRecreateGrid();
                    return false;
                }

                Detail.Grid.Insert(cur_item.Row_num, new clsDetail.clsGrid { Row_num = -1, txtPeriod = "", txtBegin_dt = "", txtEnd_dt = "", txtQtr = "" });
                Detail.Grid.Where(i => i.Row_num >= old_num).Select(i => { i.Row_num += 1; return i; }).ToList();
                Detail.Grid.Single(i => i.Row_num == -1).Row_num = old_num;

                Detail.iTotalRows += 1;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormInsertNewRow)");
                FormRecreateGrid();
            }

            return return_value;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;

            try 
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                modLoadUtility.LoadMonths(ref moDatabase, ref MonthList);


                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormMove(int record_move_direction)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormClear();

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            if (FormFindRecord(ref cur_set, record_move_direction) == false)
            {
                return false;
            }

            FormShow(cur_set);
            return true;

        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostSave()
        {
            // If this is a transaction page, and transaction number has changed, let the user know.
            //
            if (moPage.sPreviousKey_id != Header.txtKey_id)
            {
                FormShowMessage(User.Language.oMessage.TRX_NUM_HAS_CHANGED_TO + "  " + Header.txtKey_id, false);
            }

            moPage.sPreviousKey_id = Header.txtKey_id;

            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {

            return true;
        }

        private bool FormReArrangeDetail()                                                         // Arrange(show/hide, enable/disable) the columns in the detail(grid)
        {

            return true;
        }

        private bool FormReArrangeHeader()                                                         //  Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormRecreateDetail()                                                           //  Sync Detail.Data with Detail.Grid for the items that do not have event-handler ONLY.
        {
            int row_num = 0;

            if (Detail.Grid.Count() == 0)
            {
                moUtility.ResizeDim(ref Detail.Data, Detail.Data.GetUpperBound(0), 0);
                return true;
            }

            // We need to create it here for saving because some fields may not have been copied into the array.
            //
            Detail.iTotalRows = Detail.Grid.Count();
            moUtility.ResizeDim(ref Detail.Data, Detail.Data.GetUpperBound(0), Detail.iTotalRows - 1);

            foreach (var det in Detail.Grid)
            {
                Detail.Data[clsSetupAdvisor.PERIOD_NAME_COL, row_num] = det.txtPeriod;
                Detail.Data[clsSetupAdvisor.PERIOD_BEGIN_COL, row_num] = det.txtBegin_dt;
                Detail.Data[clsSetupAdvisor.PERIOD_END_COL, row_num] = det.txtEnd_dt;
                Detail.Data[clsSetupAdvisor.PERIOD_QUARTER_COL, row_num] = det.txtQtr;

                row_num++;
            }

            return true;
        }

        private bool FormRecreateGrid()                                                             //  Create Detail.Grid according to Detail.Data
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
                if (Detail.Data == null)
                {
                    Detail.Grid.Clear();
                    return true;
                }
                else if (Detail.Data.GetLength(1) == 0)
                {
                    Detail.Grid.Clear();
                    return true;
                }

                Detail.iTotalRows = Detail.Data.GetLength(1);

                Detail.Grid.Clear();
                for (row_num = 0; row_num < Detail.iTotalRows; row_num++)
                {
                    Detail.Grid.Add(new clsDetail.clsGrid { Row_num = row_num
                        , txtPeriod = Detail.Data[clsSetupAdvisor.PERIOD_NAME_COL, row_num]
                        , txtBegin_dt = Detail.Data[clsSetupAdvisor.PERIOD_BEGIN_COL, row_num]
                        , txtEnd_dt = Detail.Data[clsSetupAdvisor.PERIOD_END_COL, row_num]
                        , txtQtr = Detail.Data[clsSetupAdvisor.PERIOD_QUARTER_COL, row_num]});
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormRecreateGrid)");
            }

            return return_value;
        }

        private bool FormSave()
        {
            bool return_value = false;
            clsRecordset cur_set;

            try
            {
                if (FormOpenDatabase() == false)                     // Has to come before FormCheck()
                {
                    return false;
                }
                else if (FormCheck() == false)                       // Check if data is ok to save.
                {
                    return false;
                }

                moPage.sPreviousKey_id = Header.txtKey_id;
                cur_set = new clsRecordset(ref moDatabase);

                if (modFormUtility.RecordOpen(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sRestrictionClause, moPage.sTable_nm, moPage.sKeyField_nm) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormCheckConcurrency(cur_set) == false)
                {
                    return false;
                }
                else if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormPreSave(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (!moSetupAdvisor.SaveFiscalYear(Header.txtKey_id, GlobalVar.goUtility.ToInteger(Header.cboFirstMonth), ref Detail.Data))
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }
                else if (moDatabase.TransactionCommit() == false)
                {
                    FormShowMessage();
                    moDatabase.TransactionRollback();
                    return false;
                }

                FormPostSave();
                    
                return_value = true;

            }
            catch (Exception ex)
            {

                FormShowMessage(ex.Message + " (FormSave)");
                moDatabase.TransactionRollback();

            }

            return return_value;
        }

        private bool FormSaveDetail()
        {
            bool return_value = false;

            int col_num = 0;
            int row_num = 0;
            string field_list = "";
            string value_list = "";
            string sql_str = "";

            clsRecordset size_set = new clsRecordset(ref moDatabase);

            try
            {
                if (modDetailUtility.PreSaveDetail(ref moDatabase, ref size_set, ref field_list, moPage.iTransaction_typ, Header.txtKey_id, moPage.sKeyField_nm, moPage.sDetailTable_nm, Detail.FieldName, clsSetupAdvisor.TOTAL_COLUMNS) == false)
                {
                    FormShowMessage();
                    return false;
                }

                for (row_num = 0; row_num <= Detail.Data.GetUpperBound(1); row_num++)
                {
                    // Create the value list.
                    //
                    value_list = moGeneral.EncloseField(moPage.sKeyField_nm, Header.txtKey_id);
                    if (moPage.iTransaction_typ > 0)
                    {
                        value_list += "," + moPage.iTransaction_typ;
                    }
                    value_list += "," + (row_num + 1).ToString();

                    if (moUtility.ToValue(Detail.Data[clsSetupAdvisor.PERIOD_BEGIN_COL, row_num]) > 0)
                    {
                        for (col_num = 0; col_num < clsSetupAdvisor.TOTAL_COLUMNS; col_num++)
                        {
                            if (moUtility.IsNonEmpty(Detail.FieldName[col_num]))      // Attach if field name exist.
                            {
                                if (col_num == clsSetupAdvisor.PERIOD_NAME_COL)
                                {
                                    if (moUtility.IsEmpty(Detail.Data[clsSetupAdvisor.PERIOD_NAME_COL, row_num]))
                                    {
                                        value_list += ",'" + GlobalVar.goConstant.FOR_ALL + "'";
                                    }
                                    else
                                    {
                                        value_list += ",'" + Detail.Data[clsSetupAdvisor.PERIOD_NAME_COL, row_num] + "'";
                                    }
                                }
                                else
                                {
                                    value_list += "," + moGeneral.EncloseField(Detail.FieldName[col_num], Detail.Data[col_num, row_num], size_set.Size(Detail.FieldName[col_num]));
                                }
                            }
                            modGeneralUtility.RunEvents();
                        }

                        sql_str = "INSERT INTO " + moPage.sDetailTable_nm + "(";
                        sql_str += field_list;
                        sql_str += ") VALUES(" + value_list + ")";

                        if (moDatabase.ExecuteSQL(sql_str) == false)
                        {
                            FormShowMessage();
                            return false;
                        }
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveDetail)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormSaveExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormSaveHeader(clsRecordset cur_set)
        {
            bool return_value = false;
            string sql_str = null;

            try
            {
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveHeader)");
            }

            return return_value;
        }

        private bool FormSearch()
        {

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {
            if (FormShowHeader(cur_set) == false)
            {
                return false;
            }
            else if (FormShowDetail() == false)
            {
                return false;
            }
            else if (FormShowExtra(cur_set) == false)
            {
                return false;
            }

            FormReArrangeHeader();
            FormReArrangeDetail();

            return true;
        }

        private bool FormShowDetail()
        {
            bool return_value = false;
           
            try
            {
                if (modDetailUtility.GetDetail(ref moDatabase, moPage.Title, Header.txtKey_id, moPage.sKeyField_nm, ref Detail.iTotalRows, moPage.sDetailTable_nm, moPage.iTransaction_typ, Detail.FieldName, ref Detail.Data) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormRecreateGrid() == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowDetail)");
                FormRecreateGrid();
            }

            return return_value;
        }

        private bool FormShowExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                moPage.Clear();
                moPage.PreserveTimestamp(cur_set);
                moPage.bNew_fl = false;

                // This is where bReadOnly_fl & bReserved_fl are set according to the nature of the current record.
                //
                moPage.bReadOnly_fl = (moUtility.ToInteger(Header.txtStatus_typ) > 0);

                moPage.sPreviousKey_id = Header.txtKey_id;
                Header.Preserve();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowHeader(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                Header.txtKey_id = cur_set.sField(moPage.sKeyField_nm);

                Header.txtStatus_typ = cur_set.iField("iStatus_typ").ToString();
                Header.optPeriods = cur_set.iField("iTotaPeriods");
                Header.cboFirstMonth = cur_set.iField("iFirstMonth").ToString();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowHeader)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowListing()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moListing.Show(moDatabase, moPage) == false)
            {
                return false;
            }

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            moView.SwitchView(moPage, cur_page);

            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moZoom.iColumn == clsSetupAdvisor.PERIOD_NAME_COL)
            {
                if (moZoom.Inventory(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormClear();
                return true;
            }

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
                {
                    return false;
                }
            }

            FormCancel();
            return true;
        }

        private bool btnDelete_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormClear();
                return true;
            }

            if (FormDialog(btnDelete_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_DELETE) == false)
            {
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (FormDelete() == false)
            {
                return false;
            }
            
            FormClear();
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormExit();
                return true;
            }

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }

        private bool btnFirst_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnFirst_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.FIRST_RECORD_TYPE);
        }

        private bool btnLast_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnLast_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.LAST_RECORD_TYPE);
        }

        private bool btnNext_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnNext_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.NEXT_RECORD_TYPE);
        }

        private bool btnPrevious_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnPrevious_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.PREVIOUS_RECORD_TYPE);
        }

        private bool btnSave_Clicked()
        {
            FormPreEvent();

            if (FormSave() == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewHeader_Clicked()
        {
            FormPreEvent();                                                                           
            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool cmdViewListing_Clicked()
        {
            FormPreEvent();       
            
            if (FormShowListing() == false)
            {
                return false;
            }

            FormSwitchView(moView.LISTING_PAGE_NUM);
            return true;

        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnListingSelect_Clicked(Models.clsListing.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.IsEmpty(cur_item.Code))
            {
                return false;
            }

            FormClear();
            Header.txtKey_id = cur_item.Code;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;

            FormPreEvent();

            try
            {
                if (moUtility.IsEmpty(cur_item.Col_0))
                {
                    return false;
                }


                FormSwitchView(moZoom.iView);
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();                                                                   

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }
        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Changed()
        {
            if (Header.txtKey_id == Header.Tag.txtKey_id)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (txtKey_id_Verified() == false)
            {
                Header.txtKey_id = Header.Tag.txtKey_id;
                return false;
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Verified()
        {
            bool return_value = false;
            clsRecordset cur_set;
            string key_id = "";

            try
            {
                if (moUtility.ToInteger(Header.txtKey_id) != 0)
                {
                    Header.txtKey_id = moUtility.ToInteger(Header.txtKey_id).ToString();            // 02/18/2025  Now, we accept 4-digit integer only
                }
                else
                {
                    Header.txtKey_id = "";
                }

                key_id = Header.txtKey_id;

                if (Header.txtKey_id == Header.Tag.txtKey_id)
                {
                    return true;
                }
                else if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormClear();
                    return true;
                }
                else if (moUtility.SLength(Header.txtKey_id) != 4)
                {
                    FormShowMessage(User.Language.oMessage.PLESE_ENTER_A_VALID_YEAR);
                    return false;

                }

                if (FormOpenDatabase() == false)
                {
                    FormClear();
                    FormShowMessage(User.Language.oMessage.CONNECTION_HAS_FAILED);
                    return false;
                }

                cur_set = new clsRecordset(ref moDatabase);

                if (FormFindRecord(ref cur_set))
                {
                    FormShow(cur_set);
                }
                else
                {
                    if (moPage.bNew_fl == false)                                  // This will let the user change the ID if it is brand new record.
                    {
                        FormClear();
                        Header.txtKey_id = key_id;
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtKey_id_Verified)");
            }

            return return_value;
        }

        private bool cmdSetup_Clicked()
        {
            FormPreEvent();

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (SetupPeriod() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdExecute_Clicked()
        {
            FormPreEvent();

            if (FormDialog(cmdExecute_Clicked, 100, User.Language.oMessage.MAY_TAKE_WHILE + User.Language.oMessage.WOULD_LIKE_PROCEED) == false)
            {
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (ExecutePeriod() == false)
            {
                return false;
            }
            
            FormClear();

            FormShowMessage(User.Language.oMessage.EXECUTION_IS_COMPLETE, false);

            return FormPostEvent();
        }
        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool cmdAddMoreLines_Clicked()
        {
            return FormAddMoreRows();
        }

        private bool btnDetailDelete_Clicked(clsDetail.clsGrid cur_item)
        {
            FormPreEvent();

            return FormDeleteCurrentRow(cur_item);
        }

        private bool btnDetailInsert_Clicked(clsDetail.clsGrid cur_item)
        {
            FormPreEvent();

            return FormInsertNewRow(cur_item);
        }

        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

        public bool SetupPeriod()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    return false;
                }
                if (moUtility.ToInteger(Header.cboFirstMonth) == 0)
                {
                    FormShowMessage(User.Language.oCaption.FIRST_MONTH + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("cboFirstMonth");
                    return false;
                }

                if (Header.optPeriods == 12 || Header.optPeriods == 13)
                {
                    if (moSetupAdvisor.CreateFiscalPeriods(Header.txtKey_id, moUtility.ToInteger(Header.cboFirstMonth), Header.optPeriods, ref Detail.Data) == false)
                    {
                        FormShowMessage();
                        return false;
                    }
                }
                else
                {
                    FormShowMessage(User.Language.oMessage.SETUP_IS_FOR_12_AND_13);
                    return false;
                }

                if (FormRecreateGrid() == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(User.Language.oMessage.SETUPPERIOD);
            }

            return return_value;
        }


        public bool ExecutePeriod()
        {

            bool return_value = false;
            string fiscal_year = "";
            int total_periods = 0;
            int cur_period = 0;
            string temp_date = "";
            int last_begin = 0;
            int last_end = 0;
            int last_quarter = 0;
            string sql_str = "";
            bool was_in_trx = false;
            string msg = "";

            try
            {

                was_in_trx = false;

                // If ths status is OPEN, it means this year is being already used.
                // Do not proceed.
                //
                if (moPage.bNew_fl == false && moUtility.ToInteger(Header.txtStatus_typ) >= GlobalVar.goConstant.STATUS_OPEN)
                {
                    FormClear();
                    return return_value;
                }

                if (FormRecreateDetail() == false)
                {
                    return false;
                }

                // Check the basic data.
                //
                if (!FormCheck())
                {
                    return return_value;
                }

                fiscal_year = moUtility.STrim(Header.txtKey_id);

                if (Header.optPeriods <= 13)
                {
                    total_periods = Header.optPeriods;
                }
                else
                {
                    for (total_periods = 0; total_periods < Detail.Data.GetLength(1); total_periods++)
                    {
                        if (moUtility.IsEmpty(Detail.Data[clsSetupAdvisor.PERIOD_BEGIN_COL, total_periods]))
                        {
                            break;
                        }
                    }
                }

                if (0 >= total_periods)
                {
                    FormShowMessage(User.Language.oMessage.NEED_AT_LEAST_ONE_PERIOD);
                    return false;
                }

                // Save the periods first.
                //
                if (FormSave() == false)
                {
                    return false;
                }

                // Activate this year.
                //
                if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (moSetupAdvisor.ActivatePeriods(fiscal_year) == false)
                {
                    if (moDatabase.IsErrorFound())
                    {
                        msg = moDatabase.GetErrorMessage();
                    }
                    msg += " Make sure all stored procudres are compiled correctly.";
                    FormShowMessage(msg);              // 02/18/2025  At the initial stage, "CreateCustomerInARBalance_sp is missing" error message will display. It means the SP's are not placed yet.
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (moDatabase.TransactionCommit() == false)
                {
                    FormShowMessage();
                    moDatabase.TransactionRollback();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                if (was_in_trx)
                {
                    moDatabase.TransactionRollback();
                }

                FormShowMessage(ex.Message + " (ExecutePeriod)");
            }

            return return_value;
        }
    }
}
