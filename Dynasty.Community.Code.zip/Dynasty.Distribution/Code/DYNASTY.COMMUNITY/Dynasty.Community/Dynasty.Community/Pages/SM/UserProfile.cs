﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP.Pages.SM
{
    public partial class UserProfile
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<UserProfile> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;                                                               
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;
        private Models.clsSpreadsheet moSpreadsheet;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsUserProfile moUserProfile;

        private List<Models.clsCombobox> OfficeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> LanguageList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> UserGroupList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> UserTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> LocationList = new List<Models.clsCombobox>();
                
        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader                   
        {
            // Listing of UI items on the header
            //
            public string txtKey_id = "";
            public string txtUser_nm = "";
            public string txtEncriptedPassword = "";
            public string cboOffice_cd = "";
            public string cboUserGroup_cd = "";
            public string cboUserType_id = "";
            public string cboLanguage_cd = "";
            public string txtPassword = "";
            public string txtEmailAddress = "";
            public string txtEmployee_cd = "";
            public string cboLocation_cd = "";
            public string txtIPAddressFrom = "";
            public string txtIPAddressTo = "";
            public string txtPhone1 = "";
            public string txtMobilePhone = "";

            public bool chkRestrictLocation_fl = false;
            public bool chkExpires_fl = false;
            public bool chkAccounting_fl = false;
            public bool chkAdmin_fl = false;
            public bool chkSales_fl = false;
            public bool chkAR_fl = false;
            public bool chkPurchasing_fl = false;
            public bool chkAP_fl = false;
            public bool chkHelpdesk_fl = false;
            public bool chkTemp_fl = false;
            public bool chkWH_fl = false;
            public bool chkDeactivated_fl = false;
            public bool chkJC_fl = false;
            public bool chkMF_fl = false;

            // Datetime component is not very user-friendly, yet, as of VS2019.
            // For better understanding this, read the comment on bUseDatePicker_fl in clsUser.
            //
            public string mskExpiration_dt = "";
            public DateTime? dtExpiration_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag                                                                     
            {
                public string txtKey_id = "";
                public string txtUser_nm = "";
                public string mskExpiration_dt = "";
                public string txtEmployee_cd = "";
                public DateTime? dtExpiration_dt = null;
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()                                                                  
            {
                Tag.txtKey_id = txtKey_id;
                Tag.txtUser_nm = txtUser_nm;
                Tag.txtEmployee_cd = txtEmployee_cd;
                Tag.mskExpiration_dt = mskExpiration_dt;
                Tag.dtExpiration_dt = dtExpiration_dt;
            }
        }
        private clsHeader Header = new clsHeader();

        private string msOriginalPhone = "";
        private string msOriginalMobilePhone = "";
        private string msOriginalEmailAddress = "";


        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;                        
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows()
        {

            return true;
        }

        private bool FormCalculateTotal()
        {

            return true;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            if (FormCheckSecurity() == false)
            {
                return false;
            }
            else if (FormCheckHeader() == false)
            {
                return false;
            }
            else if (FormCheckExtra() == false)
            {
                return false;
            }

            return true;
        }

        private bool FormCheckExtra()                                                              // validate extra other than the header and detail.
        {
            bool return_value = false;
            int max_users = 0;

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                // If max-number of users is set, check it here.  This is for SAAS environment.
                //
                if (moPage.bNew_fl)
                {
                    if (cur_set.CreateSnapshot("SELECT iMaxUsers_num FROM tblGOMaster") == false)
                    {
                        FormShowMessage();
                        return false;
                    }
                    max_users = cur_set.iField("iMaxUsers_num");

                    if (max_users > 0)     // Only if max is set.
                    {
                        if (cur_set.CreateSnapshot("SELECT COUNT(*) AS iCount FROM tblGOUser WHERE sUser_cd <> 'SA'") == false)         // SA is not a part of this company.  It is is the global user-id for SAAS administrator
                        {
                            FormShowMessage();
                            return false;
                        }
                        if (max_users <= cur_set.iField("iCount"))
                        {
                            FormShowMessage(User.Language.oMessage.MAX_ACCOUNTS_HAS_REACHED + " Max = " + max_users.ToString());
                            return false;
                        }
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckExtra)");
            }

            return return_value;
        }

        private bool FormCheckHeader()                                                             // validate the header data.
        {
            bool return_value = false;

            try
            {
                Header.txtUser_nm = moUtility.EvalQuote(moUtility.STrim(Header.txtUser_nm));

                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormShowMessage(User.Language.oCaption.CODE + @User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("txtKey_id");
                    return false;
                }
                else if (moPage.bNew_fl && GlobalVar.goUtility.SLength(Header.txtKey_id) < 5)
                {
                    FormShowMessage(User.Language.oMessage.USER_ID_HAS_TO_BE_AT_LEAST_5_LETTERS);
                    FormSetFocus("txtKey_id");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.txtUser_nm))
                {
                    FormShowMessage(User.Language.oCaption.USER_NAME + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("txtUser_nm");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.txtPhone1))
                {
                    FormShowMessage(User.Language.oCaption.PHONE + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("txtPhone1");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.txtMobilePhone))
                {
                    FormShowMessage(User.Language.oCaption.MOBILE_PHONE + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("txtMobilePhone");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.txtEmailAddress))
                {
                    FormShowMessage(User.Language.oCaption.EMAIL_ADDRESS + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("txtEmailAddress");
                    return false;
                }

                if (moDatabase.CommunityVersion == false)
                {
                    if (moUtility.IsEmpty(Header.cboOffice_cd))
                    {
                        FormShowMessage(User.Language.oCaption.OFFICE + User.Language.oMessage.IS_REQUIRED);
                        FormSetFocus("cboOffice_cd");
                        return false;
                    }
                }

                if (moUtility.IsEmpty(Header.cboUserGroup_cd))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_SELECT_A_USER_GROUP);
                    FormSetFocus("cboUserGroup_cd");
                    return false;
                }
                else if (moUtility.ToInteger(Header.cboUserType_id) == 0)
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER + User.Language.oCaption.USER_SECURITY_TYPE);
                    FormSetFocus("cboUserType_id");
                    return false;
                }
                else if (moUtility.ToInteger(Header.cboUserType_id) == clsConstant.USER_VIEW_ONLY_TYPE && Header.chkExpires_fl == false)
                {
                    Header.chkExpires_fl = true;
                }

                if (moPage.bNew_fl && GlobalVar.goUtility.SLength(Header.txtPassword) < 5)
                {
                    FormShowMessage(User.Language.oMessage.PASSWORD_SHOULD_BE_5_LETTERS_AT_LEAST);
                    FormSetFocus("txtPassword");
                    return false;
                }
                if (Header.chkExpires_fl && moGeneral.IsValidDate(Header.mskExpiration_dt) == false)
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_A_VALID_DATE);

                    if (User.bUseDatePicker_fl)
                    {
                        FormSetFocus("dtExpiration_dt");
                    }
                    else
                    {
                        FormSetFocus("mskExpiration_dt");
                    }

                    return false;
                }

                Header.txtIPAddressTo = moUtility.STrim(Header.txtIPAddressTo);
                Header.txtIPAddressFrom = moUtility.STrim(Header.txtIPAddressFrom);

                if (moUtility.IsEmpty(Header.txtIPAddressTo))
                {
                    Header.txtIPAddressTo = Header.txtIPAddressFrom;
                }
                else if (moUtility.IsEmpty(Header.txtIPAddressFrom))
                {
                    Header.txtIPAddressFrom = Header.txtIPAddressTo;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckHeader)");
            }

            return return_value;
        }

        private bool FormCheckConcurrency(clsRecordset cur_set)                                    // Check if someone has changed this record while it is open in this session.
        {
            if (cur_set.IsNonEmpty()) 
            {
                if (moPage.bNew_fl)
                {
                    // If someone has created a record with the same key
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.DUPLICATE_IS_FOUND + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                    moPage.bNew_fl = false;
                }
                else if (moPage.CheckForConcurrency(cur_set) == false)
                {
                    // If someone has updated this record in the meantime.
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        private bool FormCheckToDelete()
        {
            clsIntegrity o_integrity = new clsIntegrity(ref moDatabase);

            if (FormCheckSecurity() == false)
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }
            else if (modFormUtility.IsReservedRecord(ref moDatabase, Header.txtKey_id, moPage.bReserved_fl))
            {
                FormShowMessage(User.Language.oMessage.RESERVED_RECORD_IS_NOT_ALLOWED_TO_DELETE);
                return false;
            }
            else if (o_integrity.IsReferenced(moPage.sModule_id, moPage.sKeyField_nm, Header.txtKey_id))
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }

            return true;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearExtra();

            return true;
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            msOriginalPhone = "";
            msOriginalMobilePhone = "";
            msOriginalEmailAddress = "";

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {
            Header.txtKey_id = "";
            Header.txtUser_nm = "";
            Header.txtEncriptedPassword = "";
            Header.cboOffice_cd = "";
            Header.cboUserGroup_cd = "";
            Header.cboUserType_id = "";
            Header.cboLanguage_cd = "";
            Header.txtPassword = "";
            Header.txtEmailAddress = "";
            Header.txtEmployee_cd = "";
            Header.cboLocation_cd = "";
            Header.txtIPAddressFrom = "";
            Header.txtIPAddressTo = "";
            Header.txtPhone1 = "";
            Header.txtMobilePhone = "";

            Header.chkExpires_fl = false;
            Header.chkRestrictLocation_fl = false;

            Header.chkAccounting_fl = false;
            Header.chkAdmin_fl = false;
            Header.chkSales_fl = false;
            Header.chkAR_fl = false;
            Header.chkPurchasing_fl = false;
            Header.chkAP_fl = false;
            Header.chkHelpdesk_fl = false;
            Header.chkTemp_fl = false;
            Header.chkWH_fl = false;
            Header.chkJC_fl = false;
            Header.chkMF_fl = false;
            Header.chkDeactivated_fl = false;

            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            //
            Header.mskExpiration_dt = "";
            Header.dtExpiration_dt = null;
            FormSyncDates(false);

            return true;
        }

        private bool FormClearMessage()                                                            
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id) || moPage.bNew_fl)
                {
                    FormClear();
                    return true;
                }
                else if (FormCheckToDelete() == false)
                {
                    return false;
                }

                // Transaction begins here.
                //
                if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }

                if (modFormUtility.RecordDelete(ref moDatabase, moPage.iScreen_typ, Header.txtKey_id, moPage.sKeyField_nm, moPage.sTable_nm, moPage.sDetailTable_nm, moPage.sRestrictionClause, moPage.iTransaction_typ) == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }
                else if (FormDeleteExtra() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }

                // Transaction ends here.
                //
                if (moDatabase.TransactionCommit() == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDelete)");
                moDatabase.TransactionRollback();
                return_value = false;
            }

            return return_value;
        }

        private bool FormDeleteExtra()
        {

            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormFindRecord(ref clsRecordset cur_set, int matching_type = 0)
        {
            bool return_value = false;
            string restriction_clause;

            matching_type = moUtility.IIf(matching_type > 0, matching_type, GlobalVar.goConstant.MATCHING_RECORD_TYPE);

            restriction_clause = moPage.sRestrictionClause;

            if (matching_type != GlobalVar.goConstant.MATCHING_RECORD_TYPE)
            {
                if (moUtility.IsEmpty(restriction_clause))
                {
                    restriction_clause = "sUser_cd <> 'SA'";
                }
                else
                {
                    restriction_clause += " AND sUser_cd <> 'SA'";
                }
            }

            return_value = modFormUtility.RecordRead(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sTable_nm, moPage.sKeyField_nm, moPage.sPreviousKey_id, restriction_clause, ref matching_type);

            return return_value;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moUserProfile = new clsUserProfile(ref moDatabase);

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.SMMENU_NAME;
            moPage.Title = User.Language.oCaption.USER_PROFILE;
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormInitHeader();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = "tblGOUser"; 
            moPage.sKeyField_nm = "sUser_cd";
            moPage.iTransaction_typ= 0;
            moPage.sKeyDescription = "sUser_nm";

            return true;
        }

        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {
            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            // FormSave() & FormCheck() use the plain textbox whose name starts with "msk"
            // dt* variables are only to interact with UI.  Internally, msk* fields are used.
            //
            FormSyncDates(User.bUseDatePicker_fl);

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback
            
            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;

            try 
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                modLoadUtility.LoadUserGroup(ref moDatabase, ref UserGroupList);
                modLoadUtility.LoadUserType(ref moDatabase, ref UserTypeList);
                modLoadUtility.LoadOffice(ref moDatabase, ref OfficeList);
                modLoadUtility.LoadLanguage(ref moDatabase, ref LanguageList);
                modLoadUtility.LoadLocationCode(ref moDatabase, ref LocationList);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormMove(int record_move_direction)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormClear();

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            if (FormFindRecord(ref cur_set, record_move_direction) == false)
            {
                return false;
            }

            FormShow(cur_set);
            return true;

        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostSave()
        {
            // If this is a transaction page, and transaction number has changed, let the user know.
            //
            if (moPage.sPreviousKey_id != Header.txtKey_id)
            {
                FormShowMessage(User.Language.oMessage.TRX_NUM_HAS_CHANGED_TO + "  " + Header.txtKey_id, false);
            }

            moPage.sPreviousKey_id = Header.txtKey_id;

            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {

            return true;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            if (moGeneral.IsValidDate(Header.mskExpiration_dt) || moUtility.IsDate(Header.dtExpiration_dt))
            {
                Header.chkExpires_fl = true;
            }

            return true;
        }

        private bool FormSave()
        {
            bool return_value = false;
            clsRecordset cur_set;

            try
            {
                if (FormOpenDatabase() == false)                     // Has to come before FormCheck()
                {
                    return false;
                }
                else if (FormCheck() == false)                       // Check if data is ok to save.
                {
                    return false;
                }

                moPage.sPreviousKey_id = Header.txtKey_id;
                cur_set = new clsRecordset(ref moDatabase);

                if (modFormUtility.RecordOpen(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sRestrictionClause, moPage.sTable_nm, moPage.sKeyField_nm) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormCheckConcurrency(cur_set) == false)
                {
                    return false;
                }
                else if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormPreSave(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveHeader(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveExtra(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (moUserProfile.Save() == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }
                else if (moDatabase.TransactionCommit() == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }

                FormPostSave();
                    
                return_value = true;

            }
            catch (Exception ex)
            {

                FormShowMessage(ex.Message + " (FormSave)");
                moDatabase.TransactionRollback();

            }

            return return_value;
        }

        private bool FormSaveExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                if (UpdateUserEmployee() == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveExtra)");
            }

            return return_value;
        }

        private bool FormSaveHeader(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                // This is for Concurrency check to go smooth.
                // If someone calls FormSave() without going thru the whole saving routine that
                // clears the screen, and save again later, then FormCheckConcurrency() will raise an error
                // because the record in the database has been updated but moPage.Original.dtLastUpdate_dt still has the old timestamp.
                //
                moPage.Original.sLastUpdate_id = moDatabase.sUser_cd;
                moPage.Original.dtLastUpdate_dt = DateTime.Now;

                moUserProfile.bNew_fl = (moPage.bNew_fl || cur_set.EOF());

                moUserProfile.sUser_cd = Header.txtKey_id;

                if (moUserProfile.bNew_fl)
                {
                    moUserProfile.sPassword = moUtility.PasswordEncode(Header.txtPassword);
                }

                moUserProfile.iReserved_fl = moUtility.IIf(moPage.bReserved_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moUserProfile.sOffice_cd = Header.cboOffice_cd;
                moUserProfile.sLanguage_cd = Header.cboLanguage_cd;
                moUserProfile.sUserGroup_cd = Header.cboUserGroup_cd;
                moUserProfile.sUser_nm = moUtility.EvalQuote(Header.txtUser_nm);
                moUserProfile.iUserType_id = moUtility.ToInteger(Header.cboUserType_id);
                moUserProfile.sEmailAddress = moUtility.EvalQuote(Header.txtEmailAddress);
                moUserProfile.iExpiration_dt = moGeneral.ToNumDate(Header.mskExpiration_dt);
                moUserProfile.sEmployee_cd = Header.txtEmployee_cd;
                moUserProfile.sLocation_cd = Header.cboLocation_cd;
                moUserProfile.iRestrictLocation_fl = moUtility.IIf(Header.chkRestrictLocation_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moUserProfile.sIPAddressFrom = Header.txtIPAddressFrom;
                moUserProfile.sIPAddressTo = Header.txtIPAddressTo;
                moUserProfile.sPhone1 = Header.txtPhone1;
                moUserProfile.sMobilePhone = Header.txtMobilePhone;

                moUserProfile.iAdmin_fl = moUtility.IIf(Header.chkAdmin_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moUserProfile.iAccounting_fl = moUtility.IIf(Header.chkAccounting_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moUserProfile.iSales_fl = moUtility.IIf(Header.chkSales_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moUserProfile.iAR_fl = moUtility.IIf(Header.chkAR_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moUserProfile.iPurchasing_fl = moUtility.IIf(Header.chkPurchasing_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moUserProfile.iAP_fl = moUtility.IIf(Header.chkAP_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moUserProfile.iHelpdesk_fl = moUtility.IIf(Header.chkHelpdesk_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moUserProfile.iWH_fl = moUtility.IIf(Header.chkWH_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moUserProfile.iJC_fl = moUtility.IIf(Header.chkJC_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moUserProfile.iMF_fl = moUtility.IIf(Header.chkMF_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);

                moUserProfile.iTemp_fl = moUtility.IIf(Header.chkTemp_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);

                moUserProfile.iDeactivated_fl = moUtility.IIf(Header.chkDeactivated_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);

                moUserProfile.sLastUpdate_id = moPage.Original.sLastUpdate_id;
                moUserProfile.dtLastUpdate_dt = moPage.Original.dtLastUpdate_dt;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveHeader)");
            }

            return return_value;
        }

        private bool FormSearch()
        {

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {
            if (FormShowHeader(cur_set) == false)
            {
                return false;
            }
            else if (FormShowExtra(cur_set) == false)
            {
                return false;
            }

            FormReArrangeHeader();

            return true;
        }

        private bool FormShowExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                moPage.Clear();
                moPage.PreserveTimestamp(cur_set);
                moPage.bNew_fl = false;

                msOriginalPhone = cur_set.sField("sPhone1");
                msOriginalMobilePhone = cur_set.sField("sMobilePhone");
                msOriginalEmailAddress = cur_set.sField("sEmailAddress");

                // This is where bReadOnly_fl & bReserved_fl are set according to the nature of the current record.
                //
                moPage.bReserved_fl = (cur_set.iField("iReserved_fl") > 0);
                
                moPage.sPreviousKey_id = Header.txtKey_id;
                Header.Preserve();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowHeader(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                Header.txtKey_id = cur_set.sField(moPage.sKeyField_nm);
                Header.txtUser_nm = cur_set.sField("sUser_nm");
                Header.txtEmailAddress = cur_set.sField("sEmailAddress");
                Header.txtEmployee_cd = cur_set.sField("sEmployee_cd");
                Header.chkRestrictLocation_fl = (cur_set.iField("iRestrictLocation_fl") == GlobalVar.goConstant.FLAG_ON);

                Header.txtIPAddressFrom = cur_set.sField("sIPAddressFrom");
                Header.txtIPAddressTo = cur_set.sField("sIPAddressTo");

                Header.chkAccounting_fl = (cur_set.iField("iAccounting_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkAdmin_fl = (cur_set.iField("iAdmin_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkSales_fl = (cur_set.iField("iSales_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkAR_fl = (cur_set.iField("iAR_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkPurchasing_fl = (cur_set.iField("iPurchasing_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkAP_fl = (cur_set.iField("iAP_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkHelpdesk_fl = (cur_set.iField("iHelpdesk_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkTemp_fl = (cur_set.iField("iTemp_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkWH_fl = (cur_set.iField("iWH_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkJC_fl = (cur_set.iField("iJC_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkMF_fl = (cur_set.iField("iMF_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkDeactivated_fl = (cur_set.iField("iDeactivated_fl") == GlobalVar.goConstant.FLAG_ON);

                Header.cboUserGroup_cd = cur_set.sField("sUserGroup_cd");
                Header.cboUserType_id = cur_set.iField("iUserType_id").ToString();
                Header.cboLocation_cd = cur_set.sField("sLocation_cd");
                Header.cboOffice_cd = cur_set.sField("sOffice_cd");
                Header.cboLanguage_cd = cur_set.sField("sLanguage_cd");

                Header.txtPhone1 = cur_set.sField("sPhone1");
                Header.txtMobilePhone = cur_set.sField("sMobilePhone");

                // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
                // Make sure both, dt* and msk*, are sync'ed.
                //
                Header.mskExpiration_dt = moGeneral.ToStrDate(cur_set.iField("iExpiration_dt"));
                FormSyncDates(false);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowHeader)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowListing()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moListing.Show(moDatabase, moPage) == false)
            {
                return false;
            }

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtExpiration_dt, ref Header.mskExpiration_dt, use_date_picker);

            return true;
        }
        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moZoom.Caller == "txtEmployee_cd")
            {
                if (moZoom.Code(ref moDatabase, "tblGOEmployee", "sEmployee_nm") == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormClear();
                return true;
            }

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
                {
                    return false;
                }
            }

            FormCancel();
            return true;
        }

        private bool btnDelete_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormClear();
                return true;
            }

            if (FormDialog(btnDelete_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_DELETE) == false)
            {
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (FormDelete() == false)
            {
                return false;
            }
            
            FormClear();
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormExit();
                return true;
            }

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }

        private bool btnFirst_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnFirst_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.FIRST_RECORD_TYPE);
        }

        private bool btnLast_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnLast_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.LAST_RECORD_TYPE);
        }

        private bool btnNext_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnNext_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.NEXT_RECORD_TYPE);
        }

        private bool btnPrevious_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnPrevious_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.PREVIOUS_RECORD_TYPE);
        }

        private bool btnSave_Clicked()
        {
            FormPreEvent();

            if (FormSave() == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewHeader_Clicked()
        {
            FormPreEvent();                                                                           
            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool cmdViewListing_Clicked()
        {
            FormPreEvent();       
            
            if (FormShowListing() == false)
            {
                return false;
            }

            FormSwitchView(moView.LISTING_PAGE_NUM);
            return true;

        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnListingSelect_Clicked(Models.clsListing.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.IsEmpty(cur_item.Code))
            {
                return false;
            }

            FormClear();
            Header.txtKey_id = cur_item.Code;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                if (moUtility.IsEmpty(cur_item.Col_0))
                {
                    return false;
                }

                code_selected = cur_item.Col_0;

                if (moZoom.Caller == "txtEmployee_cd")
                {
                    Header.txtEmployee_cd = code_selected;
                    if (txtEmployee_cd_Changed() == false)
                    {
                        return false;
                    }
                }

                FormSwitchView(moZoom.iView);

                return_value = FormPostEvent();
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();                                                                   

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }
        private bool btnZoomOnEmployee_cd_Clicked()
        {
            FormPreEvent();

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtEmployee_cd", -1, -1, moView.MAIN_PAGE_NUM, "sEmployee_cd", "") == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Changed()
        {
            Header.txtKey_id = modCommonUtility.CleanCode(Header.txtKey_id);

            if (Header.txtKey_id == Header.Tag.txtKey_id)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (txtKey_id_Verified() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool mskExpiration_dt_Changed()
        {
            if (Header.mskExpiration_dt == Header.Tag.mskExpiration_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.IsValidDate(Header.mskExpiration_dt) == false)
            {
                Header.mskExpiration_dt = Header.Tag.mskExpiration_dt;
                FormShowMessage(User.Language.oCaption.LAST_CONTACT_DATE + User.Language.oMessage.IS_INVALID);
                FormSetFocus("mskExpiration_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtExpiration_dt_Changed()
        {
            if (Header.dtExpiration_dt == Header.Tag.dtExpiration_dt)
            {
                return true;
            }

            FormPreEvent();                                                                     // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtExpiration_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtExpiration_dt);   // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtExpiration_dt) == false)
            {
                Header.dtExpiration_dt = Header.Tag.dtExpiration_dt;
                FormShowMessage(User.Language.oCaption.NEXT_CONTACT_DATE + User.Language.oMessage.IS_INVALID);
                FormSetFocus("dtExpiration_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool txtEmployee_cd_Changed()
        {
            clsRecordset cur_set = new clsRecordset(ref moDatabase);
            string sql_str = "";

            Header.txtEmployee_cd = modCommonUtility.CleanCode(Header.txtEmployee_cd);

            if (Header.txtEmployee_cd == Header.Tag.txtEmployee_cd)
            {
                return true;
            }

            FormPreEvent();                                                                     // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if(moUtility.IsEmpty(Header.txtEmployee_cd))
            {
                return FormPostEvent();
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moValidate.IsValidEmployeeCode(Header.txtEmployee_cd) == false)
            {
                FormShowMessage(Header.txtEmployee_cd + User.Language.oMessage.IS_INVALID);
                Header.txtEmployee_cd = Header.Tag.txtEmployee_cd;
                return false;
            }

            if (moUtility.IsEmpty(Header.txtKey_id))            // in search mode
            {
                moValidate.Release();
                return true;
            }

            sql_str = "SELECT * FROM tblGOUser WHERE sEmployee_cd = '" + Header.txtEmployee_cd + "'";

            if (cur_set.CreateSnapshot(sql_str) == false)
            {
                FormShowMessage();
                Header.txtEmployee_cd = Header.Tag.txtEmployee_cd;
                return false;
            }

            if (cur_set.sField("sUser_cd") != Header.txtKey_id)
            {
                FormShowMessage(Header.txtEmployee_cd + User.Language.oMessage.IS_ALREADY_IN_USE);
                Header.txtEmployee_cd = Header.Tag.txtEmployee_cd;
                return false;
            }

            Header.txtEmailAddress = moValidate.oRecordset.sField("sEmailAddress");
            Header.txtPhone1 = moValidate.oRecordset.sField("sPhone1");
            Header.txtMobilePhone = moValidate.oRecordset.sField("sMobilePhone");

            return FormPostEvent();
        }

        private bool chkExpires_fl_Clicked()
        {
            FormPreEvent();   

            if (Header.chkExpires_fl)
            {
                Header.mskExpiration_dt = "";
                Header.dtExpiration_dt = null;
            }

            return FormPostEvent();
        }

        private bool txtUser_nm_Changed()
        {
            Header.txtUser_nm = moUtility.EvalQuote(moUtility.STrim(Header.txtUser_nm));

            if (Header.txtUser_nm == Header.Tag.txtUser_nm)
            {
                return true;
            }

            FormPreEvent();

            return FormPostEvent();
        }

        private bool cmdResetPassword_Clicked()
        {
            string new_password = "";

            FormPreEvent();

            if (moPage.bNew_fl || moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }

            if (FormDialog(cmdResetPassword_Clicked, 1000, "This will reset the password." + User.Language.oMessage.WOULD_LIKE_PROCEED) == false)
            {
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moGeneral.ResetPassword(Header.txtKey_id, ref new_password))
            {
                FormShowMessage("The password has changed to " + new_password, false);
            }
            else
            {
                if (moDatabase.IsErrorFound())
                {
                    FormShowMessage();
                }
                else
                {
                    FormShowMessage("Resetting the password has failed.");
                }
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Verified()
        {
            bool return_value = false;
            clsRecordset cur_set;
            string key_id = "";
            int char_num = 0;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormClear();
                    return true;
                }

                key_id = Header.txtKey_id;

                if (Header.txtKey_id == GlobalVar.goConstant.SYSTEM_ADMINISTRATOR && User.sUser_cd != GlobalVar.goConstant.SYSTEM_ADMINISTRATOR)
                {
                    FormShowMessage(Header.txtKey_id + User.Language.oMessage.IS_INVALID);
                    Header.txtKey_id = Header.Tag.txtKey_id;
                    FormSetFocus("txtKey_id");
                    return false;
                }

                if (FormOpenDatabase() == false)
                {
                    FormClear();
                    FormShowMessage(User.Language.oMessage.CONNECTION_HAS_FAILED);
                    return false;
                }

                cur_set = new clsRecordset(ref moDatabase);

                if (FormFindRecord(ref cur_set))
                {
                    FormShow(cur_set);
                }
                else
                {
                    if (moPage.bNew_fl == false)                                  // This will let the user change the ID if it is brand new record.
                    {
                        FormClear();
                        Header.txtKey_id = key_id;
                    }

                    if (moUtility.ValidUserIdAndPassword(key_id) == false)
                    {
                        FormShowMessage(User.Language.oMessage.USER_ID_PASSWARD_CAN_INCLUDE);
                        FormClear();
                        FormSetFocus("txtKey_id");
                        return false;
                    }

                    if (moPage.bNew_fl)
                    {
                        Header.txtPassword = Header.txtKey_id;      // Initially, set to the user-id
                    }

                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtKey_id_Verified)");
            }

            return return_value;
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================


        private bool UpdateUserEmployee()
        {
            bool return_value = false;
            string sql_str = "";

            try
            {
                sql_str = "UPDATE tblGOEmployee SET";
                sql_str += " sEmailAddress = '" + moUtility.EvalQuote(Header.txtEmailAddress) + "'";
                sql_str += ",sPhone1 = '" + moUtility.EvalQuote(Header.txtPhone1) + "'";
                sql_str += ",sMobilePhone = '" + moUtility.EvalQuote(Header.txtMobilePhone) + "'";
                sql_str += " WHERE sEmployee_cd = '" + Header.txtEmployee_cd + "'";
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PrepListingDownload)");
            }

            return return_value;
        }
    }
}
