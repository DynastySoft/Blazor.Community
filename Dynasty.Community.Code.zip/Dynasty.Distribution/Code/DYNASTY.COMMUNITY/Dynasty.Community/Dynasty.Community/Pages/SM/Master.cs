﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Local;
using Dynasty.ASP.Shared;

namespace Dynasty.ASP.Pages.SM
{
    public partial class Master
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<Master> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;                                                               
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;
        private Models.clsSpreadsheet moSpreadsheet;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        private bool DisableBatch
        {
            get
            {
                return (Header.cboVersion_nm.ToString() != GlobalVar.goConstant.ENMENU_NAME && Header.cboVersion_nm.ToString() != GlobalVar.goConstant.PLMENU_NAME
                     && Header.cboVersion_nm.ToString() != GlobalVar.goConstant.SSMENU_NAME);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsMoney moMoney;
        private clsBatch moBatch;

        private int miCurrentYearBegin_dt = 0;
        private int miCurrentYearEnd_dt = 0;
        private int miOriginalBusiness_typ = 0;
        private int miOriginalCommitHold_fl = 0;
        private int miOriginalMaxBins_num = 0;
        private int miOriginalInventoryCost_typ = 0;
        private int miAllowQuantityAllocation = 0;
        private string msOriginalFiscalYear = "";                                                   // 02/18/2025

        private bool mbSAASInProduction_fl = false;                                                 // True : if this is SAAS version and in production

        private List<Models.clsCombobox> CountryCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> PeriodList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> BusinessTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> AccountingTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> DynastyVersionList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CostMethodList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> OversoldTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CurrencyList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> TaxTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> TotalBinList = new List<Models.clsCombobox>();

        private int miInvoiceNumbering_typ = 0;
        private readonly int INVOICE_NUMBERING_REGULAR = 1;
        private readonly int INVOICE_NUMBERING_BY_CUSTOMER = 2;
        private readonly int INVOICE_NUMBERING_BY_JOB = 3;
        private readonly int INVOICE_NUMBERING_EDITABLE = 4;


        private bool mbOriginalWHExist_fl = false;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader                   
        {
            // Listing of UI items on the header
            //
            public int optFreight_typ = 0;
            public int optAddress_typ = 0;
            public int optMoney_typ = 0;
            public int optDate_typ = 0;
            public int optProcessing_typ = 0;
            public int optRestrictByPeriod_fl = 0;
            public int optBudget_typ = 0;
            public int optGLAcctCode_typ = 0;

            public string txtCompany_nm = "";
            public string txtAddress1 = "";
            public string txtAddress2 = "";
            public string txtCity = "";
            public string txtState = "";
            public string txtZipCode = "";
            public string txtPhone = "";
            public string txtFax = "";
            public string txtFiscalYear = "";
            public string txtCompany_id = "";
            public string txtGLAcctCodeFormat = "";
            public string txtGLAcctCodeLength = "";
            public string txtSMTPServer_nm = "";
            public string txtLocalAM = "";
            public string txtLocalPM = "";
            public string txtMarkup_rt = "";
            public string txtFinancialChargeRate = "";
            public string mskEarningAcct_cd = "";
            public string txtLateCharge_amt = "";

            public string txtInvoice_num = "";
            public string txtCM_num = "";
            public string txtVoucher_num = "";
            public string txtDM_num = "";
            public string txtSO_num = "";
            public string txtQuote_num = "";
            public string txtPO_num = "";

            public string cboCurrency_cd = "";
            public string cboCountry_cd = "";
            public string cboBusiness_typ = "";
            public string cboOversold_typ = "";
            public string cboAccounting_typ = "";
            public string cboInventoryCost_typ = "";
            public string cboSalesTax_typ = "";
            public string cboVersion_nm = "";
            public string cboPriceCurrency_cd = "";
            public string cboCurPeriod = "";
            public string cboMaxBins_num = "";

            public string txtMaxQuick_amt = "";
            public string txtSystemEmailAddress = "";
            public string txtSystemEmailPassword = "";
            public string txtSystemEmailPort_num = "";

            public bool chkDoNotSummarizeAccountsInPosting_fl = false;
            public bool chkCalcCommissionByItem_fl = false;
            public bool chkTrackRevenueByCustomer_fl = false;
            public bool chkMarkupItems_fl = false;

            public bool chkSystemEmailUseSSL_fl = false;
            public bool chkUseCalendarYearForDepreciation_fl = false;
            public bool chkCommitHold_fl = false;
            public bool chkDoNotTrackLot_fl = false;
            public bool chkDoNotTrackSerial_fl = false;
            public bool chkEnableAFT_fl = false;
            public bool chkEnablePageLevelSecurity_fl = false;

            public bool chkGLExist_fl = false;
            public bool chkIVExist_fl = false;
            public bool chkARExist_fl = false;
            public bool chkSOExist_fl = false;
            public bool chkAPExist_fl = false;
            public bool chkPOExist_fl = false;
            public bool chkBRExist_fl = false;
            public bool chkJCExist_fl = false;
            public bool chkPRExist_fl = false;
            public bool chkFAExist_fl = false;
            public bool chkWHExist_fl = false;
            public bool chkMCExist_fl = false;
            public bool chkMFExist_fl = false;
            public bool chkCMExist_fl = false;
            public bool chkWOExist_fl = false;
            public bool chkNPExist_fl = false;
            public bool chkRTExist_fl = false;
            public bool chkIEExist_fl = false;

            public bool chkDoNotClosePeriod_fl = false;
            public bool chkIncludeSerialInInvoice_fl = false;

            public bool chkBlockAccountBalance_fl = false;
            public bool chkUseMatrixForm_fl = false;
            public bool chkApplyCustomerPricing_fl = false;
            public bool chkShowItemPrice_fl = false;
            public bool chkBlockItemPrice_fl = false;
            public bool chkBlockPaymentDiscount_fl = false;
            public bool chkBlockTransaction_fl = false;
            public bool chkLockClosedPeriods_fl = false;
            public bool chkAllowQuantityAllocation_fl = false;
            public bool chkPrintDetailsOnCheckStub_fl = false;
            public bool chkLockPrintedInvoice_fl = false;

            public bool chkShowOriginalQtyOrdered_fl = false;
            public bool chkEnableBatchEntry_fl = false;

            public bool chkFreightTax_fl = false;
            public bool chkTaxIsDiscountable_fl = false;
            public bool chkFreightIsDiscountable_fl = false;
            public bool chkPrimaryRule_fl = false;
            public bool chkAllowItemCodeChange_fl = false;
            public bool chkEditableInvoiceNumber_fl = false;
            public bool chkInvoiceNumberingByCustomer_fl = false;
            public bool chkInvoiceNumberingByJob_fl = false;

            public bool chkLockRentalAtBilling_fl = false;
            public string txtSecurityDeposit_pc = "";
            public string txtFirstPayment_pc = "";
            public bool chkInspectReturn_fl = false;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag                                                                     
            {
                public string txtFiscalYear = "";
                public string cboVersion_nm = "";
                public string mskEarningAcct_cd = "";
                public string txtFinancialChargeRate = "";
                public string txtLateCharge_amt = "";

            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()                                                                  
            {
                Tag.txtFiscalYear = txtFiscalYear;
                Tag.cboVersion_nm = cboVersion_nm;
                Tag.mskEarningAcct_cd = mskEarningAcct_cd;
                Tag.txtFinancialChargeRate = txtFinancialChargeRate;
                Tag.txtLateCharge_amt = txtLateCharge_amt;
            }
        }
        private clsHeader Header = new clsHeader();                                                 


        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;                        
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows()
        {

            return true;
        }

        private bool FormCalculateTotal()
        {

            return true;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            if (FormCheckSecurity() == false)
            {
                return false;
            }
            else if (FormCheckHeader() == false)
            {
                return false;
            }
            else if (FormCheckExtra() == false)
            {
                return false;
            }

            return true;
        }

        private bool FormCheckExtra()                                                              // validate extra other than the header and detail.
        {
            bool return_value = false;
            string trx_list = "";
            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                

                if (miOriginalBusiness_typ > 0 && miOriginalBusiness_typ != moUtility.ToInteger(Header.cboBusiness_typ))
                {
                    if (miOriginalBusiness_typ == GlobalVar.goConstant.NP_BUSINESS_NUM || moUtility.ToInteger(Header.cboBusiness_typ) == GlobalVar.goConstant.NP_BUSINESS_NUM)
                    {
                        if (moGeneral.ReadNextNumber(GlobalVar.goConstant.TRX_JOURNAL_TYPE) > 1)
                        {
                            FormShowMessage(User.Language.oMessage.YOU_CANNOT_CHANGE_BUSINESS_TYPE);
                            return false;
                        }
                    }
                }

                if ((moDatabase.bUseFullAccountCode_fl && Header.optGLAcctCode_typ == 0) || (!moDatabase.bUseFullAccountCode_fl && Header.optGLAcctCode_typ == 1))
                {
                    if (moGeneral.UnpostedJournalExist())
                    {
                        return false;
                    }
                }

                if (miOriginalCommitHold_fl != moUtility.IIf(Header.chkCommitHold_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF))
                {
                    if (moGeneral.GetInventoryTransactionOnHold(ref trx_list) == false)
                    {
                        FormShowMessage();
                        return false;
                    }
                    else if (moUtility.IsNonEmpty(trx_list))
                    {
                        FormShowMessage("In order to reset '" + @User.Language.oCaption.STATUS_HOLD_COMMITS_QUANTITY + "' option, you need to change the hold status of " + trx_list);
                        return false;
                    }
                }

                // If W/H is implemented, serial/lot are not tracked for NOW.
                // 09/04/2020  Let them do it.  But, at W/H, serial/lot numbers are not tracked.  They should be handled at invoice/voucher pages.
                //
                //if (Header.chkWHExist_fl)
                //{
                //    Header.chkDoNotTrackLot_fl = true;
                //    Header.chkDoNotTrackSerial_fl = true;
                //}

                if (Header.optProcessing_typ == GlobalVar.goConstant.REALTIME_MODE_NUM)
                {
                    if (Header.chkWHExist_fl && (Header.chkARExist_fl || Header.chkAPExist_fl))
                    {
                        FormShowMessage(User.Language.oMessage.REALTIME_PROCESSING_NOT_ALLOWED_WHEN_WH_IS_IMPLEMENTED);
                        return false;
                    }
                    else if (Header.chkEnableBatchEntry_fl)
                    {
                        FormShowMessage(User.Language.oMessage.REALTIME_PROCESSING_DOES_NOT_ALLOW_BATCH_ENTRY);
                        return false;
                    }
                }

                // AVG-cost method can change to any other method, but not vice versa
                //
                if (miOriginalInventoryCost_typ > 0 && miOriginalInventoryCost_typ != GlobalVar.goIVConstant.AVG_COST_NUM && moUtility.ToInteger(Header.cboInventoryCost_typ) == GlobalVar.goIVConstant.AVG_COST_NUM)
                {
                    if (moValidate.IsValidRecord("SELECT sItem_cd, COUNT(*) AS iCount FROM tblIVCost GROUP BY sItem_cd") == false)
                    {
                        FormShowMessage();
                        return false;
                    }

                    while (moValidate.oRecordset.EOF() == false)
                    {
                        if (moValidate.oRecordset.iField("iCount") > 1)     // If any one item has more then one layer, do not change to AVG-method
                        {
                            FormShowMessage(User.Language.oMessage.YOU_CANNOT_CHANGE_INVENTORY_COST_METHOD_WHEN_INVENTORY_EXIST);
                            return false;
                        }
                        moValidate.oRecordset.MoveNext();
                    }
                }

                // Module-dependancies
                //
                if (Header.chkARExist_fl == false)
                {
                    Header.chkSOExist_fl = false;
                }

                if (Header.chkAPExist_fl == false)
                {
                    Header.chkPOExist_fl = false;
                }

                if (Header.chkFAExist_fl == false)
                {
                    Header.chkRTExist_fl = false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckExtra)");
            }

            return return_value;
        }

        private bool FormCheckHeader()                                                             // validate the header data.
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtCompany_nm))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_THE_COMPANY_NAME);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("txtCompany_nm");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.txtFiscalYear))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_THE_FISCAL_YEAR);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("txtFiscalYear");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboCurPeriod))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_SELECT_THE_CURRENT_PERIOD);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboCurPeriod");
                    return false;
                }
                else if (moGeneral.ToNumDate(moUtility.SLeft(Header.cboCurPeriod, 10)) > moGeneral.CurrentDate())
                {
                    FormShowMessage(User.Language.oMessage.FUTURE_DATE_IS_NOT_ALLOWED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboCurPeriod");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboBusiness_typ))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_SELECT_THE_BUSINESS_TYPE);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboBusiness_typ");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboCountry_cd))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_SELECT_THE_COUNTRY_CODE);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboCountry_cd");
                    return false;
                }
                
                if (moUtility.IsEmpty(Header.cboVersion_nm))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_SELECT + User.Language.oCaption.DYNASTY_VERSION_MODULES);
                    FormSwitchView(moView.SYSTEM_OPTION_PAGE_NUM);
                    FormSetFocus("cboVersion_nm");
                    return false;
                }
                else if (moUtility.ToInteger(Header.cboInventoryCost_typ) == 0)
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER + User.Language.oCaption.COST_METHOD);
                    FormSwitchView(moView.SYSTEM_OPTION_PAGE_NUM);
                    FormSetFocus("cboInventoryCost_typ");
                    return false;
                }

                // Check if the initial numbers are valid.
                //
                if (moUtility.ToInteger(Header.txtInvoice_num) <= 0)
                {
                    FormShowMessage(Header.txtInvoice_num + User.Language.oMessage.IS_INVALID);
                    FormSwitchView(moView.SYSTEM_OPTION_PAGE_NUM);
                    FormSetFocus("txtInvoice_num");
                    return false;
                }
                else if (moUtility.ToInteger(Header.txtCM_num) <= 0)
                {
                    FormShowMessage(Header.txtCM_num + User.Language.oMessage.IS_INVALID);
                    FormSwitchView(moView.SYSTEM_OPTION_PAGE_NUM);
                    FormSetFocus("txtCM_num");
                    return false;
                }
                else if (moUtility.ToInteger(Header.txtVoucher_num) <= 0)
                {
                    FormShowMessage(Header.txtVoucher_num + User.Language.oMessage.IS_INVALID);
                    FormSwitchView(moView.SYSTEM_OPTION_PAGE_NUM);
                    FormSetFocus("txtVoucher_num");
                    return false;
                }
                else if (moUtility.ToInteger(Header.txtDM_num) <= 0)
                {
                    FormShowMessage(Header.txtDM_num + User.Language.oMessage.IS_INVALID);
                    FormSwitchView(moView.SYSTEM_OPTION_PAGE_NUM);
                    FormSetFocus("txtDM_num");
                    return false;
                }
                else if (moUtility.ToInteger(Header.txtQuote_num) <= 0)
                {
                    FormShowMessage(Header.txtQuote_num + User.Language.oMessage.IS_INVALID);
                    FormSwitchView(moView.SYSTEM_OPTION_PAGE_NUM);
                    FormSetFocus("txtQuote_num");
                    return false;
                }
                else if (moUtility.ToInteger(Header.txtSO_num) <= 0)
                {
                    FormShowMessage(Header.txtDM_num + User.Language.oMessage.IS_INVALID);
                    FormSwitchView(moView.SYSTEM_OPTION_PAGE_NUM);
                    FormSetFocus("txtSO_num");
                    return false;
                }
                else if (moUtility.ToInteger(Header.txtPO_num) <= 0)
                {
                    FormShowMessage(Header.txtDM_num + User.Language.oMessage.IS_INVALID);
                    FormSwitchView(moView.SYSTEM_OPTION_PAGE_NUM);
                    FormSetFocus("txtPO_num");
                    return false;
                }

                if (moUtility.IsNonEmpty(Header.mskEarningAcct_cd) && moUtility.ToInteger(Header.txtGLAcctCodeLength) <= 0) // Code length should be checked only if the default earning account is set up.
                {
                    FormShowMessage(User.Language.oMessage.ACCOUNT_CODE_LENGTH_SHOULD_BE_A_POSITIVE_NUMBER);
                    FormSwitchView(moView.GL_OPTION_PAGE_NUM);
                    FormSetFocus("mskEarningAcct_cd");
                    return false;
                }
                if (moUtility.IsEmpty(Header.cboCurrency_cd))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER + User.Language.oCaption.PRIMARY_CURRENCY);
                    FormSwitchView(moView.GL_OPTION_PAGE_NUM);
                    FormSetFocus("cboCurrency_cd");
                    return false;
                }
                if (moUtility.IsEmpty(Header.cboPriceCurrency_cd) || moDatabase.CommunityVersion)
                {
                    Header.cboPriceCurrency_cd = Header.cboCurrency_cd;
                }

                if (moDatabase.CommunityVersion)
                {
                    Header.optBudget_typ = GlobalVar.goGLConstant.NO_BUDGET_TYPE;
                }

                // else if (moUtility.IsEmpty(mskEarningAcct_cd))   DO NOT CHECK HERE


                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckHeader)");
            }

            return return_value;
        }

        private bool FormCheckConcurrency(clsRecordset cur_set)                                    // Check if someone has changed this record while it is open in this session.
        {
            if (cur_set.IsNonEmpty()) 
            {
                if (moPage.bNew_fl)
                {
                    // If someone has created a record with the same key
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.DUPLICATE_IS_FOUND + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                    moPage.bNew_fl = false;
                }
                else if (moPage.CheckForConcurrency(cur_set) == false)
                {
                    // If someone has updated this record in the meantime.
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        private bool FormCheckToDelete()
        {
            
            return false;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearExtra();

            return true;
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            miOriginalInventoryCost_typ = 0;
            mbOriginalWHExist_fl = false;

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {


            return true;
        }

        private bool FormClearMessage()                                                            
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            bool return_value = false;

            try
            {
                
                return_value = false;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDelete)");
                moDatabase.TransactionRollback();
                return_value = false;
            }

            return return_value;
        }

        private bool FormDeleteExtra()
        {

            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormFindRecord(ref clsRecordset cur_set)
        {

            bool return_value = false;
            string sql_str = null;

            sql_str = "SELECT * FROM tblGOMaster";

            if (cur_set.CreateSnapshot(sql_str) == false)
            {
                FormShowMessage();
                return_value = false;
            }
            else
            {
                return_value = (cur_set.EOF() == false);
            }

            return return_value;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moMoney = new clsMoney(ref moDatabase);
            moBatch = new clsBatch();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.SMMENU_NAME;
            moPage.Title = User.Language.oCaption.SYSTEM_OPTIONS;
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormInitHeader();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = "tblGOMaster"; 
            moPage.sKeyField_nm = "";
            moPage.iTransaction_typ= 0;

            return true;
        }

        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {


            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback
            
            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;
            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                modLoadUtility.LoadCountryCode(ref moDatabase, ref CountryCodeList);
                modLoadUtility.LoadBusinessType(ref moDatabase, ref BusinessTypeList);
                modLoadUtility.LoadFiscalPeriod(ref moDatabase, ref PeriodList, moDatabase.sCurFiscalYear, false, false);
                modLoadUtility.LoadCurrencyCode(ref moDatabase, ref CurrencyList);
                modLoadUtility.LoadInventoryCostType(ref moDatabase, ref CostMethodList);
                modLoadUtility.LoadInventoryOversoldType(ref moDatabase, ref OversoldTypeList);
                modLoadUtility.LoadAccountingType(ref moDatabase, ref AccountingTypeList);
                modLoadUtility.LoadSalesPurchaseTaxType(ref TaxTypeList);
                modLoadUtility.LoadDynastyVersion(ref DynastyVersionList);
                modLoadUtility.LoadIntegers(ref TotalBinList, 1, 5);

                if (FormFindRecord(ref cur_set))
                {
                    FormShow(cur_set);
                }

                // Disable the modules if in SAAS production.
                //
                mbSAASInProduction_fl = (moDatabase.bIsSAASVersion_fl && moDatabase.iInProduction_typ > 0);                

                if (mbSAASInProduction_fl)
                {
                    Header.cboVersion_nm = GlobalVar.goConstant.SSMENU_NAME;
                }

                if (moDatabase.CommunityVersion)
                {
                    Header.optBudget_typ = GlobalVar.goGLConstant.NO_BUDGET_TYPE;
                }

                if (moDatabase.CommunityVersion)
                {
                    Header.chkGLExist_fl = true;
                    Header.chkIVExist_fl = true;
                    Header.chkARExist_fl = true;
                    Header.chkAPExist_fl = true;
                    Header.chkSOExist_fl = true;
                    Header.chkPOExist_fl = false;
                    Header.chkJCExist_fl = false;
                    Header.chkBRExist_fl = false;
                    Header.chkPRExist_fl = false;
                    Header.chkPRExist_fl = false;
                    Header.chkFAExist_fl = false;
                    Header.chkWHExist_fl = false;
                    Header.chkMCExist_fl = false;
                    Header.chkMFExist_fl = false;
                    Header.chkCMExist_fl = false;
                    Header.chkNPExist_fl = false;
                    Header.chkWOExist_fl = false;
                    Header.chkRTExist_fl = false;
                    Header.chkIEExist_fl = false;
                }


                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostSave()
        {
            
            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {

            Header.chkEditableInvoiceNumber_fl = false;
            Header.chkInvoiceNumberingByCustomer_fl = false;
            Header.chkInvoiceNumberingByJob_fl = false;

            if (miInvoiceNumbering_typ == INVOICE_NUMBERING_EDITABLE)
            {
                Header.chkEditableInvoiceNumber_fl = true;
            }
            else if (miInvoiceNumbering_typ == INVOICE_NUMBERING_BY_CUSTOMER)
            {
                Header.chkInvoiceNumberingByCustomer_fl = true;
            }
            else if (miInvoiceNumbering_typ == INVOICE_NUMBERING_BY_JOB)
            {
                Header.chkInvoiceNumberingByJob_fl = true;
            }

            return true;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormSave()
        {
            bool return_value = false;
            clsRecordset cur_set;

            try
            {
                if (FormOpenDatabase() == false)                     // Has to come before FormCheck()
                {
                    return false;
                }
                else if (FormCheck() == false)                       // Check if data is ok to save.
                {
                    return false;
                }

                cur_set = new clsRecordset(ref moDatabase);

                if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormPreSave(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveHeader(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveExtra(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (moDatabase.TransactionCommit() == false)
                {
                    FormShowMessage();
                    moDatabase.TransactionRollback();
                    return false;
                }

                modSetupUtility.SetCompanyName(moDatabase, Header.txtCompany_nm);

                FormPostSave();
                    
                return_value = true;

            }
            catch (Exception ex)
            {

                FormShowMessage(ex.Message + " (FormSave)");
                moDatabase.TransactionRollback();

            }

            return return_value;
        }

        private bool FormSaveExtra(clsRecordset cur_set)
        {
            bool return_value = false;
            string sql_str = "";
            clsRecordset trx_set = new clsRecordset(ref moDatabase);
            int next_num = 0;

            try
            {
                // 04/01/2023
                // When B/R is installed, both accounts, cash and checking, need to share the same account that is linked to a bank so that they will be properly grabbed in daily deposit slip.
                // When cash comes in as a payment, it should be set aside from the actual petty cash.  At the end of each day, all receipts should be included in the daily deposit slip printing.
                //
                if (Header.chkBRExist_fl)
                {
                    if (moDatabase.ExecuteSQL("UPDATE tblARAccounts SET sCashAcct_cd = sCheckAcct_cd") == false)
                    {
                        FormShowMessage();
                        return false;
                    }
                    //if (moDatabase.ExecuteSQL("UPDATE tblAPAccounts SET sCashAcct_cd = sCheckAcct_cd") == false)      A/P do not use cash for payment
                    //{
                    //    FormShowMessage();
                    //    return false;
                    //}
                }

                // 04/30/2020
                // If A/F invoice uses large numbers, this will mess up the regular invoice numbering.
                // Sice invoice entry checks the uniqueness of each number, no need to do this here.
                //
                //next_num = goUtility.GetLargestNumberUsed(ref moDatabase, goConstant.TRX_INVOICE_TYPE) + 1
                //If goUtility.ToInteger(Header.txtInvoice_num) > next_num Then
                next_num = moUtility.ToInteger(Header.txtInvoice_num);
                //End If
                sql_str = "UPDATE tblGONextTransactionNumber SET iNext_num = " + next_num.ToString() + " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_INVOICE_TYPE.ToString();
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                next_num = moUtility.GetLargestNumberUsed(ref moDatabase, GlobalVar.goConstant.TRX_CM_TYPE) + 1;
                if (moUtility.ToInteger(Header.txtCM_num) > next_num)
                {
                    next_num = moUtility.ToInteger(Header.txtCM_num);
                }
                sql_str = "UPDATE tblGONextTransactionNumber SET iNext_num = " + next_num.ToString() + " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_CM_TYPE.ToString();
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                next_num = moUtility.GetLargestNumberUsed(ref moDatabase, GlobalVar.goConstant.TRX_PURCHASE_TYPE) + 1;
                if (moUtility.ToInteger(Header.txtVoucher_num) > next_num)
                {
                    next_num = moUtility.ToInteger(Header.txtVoucher_num);
                }
                sql_str = "UPDATE tblGONextTransactionNumber SET iNext_num = " + next_num.ToString() + " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_PURCHASE_TYPE.ToString();
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                next_num = moUtility.GetLargestNumberUsed(ref moDatabase, GlobalVar.goConstant.TRX_DM_TYPE) + 1;
                if (moUtility.ToInteger(Header.txtDM_num) > next_num)
                {
                    next_num = moUtility.ToInteger(Header.txtDM_num);
                }
                sql_str = "UPDATE tblGONextTransactionNumber SET iNext_num = " + next_num.ToString() + " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_DM_TYPE.ToString();
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                next_num = moUtility.GetLargestNumberUsed(ref moDatabase, GlobalVar.goConstant.TRX_SO_TYPE) + 1;
                if (moUtility.ToInteger(Header.txtSO_num) > next_num)
                {
                    next_num = moUtility.ToInteger(Header.txtSO_num);
                }
                sql_str = "UPDATE tblGONextTransactionNumber SET iNext_num = " + next_num.ToString() + " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_SO_TYPE.ToString();
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                next_num = moUtility.GetLargestNumberUsed(ref moDatabase, GlobalVar.goConstant.TRX_QUOTE_TYPE) + 1;
                if (moUtility.ToInteger(Header.txtQuote_num) > next_num)
                {
                    next_num = moUtility.ToInteger(Header.txtQuote_num);
                }
                sql_str = "UPDATE tblGONextTransactionNumber SET iNext_num = " + next_num.ToString() + " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_QUOTE_TYPE.ToString();
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                next_num = moUtility.GetLargestNumberUsed(ref moDatabase, GlobalVar.goConstant.TRX_PO_TYPE) + 1;
                if (moUtility.ToInteger(Header.txtPO_num) > next_num)
                {
                    next_num = moUtility.ToInteger(Header.txtPO_num);
                }
                sql_str = "UPDATE tblGONextTransactionNumber SET iNext_num = " + next_num.ToString() + " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_PO_TYPE.ToString();
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                // IF W/H flag changes, we need to make sure there is no D/M and C/M unposted.
                // When no W/H is implemented, they are marked 'completed' and ready for posting. 
                // If, however, W/H is implemented, they are not set until they are sent/received through W/H.
                // This completion flag will create issues for update and posting when this flag changes.
                // 
                if (mbOriginalWHExist_fl != Header.chkWHExist_fl)
                {
                    sql_str = "SELECT * FROM tblARChargeUnposted WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_CM_TYPE.ToString() + " AND iStatus_typ = " + GlobalVar.goConstant.OPEN_TRX_NUM.ToString();
                    if (trx_set.CreateSnapshot(sql_str) == false)
                    {
                        FormShowMessage();
                        return false;
                    }
                    if (trx_set.RecordCount() > 0)
                    {
                        FormShowMessage("Please, post the credit memos before you enable/disable the W/H implementation.");
                        return false;
                    }

                    sql_str = "SELECT * FROM tblAPChargeUnposted WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_DM_TYPE.ToString() + " AND iStatus_typ = " + GlobalVar.goConstant.OPEN_TRX_NUM.ToString();
                    if (trx_set.CreateSnapshot(sql_str) == false)
                    {
                        FormShowMessage();
                        return false;
                    }
                    if (trx_set.RecordCount() > 0)
                    {
                        FormShowMessage("Please, post the debit memos before you enable/disable the W/H implementation.");
                        return false;
                    }
                }

                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.DO_NOT_CLOSE_PERIOD, moUtility.IIf(Header.chkDoNotClosePeriod_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.FREIGHT_CALCULATION_METHOD, Header.optFreight_typ);
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.INCLUDE_SERIAL_IN_INVOICE, moUtility.IIf(Header.chkIncludeSerialInInvoice_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.USE_MATRIX_FORM, moUtility.IIf(Header.chkUseMatrixForm_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.SHOW_PURCHASE_PRICE, moUtility.IIf(Header.chkShowItemPrice_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.LOCK_CLOSED_PERIODS, moUtility.IIf(Header.chkLockClosedPeriods_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.BLOCK_ACCOUNT_BALANCE, moUtility.IIf(Header.chkBlockAccountBalance_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.BLOCK_PRICE_CHANGE, moUtility.IIf(Header.chkBlockItemPrice_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.BLOCK_PAYMENT_DISCOUNT_CHANGE, moUtility.IIf(Header.chkBlockPaymentDiscount_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.ALLOW_QUANTITY_ALLOCATION, moUtility.IIf(Header.chkAllowQuantityAllocation_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.PRINT_DETAILS_ON_CHECK_STUB, moUtility.IIf(Header.chkPrintDetailsOnCheckStub_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.BLOCK_TRANSACTION, moUtility.IIf(Header.chkBlockTransaction_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.LOCK_PRINTED_INVOICE, moUtility.IIf(Header.chkLockPrintedInvoice_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.SHOW_ORIGINAL_QTY_ORDERED_ON_INVOICE_QTY, moUtility.IIf(Header.chkShowOriginalQtyOrdered_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.TAX_IS_DISCOUNTABLE, moUtility.IIf(Header.chkTaxIsDiscountable_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.FREIGHT_IS_DISCOUNTABLE, moUtility.IIf(Header.chkFreightIsDiscountable_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.PRIMARY_RULES_SUBITEMS, moUtility.IIf(Header.chkPrimaryRule_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.ALLOW_ITEM_CODE_CHANGE, moUtility.IIf(Header.chkAllowItemCodeChange_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.EDITABLE_INVOICE_NUMBER, moUtility.IIf(Header.chkEditableInvoiceNumber_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.INVOICE_NUMBERING_BY_CUSTOMER, moUtility.IIf(Header.chkInvoiceNumberingByCustomer_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.INVOICE_NUMBERING_BY_JOB, moUtility.IIf(Header.chkInvoiceNumberingByJob_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.LOCK_RENTAL_ONECE_BILLED, moUtility.IIf(Header.chkLockRentalAtBilling_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));
                modSecurity.SaveSecurityOption(ref moDatabase, moDatabase.sCurProgram_nm, modConstant.APPLY_CUSTOMER_PRICING, moUtility.IIf(Header.chkApplyCustomerPricing_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF));

                // Initialize all bin's that are associzted with item code.
                // This should cooperate with the default-bin change in Quantity page.
                //
                if (miOriginalMaxBins_num <= 1 && moUtility.ToInteger(Header.cboMaxBins_num) > 1)
                {
                    if (!GlobalVar.goBin.InitializeBin(ref moDatabase, "", "", ""))
                    {
                        FormShowMessage();
                        return false;
                    }
                }

                if (miAllowQuantityAllocation == GlobalVar.goConstant.FLAG_ON && !Header.chkAllowQuantityAllocation_fl)
                {
                    clsSalesOrder o_so = new clsSalesOrder(ref moDatabase);
                    if (!o_so.ReleaseAllocation(0))
                    {
                        FormShowMessage();
                        return false;
                    }
                }

                if (Header.chkIEExist_fl == false)
                {
                    sql_str = "UPDATE tblAPVendor SET iImport_fl = 0";
                    if (moDatabase.ExecuteSQL(sql_str) == false)
                    {
                        FormShowMessage();
                        return false;
                    }
                }

                if (Header.chkEnableBatchEntry_fl == false)
                {
                    moBatch.TurnOffBatch(ref moDatabase, "");        // There could be open batches.
                    moDatabase.iBatch_num = 0;
                    User.iBatch_num = 0;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveExtra)");
            }

            return return_value;
        }

        private bool FormSaveHeader(clsRecordset cur_set)
        {
            bool return_value = false;
            string sql_str = null;

            try
            {

                // miCurrentYearBegin_dt & miCurrentYearEnd_dt needs to be set here

                sql_str = "UPDATE tblGOMaster SET";
                sql_str += " iFreightCalculation_typ = " + Header.optFreight_typ.ToString();

                sql_str += ",iAddress_typ=" + Header.optAddress_typ.ToString();
                sql_str += ",iMoney_typ=" + Header.optMoney_typ.ToString();
                sql_str += ",iDate_typ=" + Header.optDate_typ.ToString();
                sql_str += ",iProcessingMode=" + Header.optProcessing_typ.ToString();
                sql_str += ",sLocalAM='" + moUtility.EvalQuote(Header.txtLocalAM) + "'";
                sql_str += ",sLocalPM='" + moUtility.EvalQuote(Header.txtLocalPM) + "'";
                sql_str += ",iDoNotSummarizeAccounts_fl=" + moUtility.IIf(Header.chkDoNotSummarizeAccountsInPosting_fl, GlobalVar.goConstant.FLAG_ON.ToString(), GlobalVar.goConstant.FLAG_OFF.ToString());
                sql_str += ",iCalcCommissionByItem_fl=" + moUtility.IIf(Header.chkCalcCommissionByItem_fl, GlobalVar.goConstant.FLAG_ON.ToString(), GlobalVar.goConstant.FLAG_OFF.ToString());
                sql_str += ",iTrackRevenueByCustomer_fl=" + moUtility.IIf(Header.chkTrackRevenueByCustomer_fl, GlobalVar.goConstant.FLAG_ON.ToString(), GlobalVar.goConstant.FLAG_OFF.ToString());
                sql_str += ",iMarkupItem_fl=" + moUtility.IIf(Header.chkMarkupItems_fl, GlobalVar.goConstant.FLAG_ON.ToString(), GlobalVar.goConstant.FLAG_OFF.ToString());
                sql_str += ",fMarkup_rt=" + moMoney.ToNumMoney(Header.txtMarkup_rt);
                sql_str += ",iDeleteTransIsAllowed_fl=" + GlobalVar.goConstant.FLAG_OFF.ToString();

                if (moDatabase.CommunityVersion)
                {
                    sql_str += ",iGLExist_fl=1";
                    sql_str += ",iIVExist_fl=1";
                    sql_str += ",iARExist_fl=1";
                    sql_str += ",iAPExist_fl=1";
                    sql_str += ",iSOExist_fl=1";
                }
                else
                {
                    sql_str += ",iGLExist_fl=" + moUtility.IIf(Header.chkGLExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                    sql_str += ",iIVExist_fl=" + moUtility.IIf(Header.chkIVExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                    sql_str += ",iARExist_fl=" + moUtility.IIf(Header.chkARExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                    sql_str += ",iAPExist_fl=" + moUtility.IIf(Header.chkAPExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                    sql_str += ",iSOExist_fl=" + moUtility.IIf(Header.chkSOExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                }

                sql_str += ",iPOExist_fl=" + moUtility.IIf(Header.chkPOExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iJCExist_fl=" + moUtility.IIf(Header.chkJCExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iBRExist_fl=" + moUtility.IIf(Header.chkBRExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iPRExist_fl=" + moUtility.IIf(Header.chkPRExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iHRExist_fl=" + moUtility.IIf(Header.chkPRExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iFAExist_fl=" + moUtility.IIf(Header.chkFAExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iWHExist_fl=" + moUtility.IIf(Header.chkWHExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iMCExist_fl=" + moUtility.IIf(Header.chkMCExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iMFExist_fl=" + moUtility.IIf(Header.chkMFExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iCMExist_fl=" + moUtility.IIf(Header.chkCMExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iNPExist_fl=" + moUtility.IIf(Header.chkNPExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iWOExist_fl=" + moUtility.IIf(Header.chkWOExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iRTExist_fl=" + moUtility.IIf(Header.chkRTExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iRCExist_fl=0";
                sql_str += ",iIEExist_fl=" + moUtility.IIf(Header.chkIEExist_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();

                sql_str += ",fFinancialChargeRate=" + moMoney.ToNumMoney(Header.txtFinancialChargeRate).ToString();
                sql_str += ",mLateCharge_amt=" + moMoney.ToNumMoney(Header.txtLateCharge_amt).ToString();
                sql_str += ",sCity='" + moUtility.EvalQuote(Header.txtCity) + "'";
                sql_str += ",sState='" + moUtility.EvalQuote(Header.txtState) + "'";
                sql_str += ",sZipCode='" + moUtility.EvalQuote(Header.txtZipCode) + "'";
                sql_str += ",sAddress3='" + moUtility.SLeft(moUtility.STrim(Header.txtCity) + ", " + moUtility.STrim(Header.txtState) + " " + moUtility.STrim(Header.txtZipCode), 40) + "'";
                sql_str += ",sAddress2='" + moUtility.EvalQuote(Header.txtAddress2) + "'";
                sql_str += ",sAddress1='" + moUtility.EvalQuote(Header.txtAddress1) + "'";
                sql_str += ",sCompany_nm='" + moUtility.EvalQuote(Header.txtCompany_nm) + "'";
                sql_str += ",sPhone='" + moUtility.EvalQuote(Header.txtPhone) + "'";
                sql_str += ",sFax='" + moUtility.EvalQuote(Header.txtFax) + "'";
                sql_str += ",sCompany_id='" + moUtility.EvalQuote(Header.txtCompany_id) + "'";
                sql_str += ",sCurrency_cd='" + Header.cboCurrency_cd.ToString() + "'";
                sql_str += ",sCountry_cd='" + Header.cboCountry_cd.ToString() + "'";
                sql_str += ",iBusiness_typ=" + Header.cboBusiness_typ.ToString();
                sql_str += ",iInventoryControl_typ=" + Header.cboOversold_typ.ToString();
                sql_str += ",iAccounting_typ=" + Header.cboAccounting_typ.ToString();
                sql_str += ",iInventoryCost_typ=" + Header.cboInventoryCost_typ.ToString();
                sql_str += ",iInvoice_typ=1";
                sql_str += ",iStatement_typ=1";
                sql_str += ",iUseFileForPicture_fl=1"; // & goUtility.IIf(Header.chkUseFileForPicture_fl, goConstant.FLAG_ON.ToString(), goConstant.FLAG_OFF.ToString())
                sql_str += ",sGLAcctCodeFormat='" + moUtility.EvalQuote(Header.txtGLAcctCodeFormat) + "'";
                sql_str += ",iGLAcctCodeLength=" + moUtility.ToInteger(Header.txtGLAcctCodeLength).ToString();
                sql_str += ",sDefaultEarningAcct_cd='" + Header.mskEarningAcct_cd + "'";
                sql_str += ",iRestrictByPeriod_fl=" + Header.optRestrictByPeriod_fl.ToString();
                sql_str += ",iBudget_typ=" + Header.optBudget_typ.ToString();
                sql_str += ",sSMTPServer_nm='" + moUtility.EvalQuote(Header.txtSMTPServer_nm) + "'";
                sql_str += ",sPriceCurrency_cd='" + Header.cboPriceCurrency_cd.ToString() + "'";
                sql_str += ",iSalesTax_typ=" + moUtility.ToInteger(Header.cboSalesTax_typ.ToString()).ToString();
                sql_str += ",iGLAcctCode_typ = " + Header.optGLAcctCode_typ.ToString();
                sql_str += ",mMaxQuick_amt=" + moMoney.ToNumMoney(Header.txtMaxQuick_amt).ToString();
                sql_str += ",sVersion_nm='" + Header.cboVersion_nm.ToString() + "'";
                sql_str += ",iEnableBatchEntry_fl=" + moUtility.IIf(Header.chkEnableBatchEntry_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iFreightTax_fl=" + moUtility.IIf(Header.chkFreightTax_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iVertical_id=0"; //& goUtility.ToInteger(Header.cboVertical_id.ToString()).ToString
                sql_str += ",sSystemEmailAddress='" + moUtility.EvalQuote(Header.txtSystemEmailAddress) + "'";
                sql_str += ",sSystemEmailPassword='" + moUtility.EvalQuote(Header.txtSystemEmailPassword) + "'";
                sql_str += ",iSystemEmailPort_num=" + moUtility.ToInteger(Header.txtSystemEmailPort_num).ToString();
                sql_str += ",iSystemEmailUseSSL_fl=" + moUtility.IIf(Header.chkSystemEmailUseSSL_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iUseCalYearForDepreciation_fl=" + moUtility.IIf(Header.chkUseCalendarYearForDepreciation_fl, GlobalVar.goConstant.FLAG_ON.ToString(), GlobalVar.goConstant.FLAG_OFF.ToString());
                sql_str += ",iMaxBins_num=" + moUtility.ToInteger(Header.cboMaxBins_num.ToString()).ToString();
                sql_str += ",iCommitHold_fl=" + moUtility.IIf(Header.chkCommitHold_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iDoNotTrackLot_fl =" + moUtility.IIf(Header.chkDoNotTrackLot_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iDoNotTrackSerial_fl =" + moUtility.IIf(Header.chkDoNotTrackSerial_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iEnableAFT_fl =" + moUtility.IIf(Header.chkEnableAFT_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();
                sql_str += ",iSecurityDeposit_pc =" + moUtility.ToInteger(Header.txtSecurityDeposit_pc).ToString();
                sql_str += ",iFirstPayment_pc =" + moUtility.ToInteger(Header.txtFirstPayment_pc).ToString();
                sql_str += ",iInspectReturn_fl =" + moUtility.IIf(Header.chkInspectReturn_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
                sql_str += ",iEnablePageLevelSecurity_fl =" + moUtility.IIf(Header.chkEnablePageLevelSecurity_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF).ToString();

                // 02/18/2025  Update these dates regardless.  Especially, at the set-up stage.
                //
                //if (moUtility.IsEmpty(moDatabase.sCurFiscalYear) || moDatabase.iCurPeriodBegin_dt == 0 || moDatabase.iCurPeriodEnd_dt == 0 || moDatabase.iCurYearBegin_dt == 0 || moDatabase.iCurYearEnd_dt == 0)
                //{
                    sql_str += ",sCurrentFiscalYear='" + moUtility.EvalQuote(Header.txtFiscalYear) + "'";
                    sql_str += ",iCurrentPeriodBegin_dt=" + moGeneral.ToNumDate(modComboUtility.GetCodeInText(PeriodList, Header.cboCurPeriod));
                    sql_str += ",iCurrentPeriodEnd_dt=" + moGeneral.ToNumDate(modComboUtility.GetDescriptionInText(PeriodList, Header.cboCurPeriod));
                    sql_str += ",iCurrentYearBegin_dt=" + moDatabase.sCurFiscalYear + "0101";
                    sql_str += ",iCurrentYearEnd_dt=" + moDatabase.sCurFiscalYear + "1231";
                //}

                sql_str += ",sLastUpdate_id = '" + moDatabase.sUser_cd + "'";
                sql_str += ",dtLastUpdate_dt = " + moDatabase.CreateDatetimeValue(DateTime.Now);
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveHeader)");
            }

            return return_value;
        }

        private bool FormSearch()
        {

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {
            if (FormShowHeader(cur_set) == false)
            {
                return false;
            }
            else if (FormShowExtra(cur_set) == false)
            {
                return false;
            }

            FormReArrangeHeader();

            return true;
        }

        private bool FormShowExtra(clsRecordset cur_set)
        {
            bool return_value = false;
            string sql_str = "";
            clsRecordset num_set = new clsRecordset(ref moDatabase);

            try
            {
                moPage.Clear();
                moPage.PreserveTimestamp(cur_set);
                moPage.bNew_fl = false;

                // This is where bReadOnly_fl & bReserved_fl are set according to the nature of the current record.
                //
                if (moUtility.IsNonEmpty(moDatabase.sCurFiscalYear))
                {
                    Header.txtFiscalYear = moDatabase.sCurFiscalYear;
                    msOriginalFiscalYear = Header.txtFiscalYear;                    // 02/18/2025
                }

                if (moDatabase.iCurPeriodBegin_dt > 0)
                {
                    Header.cboCurPeriod = moDatabase.iCurPeriodBegin_dt.ToString();
                }

                miOriginalBusiness_typ = cur_set.iField("iBusiness_typ");
                miOriginalInventoryCost_typ = cur_set.iField("iInventoryCost_typ");

                // These are mutually exclusive.  Checkbox option is hard to accomplish this dynamically.
                // We will use radio button instead.
                //
                if (Header.chkEditableInvoiceNumber_fl)
                {
                    miInvoiceNumbering_typ = INVOICE_NUMBERING_EDITABLE;
                }
                else if (Header.chkInvoiceNumberingByCustomer_fl)
                {
                    miInvoiceNumbering_typ = INVOICE_NUMBERING_BY_CUSTOMER;
                }
                else if (Header.chkInvoiceNumberingByJob_fl)
                {
                    miInvoiceNumbering_typ = INVOICE_NUMBERING_BY_JOB;
                }
                else
                {
                    miInvoiceNumbering_typ = INVOICE_NUMBERING_REGULAR;
                }

                sql_str = "SELECT * FROM tblGONextTransactionNumber";

                if (num_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                while (num_set.EOF() == false)
                {
                    //					Select Case (num_set.iField("iTransaction_typ"))
                    if ((num_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_INVOICE_TYPE)
                    {
                        Header.txtInvoice_num = (num_set.iField("iNext_num").ToString());
                    }
                    else if ((num_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_CM_TYPE)
                    {
                        Header.txtCM_num = (num_set.iField("iNext_num").ToString());
                    }
                    else if ((num_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_PURCHASE_TYPE)
                    {
                        Header.txtVoucher_num = (num_set.iField("iNext_num").ToString());
                    }
                    else if ((num_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_DM_TYPE)
                    {
                        Header.txtDM_num = (num_set.iField("iNext_num").ToString());
                    }
                    else if ((num_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_SO_TYPE)
                    {
                        Header.txtSO_num = (num_set.iField("iNext_num").ToString());
                    }
                    else if ((num_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_QUOTE_TYPE)
                    {
                        Header.txtQuote_num = (num_set.iField("iNext_num").ToString());
                    }
                    else if ((num_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_PO_TYPE)
                    {
                        Header.txtPO_num = (num_set.iField("iNext_num").ToString());
                    }
                    else
                    {
                    }

                    num_set.MoveNext();
                }

                miOriginalCommitHold_fl = cur_set.iField("iCommitHold_fl");
                miOriginalMaxBins_num = cur_set.iField("iMaxBins_num");
                miAllowQuantityAllocation = moUtility.IIf(moDatabase.uSecurity.bAllowQuantityAllocation_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                mbOriginalWHExist_fl = (cur_set.iField("iWHExist_fl") > 0);

                if (moUtility.IsEmpty(Header.txtCompany_nm))
                {
                    Header.optDate_typ = GlobalVar.goConstant.AMERICAN_DATE;
                    Header.optFreight_typ = modConstant.FREIGHT_BY_WEIGHT_NUM;
                    Header.optMoney_typ = GlobalVar.goConstant.ROUND_TO_CENT;
                    Header.optProcessing_typ = GlobalVar.goConstant.BATCH_MODE_NUM;
                    Header.cboAccounting_typ = GlobalVar.goConstant.ACCRUAL_ACCOUNTING_TYPE_NUM.ToString();
                    Header.cboBusiness_typ = GlobalVar.goConstant.INVENTORY_BUSINESS_NUM.ToString();
                    Header.cboCountry_cd = User.Language.oString.STR_UNITED_STATES_OF_AMERICA;
                    Header.cboInventoryCost_typ = GlobalVar.goIVConstant.AVG_COST_NUM.ToString();
                    Header.cboOversold_typ = GlobalVar.goConstant.OVERSOLD_WITH_NO_RESTRICTION_NUM.ToString();
                }
                    
                Header.Preserve();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowHeader(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                Header.optFreight_typ = cur_set.iField("iFreightCalculation_typ");
                Header.optAddress_typ = cur_set.iField("iAddress_typ");
                Header.optMoney_typ = cur_set.iField("iMoney_typ");
                Header.optDate_typ = cur_set.iField("iDate_typ");
                Header.optProcessing_typ = cur_set.iField("iProcessingMode");
                Header.txtLocalAM = cur_set.sField("sLocalAM");
                Header.txtLocalPM = cur_set.sField("sLocalPM");
                Header.chkDoNotSummarizeAccountsInPosting_fl = (cur_set.iField("iDoNotSummarizeAccounts_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkCalcCommissionByItem_fl = (cur_set.iField("iCalcCommissionByItem_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkTrackRevenueByCustomer_fl = (cur_set.iField("iTrackRevenueByCustomer_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkMarkupItems_fl = (cur_set.iField("iMarkupItem_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.txtMarkup_rt = cur_set.mField("fMarkup_rt").ToString();
                Header.txtFinancialChargeRate = cur_set.mField("fFinancialChargeRate").ToString();
                Header.txtLateCharge_amt = moMoney.ToStrMoney(cur_set.mField("mLateCharge_amt"));
                Header.txtCity = cur_set.sField("sCity");
                Header.txtState = cur_set.sField("sState");
                Header.txtZipCode = cur_set.sField("sZipCode");
                Header.txtAddress2 = cur_set.sField("sAddress2");
                Header.txtAddress1 = cur_set.sField("sAddress1");
                Header.txtCompany_nm = cur_set.sField("sCompany_nm");
                Header.txtPhone = cur_set.sField("sPhone");
                Header.txtFax = cur_set.sField("sFax");

                Header.cboCurrency_cd = cur_set.sField("sCurrency_cd");
                Header.cboCountry_cd = cur_set.sField("sCountry_cd");
                Header.cboBusiness_typ = cur_set.iField("iBusiness_typ").ToString();
                Header.cboOversold_typ = cur_set.iField("iInventoryControl_typ").ToString();
                Header.cboAccounting_typ = cur_set.iField("iAccounting_typ").ToString();
                Header.cboInventoryCost_typ = cur_set.iField("iInventoryCost_typ").ToString();
                Header.txtGLAcctCodeFormat = cur_set.sField("sGLAcctCodeFormat");
                Header.txtGLAcctCodeLength = cur_set.iField("iGLAcctCodeLength").ToString();
                Header.mskEarningAcct_cd = cur_set.sField("sDefaultEarningAcct_cd");
                Header.optRestrictByPeriod_fl = cur_set.iField("iRestrictByPeriod_fl");
                Header.optBudget_typ = cur_set.iField("iBudget_typ");
                Header.txtSMTPServer_nm = cur_set.sField("sSMTPServer_nm");
                Header.cboSalesTax_typ = moDatabase.iSalesTax_typ.ToString();
                Header.txtCompany_id = cur_set.sField("sCompany_id");
                Header.cboVersion_nm = cur_set.sField("sVersion_nm");

                Header.cboPriceCurrency_cd = cur_set.sField("sPriceCurrency_cd");

                if (cur_set.mField("mMaxQuick_amt") >= moDatabase.mSmallestMoney_amt)
                {
                    Header.txtMaxQuick_amt = moMoney.ToStrMoney(cur_set.mField("mMaxQuick_amt"));
                }
                else
                {
                    Header.txtMaxQuick_amt = "";
                }

                Header.txtSystemEmailAddress = cur_set.sField("sSystemEmailAddress");
                Header.txtSystemEmailPassword = cur_set.sField("sSystemEmailPassword");
                if (cur_set.iField("iSystemEmailPort_num") > 0)
                {
                    Header.txtSystemEmailPort_num = cur_set.iField("iSystemEmailPort_num").ToString();
                }
                Header.chkSystemEmailUseSSL_fl = (cur_set.iField("iSystemEmailUseSSL_fl") > 0);
                Header.chkUseCalendarYearForDepreciation_fl = (cur_set.iField("iUseCalYearForDepreciation_fl") > 0);
                Header.cboMaxBins_num = cur_set.iField("iMaxBins_num").ToString();
                Header.chkCommitHold_fl = (cur_set.iField("iCommitHold_fl") > 0);
                Header.chkDoNotTrackLot_fl = (cur_set.iField("iDoNotTrackLot_fl") > 0);
                Header.chkDoNotTrackSerial_fl = (cur_set.iField("iDoNotTrackSerial_fl") > 0);
                Header.chkEnableAFT_fl = (cur_set.iField("iEnableAFT_fl") > 0);
                Header.chkInspectReturn_fl = (cur_set.iField("iInspectReturn_fl") > 0);
                Header.chkEnablePageLevelSecurity_fl = (cur_set.iField("iEnablePageLevelSecurity_fl") > 0);

                if (cur_set.iField("iSecurityDeposit_pc") > 0)
                {
                    Header.txtSecurityDeposit_pc = cur_set.iField("iSecurityDeposit_pc").ToString();
                }

                if (cur_set.iField("iFirstPayment_pc") > 0)
                {
                    Header.txtFirstPayment_pc = cur_set.iField("iFirstPayment_pc").ToString();
                }

                Header.chkGLExist_fl = (cur_set.iField("iGLExist_fl") > 0);
                Header.chkIVExist_fl = (cur_set.iField("iIVExist_fl") > 0);
                Header.chkARExist_fl = (cur_set.iField("iARExist_fl") > 0);
                Header.chkSOExist_fl = (cur_set.iField("iSOExist_fl") > 0);
                Header.chkAPExist_fl = (cur_set.iField("iAPExist_fl") > 0);
                Header.chkPOExist_fl = (cur_set.iField("iPOExist_fl") > 0);
                Header.chkBRExist_fl = (cur_set.iField("iBRExist_fl") > 0);
                Header.chkJCExist_fl = (cur_set.iField("iJCExist_fl") > 0);
                Header.chkPRExist_fl = (cur_set.iField("iPRExist_fl") > 0);
                Header.chkFAExist_fl = (cur_set.iField("iFAExist_fl") > 0);
                Header.chkWHExist_fl = (cur_set.iField("iWHExist_fl") > 0);
                Header.chkMCExist_fl = (cur_set.iField("iMCExist_fl") > 0);
                Header.chkMFExist_fl = (cur_set.iField("iMFExist_fl") > 0);
                Header.chkCMExist_fl = (cur_set.iField("iCMExist_fl") > 0);
                Header.chkWOExist_fl = (cur_set.iField("iWOExist_fl") > 0);
                Header.chkNPExist_fl = (cur_set.iField("iNPExist_fl") > 0);
                Header.chkRTExist_fl = (cur_set.iField("iRTExist_fl") > 0);
                Header.chkIEExist_fl = (cur_set.iField("iIEExist_fl") > 0);

                Header.chkDoNotClosePeriod_fl = moDatabase.uSecurity.bDoNotClosePeriod_fl;
                //Header.txtWinFreightDirectory_nm = moDatabase.uDirectory.sWinFreightDirectory_nm

                // At this point, we diable the following Header.options for web-version.
                //
                //========================================================================================
                moDatabase.uSecurity.bIncludeSerialInInvoice_fl = true;
                Header.chkIncludeSerialInInvoice_fl = moDatabase.uSecurity.bIncludeSerialInInvoice_fl;
                //========================================================================================

                Header.chkBlockAccountBalance_fl = moDatabase.uSecurity.bBlockAccountBalance_fl;
                Header.chkUseMatrixForm_fl = moDatabase.uSecurity.bUseMatrixForm_fl;
                Header.chkApplyCustomerPricing_fl = moDatabase.uSecurity.bApplyCustomerPricing_fl;
                Header.chkShowItemPrice_fl = moDatabase.uSecurity.bShowPurchasePrice_fl;
                Header.chkBlockItemPrice_fl = moDatabase.uSecurity.bBlockPriceChange_fl;
                Header.chkBlockPaymentDiscount_fl = moDatabase.uSecurity.bBlockPaymentDiscount_fl;
                Header.chkBlockTransaction_fl = moDatabase.uSecurity.bBlockTransaction_fl;
                Header.chkLockClosedPeriods_fl = moDatabase.uSecurity.bLockClosedPeriods_fl;
                Header.chkAllowQuantityAllocation_fl = moDatabase.uSecurity.bAllowQuantityAllocation_fl;
                Header.chkPrintDetailsOnCheckStub_fl = moDatabase.uSecurity.bPrintDetailsOnCheckStub_fl;
                Header.chkLockPrintedInvoice_fl = moDatabase.uSecurity.bLockPrintedInvoice_fl;

                Header.chkShowOriginalQtyOrdered_fl = moDatabase.uSecurity.bShowOriginalQtyOrdered_fl;
                Header.chkEnableBatchEntry_fl = moDatabase.bEnableBatchEntry_fl;

                Header.chkFreightTax_fl = moDatabase.bFreightTax_fl;
                Header.chkTaxIsDiscountable_fl = moDatabase.uSecurity.bTaxIsDiscountable_fl;
                Header.chkFreightIsDiscountable_fl = moDatabase.uSecurity.bFreightIsDiscountable_fl;
                Header.chkPrimaryRule_fl = moDatabase.uSecurity.bPrimaryRulesSubItems_fl;
                Header.chkAllowItemCodeChange_fl = moDatabase.uSecurity.bAllowItemCodeChange_fl;

                Header.chkEditableInvoiceNumber_fl = moDatabase.uSecurity.bEditableInvoiceNumber_fl;
                Header.chkInvoiceNumberingByCustomer_fl = moDatabase.uSecurity.bInvoiceNumberingByCustomer_fl;
                Header.chkInvoiceNumberingByJob_fl = moDatabase.uSecurity.bInvoiceNumberingByJob_fl;

                Header.chkLockRentalAtBilling_fl = moDatabase.uSecurity.bLockRentalAtBilling_fl;

                if (moDatabase.iTotalSegments_num == 0)
                {
                    Header.optGLAcctCode_typ = 1;
                }
                else
                {
                    if (moDatabase.bUseFullAccountCode_fl)
                    {
                        Header.optGLAcctCode_typ = 1;
                    }
                    else
                    {
                        Header.optGLAcctCode_typ = 0;
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowHeader)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowListing()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moListing.Show(moDatabase, moPage) == false)
            {
                return false;
            }

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moZoom.Caller == "mskEarningAcct_cd")
            {
                if (moZoom.Account(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
                {
                    return false;
                }
            }

            FormCancel();
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }

        private bool btnSave_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormSave() == false)
            {
                return false;
            }


            FormShowMessage(User.Language.oMessage.SAVING_IS_COMPLETE, false);
            //FormExit();

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewHeader_Clicked()
        {
            FormPreEvent();                                                                           
            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }
        private bool cmdViewSystemOptions()
        {
            FormPreEvent();
            FormSwitchView(moView.SYSTEM_OPTION_PAGE_NUM);

            return true;
        }
        private bool cmdViewSecurityOptions_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.SECUTITY_OPTION_PAGE_NUM);

            return true;
        }
        private bool cmdViewGLOptions_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.GL_OPTION_PAGE_NUM);

            return true;
        }
        private bool cmdViewLocalization_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.LOCALIZATION_PAGE_NUM);

            return true;
        }
        private bool cmdViewFreightMethod_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.FREIGHT_METHOD_PAGE_NUM);

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================

        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                if (moUtility.IsEmpty(cur_item.Col_0))
                {
                    return false;
                }

                code_selected = cur_item.Col_0;

                if (moZoom.Caller == "mskEarningAcct_cd")
                {
                    Header.mskEarningAcct_cd = code_selected;
                    if (mskEarningAcct_cd_Changed() == false)
                    {
                        return false;
                    }
                    FormSwitchView(moView.GL_OPTION_PAGE_NUM);
                    return FormPostEvent();
                }

                FormSwitchView(moZoom.iView);

                return_value = FormPostEvent();
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();                                                                   

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }
        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool txtFiscalYear_Changed()
        {
            Header.txtFiscalYear = modCommonUtility.CleanCode(Header.txtFiscalYear);

            if (Header.txtFiscalYear == Header.Tag.txtFiscalYear)
            {
                return true;
            }

            FormPreEvent();

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moUtility.IsNonEmpty(Header.txtFiscalYear))
            {
                if (moValidate.IsValidFiscalYear(Header.txtFiscalYear) == false)
                {
                    FormShowMessage(User.Language.oMessage.FISCAL_YEAR_IS_INVALID);
                    Header.txtFiscalYear = Header.Tag.txtFiscalYear;
                    FormSetFocus("txtFiscalYear");
                    moValidate.Release();
                    return false;
                }

                PeriodList.Clear();
                modLoadUtility.LoadFiscalPeriod(ref moDatabase, ref PeriodList, Header.txtFiscalYear);

                // 02/18/2025  Current year is updated when a new year is selected.   This is for the initial set-up
                //
                if (moValidate.IsValidRecord("SELECT * FROM tblGLPeriodDet WHERE sFiscalYear = '" + Header.txtFiscalYear + "' ORDER by iPeriodBegin_dt") == false)
                {
                    FormShowMessage();
                    return false;
                }

                moValidate.oRecordset.MoveFirst();
                miCurrentYearBegin_dt = moValidate.oRecordset.iField("iPeriodBegin_dt");
                moValidate.oRecordset.MoveLast();
                miCurrentYearEnd_dt = moValidate.oRecordset.iField("iPeriodEnd_dt");

                moValidate.Release();

            }

            return FormPostEvent();
        }

        private bool cboVersion_nm_Clicked()
        {
            if (Header.cboVersion_nm == Header.Tag.cboVersion_nm)
            {
                return true;
            }

            FormPreEvent();

            Header.chkGLExist_fl = (Header.cboVersion_nm != GlobalVar.goConstant.SSMENU_NAME);
            Header.chkIVExist_fl = (Header.cboVersion_nm != GlobalVar.goConstant.SSMENU_NAME);
            Header.chkARExist_fl = (Header.cboVersion_nm != GlobalVar.goConstant.SSMENU_NAME);
            Header.chkSOExist_fl = (Header.cboVersion_nm != GlobalVar.goConstant.SSMENU_NAME);
            Header.chkAPExist_fl = (Header.cboVersion_nm != GlobalVar.goConstant.SSMENU_NAME);
            Header.chkPOExist_fl = (Header.cboVersion_nm != GlobalVar.goConstant.SSMENU_NAME);

            Header.chkBRExist_fl = false;
            Header.chkJCExist_fl = false;
            Header.chkFAExist_fl = false;
            Header.chkWHExist_fl = false;
            Header.chkMFExist_fl = false;
            Header.chkCMExist_fl = false;
            Header.chkWOExist_fl = false;
            Header.chkRTExist_fl = false;

            // These are sold separately
            //
            Header.chkPRExist_fl = false;
            Header.chkMCExist_fl = false;
            Header.chkIEExist_fl = false;
            Header.chkNPExist_fl = false;

            if (Header.cboVersion_nm != GlobalVar.goConstant.SSMENU_NAME)
            {

                if (Header.cboVersion_nm.ToString() == GlobalVar.goConstant.ENMENU_NAME || Header.cboVersion_nm.ToString() == GlobalVar.goConstant.PLMENU_NAME) // Enterprise or Platinum
                {
                    Header.chkFAExist_fl = true;
                    Header.chkJCExist_fl = true;
                    Header.chkBRExist_fl = true;
                    Header.chkWHExist_fl = true;
                    Header.chkMFExist_fl = true;
                    Header.chkCMExist_fl = true;
                    Header.chkWOExist_fl = true;
                }

            }

            if (DisableBatch)
            {
                Header.chkEnableBatchEntry_fl = false;
            }

            return FormPostEvent();
        }

        private bool btnZoomEarningAcct_cd_Clicked()
        {
            string where_clause = "tblGLAccount.iGroup_typ BETWEEN 3000 AND 3999";

            FormPreEvent();

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "mskEarningAcct_cd", -1, -1, moView.MAIN_PAGE_NUM, "sAccount_cd", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool txtLateCharge_amt_Changed()
        {
            if (Header.txtLateCharge_amt == Header.Tag.txtLateCharge_amt)
            {
                return true;
            }
            if (moUtility.IsNonEmpty(Header.txtLateCharge_amt))
            {
                if (moMoney.ToNumMoney(Header.txtLateCharge_amt) < 0)
                {
                    FormShowMessage(User.Language.oMessage.NEGATIVE_AMOUNT_IS_NOT_ALLOWED);
                    Header.txtLateCharge_amt = Header.Tag.txtLateCharge_amt;
                    FormSetFocus("txtLateCharge_amt");
                    return false;
                }
                else if (moMoney.ToNumMoney(Header.txtLateCharge_amt) > 0)
                {
                    Header.txtLateCharge_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.txtLateCharge_amt));
                    Header.txtFinancialChargeRate = "";      // Mutually exclusive
                }
                else
                {
                    Header.txtLateCharge_amt = "";
                }
            }

            return FormPostEvent();
        }

        private bool txtFinancialChargeRate_Changed()
        {
            if (Header.txtFinancialChargeRate == Header.Tag.txtFinancialChargeRate)
            {
                return true;
            }
            if(moUtility.IsNonEmpty(Header.txtFinancialChargeRate))
            {
                if (moMoney.ToNumMoney(Header.txtFinancialChargeRate) < 0)
                {
                    FormShowMessage(User.Language.oMessage.NEGATIVE_AMOUNT_IS_NOT_ALLOWED);
                    Header.txtFinancialChargeRate = Header.Tag.txtFinancialChargeRate;
                    FormSetFocus("txtFinancialChargeRate");
                    return false;
                }
                else if (moMoney.ToNumMoney(Header.txtFinancialChargeRate) > 0)
                {
                    Header.txtFinancialChargeRate = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.txtFinancialChargeRate));
                    Header.txtLateCharge_amt = "";      // Mutually exclusive
                }
                else
                {
                    Header.txtFinancialChargeRate = "";
                }
            }

            return FormPostEvent();
        }

        private bool mskEarningAcct_cd_Changed()
        {
            Header.mskEarningAcct_cd = modCommonUtility.CleanCode(Header.mskEarningAcct_cd);

            if (Header.mskEarningAcct_cd == Header.Tag.mskEarningAcct_cd)
            {
                return true;
            }

            FormPreEvent();

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moUtility.IsNonEmpty(Header.mskEarningAcct_cd))
            {
                if (moValidate.IsValidActualAcctCode(Header.mskEarningAcct_cd) == false)
                {
                    FormShowMessage(Header.mskEarningAcct_cd + User.Language.oMessage.IS_INVALID);
                    Header.mskEarningAcct_cd = Header.Tag.mskEarningAcct_cd;
                    FormSetFocus("mskEarningAcct_cd");
                    moValidate.Release();
                    return false;
                }
                else if (moValidate.oRecordset.iField("iGroup_typ") != GlobalVar.goGLConstant.CURRENT_EARNING_NUM)
                {
                    FormShowMessage(Header.mskEarningAcct_cd + User.Language.oMessage.IS_INVALID_FOR_EARNING_ACCT);
                    Header.mskEarningAcct_cd = Header.Tag.mskEarningAcct_cd;
                    FormSetFocus("mskEarningAcct_cd");
                    moValidate.Release();
                    return false;
                }

                moValidate.Release();
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

    }
}
