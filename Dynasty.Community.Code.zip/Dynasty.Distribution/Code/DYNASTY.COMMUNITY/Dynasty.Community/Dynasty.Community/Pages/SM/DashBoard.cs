﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Report;
using Dynasty.Local;
using System.Collections;

namespace Dynasty.ASP.Pages.SM
{
    public partial class DashBoard
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<MarkUp> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;
        private Models.clsDashBoard moDetail;
        private clsEnterprise moEnterprise;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsReportViewer moReport;
        private Models.clsSession moSession;

        private string msTitle = "";

        private int miDetailColumn = 0;

        private bool mbChartInitialized_fl = false;

        private bool IsDirector
        {
            get { return moUtility.IsDirector(moDatabase) || User.ViewOnly; }       // Let the demo see all
        }

        private bool IsManager
        {
            get { return moUtility.IsManager(moDatabase) || User.ViewOnly; }         // Let the demo see all
        }
        private bool IsSalesManager
        {
            get { return moUtility.IsSalesManager(moDatabase) || User.ViewOnly; }         // Let the demo see all
        }

        private bool IsSupervisor
        {
            get { return moUtility.IsSupervisor(moDatabase) || User.ViewOnly; }      // Let the demo see all
        }

        private bool ViewFinancials
        {
            get { return (IsDirector || User.ViewOnly); }                       // Let the demo see all
        }

        private bool Visualize
        {
            get { return (moDetail.ColumnCaption.GetUpperBound(0) <= 1 && mbChartInitialized_fl && (ViewFinancials || IsSalesManager)); }
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader
        {

            // Datetime component is not very user-friendly, yet, as of VS2019.
            // For better understanding this, read the comment on bUseDatePicker_fl in clsUser.
            //
            public string mskApply_dt = "";
            public DateTime? dtApply_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag
            {
                public string mskApply_dt = "";
                public DateTime? dtApply_dt = null;
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()
            {
                Tag.mskApply_dt = mskApply_dt;
                Tag.dtApply_dt = dtApply_dt;
            }
        }
        private clsHeader Header = new clsHeader();

        private class clsFinancial
        {
            public string lblReceivable_amt = "0.00";
            public string lblPayable_amt = "0.00";
            public string lblInventory_amt = "0.00";
            public string lblBankBalance_amt = "0.00";         // total of all banks

            public class clsBank
            {
                public string lblBank_nm = "BOA";
                public string lblBalance_amt = "0.00";
            }

            public clsBank Bank = new clsBank();
        }
        private clsFinancial Financial = new clsFinancial();
        private clsFinancial.clsBank[] BankData = new clsFinancial.clsBank[10];

        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            moSession.RemoveSession(moDatabase);        // Delete the session file.

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        private void FormDownloadFile(string file_name)                                             // Download a file.
        {
            Models.JSFunction.DownloadFile(JSRuntime, moPage, User.sWebSite, file_name);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            bool return_value = false;

            if (FormCheckSecurity() == false)
            {
                return false;
            }

            try
            {
                FormSyncDates(User.bUseDatePicker_fl);

                if (moUtility.IsBlankDate(Header.mskApply_dt))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER + User.Language.oCaption.REPORT_DATE);
                    if (User.bUseDatePicker_fl)
                    {
                        FormSetFocus("dtApply_dt");
                    }
                    else
                    {
                        FormSetFocus("mskApply_dt");
                    }

                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheck)");
            }

            return return_value;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            moDetail.Clear();

            return true;
        }

        private bool FormClearMessage()
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();
            moDetail = new Models.clsDashBoard();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moReport = new clsReportViewer();
            moEnterprise = new clsEnterprise();
            moSession = new Models.clsSession();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.SMMENU_NAME;
            moPage.Title = User.Language.oCaption.EXECUTIVE_DASHBOARD;
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormPostEvent()
        {
            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            // FormSave() & FormCheck() use the plain textbox whose name starts with "msk"
            // dt* variables are only to interact with UI.  Internally, msk* fields are used.
            //
            FormSyncDates(User.bUseDatePicker_fl);

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback

            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;

            try
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                Header.mskApply_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                FormSyncDates(false);

                cmdRefresh_clicked();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPrint(int print_type)
        {
            bool return_value = false;

            try
            {
                
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormPrint)");
            }

            return return_value;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormRecreateDetail()                                                           //  Sync moDetail.Data with moDetail.Grid for the items that do not have event-handler ONLY.
        {
            if (moDetail.RecreateDetail() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateDetailLine(Models.clsDashBoard.clsGrid cur_item, int row_num = -1)
        {
            if (moDetail.RecreateDetailLine(cur_item, row_num) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateGrid()                                                             //  Create moDetail.Grid according to moDetail.Data
        {
            if (moDetail.RecreateGrid() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtApply_dt, ref Header.mskApply_dt, use_date_picker);

            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moZoom.Caller == "txtAsset_cd")
            {
                if (moZoom.Code(ref moDatabase, "tblFAAsset") == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }


        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }


        private bool btnPrint_Clicked()
        {
            FormPreEvent();

            if (FormCheck())
            {
                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
                FormPrint(GlobalVar.goConstant.PRINT_TO_PDF);
            }

            return FormPostEvent();
        }

        private bool btnExcel_Clicked()
        {
            FormPreEvent();

            if (FormCheck())
            {
                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
                FormPrint(GlobalVar.goConstant.PRINT_TO_EXCEL);
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================

 
        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                if (moUtility.IsEmpty(cur_item.Col_0))
                {
                    return false;
                }

                code_selected = cur_item.Col_0;

                FormSwitchView(moZoom.iView);

                return_value = FormPostEvent();
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        private bool dtApply_dt_Changed()
        {
            if (Header.dtApply_dt == Header.Tag.dtApply_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                Header.dtApply_dt = Header.Tag.dtApply_dt;
                return false;
            }

            if (moUtility.IsEmpty(Header.dtApply_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtApply_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtApply_dt) == false)
            {
                Header.dtApply_dt = Header.Tag.dtApply_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtApply_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskApply_dt_Changed()
        {
            if (Header.mskApply_dt == Header.Tag.mskApply_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                Header.mskApply_dt = Header.Tag.mskApply_dt;
                return false;
            }

            if (moGeneral.ValidDate(ref Header.mskApply_dt) == false)
            {
                Header.mskApply_dt = Header.Tag.mskApply_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskApply_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdRefresh_clicked()
        {
            FormPreEvent();

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            UpdateAll();

            mbChartInitialized_fl = GetCharts();

            return FormPostEvent();
        }
        private bool btnDetailSelect_Clicked(Models.clsDashBoard.clsGrid cur_item)
        {
            FormPreEvent();

            DrillDownOnDashBoard(moGeneral.ToNumDate(Header.mskApply_dt), cur_item.Row_num);

            return FormPostEvent();
        }

        private bool cmdInvoicesOverDue_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            moDetail.sInvoicesOverDue = UpdateNumber(ref moDetail.sInvoicesOverDue, moDetail.InvoicesOverDue(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), false));

            msTitle = moDetail.sInvoicesOverDue + " : " + Header.mskApply_dt;

            return FormPostEvent();
        }

        private bool cmdBillsOverDue_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            moDetail.sBillsOverDue = UpdateNumber(ref moDetail.sBillsOverDue, moDetail.BillsOverDue(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), false));

            msTitle = moDetail.sBillsOverDue + " : " + Header.mskApply_dt;

            return FormPostEvent();
        }

        private bool cmdOrdersToShip_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            moDetail.sOrdersToShip = UpdateNumber(ref moDetail.sOrdersToShip, moDetail.OrdersToShip(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), false));

            msTitle = moDetail.sOrdersToShip + " : " + Header.mskApply_dt;

            return FormPostEvent();
        }

        private bool cmdQuotesNotApproved_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            moDetail.sQuotesNotApproved = UpdateNumber(ref moDetail.sQuotesNotApproved, moDetail.QuotesNotApproved(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), false));

            msTitle = moDetail.sQuotesNotApproved + " : " + Header.mskApply_dt;

            return FormPostEvent();
        }

        private bool cmdBestSellers_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            moDetail.BestSellers(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt));

            msTitle = moDetail.sBestSellers + " : " + Header.mskApply_dt;

            return FormPostEvent();
        }

        private bool cmdBestProfitors_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            moDetail.BestProfitors(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt));

            msTitle = moDetail.sBestProfitors + " : " + Header.mskApply_dt;

            return FormPostEvent();
        }

        private bool cmdApprovalsPending_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            moDetail.sApprovalsPending = UpdateNumber(ref moDetail.sApprovalsPending, moDetail.ApprovalsPending(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), false));

            msTitle = moDetail.sApprovalsPending + " : " + Header.mskApply_dt;

            return FormPostEvent();
        }

        private bool cmdCustomersToContact_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            moDetail.sCustomersToContact = UpdateNumber(ref moDetail.sCustomersToContact, moDetail.CustomersToContact(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), false));

            msTitle = moDetail.sCustomersToContact + " : " + Header.mskApply_dt;

            return FormPostEvent();
        }

        private bool cmdVendorsToContact_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            moDetail.sVendorsToContact = UpdateNumber(ref moDetail.sVendorsToContact, moDetail.VendorsToContact(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), false));

            msTitle = moDetail.sVendorsToContact + " : " + Header.mskApply_dt;

            return FormPostEvent();
        }

        private bool cmdProspectsToContact_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            moDetail.sProspectsToContact = UpdateNumber(ref moDetail.sProspectsToContact, moDetail.ProspectsToContact(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), false));

            msTitle = moDetail.sProspectsToContact + " : " + Header.mskApply_dt;

            return FormPostEvent();
        }

        private bool cmdCustomerSupport_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            moDetail.sCustomerSupport = UpdateNumber(ref moDetail.sCustomerSupport, moDetail.CustomerSupport(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), false));

            msTitle = moDetail.sCustomerSupport + " : " + Header.mskApply_dt;

            return FormPostEvent();
        }

        private bool cmdReceivableAging_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            moDetail.ReceivableAging(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt));

            msTitle = moDetail.sReceivableAging + " : " + Header.mskApply_dt;

            return FormPostEvent();
        }

        private bool cmdPayableAging_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            moDetail.PayableAging(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt));

            msTitle = moDetail.sPayableAging + " : " + Header.mskApply_dt;

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================


        private void UpdateAll()
        {
            moDetail.Clear();

            moDetail.sCustomersToContact = UpdateNumber(ref moDetail.sCustomersToContact, moDetail.CustomersToContact(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), true));
            moDetail.sVendorsToContact = UpdateNumber(ref moDetail.sVendorsToContact, moDetail.VendorsToContact(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), true));
            moDetail.sProspectsToContact = UpdateNumber(ref moDetail.sProspectsToContact, moDetail.ProspectsToContact(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), true));
            moDetail.sOrdersToShip = UpdateNumber(ref moDetail.sOrdersToShip, moDetail.OrdersToShip(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), true));
            moDetail.sQuotesNotApproved = UpdateNumber(ref moDetail.sQuotesNotApproved, moDetail.QuotesNotApproved(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), true));
            moDetail.sBillsOverDue = UpdateNumber(ref moDetail.sBillsOverDue, moDetail.BillsOverDue(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), true));
            moDetail.sInvoicesOverDue = UpdateNumber(ref moDetail.sInvoicesOverDue, moDetail.InvoicesOverDue(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), true));
            moDetail.sCustomerSupport = UpdateNumber(ref moDetail.sCustomerSupport, moDetail.CustomerSupport(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), true));
            moDetail.sApprovalsPending = UpdateNumber(ref moDetail.sApprovalsPending, moDetail.ApprovalsPending(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), true));
            //moDetail.sApprovalsToMake = UpdateNumber(ref moDetail.sApprovalsToMake, moApproval.CountApprovalsToMake(moDatabase.sUser_cd));

        }

        private string UpdateNumber(ref string cur_label, int cur_num)
        {

            string return_value = "";
            string temp_text = cur_label;

            temp_text = moUtility.SLeft(temp_text, moUtility.SInStr(temp_text, "(")) + " " + cur_num.ToString() + " )";
            return_value = temp_text;

            return return_value;
        }


        public bool DrillDownOnDashBoard(int cur_date, int row_num)
        {
            bool return_value = false;
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";
            string page_name = "";
            string entity_code = "";
            int cell_val = 0;

            try
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                if (row_num < 0)
                {
                    return false;
                }
                else if (moUtility.ToValue(moDetail.Data[Models.clsDashBoard.DASHBOARD_TYPE_NUM, row_num]) <= 0)
                {
                    return false;
                }

                cell_val = moUtility.ToInteger(moDetail.Data[Models.clsDashBoard.DASHBOARD_TYPE_NUM, row_num]);

                if (cell_val == Models.clsDashBoard.DASHBOARD_CUSTOMER_TYPE_NUM)
                {
                    entity_code = moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num];
                    page_name = "Customer";
                }
                else if (cell_val == Models.clsDashBoard.DASHBOARD_PROSPECT_TYPE_NUM)
                {
                    entity_code = moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num];
                    page_name = "ContactManager";
                }
                else if (cell_val == Models.clsDashBoard.DASHBOARD_CUSTOMER_SUPPORT_TYPE_NUM)
                {
                    entity_code = moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num];
                    page_name = "HelpDesk";
                }
                else if (cell_val == Models.clsDashBoard.DASHBOARD_VENDOR_TYPE_NUM)
                {
                    entity_code = moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num];
                    page_name = "Vendor";
                }
                else if (cell_val == Models.clsDashBoard.DASHBOARD_BEST_SELLER_TYPE_NUM || cell_val == Models.clsDashBoard.DASHBOARD_BEST_PROFITOR_TYPE_NUM)
                {
                    entity_code = moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num];
                    page_name = "Item";
                }
                else if (cell_val == Models.clsDashBoard.DASHBOARD_RECEIVABLE_AGING_TYPE_NUM)
                {
                    if (!moUtility.IsEmpty(moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num]))
                    {
                        entity_code = moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num];
                        page_name = "LookupInvoice";
                    }
                    else
                    {
                        moDetail.ReceivableAging(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), true);
                    }
                }
                else if (cell_val == Models.clsDashBoard.DASHBOARD_PAYABLE_AGING_TYPE_NUM)
                {
                    if (!moUtility.IsEmpty(moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num]))
                    {
                        entity_code = moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num];
                        page_name = "LookupVoucher";
                    }
                    else
                    {
                        moDetail.PayableAging(ref moDatabase, moGeneral.ToNumDate(Header.mskApply_dt), true);
                    }
                }
                else if (cell_val == GlobalVar.goConstant.TRX_SO_TYPE)
                {
                    entity_code = moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num];
                    page_name = "Order";
                }
                else if (cell_val == GlobalVar.goConstant.TRX_QUOTE_TYPE)
                {
                    entity_code = moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num];
                    page_name = "Quote";
                }
                else if (cell_val == GlobalVar.goConstant.TRX_INVOICE_TYPE)
                {
                    entity_code = moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num];
                    if (moUtility.ToValue(moDetail.Data[Models.clsDashBoard.DASHBOARD_DEPTH_NUM, row_num]) == Models.clsDashBoard.DASHBOARD_APPROVAL_WAITING_TYPE_NUM)
                    {
                        page_name = "Invoice";
                    }
                    else
                    {
                        page_name = "LookupInvoice";
                    }
                }
                else if (cell_val == GlobalVar.goConstant.TRX_CM_TYPE)
                {
                    entity_code = moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num];
                    if (moUtility.ToValue(moDetail.Data[Models.clsDashBoard.DASHBOARD_DEPTH_NUM, row_num]) == Models.clsDashBoard.DASHBOARD_APPROVAL_WAITING_TYPE_NUM)
                    {
                        page_name = "CreditMemo";
                    }
                    else
                    {
                        page_name = "LookupCreditMemo";
                    }
                }
                else if (cell_val == GlobalVar.goConstant.TRX_RECEIPT_TYPE)
                {
                    entity_code = moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num];
                    if (moUtility.ToValue(moDetail.Data[Models.clsDashBoard.DASHBOARD_DEPTH_NUM, row_num]) == Models.clsDashBoard.DASHBOARD_APPROVAL_WAITING_TYPE_NUM)
                    {
                        page_name = "CashReceipt";
                    }
                    else
                    {
                        page_name = "LookupCashReceipt";
                    }
                }
                else if (cell_val == GlobalVar.goConstant.TRX_PO_TYPE)
                {
                    entity_code = moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num];
                    page_name = "PurchaseOrder";
                }
                else if (cell_val == GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE)
                {
                    entity_code = moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num];
                    page_name = "PurchaseRequisition";
                }
                else if (cell_val == GlobalVar.goConstant.TRX_PURCHASE_TYPE)
                {
                    entity_code = moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num];
                    if (moUtility.ToValue(moDetail.Data[Models.clsDashBoard.DASHBOARD_DEPTH_NUM, row_num]) == Models.clsDashBoard.DASHBOARD_APPROVAL_WAITING_TYPE_NUM)
                    {
                        page_name = "Voucher";
                    }
                    else
                    {
                        page_name = "LookupVoucher";
                    }
                }
                else if (cell_val == GlobalVar.goConstant.TRX_DM_TYPE)
                {
                    entity_code = moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num];
                    if (moUtility.ToValue(moDetail.Data[Models.clsDashBoard.DASHBOARD_DEPTH_NUM, row_num]) == Models.clsDashBoard.DASHBOARD_APPROVAL_WAITING_TYPE_NUM)
                    {
                        page_name = "DebitMemo";
                    }
                    else
                    {
                        page_name = "LookupDebitMemo";
                    }
                }
                else if (cell_val == GlobalVar.goConstant.TRX_PAYMENT_TYPE)
                {
                    entity_code = moDetail.Data[Models.clsDashBoard.DASHBOARD_CODE_NUM, row_num];
                    if (moUtility.ToValue(moDetail.Data[Models.clsDashBoard.DASHBOARD_DEPTH_NUM, row_num]) == Models.clsDashBoard.DASHBOARD_APPROVAL_WAITING_TYPE_NUM)
                    {
                        page_name = "CashPayment";
                    }
                    else
                    {
                        page_name = "LookupCashPayment";
                    }
                }
                else
                {

                }

                if (moUtility.IsNonEmpty(page_name))
                {
                    o_session.SetSessionValues(moDatabase, User, ref session_id, entity_code);
                    FormOpenPDF(page_name + "/" + session_id);
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (DrillDownOnDashBoard)");
            }

            return return_value;
        }

        // ------------------------------------------------------------------------------------------------------------------------------------
        // VISUALIZATION SECTION
        // Redzen Chart  https://blazor.radzen.com/line-chart
        // ------------------------------------------------------------------------------------------------------------------------------------

        private clsRadzenChart[] YearlyChart = new clsRadzenChart[1];
        private clsRadzenChart.clsData[] BSChart = new clsRadzenChart.clsData[1];
        private clsRadzenChart.clsData[] PLChart = new clsRadzenChart.clsData[1];

        private bool GetCharts()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (GetYearlyChart() == false)
            {
                return false;
            }
            if (ViewFinancials)
            {
                modRadzen.chkBalance_fl = true;
                modRadzen.chkFinalcial_fl = true;

                if (GetFinancialCharts() == false)
                {
                    return false;
                }
                if (GetFinancials() == false)
                {
                    return false;
                }
            }
            else
            {
                modRadzen.chkBalance_fl = false;
                modRadzen.chkFinalcial_fl = false;
            }

            return true;
        }

        private bool GetFinancials()
        {
            bool return_value = false;
            string sql_str = "";
            int i = 0;

            clsRecordset cur_set = new clsRecordset(ref moDatabase);
            clsMoney o_money = new clsMoney(ref moDatabase);

            try
            {
                // Some accounts use the same group_type for both, actual and summary, so that we need to get the actuals and get the totals
                //
                sql_str = "SELECT sAccount_cd, iGroup_typ, acct.sDescription, mYTD_amt, acct.mBalance_amt, iSummary_typ, bank.sBank_nm from tblGLAccount acct LEFT JOIN tblBRBankAccount bank ON (acct.sAccount_cd = bank.sGLAcct_cd)";
                sql_str += " WHERE ((iGroup_typ = " + GlobalVar.goGLConstant.PETTY_CASH_NUM + ")";
                sql_str += " OR (iGroup_typ = " + GlobalVar.goGLConstant.CHECK_CASH_NUM + " AND acct.mBalance_amt <> 0)";
                sql_str += " OR (iGroup_typ IN (" + GlobalVar.goGLConstant.INVENTORY_ASSET_NUM + ", " + GlobalVar.goGLConstant.ACCT_RECEIVABLE_NUM.ToString() + ", " + GlobalVar.goGLConstant.ACCT_PAYABLE_NUM.ToString()  + ")))";
                sql_str += " AND iSummary_typ = " + GlobalVar.goGLConstant.ACTUAL_TYPE_NUM.ToString();
                sql_str += " ORDER BY iGroup_typ";   
                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                i = 0;
                while (cur_set.EOF() == false)
                {
                    if (cur_set.iField("iGroup_typ") == GlobalVar.goGLConstant.PETTY_CASH_NUM || cur_set.iField("iGroup_typ") == GlobalVar.goGLConstant.CHECK_CASH_NUM)
                    {
                        i += 1;
                    }
                    cur_set.MoveNext();
                }

                BankData = null;

                if (i > 0)
                {
                    BankData = new clsFinancial.clsBank[i];
                }

                cur_set.MoveFirst();
                i = 0;

                while (cur_set.EOF() == false)
                {
                    if (cur_set.iField("iGroup_typ") == GlobalVar.goGLConstant.PETTY_CASH_NUM || cur_set.iField("iGroup_typ") == GlobalVar.goGLConstant.CHECK_CASH_NUM)
                    {
                        BankData[i] = new clsFinancial.clsBank();
                        BankData[i].lblBank_nm = moUtility.IIf(moUtility.IsNonEmpty(cur_set.sField("sBank_nm")), cur_set.sField("sBank_nm"), cur_set.sField("sDescription"));
                        BankData[i].lblBalance_amt = o_money.ToStrMoney(cur_set.mField("mBalance_amt"));
                        i += 1;

                        Financial.lblBankBalance_amt = o_money.ToStrMoney(o_money.ToNumMoney(Financial.lblBankBalance_amt) + cur_set.mField("mBalance_amt"));
                    }
                    else if (cur_set.iField("iGroup_typ") == GlobalVar.goGLConstant.INVENTORY_ASSET_NUM)
                    {
                        Financial.lblInventory_amt = o_money.ToStrMoney(o_money.ToNumMoney(Financial.lblInventory_amt) + cur_set.mField("mBalance_amt"));
                    }
                    else if (cur_set.iField("iGroup_typ") == GlobalVar.goGLConstant.ACCT_RECEIVABLE_NUM)
                    {
                        Financial.lblReceivable_amt = o_money.ToStrMoney(o_money.ToNumMoney(Financial.lblReceivable_amt) + cur_set.mField("mBalance_amt"));
                    }
                    else if (cur_set.iField("iGroup_typ") == GlobalVar.goGLConstant.ACCT_PAYABLE_NUM)
                    {
                        Financial.lblPayable_amt = o_money.ToStrMoney(o_money.ToNumMoney(Financial.lblPayable_amt) + cur_set.mField("mBalance_amt"));
                    }

                    cur_set.MoveNext();
                }
                
                return_value = true;
            }
            catch(Exception ex)
            {
                FormShowMessage(ex.Message + " (GetFinancials)");
            }

            return return_value;
        }

        // This will show the summaries of sales, expenses & profit over the past one year 
        // 
        // clsRadzenChart[].Data[,] should look like this 
        //          REVENUE	281	283	383
        //          EXPENSE	180	183	293
        //          PROFIT	99	100	100
        // chart_caption[] has the captions 

        private bool GetYearlyChart()
        {
            bool return_value = false;
            string sql_str = "";
            string[,] chart_data = null;
            string[] chart_caption = null;
            int total_col = 12;
            int total_row = 1;
            int i = 0;
            int period_begin = ((moGeneral.ToNumDate(Header.mskApply_dt) / 100) * 100 + 1);

            const int TITLE_COL = 0;
            const int CATEGORY_COL = 1;
            const int VALUE_COL = 2;

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                // Get Revenue total
                //
                sql_str = "SELECT iGroup_typ, iPeriodBegin_dt, SUM(mPeriodNet_amt) AS mTotal_amt FROM tblGLBalance ";
                sql_str += " WHERE (iGroup_typ = 4 OR iGroup_typ = 5)  AND iAcctLevel = 1";
                sql_str += " AND iPeriodBegin_dt > " + moUtility.AddToDate(GlobalVar.goConstant.YEAR_TYPE, period_begin, -1).ToString();
                sql_str += " AND iPeriodBegin_dt <= " + period_begin.ToString();;
                sql_str += " GROUP BY iGroup_typ, iPeriodBegin_dt ORDER BY iGroup_typ, iPeriodBegin_dt";
                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }
                if (cur_set.EOF())
                {
                    return false;
                }

                total_col = 13;     // 12 periods + title

                if (ViewFinancials)
                {
                    total_row = 3;
                }
                else
                {
                    total_row = 1;          // Sales only
                }

                moUtility.ResizeDim(ref chart_data, total_col, total_row - 1);
                moUtility.ResizeDim(ref chart_caption, total_col);

                chart_data[0, 0] = User.Language.oCaption.REVENUE;
                i = 0;

                while (cur_set.EOF() == false)
                {
                    i += 1;
                    chart_data[i, 0] = cur_set.mField("mTotal_amt").ToString();     
                    //chart_caption[i] = moUtility.SLeft(cur_set.iField("iPeriodBegin_dt").ToString(), 4) + "/" +  ((cur_set.iField("iPeriodBegin_dt") / 100) % 100 ).ToString();      // e.g.,  2022.5
                    chart_caption[i] = moUtility.GetStrMonth(moUtility.GetMonth(cur_set.iField("iPeriodBegin_dt")), true)  + " " +  moUtility.GetYear(cur_set.iField("iPeriodBegin_dt"), true);

                    cur_set.MoveNext();

                    if (cur_set.iField("iGroup_typ") == 5)
                    {
                        break;
                    }
                }

                if (ViewFinancials)
                {
                    chart_data[0, 1] = User.Language.oCaption.EXPENSE;
                    i = 0;

                    while (cur_set.EOF() == false)
                    {
                        i += 1;
                        chart_data[i, 1] = cur_set.mField("mTotal_amt").ToString();

                        cur_set.MoveNext();
                    }

                    chart_data[0, 2] = User.Language.oCaption.PROFIT;

                    for (i = 1; i <= 12; i++)
                    {
                        chart_data[i, 2] = (moUtility.ToValue(chart_data[i, 0]) - moUtility.ToValue(chart_data[i, 1])).ToString();
                    }
                }

                if (modRadzen.GetLineChartData(ref moDatabase, ref YearlyChart, chart_data, chart_caption, total_col, total_row, false) == false)
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (GetYearlyChart)");
            }

            return return_value;
        }

        // This will show the yearly P & L
        // 
        // clsRadzenChart.clsData[] should have the data 

        private bool GetFinancialCharts()
        {
            bool return_value = false;
            string[] chart_data = null;
            string[] captions = null;
            string sql_str = "";
            int total_col = 12;
            int total_row = 3;
            int i = 0;
            int period_begin = ((moGeneral.ToNumDate(Header.mskApply_dt) / 100) * 100 + 1);

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                // Get the totals
                //
                //sql_str = "SELECT iGroup_typ, SUM(mPeriodNet_amt) AS mPeriodTotal_amt, SUM(mYearNet_amt) AS mYearTotal_amt FROM tblGLBalance ";
                //sql_str += " WHERE iAcctLevel = 1";
                //sql_str += " AND iPeriodBegin_dt = " + period_begin.ToString(); ;
                //sql_str += " GROUP BY iGroup_typ ORDER BY iGroup_typ";

                sql_str = "SELECT (iGroup_typ / 1000) AS iCategory, SUM(mBalance_amt) AS mTotal_amt FROM tblGLAccount WHERE iAcctLevel = 1 GROUP BY (iGroup_typ / 1000) ORDER BY iCategory";
                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }
                if (cur_set.EOF())
                {
                    return false;
                }

                total_col = 3;
                moUtility.ResizeDim(ref chart_data, total_col - 1);
                moUtility.ResizeDim(ref captions, total_col - 1);

                // Balance Sheet
                //
                i = 0;

                while (cur_set.EOF() == false)
                {
                    if (cur_set.iField("iCategory") > 3)
                    {
                        break;
                    }

                    chart_data[i] = cur_set.mField("mTotal_amt").ToString();

                    if (cur_set.iField("iCategory") == 1)
                    {
                        captions[i] = User.Language.oCaption.ASSET;
                    }
                    else if (cur_set.iField("iCategory") == 2)
                    {
                        captions[i] = User.Language.oCaption.LIABILITY;
                    }
                    else if (cur_set.iField("iCategory") == 3)
                    {
                        captions[i] = User.Language.oCaption.CAPITAL;
                    }

                    cur_set.MoveNext();
                    i += 1;
                }

                if (modRadzen.GetPieData(ref moDatabase, ref BSChart, chart_data, captions, total_col) == false)
                {
                    FormShowMessage();
                    return false;
                }

                moUtility.ResizeDim(ref chart_data, total_col - 1);
                moUtility.ResizeDim(ref captions, total_col - 1);

                // Profit & Loss
                //

                i = 0;

                while (cur_set.EOF() == false)
                {
                    chart_data[i] = cur_set.mField("mTotal_amt").ToString();

                    if (cur_set.iField("iCategory") == 4)
                    {
                        captions[i] = User.Language.oCaption.REVENUE;
                    }
                    else // if (cur_set.iField("iCategory") == 5)
                    {
                        captions[i] = User.Language.oCaption.EXPENSE;
                        break;
                    }

                    cur_set.MoveNext();
                    i += 1;
                }

                captions[2] = User.Language.oCaption.PROFIT;
                chart_data[2] = (moUtility.ToValue(chart_data[0]) - moUtility.ToValue(chart_data[1])).ToString();

                if (modRadzen.GetPieData(ref moDatabase, ref PLChart, chart_data, captions, total_col) == false)
                {
                    FormShowMessage();
                    return false;
                }


                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (GetFinancialCharts)");
            }

            return return_value;
        }

        string FormatValue(object value)
        {
            return modRadzen.FormatValue(value);
        }

        string FormatAsMonth(object value)
        {
            return modRadzen.FormatAsMonth(value);
        }
        // ------------------------------------------------------------------------------------------------------------------------------------
        // END OF VISUALIZATION SECTION
        // ------------------------------------------------------------------------------------------------------------------------------------

    }
}
