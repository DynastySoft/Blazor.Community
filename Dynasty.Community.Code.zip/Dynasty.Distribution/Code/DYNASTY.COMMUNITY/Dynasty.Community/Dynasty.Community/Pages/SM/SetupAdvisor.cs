﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Local;
using System.Diagnostics.Eventing.Reader;

namespace Dynasty.ASP.Pages.SM
{
    public partial class SetupAdvisor
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<SetupAdvisor> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsZoom moZoom;                                                               
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;
        private Models.clsSpreadsheet moSpreadsheet;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader                   
        {
            // Company info
            //
            public string txtCompany_nm = "";
            public string txtAddress1 = "";
            public string txtAddress2 = "";
            public string txtCity = "";
            public string txtState = "";
            public string txtZipCode = "";
            public string txtPhone = "";
            public string txtFax = "";
            public string cboCountry_cd = "";

            public string cboBusiness_typ = "";
            public string cboAccounting_typ = "";

            // Bank account names
            //
            public string txtChecking1Acct_nm = "";
            public string txtChecking2Acct_nm = "";
            public string txtChecking3Acct_nm = "";

            // Beginning numbers
            //
            public string txtQuote_num = "";
            public string txtOrder_num = "";
            public string txtInvoice_num = "";

            // Tax
            //
            public string txtStateTax = "";
            public string txtCountyTax = "";
            public string txtCityTax = "";
            //public string txtPurchaseTax = "";
            public string cboTax_typ = "";

            // Current fiscal year
            //
            public string txtCurrentYear = "";
            public string mskFirstDateOfYear_dt = "";
            public int optPeriods = 0;

            public DateTime? dtFirstDateOfYear_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag                                                                     
            {
                public string txtStateTax = "";
                public string txtCountyTax = "";
                public string txtCityTax = "";
                //public string txtPurchaseTax = "";
                public string mskFirstDateOfYear_dt = "";

                public DateTime? dtFirstDateOfYear_dt = null;
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()                                                                  
            {
                Tag.txtStateTax = txtStateTax;
                Tag.txtCountyTax = txtCountyTax;
                Tag.txtCityTax = txtCityTax;
                //Tag.txtPurchaseTax = txtPurchaseTax;

                Tag.mskFirstDateOfYear_dt = mskFirstDateOfYear_dt;
                Tag.dtFirstDateOfYear_dt = dtFirstDateOfYear_dt;

            }
        }
        private clsHeader Header = new clsHeader();

        public const int VIEW_COMPANY = 0;
        public const int VIEW_BANK = 1;
        public const int VIEW_BEGINNING_NUMBERS = 2;
        public const int VIEW_TAX = 3;
        public const int VIEW_FISCAL_YEAR = 4;
        public const int VIEW_EXECUTE = 5;

        private List<Models.clsCombobox> CountryCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> PeriodList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> BusinessTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> AccountingTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> TaxTypeList = new List<Models.clsCombobox>();

        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;                        
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtFirstDateOfYear_dt, ref Header.mskFirstDateOfYear_dt, use_date_picker);

            return true;
        }
        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            if (FormCheckHeader() == false)
            {
                return false;
            }
            else if (FormCheckExtra() == false)
            {
                return false;
            }

            return true;
        }

        private bool FormCheckExtra()                                                              // validate extra other than the header and detail.
        {
            bool return_value = false;

            try
            {
                
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckExtra)");
            }

            return return_value;
        }

        private bool FormCheckHeader()                                                             // validate the header data.
        {
            bool return_value = false;

            try
            {
                FormSyncDates(User.bUseDatePicker_fl);

                Header.txtCompany_nm = moUtility.EvalQuote(moUtility.STrim(Header.txtCompany_nm));
                Header.txtAddress1 = moUtility.EvalQuote(moUtility.STrim(Header.txtAddress1));
                Header.txtAddress2 = moUtility.EvalQuote(moUtility.STrim(Header.txtAddress2));
                Header.txtCity = moUtility.EvalQuote(moUtility.STrim(Header.txtCity));
                Header.txtState = moUtility.EvalQuote(moUtility.STrim(Header.txtState));
                Header.txtZipCode = moUtility.EvalQuote(moUtility.STrim(Header.txtZipCode));
                Header.txtPhone = moUtility.EvalQuote(moUtility.STrim(Header.txtPhone));
                Header.txtFax = moUtility.EvalQuote(moUtility.STrim(Header.txtFax));

                if (moUtility.IsEmpty(Header.cboCountry_cd))
                {
                    Header.cboCountry_cd = User.Language.oString.STR_UNITED_STATES_OF_AMERICA;
                }

                Header.txtChecking1Acct_nm = moUtility.EvalQuote(moUtility.STrim(Header.txtChecking1Acct_nm));
                Header.txtChecking2Acct_nm = moUtility.EvalQuote(moUtility.STrim(Header.txtChecking2Acct_nm));
                Header.txtChecking3Acct_nm = moUtility.EvalQuote(moUtility.STrim(Header.txtChecking3Acct_nm));

                if (moUtility.ToInteger(Header.txtQuote_num, true) <= 0)
                {
                    Header.txtQuote_num = "1";
                }
                else
                {
                    Header.txtQuote_num = moUtility.ToInteger(Header.txtQuote_num, true).ToString();
                }

                if (moUtility.ToInteger(Header.txtOrder_num, true) <= 0)
                {
                    Header.txtOrder_num = "1";
                }
                else
                {
                    Header.txtOrder_num = moUtility.ToInteger(Header.txtOrder_num, true).ToString();
                }

                if (moUtility.ToInteger(Header.txtInvoice_num, true) <= 0)
                {
                    Header.txtInvoice_num = "1";
                }
                else
                {
                    Header.txtInvoice_num = moUtility.ToInteger(Header.txtInvoice_num, true).ToString();
                }


                if (moUtility.ToValue(Header.txtStateTax, 5) <= 0)
                {
                    Header.txtStateTax = "";
                }
                else
                {
                    Header.txtStateTax = moUtility.ToValue(Header.txtStateTax, 5).ToString();
                }

                if (moUtility.ToValue(Header.txtCountyTax, 5) <= 0)
                {
                    Header.txtCountyTax = "";
                }
                else
                {
                    Header.txtCountyTax = moUtility.ToValue(Header.txtCountyTax, 5).ToString();

                }

                if (moUtility.ToValue(Header.txtCityTax, 5) <= 0)
                {
                    Header.txtCityTax = "";
                }
                else
                {
                    Header.txtCityTax = moUtility.ToValue(Header.txtCityTax, 5).ToString();
                }

                //if (moUtility.ToValue(Header.txtPurchaseTax, 5) <= 0)
                //{
                //    Header.txtPurchaseTax = "";
                //}
                //else
                //{
                //    Header.txtPurchaseTax = moUtility.ToValue(Header.txtPurchaseTax, 5).ToString();
                //}

                if (moUtility.ToInteger(Header.cboBusiness_typ) <= 0)
                {
                    Header.cboBusiness_typ = GlobalVar.goConstant.INVENTORY_BUSINESS_NUM.ToString();
                }
                if (moUtility.ToInteger(Header.cboAccounting_typ) <= 0)
                {
                    Header.cboAccounting_typ = GlobalVar.goConstant.ACCRUAL_ACCOUNTING_TYPE_NUM.ToString();
                }
                if (moUtility.ToInteger(Header.cboTax_typ) <= 0)
                {
                    Header.cboTax_typ = GlobalVar.goConstant.REGULAR_TAX_NUM.ToString();
                }
                if (moUtility.IsEmpty(Header.cboCountry_cd))
                {
                    Header.cboCountry_cd = User.Language.oString.STR_UNITED_STATES_OF_AMERICA;
                }
                if (Header.optPeriods == 0)
                {
                    Header.optPeriods = 12;
                }


                if (moUtility.IsEmpty(Header.txtCompany_nm))
                {
                    FormShowMessage("Please, enter company name.");
                    FormSwitchView(VIEW_COMPANY);
                    FormSetFocus("txtCompany_nm");
                    return false;
                }
                if (moUtility.IsEmpty(Header.txtChecking1Acct_nm))
                {
                    FormShowMessage("Please, enter all three bank account names.");
                    FormSwitchView(VIEW_BANK);
                    FormSetFocus("txtChecking1Acct_nm");
                    return false;
                }
                if (moUtility.IsEmpty(Header.txtChecking2Acct_nm))
                {
                    FormShowMessage("Please, enter all three bank account names.");
                    FormSwitchView(VIEW_BANK);
                    FormSetFocus("txtChecking2Acct_nm");
                    return false;
                }
                if (moUtility.IsEmpty(Header.txtChecking3Acct_nm))
                {
                    FormShowMessage("Please, enter all three bank account names.");
                    FormSwitchView(VIEW_BANK);
                    FormSetFocus("txtChecking3Acct_nm");
                    return false;
                }

                if (Header.txtChecking1Acct_nm == Header.txtChecking2Acct_nm || Header.txtChecking1Acct_nm == Header.txtChecking3Acct_nm || Header.txtChecking2Acct_nm == Header.txtChecking3Acct_nm)
                {
                    FormShowMessage("Please, enter different bank account names.");
                    FormSwitchView(VIEW_BANK);
                    FormSetFocus("txtChecking1Acct_nm");
                    return false;
                }

                if (moUtility.IsEmpty(Header.txtCurrentYear))
                {
                    FormShowMessage("Please, enter the current fiscal year.");
                    FormSwitchView(VIEW_FISCAL_YEAR);
                    FormSetFocus("txtCurrentYear");
                    return false;
                }

                // Accept last year and this year only
                //
                if (moUtility.ToInteger(Header.txtCurrentYear) != moGeneral.CurrentYear() - 1 && moUtility.ToInteger(Header.txtCurrentYear) != moGeneral.CurrentYear())
                {
                    FormShowMessage("Please, enter " + (moGeneral.CurrentYear() - 1).ToString() + " or " + moGeneral.CurrentYear().ToString() + ".");
                    FormSwitchView(VIEW_FISCAL_YEAR);
                    FormSetFocus("txtCurrentYear");
                    return false;
                }
                if (moGeneral.IsValidDate(Header.mskFirstDateOfYear_dt) == false)
                {
                    FormShowMessage("Please, enter a valid date.");
                    FormSwitchView(VIEW_FISCAL_YEAR);

                    if (User.bUseDatePicker_fl)
                    {
                        FormSetFocus("dtFirstDateOfYear_dt");
                    }
                    else
                    {
                        FormSetFocus("mskFirstDateOfYear_dt");
                    }
                    return false;
                }
                if (moUtility.GetYear(moGeneral.ToNumDate(Header.mskFirstDateOfYear_dt)) != moUtility.ToInteger(Header.txtCurrentYear))
                {
                    FormShowMessage("The year in 'First Date of Year' does not match 'Fiscal Year'.");
                    FormSwitchView(VIEW_FISCAL_YEAR);

                    if (User.bUseDatePicker_fl)
                    {
                        FormSetFocus("dtFirstDateOfYear_dt");
                    }
                    else
                    {
                        FormSetFocus("mskFirstDateOfYear_dt");
                    }
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckHeader)");
            }

            return return_value;
        }

        private bool FormCheckConcurrency(clsRecordset cur_set)                                    // Check if someone has changed this record while it is open in this session.
        {
            if (cur_set.IsNonEmpty()) 
            {
                if (moPage.bNew_fl)
                {
                    // If someone has created a record with the same key
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.DUPLICATE_IS_FOUND + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                    moPage.bNew_fl = false;
                }
                else if (moPage.CheckForConcurrency(cur_set) == false)
                {
                    // If someone has updated this record in the meantime.
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        private bool FormCheckToDelete()
        {

            return true;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearExtra();

            return true;
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {
            Header.txtCompany_nm = "";

            return true;
        }

        private bool FormClearMessage()                                                            
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            bool return_value = false;

            try
            {
                
                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDelete)");
                moDatabase.TransactionRollback();
                return_value = false;
            }

            return return_value;
        }

        private bool FormDeleteExtra()
        {

            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormFindRecord(ref clsRecordset cur_set, int matching_type = 0)
        {
            bool return_value = false;

            return return_value;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.SMMENU_NAME;
            moPage.Title = "Setup Advisor";
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);
            
            Modal.Release();

            FormInitHeader();

            moPage.iCurrentView = VIEW_COMPANY;
            FormSwitchView(moPage.iCurrentView);

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = ""; 
            moPage.sKeyField_nm = "";
            moPage.iTransaction_typ= 0;

            return true;
        }

        private bool FormPostEvent()
        {

            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            // FormSave() & FormCheck() use the plain textbox whose name starts with "msk"
            // dt* variables are only to interact with UI.  Internally, msk* fields are used.
            //
            FormSyncDates(User.bUseDatePicker_fl);

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback
            
            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;

            try 
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                modLoadUtility.LoadCountryCode(ref moDatabase, ref CountryCodeList);
                modLoadUtility.LoadAccountingType(ref moDatabase, ref AccountingTypeList);
                modLoadUtility.LoadBusinessType(ref moDatabase, ref BusinessTypeList);
                modLoadUtility.LoadSalesTaxType(ref moDatabase, ref TaxTypeList);

                Header.cboBusiness_typ = GlobalVar.goConstant.INVENTORY_BUSINESS_NUM.ToString();
                Header.cboAccounting_typ = GlobalVar.goConstant.ACCRUAL_ACCOUNTING_TYPE_NUM.ToString();
                Header.cboTax_typ = GlobalVar.goConstant.REGULAR_TAX_NUM.ToString();
                Header.cboCountry_cd = User.Language.oString.STR_UNITED_STATES_OF_AMERICA;
                Header.txtCurrentYear = moGeneral.CurrentYear().ToString();

                Header.optPeriods = 12;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormMove(int record_move_direction)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormClear();

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            if (FormFindRecord(ref cur_set, record_move_direction) == false)
            {
                return false;
            }

            FormShow(cur_set);
            return true;

        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostSave()
        {


            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {

            return true;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormSave()
        {
            bool return_value = false;
            clsRecordset cur_set;

            clsSetupAdvisor o_setup = new clsSetupAdvisor(ref moDatabase, moUtility.ToInteger(Models.Length.KEY_CODE));

            try
            {
                if (FormOpenDatabase() == false)                     // Has to come before FormCheck()
                {
                    return false;
                }
                else if (FormCheck() == false)                       // Check if data is ok to save.
                {
                    return false;
                }
                
                if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (o_setup.SetupDefaultDynasty(Header.cboCountry_cd, Header.txtCurrentYear, moUtility.GetMonth(moGeneral.ToNumDate(Header.mskFirstDateOfYear_dt))
                , Header.optPeriods, moUtility.ToInteger(Header.cboBusiness_typ),   moUtility.ToInteger(Header.cboAccounting_typ)
                , moUtility.ToValue(Header.txtStateTax), moUtility.ToValue(Header.txtCountyTax), moUtility.ToValue(Header.txtCityTax), Header.txtChecking1Acct_nm
                , Header.txtChecking2Acct_nm, Header.txtChecking3Acct_nm) == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }
                else if (SaveCompany() == false)                // This should come after SetupDefaultDynasty because of period setup
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (SaveNextNumbers() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (moDatabase.TransactionCommit() == false)
                {
                    FormShowMessage();
                    moDatabase.TransactionRollback();
                    return false;
                }

                modSetupUtility.SetCompanyName(moDatabase);

                FormPostSave();
                    
                return_value = true;

            }
            catch (Exception ex)
            {

                FormShowMessage(ex.Message + " (FormSave)");
                moDatabase.TransactionRollback();

            }

            return return_value;
        }

        private bool FormSaveExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormSaveHeader(clsRecordset cur_set)
        {
            bool return_value = false;
            string sql_str = null;

            try
            {
                
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveHeader)");
            }

            return return_value;
        }

        private bool FormSearch()
        {

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {
            if (FormShowHeader(cur_set) == false)
            {
                return false;
            }
            else if (FormShowExtra(cur_set) == false)
            {
                return false;
            }

            FormReArrangeHeader();

            return true;
        }

        private bool FormShowExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowHeader(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowHeader)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowListing(int new_view)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moListing.Show(moDatabase, moPage) == false)
            {
                return false;
            }

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            if (VIEW_EXECUTE >= cur_page && VIEW_COMPANY <= cur_page)
            {
                moPage.iCurrentView = cur_page;
            }

            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
            {
                return false;
            }

            FormCancel();
            return true;
        }

        private bool btnDelete_Clicked()
        {
            
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtCompany_nm))
            {
                FormExit();
                return true;
            }

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }

        private bool btnFirst_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnFirst_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.FIRST_RECORD_TYPE);
        }

        private bool btnLast_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnLast_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.LAST_RECORD_TYPE);
        }

        private bool btnNext_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnNext_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.NEXT_RECORD_TYPE);
        }

        private bool btnPrevious_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnPrevious_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.PREVIOUS_RECORD_TYPE);
        }

        private bool btnSave_Clicked()
        {
            FormPreEvent();

            if (FormSave() == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdView_Clicked(int new_view)
        {
            FormPreEvent();                                                                           
            FormSwitchView(new_view);

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================


        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        private bool dtFirstDateOfYear_dt_Changed()
        {
            if (Header.dtFirstDateOfYear_dt == Header.Tag.dtFirstDateOfYear_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtFirstDateOfYear_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtFirstDateOfYear_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtFirstDateOfYear_dt) == false)
            {
                Header.dtFirstDateOfYear_dt = Header.Tag.dtFirstDateOfYear_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtFirstDateOfYear_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskFirstDateOfYear_dt_Changed()
        {
            if (Header.mskFirstDateOfYear_dt == Header.Tag.mskFirstDateOfYear_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskFirstDateOfYear_dt) == false)
            {
                Header.mskFirstDateOfYear_dt = Header.Tag.mskFirstDateOfYear_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskFirstDateOfYear_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdExcecute_Clicked()
        {
            if (FormDialog(cmdExcecute_Clicked, 100,  "This will initialize the system and may take a few minutes. Do you want to proceed?") == false)
            {
                return false;
            }

            if (FormSave() == false)
            {
                return false;
            }

            FormExit();

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================
        private bool SaveCompany()
        {
            bool return_value = false;
            string sql_str = "";
            
            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                sql_str = "SELECT * FROM tblGLPeriodDet WHERE sFiscalYear = '" + Header.txtCurrentYear + "' ORDER BY iPeriodBegin_dt";
                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (cur_set.EOF())
                {
                    FormShowMessage("Cannot read period table.");
                    return false;
                }

                sql_str = "UPDATE tblGOMaster SET";
                sql_str += " iBusiness_typ=" + Header.cboBusiness_typ;
                sql_str += ",iAccounting_typ=" + Header.cboAccounting_typ;
                sql_str += ",sCity='" + Header.txtCity + "'";
                sql_str += ",sState='" + Header.txtState + "'";
                sql_str += ",sZipCode='" + Header.txtZipCode + "'";
                sql_str += ",sAddress3='" + moUtility.SLeft(moUtility.STrim(Header.txtCity) + ", " + moUtility.STrim(Header.txtState) + " " + moUtility.STrim(Header.txtZipCode), 40) + "'";
                sql_str += ",sAddress2='" + Header.txtAddress2 + "'";
                sql_str += ",sAddress1='" + Header.txtAddress1 + "'";
                sql_str += ",sCompany_nm='" + Header.txtCompany_nm + "'";
                sql_str += ",sPhone='" + Header.txtPhone + "'";
                sql_str += ",sFax='" + Header.txtFax + "'";
                sql_str += ",sCountry_cd='" + Header.cboCountry_cd + "'";
                sql_str += ",iGLAcctCode_typ = 1";

                if (moDatabase.CommunityVersion)
                {
                    sql_str += ",iGLExist_fl = 1";
                    sql_str += ",iIVExist_fl = 1";
                    sql_str += ",iARExist_fl = 1";
                    sql_str += ",iAPExist_fl = 1";
                    sql_str += ",iSOExist_fl = 1";
                    sql_str += ",iPOExist_fl = 0";
                    sql_str += ",iJCExist_fl = 0";
                    sql_str += ",iBRExist_fl = 0";
                    sql_str += ",iPRExist_fl = 0";
                    sql_str += ",iHRExist_fl = 0";
                    sql_str += ",iFAExist_fl = 0";
                    sql_str += ",iWHExist_fl = 0";
                    sql_str += ",iMCExist_fl = 0";
                    sql_str += ",iMFExist_fl = 0";
                    sql_str += ",iCMExist_fl = 0";
                    sql_str += ",iNPExist_fl = 0";
                    sql_str += ",iWOExist_fl = 0";
                    sql_str += ",iRTExist_fl = 0";
                    sql_str += ",iRCExist_fl = 0";
                    sql_str += ",iIEExist_fl = 0";
                }

                sql_str += ",sCurrentFiscalYear='" + moUtility.EvalQuote(Header.txtCurrentYear) + "'";
                cur_set.MoveFirst();
                sql_str += ",iCurrentYearBegin_dt=" + cur_set.iField("iPeriodBegin_dt");
                cur_set.MoveLast();
                sql_str += ",iCurrentYearEnd_dt=" + cur_set.iField("iPeriodEnd_dt");
                
                if (cur_set.CreateSnapshot("SELECT * FROM tblGLPeriodDet WHERE sFiscalYear = '" + Header.txtCurrentYear + "' AND " + moGeneral.CurrentDate().ToString() + " BETWEEN iPeriodBegin_dt AND iPeriodEnd_dt") == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (cur_set.EOF())
                {
                    FormShowMessage("Cannot read period table.");
                    return false;
                }

                sql_str += ",iCurrentPeriodBegin_dt=" + cur_set.iField("iPeriodBegin_dt");
                sql_str += ",iCurrentPeriodEnd_dt=" + cur_set.iField("iPeriodEnd_dt");

                if (!moDatabase.ExecuteSQL(sql_str))
                {
                    return return_value;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SaveCompany)");
            }

            return return_value;
        }

        private bool SaveNextNumbers()
        {
            bool return_value = false;
            string sql_str = "";

            try
            {
                sql_str = "UPDATE tblGONextTransactionNumber SET ";
                sql_str += " iNext_num = " + Header.txtInvoice_num;
                sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_INVOICE_TYPE.ToString();
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                sql_str = "UPDATE tblGONextTransactionNumber SET ";
                sql_str += " iNext_num = " + Header.txtOrder_num;
                sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_SO_TYPE.ToString();
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                sql_str = "UPDATE tblGONextTransactionNumber SET ";
                sql_str += " iNext_num = " + Header.txtQuote_num;
                sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_QUOTE_TYPE.ToString();
                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SaveNextNumbers)");
            }

            return return_value;
        }

    }
 }
