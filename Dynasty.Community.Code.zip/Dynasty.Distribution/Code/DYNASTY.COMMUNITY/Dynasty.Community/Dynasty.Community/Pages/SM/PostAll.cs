﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP.Pages.SM
{
    public partial class PostAll
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<PostAll> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;
        private Models.clsEntitySearch moSearch;
        private Models.clsSpreadsheet moPostingError;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsBatch moBatch;

        private List<Models.clsCombobox> BatchList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> JournalCodeList = new List<Models.clsCombobox>();

        private bool mbErrorFound_fl = false;

        private int miDateFrom_num = 0;
        private int miDateThru_num = 0;
        private int miBatchFrom_num = 0;
        private int miBatchThru_num = 0;

        private bool BatchExist
        {
            get
            {
                return (moUtility.ToInteger(Header.cboBatch_num) > 0);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader
        {
            // Listing of UI items on the header
            //

            public string cboBatch_num = "";
            public bool chkProceedOnError_fl = false;

            // A/P
            //
            public bool chkAllAP_fl = false;
            public bool chkVoucher_fl = false;
            public string txtVoucherFrom = "";
            public string txtVoucherThru = "";

            public bool chkCashPayment_fl = false;
            public string txtCashPaymentFrom = "";
            public string txtCashPaymentThru = "";

            public bool chkDebitMemo_fl = false;
            public string txtDebitMemoFrom = "";
            public string txtDebitMemoThru = "";

            public bool chkStopPayment_fl = false;
            public string txtStopPaymentFrom = "";
            public string txtStopPaymentThru = "";

            public bool chkAllMCAP_fl = false;
            public bool chkMCVoucher_fl = false;
            public string txtMCVoucherFrom = "";
            public string txtMCVoucherThru = "";

            public bool chkMCCashPayment_fl = false;
            public string txtMCCashPaymentFrom = "";
            public string txtMCCashPaymentThru = "";

            public bool chkMCDebitMemo_fl = false;
            public string txtMCDebitMemoFrom = "";
            public string txtMCDebitMemoThru = "";

            public bool chkMCStopPayment_fl = false;
            public string txtMCStopPaymentFrom = "";
            public string txtMCStopPaymentThru = "";

            // A/R
            //
            public bool chkAllAR_fl = false;
            public bool chkInvoice_fl = false;
            public string txtInvoiceFrom = "";
            public string txtInvoiceThru = "";

            public bool chkCashReceipt_fl = false;
            public string txtCashReceiptFrom = "";
            public string txtCashReceiptThru = "";

            public bool chkCreditMemo_fl = false;
            public string txtCreditMemoFrom = "";
            public string txtCreditMemoThru = "";

            public bool chkNSF_fl = false;
            public string txtNSFFrom = "";
            public string txtNSFThru = "";

            public bool chkAllMCAR_fl = false;
            public bool chkMCInvoice_fl = false;
            public string txtMCInvoiceFrom = "";
            public string txtMCInvoiceThru = "";

            public bool chkMCCashReceipt_fl = false;
            public string txtMCCashReceiptFrom = "";
            public string txtMCCashReceiptThru = "";

            public bool chkMCCreditMemo_fl = false;
            public string txtMCCreditMemoFrom = "";
            public string txtMCCreditMemoThru = "";

            public bool chkMCNSF_fl = false;
            public string txtMCNSFFrom = "";
            public string txtMCNSFThru = "";

            // Inventory
            //
            public bool chkAllIV_fl = false;
            public bool chkPurchase_fl = false;
            public string txtPurchaseFrom = "";
            public string txtPurchaseThru = "";

            public bool chkPurchaseReturn_fl = false;
            public string txtPurchaseReturnFrom = "";
            public string txtPurchaseReturnThru = "";

            public bool chkSale_fl = false;
            public string txtSaleFrom = "";
            public string txtSaleThru = "";

            public bool chkSaleReturn_fl = false;
            public string txtSaleReturnFrom = "";
            public string txtSaleReturnThru = "";

            public bool chkTransferOut_fl = false;
            public string txtTransferOutFrom = "";
            public string txtTransferOutThru = "";

            public bool chkTransferIn_fl = false;
            public string txtTransferInFrom = "";
            public string txtTransferInThru = "";

            public bool chkPhysical_fl = false;
            public string txtPhysicalFrom = "";
            public string txtPhysicalThru = "";

            public bool chkSpoilage_fl = false;
            public string txtSpoilageFrom = "";
            public string txtSpoilageThru = "";

            public bool chkInternalUse_fl = false;
            public string txtInternalUseFrom = "";
            public string txtInternalUseThru = "";

            // G/L
            //
            public bool chkJournal_fl = false;
            public string txtJournalFrom = "";
            public string txtJournalThru = "";
            public string cboJournal_cd = "";

            // B/R
            //
            public bool chkAllBR_fl = false;
            public bool chkBRIncome_fl = false;
            public string txtBRIncomeFrom = "";
            public string txtBRIncomeThru = "";

            public bool chkBRExpense_fl = false;
            public string txtBRExpenseFrom = "";
            public string txtBRExpenseThru = "";

            public bool chkBRDeposit_fl = false;
            public string txtBRDepositFrom = "";
            public string txtBRDepositThru = "";

            public bool chkBRWithdrawal_fl = false;
            public string txtBRWithdrawalFrom = "";
            public string txtBRWithdrawalThru = "";

            public bool chkBRTransfer_fl = false;
            public string txtBRTransferFrom = "";
            public string txtBRTransferThru = "";

            public bool chkBRDepositSlip_fl = false;
            public string txtBRDepositSlipFrom = "";
            public string txtBRDepositSlipThru = "";

            // Datetime component is not very user-friendly, yet, as of VS2019.
            // For better understanding this, read the comment on bUseDatePicker_fl in clsUser.
            //
            public string mskFrom_dt = "";
            public string mskThru_dt = "";
            public DateTime? dtFrom_dt = null;
            public DateTime? dtThru_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag
            {
                public string cboBatch_num = "";
                public string cboJournal_cd = "";

                public string mskFrom_dt = "";
                public string mskThru_dt = "";
                public DateTime? dtFrom_dt = null;
                public DateTime? dtThru_dt = null;
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()
            {
                Tag.cboBatch_num = cboBatch_num;
                Tag.cboJournal_cd = cboJournal_cd;

                Tag.mskFrom_dt = mskFrom_dt;
                Tag.mskThru_dt = mskThru_dt;
                Tag.dtFrom_dt = dtFrom_dt;
                Tag.dtThru_dt = dtThru_dt;
            }
        }
        private clsHeader Header = new clsHeader();


        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows()
        {

            return true;
        }

        private bool FormCalculateTotal()
        {

            return true;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            bool return_value = false;
            string post_year = "";
            string tmp = "";

            if (FormCheckSecurity() == false)
            {
                return false;
            }

            try
            {
                FormSyncDates(User.bUseDatePicker_fl);

                if (moDatabase.uProgram.bGLExist_fl && moUtility.IsEmpty(moDatabase.sDefCEAccount_cd))
                {
                    FormShowMessage(User.Language.oMessage.DEF_CE_ACCT_IS_NOT_SETUP);
                    return false;
                }

                if (moUtility.IsBlankDate(Header.mskFrom_dt))
                {
                    Header.mskFrom_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());           // When batch number is given, dates are ignored 
                }

                if (moUtility.IsBlankDate(Header.mskThru_dt))
                {
                    Header.mskThru_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                }

                if (moGeneral.ToNumDate(Header.mskThru_dt) < moGeneral.ToNumDate(Header.mskFrom_dt))
                {
                    moUtility.Swap(ref Header.mskFrom_dt, ref Header.mskThru_dt);
                }

                FormSyncDates(false);       // In case the dates are changed here.

                post_year = moDatabase.sCurFiscalYear;

                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                if (moGeneral.ValidDateForPosting(moGeneral.ToNumDate(Header.mskFrom_dt), ref post_year) == false || moGeneral.ValidDateForPosting(moGeneral.ToNumDate(Header.mskThru_dt), ref post_year) == false)
                {
                    if (FormDialog(cmdPostNow_Clicked, 100, User.Language.oMessage.INVALID_DATE_IN_CURRENT_YEAR_PROCEED) == false)
                    {
                        return false;
                    }

                    // 02/18/2024       Make sure the dates are valid in the period table.
                    //
                    if (moValidate.IsValidFiscalPeriod(moGeneral.ToNumDate(Header.mskFrom_dt), "", true) == false)
                    {
                        FormShowMessage(Header.mskFrom_dt + " " + User.Language.oMessage.IS_INVALID);
                        return false;
                    }

                    if (moUtility.GetYear(moGeneral.ToNumDate(Header.mskFrom_dt)) != moUtility.GetYear(moGeneral.ToNumDate(Header.mskThru_dt)))
                    {
                        if (moValidate.IsValidFiscalPeriod(moGeneral.ToNumDate(Header.mskThru_dt), "", true) == false)
                        {
                            FormShowMessage(Header.mskThru_dt + " " + User.Language.oMessage.IS_INVALID);
                            return false;
                        }
                    }
                }

                miDateFrom_num = moGeneral.ToNumDate(Header.mskFrom_dt);
                miDateThru_num = moGeneral.ToNumDate(Header.mskThru_dt);

                miBatchFrom_num = 0;
                miBatchThru_num = 0;

                if (moUtility.IsNonEmpty(Header.cboBatch_num) && User.bBatchEnabled_fl)
                {
                    if (moUtility.ToInteger(Header.cboBatch_num) == GlobalVar.goConstant.FOR_ALL_NUM)   // User-specific transactions will be imposed in PostOneTransaction()
                    {
                        miBatchFrom_num = 1;
                        miBatchThru_num = clsBatch.LASRGEST_BATCH_NUM;      // a very large number
                    }
                    else
                    {
                        miBatchFrom_num = moUtility.ToInteger(Header.cboBatch_num);
                        miBatchThru_num = moUtility.ToInteger(Header.cboBatch_num);
                    }
                }

                if (BatchExist)
                {
                    Header.chkAllAP_fl = true;
                    Header.chkAllMCAP_fl = true;
                    Header.chkAllAR_fl = true;
                    Header.chkAllMCAR_fl = true;
                    Header.chkAllIV_fl = true;
                    Header.chkAllBR_fl = true;

                    chkAllAP_fl_Clicked();
                    chkAllMCAP_fl_Clicked();
                    chkAllAR_fl_Clicked();
                    chkAllMCAR_fl_Clicked();
                    chkAllIV_fl_Clicked();
                    chkAllBR_fl_Clicked();

                    Header.chkJournal_fl = false;
                    Header.chkAllAP_fl = false;
                    Header.chkAllMCAP_fl = false;
                    Header.chkAllAR_fl = false;
                    Header.chkAllMCAR_fl = false;
                    Header.chkAllIV_fl = false;
                    Header.chkAllBR_fl = false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheck)");
            }

            return return_value;
        }


        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearExtra();

            return true;
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {

            return true;
        }

        private bool FormClearMessage()
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormFindRecord(ref clsRecordset cur_set, int matching_type = 0)
        {
            bool return_value = false;

            matching_type = (int)(moUtility.IIf(matching_type > 0, matching_type, GlobalVar.goConstant.MATCHING_RECORD_TYPE));
            return_value = modFormUtility.RecordRead(ref moDatabase, ref cur_set, Header.txtVoucherFrom, moPage.sTable_nm, moPage.sKeyField_nm, moPage.sPreviousKey_id, moPage.sRestrictionClause, ref matching_type);

            return return_value;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moPostingError = new Models.clsSpreadsheet();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moBatch = new clsBatch();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.SMMENU_NAME;
            moPage.Title = User.Language.oCaption.DAILY_POSTING;
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormInitHeader();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = "";
            moPage.sKeyField_nm = "";
            moPage.iTransaction_typ = 0;

            return true;
        }

        private bool FormPostEvent()
        {
            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            // FormSave() & FormCheck() use the plain textbox whose name starts with "msk"
            // dt* variables are only to interact with UI.  Internally, msk* fields are used.
            //
            FormSyncDates(User.bUseDatePicker_fl);


            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback

            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;
            bool discrete_fl = false;

            try
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                discrete_fl = User.bBatchEnabled_fl;

                modLoadUtility.LoadJournalCode(ref moDatabase, ref JournalCodeList);

                if (discrete_fl)
                {
                    modLoadUtility.LoadBatchNumbers(ref moDatabase, ref BatchList, moDatabase.sUser_cd);
                }

                if (moDatabase.uSecurity.bBlockTransaction_fl && moDatabase.iUserType_id < clsConstant.USER_SUPERVISOR_TYPE)
                {
                    discrete_fl = true;
                }

                Header.mskFrom_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                Header.mskThru_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                FormSyncDates(false);

                FormSwitchView(moView.AP_PAGE_NUM);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }
        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtFrom_dt, ref Header.mskFrom_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtThru_dt, ref Header.mskThru_dt, use_date_picker);

            return true;
        }
        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }


        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtVoucherFrom))
            {
                FormExit();
                return true;
            }

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }
        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdAP_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.AP_PAGE_NUM);

            return true;
        }
        private bool cmdAR_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.AR_PAGE_NUM);

            return true;
        }
        private bool cmdIV_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.IV_PAGE_NUM);

            return true;
        }
        private bool cmdGL_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.GL_PAGE_NUM);

            return true;
        }

        private bool cmdBR_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.BR_PAGE_NUM);

            return true;
        }

        private bool cmdError_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.ERROR_PAGE_NUM);

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        
        private bool chkAllAP_fl_Clicked()
        {
            FormPreEvent();

            Header.chkVoucher_fl = (Header.chkAllAP_fl == false);
            Header.chkDebitMemo_fl = (Header.chkAllAP_fl == false);
            Header.chkCashPayment_fl = (Header.chkAllAP_fl == false);
            Header.chkStopPayment_fl = (Header.chkAllAP_fl == false);

            return FormPostEvent();
        }
        private bool chkAllMCAP_fl_Clicked()
        {
            FormPreEvent();

            Header.chkMCVoucher_fl = (Header.chkAllMCAP_fl == false);
            Header.chkMCDebitMemo_fl = (Header.chkAllMCAP_fl == false);
            Header.chkMCCashPayment_fl = (Header.chkAllMCAP_fl == false);
            Header.chkMCStopPayment_fl = (Header.chkAllMCAP_fl == false);

            return FormPostEvent();
        }

        private bool chkAllAR_fl_Clicked()
        {
            FormPreEvent();

            Header.chkInvoice_fl = (Header.chkAllAR_fl == false);
            Header.chkCreditMemo_fl = (Header.chkAllAR_fl == false);
            Header.chkCashReceipt_fl = (Header.chkAllAR_fl == false);
            Header.chkNSF_fl = (Header.chkAllAR_fl == false);

            return FormPostEvent();
        }

        private bool chkAllMCAR_fl_Clicked()
        {
            FormPreEvent();

            Header.chkMCInvoice_fl = (Header.chkAllMCAR_fl == false);
            Header.chkMCCreditMemo_fl = (Header.chkAllMCAR_fl == false);
            Header.chkMCCashReceipt_fl = (Header.chkAllMCAR_fl == false);
            Header.chkMCNSF_fl = (Header.chkAllMCAR_fl == false);

            return FormPostEvent();
        }

        private bool chkAllIV_fl_Clicked()
        {
            FormPreEvent();

            Header.chkPurchase_fl = (Header.chkAllIV_fl == false);
            Header.chkPurchaseReturn_fl = (Header.chkAllIV_fl == false);
            Header.chkSale_fl = (Header.chkAllIV_fl == false);
            Header.chkSaleReturn_fl = (Header.chkAllIV_fl == false);
            Header.chkSpoilage_fl = (Header.chkAllIV_fl == false);
            Header.chkPhysical_fl = (Header.chkAllIV_fl == false);
            Header.chkTransferIn_fl = (Header.chkAllIV_fl == false);
            Header.chkTransferOut_fl = (Header.chkAllIV_fl == false);
            Header.chkInternalUse_fl = (Header.chkAllIV_fl == false);

            return FormPostEvent();
        }

        private bool chkAllBR_fl_Clicked()
        {
            FormPreEvent();

            Header.chkBRDeposit_fl = (Header.chkAllBR_fl == false);
            Header.chkBRExpense_fl = (Header.chkAllBR_fl == false);
            Header.chkBRIncome_fl = (Header.chkAllBR_fl == false);
            Header.chkBRTransfer_fl = (Header.chkAllBR_fl == false);
            Header.chkBRWithdrawal_fl = (Header.chkAllBR_fl == false);
            Header.chkBRDepositSlip_fl = (Header.chkAllBR_fl == false);

            return FormPostEvent();
        }

        private bool dtFrom_dt_Changed()
        {
            if (Header.dtFrom_dt == Header.Tag.dtFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtFrom_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtFrom_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtFrom_dt) == false)
            {
                Header.dtFrom_dt = Header.Tag.dtFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtFrom_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskFrom_dt_Changed()
        {
            if (Header.mskFrom_dt == Header.Tag.mskFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskFrom_dt) == false)
            {
                Header.mskFrom_dt = Header.Tag.mskFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskFrom_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtThru_dt_Changed()
        {
            if (Header.dtThru_dt == Header.Tag.dtThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtThru_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtThru_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtThru_dt) == false)
            {
                Header.dtThru_dt = Header.Tag.dtThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskThru_dt_Changed()
        {
            if (Header.mskThru_dt == Header.Tag.mskThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskThru_dt) == false)
            {
                Header.mskThru_dt = Header.Tag.mskThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdPostNow_Clicked()
        {
            DateTime time_started = default(DateTime);

            FormPreEvent();

            if (FormCheck() == false)
            {
                return false;
            }

            time_started = DateTime.Now;
            mbErrorFound_fl = false;

            // Turn off batch
            //
            User.iBatch_num = 0;
            moDatabase.iBatch_num = 0;

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (PostNow() == false)
            {
                FormSwitchView(moView.ERROR_PAGE_NUM);
                return false;
            }

            FormShowMessage(moUtility.SReplace(User.Language.oMessage.POSTING_IS_COMPLETE, ".", "") + " (" + DateHelper.DateDiff(DateHelper.DateInterval.Second, time_started, DateTime.Now) + " seconds taken).", false);

            return FormPostEvent();
        }

        private bool cmdShowErrorHistory_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (ShowPostingError("", true) == false)
            {
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================
        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

        private bool PostNow()
        {
            bool return_value = false;
            int num_failed = 0;
            int wo_generated = 0;
            string sys_error = "";
            clsFacilityPlan o_fm = new clsFacilityPlan(ref moDatabase);

            try
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                moDatabase.SetPostingTime(moUtility.GeneratePostingTime());
                moDatabase.GetErrorMessage(); // In order to clean up any existing error message.

                if (!o_fm.GenerateScheduledWorkOrders(moGeneral.CurrentDate(), ref wo_generated))
                {
                    FormShowMessage("Work order generation failed. " + wo_generated.ToString() + " w/o generated.");
                    return false;
                }

                moGeneral.CleanupTempReportTables(); // Clean up temporary report tables
                num_failed = 0;

                if (PostALL(ref num_failed) == false)
                {
                    if (moDatabase.IsErrorFound())
                    {
                        sys_error = moDatabase.GetErrorMessage();
                    }
                }

                if (moGeneral.UseSQLProcedures())       // S/P does not return error message. It just saves it into tblGOErrorLog
                {
                    clsRecordset cur_set = new clsRecordset(ref moDatabase);
                    if (cur_set.CreateSnapshot("SELECT * FROM tblGOErrorLog WHERE sUser_cd = '" + moDatabase.sUser_cd + "' AND fLogTime = " + moDatabase.fPostingTime.ToString()) == false)
                    {
                        FormShowMessage(User.Language.oMessage.DATABASE_CONNECTION_FAILED);
                    }
                    else
                    {
                        num_failed = cur_set.RecordCount();
                        cur_set.Release();
                    }
                }

                // Delete all batch numbers that are done regardless of error status
                //
                if (moBatch.DeleteBatch(ref moDatabase, moDatabase.sUser_cd, miBatchFrom_num, miBatchThru_num) == false)
                {
                    if (num_failed == 0 && moUtility.IsEmpty(sys_error))
                    {
                        FormShowMessage();                      // If posting is complete, show the error message from moBatch.DeleteBatch() and return true.
                        return true;
                    }
                }

                if (num_failed == 0 && moUtility.IsEmpty(sys_error))
                {
                    if (moDatabase.bEnableBatchEntry_fl)
                    {
                        modLoadUtility.LoadBatchNumbers(ref moDatabase, ref BatchList, moDatabase.sUser_cd);
                    }
                }
                else if (moUtility.IsNonEmpty(sys_error))       // B/R posting does not use stored procedures so that just show the error returned
                {
                    ShowPostingError(sys_error);
                    return false;
                }
                else
                {
                    ShowPostingError(sys_error);
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PostNow)");
            }

            return return_value;
        }

        private bool PostALL(ref int num_failed)
        {
            bool return_value = false;

            try
            {
                if (PostAP(ref num_failed) == false)
                {
                    return false;
                }
                if (PostAR(ref num_failed) == false)
                {
                    return false;
                }
                if (PostIV(ref num_failed) == false)
                {
                    return false;
                }
                if (PostGL(ref num_failed) == false)
                {
                    return false;
                }
                if (PostBR(ref num_failed) == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PostALL)");
            }

            return return_value;
        }

        private bool PostAP(ref int mumber_failed)
        {
            bool return_value = false;

            try
            {
                if (Header.chkVoucher_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtVoucherFrom), moUtility.ToInteger(Header.txtVoucherThru), GlobalVar.goConstant.TRX_PURCHASE_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkVoucher_fl = false;
                }

                if (Header.chkCashPayment_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtCashPaymentFrom), moUtility.ToInteger(Header.txtCashPaymentThru), GlobalVar.goConstant.TRX_PAYMENT_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkCashPayment_fl = false;
                }

                if (Header.chkStopPayment_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtStopPaymentFrom), moUtility.ToInteger(Header.txtStopPaymentThru), GlobalVar.goConstant.TRX_STOP_PAYMENT_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkStopPayment_fl = false;
                }

                if (Header.chkDebitMemo_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtDebitMemoFrom), moUtility.ToInteger(Header.txtDebitMemoThru), GlobalVar.goConstant.TRX_DM_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkDebitMemo_fl = false;
                }

                if (Header.chkMCVoucher_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtMCVoucherFrom), moUtility.ToInteger(Header.txtMCVoucherThru), GlobalVar.goConstant.TRX_PURCHASE_TYPE, User.Language.oMessage.NOW_POSTING_AP, Header.chkProceedOnError_fl, ref mumber_failed, true))
                    {
                        return return_value;
                    }
                    Header.chkMCVoucher_fl = false;
                }

                if (Header.chkMCCashPayment_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtMCCashPaymentFrom), moUtility.ToInteger(Header.txtMCCashPaymentThru), GlobalVar.goConstant.TRX_PAYMENT_TYPE, User.Language.oMessage.NOW_POSTING_AP, Header.chkProceedOnError_fl, ref mumber_failed, true))
                    {
                        return return_value;
                    }
                    Header.chkMCCashPayment_fl = false;
                }

                if (Header.chkMCStopPayment_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtMCStopPaymentFrom), moUtility.ToInteger(Header.txtMCStopPaymentThru), GlobalVar.goConstant.TRX_STOP_PAYMENT_TYPE, User.Language.oMessage.NOW_POSTING_AP, Header.chkProceedOnError_fl, ref mumber_failed, true))
                    {
                        return return_value;
                    }
                    Header.chkMCStopPayment_fl = false;
                }

                if (Header.chkMCDebitMemo_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtMCDebitMemoFrom), moUtility.ToInteger(Header.txtMCDebitMemoThru), GlobalVar.goConstant.TRX_DM_TYPE, User.Language.oMessage.NOW_POSTING_AP, Header.chkProceedOnError_fl, ref mumber_failed, true))
                    {
                        return return_value;
                    }
                    Header.chkMCDebitMemo_fl = false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PostAP)");
            }

            return return_value;
        }

        private bool PostAR(ref int mumber_failed)
        {
            bool return_value = false;

            try
            {
                // 05/01/2022
                // Post receipt & demo first because the invoices automatically pick up the deposit for balance forward customers.
                // If deposit and invoice come in on the same day. Need to make deposit availale for invoice posting to pick up the deposit.
                //
                if (Header.chkCashReceipt_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtCashReceiptFrom), moUtility.ToInteger(Header.txtCashReceiptThru), GlobalVar.goConstant.TRX_RECEIPT_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkCashReceipt_fl = false;
                }

                // IMPORTANT :
                // Credit memo should come before NSF/Refund because of daily refund.
                // However, equipment rental can create credit referening invoice. If it is the case, such memo needs to be excluded here and should come after invoices are posted below.
                //
                if (Header.chkCreditMemo_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtCreditMemoFrom), moUtility.ToInteger(Header.txtCreditMemoThru), GlobalVar.goConstant.TRX_CM_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed, false, "", true))
                    {
                        return return_value;
                    }
                    //Header.chkCreditMemo_fl = false;  Otherwise, this will skip another memo posting below
                }

                if (Header.chkNSF_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtNSFFrom), moUtility.ToInteger(Header.txtNSFThru), GlobalVar.goConstant.TRX_NSF_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkNSF_fl = false;
                }

                if (Header.chkInvoice_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtInvoiceFrom), moUtility.ToInteger(Header.txtInvoiceThru), GlobalVar.goConstant.TRX_INVOICE_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkInvoice_fl = false;
                }

                // IMPORTANT :
                // Credits with no invoice referenced are posted prior to invoice posting above.
                // Here, we need to post memo with invoice number. Rental creates credits referencing invoice that is not posted yet.
                //
                if (Header.chkCreditMemo_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtCreditMemoFrom), moUtility.ToInteger(Header.txtCreditMemoThru), GlobalVar.goConstant.TRX_CM_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed, false, "", false))
                    {
                        return return_value;
                    }
                    Header.chkCreditMemo_fl = false;
                }

                if (Header.chkMCInvoice_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtMCInvoiceFrom), moUtility.ToInteger(Header.txtMCInvoiceThru), GlobalVar.goConstant.TRX_INVOICE_TYPE, User.Language.oMessage.NOW_POSTING_AR, Header.chkProceedOnError_fl, ref mumber_failed, true))
                    {
                        return return_value;
                    }
                    Header.chkMCInvoice_fl = false;
                }

                if (Header.chkMCCreditMemo_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtMCCreditMemoFrom), moUtility.ToInteger(Header.txtMCCreditMemoThru), GlobalVar.goConstant.TRX_CM_TYPE, User.Language.oMessage.NOW_POSTING_AR, Header.chkProceedOnError_fl, ref mumber_failed, true))
                    {
                        return return_value;
                    }
                    Header.chkMCCreditMemo_fl = false;
                }

                if (Header.chkMCCashReceipt_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtMCCashReceiptFrom), moUtility.ToInteger(Header.txtMCCashReceiptThru), GlobalVar.goConstant.TRX_RECEIPT_TYPE, User.Language.oMessage.NOW_POSTING_AR, Header.chkProceedOnError_fl, ref mumber_failed, true))
                    {
                        return return_value;
                    }
                    Header.chkMCCashReceipt_fl = false;
                }

                if (Header.chkMCNSF_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtMCNSFFrom), moUtility.ToInteger(Header.txtMCNSFThru), GlobalVar.goConstant.TRX_NSF_TYPE, User.Language.oMessage.NOW_POSTING_AR, Header.chkProceedOnError_fl, ref mumber_failed, true))
                    {
                        return return_value;
                    }
                    Header.chkMCNSF_fl = false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PostAR)");
            }

            return return_value;
        }

        private bool PostIV(ref int mumber_failed)
        {

            bool return_value = false;

            try
            {
                if (Header.chkPurchase_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtPurchaseFrom), moUtility.ToInteger(Header.txtPurchaseThru), GlobalVar.goConstant.TRX_IV_PURCHASE_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkPurchase_fl = false;
                }

                if (Header.chkPurchaseReturn_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtPurchaseReturnFrom), moUtility.ToInteger(Header.txtPurchaseReturnThru), GlobalVar.goConstant.TRX_IV_PURCHASE_RETURN_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkPurchaseReturn_fl = false;
                }

                if (Header.chkSale_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtSaleFrom), moUtility.ToInteger(Header.txtSaleThru), GlobalVar.goConstant.TRX_IV_SALES_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkSale_fl = false;
                }

                if (Header.chkSaleReturn_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtSaleReturnFrom), moUtility.ToInteger(Header.txtSaleReturnThru), GlobalVar.goConstant.TRX_IV_SALES_RETURN_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkSaleReturn_fl = false;
                }

                if (Header.chkTransferOut_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtTransferOutFrom), moUtility.ToInteger(Header.txtTransferOutThru), GlobalVar.goConstant.TRX_TRANSFER_OUT_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkTransferOut_fl = false;
                }

                if (Header.chkTransferIn_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtTransferInFrom), moUtility.ToInteger(Header.txtTransferInThru), GlobalVar.goConstant.TRX_TRANSFER_IN_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkTransferIn_fl = false;
                }

                if (Header.chkPhysical_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtPhysicalFrom), moUtility.ToInteger(Header.txtPhysicalThru), GlobalVar.goConstant.TRX_PHYSICAL_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkPhysical_fl = false;
                }

                if (Header.chkSpoilage_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtSpoilageFrom), moUtility.ToInteger(Header.txtSpoilageThru), GlobalVar.goConstant.TRX_SPOILAGE_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkSpoilage_fl = false;
                }

                if (Header.chkInternalUse_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtInternalUseFrom), moUtility.ToInteger(Header.txtInternalUseThru), GlobalVar.goConstant.TRX_IV_INTERNAL_USE_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkInternalUse_fl = false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PostIV)");
            }

            return return_value;
        }

        private bool PostGL(ref int mumber_failed)
        {
            bool return_value = false;

            try
            {
                if (Header.chkJournal_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtJournalFrom), moUtility.ToInteger(Header.txtJournalThru), GlobalVar.goConstant.TRX_JOURNAL_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed, false, Header.cboJournal_cd))
                    {
                        return return_value;
                    }
                }

                Header.chkJournal_fl = false;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PostGL)");
            }

            return return_value;
        }

        private bool PostBR(ref int mumber_failed)
        {

            bool return_value = false;

            try
            {
                if (Header.chkBRIncome_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtBRIncomeFrom), moUtility.ToInteger(Header.txtBRIncomeThru), GlobalVar.goConstant.TRX_BR_INCOME_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkBRIncome_fl = false;
                }

                if (Header.chkBRExpense_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtBRExpenseFrom), moUtility.ToInteger(Header.txtBRExpenseThru), GlobalVar.goConstant.TRX_BR_EXPENSE_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkBRExpense_fl = false;
                }

                if (Header.chkBRDeposit_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtBRDepositFrom), moUtility.ToInteger(Header.txtBRDepositThru), GlobalVar.goConstant.TRX_BR_FOREIGN_DEPOSIT_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkBRDeposit_fl = false;
                }

                if (Header.chkBRWithdrawal_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtBRWithdrawalFrom), moUtility.ToInteger(Header.txtBRWithdrawalThru), GlobalVar.goConstant.TRX_BR_FOREIGN_WITHDRAWAL_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkBRWithdrawal_fl = false;
                }

                if (Header.chkBRTransfer_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtBRTransferFrom), moUtility.ToInteger(Header.txtBRTransferThru), GlobalVar.goConstant.TRX_BR_TRANSFER_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkBRTransfer_fl = false;
                }
                if (Header.chkBRDepositSlip_fl || (miBatchFrom_num > 0 || miBatchThru_num > 0))
                {
                    if ((Header.chkProceedOnError_fl == false) && !modPostUtility.PostOneTransaction(ref moDatabase, miBatchFrom_num, miBatchThru_num, miDateFrom_num, miDateThru_num, moUtility.ToInteger(Header.txtBRDepositSlipFrom), moUtility.ToInteger(Header.txtBRDepositSlipThru), GlobalVar.goConstant.TRX_BR_DEPOSIT_SLIP_TYPE, User.Language.oMessage.RECORD_BEING_POSTED, Header.chkProceedOnError_fl, ref mumber_failed))
                    {
                        return return_value;
                    }
                    Header.chkBRDepositSlip_fl = false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PostBR)");
            }

            return return_value;
        }

        private bool ShowPostingError(string sys_error, bool full_history = false)
        {
            bool return_value = false;
            clsRecordset cur_set = null;
            string where_clause = "";
            string[] data_fields = new string[] { "iTransaction_typ", "iTransaction_num", "sErrorMsg", "sUser_cd", "fLogTime" };

            try
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                cur_set = new clsRecordset(ref moDatabase);

                if (full_history)
                {
                    if (moUtility.IsSystemAdministrator(moDatabase))
                    {
                        where_clause += " fLogTime >= " + moUtility.GeneratePostingTime(365);
                    }
                    else if (moUtility.IsSupervisor(moDatabase))
                    {
                        where_clause += " fLogTime >= " + moUtility.GeneratePostingTime(30);
                    }
                    else
                    {
                        where_clause += " sUser_cd = '" + User.sUser_cd + "'";
                        where_clause += " AND fLogTime >= " + moUtility.GeneratePostingTime(30);
                    }
                }
                else
                {
                    where_clause = " sUser_cd = '" + User.sUser_cd + "'";
                    where_clause += " AND fLogTime = " + moDatabase.fPostingTime;
                    if (cur_set.CreateSnapshot("SELECT * FROM tblGOErrorLog WHERE " + where_clause) == false)
                    {
                        FormShowMessage();
                        return false;
                    }
                    else if (cur_set.IsEmpty())
                    {
                        FormShowMessage(sys_error);     // system error instead.
                        return true;
                    }
                }

                if (moPostingError.Show(moDatabase, moPage, "tblGOErrorLog", data_fields, where_clause, "fLogTime DESC, sUser_cd") == false)
                {
                    FormShowMessage();
                    return false;
                }
                else
                {
                    FormSwitchView(moView.ERROR_PAGE_NUM);
                }

                mbErrorFound_fl = true;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (ShowPostingError)");
            }

            return return_value;
        }

    }
}
