﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Local;
using System.Threading.Tasks;
using System.Collections;

namespace Dynasty.ASP.Pages.SM
{
    public partial class CustomFields
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<CustomFields> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;                                                               
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;
        private Models.clsSpreadsheet moSpreadsheet;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
		private clsCustomization moCustom;

        private List<Models.clsCombobox> PageTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ExistingFieldList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> AvailableFieldList = new List<Models.clsCombobox>();

        private bool mbEnableNew_fl = true;
        private bool mbShowEntry_fl = false;
        private bool mbEnableFieldType_fl = true;
        private bool mbNewField_fl = true;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader                   
        {
            // Listing of UI items on the header
            //
            public string cboPage_nm = "";
            public string txtFieldCaption = "";
            public string lblDataField_nm = "";
            public string lblOldDataField_nm = "";
            public string cboAvailableField_nm = "";
            public string lstExistingFields = "";
            public bool chkRequired_fl = false;
            public int optField_typ = 0;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag                                                                     
            {
                public string cboPage_nm { get; set; } = "";
                public string lstExistingFields { get; set; } = "";

            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()                                                                  
            {
                Tag.cboPage_nm = cboPage_nm;
                Tag.lstExistingFields = lstExistingFields;
            }
        }
        private clsHeader Header = new clsHeader();                                                 


        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;                        
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows()
        {

            return true;
        }

        private bool FormCalculateTotal()
        {

            return true;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            if (FormCheckSecurity() == false)
            {
                return false;
            }

            Header.txtFieldCaption = moUtility.STrim(moUtility.EvalQuote(Header.txtFieldCaption));

            if (moUtility.IsEmpty(Header.cboPage_nm))
            {
                FormShowMessage(User.Language.oCaption.PAGE_NAME + User.Language.oMessage.IS_REQUIRED);
                FormSetFocus("cboPage_nm");
                return false;
            }
            if (Header.optField_typ == 0)
            {
                FormShowMessage(User.Language.oCaption.FIELD_TYPE + User.Language.oMessage.IS_REQUIRED);
                return false;
            }
            if (moUtility.IsEmpty(Header.txtFieldCaption))
            {
                FormShowMessage(User.Language.oCaption.FIELD_CAPTION + User.Language.oMessage.IS_REQUIRED);
                FormSetFocus("txtFieldCaption");
                return false;
            }
            if (mbNewField_fl && moUtility.IsEmpty(Header.cboAvailableField_nm))
            {
                FormShowMessage(User.Language.oCaption.DATA_FIELD_NAME + User.Language.oMessage.IS_REQUIRED);
                FormSetFocus("cboAvailableField_nm");
                return false;
            }

            if (mbNewField_fl)
            {
                if (ExistingFieldList.Where(i => moUtility.SUCase(i.Text) == moUtility.SUCase(Header.txtFieldCaption)).Count() > 0)
                {
                    FormShowMessage(Header.txtFieldCaption + User.Language.oMessage.ALREADY_EXISTS);
                    FormSetFocus("txtFieldCaption");
                    return false;
                }
            }
            return true;
        }

        private bool FormCheckConcurrency(clsRecordset cur_set)                                    // Check if someone has changed this record while it is open in this session.
        {
           
            return true;
        }

        private bool FormCheckToDelete()
        {
            
            return true;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearExtra();

            return true;
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            mbEnableFieldType_fl = false;
            mbEnableNew_fl = true;
            mbNewField_fl = true;
            mbShowEntry_fl = false;

            Header.txtFieldCaption = "";
            Header.lblDataField_nm = "";
            Header.optField_typ = 0;
            Header.chkRequired_fl = false;
            Header.lstExistingFields = "";

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {

            return true;
        }

        private bool FormClearMessage()                                                            
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            bool return_value = false;
            int max_item = 0;
            int i = 0;
            ArrayList item_list;

            try
            {
                if (ExistingFieldList.Count() == 0)
                {
                    return false;
                }

                if (FormOpenDatabase() ==  false)
                {
                    return false;
                }

                for (i = 0; i < moCustom.iTotalFields; i++)
                {
                    if (moCustom.GetFieldName(i) == Header.lblDataField_nm)
                    {
                        moCustom.DeleteCustomField(i);
                        break;
                    }
                }

                if (moCustom.SaveCustomInfo(GlobalVar.goUtility.ToInteger(Header.cboPage_nm), modCommonUtility.GetComboText(PageTypeList, Header.cboPage_nm)) == false)
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormDelete)");
            }

            return return_value;
        }


        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moCustom = new clsCustomization(ref moDatabase);

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.SMMENU_NAME;
            moPage.Title = User.Language.oCaption.USER_DEFINED_FIELDS;
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormInitHeader();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = ""; 
            moPage.sKeyField_nm = "";
            moPage.iTransaction_typ= 0; 

            return true;
        }

        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback
            
            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;

            try 
            {
                modWebLoadUtility.LoadCustomFields(ref moDatabase, ref PageTypeList);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostSave()
        {
            
            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {

            return true;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormSave()
        {

            bool return_value = false;

            try
            {
                if (FormCheck() == false)
                {
                    return false;
                }

                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                if (mbNewField_fl)
                {
                    if (moCustom.AddNewCustomField(Header.txtFieldCaption, Header.cboAvailableField_nm, Header.chkRequired_fl) == false)
                    {
                        FormShowMessage();
                        return false;
                    }
                }
                else if (moCustom.UpdateCustomField(Header.lblOldDataField_nm, Header.lblDataField_nm, Header.txtFieldCaption, Header.chkRequired_fl) == false)
                {
                    FormShowMessage();
                    return false;
                }

                if (moCustom.SaveCustomInfo(moUtility.ToInteger(Header.cboPage_nm), modCommonUtility.GetComboText(PageTypeList, Header.cboPage_nm)) == false)
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSave)");
            }

            return return_value;
        }

        private bool FormSearch()
        {

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {
            if (FormShowHeader(cur_set) == false)
            {
                return false;
            }
            else if (FormShowExtra(cur_set) == false)
            {
                return false;
            }

            FormReArrangeHeader();

            return true;
        }

        private bool FormShowExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                moPage.Clear();
                moPage.PreserveTimestamp(cur_set);
                moPage.bNew_fl = false;

                moPage.sPreviousKey_id = Header.cboPage_nm;
                Header.Preserve();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowHeader(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowHeader)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowListing()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moListing.Show(moDatabase, moPage) == false)
            {
                return false;
            }

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.cboPage_nm))
            {
                FormExit();
                return true;
            }

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================


        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================

        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;

            FormPreEvent();

            try
            {

                FormSwitchView(moZoom.iView);
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();                                                                   

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }
        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        private bool cboPage_nm_Clicked()
        {
            if (Header.cboPage_nm ==  Header.Tag.cboPage_nm)
            {
                return true;
            }

            cboPage_nm_Verified();

            return FormPostEvent();
        }

        private bool lstExistingFields_Clicked()
        {
            if (Header.lstExistingFields == Header.Tag.lstExistingFields)
            {
                return true;
            }

            lstExistingFields_Verified();

            return FormPostEvent();
        }
        private bool cmdNew_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.cboPage_nm))
            {
                FormShowMessage(User.Language.oCaption.PAGE_NAME + User.Language.oMessage.IS_REQUIRED);
                return false;
            }

            cmdNew_Verified();

            return FormPostEvent();
        }

        private bool cmdSave_Clicked()
        {
            FormPreEvent();

            if (FormSave())
            {
                cboPage_nm_Verified();       // Read the full info again.
            }

            return FormPostEvent();
        }

        private bool cmdDelete_Clicked()
        {
            FormPreEvent();

            if (FormDelete())
            {
                cboPage_nm_Verified();       // Read the full info again.
            }

            return FormPostEvent();
        }

        private bool FieldType_Changed(int field_type)
        {
            FormPreEvent();

            Header.optField_typ = field_type;

            FillAvailableFields(field_type);

            return FormPostEvent();
        }
        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================
        private bool cboPage_nm_Verified()
        {
            bool return_value = false;
            int i = 0;
            ArrayList item_list;

            try
            {
                FormPreEvent();
                FormClear();

                if (moUtility.IsEmpty(Header.cboPage_nm))
                {
                    ExistingFieldList.Clear();
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                moCustom.InitVars();
                moCustom.ReadCustomInfo(moUtility.ToInteger(Header.cboPage_nm), modCommonUtility.GetComboText(PageTypeList, Header.cboPage_nm));

                ExistingFieldList.Clear();
                item_list = new ArrayList();

                for (i = 0; i < moCustom.iTotalFields; i++)
                {
                    item_list.Add(new clsComboBoxItem(moCustom.GetCaption(i), moCustom.GetCaption(i)));
                }
                modWebLoadUtility.LoadComboBox(ref ExistingFieldList, item_list);

                mbEnableNew_fl = (moCustom.iTotalFields < clsCustomization.MAX_FIELDS);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (cboPage_nm_Verified)");
            }

            return return_value;
        }

        private bool lstExistingFields_Verified()
        {
            bool return_value = false;
            int max_item = 0;
            int i = 0;

            try
            {
                if (ExistingFieldList.Count() == 0)
                {
                    return true;
                }

                max_item = ExistingFieldList.Count();

                for (i = 0; i < max_item; i++)
                {
                    if (moCustom.GetCaption(i) == Header.lstExistingFields)
                    {
                        Header.txtFieldCaption = moCustom.GetCaption(i);
                        Header.lblDataField_nm = moCustom.GetFieldName(i);
                        Header.chkRequired_fl = moCustom.IsFieldRequired(i);
                        Header.lblOldDataField_nm = Header.lblDataField_nm;


                        if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(Header.lblDataField_nm, 1)) == "M")
                        {
                            Header.optField_typ = Database.clsCustomization.MONEY_FIELD_TYPE;
                        }
                        else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(Header.lblDataField_nm, 1)) == "F")
                        {
                            Header.optField_typ = Database.clsCustomization.NUMBER_FIELD_TYPE;
                        }
                        else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(Header.lblDataField_nm, 1)) == "S")
                        {
                            Header.optField_typ = Database.clsCustomization.TEXT_FIELD_TYPE;
                        }
                        else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SRight(Header.lblDataField_nm, 3)) == "_DT")
                        {
                            Header.optField_typ = Database.clsCustomization.DATE_FIELD_TYPE;
                        }

                        break;
                    }
                }

                mbEnableFieldType_fl = false;
                mbShowEntry_fl = true;
                mbNewField_fl = false;
                AvailableFieldList.Clear();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (lstExistingFields_Verified)");
            }

            return return_value;
        }

        private bool FillAvailableFields(int field_type)
        {
            bool return_value = false;
            string[] field_names = null;
            int i = 0;
            ArrayList item_list;

            try
            {
                if (mbEnableFieldType_fl ==  false || moPage.bNew_fl == false)              // Meaning that updating the existing.
                {
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                moUtility.ResizeDim(ref field_names, clsCustomization.MAX_FIELDS + 2);

                moCustom.ReadCustomInfo(moUtility.ToInteger(Header.cboPage_nm), modCommonUtility.GetComboText(PageTypeList, Header.cboPage_nm));

                AvailableFieldList.Clear();
                item_list = new ArrayList();

                if (moCustom.GetFieldNames(field_type, ref field_names))
                {
                    for (i = 0; i < clsCustomization.MAX_FIELDS; i++)
                    {
                        if (GlobalVar.goUtility.IsEmpty(field_names[i]))
                        {
                            break;
                        }
                        item_list.Add(new clsComboBoxItem(field_names[i], field_names[i]));
                    }
                }

                modWebLoadUtility.LoadComboBox(ref AvailableFieldList, item_list);

                if (AvailableFieldList.Count() > 0)
                {
                    Header.cboAvailableField_nm = field_names[0];
                }
                else
                {
                    FormShowMessage(User.Language.oMessage.TOTAL_NUMBER_OF_THIS_TYPE_REACHED_THE_LIMIT);
                    mbEnableFieldType_fl = false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FillAvailableFields)");
            }

            return return_value;
        }



        private bool cmdNew_Verified()
        {
            bool return_value = false;
            int max_item = 0;
            int i = 0;

            try
            {
                FormClear();
                mbShowEntry_fl = true;
                mbEnableFieldType_fl = true;
                mbNewField_fl = true;
                AvailableFieldList.Clear();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (cboPage_nm_Verified)");
            }

            return return_value;
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================



    }
}
