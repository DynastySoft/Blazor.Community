﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Report;
using Dynasty.Local;
using System.Reflection.PortableExecutable;

namespace Dynasty.ASP.Pages.AR
{
    public partial class PrintStatement
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<MarkUp> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;
        private Models.clsSpreadsheet moDetail;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsReportViewer moReport;

        private List<Models.clsCombobox> StatementTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> StatementPeriodList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> StatementGroupList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> GroupCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ClassCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> SalesrepCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> TerritoryCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CustomerPeriodBeginList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CustomerPeriodEndList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> FiscalYearList = new List<Models.clsCombobox>();

        private const int STATEMENT_PERIOD = 0;
        private const int STATEMENT_PERIOD_BEGIN = 1;
        private const int STATEMENT_PERIOD_END = 2;
        private const int STATEMENT_CREATED = 3;

        private bool mbDisablePeriod_fl = false;
        private int miStatement_typ = 0;
        private const int STATEMENT_REGULAR = 1;
        private const int STATEMENT_ADHOC = 2;

        private bool AdHocStatement                                                                       
        {
            get
            {
                return (miStatement_typ == STATEMENT_ADHOC);                                   
            }
        }
        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader
        {
            public string cboStatement_typ = "";
            public string cboFiscalYear = "";
            public string cboStatementPeriod_dt = "";
            public string cboClass_cd = "";
            public string cboStatementGroup_cd = "";
            public string cboGroup_cd = "";
            public string cboSalesrep_cd = "";
            public string cboTerritory_cd = "";
            public string txtCustomer_cd = "";

            // Ad-hoc
            public string txtAdHocCustomer_cd = "";
            public string cboAdHocPeriodBegin_dt = "";
            public string cboAdHocPeriodEnd_dt = "";
            public bool chkOutstandingBalanceOnly_fl = false;
            public bool chkShowAging_fl = true;
            public bool chkShowStub_fl = true;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag
            {
                public string cboStatement_typ = "";
                public string cboFiscalYear = "";
                public string cboStatementPeriod_dt = "";
                public string cboClass_cd = "";
                public string cboGroup_cd = "";
                public string cboStatementGroup_cd = "";
                public string cboSalesrep_cd = "";
                public string cboTerritory_cd = "";
                public string txtCustomer_cd = "";

                // Ad-hoc
                public string txtAdHocCustomer_cd = "";
                public string cboAdHocPeriodBegin_dt = "";
                public string cboAdHocPeriodEnd_dt = "";
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()
            {
                Tag.cboStatement_typ = cboStatement_typ;
                Tag.cboFiscalYear = cboFiscalYear;
                Tag.cboStatementPeriod_dt = cboStatementPeriod_dt;
                Tag.cboClass_cd = cboClass_cd;
                Tag.cboGroup_cd = cboGroup_cd;
                Tag.cboStatementGroup_cd = cboStatementGroup_cd;
                Tag.cboSalesrep_cd = cboSalesrep_cd;
                Tag.cboTerritory_cd = cboTerritory_cd;
                Tag.txtCustomer_cd = txtCustomer_cd;

                // Ad-hoc
                Tag.txtAdHocCustomer_cd = txtAdHocCustomer_cd;
                Tag.cboAdHocPeriodBegin_dt = cboAdHocPeriodBegin_dt;
                Tag.cboAdHocPeriodEnd_dt = cboAdHocPeriodEnd_dt;
            }
            public void ClearAdHoc()
            {
                txtAdHocCustomer_cd = "";
                cboAdHocPeriodBegin_dt = "";
                cboAdHocPeriodEnd_dt = "";

                if (txtCustomer_cd != "" || txtAdHocCustomer_cd != "")
                {
                    chkOutstandingBalanceOnly_fl = false;
                }

                Preserve();
            }
            public void ClearOptions()
            {
                cboStatement_typ = "";
                cboStatementPeriod_dt = "";
                cboClass_cd = "";
                cboGroup_cd = "";
                cboStatementGroup_cd = "";
                cboSalesrep_cd = "";
                cboTerritory_cd = "";
                txtCustomer_cd = "";

                if (txtCustomer_cd != "" || txtAdHocCustomer_cd != "")
                {
                    chkOutstandingBalanceOnly_fl = false;
                }

                Preserve();
            }
        }
        private clsHeader Header = new clsHeader();


        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        private void FormDownloadFile(string file_name)                                // Download a file.
        {
            Models.JSFunction.DownloadFile(JSRuntime, moPage, User.sWebSite, file_name);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            bool return_value = false;
            string sql_str = "";
            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (FormCheckSecurity() == false)
            {
                return false;
            }

            try
            {
                if (miStatement_typ == 0)
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_SELECT_A_STATEMENT_TYPE);
                    return false;
                }

                // If this is  Ad-hoc customer-specific
                //
                if (AdHocStatement)
                {
                    if (moUtility.IsEmpty(Header.txtAdHocCustomer_cd))
                    {
                        FormShowMessage(User.Language.oMessage.PLEASE_ENTER_A_CUSTOMER_CODE);
                        FormSetFocus("txtAdHocCustomer_cd");
                        return false;
                    }
                    if (CustomerPeriodBeginList.Count() <= 1)
                    {
                        FormShowMessage(User.Language.oMessage.CREATE_STATEMENT_SCHEDULE);
                        cmdViewSecond_Clicked();
                        return false;
                    }
                    if (moUtility.IsEmpty(Header.cboAdHocPeriodBegin_dt))
                    {
                        FormShowMessage(User.Language.oMessage.PLEASE_SELECT_THE_STATEMENT_PERIOD);
                        FormSetFocus("cboAdHocPeriodBegin_dt");
                        return false;
                    }
                    if (moUtility.IsEmpty(Header.cboAdHocPeriodEnd_dt))
                    {
                        FormShowMessage(User.Language.oMessage.PLEASE_SELECT_THE_STATEMENT_PERIOD);
                        FormSetFocus("cboAdHocPeriodEnd_dt");
                        return false;
                    }

                    Header.ClearOptions();
                }
                else
                {
                    if (StatementPeriodList.Count() <= 1)
                    {
                        FormShowMessage(User.Language.oMessage.CREATE_STATEMENT_SCHEDULE);
                        cmdViewSecond_Clicked();
                        return false;
                    }

                    if (moUtility.IsEmpty(Header.cboStatementPeriod_dt))
                    {
                        FormShowMessage(User.Language.oMessage.PLEASE_SELECT_THE_STATEMENT_PERIOD);
                        FormSetFocus("cboStatementPeriod_dt");
                        return false;
                    }

                    //  Check if the statement has been created for the period selected
                    //
                    sql_str = "SELECT * FROM tblARStatementPeriod WHERE iPeriodBegin_dt = " + Header.cboStatementPeriod_dt + " AND iStatement_dt > 0";
                    if (cur_set.CreateSnapshot(sql_str) == false)
                    {
                        FormShowMessage();
                        return false;
                    }
                    else if (cur_set.RecordCount() == 0)
                    {
                        FormShowMessage(User.Language.oMessage.NO_RECORDS_FOUND);
                        return false;
                    }

                    Header.ClearAdHoc();
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheck)");
            }

            return return_value;
        }

        private bool FormCheckSecurity()
        {
            return modSecurity.SystemPrintSecurityCheck(ref moDatabase, moPage);
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            moDetail.iTotalRows = 1;
            moUtility.ResizeDim(ref moDetail.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, moDetail.iTotalRows - 1);

            return true;
        }

        private bool FormClearMessage()
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();
            moDetail = new Models.clsSpreadsheet();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moReport = new clsReportViewer();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.ARMENU_NAME;
            moPage.Title = User.Language.oCaption.PRINT_STATEMENT;
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormPostEvent()
        {

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                                 // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                     // FormClearMessage() will clear the possible message displayed by the last postback

            return true;
        }

        private bool FormLoad()                                                                     // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;

            try
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                modLoadUtility.LoadARStatementType(ref moDatabase, ref StatementTypeList);
                modLoadUtility.LoadFiscalYear(ref moDatabase, ref FiscalYearList);
                modLoadUtility.LoadCustomerClassCode(ref moDatabase, ref ClassCodeList);
                modLoadUtility.LoadARStatementGroupCode(ref moDatabase, ref StatementGroupList);
                modLoadUtility.LoadCustomerGroupCode(ref moDatabase, ref GroupCodeList);
                modLoadUtility.LoadCustomerTerritoryCode(ref moDatabase, ref TerritoryCodeList);
                modLoadUtility.LoadSalespersonCode(ref moDatabase, ref SalesrepCodeList);

                modLoadUtility.LoadStatementPeriod(ref moDatabase, ref StatementPeriodList, moDatabase.sCurFiscalYear, false, true);
                modLoadUtility.LoadStatementPeriodBegin(ref moDatabase, ref CustomerPeriodBeginList, moDatabase.sCurFiscalYear, true);
                modLoadUtility.LoadStatementPeriodEnd(ref moDatabase, ref CustomerPeriodEndList, moDatabase.sCurFiscalYear, true);

                if (moUtility.IsSalesStaff(moDatabase))
                {
                    Header.cboSalesrep_cd = moDatabase.sUser_cd;
                }

                Header.cboStatement_typ = User.Language.oCaption.MONTHLY_STATEMENT;
                Header.Preserve();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }


        private bool FormPrint(int print_type)
        {
            bool return_value = false;
            string pdf_file = "";
            clsFile o_file = new clsFile();
            DateTime stime_started = DateTime.Now;
            clsMail o_mail = new clsMail(ref moDatabase);

            try
            {
                if (FormOpenDatabase() == false)        // Do not delete this
                {
                    return false;
                }

                moReport.InitReport(moUtility.GetServerName(ref moDatabase), moUtility.GetDatabaseName(ref moDatabase), moUtility.GetDBUser(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_ID)
                                    , moUtility.GetDBPassword(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_PASSWORD), moDatabase.uDirectory.sPDFDirectory_nm, true, true);


                if (modCommonReportUtility.SetCompanyInReport(ref moDatabase, "frmPrintStatement", ref moReport, "", moUtility.IsNonEmpty(modCommonUtility.GetCompanyLogoFile(ref moDatabase))) == false)
                {
                    FormShowMessage();
                    return false;
                }
                if (SetReportSelection() == false)
                {
                    return false;
                }
                if (SetReportFile() == false)
                {
                    return false;
                }

                if (moReport.PrintReport(ref moDatabase, print_type, ref pdf_file) == false)
                {
                    FormShowMessage(moReport.GetErrorMessage());
                    return false;
                }

                if (moUtility.IsEmpty(pdf_file) || modWebReportUtility.PDFFound(pdf_file) == false)
                {
                    FormShowMessage(User.Language.oMessage.REPORT_SERVER_NOT_RESPONDING);
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(pdf_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormPrint)");
            }

            return return_value;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormRecreateDetail()                                                           //  Sync moDetail.Data with moDetail.Grid for the items that do not have event-handler ONLY.
        {
            if (moDetail.RecreateDetail() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateDetailLine(Models.clsSpreadsheet.clsGrid cur_item, int row_num = -1)
        {
            if (moDetail.RecreateDetailLine(cur_item, row_num) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateGrid()                                                             //  Create moDetail.Grid according to moDetail.Data
        {
            if (moDetail.RecreateGrid() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            // The statement period on 'Create' tab, should always point to the last period in order to prevent messing up the current balance.
            //
            if (cur_page == moView.LISTING_PAGE_NUM)
            {
                if (StatementPeriodList.Count > 0)
                {
                    Header.cboStatementPeriod_dt = StatementPeriodList.ElementAt(0).Value;
                }
            }

            moView.SwitchView(moPage, cur_page);

            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moZoom.Caller == "txtCustomer_cd")
            {
                if (moZoom.Customer(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            if (moZoom.Caller == "txtAdHocCustomer_cd")
            {
                if (moZoom.Customer(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }


        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }


        private bool btnPrint_Clicked()
        {
            FormPreEvent();

            if (FormCheck())
            {
                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
                FormPrint(GlobalVar.goConstant.PRINT_TO_PDF);
            }

            return FormPostEvent();
        }

        private bool btnExcel_Clicked()
        {
            FormPreEvent();

            if (FormCheck())
            {
                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
                FormPrint(GlobalVar.goConstant.PRINT_TO_EXCEL);
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewHeader_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }
        private bool cmdViewListing_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.LISTING_PAGE_NUM);

            return true;
        }

        private bool cmdViewSecond_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.SECOND_PAGE_NUM);

            if (StatementPeriodList.Count() > 0)
            {
                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
                
                if (moUtility.IsEmpty(Header.cboFiscalYear))
                {
                    Header.cboFiscalYear = moDatabase.sCurFiscalYear;
                    cboFiscalYear_Clicked();
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                if (moUtility.IsEmpty(cur_item.Col_0))
                {
                    return false;
                }

                code_selected = cur_item.Col_0;

                if (moZoom.Caller == "txtCustomer_cd")
                {
                    Header.txtCustomer_cd = code_selected;
                    txtCustomer_cd_Changed();
                }
                else if (moZoom.Caller == "txtAdHocCustomer_cd")
                {
                    Header.txtAdHocCustomer_cd = code_selected;
                    txtAdHocCustomer_cd_Changed();
                }

                FormSwitchView(moZoom.iView);
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }

        private bool btnZoomOnCustomer_cd_Clicked()
        {
            string where_clause = "";

            FormPreEvent();

            if (FormOpenDatabase() == false)                // Necessary to make moDatabase.sUser_cd valid
            {
                return false;
            }

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtCustomer_cd", -1, -1, moView.MAIN_PAGE_NUM, "sCustomer_cd", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);   // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return true;
        }

        private bool btnZoomOnAdHocCustomer_cd_Clicked()
        {
            string where_clause = "";

            FormPreEvent();

            if (FormOpenDatabase() == false)                // Necessary to make moDatabase.sUser_cd valid
            {
                return false;
            }
            if (moUtility.IsSalesStaff(moDatabase))
            {
                where_clause = "sSalesrep_cd = '" + moDatabase.sUser_cd + "'";
            }

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtAdHocCustomer_cd", -1, -1, moView.MAIN_PAGE_NUM, "sCustomer_cd", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);   // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool txtCustomer_cd_Changed()
        {
            string save_period = Header.cboStatementPeriod_dt.ToString();
            string save_customer = "";

            Header.txtCustomer_cd = modCommonUtility.CleanCode(Header.txtCustomer_cd);

            if (Header.txtCustomer_cd == Header.Tag.txtCustomer_cd)
            {
                return true;
            }


            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsNonEmpty(Header.txtCustomer_cd))
            {
                if (FormOpenDatabase() == false)
                {
                    Header.txtCustomer_cd = Header.Tag.txtCustomer_cd;
                    return false;
                }
                if (moValidate.IsValidCustomerCode(Header.txtCustomer_cd) == false)
                {
                    FormShowMessage(Header.txtCustomer_cd + User.Language.oMessage.IS_INVALID);
                    Header.txtCustomer_cd = Header.Tag.txtCustomer_cd;
                    return FormPostEvent();
                }

                save_customer = Header.txtCustomer_cd;
                Header.ClearOptions();
                Header.txtCustomer_cd = save_customer;
                Header.cboStatementPeriod_dt = save_period;

                Header.ClearAdHoc();            // This indicates that this is the regular statement printing
            }

            return FormPostEvent();
        }
        private bool cboStatementPeriod_dt_Changed()
        {
            Header.cboStatementPeriod_dt = modCommonUtility.CleanCode(Header.cboStatementPeriod_dt);

            if (Header.cboStatementPeriod_dt == Header.Tag.cboStatementPeriod_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsNonEmpty(Header.cboStatementPeriod_dt))
            {
                Header.ClearAdHoc();            // This indicates that this is the regular statement printing
            }

            return FormPostEvent();
        }
        private bool cboStatementGroup_cd_Changed()
        {
            Header.cboStatementGroup_cd = modCommonUtility.CleanCode(Header.cboStatementGroup_cd);

            if (Header.cboStatementGroup_cd == Header.Tag.cboStatementGroup_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsNonEmpty(Header.cboStatementGroup_cd))
            {
                Header.ClearAdHoc();            // This indicates that this is the regular statement printing

                Header.txtCustomer_cd = "";     // Also, clean customer code
            }

            return FormPostEvent();
        }
        private bool cboGroup_cd_Changed()
        {
            Header.cboGroup_cd = modCommonUtility.CleanCode(Header.cboGroup_cd);

            if (Header.cboGroup_cd == Header.Tag.cboGroup_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsNonEmpty(Header.cboGroup_cd))
            {
                Header.ClearAdHoc();            // This indicates that this is the regular statement printing

                Header.txtCustomer_cd = "";     // Also, clean customer code
            }

            return FormPostEvent();
        }
        private bool cboClass_cd_Changed()
        {
            Header.cboClass_cd = modCommonUtility.CleanCode(Header.cboClass_cd);

            if (Header.cboClass_cd == Header.Tag.cboClass_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsNonEmpty(Header.cboClass_cd))
            {
                Header.ClearAdHoc();            // This indicates that this is the regular statement printing

                Header.txtCustomer_cd = "";     // Also, clean customer code
            }

            return FormPostEvent();
        }
        private bool cboTerritory_cd_Changed()
        {
            Header.cboTerritory_cd = modCommonUtility.CleanCode(Header.cboTerritory_cd);

            if (Header.cboTerritory_cd == Header.Tag.cboTerritory_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsNonEmpty(Header.cboTerritory_cd))
            {
                Header.ClearAdHoc();            // This indicates that this is the regular statement printing

                Header.txtCustomer_cd = "";     // Also, clean customer code
            }

            return FormPostEvent();
        }
        private bool cboSalesrep_cd_Changed()
        {
            Header.cboSalesrep_cd = modCommonUtility.CleanCode(Header.cboSalesrep_cd);

            if (Header.cboSalesrep_cd == Header.Tag.cboSalesrep_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsNonEmpty(Header.cboSalesrep_cd))
            {
                Header.ClearAdHoc();            // This indicates that this is the regular statement printing

                Header.txtCustomer_cd = "";     // Also, clean customer code
            }

            return FormPostEvent();
        }
        private bool txtAdHocCustomer_cd_Changed()
        {
            Header.txtAdHocCustomer_cd = modCommonUtility.CleanCode(Header.txtAdHocCustomer_cd);

            if (Header.txtAdHocCustomer_cd == Header.Tag.txtAdHocCustomer_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsNonEmpty(Header.txtAdHocCustomer_cd))
            {
                if (FormOpenDatabase() == false)
                {
                    Header.txtAdHocCustomer_cd = Header.Tag.txtAdHocCustomer_cd;
                    return false;
                }
                if (moValidate.IsValidCustomerCode(Header.txtAdHocCustomer_cd) == false)
                {
                    FormShowMessage(Header.txtAdHocCustomer_cd + User.Language.oMessage.IS_INVALID);
                    Header.txtAdHocCustomer_cd = Header.Tag.txtAdHocCustomer_cd;
                    return FormPostEvent();
                }
                else
                {
                    if (moUtility.IsSalesStaff(moDatabase))
                    {
                        if (moValidate.oRecordset.sField("sSalesrep_cd") != moDatabase.sUser_cd)
                        {
                            FormShowMessage(Header.txtAdHocCustomer_cd + User.Language.oMessage.IS_NOT_ACCESSIBLE);
                            Header.txtAdHocCustomer_cd = Header.Tag.txtAdHocCustomer_cd;
                            return FormPostEvent();
                        }
                    }
                }

                Header.ClearOptions();     // This indicates that this is the ad-hoc statement printing
            }
            else
            {
                Header.cboAdHocPeriodBegin_dt = "";
                Header.cboAdHocPeriodEnd_dt = "";
            }

            return FormPostEvent();
        }

        private bool cboFiscalYear_Clicked()
        {
            if (Header.cboFiscalYear == Header.Tag.cboFiscalYear)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            ShowSchedule();

            return FormPostEvent();
        }

        private bool cmdCalendarYear_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (CreateScheduleForCalendarYear())
            {
                FormRecreateGrid();
            }

            return FormPostEvent();
        }

        private bool cmdFiscalYear_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (CreateScheduleForFiscalYear())
            {
                FormRecreateGrid();
            }

            return FormPostEvent();
        }

        private bool cmdCreateStatement_Clicked()
        {
            string period_from = "";
            string period_thru = "";

            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (StatementPeriodList.Count() <= 1)
            {
                FormShowMessage(User.Language.oMessage.CREATE_STATEMENT_SCHEDULE);
                cmdViewSecond_Clicked();
                return false;
            }

            if (moUtility.IsEmpty(Header.cboStatementPeriod_dt))
            {
                FormShowMessage(User.Language.oMessage.PLEASE_SELECT_THE_STATEMENT_PERIOD);
                FormSetFocus("cboStatementPeriod_dt");
                return false;
            }

            period_from = GlobalVar.goUtility.SLeft(modCommonUtility.GetComboText(StatementPeriodList, Header.cboStatementPeriod_dt), 10);
            period_thru = GlobalVar.goUtility.SRight(modCommonUtility.GetComboText(StatementPeriodList, Header.cboStatementPeriod_dt), 10);

            if (moGeneral.GenerateCustomerStatement(moGeneral.ToNumDate(period_from), moGeneral.ToNumDate(period_thru), moGeneral.CurrentDate(), "", false))
            {
                FormShowMessage(User.Language.oMessage.CREATED_SUCCESSFULLY, false);
            }
            else
            {
                if (moDatabase.IsErrorFound())
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                }
                else 
                { 
                    FormShowMessage(User.Language.oMessage.PROCESS_HAS_BEEN_FAILED);
                }
            }


            return FormPostEvent();
        }

        private bool cmdSaveSchedule_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormRecreateDetail();

            if (SaveSchedule())
            {
                FormShowMessage(User.Language.oMessage.SAVING_DONE, false);

                modLoadUtility.LoadStatementPeriod(ref moDatabase, ref StatementPeriodList, moDatabase.sCurFiscalYear, false, true);
                modLoadUtility.LoadStatementPeriodBegin(ref moDatabase, ref CustomerPeriodBeginList, moDatabase.sCurFiscalYear, true);
                modLoadUtility.LoadStatementPeriodEnd(ref moDatabase, ref CustomerPeriodEndList, moDatabase.sCurFiscalYear, true);

            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

        private bool SetReportSelection()
        {
            bool return_value = false;
			long process_id = 0;
            string sql_str = "";
            string period_from = "";
            string period_thru = "";

            try
            {
                process_id = moUtility.GetReportProcessID();

                if (AdHocStatement)
                {
                    period_from = Header.cboAdHocPeriodBegin_dt;
                    period_thru = Header.cboAdHocPeriodEnd_dt;
                }
                else
                {
                    period_from = GlobalVar.goUtility.SLeft(modCommonUtility.GetComboText(StatementPeriodList, Header.cboStatementPeriod_dt), 10);
                    period_thru = GlobalVar.goUtility.SRight(modCommonUtility.GetComboText(StatementPeriodList, Header.cboStatementPeriod_dt), 10);
                }

                if (AdHocStatement)       // Recreate only for Ad-Hoc
                {
                    if (!moGeneral.GenerateCustomerStatement(moGeneral.ToNumDate(period_from), moGeneral.ToNumDate(period_thru), moGeneral.CurrentDate(), Header.txtAdHocCustomer_cd, Header.chkOutstandingBalanceOnly_fl))
                    {
                        FormShowMessage();
                        return false;
                    }
                    else
                    {
                        if (moDatabase.IsErrorFound())
                        {
                            FormShowMessage(moDatabase.GetErrorMessage(), false);
                        }
                    }
                }

                sql_str = "{tblARStatement.iPeriodEnd_dt} = " + moGeneral.ToNumDate(period_thru).ToString(); // All statements are based on the period-end date.

                if (AdHocStatement)
                {

                    sql_str += " AND ({tblARCustomer.sCustomer_cd} = '" + Header.txtAdHocCustomer_cd + "')";

                }
                else if (moUtility.IsNonEmpty(Header.txtCustomer_cd))
                {

                    sql_str += " AND ({tblARCustomer.sCustomer_cd} = '" + Header.txtCustomer_cd + "')";

                }
                else
                {

                    sql_str += " AND ({tblARCustomer.iPrintStmt_fl} > 0 OR {tblARCustomer.iEmailStmt_fl} > 0)";

                    if (Header.chkOutstandingBalanceOnly_fl)
                    {
                        sql_str += " AND ({tblARCustomer.mBalanceDue_amt} >= " + moDatabase.mSmallestMoney_amt.ToString() + ")";
                    }

                    if (moUtility.IsNonEmpty(Header.cboClass_cd))
                    {
                        sql_str += " AND ({tblARCustomer.sClass_cd} = '" + Header.cboClass_cd + "')";
                    }
                    if (moUtility.IsNonEmpty(Header.cboGroup_cd))
                    {
                        sql_str += " AND ({tblARCustomer.sGroup_cd} = '" + Header.cboGroup_cd + "')";
                    }
                    if (moUtility.IsNonEmpty(Header.cboSalesrep_cd))
                    {
                        sql_str += " AND ({tblARCustomer.sSalesrep_cd} = '" + Header.cboSalesrep_cd + "')";
                    }
                    if (moUtility.IsNonEmpty(Header.cboStatementGroup_cd))
                    {
                        sql_str += " AND ({tblARCustomer.sStatementGroup_cd} = '" + Header.cboStatementGroup_cd + "')";
                    }
                    if (moUtility.IsNonEmpty(Header.cboTerritory_cd))
                    {
                        sql_str += " AND ({tblARCustomer.sTerritory_cd} = '" + Header.cboTerritory_cd + "')";
                    }

                }

                sql_str += " AND ({tblARBalanceHistory.iApply_dt} >= " + moGeneral.ToNumDate(period_from).ToString() + " AND {tblARBalanceHistory.iApply_dt} <= " + moGeneral.ToNumDate(period_thru).ToString() + ")";

                moReport.SetSelectionFormula(modCommonReportUtility.CleanupFormula(sql_str));
                moReport.SetFormula("show_aging", GlobalVar.goUtility.IIf(Header.chkShowAging_fl, "1", "0").ToString());
                moReport.SetFormula("show_stub", GlobalVar.goUtility.IIf(Header.chkShowStub_fl, "1", "0").ToString());
                moReport.SetFormula(modConstant.CRYSTAL_LOGO_FUNCTION, modCommonUtility.GetCompanyLogoFile(ref moDatabase));

                // VERY IMPORTANT :
                // If this is up-to the current period, which is available only if this is for a specific customer.
                // Set the date-thru to today.
                //
                if (AdHocStatement && moGeneral.ToNumDate(Header.cboAdHocPeriodEnd_dt) > moGeneral.CurrentDate())
                {
                    period_thru = moGeneral.ToStrDate(moGeneral.CurrentDate());
                }

                moReport.SetFormula("statement_period", period_from + " ~ " + period_thru);

                moReport.SetSelectionFormula(sql_str);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SetReportSelection)");
            }

            return return_value;
        }

        private bool SetReportFile()
        {
            bool return_value = false;

            try
            {
                moReport.SetFileName(modCommonReportUtility.GetStatementReportFileName(ref moDatabase, "", true, Header.chkShowAging_fl, AdHocStatement), GlobalVar.goUtility.GetCustomReportFolder(ref moDatabase));

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SetReportFile)");
            }

            return return_value;
        }

        private bool CreateScheduleForCalendarYear()
        {
            bool return_value = false;
            int row_num = 0;
            int total_periods = 0;
            int temp_date = 0;

            try
            {
                if (moUtility.IsEmpty(Header.cboFiscalYear))
                {
                    FormShowMessage(User.Language.oMessage.FISCAL_YEAR_SHOULD_EXIST);
                    return false;
                }

                total_periods = 12;
                moUtility.ResizeDim(ref moDetail.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, total_periods - 1);

                moDetail.Data[STATEMENT_PERIOD_END, 0] = moGeneral.ToStrDate(GlobalVar.goUtility.ToInteger(Header.cboFiscalYear) * 10000 + 131);
                moDetail.Data[STATEMENT_PERIOD_END, total_periods - 1] = moGeneral.ToStrDate(GlobalVar.goUtility.ToInteger(Header.cboFiscalYear) * 10000 + 1231);

                for (row_num = 0; row_num < total_periods; row_num++)
                {
                    moDetail.Data[STATEMENT_PERIOD, row_num] = (row_num + 1).ToString();

                    temp_date = GlobalVar.goUtility.ToInteger(Header.cboFiscalYear) * 10000 + (row_num + 1) * 100 + 1;
                    moDetail.Data[STATEMENT_PERIOD_BEGIN, row_num] = moGeneral.ToStrDate(temp_date);
                }

                for (row_num = 1; row_num <= total_periods - 2; row_num++)
                {
                    temp_date = moGeneral.ToNumDate(moDetail.Data[STATEMENT_PERIOD_BEGIN, row_num + 1]);
                    temp_date = GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, temp_date, -1);
                    moDetail.Data[STATEMENT_PERIOD_END, row_num] = moGeneral.ToStrDate(temp_date);
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(CreateScheduleForCalendarYear)");
            }

            return return_value;
        }

        private bool CreateScheduleForFiscalYear()
        {
            bool return_value = false;
            int row_num = 0;
            int total_periods = 0;
            string sql_str = null;
            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                if (moUtility.IsEmpty(Header.cboFiscalYear))
                {
                    FormShowMessage(User.Language.oMessage.FISCAL_YEAR_SHOULD_EXIST);
                    return false;
                }

                sql_str = "SELECT * FROM tblGLPeriodDet WHERE sFiscalYear = '" + Header.cboFiscalYear + "' ORDER BY iDetail_num";
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    FormShowMessage();
                    return false;
                }

                if (cur_set.EOF())
                {
                    FormShowMessage(User.Language.oMessage.FISCAL_YEAR_SHOULD_EXIST);
                    return false;
                }

                total_periods = cur_set.RecordCount();
                moUtility.ResizeDim(ref moDetail.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, total_periods - 1);

                for (row_num = 0; row_num < total_periods; row_num++)
                {
                    moDetail.Data[STATEMENT_PERIOD, row_num] = (row_num + 1).ToString();
                    moDetail.Data[STATEMENT_PERIOD_BEGIN, row_num] = moGeneral.ToStrDate(cur_set.iField("iPeriodBegin_dt"));
                    moDetail.Data[STATEMENT_PERIOD_END, row_num] = moGeneral.ToStrDate(cur_set.iField("iPeriodEnd_dt"));
                    cur_set.MoveNext();
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(CreateScheduleForFiscalYear)");
            }

            return return_value;

        }

        private bool SaveSchedule()
        {
            bool return_value = false;
            string sql_str = null;
            int row_num = 0;

            try
            {
                if (CheckSchedule() == false)
                {
                    return false;
                }

                sql_str = "DELETE FROM tblARStatementPeriod WHERE sFiscalYear = '" + Header.cboFiscalYear + "'";
                if (!moDatabase.ExecuteSQL(sql_str))
                {
                    FormShowMessage();
                    return false;
                }

                for (row_num = 0; row_num < moDetail.Data.GetLength(1); row_num++)
                {
                    if (moUtility.IsEmpty(moDetail.Data[STATEMENT_PERIOD_BEGIN, row_num]) || moUtility.IsEmpty(moDetail.Data[STATEMENT_PERIOD_END, row_num]))
                    {
                        break;
                    }

                    sql_str = "INSERT INTO tblARStatementPeriod(";
                    sql_str += "sFiscalYear";
                    sql_str += ",iDetail_num";
                    sql_str += ",iPeriodBegin_dt";
                    sql_str += ",iPeriodEnd_dt";
                    sql_str += ",iStatement_dt";
                    sql_str += ") VALUES (";
                    sql_str += "'" + Header.cboFiscalYear + "'";
                    sql_str += "," + (row_num + 1).ToString();
                    sql_str += "," + moGeneral.ToNumDate(moDetail.Data[STATEMENT_PERIOD_BEGIN, row_num]).ToString();
                    sql_str += "," + moGeneral.ToNumDate(moDetail.Data[STATEMENT_PERIOD_END, row_num]).ToString();
                    sql_str += ",0";
                    sql_str += ")";
                    if (!moDatabase.ExecuteSQL(sql_str))
                    {
                        FormShowMessage();
                        return false;
                    }

                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(SaveSchedule)");
            }

            return return_value;
        }

        private bool ShowSchedule()
        {
            bool return_value = false;
            int row_num = 0;
            int total_periods = 0;
            string sql_str = null;
            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                mbDisablePeriod_fl = false;
                moDetail.Grid.Clear();

                if (moUtility.IsEmpty(Header.cboFiscalYear))
                {
                    return false;
                }

                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                sql_str = "SELECT * FROM tblARStatementPeriod WHERE sFiscalYear = '" + Header.cboFiscalYear + "' ORDER BY iDetail_num";
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    FormShowMessage();
                    return false;
                }

                if (cur_set.RecordCount() > 0)
                {
                    total_periods = cur_set.RecordCount();
                }
                else
                {
                    return true;
                }

                moUtility.ResizeDim(ref moDetail.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, total_periods - 1);

                for (row_num = 0; row_num < total_periods; row_num++)
                {

                    moDetail.Data[STATEMENT_PERIOD, row_num] = (row_num + 1).ToString();

                    if (!cur_set.EOF())
                    {
                        moDetail.Data[STATEMENT_PERIOD_BEGIN, row_num] = moGeneral.ToStrDate(cur_set.iField("iPeriodBegin_dt"));
                        moDetail.Data[STATEMENT_PERIOD_END, row_num] = moGeneral.ToStrDate(cur_set.iField("iPeriodEnd_dt"));
                        moDetail.Data[STATEMENT_CREATED, row_num] = moGeneral.ToStrDate(cur_set.iField("iStatement_dt"));

                        if (cur_set.iField("iStatement_dt") > 0)
                        {
                            mbDisablePeriod_fl = true;
                        }

                        cur_set.MoveNext();
                    }
                    else
                    {
                        moDetail.Data[STATEMENT_PERIOD_BEGIN, row_num] = "";
                        moDetail.Data[STATEMENT_PERIOD_END, row_num] = "";
                        moDetail.Data[STATEMENT_CREATED, row_num] = "";
                    }

                }

                moDetail.RecreateGrid();
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(ShowSchedule)");
            }

            return return_value;
        }

        private bool CheckSchedule()
        {
            bool return_value = false;
            int total_periods = 0;
            int row_num = 0;

            try
            {
                FormRecreateDetail();

                for (total_periods = moDetail.Data.GetUpperBound(1); total_periods >= 0; total_periods--)
                {
                    if (moUtility.IsNonEmpty(moDetail.Data[STATEMENT_CREATED, total_periods]))
                    {
                        FormShowMessage(User.Language.oMessage.CANNOT_SAVE_THIS);
                        return false;
                    }
                    if (moUtility.IsNonEmpty(moDetail.Data[STATEMENT_PERIOD_BEGIN, total_periods]) || moUtility.IsNonEmpty(moDetail.Data[STATEMENT_PERIOD_END, total_periods]))
                    {
                        break;
                    }
                }

                if (total_periods <= 0)
                {
                    FormShowMessage(User.Language.oMessage.PERIOD_IS_NOT_SETUP_PROPERLY);
                    return false;
                }

                for (row_num = 0; row_num <= total_periods; row_num++)
                {

                    if (moUtility.IsEmpty(moDetail.Data[STATEMENT_PERIOD_BEGIN, row_num]))
                    {
                        FormShowMessage(User.Language.oMessage.PERIOD_IS_NOT_SETUP_PROPERLY);
                        return false;
                    }
                    else if (moUtility.IsEmpty(moDetail.Data[STATEMENT_PERIOD_END, row_num]))
                    {
                        FormShowMessage(User.Language.oMessage.PERIOD_IS_NOT_SETUP_PROPERLY);
                        return false;
                    }
                    else if (moGeneral.ToNumDate(moDetail.Data[STATEMENT_PERIOD_BEGIN, row_num]) >= moGeneral.ToNumDate(moDetail.Data[STATEMENT_PERIOD_END, row_num]))
                    {
                        FormShowMessage(User.Language.oMessage.PERIOD_IS_NOT_SETUP_PROPERLY);
                        return false;
                    }

                    if (row_num < total_periods)
                    {
                        if (moGeneral.ToNumDate(moDetail.Data[STATEMENT_PERIOD_BEGIN, row_num + 1]) <= moGeneral.ToNumDate(moDetail.Data[STATEMENT_PERIOD_END, row_num]))
                        {
                            FormShowMessage(User.Language.oMessage.PERIOD_IS_NOT_SETUP_PROPERLY);
                            return false;
                        }
                        else if (moGeneral.ToNumDate(moDetail.Data[STATEMENT_PERIOD_BEGIN, row_num + 1]) != GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, moGeneral.ToNumDate(moDetail.Data[STATEMENT_PERIOD_END, row_num]), 1))
                        {
                            FormShowMessage(User.Language.oMessage.PERIOD_IS_NOT_SETUP_PROPERLY);
                            return false;
                        }
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(CheckSchedule)");
            }

            return return_value;
        }
    }
}
