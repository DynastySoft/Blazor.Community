﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.ASP.Models;

namespace Dynasty.ASP.Pages.AR
{
    public partial class SalesRep
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<SalesRep> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;                                                               
        private Models.clsListing moListing;
        private Models.clsSpreadsheet moSpreadsheet;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        private bool ShowListingPrinter
        {
            get
            {
                return (mbListingInitiated_fl && mbListingPopulated_fl);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private Models.clsCustomField moCustomFields;
        private clsInquiry moInquiry;
        private clsCustomization moCustomization;

        private List<Models.clsCombobox> TerritoryCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CommissionCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ManagerCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> PaymentTypeList = new List<Models.clsCombobox>();

        // Listing options
        //
        private List<Models.clsCombobox> ListingByList = new List<Models.clsCombobox>();
        private string cboListingBy = "";
        private bool mbListingInitiated_fl = false;
        private bool mbListingPopulated_fl = false;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader                   
        {
            // Listing of UI items on the header
            //
            public string txtKey_id = "";
            public string txtSalesrep_nm = "";
			public string txtSSN = "";
			public string txtAddress1 = "";
            public string txtAddress2 = "";
            public string txtAddress3 = "";
            public string txtCity = "";
            public string txtState = "";
            public string txtZipCode = "";
            public string txtFax = "";
            public string txtPhone1 = "";
            public string txtPhone2 = "";
            public string txtSortKey1 = "";
            public string txtSortKey2 = "";
            public string txtComment = "";

            public string lblBalanceDue_amt = "";

            public string cboManager_cd = "";
            public string cboCommission_cd = "";
            public string cboTerritory_cd = "";
            public string cboPayment_typ = "";

            public bool chkManager_fl = false;

            // Datetime component is not very user-friendly, yet, as of VS2019.
            // For better understanding this, read the comment on bUseDatePicker_fl in clsUser.
            //
            public string mskTerminated_dt = "";                        
            public string mskHired_dt = "";
            public DateTime? dtTerminated_dt = null;                    // Make sure nullable datetime.
            public DateTime? dtHired_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag                                                                     
            {
                public string txtKey_id = "";
                public string mskTerminated_dt = "";                       
                public string mskHired_dt = "";
                public DateTime? dtTerminated_dt = null;                   // Make sure nullable datetime
                public DateTime? dtHired_dt = null;
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()                                                                  
            {

                Tag.txtKey_id = txtKey_id;
                Tag.dtTerminated_dt = dtTerminated_dt;
                Tag.dtHired_dt = dtHired_dt;
                Tag.mskTerminated_dt = mskTerminated_dt;
                Tag.mskHired_dt = mskHired_dt;
            }
        }
        private clsHeader Header = new clsHeader();

        private int miUDF_num = 0;

        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;                        
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows()
        {

            return true;
        }

        private bool FormCalculateTotal()
        {

            return true;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            if (FormCheckSecurity() == false)
            {
                return false;
            }
            else if (FormCheckHeader() == false)
            {
                return false;
            }
            else if (FormCheckExtra() == false)
            {
                return false;
            }

            return true;
        }

        private bool FormCheckExtra()                                                              // validate extra other than the header and detail.
        {
            bool return_value = false;

            try
            {

                // Custom fields
                //
                if (moCustomFields.CheckValues(moDatabase) == false)
                {
                    FormShowMessage(moCustomFields.GetErrorMessage());
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckExtra)");
            }

            return return_value;
        }

        private bool FormCheckHeader()                                                             // validate the header data.
        {
            bool return_value = false;

            try
            {
                Header.txtSalesrep_nm = moUtility.EvalQuote(moUtility.STrim(Header.txtSalesrep_nm));

                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormShowMessage(User.Language.oCaption.CODE + @User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("txtKey_id");
                    return false;
                }
                else if (moValidate.IsValidUser(Header.txtKey_id) == false)
                {
                    FormShowMessage(Header.txtKey_id + User.Language.oMessage.HAS_TO_BE_VALID_USER);
                    FormSetFocus("txtKey_id");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.txtSalesrep_nm))
                {
                    FormShowMessage(User.Language.oCaption.NAME + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("txtSalesrep_nm");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.txtPhone1))
                {
                    FormShowMessage(User.Language.oCaption.PHONE_1 + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("txtPhone1");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.txtSSN))
                {
                    FormShowMessage(User.Language.oCaption.SSN + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("txtSSN");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboTerritory_cd))
                {
                    FormShowMessage(User.Language.oCaption.TERRITORY + User.Language.oMessage.IS_REQUIRED);
                    FormSetFocus("cboTerritory_cd");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboCommission_cd))
                {
                    FormShowMessage(User.Language.oMessage.COMMISSION_CODE_HAS_TO_BE_SELECTED);
                    FormSetFocus("cboCommission_cd");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboPayment_typ))
                {
                    FormShowMessage(User.Language.oMessage.PAYMENT_TYPE_HAS_TO_BE_SELECTED);
                    FormSetFocus("cboPayment_typ");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.mskHired_dt) || moGeneral.IsValidDate(Header.mskHired_dt) == false)               // Do NOT use dtHired_dt.  mskHired_dt should have a valid value, sync'ed in FormPostEvent()
                {
                    FormShowMessage(User.Language.oCaption.DATE_HIRED + User.Language.oMessage.IS_REQUIRED);
                    if (User.bUseDatePicker_fl)
                    {
                        FormSetFocus("dtHired_dt");
                    }
                    else
                    {
                        FormSetFocus("mskHired_dt");
                    }
                    return false;
                }

                // Labeling is based on txtAddress3 so that it needs to be updated before being saved.
                // The country code is introduced now so that  txtAddress3 does not need it any more.
                //
                Header.txtState = moUtility.SUCase(moUtility.STrim(Header.txtState));
                Header.txtAddress3 = moUtility.STrim(Header.txtCity) + ", " + Header.txtState + " " + moUtility.STrim(Header.txtZipCode);
                Header.txtAddress3 = moUtility.IIf(moUtility.STrim(Header.txtAddress3) == ",", "", Header.txtAddress3).ToString();
                if (moUtility.SLength(Header.txtAddress3) > 40)
                {
                    FormShowMessage("\"" + Header.txtAddress3 + "\" " + User.Language.oMessage.IS_TOO_LONG);
                    return return_value;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckHeader)");
            }

            return return_value;
        }

        private bool FormCheckConcurrency(clsRecordset cur_set)                                    // Check if someone has changed this record while it is open in this session.
        {
            if (cur_set.IsNonEmpty()) 
            {
                if (moPage.bNew_fl)
                {
                    // If someone has created a record with the same key
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.DUPLICATE_IS_FOUND + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                    moPage.bNew_fl = false;
                }
                else if (moPage.CheckForConcurrency(cur_set) == false)
                {
                    // If someone has updated this record in the meantime.
                    //
                    if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        private bool FormCheckToDelete()
        {
            clsIntegrity o_integrity = new clsIntegrity(ref moDatabase);

            if (FormCheckSecurity() == false)
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }
            else if (modFormUtility.IsReservedRecord(ref moDatabase, Header.txtKey_id, moPage.bReserved_fl))
            {
                FormShowMessage(User.Language.oMessage.RESERVED_RECORD_IS_NOT_ALLOWED_TO_DELETE);
                return false;
            }
            else if (o_integrity.IsReferenced(moPage.sModule_id, moPage.sKeyField_nm, Header.txtKey_id))
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }

            return true;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearExtra();

            return true;
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            // Custom Fields
            //
            moCustomFields.ClearGrid();

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {
            Header.txtKey_id = "";
            Header.txtSalesrep_nm = "";

            Header.txtAddress1 = "";
            Header.txtAddress2 = "";
            Header.txtAddress3 = "";
            Header.txtFax = "";
            Header.txtPhone1 = "";
            Header.txtPhone2 = "";
            Header.txtSSN = "";
            Header.txtCity = "";
            Header.txtState = "";
            Header.txtZipCode = "";
            Header.txtSortKey1 = "";
            Header.txtSortKey2 = "";
            Header.lblBalanceDue_amt = "";
            Header.chkManager_fl = false;
            Header.txtComment = "";

            Header.cboManager_cd = "";
            Header.cboCommission_cd = "";
            Header.cboTerritory_cd = "";
            Header.cboPayment_typ = "";

            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            //
            Header.mskHired_dt = "";
            Header.mskTerminated_dt = "";
            FormSyncDates(false);

            return true;
        }

        private bool FormClearMessage()                                                            
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id) || moPage.bNew_fl)
                {
                    FormClear();
                    return true;
                }
                else if (FormCheckToDelete() == false)
                {
                    return false;
                }

                // Transaction begins here.
                //
                if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }

                if (modFormUtility.RecordDelete(ref moDatabase, moPage.iScreen_typ, Header.txtKey_id, moPage.sKeyField_nm, moPage.sTable_nm, moPage.sDetailTable_nm, moPage.sRestrictionClause, moPage.iTransaction_typ) == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }
                else if (FormDeleteExtra() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }

                // Transaction ends here.
                //
                if (moDatabase.TransactionCommit() == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDelete)");
                moDatabase.TransactionRollback();
                return_value = false;
            }

            return return_value;
        }

        private bool FormDeleteExtra()
        {

            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormFindRecord(ref clsRecordset cur_set, int matching_type = 0)
        {
            bool return_value = false;

            matching_type = (int)(moUtility.IIf(matching_type > 0, matching_type, GlobalVar.goConstant.MATCHING_RECORD_TYPE));
            return_value = modFormUtility.RecordRead(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sTable_nm, moPage.sKeyField_nm, moPage.sPreviousKey_id, moPage.sRestrictionClause, ref matching_type);

            return return_value;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moCustomFields = new Models.clsCustomField();
            moInquiry = new clsInquiry();
            moCustomization = new clsCustomization(ref moDatabase);

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.ARMENU_NAME;
            moPage.Title = User.Language.oCaption.SALES_REPRESENTATIVE;
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormInitHeader();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = "tblARSalesrep"; 
            moPage.sKeyField_nm = "sSalesrep_cd";
            moPage.iTransaction_typ= 0;
            moPage.sKeyDescription = "sSalesrep_nm";                                                // For listing

            return true;
        }

        private bool FormPostEvent()
        {

            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            // FormSave() & FormCheck() use the plain textbox whose name starts with "msk"
            // dt* variables are only to interact with UI.  Internally, msk* fields are used.
            //
            FormSyncDates(User.bUseDatePicker_fl);

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback
            
            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;
            ArrayList item_list = new ArrayList();

            try
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                modLoadUtility.LoadSalesrepPaymentType(ref moDatabase, ref PaymentTypeList);
				modLoadUtility.LoadCommissionCode(ref moDatabase, ref CommissionCodeList);
				modLoadUtility.LoadCustomerTerritoryCode(ref moDatabase, ref TerritoryCodeList);
				modLoadUtility.LoadSalespersonCode(ref moDatabase, ref ManagerCodeList);

                item_list.Add(new clsComboBoxItem(User.Language.oCaption.CODE, "sSalesrep_cd"));
                item_list.Add(new clsComboBoxItem(User.Language.oCaption.NAME, "sSalesrep_nm"));
                item_list.Add(new clsComboBoxItem(User.Language.oCaption.CITY, "sCity"));
                item_list.Add(new clsComboBoxItem(User.Language.oCaption.PHONE, "sPhone1"));
                item_list.Add(new clsComboBoxItem(User.Language.oCaption.MANAGER, "sManager_cd"));
                item_list.Add(new clsComboBoxItem(User.Language.oCaption.COMMISSION_CODE, "sCommission_cd"));
                item_list.Add(new clsComboBoxItem(User.Language.oCaption.TERRITORY, "sTerritory_cd"));

                modWebLoadUtility.LoadComboBox(ref ListingByList, item_list);
                cboListingBy = "sSalesrep_cd";

                // Custom Fields
                //
                if (moCustomization.ReadCustomInfo(0, User.Language.oString.STR_SALESREP))
                {
                    moCustomFields.CreateGrid(moCustomization.sField_nm, moCustomization.sCaptions, moCustomization.bRequired);
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormMove(int record_move_direction)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormClear();

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            if (FormFindRecord(ref cur_set, record_move_direction) == false)
            {
                return false;
            }

            FormShow(cur_set);
            return true;

        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostSave()
        {
            // If this is a transaction page, and transaction number has changed, let the user know.
            //
            if (moPage.sPreviousKey_id != Header.txtKey_id)
            {
                FormShowMessage(User.Language.oMessage.TRX_NUM_HAS_CHANGED_TO + "  " + Header.txtKey_id, false);
            }

            moPage.sPreviousKey_id = Header.txtKey_id;

            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {

            return true;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormSave()
        {
            bool return_value = false;
            clsRecordset cur_set;

            try
            {
                if (FormOpenDatabase() == false)                     // Has to come before FormCheck()
                {
                    return false;
                }
                else if (FormCheck() == false)                       // Check if data is ok to save.
                {
                    return false;
                }

                moPage.sPreviousKey_id = Header.txtKey_id;
                cur_set = new clsRecordset(ref moDatabase);

                if (modFormUtility.RecordOpen(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sRestrictionClause, moPage.sTable_nm, moPage.sKeyField_nm) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormCheckConcurrency(cur_set) == false)
                {
                    return false;
                }
                else if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormPreSave(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveHeader(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveExtra(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (moDatabase.TransactionCommit() == false)
                {
                    FormShowMessage();
                    moDatabase.TransactionRollback();
                    return false;
                }

                FormPostSave();
                    
                return_value = true;

            }
            catch (Exception ex)
            {

                FormShowMessage(ex.Message + " (FormSave)");
                moDatabase.TransactionRollback();

            }

            return return_value;
        }

        private bool FormSaveExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {

                mbListingInitiated_fl = false;      // Let it re-populate

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormSaveHeader(clsRecordset cur_set)
        {
            bool return_value = false;
            string sql_str = null;

            try
            {
                if (moPage.bNew_fl)
                {
                    sql_str = "INSERT INTO " + moPage.sTable_nm + " (";
                    sql_str += moPage.sKeyField_nm;

                    sql_str += ",sSalesrep_nm";
                    sql_str += ",sAddress1";
                    sql_str += ",sAddress2";
                    sql_str += ",sAddress3";
                    sql_str += ",sCity";
                    sql_str += ",sState";
                    sql_str += ",sZipCode";
                    sql_str += ",sFax";
                    sql_str += ",sPhone1";
                    sql_str += ",sPhone2";
                    sql_str += ",sSSN";
                    sql_str += ",sSortKey1";
                    sql_str += ",sSortKey2";
                    sql_str += ",sManager_cd";
                    sql_str += ",sCommission_cd";
                    sql_str += ",sTerritory_cd";
                    sql_str += ",iPayment_typ";
                    sql_str += ",iManager_fl";
                    sql_str += ",iTerminated_dt";
                    sql_str += ",iHired_dt";
                    sql_str += ",sComment";

                    // Custom Fields
                    //
                    sql_str += moCustomFields.GetFieldList();

                    sql_str += ",sLastUpdate_id";
                    sql_str += ",dtLastUpdate_dt";
                    sql_str += ") VALUES (";
                    sql_str += "'" + moUtility.EvalQuote(Header.txtKey_id) + "'";

                    sql_str += ",'" + moUtility.EvalQuote(Header.txtSalesrep_nm) + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtAddress1) + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtAddress2) + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtAddress3) + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtCity) + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtState) + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtZipCode) + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtFax) + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtPhone1) + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtPhone2) + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtSSN) + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtSortKey1) + "'";
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtSortKey2) + "'";
                    sql_str += ",'" + Header.cboManager_cd + "'";
                    sql_str += ",'" + Header.cboCommission_cd + "'";
                    sql_str += ",'" + Header.cboTerritory_cd + "'";
                    sql_str += "," + Header.cboPayment_typ;
                    sql_str += "," + moUtility.IIf(Header.chkManager_fl, GlobalVar.goConstant.FLAG_ON.ToString(), GlobalVar.goConstant.FLAG_OFF.ToString());
                    sql_str += "," + moGeneral.ToNumDate(Header.mskTerminated_dt).ToString();
                    sql_str += "," + moGeneral.ToNumDate(Header.mskHired_dt).ToString();
                    sql_str += ",'" + moUtility.EvalQuote(Header.txtComment) + "'";

                    // Custom Fields
                    //
                    sql_str += moCustomFields.GetValueList(moDatabase);

                    sql_str += ",'" + moDatabase.sUser_cd + "'";
                    sql_str += "," + moDatabase.CreateDatetimeValue(DateTime.Now);
                    sql_str += ")";
                }
                else
                {
                    sql_str = "UPDATE " + moPage.sTable_nm + " SET";

                    sql_str += " sSalesrep_nm = '" + moUtility.EvalQuote(Header.txtSalesrep_nm) + "'";
                    sql_str += ",sAddress1 = '" + moUtility.EvalQuote(Header.txtAddress1) + "'";
                    sql_str += ",sAddress2 = '" + moUtility.EvalQuote(Header.txtAddress2) + "'";
                    sql_str += ",sAddress3 = '" + moUtility.EvalQuote(Header.txtAddress3) + "'";
                    sql_str += ",sCity = '" + moUtility.EvalQuote(Header.txtCity) + "'";
                    sql_str += ",sState = '" + moUtility.EvalQuote(Header.txtState) + "'";
                    sql_str += ",sZipCode = '" + moUtility.EvalQuote(Header.txtZipCode) + "'";
                    sql_str += ",sFax = '" + moUtility.EvalQuote(Header.txtFax) + "'";
                    sql_str += ",sPhone1 = '" + moUtility.EvalQuote(Header.txtPhone1) + "'";
                    sql_str += ",sPhone2 = '" + moUtility.EvalQuote(Header.txtPhone2) + "'";
                    sql_str += ",sSSN = '" + moUtility.EvalQuote(Header.txtSSN) + "'";
                    sql_str += ",sSortKey1 = '" + moUtility.EvalQuote(Header.txtSortKey1) + "'";
                    sql_str += ",sSortKey2 = '" + moUtility.EvalQuote(Header.txtSortKey2) + "'";
                    sql_str += ",sManager_cd = '" + Header.cboManager_cd + "'";
                    sql_str += ",sCommission_cd = '" + Header.cboCommission_cd + "'";
                    sql_str += ",sTerritory_cd = '" + Header.cboTerritory_cd + "'";
                    sql_str += ",iPayment_typ = " + Header.cboPayment_typ;
                    sql_str += ",iManager_fl = " + moUtility.IIf(Header.chkManager_fl, GlobalVar.goConstant.FLAG_ON.ToString(), GlobalVar.goConstant.FLAG_OFF.ToString());
                    sql_str += ",iTerminated_dt = " + moGeneral.ToNumDate(Header.mskTerminated_dt).ToString(); ;
                    sql_str += ",iHired_dt = " + moGeneral.ToNumDate(Header.mskHired_dt).ToString(); ;
                    sql_str += ",sComment = '" + moUtility.EvalQuote(Header.txtComment) + "'";

                    // Custom Fields
                    //
                    sql_str += moCustomFields.GetUpdateList(moDatabase);

                    sql_str += ",sLastUpdate_id = '" + moDatabase.sUser_cd + "'";
                    sql_str += ",dtLastUpdate_dt = " + moDatabase.CreateDatetimeValue(DateTime.Now);
                    sql_str += " WHERE " + moPage.sKeyField_nm + " = '" + moUtility.EvalQuote(Header.txtKey_id) + "'";
                }

                if (moDatabase.ExecuteSQL(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveHeader)");
            }

            return return_value;
        }

        private bool FormSearch()
        {

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {
            if (FormShowHeader(cur_set) == false)
            {
                return false;
            }
            else if (FormShowExtra(cur_set) == false)
            {
                return false;
            }

            FormReArrangeHeader();

            return true;
        }

        private bool FormShowExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                moPage.Clear();
                moPage.PreserveTimestamp(cur_set);
                moPage.bNew_fl = false;

                // This is where bReadOnly_fl & bReserved_fl are set according to the nature of the current record.
                //


                moPage.sPreviousKey_id = Header.txtKey_id;
                Header.Preserve();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowHeader(clsRecordset cur_set)
        {
            bool return_value = false;
            clsMoney o_money = new clsMoney(ref moDatabase);

            try
            {
                Header.txtKey_id = cur_set.sField(moPage.sKeyField_nm);
                Header.txtSalesrep_nm = cur_set.sField("sSalesrep_nm");

                Header.txtAddress1 = cur_set.sField("sAddress1");
                Header.txtAddress2 = cur_set.sField("sAddress2");
                Header.txtAddress3 = cur_set.sField("sAddress3");
                Header.txtFax = cur_set.sField("sFax");
                Header.txtPhone1 = cur_set.sField("sPhone1");
                Header.txtPhone2 = cur_set.sField("sPhone2");
                Header.txtSSN = cur_set.sField("sSSN");
                Header.txtCity = cur_set.sField("sCity");
                Header.txtState = cur_set.sField("sState");
                Header.txtZipCode = cur_set.sField("sZipCode");
                Header.txtSortKey1 = cur_set.sField("sSortKey1");
                Header.txtSortKey2 = cur_set.sField("sSortKey2");
                Header.lblBalanceDue_amt = o_money.ToStrMoney(cur_set.mField("mBalanceDue_amt"));
                Header.chkManager_fl = (cur_set.iField("iManager_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.txtComment = cur_set.sField("sComment");

                Header.cboManager_cd = cur_set.sField("sManager_cd");
                Header.cboCommission_cd = cur_set.sField("sCommission_cd");
                Header.cboTerritory_cd = cur_set.sField("sTerritory_cd");
                Header.cboPayment_typ = cur_set.iField("iPayment_typ").ToString();

                // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
                // Make sure both, dt* and msk*, are sync'ed.
                //
                Header.mskTerminated_dt = moGeneral.ToStrDate(cur_set.iField("iTerminated_dt"));
                Header.mskHired_dt = moGeneral.ToStrDate(cur_set.iField("iHired_dt"));
                FormSyncDates(false);

                // Custom Fields
                //
                moCustomFields.SetValues(moDatabase, cur_set);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowHeader)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowListing()
        {

            if (mbListingInitiated_fl)
            {
                return true;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moListing.Show(moDatabase, moPage, "", "sPhone1", "sCity", "", "", "", "", "","", "","","","", "sTerritory_cd", "sCommission_cd", "sManager_cd", cboListingBy, moCustomization.sField_nm) == false)
            {
                return false;
            }

            mbListingInitiated_fl = true;
            mbListingPopulated_fl = (moListing.Grid.Count > 0);

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtHired_dt, ref Header.mskHired_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtTerminated_dt, ref Header.mskTerminated_dt, use_date_picker);

            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormClear();
                return true;
            }

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
                {
                    return false;
                }
            }

            FormCancel();
            return true;
        }

        private bool btnDelete_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormClear();
                return true;
            }

            if (FormDialog(btnDelete_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_DELETE) == false)
            {
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (FormDelete() == false)
            {
                return false;
            }
            
            FormClear();
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormExit();
                return true;
            }

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }

        private bool btnFirst_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnFirst_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.FIRST_RECORD_TYPE);
        }

        private bool btnLast_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnLast_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.LAST_RECORD_TYPE);
        }

        private bool btnNext_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnNext_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.NEXT_RECORD_TYPE);
        }

        private bool btnPrevious_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnPrevious_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.PREVIOUS_RECORD_TYPE);
        }

        private bool btnSave_Clicked()
        {
            FormPreEvent();

            if (FormSave() == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        private bool btnListingToPrint_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateListingHTML();

            return FormPostEvent();
        }

        private bool btnListingToExcel_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateListingExcel();

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewHeader_Clicked()
        {
            FormPreEvent();                                                                           
            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool cmdViewListing_Clicked()
        {
            FormPreEvent();       
            
            if (FormShowListing() == false)
            {
                return false;
            }

            FormSwitchView(moView.LISTING_PAGE_NUM);
            return true;

        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnListingSelect_Clicked(Models.clsListing.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.IsEmpty(cur_item.Code))
            {
                return false;
            }

            FormClear();
            Header.txtKey_id = cur_item.Code;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;

            FormPreEvent();

            try
            {

                FormSwitchView(moZoom.iView);
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();                                                                   

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }
        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Changed()
        {
            if (Header.txtKey_id == Header.Tag.txtKey_id)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (txtKey_id_Verified() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool dtHired_dt_Changed()
        {
            if (Header.dtHired_dt == Header.Tag.dtHired_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtHired_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtHired_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtHired_dt) == false)
            {
                Header.dtHired_dt = Header.Tag.dtHired_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtHired_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtTerminated_dt_Changed()
        {
            if (Header.dtTerminated_dt == Header.Tag.dtTerminated_dt)
            {
                return true;
            }

            FormPreEvent();                                                                     // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtTerminated_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtTerminated_dt);   // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtTerminated_dt) == false)
            {
                Header.dtTerminated_dt = Header.Tag.dtTerminated_dt;
                FormShowMessage(User.Language.oCaption.DATE_TERMINATED + User.Language.oMessage.IS_INVALID);
                FormSetFocus("dtTerminated_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskHired_dt_Changed()
        {
            if (Header.mskHired_dt == Header.Tag.mskHired_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskHired_dt) == false)
            {
                Header.mskHired_dt = Header.Tag.mskHired_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskHired_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskTerminated_dt_Changed()
        {
            if (Header.mskTerminated_dt == Header.Tag.mskTerminated_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskTerminated_dt) == false)
            {
                Header.mskTerminated_dt = Header.Tag.mskTerminated_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskTerminated_dt");
                return false;
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Verified()
        {
            bool return_value = false;
            clsRecordset cur_set;
            string key_id = "";

            try
            {
                Header.txtKey_id = modCommonUtility.CleanCode(Header.txtKey_id);
                key_id = Header.txtKey_id;

                if (Header.txtKey_id == Header.Tag.txtKey_id)
                {
                    return true;
                }
                else if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormClear();
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    FormClear();
                    FormShowMessage(User.Language.oMessage.CONNECTION_HAS_FAILED);
                    return false;
                }

                cur_set = new clsRecordset(ref moDatabase);

                if (FormFindRecord(ref cur_set))
                {
                    FormShow(cur_set);
                }
                else
                {
                    if (moPage.bNew_fl == false)                                  // This will let the user change the ID if it is brand new record.
                    {
                        FormClear();
                        Header.txtKey_id = key_id;
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtKey_id_Verified)");
            }

            return return_value;
        }

        private bool CustomField_Changed(Models.clsCustomField.clsGrid cur_item)
        {
            FormPreEvent();

            if (moCustomFields.ValidateValue(moDatabase, cur_item) == false)
            {
                FormShowMessage(moCustomFields.GetErrorMessage());
                return false;
            }

            return FormPostEvent();
        }

        private bool cboListingBy_Clicked()
        {
            mbListingInitiated_fl = false;

            FormShowListing();

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

        private bool PrepListingDownload(clsListing o_listing, ref clsSpreadsheet o_spread, ref string[] header_list)
        {
            bool return_value = false;
            int row_num = 0;
            int i = 0;

            try
            {
                moUtility.ResizeDim(ref o_spread.Data, 6 + moCustomization.iTotalFields, o_listing.Grid.Count - 1);

                foreach (var lst in o_listing.Grid)
                {
                    i = 0;
                    miUDF_num = 0;

                    o_spread.Data[i++, row_num] = lst.Code;
                    o_spread.Data[i++, row_num] = lst.Description;
                    o_spread.Data[i++, row_num] = lst.ExtraCol_1;
                    o_spread.Data[i++, row_num] = lst.ExtraCol_2;
                    o_spread.Data[i++, row_num] = lst.ExtraCol_3;
                    o_spread.Data[i++, row_num] = lst.ExtraCol_4;
                    o_spread.Data[i++, row_num] = lst.ExtraCol_5;

                    if (moCustomization.iTotalFields > 0)
                    {
                        foreach (var udf in moCustomFields.Grid)
                        {
                            if (moCustomization.iTotalFields > miUDF_num)
                            {
                                o_spread.Data[i++, row_num] = moListing.CustomFields[miUDF_num++, lst.Row_num];
                            }
                        }
                    }

                    row_num += 1;
                }

                moUtility.ResizeDim(ref header_list, i - 1);
                i = 0;

                header_list[i++] = User.Language.oCaption.CODE;
                header_list[i++] = User.Language.oCaption.NAME;
                header_list[i++] = User.Language.oCaption.PHONE;
                header_list[i++] = User.Language.oCaption.CITY;
                header_list[i++] = User.Language.oCaption.TERRITORY;
                header_list[i++] = User.Language.oCaption.COMMISSION;
                header_list[i++] = User.Language.oCaption.MANAGER;

                if (moCustomization.iTotalFields > 0)
                {
                    foreach (var udf in moCustomFields.Grid)
                    {
                        header_list[i++] = udf.Caption;
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PrepListingDownload)");
            }

            return return_value;
        }

        private bool CreateListingHTML()
        {
            bool return_value = false;
            string html_file = "";
            string[] header_list = null;

            clsSpreadsheet o_listing = new clsSpreadsheet();

            try
            {
                if (ShowListingPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moListing, ref o_listing, ref header_list) == false)
                {
                    return false;
                }

                html_file = moInquiry.CreateHTML(ref moDatabase, moPage.Title, o_listing, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(html_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(html_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateListingHTML)");
            }

            return return_value;
        }


        private bool CreateListingExcel()
        {
            bool return_value = false;
            string csv_file = "";
            string[] header_list = null;

            clsSpreadsheet o_listing = new clsSpreadsheet();

            try
            {
                if (ShowListingPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moListing, ref o_listing, ref header_list) == false)
                {
                    return false;
                }

                csv_file = moInquiry.CreateCSV(ref moDatabase, moPage.Title, o_listing, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(csv_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(csv_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateListingExcel)");
            }

            return return_value;
        }

    }
}
