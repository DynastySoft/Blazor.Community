﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP.Pages.AR
{
    public partial class ShowCommission
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<BinGenerator> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;                                                               
        private Models.clsListing moListing;
        private Models.clsEntitySearch moSearch;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        private bool ShowPrinter
        {
            get
            {
                return (moPage.iCurrentView == moView.MAIN_PAGE_NUM || moPage.iCurrentView == moView.DETAIL_PAGE_NUM);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsBatchPurchaseOrders moPO;
        private clsMoney moMoney;
        private Models.clsSpreadsheet moSummary;
        private Models.clsSpreadsheet moDetail;
        private clsInquiry moInquiry;

        private List<Models.clsCombobox> SalesrepCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> TransactionTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> DateTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CommissionTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CommissionCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> TerritoryCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> PaymentTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> SupervisorCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> SelectionTypeList = new List<Models.clsCombobox>();

        private const int SUM_SALESPERSON_COL = 1;          // DO NOT change the columns numbers.  They are used in clsCommission
        private const int SUM_NO_SALES_COL = 2;
        private const int SUM_INVOICE_AMT_COL = 3;
        private const int SUM_CM_AMT_COL = 4;
        private const int SUM_NET_SALES_COL = 5;
        private const int SUM_ORIGINAL_COMM_COL = 6;
        private const int SUM_ADJUSTMENT_COL = 7;
        private const int SUM_NET_COMM_COL = 8;
        private const int SUM_TOTAL_COLUMNS = 9;

        private const int DET_TRX_NUM_COL = 1;
        private const int DET_TRX_DATE_COL = 2;
        private const int DET_INVOICE_AMT_COL = 3;
        private const int DET_CM_AMT_COL = 4;
        private const int DET_PROFIT_AMT_COL = 5;
        private const int DET_COMM_TYPE_COL = 6;
        private const int DET_COMM_AMT_COL = 7;
        private const int DET_ACTUAL_COMM_AMT_COL = 8;
        private const int DET_ENTRY_DATE_COL = 9;
        private const int DET_USER_ID_COL = 10;
        private const int DET_TOTAL_COLUMNS = 11;

        private string msDetailTitle = "";
        private int miPaid_dt = 0;
        private decimal mmInvoice_amt = 0;

        private string[] msSummaryColumnCaptions;
        private string[] msDetailColumnCaptions;

        private string BY_SALES_PERSON
        {
            get
            {
                return (User.Language.oCaption.SALESREP);
            }       
        }
        private string BY_TERRITORY
        {
            get
            {
                return (User.Language.oCaption.TERRITORY);
            }
        }
        private string BY_COMMISSION_CODE
        {
            get
            {
                return (User.Language.oCaption.COMMISSION_CODE);
            }
        }
        private string BY_PAYMENT_TYPE
        {
            get
            {
                return (User.Language.oCaption.PAYMENT_TYPE);
            }
        }
        private string BY_SUPERVISOR
        {
            get
            {
                return (User.Language.oCaption.SUPERVISOR);
            }
        }


        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================

        private class clsHeader                   
        {
            // Listing of UI items on the header
            //
            public string cboSelection_typ = "";
            public string cboSalesrep_cd = "";
            public string cboAdjustSalesrep_cd = "";
            public string cboTransaction_typ = "";
            public string cboDate_typ = "";
            public int cboAdjustCommission_typ = 0;
            public string txtAdjustInvoice_num = "";
            public string txtAdjust_amt = "";

            public string cboCommission_cd = "";
            public string cboTerritory_cd = "";
            public string cboPayment_typ = "";
            public string cboSupervisor_cd = "";

            // Listing of UI items on the header
            //
            public string mskEntry_dt = "";
            public string mskFrom_dt = "";
            public string mskThru_dt = "";

            public DateTime? dtEntry_dt = null;
            public DateTime? dtFrom_dt = null;
            public DateTime? dtThru_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag
            {
                public string cboAdjustSalesrep_cd = "";
                public int cboAdjustCommission_typ = 0;
                public string cboTransaction_typ = "";
                public string txtAdjustInvoice_num = "";
                public string txtAdjust_amt = "";

                public string cboCommission_cd = "";
                public string cboTerritory_cd = "";
                public string cboPayment_typ = "";
                public string cboSupervisor_cd = "";

                public string mskEntry_dt = "";
                public string mskFrom_dt = "";
                public string mskThru_dt = "";

                public DateTime? dtEntry_dt = null;
                public DateTime? dtFrom_dt = null;
                public DateTime? dtThru_dt = null;
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()                                                                  
            {
                Tag.cboAdjustSalesrep_cd = cboAdjustSalesrep_cd;
                Tag.cboAdjustCommission_typ = cboAdjustCommission_typ;
                Tag.cboTransaction_typ = cboTransaction_typ;
                Tag.txtAdjustInvoice_num = txtAdjustInvoice_num;
                Tag.txtAdjust_amt = txtAdjust_amt;
                Tag.cboCommission_cd = cboCommission_cd;
                Tag.cboTerritory_cd = cboTerritory_cd;
                Tag.cboPayment_typ = cboPayment_typ;
                Tag.cboSupervisor_cd = cboSupervisor_cd;

                Tag.mskEntry_dt = mskEntry_dt;
                Tag.mskFrom_dt = mskFrom_dt;
                Tag.mskThru_dt = mskThru_dt;

                Tag.dtEntry_dt = dtEntry_dt;
                Tag.dtFrom_dt = dtFrom_dt;
                Tag.dtThru_dt = dtThru_dt;
            }
        }
        private clsHeader Header = new clsHeader();

        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            //  If the caller sends a code, bring up the record to begin with.
            // 
            if (moUtility.IsNonEmpty(StarterValue))
            {
                moPage.sInitialKey_id = StarterValue;
            }


            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;                        
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            // If user uses date-picker, we need to change the date field.
            //
            if (User.bUseDatePicker_fl && moUtility.SLeft(field_name, 3) == "msk" && moUtility.SRight(field_name, 3) == "_dt")
            {
                field_name = moUtility.SReplace(field_name, "msk", "dt");
            }

            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows(int lines_to_add = 0)
        {
           
            return true;
        }

        private bool FormCalculateTotal()
        {

            return true;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {

            if (FormCheckSecurity() == false)
            {
                return false;
            }
            if (FormCheckHeader() == false)
            {
                return false;
            }
            if (FormCheckDetail() == false)
            {
                return false;
            }
            if (FormCheckExtra() == false)
            {
                return false;
            }

            return true;
        }

        private bool FormCheckDetail()                                                              
        {
            bool return_value = false;
            int row_num;
            int inner_num;
            int records_found = 0;
            string vendor_code = "";
            bool detail_found_fl = false;

            try
            {

                row_num = 0;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckDetail)");
            }

            return return_value;
        }

        private bool FormCheckExtra()                                                              // validate extra other than the header and detail.
        {
            bool return_value = false;

            try
            {

                // Your extra form-checking goes here.
                //
                if (moUtility.IsEmpty(Header.cboAdjustSalesrep_cd))
                {
                    FormShowMessage(User.Language.oMessage.SALESPERSON_NEEDS_TO_BE_SELECTED);
                    FormSetFocus("cboAdjustSalesrep_cd");
                    return false;
                }
                else if (moGeneral.ValidDate(ref Header.mskEntry_dt) == false)
                {
                    FormShowMessage(User.Language.oMessage.DATE_NEEDS_TO_BE_ENTERED);
                    FormSetFocus("mskEntry_dt");
                    return false;
                }
                else if (moUtility.IsEmpty(Header.txtAdjustInvoice_num))
                {
                    FormShowMessage(User.Language.oMessage.INVOICE_NUMBER_IS_REQUIRED);
                    FormSetFocus("txtAdjustInvoice_num");
                    return false;
                }
                else if (moMoney.ToNumMoney(Header.txtAdjust_amt) == 0M)
                {
                    FormShowMessage(User.Language.oMessage.COMMISSION_AMOUNT_IS_REQUIRED);
                    FormSetFocus("txtAdjust_amt");
                    return false;
                }
                else if (Header.cboAdjustCommission_typ == 0)
                {
                    FormShowMessage(User.Language.oMessage.COMMISSION_TYPE_NEEDS_TO_BE_SELECTED);
                    FormSetFocus("cboAdjustCommission_typ");
                    return false;
                }

                Header.txtAdjust_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.txtAdjust_amt));
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckExtra)");
            }
            
            return return_value;
        }

        private bool FormCheckHeader()                                                             // validate the header data.
        {
            bool return_value = false;

            try
            {

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckHeader)");
            }

            return return_value;
        }

        private bool FormCheckConcurrency(clsRecordset cur_set)                                    // Check if someone has changed this record while it is open in this session.
        {
            
            return true;
        }

        private bool FormCheckToDelete()
        {
           
            return true;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearDetail();
            FormClearExtra();

            return true;
        }

        private bool FormClearDetail()                                                             // Clear the detail.
        {
            moSummary.iTotalRows = 1; // User.iLinesToIncrease;
            moDetail.iTotalRows = 1; // User.iLinesToIncrease;
            moUtility.ResizeDim(ref moSummary.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, moSummary.iTotalRows - 1);
            moUtility.ResizeDim(ref moDetail.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, moDetail.iTotalRows - 1);

            FormRecreateGrid(moSummary);
            FormRecreateGrid(moDetail);

            return true;
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {
            

            return true;
        }

        private bool FormClearMessage()                                                            
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }
                Modal.Release();                                                                   // Release this call and proceed.
            }

            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            
            return true;
        }

        private bool FormDeleteExtra()
        {

            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormFindRecord(ref clsRecordset cur_set, int matching_type = 0)
        {
            bool return_value = false;

            return return_value;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListing();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moPO = new clsBatchPurchaseOrders(ref moDatabase);
            moMoney = new clsMoney(ref moDatabase);
            moSummary = new Models.clsSpreadsheet();
            moDetail = new Models.clsSpreadsheet();
            moInquiry = new clsInquiry();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.ARMENU_NAME;
            moPage.Title = User.Language.oCaption.COMMISSION + " " + User.Language.oCaption.MONITOR;
            moPage.iScreen_typ = GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE;
            moPage.iTransaction_typ = 0;
            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormInitHeader();
            FormInitDetail();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitDetail()                                                              // Initialize the page at loading.  Only once.
        {
            // Detail table name.
            //
            moPage.sDetailTable_nm = "";

            moUtility.ResizeDim(ref moSummary.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, 0);    // These initializations are necessary
            moUtility.ResizeDim(ref moDetail.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, 0);    // These initializations are necessary

            moUtility.ResizeDim(ref msSummaryColumnCaptions, SUM_TOTAL_COLUMNS - 1);

            msSummaryColumnCaptions[SUM_SALESPERSON_COL] = User.Language.oCaption.SALESPERSON;
            msSummaryColumnCaptions[SUM_NO_SALES_COL] = User.Language.oCaption.NUM_OF + "<br />" + User.Language.oCaption.SALES;
            msSummaryColumnCaptions[SUM_INVOICE_AMT_COL] = User.Language.oCaption.INVOICE + "<br />" + User.Language.oCaption.AMOUNT;
            msSummaryColumnCaptions[SUM_CM_AMT_COL] = User.Language.oCaption.CM + "<br />" + User.Language.oCaption.AMOUNT;
            msSummaryColumnCaptions[SUM_NET_SALES_COL] = User.Language.oCaption.NET + "<br />" + User.Language.oCaption.SALES;
            msSummaryColumnCaptions[SUM_ORIGINAL_COMM_COL] = User.Language.oCaption.ORIGINAL + "<br />" + User.Language.oCaption.COMMISSION;
            msSummaryColumnCaptions[SUM_ADJUSTMENT_COL] = User.Language.oCaption.ADJUSTMENT;
            msSummaryColumnCaptions[SUM_NET_COMM_COL] = User.Language.oCaption.NET + "<br />" + User.Language.oCaption.COMMISSION;

            moUtility.ResizeDim(ref msDetailColumnCaptions, DET_TOTAL_COLUMNS - 1);

            msDetailColumnCaptions[DET_TRX_NUM_COL] = User.Language.oCaption.INVOICE + " (" + User.Language.oCaption.CM + ") <br />" + User.Language.oCaption.NUMBER;
            msDetailColumnCaptions[DET_TRX_DATE_COL] = User.Language.oCaption.DATE_APPLIED;
            msDetailColumnCaptions[DET_INVOICE_AMT_COL] = User.Language.oCaption.INVOICE + User.Language.oCaption.AMOUNT;
            msDetailColumnCaptions[DET_CM_AMT_COL] = User.Language.oCaption.CM + User.Language.oCaption.AMOUNT;
            msDetailColumnCaptions[DET_PROFIT_AMT_COL] = User.Language.oCaption.PROFIT + "<br />" + User.Language.oCaption.AMOUNT;
            msDetailColumnCaptions[DET_COMM_TYPE_COL] = User.Language.oCaption.COMMISSION + "<br />" + User.Language.oCaption.TYPE;
            msDetailColumnCaptions[DET_COMM_AMT_COL] = User.Language.oCaption.COMMISSION + "<br />" + User.Language.oCaption.AMOUNT;
            msDetailColumnCaptions[DET_ACTUAL_COMM_AMT_COL] = User.Language.oCaption.ACTUAL + "<br />" + User.Language.oCaption.COMMISSION;
            msDetailColumnCaptions[DET_ENTRY_DATE_COL] = User.Language.oCaption.DATE_ENTERED;
            msDetailColumnCaptions[DET_USER_ID_COL] = User.Language.oCaption.USER;

            FormClearDetail();

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = ""; 
            moPage.sKeyField_nm = "";
            moPage.iTransaction_typ= 0; 

            return true;
        }

        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {
            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            // FormSave() & FormCheck() use the plain box whose name starts with "msk"
            // dt* variables are only to interact with UI.  Internally, msk* fields are used.
            //
            FormSyncDates(User.bUseDatePicker_fl);

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtEntry_dt, ref Header.mskEntry_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtFrom_dt, ref Header.mskFrom_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtThru_dt, ref Header.mskThru_dt, use_date_picker);

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback
            
            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;
            ArrayList array_list = new ArrayList();

            try
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                modLoadUtility.LoadSalespersonCode(ref moDatabase, ref SalesrepCodeList);
                modLoadUtility.LoadCommissionType(ref moDatabase, ref CommissionTypeList);
                modLoadUtility.LoadCommissionCode(ref moDatabase, ref CommissionCodeList);
                modLoadUtility.LoadSalesrepPaymentType(ref moDatabase, ref PaymentTypeList);
                modLoadUtility.LoadCustomerTerritoryCode(ref moDatabase, ref TerritoryCodeList);
                modLoadUtility.loadSalesSupervisorCode(ref moDatabase, ref SupervisorCodeList);

                if (moUtility.IsSalesStaff(moDatabase))
                {
                    Header.cboSalesrep_cd = moDatabase.sUser_cd;
                    Header.cboSelection_typ = BY_SALES_PERSON;
                }

                array_list.Add(new clsComboBoxItem(User.Language.oString.STR_INVOICE, User.Language.oString.STR_INVOICE));
                array_list.Add(new clsComboBoxItem(User.Language.oString.STR_CREDIT_MEMO, User.Language.oString.STR_CREDIT_MEMO));
                modWebLoadUtility.LoadComboBox(ref TransactionTypeList, array_list);
                Header.cboTransaction_typ = User.Language.oString.STR_INVOICE;

                array_list.Clear();
                array_list.Add(new clsComboBoxItem(BY_SALES_PERSON, BY_SALES_PERSON));
                array_list.Add(new clsComboBoxItem(BY_TERRITORY, BY_TERRITORY));
                array_list.Add(new clsComboBoxItem(BY_PAYMENT_TYPE, BY_PAYMENT_TYPE));
                array_list.Add(new clsComboBoxItem(BY_COMMISSION_CODE, BY_COMMISSION_CODE));
                array_list.Add(new clsComboBoxItem(BY_SUPERVISOR, BY_SUPERVISOR));
                modWebLoadUtility.LoadComboBox(ref SelectionTypeList, array_list);
                Header.cboSelection_typ = BY_SALES_PERSON;

                array_list.Clear();
                array_list.Add(new clsComboBoxItem(User.Language.oCaption.DATE_PAID, "iPaid_dt"));
                array_list.Add(new clsComboBoxItem(User.Language.oCaption.TRANSACTION_DATE, "iApply_dt"));
                modWebLoadUtility.LoadComboBox(ref DateTypeList, array_list);
                Header.cboDate_typ = "iPaid_dt";

                msDetailTitle = User.Language.oCaption.DETAILS;

                // Do not delete this.
                // This is necessary because FormInit() is called before moDatabase is open
                //
                if (moDatabase.bCalcCommissionByItem_fl)
                {
                    msDetailColumnCaptions[DET_COMM_TYPE_COL] = "";
                    msDetailColumnCaptions[DET_COMM_AMT_COL] = User.Language.oCaption.SPLIT_PERC;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormMove(int record_move_direction)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormClear();

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            if (FormFindRecord(ref cur_set, record_move_direction) == false)
            {
                return false;
            }

            FormShow(cur_set);
            return true;

        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostSave()
        {
            
            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {

            return true;
        }

        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormRecreateDetail(Models.clsSpreadsheet cur_spread)     
        {
            if (cur_spread.RecreateDetail() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateDetailLine(Models.clsSpreadsheet.clsGrid cur_item, int row_num = -1)
        {
            if (moSummary.RecreateDetailLine(cur_item, row_num) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateGrid(Models.clsSpreadsheet cur_spread)                                                  
        {
            if (cur_spread.RecreateGrid() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormSave()
        {
            bool return_value = false;
            clsRecordset cur_set;

            try
            {

                return_value = true;

            }
            catch (Exception ex)
            {

                FormShowMessage(ex.Message + " (FormSave)");
                moDatabase.TransactionRollback();

            }

            return return_value;
        }

        private bool FormSaveExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormSaveHeader(clsRecordset cur_set)
        {
            bool return_value = false;
            string sql_str = null;

            try
            {

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveHeader)");
            }

            return return_value;
        }

        private bool FormSearch()
        {

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {
            if (FormShowHeader(cur_set) == false)
            {
                return false;
            }
            else if (FormShowExtra(cur_set) == false)
            {
                return false;
            }

            FormReArrangeHeader();

            return true;
        }

        private bool FormShowExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                moPage.Clear();
                moPage.PreserveTimestamp(cur_set);
                moPage.bNew_fl = false;

                // This is where bReadOnly_fl & bReserved_fl are set according to the nature of the current record.
                //


                Header.Preserve();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowHeader(clsRecordset cur_set)
        {
            
            return true;
        }

        private bool FormShowListing()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moListing.Show(moDatabase, moPage) == false)
            {
                return false;
            }

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);

            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moZoom.Caller == "txtVendor_cd")
            {
                if (moZoom.Vendor(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            else if (moZoom.Caller == "txtItem_cd" || moZoom.Caller == "txtItemThru_cd")
            {
                if (moZoom.Inventory(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
                {
                    return false;
                }
            }

            FormCancel();
            return true;
        }

        private bool btnDelete_Clicked()
        {
            FormPreEvent();


            if (FormDialog(btnDelete_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_DELETE) == false)
            {
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (FormDelete() == false)
            {
                return false;
            }
            
            FormClear();
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }

        private bool btnFirst_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnFirst_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.FIRST_RECORD_TYPE);
        }

        private bool btnLast_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnLast_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.LAST_RECORD_TYPE);
        }

        private bool btnNext_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnNext_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.NEXT_RECORD_TYPE);
        }

        private bool btnPrevious_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnPrevious_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.PREVIOUS_RECORD_TYPE);
        }

        private bool btnSave_Clicked()
        {
            FormPreEvent();

            if (FormSave() == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        private bool btnPrint_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateHTML();

            return FormPostEvent();
        }

        private bool btnExcel_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateExcel();

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewMain_Clicked()
        {
            FormPreEvent();       
            
            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;

        }

        private bool cmdViewDetail_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.DETAIL_PAGE_NUM);

            return true;
        }

        private bool cmdViewAdjustCommisssion()
        {
            FormPreEvent();
            FormSwitchView(moView.SECOND_PAGE_NUM);

            if (moUtility.IsEmpty(Header.mskEntry_dt))
            {
                Header.mskEntry_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                FormSyncDates(false);
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnListingSelect_Clicked(Models.clsListing.clsGrid cur_item)
        {
            FormPreEvent();


            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
               
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }

        private bool btnZoomOnKey_id_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }


        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        private bool cmdShow_Clicked()
        {
            FormPreEvent(); 

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            ShowSummary();

            cmdViewMain_Clicked();

            return FormPostEvent();
        }

        private bool dtFrom_dt_Changed()
        {
            if (Header.dtFrom_dt == Header.Tag.dtFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtFrom_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtFrom_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtFrom_dt) == false)
            {
                Header.dtFrom_dt = Header.Tag.dtFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtFrom_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskFrom_dt_Changed()
        {
            if (Header.mskFrom_dt == Header.Tag.mskFrom_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskFrom_dt) == false)
            {
                Header.mskFrom_dt = Header.Tag.mskFrom_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskFrom_dt");
                return false;
            }

            return FormPostEvent();
        }


        private bool dtThru_dt_Changed()
        {
            if (Header.dtThru_dt == Header.Tag.dtThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtThru_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtThru_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtThru_dt) == false)
            {
                Header.dtThru_dt = Header.Tag.dtThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtThru_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskThru_dt_Changed()
        {
            if (Header.mskThru_dt == Header.Tag.mskThru_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskThru_dt) == false)
            {
                Header.mskThru_dt = Header.Tag.mskThru_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskThru_dt");
                return false;
            }

            return FormPostEvent();
        }


        private bool dtEntry_dt_Changed()
        {
            if (Header.dtEntry_dt == Header.Tag.dtEntry_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtEntry_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtEntry_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtEntry_dt) == false)
            {
                Header.dtEntry_dt = Header.Tag.dtEntry_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtEntry_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskEntry_dt_Changed()
        {
            if (Header.mskEntry_dt == Header.Tag.mskEntry_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskEntry_dt) == false)
            {
                Header.mskEntry_dt = Header.Tag.mskEntry_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskEntry_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdAdjustNow_Clicked()
        {
            FormPreEvent();

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (AdjustNow())
            {
                FormShowMessage(User.Language.oMessage.UPDATE_COMPLETE, false);

                Header.txtAdjustInvoice_num = "";
                Header.txtAdjust_amt = "";
            }

            return FormPostEvent();
        }

        private bool txtAdjustInvoice_num_Changed()
        {
            if (moUtility.ToInteger(Header.txtAdjustInvoice_num) > 0)
            {
                Header.txtAdjustInvoice_num = moUtility.ToInteger(Header.txtAdjustInvoice_num).ToString();
            }
            else
            {
                Header.txtAdjustInvoice_num = "";
            }

            if (Header.txtAdjustInvoice_num == Header.Tag.txtAdjustInvoice_num)
            {
                return true;
            }

            FormPreEvent();

            if (moUtility.IsNonEmpty(Header.txtAdjustInvoice_num))
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                if (txtAdjustInvoice_num_Verified() == false)
                {
                    Header.txtAdjustInvoice_num = Header.Tag.txtAdjustInvoice_num;
                }
            }

            return FormPostEvent();
        }

        private bool cboSelection_typ_Clicked()
        {
            if (moUtility.IsSalesStaff(moDatabase) == false)
            {
                Header.cboSalesrep_cd = "";
            }

            Header.cboTerritory_cd = "";
            Header.cboCommission_cd = "";
            Header.cboPayment_typ = "";
            Header.cboSupervisor_cd = "";

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        private bool txtAdjustInvoice_num_Verified()
        {
            bool return_value = false;

            string sql_str = "";
            clsRecordset cur_set = new clsRecordset(ref moDatabase);
            int invoice_num = 0;

            try
            {
                miPaid_dt = 0;
                Header.txtAdjust_amt = "0";

                if (Header.cboTransaction_typ == User.Language.oString.STR_CREDIT_MEMO)
                {
                    sql_str = "SELECT * FROM tblARCharge WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_CM_TYPE + " AND iTransaction_num = " + moUtility.ToInteger(Header.txtAdjustInvoice_num).ToString();
                }
                else
                {
                    sql_str = "SELECT * FROM tblARCharge WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_INVOICE_TYPE + " AND iTransaction_num = " + moUtility.ToInteger(Header.txtAdjustInvoice_num).ToString();
                }

                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (cur_set.EOF())
                {
                    FormShowMessage(Header.txtAdjustInvoice_num + User.Language.oMessage.IS_INVALID);
                    return false;
                }

                mmInvoice_amt = (cur_set.mField("mNonTaxable_amt") + cur_set.mField("mTaxable_amt"));

                if (Header.cboTransaction_typ == User.Language.oString.STR_CREDIT_MEMO)
                {
                    miPaid_dt = 0;
                    if (cur_set.iField("iOrder_num") > 0)
                    {
                        sql_str = "SELECT * FROM tblARCharge WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_INVOICE_TYPE + " AND iTransaction_num = " + cur_set.iField("iOrder_num");
                        if (cur_set.CreateSnapshot(sql_str) == false)
                        {
                            return false;
                        }
                        else if (cur_set.EOF() == false)
                        {
                            miPaid_dt = moUtility.IIf((cur_set.mField("mDue_amt") < moDatabase.mSmallestMoney_amt), cur_set.iField("iPaid_dt"), 0);
                        }
                    }
                }
                else
                {
                    miPaid_dt = moUtility.IIf((cur_set.mField("mDue_amt") < moDatabase.mSmallestMoney_amt), cur_set.iField("iPaid_dt"), 0);
                }

                if (moDatabase.mSmallestMoney_amt > mmInvoice_amt) // Negative invoices can exist
                {
                    //FormShowMessage(Header.txtAdjustInvoice_num & User.Language.oMessage.IS_INVALID)
                    //Header.txtAdjustInvoice_num = ""
                    //txtInvoice_amt = "0"
                    //Exit Sub
                }

                moValidate.oRecordset.Release();
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtAdjustInvoice_num_Verified)");
            }

            return return_value;
        }
        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        private bool btnSummarySelect_Clicked(Models.clsSpreadsheet.clsGrid cur_item)
        {
            FormPreEvent();
            
            if (moUtility.IsEmpty(cur_item.Col_1))                      // Check if salesperson code is valid.
            {
                return false;
            }

            msDetailTitle = cur_item.Col_1;

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (ShowDetail(cur_item.Col_1))
            {
                FormSwitchView(moView.DETAIL_PAGE_NUM);
            }

            return FormPostEvent();
        }

        private bool btnDetailSelect_Clicked(Models.clsSpreadsheet.clsGrid cur_item)
        {
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";
            string trx_num = cur_item.Col_1;

            FormPreEvent();

            trx_num = moUtility.STrim(trx_num);

            if (moUtility.IsEmpty(trx_num))                      // Check if salesperson code is valid.
            {
                return false;
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moUtility.SInStr(trx_num, "(") > 0)
            {
                trx_num = moUtility.SReplace(trx_num, User.Language.oString.STR_CM, "");
                trx_num = moUtility.SReplace(trx_num, "(", "");
                trx_num = moUtility.SReplace(trx_num, ")", "");
                trx_num = moUtility.STrim(trx_num);
                o_session.SetSessionValues(moDatabase, User, ref session_id, trx_num);
                FormOpenPDF("LookupCreditMemo/" + session_id);
            }
            else
            {
                o_session.SetSessionValues(moDatabase, User, ref session_id, trx_num);
                FormOpenPDF("LookupInvoice/" + session_id);
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================


        public bool ShowSummary()
        {

            bool return_value = false;
            string salesperson_from = "";
            string salesperson_thru = "";
            string temp_str = "";
            string sql_str = "";
            string last_rep = "";
            clsRecordset cur_set = new clsRecordset(ref moDatabase);
            int line_num = 0;
            int i = 0;
            int col_num = 0;
            bool found_fl = false;
            decimal amt_total = 0;
            decimal amt_adjusted = 0;
            long calculation_id = 0;
            clsCommission o_commmission = new clsCommission(ref moDatabase);

            try
            {
                msDetailTitle = User.Language.oCaption.DETAILS;
                moDetail.Clear();
                moSummary.Clear();

                if (moUtility.IsBlankDate(Header.mskFrom_dt) && moUtility.IsBlankDate(Header.mskThru_dt))
                {
                    Header.mskFrom_dt = moGeneral.ToStrDate(moDatabase.iCurPeriodBegin_dt);
                    Header.mskThru_dt = moGeneral.ToStrDate(moDatabase.iCurPeriodEnd_dt);
                    FormSyncDates(false);
                }

                if (moUtility.IsBlankDate(Header.mskThru_dt) == false &&  moGeneral.ToNumDate(Header.mskFrom_dt) > moGeneral.ToNumDate(Header.mskThru_dt))
                {
                    temp_str = Header.mskFrom_dt;
                    Header.mskFrom_dt = Header.mskThru_dt;
                    Header.mskThru_dt = temp_str;
                    FormSyncDates(false);
                }

                if (Header.cboSelection_typ == BY_SALES_PERSON)
                {
                    //Header.cboSalesrep_cd = "";
                    Header.cboTerritory_cd = "";
                    Header.cboCommission_cd = "";
                    Header.cboPayment_typ = "";
                    Header.cboSupervisor_cd = "";
                }
                else if (Header.cboSelection_typ == BY_TERRITORY)
                {
                    Header.cboSalesrep_cd = "";
                    //Header.cboTerritory_cd = "";
                    Header.cboCommission_cd = "";
                    Header.cboPayment_typ = "";
                    Header.cboSupervisor_cd = "";
                }
                else if (Header.cboSelection_typ == BY_COMMISSION_CODE)
                {
                    Header.cboSalesrep_cd = "";
                    Header.cboTerritory_cd = "";
                    //Header.cboCommission_cd = "";
                    Header.cboPayment_typ = "";
                    Header.cboSupervisor_cd = "";
                }
                else if (Header.cboSelection_typ == BY_PAYMENT_TYPE)
                {
                    Header.cboSalesrep_cd = "";
                    Header.cboTerritory_cd = "";
                    Header.cboCommission_cd = "";
                    //Header.cboPayment_typ = "";
                    Header.cboSupervisor_cd = "";
                }
                else if (Header.cboSelection_typ == BY_SUPERVISOR)
                {
                    Header.cboSalesrep_cd = "";
                    Header.cboTerritory_cd = "";
                    Header.cboCommission_cd = "";
                    Header.cboPayment_typ = "";
                    //Header.cboSupervisor_cd = "";
                }
                else
                {
                    Header.cboSalesrep_cd = "";
                    Header.cboTerritory_cd = "";
                    Header.cboCommission_cd = "";
                    Header.cboPayment_typ = "";
                    Header.cboSupervisor_cd = "";
                }

                if (moUtility.IsEmpty(Header.cboSalesrep_cd) || Header.cboSalesrep_cd == User.Language.oString.STR_ALL)
                {
                    salesperson_from = "";
                    salesperson_thru = "";
                }
                else
                {
                    salesperson_from = Header.cboSalesrep_cd;
                    salesperson_thru = Header.cboSalesrep_cd;
                }

                calculation_id = o_commmission.GetCalculationID();

                if (!moDatabase.TransactionBegin())
                {
                    return return_value;
                }
                else if (!o_commmission.CalculateCommissions(salesperson_from, salesperson_thru, moGeneral.ToNumDate(Header.mskFrom_dt), moGeneral.ToNumDate(Header.mskThru_dt), true, calculation_id, Header.cboDate_typ))
                {
                    moDatabase.TransactionRollback();
                    return return_value;
                }
                else if (!moDatabase.TransactionCommit())
                {
                    moDatabase.TransactionRollback();
                    return return_value;
                }

                if (!o_commmission.GetCommissionTotalBySalesperson(ref cur_set, salesperson_from, salesperson_thru, moGeneral.ToNumDate(Header.mskFrom_dt), moGeneral.ToNumDate(Header.mskThru_dt), Header.cboDate_typ
                    , Header.cboCommission_cd, Header.cboTerritory_cd, Header.cboSupervisor_cd, moUtility.ToInteger(Header.cboPayment_typ)))
                {
                    FormShowMessage();
                    return return_value;
                }
                else if (cur_set.EOF())
                {
                    FormShowMessage(User.Language.oMessage.NO_RECORDS_FOUND);
                    return false;
                }

                //txtSummaryTotalColumns = moUtility.IIf(cur_set.FieldCount() < grdSummary.Columns.Count - 1, cur_set.FieldCount(), grdSummary.Columns.Count - 1).ToString(); // Exclude the select button

                amt_total = 0;
                amt_adjusted = 0;
                line_num = -1;
                last_rep = "";
                moUtility.ResizeDim(ref moSummary.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, cur_set.RecordCount() + 5);

                moSummary.FieldName = cur_set.FieldName;                // Referenced in CreateHTM & CreateCSV

                for (i = 0; i < moSummary.Data.GetLength(1); i++)
                {
                    if (cur_set.EOF())
                    {
                        break;
                    }

                    if (last_rep != cur_set.sField("sSalesrep_cd"))
                    {
                        line_num += 1;
                        last_rep = cur_set.sField("sSalesrep_cd");
                        moSummary.Data[SUM_SALESPERSON_COL, line_num] = cur_set.sField("sSalesrep_cd");
                    }

                    if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_INVOICE_TYPE && cur_set.iField("iAdjustment_fl") == 0)
                    {
                        moSummary.Data[SUM_NO_SALES_COL, line_num] = cur_set.iField("iCount").ToString();
                        moSummary.Data[SUM_INVOICE_AMT_COL, line_num] = moMoney.ToStrMoney(cur_set.mField("mInvoice"));
                        moSummary.Data[SUM_ORIGINAL_COMM_COL, line_num] = moMoney.ToStrMoney(cur_set.mField("mCommission"));
                    }
                    else
                    {
                        if (cur_set.iField("iAdjustment_fl") == 0)
                        {
                            moSummary.Data[SUM_CM_AMT_COL, line_num] = moMoney.ToStrMoney(cur_set.mField("mInvoice"));
                        }

                        amt_adjusted += cur_set.mField("mCommission");       // commission adjustment + C/M
                        moSummary.Data[SUM_ADJUSTMENT_COL, line_num] = moMoney.ToStrMoney(moMoney.ToNumMoney(moSummary.Data[SUM_ADJUSTMENT_COL, line_num]) + cur_set.mField("mCommission"));
                    }

                    amt_total += cur_set.mField("mCommission");

                    if (cur_set.iField("iAdjustment_fl") == 1)
                    {
                        moSummary.Data[SUM_NET_COMM_COL, line_num] = moMoney.ToStrMoney(moMoney.ToNumMoney(moSummary.Data[SUM_ORIGINAL_COMM_COL, line_num]) + moMoney.ToNumMoney(moSummary.Data[SUM_ADJUSTMENT_COL, line_num]));
                    }
                    else
                    {
                        moSummary.Data[SUM_NET_SALES_COL, line_num] = moMoney.ToStrMoney(moMoney.ToNumMoney(moSummary.Data[SUM_INVOICE_AMT_COL, line_num]) - moMoney.ToNumMoney(moSummary.Data[SUM_CM_AMT_COL, line_num]));
                        moSummary.Data[SUM_NET_COMM_COL, line_num] = moMoney.ToStrMoney(moMoney.ToNumMoney(moSummary.Data[SUM_ORIGINAL_COMM_COL, line_num]) + moMoney.ToNumMoney(moSummary.Data[SUM_ADJUSTMENT_COL, line_num]));
                    }

                    cur_set.MoveNext();
                }

                cur_set.Release();

                line_num += 1;
                moSummary.Data[SUM_ADJUSTMENT_COL, line_num] = "============";
                moSummary.Data[SUM_NET_COMM_COL, line_num] = "============";

                line_num += 1;
                moSummary.Data[SUM_ADJUSTMENT_COL - 1, line_num] = moUtility.SUCase(User.Language.oString.STR_TOTAL);
                moSummary.Data[SUM_ADJUSTMENT_COL, line_num] = moMoney.ToStrMoney(amt_adjusted);
                moSummary.Data[SUM_NET_COMM_COL, line_num] = moMoney.ToStrMoney(amt_total);

                moUtility.ResizeDimPreserved(ref moSummary.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, line_num);

                FormRecreateGrid(moSummary);

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "ShowSummary");
            }

            return return_value;

        }


        public bool ShowDetail(string salesperson_code)
        {
            bool return_value = false;
            clsRecordset cur_set = new clsRecordset(ref moDatabase);
            int line_num = 0;
            int col_num = 0;
            int i = 0;
            int field_col = 0;
            clsCommission o_commmission = new clsCommission(ref moDatabase);
            string sql_str = "";
            string trx_type = "";
            string tmp = "";
            decimal amt_actual_comm = 0;
            decimal amt_invoice = 0;
            decimal amt_cm = 0;
            decimal amt_adjusted = 0;

            try
            {
                if (!o_commmission.GetSalespersonCommission(ref cur_set, salesperson_code, moGeneral.ToNumDate(Header.mskFrom_dt), moGeneral.ToNumDate(Header.mskThru_dt), Header.cboDate_typ))
                {
                    FormShowMessage();
                    return false;
                }
                else if (cur_set.EOF())
                {
                    FormShowMessage(User.Language.oMessage.NO_RECORDS_FOUND);
                    return false;
                }

                amt_actual_comm = 0;
                amt_invoice = 0;
                amt_cm = 0;
                amt_adjusted = 0;
                line_num = 0;
                moUtility.ResizeDim(ref moDetail.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, cur_set.RecordCount() + 5);

                moDetail.FieldName = cur_set.FieldName;                // Referenced in CreateHTM & CreateCSV

                for (i = 0; i < moDetail.Data.GetLength(1); i++)
                {
                    if (cur_set.EOF())
                    {
                        break;
                    }
                    moDetail.Data[DET_TRX_DATE_COL, line_num] = moGeneral.ToStrDate(cur_set.iField("iApply_dt"));
                    if (cur_set.iField("iCommission_typ") == GlobalVar.goARConstant.SALES_PERCENT_COMM_NUM)
                    {
                        trx_type = GlobalVar.goARConstant.SALES_PERCENT_COMM;
                    }
                    else if (cur_set.iField("iCommission_typ") == GlobalVar.goARConstant.PROFIT_PERCENT_COMM_NUM)
                    {
                        trx_type = GlobalVar.goARConstant.PROFIT_PERCENT_COMM;
                    }
                    else
                    {
                        trx_type = GlobalVar.goARConstant.FLAT_AMOUNT_COMM;
                    }

                    if (moDatabase.bCalcCommissionByItem_fl == false)
                    {
                        moDetail.Data[DET_COMM_TYPE_COL, line_num] = trx_type;
                    }

                    if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_INVOICE_TYPE)
                    {
                        moDetail.Data[DET_TRX_NUM_COL, line_num] = cur_set.iField("iTransaction_num").ToString();
                        moDetail.Data[DET_ACTUAL_COMM_AMT_COL, line_num] = moMoney.ToStrMoney(cur_set.mField("mActualComm_amt"));

                        if (cur_set.iField("iAdjustment_fl") == 1)
                        {
                            moDetail.Data[DET_INVOICE_AMT_COL, line_num] = moUtility.SUCase(User.Language.oCaption.ADJUSTMENT);
                            amt_adjusted += cur_set.mField("mInvoice_amt");
                        }
                        else
                        {
                            moDetail.Data[DET_INVOICE_AMT_COL, line_num] = moMoney.ToStrMoney(cur_set.mField("mInvoice_amt"));
                            amt_invoice += cur_set.mField("mInvoice_amt");
                        }

                        amt_actual_comm += cur_set.mField("mActualComm_amt");
                    }
                    else
                    {
                        moDetail.Data[DET_TRX_NUM_COL, line_num] = User.Language.oString.STR_CM + "(" + cur_set.iField("iTransaction_num") + ")";
                        moDetail.Data[DET_ACTUAL_COMM_AMT_COL, line_num] = moMoney.ToStrMoney(cur_set.mField("mActualComm_amt"));
                        moDetail.Data[DET_CM_AMT_COL, line_num] = moMoney.ToStrMoney(cur_set.mField("mInvoice_amt"));
                        amt_actual_comm += cur_set.mField("mActualComm_amt");
                        amt_cm += cur_set.mField("mInvoice_amt");
                    }

                    moDetail.Data[DET_PROFIT_AMT_COL, line_num] = moMoney.ToStrMoney(cur_set.mField("mProfit_amt"));
                    moDetail.Data[DET_COMM_AMT_COL, line_num] = moMoney.ToStrMoney(cur_set.mField("fCommission_amt"));
                    moDetail.Data[DET_USER_ID_COL, line_num] = cur_set.sField("sLastUpdate_id");
                    moDetail.Data[DET_ENTRY_DATE_COL, line_num] = moGeneral.ToStrDate(cur_set.iField("iEntry_dt"));
                    cur_set.MoveNext();
                    line_num += 1;
                }

                moDetail.Data[DET_TRX_DATE_COL, line_num] = "============";
                moDetail.Data[DET_INVOICE_AMT_COL, line_num] = "============";
                moDetail.Data[DET_CM_AMT_COL, line_num] = "============";
                moDetail.Data[DET_ACTUAL_COMM_AMT_COL, line_num] = "============";

                line_num += 1;
                moDetail.Data[DET_TRX_DATE_COL, line_num] = moUtility.SUCase(User.Language.oString.STR_TOTAL);
                moDetail.Data[DET_INVOICE_AMT_COL, line_num] = moMoney.ToStrMoney(amt_invoice);
                moDetail.Data[DET_CM_AMT_COL, line_num] = moMoney.ToStrMoney(amt_cm);
                moDetail.Data[DET_ACTUAL_COMM_AMT_COL, line_num] = moMoney.ToStrMoney(amt_actual_comm);

                moUtility.ResizeDimPreserved(ref moDetail.Data, Models.clsSpreadsheet.TOTAL_COLUMNS - 1, line_num);

                FormRecreateGrid(moDetail);

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message);
            }

            return return_value;
        }

        private bool AdjustNow()
        {

            bool return_value = false;
            int i = 0;
            int detail_id = 0;
            clsRecordset cur_set = new clsRecordset(ref moDatabase);
            int new_trx_num = 0;
            string sql_str = "";
            clsCommission o_commission = new clsCommission(ref moDatabase);
            int trx_type = 0;
            bool existing_salesperson_fl = false;

            try
            {
                // If data has changed, then check if it is ok to save.
                //
                if (FormCheck() == false)
                {
                    return false;
                }
                
                trx_type = moUtility.IIf(Header.cboTransaction_typ == User.Language.oString.STR_CREDIT_MEMO, GlobalVar.goConstant.TRX_CM_TYPE, GlobalVar.goConstant.TRX_INVOICE_TYPE);
                cur_set = new clsRecordset(ref moDatabase);

                sql_str = "SELECT * FROM tblARChargeCommUnposted WHERE iTransaction_typ = " + trx_type;
                sql_str += " AND iTransaction_num = " + moUtility.ToInteger(Header.txtAdjustInvoice_num);

                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                detail_id = cur_set.RecordCount();

                // Now create a commission adjustment record.
                //
                o_commission.InitCommission(trx_type, moUtility.ToInteger(Header.txtAdjustInvoice_num));
                o_commission.mInvoice_amt = mmInvoice_amt;
                o_commission.iStatus_typ = GlobalVar.goConstant.POSTED_TRX_NUM;
                o_commission.iApply_dt = moGeneral.ToNumDate(Header.mskEntry_dt);
                o_commission.iEntry_dt = moGeneral.CurrentDate();
                o_commission.bPaid_fl = false;
                o_commission.iPaid_dt = miPaid_dt;
                o_commission.AddCommission(Header.cboAdjustSalesrep_cd, moMoney.ToNumMoney(Header.txtAdjust_amt), Header.cboAdjustCommission_typ);

                if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (o_commission.AdjustCommission(detail_id) == false)
                {
                    FormShowMessage();
                    moDatabase.TransactionRollback();
                    return return_value;
                }
                else if (moDatabase.TransactionCommit() == false)
                {
                    FormShowMessage();
                    moDatabase.TransactionRollback();
                    return false;
                }

                cur_set.Release();
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (AdjustNow)");
                moDatabase.TransactionRollback();
            }

            return return_value;
        }

        private bool CreateHTML()
        {
            bool return_value = false;
            string html_file = "";
            string date_range = Header.mskFrom_dt + " ~ " + Header.mskThru_dt;

            try
            {
                if (moPage.iCurrentView == moView.MAIN_PAGE_NUM)
                {
                    html_file = moInquiry.CreateHTML(ref moDatabase, moPage.Title + " : " + Header.mskFrom_dt + " ~ " + Header.mskThru_dt, moSummary, SUM_TOTAL_COLUMNS, msSummaryColumnCaptions);
                }
                else if (moPage.iCurrentView == moView.DETAIL_PAGE_NUM)
                {
                    html_file = moInquiry.CreateHTML(ref moDatabase, msDetailTitle + " : " + Header.mskFrom_dt + " ~ " + Header.mskThru_dt, moDetail, DET_TOTAL_COLUMNS, msDetailColumnCaptions);
                }

                if (moUtility.IsEmpty(html_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(html_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateHTML)");
            }

            return return_value;
        }


        private bool CreateExcel()
        {
            bool return_value = false;
            string csv_file = "";
            string date_range = Header.mskFrom_dt + " ~ " + Header.mskThru_dt;
            int i;

            try
            {
                if (moPage.iCurrentView == moView.MAIN_PAGE_NUM)
                {
                    csv_file = moInquiry.CreateCSV(ref moDatabase, moPage.Title + " : " + Header.mskFrom_dt + " ~ " + Header.mskThru_dt, moSummary, SUM_TOTAL_COLUMNS, msSummaryColumnCaptions);
                }
                else if (moPage.iCurrentView == moView.DETAIL_PAGE_NUM)
                {
                    csv_file = moInquiry.CreateCSV(ref moDatabase, msDetailTitle + " : " + Header.mskFrom_dt + " ~ " + Header.mskThru_dt, moDetail, DET_TOTAL_COLUMNS, msDetailColumnCaptions);
                }

                if (moUtility.IsEmpty(csv_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(csv_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateExcel)");
            }

            return return_value;
        }

    }
}
