﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Local;
using Dynasty.Report;
using Dynasty.ASP.Models;

namespace Dynasty.ASP.Pages.AR
{
    public partial class Invoice
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<Invoice> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;                                                               
        private Models.clsListingCharge moListing;
        private Models.clsListingCharge moSearch;
        private Models.clsSpreadsheet moSpreadsheet;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);                                   // Do NOT include  || moPage.bReserved_fl);
            }
        }

        private bool ShowNavigation
        {
            get
            {
                return (moPage.iCurrentView != moView.ZOOM_PAGE_NUM && moPage.iCurrentView != moView.ORDER_PAGE_NUM && moPage.iCurrentView != moView.MATRIX_PAGE_NUM && moPage.iCurrentView != moView.PRINT_PAGE_NUM);          
            }
        }

        private bool ShowHeader
        {
            get
            {
                return ((User.IsMobile == false && (moPage.iCurrentView == moView.MAIN_PAGE_NUM || moPage.iCurrentView == moView.DETAIL_PAGE_NUM || moPage.iCurrentView == moView.PAYMENT_PAGE_NUM
                    || moPage.iCurrentView == moView.COMMISSION_PAGE_NUM || moPage.iCurrentView == moView.OPTIONS_PAGE_NUM )) 
                    || (User.IsMobile && (moPage.iCurrentView == moView.MAIN_PAGE_NUM)));
            }
        }


        private bool ShowSearchPrinter
        {
            get
            {
                return (mbSearchInitiated_fl && mbSearchPopulated_fl);
            }
        }


        private bool ShowListingPrinter
        {
            get
            {
                return (mbListingInitiated_fl && mbListingPopulated_fl);
            }
        }

        private bool InventoryBusiness
        {
            get
            {
                return (moDatabase.iCurBusiness_typ == GlobalVar.goConstant.INVENTORY_BUSINESS_NUM);
            }
        }

        private bool ValidToPrint
        {
            get
            {
                return (moUtility.ToInteger(Header.cboStatus_typ) != GlobalVar.goConstant.VOID_TRX_NUM);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // These are instantiated in FormInit().
        private clsGeneral moGeneral;                                                               
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsMoney moMoney;
        private clsBatch moBatch;

        private clsCurrency moCurrency;
        private clsInvoice moInvoice;
        private clsCustomer moCustomer;
        private clsTransactionPayment moTransactionPayment;
        private clsCommission moCommission;
        private clsJobCost moJobCost;
        private clsPaymentSchedule moPaymentSchedule;
        private clsBlanketOrder moBlanketOrder;
        private Models.clsChargeDetail moDetail;
        private Models.clsChargeDetail moMultiOrder;
        private Models.clsItemMatrix moItemMatrix;
        private Models.clsCustomField moCustomFields;
        private Models.clsSession moSession;

        private clsSerial moSerial;
        private clsSerialUtility moSerialUtility;

        private clsReportViewer moReport;
        private clsInquiry moInquiry;

        private List<Models.clsCombobox> StatusTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> JobCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> FundCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> LocationCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> TaxCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ViaCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> PriceCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> SalesrepCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> TermsCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> FOBCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> PostingCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> DunnCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> IntervalTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> RecurTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ShipToCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> PaymentTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CommissionTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> ReportTypeList = new List<Models.clsCombobox>();

        private string msDefaultRestrictionClause = "";
        private string msFund_cd = "";
        private string msHoldStatusMessage = "";

        private decimal mmPriceExchange_rt = 0;
        private decimal mmExchange_rt = 0;
        private decimal mmSaleExchange_rt = 0;

        private bool mbShowShipTo_fl = false;
        private string msOriginalTax_cd = "";
        private int miOrder_typ = 0;
        private bool mbPaymentUpdated_fl = false;
        private bool mbPaymentScheduleUpdated_fl = false;

        // miMatrixColumn counts column when matrix is populated 
        //
        private int miMatrixColumn = 0;

        // Make the invoice number editable.
        //
        public bool EnableInvoiceNumber
        {
            get
            {
                return moDatabase.uSecurity.bEditableInvoiceNumber_fl;
            }
        }

        // Hide the formatted-invoice number.
        //
        public bool HideInvoiceNumber
        {
            get { 
                return ((EnableInvoiceNumber == false) && ((Header.txtKey_id == Header.txtTransaction_num) || (Header.txtTransaction_num == ""))); 
            }
        }

        public bool EntityExist
        {
            get
            {
                return (moUtility.IsNonEmpty(Header.txtKey_id) && moUtility.IsNonEmpty(Header.txtCustomer_cd));
            }
        }

        // These are special flags to disable corresponding columns for faster entry.
        //
        public bool chkUseScanner_fl = false;
        public bool chkDisableDescription_fl = false;
        public bool chkDisableUnit_fl = false;
        public bool chkDisableQty_fl = false;
        public bool chkDisablePrice_fl = false;
        public bool chkDisableTax_fl = false;
        public bool chkDisableJob_fl = false;
        public bool chkDisableAccount_fl = false;

        // After-fact transaction
        // When this option is on, user can enter a transaction number less than the current system number.
        //
        private bool chkAfterFact_fl = false;

        // For invoice printing
        //
        private string cboReport_typ = "";
        private int optReportOption_typ = 1;            // 1 for invoice.  2 for packing slip 
        private bool chkSendEmail_fl = false;
        private string txtEmailRecipient = "";

        public bool mbMultiOrder_fl = false;
        public bool mbFromPackingSlip_fl = false;

        public int miSource_typ = 0;
        public int miSource_num = 0;

        private int miPrintDestination_typ = 0;

        // Listing options
        //
        private List<Models.clsCombobox> ListingByList = new List<Models.clsCombobox>();
        private string cboListingBy = "";
        private bool mbListingInitiated_fl = false;
        private bool mbListingPopulated_fl = false;

        // Search options
        //
        private string cboSearchYear = "";
        private bool mbSearchInitiated_fl = false;
        private bool mbSearchPopulated_fl = false;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader                   
        {
            // Listing of UI items on the header
            //
            public string txtKey_id = "";
            public string txtTransaction_num = "";
            public string cboStatus_typ = "";
            public string cboFund_cd = "";
            public string cboLocation_cd = "";

            public string txtCustomer_cd = "";
            public string txtCustomer_nm = "";
            public string txtCustomerAttn = "";
            public string txtCustomerAddress1 = "";
            public string txtCustomerAddress2 = "";
            public string txtCustomerAddress3 = "";
            public string txtYourReference = "";
            public string txtOurReference = "";
            public string txtComment = "";
            public string txtOrder_num = "";
            public string txtWeight = "";
            public string txtTotal_amt = "";
            public string txtTax_pc = "";
            public string txtNonTaxable_amt = "";
            public string txtTaxable_amt = "";
            public string txtTax_amt = "";
            public string txtDiscount_amt = "";
            public string txtFreight_amt = "";
            public string txtPaid_amt = "";
            public string txtDue_amt = "";
            public string cboRecur_typ = "";
            public string txtRecurTo_num = "";
            public string txtShipTo_cd = "";
            public string txtShipTo_nm = "";
            public string txtShipToAttn = "";
            public string txtShipToAddress1 = "";
            public string txtShipToAddress2 = "";
            public string txtShipToAddress3 = "";
            public string txtBatch_num = "0";
            public string txtPrinted_num = "0";
            public string txtFreightTax_amt = "";

            public string txtShipToCity = "";
            public string txtShipToState = "";
            public string txtShipToZipCode = "";
            public string txtShipToCountry_cd = "";
            public string txtShipToPhone = "";
            public string txtShipToFax = "";
            public string txtWebUser_id = "";
            public string txtUserApproved_cd = "";
            public string txtToApprove_num = "";

            public string txtRemaining_amt = "";

            public string cboJob_cd = "";
            public string cboTax_cd = "";
            public string cboVia_cd = "";
            public string cboPrice_cd = "";
            public string cboSalesrep_cd = "";
            public string cboTerms_cd = "";
            public string cboFOB_cd = "";
            public string cboPosting_cd = "";
            public string cboDunn_cd = "";
            public string cboShipTo_cd = "";

            public bool chkDropShipment_fl = false;
            public bool chkGiftShipment_fl = false;
            public bool chkRecur_fl = false;

            // Payment schedule
            //
            public string txtSplit_num = "";
            public string cboInterval_typ = "";
            public string mskStarting_dt = "";
            public DateTime? dtStarting_dt = null;

            // Multi-order
            //
            public string txtMultiOrder_num = "";

            // POS for Mobile
            //
            public string txtPOSItem_cd = "";

            // Matrix item
            //
            public string txtMatrixItem_cd = "";
            public string txtMatrixUnitPrice_amt = "";
            public string lblMatrixItemDescription = "";
            public string lblSystemUnitPrice_amt = "";

            // Total Qty
            //
            public string lblTotal_qty = "";

            // Datetime component is not very user-friendly, yet, as of VS2019.
            // For better understanding this, read the comment on bUseDatePicker_fl in clsUser.
            //
            public string mskEntry_dt = "";
            public string mskApply_dt = "";
            public string mskToRecur_dt = "";
            public string mskShipped_dt = "";
            public string mskRequired_dt = "";
            public string mskDue_dt = "";
            
            public DateTime? dtEntry_dt = null;
            public DateTime? dtApply_dt = null;
            public DateTime? dtToRecur_dt = null;
            public DateTime? dtShipped_dt = null;
            public DateTime? dtRequired_dt = null;
            public DateTime? dtDue_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag                                                                     
            {
                public string txtKey_id  = "";
                public string cboStatus_typ = "";
                public string cboFund_cd = "";
                public string cboLocation_cd = "";
                public string cboTax_cd = "";
                public string cboShipTo_cd = "";
                public string cboSalesrep_cd = "";
                public string txtCustomer_cd = "";
                public string txtOrder_num = "";
                public string txtFreight_amt = "";

                public string txtMultiOrder_num = "";
                public string txtPOSItem_cd = "";
                public string txtMatrixItem_cd = "";

                public string mskEntry_dt = "";
                public string mskApply_dt = "";
                public string mskToRecur_dt = "";
                public string mskShipped_dt = "";
                public string mskRequired_dt = "";
                public string mskDue_dt = "";
                public string mskStarting_dt = "";

                public DateTime? dtEntry_dt = null;
                public DateTime? dtApply_dt = null;
                public DateTime? dtToRecur_dt = null;
                public DateTime? dtShipped_dt = null;
                public DateTime? dtRequired_dt = null;
                public DateTime? dtDue_dt = null;
                public DateTime? dtStarting_dt = null;
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()                                                                  
            {
                Tag.txtKey_id = txtKey_id;
                Tag.cboStatus_typ = cboStatus_typ;
                Tag.cboFund_cd = cboFund_cd;
                Tag.cboLocation_cd = cboLocation_cd;
                Tag.cboTax_cd = cboTax_cd;
                Tag.cboShipTo_cd = cboShipTo_cd;
                Tag.cboSalesrep_cd = cboSalesrep_cd;
                Tag.txtCustomer_cd = txtCustomer_cd;
                Tag.txtOrder_num = txtOrder_num;
                Tag.txtFreight_amt = txtFreight_amt;

                Tag.txtMultiOrder_num = txtMultiOrder_num;
                Tag.txtPOSItem_cd = txtPOSItem_cd;
                Tag.txtMatrixItem_cd = txtMatrixItem_cd;

                Tag.mskEntry_dt = mskEntry_dt;
                Tag.mskApply_dt = mskApply_dt;
                Tag.mskToRecur_dt = mskToRecur_dt;
                Tag.mskShipped_dt = mskShipped_dt;
                Tag.mskRequired_dt = mskRequired_dt;
                Tag.mskDue_dt = mskDue_dt;

                Tag.dtEntry_dt = dtEntry_dt;
                Tag.dtApply_dt = dtApply_dt;
                Tag.dtToRecur_dt = dtToRecur_dt;
                Tag.dtShipped_dt = dtShipped_dt;
                Tag.dtRequired_dt = dtRequired_dt;
                Tag.dtDue_dt = dtDue_dt;

                Tag.mskStarting_dt = mskStarting_dt;
                Tag.dtStarting_dt = dtStarting_dt;

            }
        }
        private clsHeader Header = new clsHeader();

        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;                        
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            moSession.RemoveSession(moDatabase);        // Delete the session file.

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            // If user uses date-picker, we need to change the date field.
            //
            if (User.bUseDatePicker_fl && moUtility.SLeft(field_name, 3) == "msk" && moUtility.SRight(field_name, 3) == "_dt")
            {
                field_name = moUtility.SReplace(field_name, "msk", "dt");
            }
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows(int lines_to_add = 0)
        {
            if (lines_to_add <= 0)
            {
                lines_to_add = User.iLinesToIncrease;
            }

            if (moDetail.AddMoreRows(lines_to_add))
            {
                FormShowMessage();
                FormRecreateGrid();
                return false;
            }

            return true;
        }

        private bool FormCalculateCurrentRow(Models.clsChargeDetail.clsGrid cur_item)
        {
            bool return_value = false;
            int cur_row = 0;

            try
            {
                CalculateQty(cur_item);

                cur_row = cur_item.Row_num;

                // Generic line calculation has to be used:
                // All customer and vendor related charge/memo transactions should use this.
                //
                if (false == moDetail.CalculateRow(ref moDatabase, ref cur_item, ref cur_item.txtShipped_qty))
                {
                    FormShowMessage();
                    return false;
                }

                // Need to sync moDetail.Data[].
                //
                if (FormRecreateDetailLine(cur_item, cur_row) == false)
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCalculateCurrentRow)");
            }

            return return_value;
        }

        private bool FormCalculateDue()
        {
            bool return_value = false;
            decimal amt_total = 0;
            decimal amt_paid = 0;

            try
            {
                amt_paid = moMoney.ToNumMoney(Header.txtPaid_amt);
                amt_total = moDetail.CalculateSubTotal(ref moDatabase, moMoney.ToNumMoney(Header.txtTaxable_amt), moMoney.ToNumMoney(Header.txtNonTaxable_amt), moMoney.ToNumMoney(Header.txtFreight_amt), moMoney.ToNumMoney(Header.txtTax_amt), moUtility.ToValue(Header.txtTax_pc));
                Header.txtTotal_amt = moMoney.ToStrMoney(amt_total);
                Header.txtDue_amt = moMoney.ToStrMoney(amt_total - amt_paid);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "FormCalculateDue");
            }

            return return_value;
        }
        private bool FormCalculateTotal(decimal amt_tax = 0)
        {
            bool return_value = false;
            decimal amt_nontaxable = 0;
            decimal amt_taxable = 0;
            decimal amt_discount = 0;
            decimal total_wight = 0;
            decimal amt_freight_tax = 0;
            decimal amt_tax_passed = amt_tax;
            decimal total_qty = 0;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    return true; // In Search mode
                }

                amt_nontaxable = 0;
                amt_taxable = 0;
                amt_discount = 0;
                amt_freight_tax = 0;

                if (false == moGeneral.CalculateFreightTax(moMoney.ToNumMoney(Header.txtFreight_amt), moUtility.ToValue(Header.txtTax_pc), ref amt_freight_tax))
                {
                    FormShowMessage();
                    // Return return_value  ' still need to show them.
                }

                if (false == moDetail.CalculateTotals(ref moDatabase, ref amt_nontaxable, ref amt_taxable, ref amt_tax, ref amt_discount, ref total_wight, ref amt_freight_tax, false, ref total_qty))
                {
                    if (amt_tax_passed != 0)
                    {
                        FormShowMessage(User.Language.oMessage.TAX_ADJUSTMENT_FAILED_DEFAULT_IS_APPLIED);
                        amt_tax = 0; // do default calculation
                        if (false == moDetail.CalculateTotals(ref moDatabase, ref amt_nontaxable, ref amt_taxable, ref amt_tax, ref amt_discount, ref total_wight, ref amt_freight_tax, false, ref total_qty))
                        {
                            FormShowMessage();
                            // Return return_value  ' still need to show them.
                        }
                    }
                    else
                    {
                        FormShowMessage();
                        // Return return_value  ' still need to show them.
                    }
                }

                Header.txtFreightTax_amt = amt_freight_tax.ToString();
                Header.txtNonTaxable_amt = moMoney.ToStrMoney(amt_nontaxable);
                Header.txtTaxable_amt = moMoney.ToStrMoney(amt_taxable);
                Header.txtTax_amt = moMoney.ToStrMoney(amt_tax); // amt_freight_tax is included already
                Header.txtDiscount_amt = moMoney.ToStrMoney(amt_discount);
                Header.lblTotal_qty = total_qty.ToString();

                if (total_wight > 0) // Respect the value user entered
                {
                    Header.txtWeight = moUtility.RoundToQtyFactor(total_wight).ToString();
                }

                return_value = FormCalculateDue();
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCalculateTotal)");
            }

            return return_value;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {
            if (FormCheckSecurity() == false)
            {
                return false;
            }
            if (FormRecreateDetail() == false)
            {
                return false;
            }
            if (FormCheckHeader() == false)
            {
                return false;
            }

            if (moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.VOID_TRX_NUM)
            {
                return true;
            }

            if (FormCheckDetail() == false)
            {
                return false;
            }
            if (FormCheckExtra() == false)
            {
                return false;
            }

            // This transaction-specific bellow
            //
            if (CheckPaymentSchedule() == false)
            {
                return false;
            }
            if (CheckPayment() == false)
            {
                return false;
            }
            if (!moBlanketOrder.CheckForBlanketOrder(GlobalVar.goConstant.TRX_SO_TYPE, moUtility.ToInteger(Header.txtOrder_num), miOrder_typ, moPage.Original.mTotal_amt, moMoney.ToNumMoney(Header.txtTotal_amt)))
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormCheckDetail()                                                             // validate Detail for saving.
        {
            FormRecreateDetail();       // Need to make sure moDetail.Data[] has the latest.

            if (false == moDetail.CheckChargeDetail(ref moDatabase, Header.cboLocation_cd, moUtility.ToValue(Header.txtTax_pc)))
            {
                FormShowMessage();
                return false;
            }

            return true;
        }


        private bool FormCheckExtra()                                                              // validate extra other than the header and detail.
        {
            bool return_value = false;
            decimal total_amt = 0;
            string entity_code = "";
            int row_num = 0;
            string salesrep_code = "";
            int commission_type = 0;
            decimal commission_amt = 0;

            try
            {
                CalculatePayment();                 // Necessary to check here again.
                CalculatePaymentSchedule(); 

                Header.txtTransaction_num = moUtility.EvalQuote(Header.txtTransaction_num);

                if (moDatabase.uSecurity.bEditableInvoiceNumber_fl)
                {

                    if (moUtility.IsEmpty(Header.txtTransaction_num))
                    {
                        FormShowMessage(User.Language.oMessage.ENTER_INVOICE_NUM_FIRST);
                        return false;
                    }

                    // Since user edits the invoice number, we need to make sure the number is unique for the customer.
                    //
                    if (moValidate.IsValidCustomerInvoice(Header.txtCustomer_cd, Header.txtTransaction_num))
                    {
                        if (moValidate.oRecordset.iField("iTransaction_num") != moUtility.ToInteger(Header.txtKey_id))
                        {
                            FormShowMessage(User.Language.oString.STR_INVOICE_NUM + ", " + Header.txtTransaction_num + "," + User.Language.oMessage.IS_USED_BY + User.Language.oString.STR_INVOICE + "(" + moValidate.oRecordset.iField("iTransaction_num").ToString() + ").");
                            return false;
                        }
                    }

                    moValidate.Release();

                }
                else if (moUtility.IsEmpty(Header.txtTransaction_num) || moPage.bNew_fl)
                {

                    if (moDatabase.uSecurity.bInvoiceNumberingByJob_fl)
                    {
                        entity_code = Header.cboJob_cd;
                    }
                    else if (moDatabase.uSecurity.bInvoiceNumberingByCustomer_fl)
                    {
                        entity_code = Header.txtCustomer_cd;
                    }
                    else
                    {
                        entity_code = "";
                    }

                    Header.txtTransaction_num = moGeneral.GetFormatedDocumentNumber(moPage.iTransaction_typ, Header.txtKey_id, entity_code);

                }

                if (moCustomer.iBalance_typ == GlobalVar.goARConstant.CASH_CUSTOMER_NUM && moMoney.ToNumMoney(Header.txtDue_amt) >= moDatabase.mSmallestMoney_amt)
                {
                    FormShowMessage(User.Language.oMessage.CASH_CUST_SHOULD_PAY_OFF);
                    return false;
                    //ElseIf (moMoney.ToNumMoney(Header.txtDue_amt) < 0.0#) Then       06/19/2018 Negative vouchers/Invoices - we allow Negative vouchers/Invoices from now on.
                }
                else if ((moMoney.ToNumMoney(Header.txtDue_amt) < 0) && (moMoney.ToNumMoney(Header.txtPaid_amt) >= moDatabase.mSmallestMoney_amt)) // Negative is not allowed only when there is a payment, which means over-payment
                {
                    FormShowMessage(User.Language.oMessage.AMOUNT_DUE_CANNOT_BE_NEGATIVE);
                    return false;
                }

                // Check if the credit limit should be checked against this customer.
                // Let the global Function handles it because the level of checking should
                // be done globally.
                //
                if (moCustomer.iCheckCrLimit_fl == GlobalVar.goConstant.FLAG_ON && moMoney.ToNumMoney(Header.txtDue_amt) >= moDatabase.mSmallestMoney_amt)
                {
                    if (moGeneral.CheckCreditLimit(moMoney.ToNumMoney(Header.txtDue_amt), moCustomer.mCreditLimit_amt + moCustomer.mDeposit_amt - moCustomer.mBalanceDue_amt) == false)
                    {
                        if (FormDialog(btnSave_Clicked, 1000, User.Language.oMessage.AMOUNT_EXCEEDS_CREDIT_LINE + User.Language.oMessage.WOULD_LIKE_PROCEED) == false)
                        {
                            return false;
                        }
                    }
                }

                // Recurring information.
                //
                if (Header.chkRecur_fl)
                {
                    if (moUtility.IsBlankDate(Header.mskToRecur_dt) && moUtility.ToInteger(Header.txtRecurTo_num) == 0)
                    {
                        FormShowMessage(User.Language.oMessage.PLEASE_CHOOSE_EITHER_EXPIRATION_DATE_OR_TOTAL_NUMBER_OF_RECURRING);
                        return false;
                    }
                    else if (!moUtility.IsBlankDate(Header.mskToRecur_dt) && moUtility.ToInteger(Header.txtRecurTo_num) > 0)
                    {
                        FormShowMessage(User.Language.oMessage.PLEASE_CHOOSE_EITHER_EXPIRATION_DATE_OR_TOTAL_NUMBER_OF_RECURRING);
                        return false;
                    }
                    else if (moUtility.ToInteger(Header.cboRecur_typ) == 0)
                    {
                        FormShowMessage(User.Language.oMessage.PLEASE_SELECT_RECURRING_TYPE);
                        return false;
                    }

                    for (row_num = 0; row_num < moDetail.Data.GetLength(1); row_num++)
                    {
                        if (moUtility.IsNonEmpty(moDetail.Data[Models.clsChargeDetail.ITEM_CODE_COL, row_num]))
                        {
                            if (moUtility.IsInventoryItemType(moUtility.ToInteger(moDetail.Data[Models.clsChargeDetail.ITEM_TYPE_COL, row_num])))
                            {
                                FormShowMessage(User.Language.oMessage.INVENTORY_ITEM_NOT_ALLOWED_FOR_THIS_TRANSACTION);
                                return false;
                            }
                        }
                    }
                }
                else
                {
                    Header.mskToRecur_dt = moUtility.GetEmptyMaskedDate();
                    Header.txtRecurTo_num = "";
                    Header.cboRecur_typ = "";
                }

                if (moCommission.CheckCommission() == false)
                {
                    FormShowMessage();
                    return false;
                }

                // Custom fields
                //
                if (moCustomFields.CheckValues(moDatabase) == false)
                {
                    FormShowMessage(moCustomFields.GetErrorMessage());
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckExtra)");
            }

            return return_value;
        }

        private bool FormCheckHeader()                                                             // validate the header data.
        {
            bool return_value = false;

            try
            {
                // GENERIC VALIDATIONS FOR ALL TRASNACTIONS
                //
                msFund_cd = GlobalVar.goFund.GetSelectedFundCodeToSave(ref moDatabase, Header.cboFund_cd);
                FormSyncDates(User.bUseDatePicker_fl);

                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormShowMessage(User.Language.oString.STR_TRANSACTION_NUMBER + @User.Language.oMessage.IS_REQUIRED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("txtKey_id");
                    return false;
                }
                if (moDatabase.bFundAccounting_fl && moUtility.IsEmpty(msFund_cd))
                {
                    FormShowMessage(User.Language.oCaption.FUND_CODE + User.Language.oMessage.IS_REQUIRED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboFund_cd");
                    return false;
                }
                if (moUtility.ToInteger(Header.cboStatus_typ) == 0)
                {
                    FormShowMessage(User.Language.oMessage.STATUS_HAS_TO_BE_SELECTED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboStatus_typ");
                    return false;
                }
                if (moUtility.IsBlankDate(Header.mskEntry_dt))
                {
                    FormShowMessage(User.Language.oMessage.ENTRY_DATE_IS_REQUIRED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("mskEntry_dt");
                    return false;
                }
                if (modCommonUtility.ValidEntryDate(ref moDatabase, ref Header.mskEntry_dt) == false)
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_A_VALID_DATE_ENTERED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("mskEntry_dt");
                    return false;
                }
                if (moUtility.ToInteger(Header.cboStatus_typ) != GlobalVar.goConstant.OPEN_TRX_NUM)
                {
                    if (moUtility.IsBlankDate(Header.mskApply_dt))
                    {
                        Header.mskApply_dt = Header.mskEntry_dt;
                        FormSyncDates(false);
                    }
                    return true;
                }

                if (moUtility.IsBlankDate(Header.mskApply_dt))
                {
                    FormShowMessage(User.Language.oCaption.APPLY_DATE + User.Language.oMessage.IS_REQUIRED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("mskApply_dt");
                    return false;
                }
                if (modCommonUtility.ValidApplyDate(ref moDatabase, ref Header.mskApply_dt) == false)
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_A_VALID_DATE_APPLIED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("mskApply_dt");
                    return false;
                }
                if (moUtility.IsBlankDate(Header.mskRequired_dt))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_DATE_REQUIRED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("mskRequired_dt");
                    return false;
                }
                if (moUtility.IsBlankDate(Header.mskShipped_dt))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_DATE_SHIPPED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("mskShipped_dt");
                    return false;
                }
                if (moUtility.IsEmpty(Header.cboPosting_cd))
                {
                    FormShowMessage(User.Language.oMessage.POSTING_CODE_IS_REQUIRED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboPosting_cd");
                    return false;
                }
                if (moUtility.IsEmpty(Header.cboTerms_cd))
                {
                    FormShowMessage(User.Language.oMessage.TERMS_CODE_IS_REQUIRED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboTerms_cd");
                    return false;
                }
                if (moUtility.IsEmpty(Header.cboLocation_cd))
                {
                    FormShowMessage(User.Language.oMessage.LOCATION_CODE_IS_REQUIRED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboLocation_cd");
                    return false;
                }
                if (moUtility.IsEmpty(Header.txtCustomer_cd))
                {
                    FormShowMessage(User.Language.oMessage.CUSTOMER_CODE_IS_REQUIRED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("txtCustomer_cd");
                    return false;
                }
                if (moCustomer.GetCustomer(Header.txtCustomer_cd, true) == false)
                {
                    FormShowMessage(Header.txtCustomer_cd + User.Language.oMessage.IS_INVALID);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("txtCustomer_cd");
                    return false;
                }
                if (moUtility.IsEmpty(Header.txtShipTo_nm))
                {
                    FormShowMessage(User.Language.oMessage.SHIP_TO_NAME_IS_REQUIRED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("txtShipTo_nm");
                    return false;
                }
                if (moDatabase.uSecurity.bInvoiceNumberingByJob_fl && moUtility.IsEmpty(Header.cboJob_cd))
                {
                    FormShowMessage(User.Language.oString.STR_JOB + User.Language.oMessage.IS_REQUIRED);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    FormSetFocus("cboJob_cd");
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckHeader)");
            }

            return return_value;
        }

        private bool FormCheckConcurrency(clsRecordset cur_set, bool from_printing_fl)                                    // Check if someone has changed this record while it is open in this session.
        {
            if (cur_set.IsNonEmpty()) 
            {
                if (moPage.bNew_fl)
                {
                    // Let it go.  FormPreSave() will take care of this case.
                }
                else if (moPage.CheckForConcurrency(cur_set) == false)
                {
                    // If someone has updated this record in the meantime.
                    //
                    if (from_printing_fl)
                    {
                        if (FormDialog(cmdOKOnPrint_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                        {
                            return false;
                        }
                    }
                    else
                    {
                        if (FormDialog(btnSave_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED + (char)(modvbConstant.KEY_RETURN) + User.Language.oMessage.WOULD_LIKE_TO_OVERRIDE) == false)
                        {
                            return false;
                        }
                    }
                }
            }
            else if (moPage.bNew_fl == false)
            {
                // If current record is missing, it could have been posted by someone.
                // Need to make sure it does not exist in the posted table.
                //
                if (moValidate.IsValidTransaction(moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id), false))
                {
                    FormShowMessage(User.Language.oMessage.THIS_TRX_EXISTS_AND_HAS_BEEN_POSTED_ALREADY);
                    return false;
                }
            }

            return true;
        }

        private bool FormCheckToDelete()
        {
            clsIntegrity o_integrity = new clsIntegrity(ref moDatabase);

            if (FormCheckSecurity() == false)
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }
            else if (modFormUtility.IsReservedRecord(ref moDatabase, Header.txtKey_id, moPage.bReserved_fl))
            {
                FormShowMessage(User.Language.oMessage.RESERVED_RECORD_IS_NOT_ALLOWED_TO_DELETE);
                return false;
            }
            else if (o_integrity.IsReferenced(moPage.sModule_id, moPage.sKeyField_nm, Header.txtKey_id))
            {
                FormShowMessage(User.Language.oMessage.CANNOT_DELETE_THIS_REC);
                return false;
            }

            return true;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearDetail();
            FormClearExtra();

            return true;
        }

        private bool FormClearDetail()                                                             // Clear the detail.
        {
            moDetail.iNextLine_id = 1;
            moDetail.iTotalRows = User.iLinesToIncrease;
            moUtility.ResizeDim(ref moDetail.Data, Models.clsChargeDetail.TOTAL_COLUMNS - 1, moDetail.iTotalRows - 1);
            
            return FormRecreateGrid();
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            Header.txtRemaining_amt = "";

            mmPriceExchange_rt = 0;
            mmExchange_rt = 0;
            mmSaleExchange_rt = 0;

            msFund_cd = "";
            msHoldStatusMessage = "";

            msOriginalTax_cd = "";
            miOrder_typ = 0;
            mbShowShipTo_fl = false;
            mbPaymentUpdated_fl = false;
            mbPaymentScheduleUpdated_fl = false;

            miSource_typ = 0;
            miSource_num = 0;

            chkSendEmail_fl = false;
            txtEmailRecipient = "";

            JobCodeList.Clear();            // Job is customer-dependant

            moTransactionPayment = new clsTransactionPayment(ref moDatabase);

            moCommission.CreateGrid();
            moJobCost.Grid.Clear();
            moPaymentSchedule.CreateGrid();
            
            //  DO NOT USE. cmdMultiOrderClear_Clicked();
            Header.txtMultiOrder_num = "";
            moMultiOrder.Grid.Clear();

            // Custom Fields
            //
            moCustomFields.ClearGrid();

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {
            Header.txtKey_id = "";
            Header.cboFund_cd = "";
            Header.cboStatus_typ = "";
            Header.cboLocation_cd = "";
            Header.txtComment = "";

            Header.txtCustomer_cd = "";
            Header.txtCustomer_nm = "";
            Header.txtCustomerAttn = "";
            Header.txtCustomerAddress1 = "";
            Header.txtCustomerAddress2 = "";
            Header.txtCustomerAddress3 = "";
            Header.txtYourReference = "";
            Header.txtOurReference = "";
            Header.txtComment = "";
            Header.txtOrder_num = "";
            Header.txtWeight = "";
            Header.txtTotal_amt = "";
            Header.txtTax_pc = "";
            Header.txtNonTaxable_amt = "";
            Header.txtTaxable_amt = "";
            Header.txtTax_amt = "";
            Header.txtDiscount_amt = "";
            Header.txtFreight_amt = "";
            Header.txtPaid_amt = "";
            Header.txtDue_amt = "";
            Header.txtRecurTo_num = "";
            Header.txtShipTo_cd = "";
            Header.txtShipTo_nm = "";
            Header.txtShipToAttn = "";
            Header.txtShipToAddress1 = "";
            Header.txtShipToAddress2 = "";
            Header.txtShipToAddress3 = "";
            Header.txtTransaction_num = "";
            Header.txtBatch_num = "0";
            Header.txtPrinted_num = "0";
            Header.txtFreightTax_amt = "";
            mbMultiOrder_fl = false;
            mbFromPackingSlip_fl = false;

            Header.txtShipToCity = "";
            Header.txtShipToState = "";
            Header.txtShipToZipCode = "";
            Header.txtShipToCountry_cd = "";
            Header.txtShipToPhone = "";
            Header.txtShipToFax = "";
            Header.txtWebUser_id = "";
            Header.txtUserApproved_cd = "";
            Header.txtToApprove_num = "";

            Header.cboJob_cd = "";
            Header.cboTax_cd = "";
            Header.cboVia_cd = "";
            Header.cboPrice_cd = "";
            Header.cboTerms_cd = "";
            Header.cboFOB_cd = "";
            Header.cboPosting_cd = "";
            Header.cboDunn_cd = "";
            Header.cboRecur_typ = "";
            Header.cboShipTo_cd = "";

            // Sales rep sees his own customers only.
            //
            if (moUtility.IsSalesStaff(moDatabase))
            {
                Header.cboSalesrep_cd = moDatabase.sUser_cd;
            }
            else
            {
                Header.cboSalesrep_cd = "";
            }

            Header.chkDropShipment_fl = false;
            Header.chkGiftShipment_fl = false;
            Header.chkRecur_fl = false;

            Header.txtSplit_num = "";
            Header.cboInterval_typ = "";

            Header.lblTotal_qty = "";

            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            //
            Header.mskEntry_dt = "";
            Header.mskApply_dt = "";
            Header.mskToRecur_dt = "";
            Header.mskShipped_dt = "";
            Header.mskRequired_dt = "";
            Header.mskDue_dt = "";
            Header.mskStarting_dt = "";
            FormSyncDates(false);

            return true;
        }

        private bool FormClearMessage()                                                            
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            moPage.bInDialog_fl = true;         // Meaning a dialog started

            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    moPage.bInDialog_fl = false;            // Meaning a dialog is enidng with Cancel button
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }

                Modal.Release();                                                                   // Release this call and proceed.
            }

            moPage.bInDialog_fl = false;            // Meaning a dialog is enidng with Cancel button
            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id) || moPage.bNew_fl)
                {
                    FormClear();
                    return true;
                }
                else if (FormCheckToDelete() == false)
                {
                    return false;
                }

                // Transaction begins here.
                //
                if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }

                if (modFormUtility.RecordDelete(ref moDatabase, moPage.iScreen_typ, Header.txtKey_id, moPage.sKeyField_nm, moPage.sTable_nm, moPage.sDetailTable_nm, moPage.sRestrictionClause, moPage.iTransaction_typ) == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }
                else if (FormDeleteExtra() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }

                // Transaction ends here.
                //
                if (moDatabase.TransactionCommit() == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDelete)");
                moDatabase.TransactionRollback();
                return_value = false;
            }

            return return_value;
        }

        private bool FormDeleteExtra()
        {

            return true;
        }

        private bool FormDeleteCurrentRow(Models.clsChargeDetail.clsGrid cur_item)
        {
            bool return_value = false;
            int old_num = cur_item.Row_num;

            try
            {
                if (moDetail.DeleteCurrentRow(cur_item) == false)
                {
                    FormShowMessage();
                    FormRecreateGrid();
                    return false;
                }
                if (FormCalculateTotal() == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDeleteCurrentRow)");
                FormRecreateGrid();
            }

            return return_value;
        }

        private bool FormEnableBatch(bool switch_fl = true)
        {

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (switch_fl)
            {
                moBatch.ToggleBatch(ref moDatabase);
            }

            User.bBatchEnabled_fl = moDatabase.AllowBatchEntry();
            User.iBatch_num = moDatabase.CurrentBatch;

            moBatch.ShowBatch(moDatabase);

            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormFindRecord(ref clsRecordset cur_set, int matching_type = 0)
        {
            bool return_value = false;

            matching_type = (int)(moUtility.IIf(matching_type > 0, matching_type, GlobalVar.goConstant.MATCHING_RECORD_TYPE));
            return_value = modFormUtility.RecordRead(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sTable_nm, moPage.sKeyField_nm, moPage.sPreviousKey_id, moPage.sRestrictionClause, ref matching_type);

            return return_value;
        }


        public bool FormCheckExchangeRate(int apply_date = 0)
        {
            bool return_value = false;
            decimal old_exchange_rate = mmSaleExchange_rt; // DO NOT change to Double because of comparison issue
            decimal old_price_exchange_rate = mmPriceExchange_rt;

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                mmSaleExchange_rt = 1;
                mmPriceExchange_rt = 1;
                return return_value;
            }
            else if (moUtility.IsEmpty(Header.mskApply_dt) && apply_date == 0)
            {
                mmSaleExchange_rt = 1;
                mmPriceExchange_rt = 1;
                return return_value;
            }

            if (apply_date == 0)
            {
                apply_date = moGeneral.ToNumDate(Header.mskApply_dt);
            }
            if (apply_date == 0)
            {
                apply_date = moGeneral.CurrentDate();
            }

            moCurrency.GetSaleExchangeRate(moDatabase.sCurrency_cd, ref mmSaleExchange_rt, ref mmPriceExchange_rt, apply_date);

            if ((old_exchange_rate != mmSaleExchange_rt) || (old_price_exchange_rate != mmPriceExchange_rt))
            {
                return_value = true;
            }

            return return_value;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListingCharge();
            moSpreadsheet = new Models.clsSpreadsheet();
            moSearch = new Models.clsListingCharge();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moMoney = new clsMoney(ref moDatabase);
            moBatch = new clsBatch();
            moSession = new Models.clsSession();

            moCurrency = new clsCurrency(ref moDatabase);
            moInvoice = new clsInvoice(ref moDatabase);
            moCustomer = new clsCustomer(ref moDatabase);
            moTransactionPayment = new clsTransactionPayment(ref moDatabase);
            moCommission = new clsCommission(ref moDatabase);
            moJobCost = new clsJobCost(ref moDatabase);
            moPaymentSchedule = new clsPaymentSchedule();
            moBlanketOrder = new clsBlanketOrder(ref moDatabase);
            moDetail = new Models.clsChargeDetail(GlobalVar.goConstant.TRX_INVOICE_TYPE);
            moMultiOrder = new Models.clsChargeDetail(GlobalVar.goConstant.TRX_SO_TYPE);
            moItemMatrix = new Models.clsItemMatrix();
            moCustomFields = new Models.clsCustomField() ;

            moSerial = new clsSerial(ref moDatabase);
            moSerialUtility = new clsSerialUtility();

            moReport = new clsReportViewer();
            moInquiry = new clsInquiry();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.ARMENU_NAME;
            moPage.Title = User.Language.oCaption.INVOICE_ENTRY;
            moPage.iScreen_typ = GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE;
            moPage.iTransaction_typ = GlobalVar.goConstant.TRX_INVOICE_TYPE;
            moPage.iJournal_typ = 0;

            miPrintDestination_typ = GlobalVar.goConstant.PRINT_TO_PDF;

            // sRestrictionClause will need to change as some conditions change, which is done in ResetRestrictionClause().
            // moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);
            msDefaultRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);
            ResetRestrictionClause();

            Modal.Release();
            Lock.Clear();

            FormInitHeader();
            FormInitDetail();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitDetail()                                                              // Initialize the page at loading.  Only once.
        {
            // Detail table name.
            //
            moPage.sDetailTable_nm = "tblARChargeDetUnposted";

            moUtility.ResizeDim(ref moDetail.Data, Models.clsChargeDetail.TOTAL_COLUMNS - 1, 0);    // These initializations are necessary
            moUtility.ResizeDim(ref moDetail.FieldName, Models.clsChargeDetail.TOTAL_COLUMNS - 1);  // Models.clsChargeDetail.TOTAL_COLUMNS should be large enough to cover all transactions

            moDetail.FieldName[Models.clsChargeDetail.ITEM_CODE_COL] = moInvoice.sDetailFieldNames[clsInvoice.ITEM_CODE_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.LOCATION_COL] = moInvoice.sDetailFieldNames[clsInvoice.LOCATION_COL]; 

            moDetail.FieldName[Models.clsChargeDetail.ITEM_MANUFACTURER_COL] = moInvoice.sDetailFieldNames[clsInvoice.ITEM_MANUFACTURER_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.ITEM_BRAND_COL] = moInvoice.sDetailFieldNames[clsInvoice.ITEM_BRAND_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.ITEM_MODEL_COL] = moInvoice.sDetailFieldNames[clsInvoice.ITEM_MODEL_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.ITEM_STYLE_COL] = moInvoice.sDetailFieldNames[clsInvoice.ITEM_STYLE_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.ITEM_COLOR_COL] = moInvoice.sDetailFieldNames[clsInvoice.ITEM_COLOR_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.ITEM_SIZE_COL] = moInvoice.sDetailFieldNames[clsInvoice.ITEM_SIZE_COL]; 

            moDetail.FieldName[Models.clsChargeDetail.DESCRIPTION_COL] = moInvoice.sDetailFieldNames[clsInvoice.DESCRIPTION_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.UNIT_CODE_COL] = moInvoice.sDetailFieldNames[clsInvoice.UNIT_CODE_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.QTY_SHIPPED_COL] = moInvoice.sDetailFieldNames[clsInvoice.QTY_SHIPPED_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.QTY_ORDERED_COL] = moInvoice.sDetailFieldNames[clsInvoice.QTY_ORDERED_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.QTY_BACKORDER_COL] = moInvoice.sDetailFieldNames[clsInvoice.QTY_BACKORDER_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.UNIT_PRICE_COL] = moInvoice.sDetailFieldNames[clsInvoice.UNIT_PRICE_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.AMT_EXTENDED_COL] = moInvoice.sDetailFieldNames[clsInvoice.AMT_EXTENDED_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.DISC_PERC_COL] = moInvoice.sDetailFieldNames[clsInvoice.DISC_PERC_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.TAX_CODE_COL] = moInvoice.sDetailFieldNames[clsInvoice.TAX_CODE_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.FULL_ACCT_CODE_COL] = moInvoice.sDetailFieldNames[clsInvoice.FULL_ACCT_CODE_COL]; 

            moDetail.FieldName[Models.clsChargeDetail.NATURAL_ACCT_CODE_COL] = moInvoice.sDetailFieldNames[clsInvoice.NATURAL_ACCT_CODE_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.SEGMENT1_COL] = moInvoice.sDetailFieldNames[clsInvoice.SEGMENT1_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.SEGMENT2_COL] = moInvoice.sDetailFieldNames[clsInvoice.SEGMENT2_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.SEGMENT3_COL] = moInvoice.sDetailFieldNames[clsInvoice.SEGMENT3_COL]; 
            moDetail.FieldName[Models.clsChargeDetail.SEGMENT4_COL] = moInvoice.sDetailFieldNames[clsInvoice.SEGMENT4_COL];  
            moDetail.FieldName[Models.clsChargeDetail.SEGMENT5_COL] = moInvoice.sDetailFieldNames[clsInvoice.SEGMENT5_COL];  
            moDetail.FieldName[Models.clsChargeDetail.SEGMENT6_COL] = moInvoice.sDetailFieldNames[clsInvoice.SEGMENT6_COL];  

            moDetail.FieldName[Models.clsChargeDetail.AMT_TAX_COL] = moInvoice.sDetailFieldNames[clsInvoice.AMT_TAX_COL];  
            moDetail.FieldName[Models.clsChargeDetail.TAX_PERC_COL] = moInvoice.sDetailFieldNames[clsInvoice.TAX_PERC_COL];  
            moDetail.FieldName[Models.clsChargeDetail.QTY_IN_IVUNIT_COL] = moInvoice.sDetailFieldNames[clsInvoice.QTY_IN_IVUNIT_COL];  
            moDetail.FieldName[Models.clsChargeDetail.IVUNIT_CODE_COL] = moInvoice.sDetailFieldNames[clsInvoice.IVUNIT_CODE_COL];  
            moDetail.FieldName[Models.clsChargeDetail.TOTAL_COST_COL] = moInvoice.sDetailFieldNames[clsInvoice.TOTAL_COST_COL];  
            moDetail.FieldName[Models.clsChargeDetail.ITEM_TYPE_COL] = moInvoice.sDetailFieldNames[clsInvoice.ITEM_TYPE_COL];  
            moDetail.FieldName[Models.clsChargeDetail.AMT_DISC_COL] = moInvoice.sDetailFieldNames[clsInvoice.AMT_DISC_COL];  
            moDetail.FieldName[Models.clsChargeDetail.CONVERSION_RATE_COL] = moInvoice.sDetailFieldNames[clsInvoice.CONVERSION_RATE_COL];  
            moDetail.FieldName[Models.clsChargeDetail.SELL_UNIT_CODE_COL] = moInvoice.sDetailFieldNames[clsInvoice.SELL_UNIT_CODE_COL];  
            moDetail.FieldName[Models.clsChargeDetail.SELL_UNIT_PRICE_COL] = moInvoice.sDetailFieldNames[clsInvoice.SELL_UNIT_PRICE_COL];  
            moDetail.FieldName[Models.clsChargeDetail.LINE_ID_COL] = moInvoice.sDetailFieldNames[clsInvoice.LINE_ID_COL];  
            moDetail.FieldName[Models.clsChargeDetail.KIT_ID_COL] = moInvoice.sDetailFieldNames[clsInvoice.KIT_ID_COL];  
            moDetail.FieldName[Models.clsChargeDetail.WEIGHT_PER_UNIT_COL] = moInvoice.sDetailFieldNames[clsInvoice.WEIGHT_PER_UNIT_COL];  
            moDetail.FieldName[Models.clsChargeDetail.FREIGHT_PER_UNIT_COL] = moInvoice.sDetailFieldNames[clsInvoice.FREIGHT_PER_UNIT_COL];  
            moDetail.FieldName[Models.clsChargeDetail.EXPENSE_TYPE_COL] = moInvoice.sDetailFieldNames[clsInvoice.EXPENSE_TYPE_COL];  
            moDetail.FieldName[Models.clsChargeDetail.EXPENSE_NUM_COL] = moInvoice.sDetailFieldNames[clsInvoice.EXPENSE_NUM_COL];  
            moDetail.FieldName[Models.clsChargeDetail.EXPENSE_DETAIL_COL] = moInvoice.sDetailFieldNames[clsInvoice.EXPENSE_DETAIL_COL];  
            moDetail.FieldName[Models.clsChargeDetail.PRIMARY_ITEM_CODE_COL] = moInvoice.sDetailFieldNames[clsInvoice.PRIMARY_ITEM_CODE_COL];  
            moDetail.FieldName[Models.clsChargeDetail.JOB_CODE_COL] = moInvoice.sDetailFieldNames[clsInvoice.JOB_CODE_COL];  
            moDetail.FieldName[Models.clsChargeDetail.ORDER_NUM_COL] = moInvoice.sDetailFieldNames[clsInvoice.ORDER_NUM_COL];  
            moDetail.FieldName[Models.clsChargeDetail.LINE_TYPE_COL] = moInvoice.sDetailFieldNames[clsInvoice.LINE_TYPE_COL];
            moDetail.FieldName[Models.clsChargeDetail.SOURCE_DETAIL_ID_COL] = moInvoice.sDetailFieldNames[clsInvoice.SOURCE_DETAIL_ID_COL];

            FormClearDetail();

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = "tblARChargeUnposted"; 
            moPage.sKeyField_nm = "itransaction_num";

            return true;
        }

        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {

            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            // FormSave() & FormCheck() use the plain textbox whose name starts with "msk"
            // dt* variables are only to interact with UI.  Internally, msk* fields are used.
            //
            FormSyncDates(User.bUseDatePicker_fl);


            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback
            
            return true;
        }

        private bool FormInsertNewRow(Models.clsChargeDetail.clsGrid cur_item)
        {
            bool return_value = false;
            int old_num = cur_item.Row_num;

            try
            {
                if (moDetail.InsertNewRow(cur_item) == false)
                {
                    FormShowMessage();
                    FormRecreateGrid();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormInsertNewRow)");
                FormRecreateGrid();
            }

            return return_value;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;
            clsCustomization custom_fields = new clsCustomization(ref moDatabase);

            try
            {
                if (FormReceiveValues() == false)                    // All pages that use session value need to capture it here before FormOpenDatabase()
                {
                    return false;
                }
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                modLoadUtility.LoadLocationCode(ref moDatabase, ref LocationCodeList);
                modLoadUtility.LoadStatusType(ref moDatabase, ref StatusTypeList);
                modLoadUtility.LoadJobCode(ref moDatabase, ref JobCodeList);
                modLoadUtility.LoadFundCode(ref moDatabase, ref FundCodeList, moGeneral.CurrentDate(), GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE); // Need to load fund whether it is fund accouning or not
                modLoadUtility.LoadRecurringType(ref moDatabase, ref RecurTypeList);
                modLoadUtility.LoadARDunnCode(ref moDatabase, ref DunnCodeList);
                modLoadUtility.LoadARTaxCode(ref moDatabase, ref TaxCodeList);
                modLoadUtility.LoadViaCode(ref moDatabase, ref ViaCodeList);
                modLoadUtility.LoadARPriceCode(ref moDatabase, ref PriceCodeList);
                modLoadUtility.LoadSalespersonCode(ref moDatabase, ref SalesrepCodeList);
                modLoadUtility.LoadARTermsCode(ref moDatabase, ref TermsCodeList);
                modLoadUtility.LoadARPostingCode(ref moDatabase, ref PostingCodeList);
                modLoadUtility.LoadFOB(ref moDatabase, ref FOBCodeList);
                modLoadUtility.LoadSplitPaymentFrequency(ref IntervalTypeList);
                modLoadUtility.LoadPaymentType(ref moDatabase, ref PaymentTypeList, false, true, true, false, true, true);
                modLoadUtility.LoadCommissionType(ref moDatabase, ref CommissionTypeList);
                modLoadUtility.LoadInvoiceType(ref moDatabase, ref ReportTypeList);

                modLoadUtility.LoadListingBy(ref moDatabase, ref ListingByList, moPage.iTransaction_typ, User);

                if (moDatabase.uSecurity.bUseMatrixForm_fl)
                {
                    cboReport_typ = Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LC1_NUM);
                }

                // Sales rep sees his own customers only.
                //
                if (moUtility.IsSalesStaff(moDatabase))
                {
                    Header.cboSalesrep_cd = moDatabase.sUser_cd;
                }

                FormEnableBatch(false);

                ResetRestrictionClause();                                       // Has to set here after database connection.

                chkDisableDescription_fl = User.bDisableDescription_fl;
                chkDisableQty_fl = User.bDisableQuantity_fl;
                chkDisableUnit_fl = User.bDisableUnitCode_fl;
                chkDisablePrice_fl = User.bDisableUnitPrice_fl;

                // Custom Fields
                //
                if (custom_fields.ReadCustomInfo(moPage.iTransaction_typ, ""))
                {
                    moCustomFields.CreateGrid(custom_fields.sField_nm, custom_fields.sCaptions, custom_fields.bRequired);
                }

                if (moUtility.IsNonEmpty(moPage.sInitialKey_id))
                {
                    Header.txtKey_id = moPage.sInitialKey_id;
                    txtKey_id_Changed();
                }

                User.bConnected_fl = true;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormMove(int record_move_direction)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormClear();

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            if (FormFindRecord(ref cur_set, record_move_direction) == false)
            {
                return false;
            }

            FormShow(cur_set);
            return true;

        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostSave()
        {
            // If this is a transaction page, and transaction number has changed, let the user know.
            //
            if (moPage.sPreviousKey_id != Header.txtKey_id)
            {
                FormShowMessage(User.Language.oMessage.TRX_NUM_HAS_CHANGED_TO + "  " + Header.txtKey_id, false);
            }

            moPage.sPreviousKey_id = Header.txtKey_id;

            return true;
        }

        private bool FormPostTransactionRealtime()
        {
            int number_failed = 0;
            string posting_error = "";

            if (moDatabase.bRealTimeMode == false || moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.HOLD_TRX_NUM)
            {
                return true;
            }

            if (moGeneral.ApplyDateIsOkToPost(moGeneral.ToNumDate(Header.mskApply_dt), false) == false)
            {
                FormShowMessage(Header.mskApply_dt + User.Language.oMessage.IS_INVALID_FOR_POSTING);
                return false;
            }

            if (modPostUtility.PostOneTransaction(ref moDatabase, 0, 0, moGeneral.ToNumDate(Header.mskApply_dt), moGeneral.ToNumDate(Header.mskApply_dt)
                                , moUtility.ToInteger(Header.txtKey_id), moUtility.ToInteger(Header.txtKey_id), moPage.iTransaction_typ, posting_error, false, ref number_failed) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {
            // Put some extra validation against the existing record
            // before saving the current modification.
            //
            
            if (chkAfterFact_fl)
            {
                // A.f.t. transactions should have a number non-existing number less than the current transaction number in the system.
                // Duplicate entry will be checked in clsInvoice.
                //
                if (moPage.bNew_fl)
                {
                    if (moUtility.ToInteger(Header.txtKey_id) >= modGeneralUtility.ReadNextTransactionNumber(ref moDatabase, moPage.iTransaction_typ))
                    {
                        FormShowMessage(Header.txtKey_id + User.Language.oMessage.IS_INVALID);
                        return false;
                    }
                }
            }
            else if (modGeneralUtility.CheckTransactionNumber(ref moDatabase, moPage.bNew_fl, moPage.iScreen_typ, moPage.iTransaction_typ, ref Header.txtKey_id) == false)
            {
                return false;
            }

            // Someone could have saved with the same number.
            //
            if (moPage.bNew_fl && Header.txtKey_id != moPage.sPreviousKey_id)
            {
                if (EnableInvoiceNumber == false)
                {
                    Header.txtTransaction_num = moGeneral.GetFormatedDocumentNumber(moPage.iTransaction_typ, Header.txtKey_id, "");     // Need to reset the formatted number
                }
                cur_set.Release();
            }

            return true;
        }

        private bool FormPrint()
        {
            bool return_value = false;
            string report_name = "";
            string pdf_file = "";
            clsFile o_file = new clsFile();
            DateTime stime_started = DateTime.Now;
            clsMail o_mail = new clsMail(ref moDatabase);

            try
            {
                if (FormOpenDatabase() == false)        // Do not delete this
                {
                    return false;
                }

                if (optReportOption_typ == 1)
                {
                    report_name = modCommonReportUtility.GetInvoiceReportFileName(ref moDatabase, modCommonUtility.GetComboText(ReportTypeList, cboReport_typ));
                }
                else
                {
                    report_name = modCommonReportUtility.GetInvoicePackingSlipFileName(ref moDatabase, modCommonUtility.GetComboText(ReportTypeList, cboReport_typ));
                }

                moReport.InitReport(moUtility.GetServerName(ref moDatabase), moUtility.GetDatabaseName(ref moDatabase), moUtility.GetDBUser(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_ID)
                                    , moUtility.GetDBPassword(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_PASSWORD), moDatabase.uDirectory.sPDFDirectory_nm, true, true);

                moReport.SetFileName(report_name, moUtility.GetCustomReportFolder(ref moDatabase));
                                
                if (SetReportSelection() == false)
                {
                    return false;
                }

                if (moReport.PrintReport(ref moDatabase, miPrintDestination_typ, ref pdf_file) == false)
                {
                    FormShowMessage(moReport.GetErrorMessage());
                    return false;
                }

                if (moUtility.IsEmpty(pdf_file) || modWebReportUtility.PDFFound(pdf_file) == false)
                {
                    FormShowMessage(User.Language.oMessage.REPORT_SERVER_NOT_RESPONDING);
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(pdf_file, true));

                txtEmailRecipient = moUtility.STrim(txtEmailRecipient);

                if (chkSendEmail_fl && moUtility.IsNonEmpty(txtEmailRecipient))
                {
                    if (o_mail.SendMail(User.Language.oString.STR_INVOICE + ": " + Header.txtKey_id, moDatabase.uCompany.sName + " sent invoice #" + Header.txtKey_id, moDatabase.sSystemEmailAddress, txtEmailRecipient, pdf_file) == false)
                    {
                        FormShowMessage();
                    }
                    else
                    {
                        FormShowMessage(User.Language.oMessage.DOCUMENT_HAS_BEEN_SENT_TO + txtEmailRecipient + ". " + User.Language.oMessage.IT_MAY_TAKE_A_MINUTE_TO_ARRIVE, false);
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormPrint)");
            }

            return return_value;
        }

        private bool FormReArrangeDetail()                                                         // Arrange(show/hide, enable/disable) the columns in the detail(grid)
        {
            return true;
        }

        private bool FormReArrangeHeader()                                                         //  Arrange(show/hide, enable/disable) the fields in the header section
        {
            Lock.Clear();
         
            Lock.Entity = (SecurityLock() && moUtility.IsNonEmpty(Header.txtCustomer_cd));       
            Lock.Job = (SecurityLock() || (moDatabase.uProgram.bJCExist_fl == false));                               

            Lock.Price = (SecurityLock() || PriceLock());

            Lock.Tax = (SecurityLock() || ((PriceLock() || moUtility.IsSalesStaff(moDatabase)) && (moUtility.IsNonEmpty(Header.cboTax_cd))));      
            Lock.Terms = (SecurityLock() || (moUtility.IsNonEmpty(Header.cboTerms_cd) && moUtility.IsSalesStaff(moDatabase)));
            Lock.Agent = (SecurityLock() || (moUtility.IsNonEmpty(Header.cboSalesrep_cd) && moUtility.IsSalesStaff(moDatabase)));
            Lock.Posting = (SecurityLock() || (moUtility.IsNonEmpty(Header.txtKey_id) && moUtility.IsNonEmpty(Header.txtCustomer_cd) && moUtility.IsNonEmpty(Header.cboPosting_cd)));

            Lock.Location = (SecurityLock());        //  if moDatabase.bRestrictLocation_fl, it just shows the designated location only already

            Lock.Order = mbMultiOrder_fl;
            Lock.Commission = ((moUtility.ToInteger(Header.txtOrder_num) > 0) || moUtility.IsSalesStaff(moDatabase));

            Lock.Account = moUtility.IsSalesStaff(moDatabase);

            return true;
        }

        private bool FormRecreateDetail()                                                           //  Sync moDetail.Data with moDetail.Grid for the items that do not have event-handler ONLY.
        {
            if (moDetail.RecreateDetail() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateDetailLine(Models.clsChargeDetail.clsGrid cur_item, int row_num = -1)
        {
            if (moDetail.RecreateDetailLine(cur_item, row_num) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateGrid()                                                             //  Create moDetail.Grid according to moDetail.Data
        {
            if (moDetail.RecreateGrid() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }
        private bool FormReceiveValues()
        {
            // If connected already, return true.  This means this page came through the menu system.
            //
            if (moUtility.IsNonEmpty(User.sServer_nm) || moDatabase.IsConnected())
            {
                return true;
            }

            // Otherwise, need to login with the info passed from the calling page.
            //
            if (modGeneralUtility.GetPassedParameters(StarterValue, User, moSession) == false)
            {
                FormShowMessage(User.Language.oMessage.PLEASE_LOG_IN_FIRST);
                return false;
            }

            moPage.sInitialKey_id = moSession.Value.Entity;

            return true;
        }

        private bool FormSave(bool from_printing_fl = false)
        {
            bool return_value = false;
            clsRecordset cur_set;

            try
            {
                if (FormOpenDatabase() == false)                     // Has to come before FormCheck()
                {
                    return false;
                }
                else if (FormCheck() == false)                       // Check if data is ok to save.
                {
                    return false;
                }

                moPage.sPreviousKey_id = Header.txtKey_id;
                cur_set = new clsRecordset(ref moDatabase);

                if (modFormUtility.RecordOpen(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sRestrictionClause, moPage.sTable_nm, moPage.sKeyField_nm) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormCheckConcurrency(cur_set, from_printing_fl) == false)
                {
                    return false;
                }
                else if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (FormPreSave(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveHeader(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveExtra(cur_set) == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormSaveDetail() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (moInvoice.SaveTransaction(ref cur_set) == false)
                {
                    FormShowMessage();
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (FormPostTransactionRealtime() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }
                else if (moDatabase.TransactionCommit() == false)
                {
                    FormShowMessage();
                    moDatabase.TransactionRollback();
                    return false;
                }

                FormPostSave();
                    
                return_value = true;

            }
            catch (Exception ex)
            {

                FormShowMessage(ex.Message + " (FormSave)");
                moDatabase.TransactionRollback();

            }

            return return_value;
        }

        private bool FormSaveDetail()
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
                // Since detail data is in moDetail.Data[], we need to copy it over to moInvoice.sDetailData[] for saving
                //
                moUtility.ResizeDim(ref moInvoice.sDetailData, clsInvoice.TOTAL_COLUMNS - 1, moDetail.Data.GetUpperBound(1));

                for (row_num = 0; row_num < moDetail.Data.GetLength(1); row_num++)
                {
                    moInvoice.sDetailData[clsInvoice.ITEM_CODE_COL, row_num] = moDetail.Data[Models.clsChargeDetail.ITEM_CODE_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.LOCATION_COL, row_num] = moDetail.Data[Models.clsChargeDetail.LOCATION_COL, row_num];

                    moInvoice.sDetailData[clsInvoice.ITEM_MANUFACTURER_COL, row_num] = moDetail.Data[Models.clsChargeDetail.ITEM_MANUFACTURER_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.ITEM_BRAND_COL, row_num] = moDetail.Data[Models.clsChargeDetail.ITEM_BRAND_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.ITEM_MODEL_COL, row_num] = moDetail.Data[Models.clsChargeDetail.ITEM_MODEL_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.ITEM_STYLE_COL, row_num] = moDetail.Data[Models.clsChargeDetail.ITEM_STYLE_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.ITEM_COLOR_COL, row_num] = moDetail.Data[Models.clsChargeDetail.ITEM_COLOR_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.ITEM_SIZE_COL, row_num] = moDetail.Data[Models.clsChargeDetail.ITEM_SIZE_COL, row_num];

                    moInvoice.sDetailData[clsInvoice.DESCRIPTION_COL, row_num] = moDetail.Data[Models.clsChargeDetail.DESCRIPTION_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.UNIT_CODE_COL, row_num] = moDetail.Data[Models.clsChargeDetail.UNIT_CODE_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.QTY_SHIPPED_COL, row_num] = moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.QTY_ORDERED_COL, row_num] = moDetail.Data[Models.clsChargeDetail.QTY_ORDERED_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.QTY_BACKORDER_COL, row_num] = moDetail.Data[Models.clsChargeDetail.QTY_BACKORDER_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.UNIT_PRICE_COL, row_num] = moDetail.Data[Models.clsChargeDetail.UNIT_PRICE_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.AMT_EXTENDED_COL, row_num] = moDetail.Data[Models.clsChargeDetail.AMT_EXTENDED_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.DISC_PERC_COL, row_num] = moDetail.Data[Models.clsChargeDetail.DISC_PERC_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.TAX_CODE_COL, row_num] = moDetail.Data[Models.clsChargeDetail.TAX_CODE_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.FULL_ACCT_CODE_COL, row_num] = moDetail.Data[Models.clsChargeDetail.FULL_ACCT_CODE_COL, row_num];

                    moInvoice.sDetailData[clsInvoice.NATURAL_ACCT_CODE_COL, row_num] = moDetail.Data[Models.clsChargeDetail.NATURAL_ACCT_CODE_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.SEGMENT1_COL, row_num] = moDetail.Data[Models.clsChargeDetail.SEGMENT1_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.SEGMENT2_COL, row_num] = moDetail.Data[Models.clsChargeDetail.SEGMENT2_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.SEGMENT3_COL, row_num] = moDetail.Data[Models.clsChargeDetail.SEGMENT3_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.SEGMENT4_COL, row_num] = moDetail.Data[Models.clsChargeDetail.SEGMENT4_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.SEGMENT5_COL, row_num] = moDetail.Data[Models.clsChargeDetail.SEGMENT5_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.SEGMENT6_COL, row_num] = moDetail.Data[Models.clsChargeDetail.SEGMENT6_COL, row_num];

                    moInvoice.sDetailData[clsInvoice.AMT_TAX_COL, row_num] = moDetail.Data[Models.clsChargeDetail.AMT_TAX_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.TAX_PERC_COL, row_num] = moDetail.Data[Models.clsChargeDetail.TAX_PERC_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.QTY_IN_IVUNIT_COL, row_num] = moDetail.Data[Models.clsChargeDetail.QTY_IN_IVUNIT_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.IVUNIT_CODE_COL, row_num] = moDetail.Data[Models.clsChargeDetail.IVUNIT_CODE_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.TOTAL_COST_COL, row_num] = moDetail.Data[Models.clsChargeDetail.TOTAL_COST_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.ITEM_TYPE_COL, row_num] = moDetail.Data[Models.clsChargeDetail.ITEM_TYPE_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.AMT_DISC_COL, row_num] = moDetail.Data[Models.clsChargeDetail.AMT_DISC_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.CONVERSION_RATE_COL, row_num] = moDetail.Data[Models.clsChargeDetail.CONVERSION_RATE_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.SELL_UNIT_CODE_COL, row_num] = moDetail.Data[Models.clsChargeDetail.SELL_UNIT_CODE_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.SELL_UNIT_PRICE_COL, row_num] = moDetail.Data[Models.clsChargeDetail.SELL_UNIT_PRICE_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.LINE_ID_COL, row_num] = moDetail.Data[Models.clsChargeDetail.LINE_ID_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.KIT_ID_COL, row_num] = moDetail.Data[Models.clsChargeDetail.KIT_ID_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.WEIGHT_PER_UNIT_COL, row_num] = moDetail.Data[Models.clsChargeDetail.WEIGHT_PER_UNIT_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.FREIGHT_PER_UNIT_COL, row_num] = moDetail.Data[Models.clsChargeDetail.FREIGHT_PER_UNIT_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.EXPENSE_TYPE_COL, row_num] = moDetail.Data[Models.clsChargeDetail.EXPENSE_TYPE_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.EXPENSE_NUM_COL, row_num] = moDetail.Data[Models.clsChargeDetail.EXPENSE_NUM_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.EXPENSE_DETAIL_COL, row_num] = moDetail.Data[Models.clsChargeDetail.EXPENSE_DETAIL_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.PRIMARY_ITEM_CODE_COL, row_num] = moDetail.Data[Models.clsChargeDetail.PRIMARY_ITEM_CODE_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.JOB_CODE_COL, row_num] = moDetail.Data[Models.clsChargeDetail.JOB_CODE_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.ORDER_NUM_COL, row_num] = moDetail.Data[Models.clsChargeDetail.ORDER_NUM_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.LINE_TYPE_COL, row_num] = moDetail.Data[Models.clsChargeDetail.LINE_TYPE_COL, row_num];
                    moInvoice.sDetailData[clsInvoice.SOURCE_DETAIL_ID_COL, row_num] = moDetail.Data[Models.clsChargeDetail.SOURCE_DETAIL_ID_COL, row_num];
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveDetail)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormSaveExtra(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                if (SaveCommission() == false)
                {
                    return false;
                }
                else if (SavePayment() == false)
                {
                    return false;
                }
                else if (SavePaymentSchedule() == false)
                {
                    return false;
                }
                else if (SaveSerial() == false)
                {
                    return false;
                }

                mbListingInitiated_fl = false;                  // Will let the listing refresh

                User.bDisableDescription_fl = chkDisableDescription_fl;
                User.bDisableQuantity_fl = chkDisableQty_fl;
                User.bDisableUnitCode_fl = chkDisableUnit_fl;
                User.bDisableUnitPrice_fl = chkDisablePrice_fl;
                User.SetPreference(ref moDatabase);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormSaveHeader(clsRecordset cur_set)
        {
            bool return_value = false;
            string sql_str = null;

            try
            {

                moInvoice.bNew_fl = (moPage.bNew_fl || cur_set.EOF());

                // This is for Concurrency check to go smooth.
                // If someone calls FormSave() without going thru the whole saving routine that
                // clears the screen, and save again later, then FormCheckConcurrency() will raise an error
                // because the record in the database has been updated but moPage.Original.dtLastUpdate_dt still has the old timestamp.
                //
                moPage.Original.sLastUpdate_id = moDatabase.sUser_cd;
                moPage.Original.dtLastUpdate_dt = DateTime.Now;

                moInvoice.iTransaction_typ = moPage.iTransaction_typ;
                moInvoice.iTransaction_num = moUtility.ToInteger(Header.txtKey_id);
                moInvoice.sTransaction_num = Header.txtTransaction_num;
                moInvoice.iDropShipment_fl = (moUtility.IIf(Header.chkDropShipment_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF));
                moInvoice.iGiftShipment_fl = (moUtility.IIf(Header.chkGiftShipment_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF));
                moInvoice.sJob_cd = Header.cboJob_cd;
                moInvoice.sYourReference = moUtility.EvalQuote(Header.txtYourReference);
                moInvoice.sReference = moUtility.EvalQuote(Header.txtOurReference);
                moInvoice.sLocation_cd = Header.cboLocation_cd;
                moInvoice.sDunn_cd = Header.cboDunn_cd;
                moInvoice.sComment = moUtility.EvalQuote(Header.txtComment);
                moInvoice.sTax_cd = Header.cboTax_cd;
                moInvoice.iEntry_dt = moGeneral.ToNumDate(Header.mskEntry_dt);
                moInvoice.iOrder_num = moUtility.ToInteger(Header.txtOrder_num);
                moInvoice.sVia_cd = Header.cboVia_cd;
                moInvoice.sPrice_cd = Header.cboPrice_cd;
                moInvoice.sSalesrep_cd = Header.cboSalesrep_cd;
                moInvoice.sTerms_cd = Header.cboTerms_cd;
                moInvoice.iShipped_dt = moGeneral.ToNumDate(Header.mskShipped_dt);
                moInvoice.iRequired_dt = moGeneral.ToNumDate(Header.mskRequired_dt);
                moInvoice.iApply_dt = moGeneral.ToNumDate(Header.mskApply_dt);
                moInvoice.sFob_cd = moUtility.EvalQuote(Header.cboFOB_cd);
                moInvoice.sCustomer_cd = moUtility.EvalQuote(Header.txtCustomer_cd);
                moInvoice.sCustomer_nm = moUtility.EvalQuote(Header.txtCustomer_nm);
                moInvoice.sCustomerAttn = moUtility.EvalQuote(Header.txtCustomerAttn);
                moInvoice.sCustomerAddress1 = moUtility.EvalQuote(Header.txtCustomerAddress1);
                moInvoice.sCustomerAddress2 = moUtility.EvalQuote(Header.txtCustomerAddress2);
                moInvoice.sCustomerAddress3 = moUtility.EvalQuote(Header.txtCustomerAddress3);
                moInvoice.fWeight = moUtility.ToValue(Header.txtWeight);
                moInvoice.mTotal_amt = moMoney.ToNumMoney(Header.txtTotal_amt);
                moInvoice.fTax_pc = moUtility.ToValue(Header.txtTax_pc);
                moInvoice.mNonTaxable_amt = moMoney.ToNumMoney(Header.txtNonTaxable_amt);
                moInvoice.mTaxable_amt = moMoney.ToNumMoney(Header.txtTaxable_amt);
                moInvoice.mTax_amt = moMoney.ToNumMoney(Header.txtTax_amt);
                moInvoice.mDiscount_amt = moMoney.ToNumMoney(Header.txtDiscount_amt);
                moInvoice.mFreight_amt = moMoney.ToNumMoney(Header.txtFreight_amt);
                moInvoice.mPaid_amt = moMoney.ToNumMoney(Header.txtPaid_amt);
                moInvoice.mDue_amt = moMoney.ToNumMoney(Header.txtDue_amt);
                moInvoice.iStatus_typ = moUtility.ToInteger(Header.cboStatus_typ);
                moInvoice.sPosting_cd = moUtility.EvalQuote(Header.cboPosting_cd);
                moInvoice.sShipTo_cd = moUtility.EvalQuote(Header.txtShipTo_cd);
                moInvoice.sShipTo_nm = moUtility.EvalQuote(Header.txtShipTo_nm);
                moInvoice.sShipToAddress1 = moUtility.EvalQuote(Header.txtShipToAddress1);
                moInvoice.sShipToAddress2 = moUtility.EvalQuote(Header.txtShipToAddress2);
                moInvoice.sShipToAddress3 = moUtility.EvalQuote(Header.txtShipToAddress3);
                moInvoice.sShipToCity = moUtility.EvalQuote(Header.txtShipToCity);
                moInvoice.sShipToState = moUtility.EvalQuote(Header.txtShipToState);
                moInvoice.sShipToZipCode = moUtility.EvalQuote(Header.txtShipToZipCode);
                moInvoice.sShipToFax = moUtility.EvalQuote(Header.txtShipToFax);
                moInvoice.sShipToPhone = moUtility.EvalQuote(Header.txtShipToPhone);
                moInvoice.sShipToCountry_cd = moUtility.EvalQuote(Header.txtShipToCountry_cd);
                moInvoice.sWebUser_id = moUtility.EvalQuote(Header.txtWebUser_id);
                moInvoice.iBatch_num = moDatabase.CurrentBatch;
                moInvoice.iDue_dt = moGeneral.ToNumDate(Header.mskDue_dt);
                moInvoice.iPrinted_num = moUtility.ToInteger(Header.txtPrinted_num);
                moInvoice.iRecurring_typ = moUtility.ToInteger(Header.cboRecur_typ);
                moInvoice.iToRecur_num = moUtility.ToInteger(Header.txtRecurTo_num);
                moInvoice.iToRecur_dt = moGeneral.ToNumDate(Header.mskToRecur_dt);
                moInvoice.sShipToAttn = moUtility.EvalQuote(Header.txtShipToAttn);
                moInvoice.sUserApproved_cd = moUtility.EvalQuote(Header.txtUserApproved_cd);
                moInvoice.iToApprove_num = moUtility.ToInteger(Header.txtToApprove_num);
                moInvoice.sFund_cd = GlobalVar.goFund.GetSelectedFundCodeToSave(ref moDatabase, Header.cboFund_cd.ToString());
                moInvoice.mFreightTax_amt = moMoney.ToNumMoney(Header.txtFreightTax_amt);
                moInvoice.iMultiOrder_fl = moUtility.IIf(mbMultiOrder_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);
                moInvoice.iFromPackingSlip_fl = moUtility.IIf(mbFromPackingSlip_fl, GlobalVar.goConstant.FLAG_ON, GlobalVar.goConstant.FLAG_OFF);

                // Attach the custom field list
                //
                moInvoice.CustomFieldList = moCustomFields.GetFieldList();
                moInvoice.CustomValueList = moCustomFields.GetValueList(moDatabase);
                moInvoice.CustomUpdateList = moCustomFields.GetUpdateList(moDatabase);

                moInvoice.sCreator_id = moPage.Original.sLastUpdate_id;
                moInvoice.sLastUpdate_id = moPage.Original.sLastUpdate_id;
                moInvoice.dtLastUpdate_dt = moPage.Original.dtLastUpdate_dt;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormSaveHeader)");
            }

            return return_value;
        }

        private bool FormSearch()
        {
            string search_detail = modCommonUtility.GetTransactionDetailSearchCriteria(moDetail.Grid, moPage.sDetailTable_nm, moPage.iTransaction_typ, Models.clsChargeDetail.ITEM_CODE_COL, moUtility.ToInteger(Header.txtOrder_num));
            string where_clause = GetSearchCriteria();

            if (moUtility.IsEmpty(where_clause))
            {
                where_clause = search_detail;
            }
            else
            {
                where_clause += moUtility.IIf(moUtility.IsNonEmpty(search_detail), " AND ", "") + search_detail;
            }

            if (moUtility.IsEmpty(where_clause))
            {
                FormShowMessage(User.Language.oMessage.PLEASE_ENTER_THE_SEARCH_CRITERIA_ON_THE_MAIN_ENTRY_TAB);
                return false;
            }

            where_clause = moUtility.IIf(moUtility.IsNonEmpty(moPage.sRestrictionClause), moPage.sRestrictionClause, "iTransaction_typ = " + moPage.iTransaction_typ.ToString()) + " AND " + where_clause;


            mbSearchPopulated_fl = false;

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            //where_clause = modCommonUtility.AddCommonTransactionSearchClause(where_clause, moPage.iTransaction_typ, cboSearchYear);

            if (moSearch.Show(moDatabase, moPage, where_clause) == false)
            {
                FormShowMessage();
                return false;
            }

            mbSearchInitiated_fl = true;
            mbSearchPopulated_fl = (moSearch.Grid.Count > 0);

            if (mbSearchPopulated_fl == false)
            {
                FormShowMessage(User.Language.oMessage.NO_MATCHING_RECORDS_FOUND);
            }

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {
            if (FormShowHeader(cur_set) == false)
            {
                return false;
            }
            else if (FormShowDetail() == false)
            {
                return false;
            }
            else if (FormShowExtra(cur_set) == false)
            {
                return false;
            }

            FormReArrangeHeader();
            FormReArrangeDetail();

            return true;
        }

        private bool FormShowDetail()
        {
            bool return_value = false;
            int row_num = 0;

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                FormClearDetail();

                if (modDetailUtility.GetDetail(ref moDatabase, moPage.Title, Header.txtKey_id, moPage.sKeyField_nm, ref moDetail.iTotalRows, moPage.sDetailTable_nm, moPage.iTransaction_typ, moDetail.FieldName, ref moDetail.Data) == false)
                {
                    FormShowMessage();
                    return false;
                }

                moDetail.iNextLine_id = modCommonUtility.GetNextLineId(moDetail.Data, Models.clsChargeDetail.LINE_ID_COL);

                if (false == moSerialUtility.ReadSerialData(ref moDatabase, ref moSerial, ref moDetail.Data, moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id)))
                {
                    FormShowMessage();
                    return false;
                }

                if (FormRecreateGrid() == false)
                {
                    return false;
                }
                Header.lblTotal_qty = moDetail.CalcluateTotalQTY(moDetail.Data, Models.clsChargeDetail.ITEM_CODE_COL, Models.clsChargeDetail.ITEM_TYPE_COL, Models.clsChargeDetail.QTY_SHIPPED_COL).ToString();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowDetail)");
            }

            return return_value;
        }

        private bool FormShowExtra(clsRecordset cur_set)
        {
            bool return_value = false;
            clsApproval o_approval = new clsApproval(ref moDatabase);

            try
            {
                moPage.Clear();
                moPage.PreserveTimestamp(cur_set);
                moPage.PreserveOriginal(cur_set);
                moPage.bNew_fl = false;

                // This is where bReadOnly_fl & bReserved_fl are set according to the nature of the current record.
                //
                moJobCost.Grid.Clear();

                msOriginalTax_cd = cur_set.sField("sTax_cd");
                msHoldStatusMessage = GlobalVar.goStatus.HoldingStatusTypeText(cur_set.iField("iHoldStatus_typ"));

                if (cur_set.iField("iHoldStatus_typ") > 0)
                {
                    msHoldStatusMessage += o_approval.GetPendidngStatus(cur_set.iField("iTransaction_typ"), cur_set.iField("iTransaction_num"));
                }

                miSource_typ = cur_set.iField("iSource_typ");
                miSource_num = cur_set.iField("iSource_num");

                Header.txtRemaining_amt = "";

                mbPaymentUpdated_fl = false;
                mbPaymentScheduleUpdated_fl = false;

                if (GetPayment() == false)
                {
                    return false;
                }
                if (GetCommission() == false)
                {
                    return false;
                }
                if (GetPaymentSchedule() == false)
                {
                    return false;
                }

                moPage.sPreviousKey_id = Header.txtKey_id;
                Header.Preserve();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowHeader(clsRecordset cur_set)
        {
            bool return_value = false;

            try
            {
                Header.txtKey_id = cur_set.sField(moPage.sKeyField_nm);
                Header.txtTransaction_num = cur_set.sField("sTransaction_num");
                Header.cboStatus_typ = cur_set.iField("iStatus_typ").ToString();
                Header.cboFund_cd = GlobalVar.goFund.GetSelectedFundCodeToDisplay(ref moDatabase, cur_set.sField("sFund_cd"));

                Header.txtCustomer_cd = cur_set.sField("sCustomer_cd");
                modLoadUtility.LoadJobCode(ref moDatabase, ref JobCodeList, Header.txtCustomer_cd);

                Header.chkDropShipment_fl = (cur_set.iField("iDropShipment_fl") == GlobalVar.goConstant.CHECKED_ON);
                Header.chkGiftShipment_fl = (cur_set.iField("iGiftShipment_fl") == GlobalVar.goConstant.CHECKED_ON);
                Header.cboJob_cd = cur_set.sField("sJob_cd");
                Header.txtYourReference = cur_set.sField("sYourReference");
                Header.txtOurReference = cur_set.sField("sReference");
                Header.cboLocation_cd = cur_set.sField("sLocation_cd");
                Header.cboDunn_cd = cur_set.sField("sDunn_cd");
                Header.txtComment = cur_set.sField("sComment");
                Header.cboTax_cd = cur_set.sField("sTax_cd");

                if (cur_set.iField("iOrder_num") > 0)
                {
                    Header.txtOrder_num = cur_set.iField("iOrder_num").ToString();
                }
                else
                {
                    Header.txtOrder_num = "";
                }
                Header.cboVia_cd = cur_set.sField("sVia_cd");
                Header.cboPrice_cd = cur_set.sField("sPrice_cd");
                Header.cboSalesrep_cd = cur_set.sField("sSalesrep_cd");
                Header.cboTerms_cd = cur_set.sField("sTerms_cd");
                Header.cboFOB_cd = cur_set.sField("sFob_cd");
                Header.txtCustomerAttn = cur_set.sField("sCustomerAttn");
                Header.txtCustomerAddress3 = cur_set.sField("sCustomerAddress3");
                Header.txtCustomerAddress2 = cur_set.sField("sCustomerAddress2");
                Header.txtCustomerAddress1 = cur_set.sField("sCustomerAddress1");
                Header.txtCustomer_nm = cur_set.sField("sCustomer_nm");

                Header.txtTotal_amt = moMoney.ToStrMoney(cur_set.mField("mTotal_amt"));
                Header.txtTax_pc = cur_set.mField("fTax_pc").ToString();
                Header.txtNonTaxable_amt = moMoney.ToStrMoney(cur_set.mField("mNonTaxable_amt"));
                Header.txtTaxable_amt = moMoney.ToStrMoney(cur_set.mField("mTaxable_amt"));
                Header.txtTax_amt = moMoney.ToStrMoney(cur_set.mField("mTax_amt"));
                Header.txtDiscount_amt = moMoney.ToStrMoney(cur_set.mField("mDiscount_amt"));
                Header.txtPaid_amt = moMoney.ToStrMoney(cur_set.mField("mPaid_amt"));
                Header.txtDue_amt = moMoney.ToStrMoney(cur_set.mField("mDue_amt"));
                Header.cboPosting_cd = cur_set.sField("sPosting_cd");
                Header.txtBatch_num = cur_set.iField("iBatch_num").ToString();
                Header.txtPrinted_num = cur_set.iField("iPrinted_num").ToString();
                Header.txtShipToAttn = cur_set.sField("sShipToAttn");
                Header.txtShipToAddress3 = cur_set.sField("sShipToAddress3");
                Header.txtShipToAddress2 = cur_set.sField("sShipToAddress2");
                Header.txtShipToAddress1 = cur_set.sField("sShipToAddress1");
                Header.txtShipTo_nm = cur_set.sField("sShipTo_nm");
                Header.cboFund_cd = GlobalVar.goFund.GetSelectedFundCodeToDisplay(ref moDatabase, cur_set.sField("sFund_cd").ToString());
                Header.txtFreightTax_amt = cur_set.mField("mFreightTax_amt").ToString();
                mbMultiOrder_fl = (cur_set.iField("iMultiOrder_fl") == GlobalVar.goConstant.FLAG_ON);
                mbFromPackingSlip_fl = (cur_set.iField("iFromPackingSlip_fl") == GlobalVar.goConstant.FLAG_ON);

                Header.cboRecur_typ = cur_set.iField("iRecurring_typ").ToString();
                Header.txtRecurTo_num = cur_set.iField("iToRecur_num").ToString();

                if (cur_set.iField("iRecurring_typ") > 0 && (cur_set.iField("iToRecur_num") > 0 || cur_set.iField("iToRecur_dt") > 0)) 
                {
                    Header.chkRecur_fl = true;
                }
                else
                {
                    Header.chkRecur_fl = false;
                    Header.cboRecur_typ = "";
                    Header.txtRecurTo_num = "";
                }

                if (cur_set.mField("fWeight") > 0)
                {
                    Header.txtWeight = cur_set.mField("fWeight").ToString();
                }
                else
                {
                    Header.txtWeight = "";
                }

                if (cur_set.mField("mFreight_amt") > 0)
                {
                    Header.txtFreight_amt = moMoney.ToStrMoney(cur_set.mField("mFreight_amt"));
                }
                else
                {
                    Header.txtFreight_amt = "";
                }

                Header.txtShipToFax = cur_set.sField("sShipToFax");
                Header.txtShipToPhone = cur_set.sField("sShipToPhone");
                Header.txtShipToCountry_cd = cur_set.sField("sShipToCountry_cd");
                Header.txtShipToZipCode = cur_set.sField("sShipToZipCode");
                Header.txtShipToState = cur_set.sField("sShipToState");
                Header.txtShipToCity = cur_set.sField("sShipToCity");
                Header.txtShipTo_cd = cur_set.sField("sShipTo_cd");
                Header.txtWebUser_id = cur_set.sField("sWebUser_id");
                Header.txtUserApproved_cd = cur_set.sField("sUserApproved_cd");
                Header.txtToApprove_num = cur_set.iField("iToApprove_num").ToString();

                // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
                // Make sure both, dt* and msk*, are sync'ed.
                //
                Header.mskEntry_dt = moGeneral.ToStrDate(cur_set.iField("iEntry_dt"));
                Header.mskApply_dt = moGeneral.ToStrDate(cur_set.iField("iApply_dt"));
                Header.mskShipped_dt = moGeneral.ToStrDate(cur_set.iField("iShipped_dt"));
                Header.mskRequired_dt = moGeneral.ToStrDate(cur_set.iField("iRequired_dt"));
                Header.mskToRecur_dt = moGeneral.ToStrDate(cur_set.iField("iToRecur_dt"));
                Header.mskDue_dt = moGeneral.ToStrDate(cur_set.iField("iDue_dt"));

                // Custom Fields
                //
                moCustomFields.SetValues(moDatabase, cur_set);

                FormSyncDates(false);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowHeader)");
                return_value = false;
            }

            return return_value;
        }

        private bool FormShowListing()
        {
            string where_clause = "";

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (mbListingInitiated_fl)
            {
                return true;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moListing.Show(moDatabase, moPage, where_clause, cboListingBy) == false)
            {
                FormShowMessage();
                return false;
            }

            mbListingInitiated_fl = true;
            mbListingPopulated_fl = (moListing.Grid.Count > 0);

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtApply_dt, ref Header.mskApply_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtEntry_dt, ref Header.mskEntry_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtRequired_dt, ref Header.mskRequired_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtShipped_dt, ref Header.mskShipped_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtToRecur_dt, ref Header.mskToRecur_dt, use_date_picker);

            // Payment schedule
            //
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtStarting_dt, ref Header.mskStarting_dt, use_date_picker);

            return true;
        }

        private bool FormSwitchView(int cur_page = -1)                                                              // Switch the tab-pages
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            moView.SwitchView(moPage, cur_page);

            if (cur_page == moView.PAYMENT_PAGE_NUM)
            {
                mbPaymentUpdated_fl = true;             // Meaning that user visited/updated payment.
            }
            else if (cur_page == moView.PAYMENT_SCHEDULE_PAGE_NUM)
            {
                mbPaymentScheduleUpdated_fl = true;     // Meaning that user visited/updated payment schedule page.
                CalculatePaymentSchedule();
            }
            else
            {
                if (mbPaymentUpdated_fl)
                {
                    CalculatePayment();
                    mbPaymentUpdated_fl = false;
                }
                
                if (mbPaymentScheduleUpdated_fl)
                {
                    CalculatePaymentSchedule();
                    mbPaymentScheduleUpdated_fl = false;     
                }
            }

            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);
            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moZoom.Caller == "txtCustomer_cd")
            {
                if (moZoom.Customer(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            else if (moZoom.Caller == "txtOrder_num")
            {
                if (moZoom.Transaction(ref moDatabase, GlobalVar.goConstant.TRX_SO_TYPE, "tblSOTransaction") == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            else if (moZoom.iColumn == Models.clsChargeDetail.ITEM_CODE_COL || moZoom.Caller == "txtMatrixItem_cd")
            {
                if (moZoom.Inventory(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            else if (moZoom.iColumn == Models.clsChargeDetail.FULL_ACCT_CODE_COL)
            {
                if (moZoom.Account(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormClear();
                return true;
            }

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
                {
                    return false;
                }
            }

            FormCancel();
            return true;
        }

        private bool btnCopy_Clicked()
        {
            

            return true;
        }


        private bool btnDelete_Clicked()
        {
            FormPreEvent();

            // We do not delete the transactions.
            
            FormClear();
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                FormExit();
                return true;
            }

            if (FormDialog(btnExit_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_EXIT) == false)
            {
                return false;
            }

            FormExit();
            return true;
        }

        private bool btnFirst_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnFirst_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.FIRST_RECORD_TYPE);
        }

        private bool btnLast_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnLast_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.LAST_RECORD_TYPE);
        }

        private bool btnNext_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnNext_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.NEXT_RECORD_TYPE);
        }

        private bool btnPrevious_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnPrevious_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.PREVIOUS_RECORD_TYPE);
        }

        private bool btnSave_Clicked()
        {
            FormPreEvent();

            if (moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.VOID_TRX_NUM)
            {
                if (FormDialog(btnSave_Clicked, 10, User.Language.oMessage.ARE_YOU_SURE_TO_VOID) == false)
                {
                    return false;
                }
            }

            if (FormSave() == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        private bool btnPrint_Clicked()
        {
            FormPreEvent();

            miPrintDestination_typ = GlobalVar.goConstant.PRINT_TO_PDF;

            if (moUtility.IsEmpty(Header.txtKey_id) || moUtility.IsEmpty(Header.txtCustomer_cd))
            {
                return false;
            }

            if (moUtility.IsEmpty(moCustomer.sEmailAddress))
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                moCustomer.GetCustomer(Header.txtCustomer_cd, true);
            }

            txtEmailRecipient = moCustomer.sEmailAddress;

            FormSwitchView(moView.PRINT_PAGE_NUM);

            return FormPostEvent();
        }


        private bool btnExcel_Clicked()
        {
            FormPreEvent();

            miPrintDestination_typ = GlobalVar.goConstant.PRINT_TO_EXCEL;

            if (moUtility.IsEmpty(Header.txtKey_id) || moUtility.IsEmpty(Header.txtCustomer_cd))
            {
                return false;
            }

            if (moUtility.IsEmpty(moCustomer.sEmailAddress))
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                if (moValidate.IsValidCustomerCode(Header.txtCustomer_cd) == false)
                {
                    FormShowMessage(Header.txtCustomer_cd + User.Language.oMessage.IS_INVALID);
                    FormSetFocus("txtCustomer_cd");
                    return false;
                }

                txtEmailRecipient = moValidate.oRecordset.sField("sEmailAddress");
                moValidate.Release();
            }

            FormSwitchView(moView.PRINT_PAGE_NUM);

            return FormPostEvent();
        }

        private bool btnSearchToPrint_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateSearchHTML();

            return FormPostEvent();
        }

        private bool btnSearchToExcel_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateSearchExcel();

            return FormPostEvent();
        }

        private bool btnListingToPrint_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateListingHTML();

            return FormPostEvent();
        }

        private bool btnListingToExcel_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateListingExcel();

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewHeader_Clicked()
        {
            FormPreEvent();                                                                           
            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool cmdViewListing_Clicked()
        {
            FormPreEvent();       
            
            if (FormShowListing() == false)
            {
                return false;
            }

            FormSwitchView(moView.LISTING_PAGE_NUM);
            return true;

        }

        private bool cmdViewDetail_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.DETAIL_PAGE_NUM);

            return true;
        }

        private bool cmdViewMatrix_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.MATRIX_PAGE_NUM);

            return true;
        }

        private bool cmdViewMultiOrder_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.ORDER_PAGE_NUM);

            return true;
        }

        private bool cmdViewPayment_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.PAYMENT_PAGE_NUM);

            return true;
        }

        private bool cmdViewCommission_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.COMMISSION_PAGE_NUM);

            return true;
        }

        private bool cmdViewOptions_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.OPTIONS_PAGE_NUM);

            return true;
        }

        private bool cmdViewSearch_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.SEARCH_PAGE_NUM);

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnListingSelect_Clicked(Models.clsListingCharge.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.ToInteger(cur_item.Transaction_num) <= 0)   // May have a string such as TOTAL
            {
                return false;
            }

            FormClear();
            Header.txtKey_id = cur_item.Transaction_num;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnSearchSelect_Clicked(Models.clsListingCharge.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.IsEmpty(cur_item.Transaction_num))
            {
                return false;
            }

            FormClear();
            Header.txtKey_id = cur_item.Transaction_num;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                if (moUtility.IsEmpty(cur_item.Col_0))
                {
                    return false;
                }

                code_selected = cur_item.Col_0;

                if (moZoom.Caller == "txtCustomer_cd")
                {
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    Header.txtCustomer_cd = code_selected;
                    return txtCustomer_cd_Changed();
                }
                else if (moZoom.Caller == "txtOrder_num")
                {
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    Header.txtOrder_num = code_selected;
                    return txtOrder_num_Changed();
                }
                else if (moZoom.Caller == "txtMatrixItem_cd")
                {
                    FormSwitchView(moView.MATRIX_PAGE_NUM);
                    Header.txtMatrixItem_cd = code_selected;
                    return txtMatrixItem_cd_Changed();
                }

                // Detail.Grid.Single(i => i.Row_num == moZoom.iRow).txtItem_cd = cur_item.Col_0;
                // Detail.Data[moZoom.iColumn, moZoom.iRow] = cur_item.Col_0;

                Models.clsChargeDetail.clsGrid detail_item = moDetail.Grid.Single(i => i.Row_num == moZoom.iRow);

                if (moZoom.iColumn == Models.clsChargeDetail.ITEM_CODE_COL)
                {
                    FormSwitchView(moView.DETAIL_PAGE_NUM);
                    detail_item.txtItem_cd = code_selected;
                    return DetailItem_cd_Changed(detail_item);
                }
                else if (moZoom.iColumn == Models.clsChargeDetail.FULL_ACCT_CODE_COL)
                {
                    FormSwitchView(moView.DETAIL_PAGE_NUM);
                    detail_item.mskGLAccount_cd = code_selected;
                    return DetailAccount_cd_Changed(detail_item);
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return FormClearMessage();              // Need to clear message that cmdZoomOK_Clicked() shows
        }

        private bool cmdZoomOK_Clicked()
        {
            int total_row_added = 0;

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (CreateDetailLinesFromZoom(ref total_row_added))
            {
                if (moZoom.ExitAtOK)
                {
                    FormSwitchView(moZoom.iView);
                }
                else
                {
                    FormShowMessage(total_row_added.ToString() + User.Language.oMessage.RECORDS_ARE_ADDED, false);
                }
            }
            else
            {
                FormRecreateGrid();         // Change back to original
            }

            FormCalculateTotal();

            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }

        private bool cmdSearch_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormSearch() == false)
            {
                return false;
            }

            return true;
        }

        private bool btnZoomOnCustomer_cd_Clicked()
        {
            string where_clause = "";

            FormPreEvent();

            if (FormOpenDatabase() == false)                // Necessary to make moDatabase.sUser_cd valid
            {
                return false;
            }
            if (moUtility.IsSalesStaff(moDatabase))
            {
                where_clause = "sSalesrep_cd = '" + moDatabase.sUser_cd + "'";
            }

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtCustomer_cd", -1, -1, moView.MAIN_PAGE_NUM, "sCustomer_cd", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");      // shoud not happen
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool btnZoomOnOrder_num_Clicked()
        {
            string where_clause = "";

            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtCustomer_cd))
            {
                FormShowMessage(User.Language.oMessage.ENTER_CUST_CODE_FIRST);
                return false;
            }

            where_clause = "iTransaction_typ = " + GlobalVar.goConstant.TRX_SO_TYPE.ToString() + " AND sCustomer_cd = '" + Header.txtCustomer_cd + "'";

            if (moUtility.IsSalesStaff(moDatabase))
            {
                where_clause +=  " AND sSalesrep_cd = '" + moDatabase.sUser_cd + "'";
            }

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtOrder_num", -1, -1, moView.MAIN_PAGE_NUM, "iTransaction_num", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");      // should not happen
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }
        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool cmdNew_Clicked()
        {
            string entity_code = "";
            string customer_code = "";
            string job_code = "";

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (chkAfterFact_fl)            // For A.F.T, New button should be disabled.
            {
                return false;
            }

            // This logic is for invoice numbers bu customer/job.
            //
            if (moUtility.IsNonEmpty(Header.txtKey_id))
            {
                FormClear();            // Clear only when a record is displayed.
            }

            if (moDatabase.uSecurity.bInvoiceNumberingByJob_fl)
            {
                if (moUtility.IsEmpty(Header.cboJob_cd))
                {
                    FormShowMessage(User.Language.oMessage.ENTER_CUST_JOB_CODE_FIRST);
                    return false;
                }
                entity_code = Header.cboJob_cd;
                customer_code = Header.txtCustomer_cd;
                job_code = Header.cboJob_cd;
            }
            else if (moDatabase.uSecurity.bInvoiceNumberingByCustomer_fl)
            {
                if (moUtility.IsEmpty(Header.txtCustomer_cd))
                {
                    FormShowMessage(User.Language.oMessage.ENTER_CUST_CODE_FIRST);
                    return false;
                }
                entity_code = Header.txtCustomer_cd;
                customer_code = Header.txtCustomer_cd;
                job_code = Header.cboJob_cd;
            }


            FormClear();            

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            // Get the next transaction number.  This would not consume the number.  FormSave() will consume the number.
            //
            Header.txtKey_id = modGeneralUtility.ReadNextTransactionNumber(ref moDatabase, moPage.iTransaction_typ).ToString();

            if (moUtility.ToInteger(Header.txtKey_id) > 0)
            {
                Header.txtTransaction_num = moGeneral.GetFormatedDocumentNumber(moPage.iTransaction_typ, Header.txtKey_id, entity_code);

                // If invoice numbering is by customer/job, need to populate the customer info.
                //
                if (moUtility.IsNonEmpty(entity_code))
                {
                    Header.Tag.txtCustomer_cd = "";
                    Header.txtCustomer_cd = customer_code;
                    
                    if (txtCustomer_cd_Changed() ==  false)
                    {
                        Header.txtCustomer_cd = "";                             // Something went wrong.  Let them enter it again.
                        Header.Tag.txtCustomer_cd = Header.txtCustomer_cd;
                    }
                }

                Header.cboJob_cd = job_code;
                Header.cboLocation_cd = moGeneral.GetDefaultLocationCode("");
                Header.cboStatus_typ = GlobalVar.goConstant.OPEN_TRX_NUM.ToString();
                Header.mskEntry_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                Header.mskApply_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());

                Header.mskRequired_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                Header.mskShipped_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());

                FormSyncDates(false);
            }
            else
            {
                FormShowMessage();
                Header.txtKey_id = "";
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return FormPostEvent();
        }
        private bool txtKey_id_Changed()
        {
            if (Header.txtKey_id == Header.Tag.txtKey_id)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (txtKey_id_Verified() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool dtEntry_dt_Changed()
        {
            if (Header.dtEntry_dt == Header.Tag.dtEntry_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtEntry_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtEntry_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtEntry_dt) == false)
            {
                Header.dtEntry_dt = Header.Tag.dtEntry_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtEntry_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskEntry_dt_Changed()
        {
            if (Header.mskEntry_dt == Header.Tag.mskEntry_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskEntry_dt) == false)
            {
                Header.mskEntry_dt = Header.Tag.mskEntry_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskEntry_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtApply_dt_Changed()
        {
            if (Header.dtApply_dt == Header.Tag.dtApply_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtApply_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtApply_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtApply_dt) == false)
            {
                Header.dtApply_dt = Header.Tag.dtApply_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtApply_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskApply_dt_Changed()
        {
            if (Header.mskApply_dt == Header.Tag.mskApply_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskApply_dt) == false)
            {
                Header.mskApply_dt = Header.Tag.mskApply_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskApply_dt");
                return false;
            }

            return FormPostEvent();
        }


        private bool dtRequired_dt_Changed()
        {
            if (Header.dtRequired_dt == Header.Tag.dtRequired_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtRequired_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtRequired_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtRequired_dt) == false)
            {
                Header.dtRequired_dt = Header.Tag.dtRequired_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtRequired_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskRequired_dt_Changed()
        {
            if (Header.mskRequired_dt == Header.Tag.mskRequired_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskRequired_dt) == false)
            {
                Header.mskRequired_dt = Header.Tag.mskRequired_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskRequired_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtShipped_dt_Changed()
        {
            if (Header.dtShipped_dt == Header.Tag.dtShipped_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtShipped_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtShipped_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtShipped_dt) == false)
            {
                Header.dtShipped_dt = Header.Tag.dtShipped_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtShipped_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskShipped_dt_Changed()
        {
            if (Header.mskShipped_dt == Header.Tag.mskShipped_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskShipped_dt) == false)
            {
                Header.mskShipped_dt = Header.Tag.mskShipped_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskShipped_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtToRecur_dt_Changed()
        {
            if (Header.dtToRecur_dt == Header.Tag.dtToRecur_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtToRecur_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtToRecur_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtToRecur_dt) == false)
            {
                Header.dtToRecur_dt = Header.Tag.dtToRecur_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtToRecur_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskToRecur_dt_Changed()
        {
            if (Header.mskToRecur_dt == Header.Tag.mskToRecur_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskToRecur_dt) == false)
            {
                Header.mskToRecur_dt = Header.Tag.mskToRecur_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskToRecur_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool dtStarting_dt_Changed()
        {
            if (Header.dtStarting_dt == Header.Tag.dtStarting_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtStarting_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtStarting_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtStarting_dt) == false)
            {
                Header.dtStarting_dt = Header.Tag.dtStarting_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtStarting_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskStarting_dt_Changed()
        {
            if (Header.mskStarting_dt == Header.Tag.mskStarting_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskStarting_dt) == false)
            {
                Header.mskStarting_dt = Header.Tag.mskStarting_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskStarting_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool txtCustomer_cd_Changed()
        {
            Header.txtCustomer_cd = modCommonUtility.CleanCode(Header.txtCustomer_cd);

            if (Header.txtCustomer_cd == Header.Tag.txtCustomer_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (txtCustomer_cd_Verified() == false)
            {
                Header.txtCustomer_cd = Header.Tag.txtCustomer_cd;
                FormSetFocus("txtCustomer_cd");
                return false;
            }

            if (moUtility.IsNonEmpty(Header.txtKey_id))
            {
                cboSalesrep_cd_Clicked();
                msOriginalTax_cd = Header.cboTax_cd;
            }

            return FormPostEvent();
        }

        private bool cboTax_cd_Clicked()
        {
            if (Header.cboTax_cd == Header.Tag.cboTax_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (cboTax_cd_Verified() == false)
            {
                Header.cboTax_cd = Header.Tag.cboTax_cd;
                FormSetFocus("cboTax_cd");
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdShowShipTo_Clicked()
        {
            FormPreEvent();                                                                   

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            modLoadUtility.LoadShipToCode(ref moDatabase, ref ShipToCodeList, Header.txtCustomer_cd);
            mbShowShipTo_fl = true;

            return FormPostEvent();
        }

        private bool cboShipTo_cd_Clicked()
        {
            if (Header.cboShipTo_cd == Header.Tag.cboShipTo_cd)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (cboShipTo_cd_Verified() == false)
            {
                Header.cboShipTo_cd = Header.Tag.cboShipTo_cd;
                FormSetFocus("cboShipTo_cd");
                return false;
            }

            return FormPostEvent();
        }

        private bool chkUseScanner_fl_Clicked()
        {
            FormPreEvent();

            //// boolean click event kickes in before the value is changed 
            //// so that we need to handle this according to the previous value.
            ////
            //chkDisableDescription_fl = (chkUseScanner_fl == false);
            //chkDisablePrice_fl = (chkUseScanner_fl == false);
            //chkDisableQty_fl = (chkUseScanner_fl == false);
            //chkDisableUnit_fl = (chkUseScanner_fl == false);

            // Instead, tab stop is disabled.
            //chkDisableJob_fl = (chkUseScanner_fl == false);
            //chkDisableTax_fl = (chkUseScanner_fl == false);
            //chkDisableAccount_fl = (chkUseScanner_fl == false);

            return FormPostEvent();
        }

        private bool cmdCalculateFreight_Clicked()
        {
            FormPreEvent();

            cmdCalculateFreight_Verified();

            return FormPostEvent();
        }

        private bool txtFreight_amt_Changed()
        {
            if (moMoney.ToNumMoney(Header.txtFreight_amt) > 0)
            {
                Header.txtFreight_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.txtFreight_amt));
            }
            else
            {
                Header.txtFreight_amt = "";
            }

            if (Header.txtFreight_amt == Header.Tag.txtFreight_amt)
            {
                return true;
            }

            FormPreEvent();

            if (txtFreight_amt_Verified() == false)
            {
                Header.txtFreight_amt = Header.Tag.txtFreight_amt;
                return false;
            }

            return FormPostEvent();
        }

        private bool txtWeight_Changed()
        {
            if (moUtility.ToValue(Header.txtWeight) > 0)
            {
                Header.txtWeight = Math.Abs(moUtility.ToValue(Header.txtWeight)).ToString();
            }
            else
            {
                Header.txtWeight = "";
            }

            FormPreEvent();

            return FormPostEvent();
        }

        private bool txtOrder_num_Changed()
        {
            if (moUtility.ToInteger(Header.txtOrder_num) > 0)
            {
                Header.txtOrder_num = moUtility.ToInteger(Header.txtOrder_num).ToString();
            }
            else
            {
                Header.txtOrder_num = "";
            }

            if (Header.txtOrder_num == Header.Tag.txtOrder_num)
            {
                return true;
            }

            FormPreEvent();

            if (txtOrder_num_Verified() == false)
            {
                // if moPage.bInDialog_fl ==  true, this is returned in dialog mode.
                //
                if (moPage.bInDialog_fl == false)
                {
                    Header.txtOrder_num = Header.Tag.txtOrder_num;
                }
                return false;
            }

            FormSyncDates(false);

            return FormPostEvent();
        }
        
        private bool cboSalesrep_cd_Clicked()
        {
            clsCommission.clsGrid grid_item = new clsCommission.clsGrid();

            if (Header.cboSalesrep_cd == Header.Tag.cboSalesrep_cd)
            {
                return true;
            }
            if (moUtility.IsEmpty(Header.cboSalesrep_cd))
            {
                moCommission.CreateGrid();
                return true;
            }

            FormPreEvent();

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moValidate.IsValidSalesrepCodeWithCommission(Header.cboSalesrep_cd) == false)
            {
                FormShowMessage(Header.cboSalesrep_cd + User.Language.oMessage.IS_INVALID);
                Header.cboSalesrep_cd = Header.Tag.cboSalesrep_cd;
                return false;
            }
            if (moCommission.FindGridLine(0, ref grid_item) == false)
            {
                FormShowMessage();
                Header.cboSalesrep_cd = Header.Tag.cboSalesrep_cd;
                return false;
            }

            grid_item.cboSalesrep_cd = Header.cboSalesrep_cd;

            if (moDatabase.bCalcCommissionByItem_fl)
            {
                grid_item.txtCommission_amt = "100";    // percent
                grid_item.cboCommission_typ = GlobalVar.goARConstant.SALES_PERCENT_COMM_NUM.ToString();      // just tentative.  This is not used in calculation
            }
            else
            {
                grid_item.txtCommission_amt = moMoney.ToStrMoney(moValidate.oRecordset.mField("fCommission_amt"));
                grid_item.cboCommission_typ = moValidate.oRecordset.iField("iCommission_typ").ToString();
            }

            return FormPostEvent();
        }

        private bool cmdGetJobExpenses_Clicked()
        {
            FormPreEvent();

            if (cmdGetJobExpenses_Verified() == false)
            {
                return false;
            }

            FormSwitchView(moView.JOB_EXPENSES_PAGE_NUM);

            return FormPostEvent();
        }

        private bool cmdPaymentSchedule_Clicked()
        {
            FormPreEvent();

            if (cmdPaymentSchedule_Verified() == false)
            {
                return false;
            }

            FormSwitchView(moView.PAYMENT_SCHEDULE_PAGE_NUM);

            return FormPostEvent();
        }

        private bool cmdCreatePaymentSchedule_Clicked()
        {
            FormPreEvent();

            if (cmdCreatePaymentSchedule_Verified() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdOKOnJobExpense_Clicked()
        {
            FormPreEvent();

            if (cmdOKOnJobExpense_Verified() == false)
            {
                return false;
            }

            FormSwitchView(moView.DETAIL_PAGE_NUM);

            return FormPostEvent();
        }

        private bool cmdCancelOnSearch_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return FormPostEvent();
        }

        private bool cmdCancelOnPrint_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return FormPostEvent();
        }

        private bool cmdOKOnPrint_Clicked()
        {
            if (moPage.bInDialog_fl == false)           // While in dialog, do not call FormPreEvent() which will remove the possible message displayed in printing process
            {
                FormPreEvent();
            }

            if (moUtility.ToInteger(cboReport_typ) == 0)
            {
                FormShowMessage(User.Language.oMessage.SELECT_ONE_OPTION);
                FormSetFocus("cboReport_typ");
                return false;
            }

            if (chkSendEmail_fl && moUtility.IsEmpty(txtEmailRecipient))
            {
                FormShowMessage(User.Language.oMessage.ENTER_EMAIL_ADDRESS);
                FormSetFocus("txtEmailRecipient");
                return false;
            }

            // This has to come before FormSave() because it is referrenced in concurrency check.
            //
            moPage.bInPrinting_fl = true;

            // Should save/print for the first time only.  When comming back from dialog, need to skip.
            //
            if (Modal.ReturningTo(3000) == false)
            {
                if (moUtility.ToInteger(Header.txtPrinted_num) == 0 || !moDatabase.uSecurity.bLockPrintedInvoice_fl)
                {

                    FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

                    if (optReportOption_typ == 1)
                    {
                        Header.txtPrinted_num = moUtility.ToStr(moUtility.ToInteger(Header.txtPrinted_num) + 1);
                    }

                    if (ReadOnly == false)
                    {
                        if (FormSave(true) == false)
                        {
                            Header.txtPrinted_num = moUtility.ToStr(moUtility.ToInteger(Header.txtPrinted_num) - 1);
                            moPage.bInPrinting_fl = false;
                            return false;
                        }
                    }
                }

                moPage.bNew_fl = false;

                if (FormPrint() == false)
                {
                    return false;
                }
            }

            if (FormDialog(cmdOKOnPrint_Clicked, 3000, User.Language.oMessage.IS_PRINTED_OK) == false)
            {
                moPage.bInPrinting_fl = false;
                return false;
            }

            moPage.bInPrinting_fl = false;

            FormSwitchView(moView.MAIN_PAGE_NUM);
            FormClear();

            return FormPostEvent();
        }

        private bool cmdCancelOnOrder_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.DETAIL_PAGE_NUM);

            return FormPostEvent();
        }

        private bool cmdOKOnOrder_Clicked()
        {
            FormPreEvent();

            if (moUtility.ToInteger(Header.txtOrder_num) > 0)
            {
                FormShowMessage(User.Language.oMessage.MULTI_ORDER_ENTRY_IS_NOT_ALLOWED_WITH_MAIN_ORDER_NUMBER);
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (AddMultiOrder() == false)
            {
                return false;
            }

            mbMultiOrder_fl = true;
            FormReArrangeHeader();

            FormCalculateTotal();

            cmdMultiOrderClear_Clicked();

            FormSwitchView(moView.DETAIL_PAGE_NUM);

            return FormPostEvent();
        }

        private bool cmdOKOnItemMatrix_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id) || moUtility.IsEmpty(Header.txtCustomer_cd))
            {
                FormSwitchView(moView.MAIN_PAGE_NUM);
                FormShowMessage(User.Language.oMessage.PLEASE_ENTER + User.Language.oCaption.TRANSACTION_NUM + "/" + User.Language.oCaption.CUSTOMER_CODE);
                return false;
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moItemMatrix.CreateDetailLinesFromMatrix(ref moDatabase, Header.txtMatrixItem_cd, Header.cboLocation_cd ) == false)
            {
                FormShowMessage();
                return false;
            }
            else if (CreateDetailLinesFromMatrix() == false)
            {
                FormRecreateGrid();         // Change back to original
                return false;
            }
            else
            {
                Header.txtMatrixItem_cd = "";
                Header.lblMatrixItemDescription = "";
                Header.txtMatrixUnitPrice_amt = "";
                Header.lblSystemUnitPrice_amt = "";
                moItemMatrix.Grid.Clear();
            }

            FormCalculateTotal();

            FormSwitchView(moView.DETAIL_PAGE_NUM);

            return FormPostEvent();
        }

        private bool cmdCancelOnItemMatrix_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.DETAIL_PAGE_NUM);

            return FormPostEvent();
        }

        private bool cmdMultiOrderClear_Clicked()
        {
            FormPreEvent();

            Header.txtMultiOrder_num = "";
            moMultiOrder.Grid.Clear();

            return FormPostEvent();
        }

        private bool txtMultiOrder_num_Changed()
        {
            if (moUtility.ToInteger(Header.txtMultiOrder_num) <= 0)
            {
                Header.txtMultiOrder_num = "";
            }
            else
            {
               Header.txtMultiOrder_num = moUtility.ToInteger(Header.txtMultiOrder_num).ToString();
            }

            if (Header.txtMultiOrder_num == Header.Tag.txtMultiOrder_num)
            {
                return true;
            }
            
            FormPreEvent();

            if (txtMultiOrder_num_Verified() == false)
            {
                // if moPage.bInDialog_fl ==  true, this is returned in dialog mode.
                //
                if (moPage.bInDialog_fl == false)
                {
                    Header.txtMultiOrder_num = Header.Tag.txtMultiOrder_num;
                }
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdPOSFind_Clicked()
        {
            txtPOSItem_cd_Changed();

            return true;
        }

        private bool txtPOSItem_cd_Changed()                                                // This is available only when scanner option is checked
        {
            Header.txtPOSItem_cd = modCommonUtility.CleanCode(Header.txtPOSItem_cd);

            if (Header.txtPOSItem_cd == Header.Tag.txtPOSItem_cd)
            {
                return FormPostEvent();
            }

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                Header.txtPOSItem_cd = "";
                FormSwitchView(moView.MAIN_PAGE_NUM);
                FormSetFocus("txtKey_id");
                return FormPostEvent();
            }

            if (moUtility.IsEmpty(Header.txtCustomer_cd))
            {
                Header.txtPOSItem_cd = "";
                FormSwitchView(moView.MAIN_PAGE_NUM);
                FormShowMessage(User.Language.oMessage.PLEASE_ENTER + User.Language.oCaption.CUSTOMER_CODE);
                FormSetFocus("txtCustomer_cd");
                return FormPostEvent();
            }

            if (moUtility.IsEmpty(Header.cboLocation_cd))
            {
                Header.txtPOSItem_cd = "";
                FormSwitchView(moView.MAIN_PAGE_NUM);
                FormShowMessage(User.Language.oMessage.PLEASE_ENTER + User.Language.oCaption.LOCATION_CODE);
                FormSetFocus("cboLocation_cd");
                return FormPostEvent();
            }

            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moUtility.IsNonEmpty(Header.txtPOSItem_cd))
            {
                txtPOSItem_cd_Verified();
                FormCalculateTotal();
            }

            Header.txtPOSItem_cd = "";
            FormSetFocus("txtPOSItem_cd");

            return FormPostEvent();
        }

        private bool txtMatrixItem_cd_Changed()
        {
            Header.txtMatrixItem_cd = modCommonUtility.CleanCode(Header.txtMatrixItem_cd);

            if (Header.txtMatrixItem_cd == Header.Tag.txtMatrixItem_cd)
            {
                return true;
            }

            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtMatrixItem_cd))
            {
                Header.lblSystemUnitPrice_amt = "";
                Header.lblMatrixItemDescription = "";
                Header.txtMatrixUnitPrice_amt = "";
            }
            else if (txtMatrixItem_cd_Verified() == false)
            {
                Header.txtMatrixItem_cd = Header.Tag.txtMatrixItem_cd;
                return false;
            }

            return FormPostEvent();
        }

        private bool btnZoomOnMatrixItem_cd_Clicked()
        {
            string where_clause = "iItem_typ >= " + GlobalVar.goIVConstant.SUMMARY_SALES_ITEM_TYPES.ToString();

            FormPreEvent();

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtMatrixItem_cd", -1, -1, moView.MAIN_PAGE_NUM, "sItem_cd", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");  //should not happen
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }


        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Verified()
        {
            bool return_value = false;
            clsRecordset cur_set;
            string key_id = "";

            try
            {
                if (moUtility.ToInteger(Header.txtKey_id) > 0)
                {
                    Header.txtKey_id = moUtility.ToInteger(Header.txtKey_id).ToString();
                }
                else
                {
                    Header.txtKey_id = "";
                }

                key_id = Header.txtKey_id;

                if (Header.txtKey_id == Header.Tag.txtKey_id)
                {
                    return true;
                }
                else if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormClear();
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    FormClear();
                    FormShowMessage(User.Language.oMessage.CONNECTION_HAS_FAILED);
                    return false;
                }

                cur_set = new clsRecordset(ref moDatabase);

                if (FormFindRecord(ref cur_set))
                {
                    FormShow(cur_set);
                }
                else
                {
                    if (chkAfterFact_fl == false || moUtility.IsSalesStaff(moDatabase))
                    {
                        cmdNew_Clicked();
                        FormShowMessage(key_id + User.Language.oMessage.IS_NOT_FOUND);
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtKey_id_Verified)");
            }

            return return_value;
        }

        private bool txtCustomer_cd_Verified()
        {
            bool return_value = false;


            try
            {
                if (moUtility.IsNonEmpty(Header.txtCustomer_cd))
                {
                    if (FormOpenDatabase() == false)
                    {
                        return false;
                    }

                    if (moCustomer.GetCustomer(Header.txtCustomer_cd, true, "", true) == false)
                    {
                        if (moDatabase.IsErrorFound())
                        {
                            FormShowMessage();
                        }
                        else
                        {
                            FormShowMessage(Header.txtCustomer_cd + User.Language.oMessage.IS_INVALID);
                        }
                        Header.txtCustomer_cd = "";
                        return false;
                    }

                    // If the invoice numberring is by job, we need to populate this so that user can select one for new invoice number.
                    // This should come before moUtility.IsEmpty(Header.txtKey_id) is checked for exit.
                    //
                    modLoadUtility.LoadJobCode(ref moDatabase, ref JobCodeList, Header.txtCustomer_cd);

                    if (moUtility.IsEmpty(Header.txtKey_id))
                    {
                        // Working in search mode
                        return true;
                    }
                    else if (moCustomer.IsValidForTransaction(moPage.iTransaction_typ) == false)
                    {
                        FormShowMessage(Header.txtCustomer_cd + User.Language.oMessage.IS_INVALID_FOR_THIS_TRX);
                        Header.txtCustomer_cd = "";
                        return false;
                    }
                    else
                    {
                        Header.txtCustomer_nm = moCustomer.sCustomer_nm;
                        Header.txtCustomerAttn = moCustomer.sAttention_nm;
                        Header.txtCustomerAddress1 = moCustomer.sAddress1;
                        Header.txtCustomerAddress2 = moCustomer.sAddress2;
                        Header.txtCustomerAddress3 = moCustomer.sAddress3;
                        Header.cboTax_cd = moCustomer.sTax_cd;
                        Header.cboPosting_cd = moCustomer.sPosting_cd;
                        Header.cboTerms_cd = moCustomer.sTerms_cd;
                        Header.cboSalesrep_cd = moCustomer.sSalesrep_cd;
                        Header.cboPrice_cd = moCustomer.sPrice_cd;
                        Header.cboVia_cd = moCustomer.sVia_cd;
                        Header.chkDropShipment_fl = (moCustomer.iDropShipCustomer_fl == GlobalVar.goConstant.FLAG_ON);

                        Header.txtShipTo_cd = moCustomer.sShipTo_cd;
                        Header.txtShipTo_nm = moCustomer.sShipTo_nm;
                        Header.txtShipToAttn = moCustomer.sShipToAttention_nm;
                        Header.txtShipToAddress1 = moCustomer.sShipToAddress1;
                        Header.txtShipToAddress2 = moCustomer.sShipToAddress2;
                        Header.txtShipToAddress3 = moCustomer.sShipToAddress3;
                        Header.txtShipToCity = moCustomer.sShipToCity;
                        Header.txtShipToState = moCustomer.sShipToState;
                        Header.txtShipToZipCode = moCustomer.sShipToZipCode;
                        Header.txtShipToCountry_cd = moCustomer.sShipToCountry_cd;
                        Header.txtShipToPhone = moCustomer.sShipToPhone;
                        Header.txtShipToFax = moCustomer.sShipToFax;
                        Header.cboFOB_cd = moCustomer.sFob_cd;

                        FormCheckExchangeRate();

                        if (moDatabase.uProgram.bGLExist_fl && moUtility.IsNonEmpty(Header.cboTax_cd))
                        {
                            if (moValidate.IsValidARTaxCode(Header.cboTax_cd))
                            {
                                if (moValidate.oRecordset.iField("iTax_typ") == GlobalVar.goConstant.REGULAR_TAX_NUM)
                                {
                                    Header.txtTax_pc = moValidate.oRecordset.mField("fTotalTax_pc").ToString();
                                }
                                else
                                {
                                    Header.txtTax_pc = (-moValidate.oRecordset.mField("fTotalTax_pc")).ToString(); // Included-Tax
                                }
                            }
                            else
                            {
                                Header.txtTax_pc = "0";
                                Header.cboTax_cd = "";
                            }
                        }
                        else
                        {
                            Header.txtTax_pc = "0";
                        }

                        mbShowShipTo_fl = false;
                        msOriginalTax_cd = Header.cboTax_cd;

                        //if (false == modCommissionUtility.GetSalespersonCommission(ref moDatabase, ref grdCommission, moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id), COMMISSION_SALESREP_CODE_COL, COMMISSION_AMOUNT_COL, COMMISSION_TYPE_COL, ref moWebDropdownList, ref Header.cboSalesrep_cd))
                        //{
                        //    FormShowMessage();
                        //}

                    }

                }

                Header.cboLocation_cd = moGeneral.GetDefaultLocationCode(Header.txtCustomer_cd);
                moValidate.oRecordset.Release();
                FormReArrangeHeader();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtCustomer_cd_Verified)");
            }

            return return_value;
        }

        private bool cboShipTo_cd_Verified()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.cboShipTo_cd))
                {
                    return true;
                }
                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                if (moValidate.IsValidCustomerCode(Header.cboShipTo_cd) ==  false)
                {
                    FormShowMessage(Header.cboShipTo_cd + User.Language.oMessage.IS_INVALID);
                    return false;
                }
                else
                {
                    Header.txtShipTo_nm = moValidate.oRecordset.sField("sCustomer_nm");
                    Header.txtShipToAddress1 = moValidate.oRecordset.sField("sAddress1");
                    Header.txtShipToAddress2 = moValidate.oRecordset.sField("sAddress2");
                    Header.txtShipToAddress3 = moValidate.oRecordset.sField("sAddress3");
                    Header.txtShipToCity = moValidate.oRecordset.sField("sCity");
                    Header.txtShipToState = moValidate.oRecordset.sField("sState");
                    Header.txtShipToZipCode = moValidate.oRecordset.sField("sZipCode");
                    Header.txtShipToCountry_cd = moValidate.oRecordset.sField("sCountry_cd");
                    Header.txtShipToPhone = moValidate.oRecordset.sField("sPhone1");
                    Header.txtShipToFax = moValidate.oRecordset.sField("sFax");
                }

                moValidate.Release();
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (cboShipTo_cd_Verified)");
            }

            return return_value;
        }

        private bool cboTax_cd_Verified()
        {
            bool return_value = false;


            try
            {
                if (moUtility.IsEmpty(Header.cboTax_cd))
                {
                    Header.txtTax_pc = "0";
                }
                else if (FormOpenDatabase() == false)
                {
                    return false;
                }
                else if (moValidate.IsValidARTaxCode(Header.cboTax_cd))
                {

                    if (moValidate.oRecordset.iField("iTax_typ") == GlobalVar.goConstant.REGULAR_TAX_NUM)
                    {
                        Header.txtTax_pc = moValidate.oRecordset.mField("fTotalTax_pc").ToString();
                    }
                    else
                    {
                        Header.txtTax_pc = (-moValidate.oRecordset.mField("fTotalTax_pc")).ToString(); // Included-Tax
                    }

                }

                RecalculateTax(msOriginalTax_cd);
                msOriginalTax_cd = Header.cboTax_cd;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (cboTax_cd_Verified)");
            }

            return return_value;
        }


        private bool cmdCalculateFreight_Verified()
        {
            bool return_value = false;
            int i = 0;
            decimal qty = 0;
            decimal freight_amt = 0;

            try
            {
                if (moDatabase.iFreightCalculation_typ == modConstant.FREIGHT_BY_UPS_NUM)
                {
                    return true;
                }
                else
                {
                    if (FormOpenDatabase() == false)
                    {
                        return false;
                    }

                    if (moUtility.IsEmpty(Header.cboVia_cd))
                    {
                        FormShowMessage(User.Language.oMessage.ENTER_SHIPPING_VIA_CODE);
                        return false;
                    }
                    else if (moDatabase.iFreightCalculation_typ == modConstant.FREIGHT_BY_WEIGHT_NUM)
                    {
                        Header.txtFreight_amt = moMoney.ToStrMoney(moGeneral.CalculateFreight(Header.cboVia_cd, moUtility.ToValue(Header.txtWeight)));
                    }
                    else if (moDatabase.iFreightCalculation_typ == modConstant.FREIGHT_BY_PRICE_NUM)
                    {
                        Header.txtFreight_amt = moMoney.ToStrMoney(moGeneral.CalculateFreight(Header.cboVia_cd, moMoney.ToNumMoney(Header.txtTaxable_amt) + moMoney.ToNumMoney(Header.txtNonTaxable_amt)));
                    }
                    else //If moDatabase.iFreightCalculation_typ = FREIGHT_BY_QUANTITY_NUM Then
                    {
                        qty = 0;
                        for (i = 0; i < moDetail.Data.GetLength(1) - 1; i++)
                        {
                            if (moUtility.IsNonEmpty(moDetail.Data[Models.clsChargeDetail.ITEM_CODE_COL, i]) && moUtility.ToValue(moDetail.Data[Models.clsChargeDetail.QTY_IN_IVUNIT_COL, i]) > 0)
                            {
                                qty += moUtility.ToValue(moDetail.Data[Models.clsChargeDetail.QTY_IN_IVUNIT_COL, i]);
                            }
                        }
                        Header.txtFreight_amt = moMoney.ToStrMoney(moGeneral.CalculateFreight(Header.cboVia_cd, qty));
                    }

                    txtFreight_amt_Changed();
                }

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "cmdCalculateFreight_Verified");
            }

            return return_value;
        }

        private bool txtFreight_amt_Verified()
        {

            if (moMoney.ToNumMoney(Header.txtFreight_amt) < 0)
            {
                FormShowMessage(User.Language.oMessage.NEGATIVE_AMOUNT_IS_NOT_ALLOWED);
                return false;
            }
            else if (moMoney.ToNumMoney(Header.txtFreight_amt) == 0)
            {
                Header.txtFreight_amt = "";
                Header.txtFreightTax_amt = "";
            }
            else
            {
                Header.txtFreight_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.txtFreight_amt));
            }

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return true; // Working in Search mode
            }

            FormCalculateTotal(); // DO NOT USE CalculateDueAmount because the taxes need to be recalculated

            return true;
        }

        private bool txtOrder_num_Verified()
        {
            bool return_value = false;

            clsRecordset cur_set = new clsRecordset(ref moDatabase);
            clsRecordset order_set = new clsRecordset(ref moDatabase);
            clsRecordset detail_set = new clsRecordset(ref moDatabase);
            clsWarehouseSlip o_wh_slip = new clsWarehouseSlip(ref moDatabase);
            string sql_str = null;
            bool from_packing_slip_fl = false;
            bool copy_all_fl = false;

            try
            {

                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    return true;    // in search mode
                }

                if (moUtility.ToInteger(Header.txtOrder_num) == 0)
                {
                    foreach (var det in moDetail.Grid)
                    {
                        det.lblOrder_num = "";
                        moDetail.Data[Models.clsChargeDetail.ORDER_NUM_COL, det.Row_num] = "";
                    }

                    mbFromPackingSlip_fl = false;
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                // User can bring up an existing invoice and delete the order number and enter the same number again.  We need to stop it.
                //
                sql_str = "SELECT iTransaction_num FROM tblARChargeUnposted";
                sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_INVOICE_TYPE;
                sql_str += " AND iOrder_num = " + Header.txtOrder_num;
                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (cur_set.EOF() == false)
                {
                    if (moUtility.ToInteger(Header.txtKey_id) == cur_set.iField("iTransaction_num"))
                    {
                        FormShowMessage("You cannot delete this order number and enter it again.  Please, bring up the original invoice.");
                        return false;
                    }
                    //else          01/272024  Not necessary. Warning is given down below
                    //{
                    //    FormShowMessage(User.Language.oMessage.INVOICE_EXIST_WITH_THIS_SO + " " + cur_set.iField("iTransaction_num") + ".");
                    //}

                    //return false;
                }

                order_set = new clsRecordset(ref moDatabase);

                sql_str = modConstant.ORDER_DYNASET + " AND iTransaction_num = " + moUtility.ToInteger(Header.txtOrder_num).ToString();

                if (order_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (order_set.EOF())
                {
                    FormShowMessage(Header.txtOrder_num + User.Language.oMessage.IS_INVALID);
                    return false;
                }
                if (order_set.iField("iJournal_typ") > 0)
                {
                    FormShowMessage(User.Language.oMessage.REPLACEMENT_ORDER_IS_NOT_ALLOWED);
                    return false;
                }

                // Foreign currency is not allowed.
                //
                if (moUtility.IsNonEmpty(order_set.sField("sCurrency_cd")) && moDatabase.sCurrency_cd != order_set.sField("sCurrency_cd"))
                {
                    FormShowMessage(User.Language.oMessage.FOREIGN_TRANSACTION_IS_NOT_ALLOWED);
                    return false;
                }

                if (moUtility.IsSalesStaff(moDatabase) && order_set.sField("sSalesrep_cd") != moDatabase.sUser_cd)
                {
                    FormShowMessage(Header.txtOrder_num + User.Language.oMessage.IS_NOT_ACCESSIBLE);
                    return false;
                }

                miOrder_typ = order_set.iField("iOrder_typ");

                // If "iToBeInvoiced_num" = 0, then remind the user of the total
                // number invoiced and proceed.
                //
                if (order_set.iField("iToBeInvoiced_num") <= 0)
                {
                    // If iInvoiced_num > 0, then this order has been invoiced iInvoiced_num times.
                    //
                    if (order_set.iField("iInvoiced_num") > 0)
                    {
                        if (FormDialog(txtOrder_num_Changed, 1000, User.Language.oMessage.ORDER_HAS_BEEN_INVOICED + " (" + order_set.iField("iInvoiced_num").ToString() + ") " + User.Language.oString.STR_TIMES + User.Language.oMessage.WOULD_LIKE_PROCEED) == false)
                        {
                            return false;
                        }

                        copy_all_fl = false;
                    }
                }
                else
                {
                    copy_all_fl = true;
                }

                mbMultiOrder_fl = false;
                mbFromPackingSlip_fl = false;
                from_packing_slip_fl = false;
                detail_set = new clsRecordset(ref moDatabase);

                if (!moGeneral.GetOrderForBilling(ref order_set, ref detail_set, GlobalVar.goConstant.TRX_INVOICE_TYPE, moUtility.ToInteger(Header.txtKey_id), moUtility.ToInteger(Header.txtOrder_num), ref from_packing_slip_fl, false, copy_all_fl, true))
                {
                    FormShowMessage();
                    return false;
                }
                else if (detail_set.EOF())
                {
                    FormShowMessage(User.Language.oMessage.MERCHANDISE_HAS_NOT_BEEN_SHIPPED_YET);
                    return false;
                }

                mbFromPackingSlip_fl = from_packing_slip_fl;

                CopyOrderToInvoice(ref order_set, detail_set, moUtility.ToInteger(Header.txtOrder_num));

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtOrder_num_Verified)");
            }

            return return_value;
        }

        private bool cmdGetJobExpenses_Verified()
        {
            bool return_value = false;
            string[,] expense_data = null;
            int row_num = 0;
            int max_num = 0;
            clsJobCost.clsGrid grid_line = new clsJobCost.clsGrid();

            try
            {

                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_THE_INVOICE_NUMBER);
                    return false;
                }
                else if (moDatabase.uProgram.bJCExist_fl == false)
                {
                    FormShowMessage(User.Language.oMessage.JOB_COST_MODULE_IS_NOT_LINKED);
                    return false;
                }
                else if (moMoney.ToNumMoney(Header.txtOrder_num) > 0)
                {
                    FormShowMessage(User.Language.oMessage.THIS_IS_NOT_ALLOWED_FOR_AN_INVOICE_WITH_ORDER_NUMBER);
                    return false;
                }
                else if (moUtility.IsEmpty(Header.txtCustomer_cd))
                {
                    FormShowMessage(User.Language.oMessage.ENTER_CUST_CODE_FIRST);
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboStatus_typ))
                {
                    FormShowMessage(User.Language.oMessage.SELECT_STATUS_TYPE);
                    return false;
                }
                else if (moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.HOLD_TRX_NUM || moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.VOID_TRX_NUM)
                {
                    FormShowMessage(User.Language.oMessage.THIS_IS_NOT_ALLOWED_FOR_AN_INVOICE_WITH_THIS_STATUS_TYPE);
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboJob_cd))
                {
                    FormShowMessage(User.Language.oMessage.ENTER_JOB_CODE_FIRST);
                    return false;
                }

                moJobCost.Grid.Clear();

                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                if (moJobCost.GetCustomerJobExpenses(Header.txtCustomer_cd, ref expense_data, Header.cboJob_cd) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (expense_data == null)
                {
                    FormShowMessage(User.Language.oMessage.NO_RECORDS_FOUND);
                    return false;
                }
                else if (expense_data.GetLength(1) == 0)
                {
                    FormShowMessage(User.Language.oMessage.NO_RECORDS_FOUND);
                    return false;
                }

                for (max_num = expense_data.GetUpperBound(1) ; max_num >= 0; max_num--)
                {
                    if (moUtility.IsNonEmpty(expense_data[clsJobCost.APPLY_DATE_COL, max_num]) && moUtility.IsNonEmpty(expense_data[clsJobCost.TRANS_NUM_COL, max_num]))
                    {
                        break;
                    }
                }
                    
                if (max_num < 0)
                {
                    FormShowMessage(User.Language.oMessage.NO_RECORDS_FOUND);
                    return true;
                }

                moJobCost.CreateGrid(max_num + 1);

                for (row_num = 0; row_num <= max_num; row_num++)
                {
                    grid_line = new clsJobCost.clsGrid();
                    if (moJobCost.FindGridLine(row_num, ref grid_line))
                    {
                        grid_line.chkInclude_fl = false;
                        grid_line.lblApply_dt = expense_data[clsJobCost.APPLY_DATE_COL, row_num];
                        grid_line.lblJob_cd = expense_data[clsJobCost.JOB_CODE_COL, row_num];
                        grid_line.lblTransactionText = expense_data[clsJobCost.TRANS_STRING_TYPE_COL, row_num];
                        grid_line.lblTransaction_num = expense_data[clsJobCost.TRANS_NUM_COL, row_num];
                        grid_line.lblItem_cd = expense_data[clsJobCost.ITEM_CODE_COL, row_num];
                        grid_line.lblDescription = expense_data[clsJobCost.DESCRIPTION_COL, row_num];
                        grid_line.lblUnit_cd = expense_data[clsJobCost.UNIT_CODE_COL, row_num];
                        grid_line.lblQuantity = expense_data[clsJobCost.QTY_COL, row_num];
                        grid_line.lblUnitPrice_amt = expense_data[clsJobCost.UNIT_PRICE_COL, row_num];
                        grid_line.lblExpense_amt = expense_data[clsJobCost.EXPENSE_AMT_COL, row_num];
                        grid_line.lblDocument_num = expense_data[clsJobCost.DOCUMENT_COL, row_num];
                        grid_line.lblOurReference = expense_data[clsJobCost.OUR_REFERENCE_COL, row_num];
                        grid_line.lblYourReference = expense_data[clsJobCost.YOUR_REFERENCE_COL, row_num];
                        grid_line.lblUser_cd = expense_data[clsJobCost.USER_COL, row_num];
                        grid_line.lblTransaction_typ = expense_data[clsJobCost.TRANS_TYPE_COL, row_num];
                        grid_line.lblDetail_num = expense_data[clsJobCost.DETAIL_NUM_COL, row_num];
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (cmdGetJobExpenses_Click_Verified)");
            }

            return return_value;
        }

        private bool cmdPaymentSchedule_Verified()
        {
            bool return_value = false;
            string discount_date = "";
            decimal discount_amt = 0;
            clsPaymentSchedule.clsGrid grid_item;

            try
            {

                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_THE_INVOICE_NUMBER);
                    return false;
                }
                else if (moUtility.STrim(Header.txtCustomer_cd) == "")
                {
                    FormShowMessage(User.Language.oMessage.ENTER_CUST_CODE_FIRST);
                    return false;
                }
                else if (moUtility.IsEmpty(Header.cboStatus_typ))
                {
                    FormShowMessage(User.Language.oMessage.SELECT_STATUS_TYPE);
                    return false;
                }
                else if (moUtility.ToInteger(Header.cboStatus_typ) != GlobalVar.goConstant.OPEN_TRX_NUM)
                {
                    FormShowMessage(User.Language.oMessage.THIS_IS_NOT_ALLOWED_FOR_AN_INVOICE_WITH_THIS_STATUS_TYPE);
                    return false;
                }

                // If created by other page, do not proceed
                //
                if (miSource_typ != 0 && miSource_num != 0)
                {
                    return true;
                }

                if (moPaymentSchedule.Grid.Count == 0)
                {
                    moPaymentSchedule.CreateGrid(10);
                }

                // Single payment schedule STRICTLY goes by the invoice date and term.
                //
                grid_item = new clsPaymentSchedule.clsGrid();
                if (moPaymentSchedule.FindGridLine(1, ref grid_item))
                {

                    // If the second line is empty, place the total amount and the default due date on the first line.
                    //
                    if (moUtility.IsEmpty(grid_item.txtDue_dt) || moMoney.ToNumMoney(grid_item.txtDue_amt) == 0)
                    {
                        if (FormOpenDatabase() == false)
                        {
                            return false;
                        }

                        if (moValidate.IsValidARTermsCode(Header.cboTerms_cd))
                        {
                            Header.mskDue_dt = moGeneral.ToStrDate(moUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, moGeneral.ToNumDate(Header.mskApply_dt), moValidate.oRecordset.iField("iDueDays")));
                            discount_date = moGeneral.ToStrDate(moUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, moGeneral.ToNumDate(Header.mskApply_dt), moValidate.oRecordset.iField("iDiscountDays")));
                            discount_amt = moGeneral.CalculatePaymentDiscount(moMoney.ToNumMoney(Header.txtTaxable_amt) + moMoney.ToNumMoney(Header.txtNonTaxable_amt), moMoney.ToNumMoney(Header.txtTax_amt)
                                , moMoney.ToNumMoney(Header.txtFreightTax_amt), moMoney.ToNumMoney(Header.txtFreight_amt), moValidate.oRecordset.mField("fDiscount_pc"), (moUtility.ToValue(Header.txtTax_pc) < 0));
                            FormSyncDates(false);
                        }
                        else // not expected at all
                        {

                            FormShowMessage(User.Language.oString.STR_TERMS_CODE + User.Language.oMessage.IS_INVALID);
                            return false;

                        }

                        // Place the total amount and the default due date on the first line.
                        //
                        if (moPaymentSchedule.FindGridLine(0, ref grid_item))
                        {
                            grid_item.txtDue_dt = Header.mskDue_dt;
                            grid_item.txtDue_amt = Header.txtTotal_amt;
                            grid_item.txtDiscount_dt = discount_date;
                            grid_item.txtDiscount_amt = moMoney.ToStrMoney(discount_amt);
                        }
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (cmdPaymentSchedule_Verified)");
            }

            return return_value;
        }

        private bool cmdCreatePaymentSchedule_Verified()
        {
            bool return_value = false;
            string[,] detail_data = null;

            try
            {
                if (moMoney.ToNumMoney(Header.txtTotal_amt) <= 0)
                {
                    moPaymentSchedule.CreateGrid();
                    return true;
                }

                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    return false;
                }
                else if (moUtility.IsEmpty(Header.mskApply_dt))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER_DATE_APPLIED);
                    return false;
                }
                else if (moUtility.ToInteger(Header.txtSplit_num) == 0 || moUtility.IsEmpty(Header.cboInterval_typ))
                {
                    FormShowMessage("Please, enter the number of payments and interval.");
                    return false;
                }

                if (moUtility.IsEmpty(Header.mskStarting_dt))
                {
                    Header.mskStarting_dt = Header.mskApply_dt;
                }

                moUtility.ResizeDim(ref detail_data, GlobalVar.goConstant.SPLIT_PAYMENT_TOTAL_DETAIL_COL - 1, 0);

                if (moPaymentSchedule.CreateSchedule(ref moDatabase, ref detail_data, moPage.iTransaction_typ, moMoney.ToNumMoney(Header.txtTotal_amt)
                    , moUtility.ToInteger(Header.txtSplit_num), moUtility.ToInteger(Header.cboInterval_typ), moGeneral.ToNumDate(Header.mskStarting_dt)) == false)
                {
                    FormShowMessage();
                    return false;
                }
                else if (moPaymentSchedule.RecreateGrid(detail_data) == false)
                {
                    FormShowMessage(moPaymentSchedule.GetErrorMessage());
                    return false;
                }

                CalculatePaymentSchedule();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (cmdCreatePaymentSchedule_Verified)");
            }

            return return_value;
        }

        private bool cmdOKOnJobExpense_Verified()
        {
            bool return_value = false;
            int max_row = 0;
            int row_num = 0;
            int active_row = 0;
            Models.clsChargeDetail.clsGrid det_grid;

            try
            {
                foreach (var det in moJobCost.Grid)
                {
                    if (det.chkInclude_fl)
                    {
                        max_row += 1;
                    }
                }

                if (max_row == 0)
                {
                    FormShowMessage(User.Language.oMessage.NO_RECORDS_FOUND);
                    return false;
                }

                active_row = GetStartingRowInMainTable();

                FormAddMoreRows(max_row);

                foreach (var jc in moJobCost.Grid)
                {
                    if (jc.chkInclude_fl)
                    {
                        if (moUtility.IsNonEmpty(jc.lblJob_cd))
                        {
                            det_grid = new Models.clsChargeDetail.clsGrid();

                            if (moDetail.FindGridLine(active_row, ref det_grid))
                            {
                                //det_grid.txtItem_cd = jc.lblItem_cd;          Inventory item type is not accepted
                                //DetailItem_cd_Changed(det_grid);

                                det_grid.txtUnit_cd = jc.lblUnit_cd;
                                DetailUnit_cd_Changed(det_grid);

                                if (moUtility.ToValue(jc.lblQuantity) > 0)
                                {
                                    det_grid.txtShipped_qty = jc.lblQuantity;
                                }
                                else
                                {
                                    det_grid.txtShipped_qty = "1";
                                }
                                DetailShipped_qty_Changed(det_grid);

                                if (moMoney.ToNumMoney(jc.lblUnitPrice_amt) > 0)
                                {
                                    det_grid.txtUnitPrice_amt = jc.lblUnitPrice_amt;
                                }
                                else 
                                {
                                    det_grid.txtUnitPrice_amt = jc.lblExpense_amt;
                                }
                                DetailUnitPrice_amt_Changed(det_grid);

                                det_grid.cboJob_cd = jc.lblJob_cd;
                                det_grid.lblExpense_typ = jc.lblTransaction_typ;
                                det_grid.lblExpense_num = jc.lblTransaction_num;
                                det_grid.lblExpenseDetail_num = jc.lblDetail_num;

                                if (moUtility.IsNonEmpty(jc.lblItem_cd))
                                {
                                    det_grid.txtDescription = moUtility.SLeft(jc.lblItem_cd + " : " + jc.lblDescription, moUtility.ToInteger(Models.Length.COMMENT));
                                }
                                else
                                {
                                    det_grid.txtDescription = jc.lblDescription;
                                }
                                active_row += 1;
                            }
                        }
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (cmdOKOnJobExpense_Verified)");
            }

            return return_value;
        }

        private bool txtMultiOrder_num_Verified()
        {
            bool return_value = false;
            string sql_str = "";
            bool from_packing_slip_fl = false;
            bool copy_all_fl = false;
            bool first_order_fl = false;

            clsRecordset order_set;
            clsRecordset detail_set;
            clsWarehouseSlip o_wh_slip;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormShowMessage(User.Language.oMessage.ENTER_TRX_NUM_FIRST);
                    return false;
                }
                else if (moUtility.IsEmpty(Header.txtCustomer_cd))
                {
                    FormShowMessage(User.Language.oMessage.ENTER_CUST_CODE_FIRST);
                    return false;
                }
                else if (moUtility.ToInteger(Header.txtOrder_num) > 0)
                {
                    FormShowMessage(User.Language.oMessage.MULTI_ORDER_ENTRY_IS_NOT_ALLOWED_WITH_MAIN_ORDER_NUMBER);
                    return false;
                }

                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                order_set = new clsRecordset(ref moDatabase);
                detail_set = new clsRecordset(ref moDatabase);
                o_wh_slip = new clsWarehouseSlip(ref moDatabase);

                sql_str = modConstant.ORDER_DYNASET + " AND iTransaction_num = " + moUtility.ToInteger(Header.txtMultiOrder_num).ToString();
                sql_str += " AND sCustomer_cd = '" + Header.txtCustomer_cd + "'";

                if (!order_set.CreateSnapshot(sql_str))
                {
                    FormShowMessage(order_set.GetErrorMessage());
                    return false;
                }
                else if (order_set.EOF())
                {
                    FormShowMessage(Header.txtMultiOrder_num + User.Language.oMessage.IS_INVALID);
                    return false;
                }

                // Foreign currency is not allowed.
                //
                if (moUtility.IsNonEmpty(order_set.sField("sCurrency_cd")) && moDatabase.sCurrency_cd != order_set.sField("sCurrency_cd"))
                {
                    FormShowMessage(User.Language.oMessage.FOREIGN_TRANSACTION_IS_NOT_ALLOWED);
                    return false;
                }

                miOrder_typ = order_set.iField("iOrder_typ");

                // If "iToBeInvoiced_num" = 0, then remind the user of the total
                // number invoiced and proceed.
                //
                if (order_set.iField("iToBeInvoiced_num") <= 0)
                {
                    // If iInvoiced_num > 0, then this order has been invoiced
                    // iInvoiced_num times.
                    //
                    if (order_set.iField("iInvoiced_num") > 0)
                    {
                        if (FormDialog(txtMultiOrder_num_Changed, 1000, User.Language.oMessage.ORDER_HAS_BEEN_INVOICED + " (" + order_set.iField("iInvoiced_num").ToString() + ") " + User.Language.oString.STR_TIMES + User.Language.oMessage.WOULD_LIKE_PROCEED) == false)
                        {
                            return false;
                        }

                        copy_all_fl = false;
                    }
                }
                else
                {
                    copy_all_fl = true;
                }

                first_order_fl = true;

                foreach (var det in moDetail.Grid)
                {
                    if (moUtility.ToInteger(det.lblOrder_num) > 0)
                    {
                        first_order_fl = false;
                    }
                }

                if (first_order_fl)
                {
                    mbFromPackingSlip_fl = false;
                }

                from_packing_slip_fl = mbFromPackingSlip_fl;
                detail_set = new clsRecordset(ref moDatabase);

                if (!moGeneral.GetOrderForBilling(ref order_set, ref detail_set, GlobalVar.goConstant.TRX_INVOICE_TYPE, moUtility.ToInteger(Header.txtKey_id), moUtility.ToInteger(Header.txtMultiOrder_num), ref from_packing_slip_fl, true, copy_all_fl, first_order_fl))
                {
                    FormShowMessage();
                    return false;
                }
                else if (detail_set.EOF())
                {
                    FormShowMessage(User.Language.oMessage.MERCHANDISE_HAS_NOT_BEEN_SHIPPED_YET);
                    return false;
                }

                if (mbFromPackingSlip_fl == false)
                {
                    mbFromPackingSlip_fl = from_packing_slip_fl;
                }

                if (ShowMultiOrder(detail_set) == false)
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtMultiOrder_num_Verified)");
            }

            return return_value;
        }

        private bool txtPOSItem_cd_Verified()
        {
            int row_num = 0;
            bool item_found_fl = false;
            decimal sell_unit_price = 0;
            bool found_by_serial_num_fl = false;

            Models.clsChargeDetail.clsGrid grid_line;

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moValidate.IsValidItemAnyCode(Header.txtPOSItem_cd, Header.cboLocation_cd, ref found_by_serial_num_fl) == false)
            {
                FormShowMessage(Header.txtPOSItem_cd + User.Language.oMessage.DOES_NOT_EXIST);
                return false;
            }

            Header.txtPOSItem_cd = moValidate.oRecordset.sField("sItem_cd"); // This is necessary because the item could have been found by other codes such as SKU, UPC & serial number.

            // Check if the item exists already
            //
            for (row_num = 0; row_num < moDetail.Data.GetLength(1); row_num++)
            {
                if (moSerial.IsSerialOrLotItem(moUtility.ToInteger(moDetail.Data[Models.clsChargeDetail.ITEM_TYPE_COL, row_num])))
                {
                    // Each serial/lot item occupy one line 
                }
                else if (moDetail.Data[Models.clsChargeDetail.ITEM_CODE_COL, row_num] == Header.txtPOSItem_cd)
                {
                    break;
                }
                else if (moUtility.IsEmpty(moDetail.Data[Models.clsChargeDetail.ITEM_CODE_COL, row_num]))
                {
                    break;
                }
            }

            // Add more line 2 lines before the end.
            //
            if (row_num >= moDetail.Data.GetLength(1) - 2)
            {
                FormAddMoreRows(10);
            }

            grid_line = new Models.clsChargeDetail.clsGrid();

            // Since our calculation is based on the grid, we need to find the grid line corresponding to the one we found in Data[]
            //
            if (moDetail.FindGridLine(row_num, ref grid_line) == false)
            {
                FormShowMessage(moDetail.GetErrorMessage());
                return false;
            }

            // If the item does not exist, add it to the next empty line.
            //
            if (moUtility.IsEmpty(grid_line.txtItem_cd))
            {
                grid_line.txtItem_cd = Header.txtPOSItem_cd;

                if (DetailItem_cd_Verified(grid_line) == false)
                {
                    FormShowMessage();
                    grid_line.txtItem_cd = "";
                    return false;
                }
                grid_line.txtShipped_qty = "1";
            }
            else
            {
                grid_line.txtShipped_qty = (moUtility.ToValue(grid_line.txtShipped_qty) + 1).ToString();
            }

            if (DetailShipped_qty_Verified(grid_line) == false)
            {
                FormShowMessage();
                grid_line.txtShipped_qty = moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, grid_line.Row_num];
                return false;

            }

            // Generic function calls for all line item change.
            //
            if (FormCalculateCurrentRow(grid_line) == false)
            {
                grid_line.txtShipped_qty = moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, grid_line.Row_num];
                return false;
            }

            FormRecreateDetailLine(grid_line);

            return true;
        }


        private bool txtMatrixItem_cd_Verified()
        {
            bool return_value = false;

            try
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                else if (moValidate.IsValidItemCode(Header.txtMatrixItem_cd, false, false, moPage.iTransaction_typ, 0, Header.cboLocation_cd) == false)
                {
                    FormShowMessage(Header.txtMatrixItem_cd + User.Language.oMessage.IS_INVALID);
                    return false;
                }
                else if (moValidate.oRecordset.iField("iItem_typ") < GlobalVar.goIVConstant.SUMMARY_SALES_ITEM_TYPES)
                {
                    FormShowMessage(Header.txtMatrixItem_cd + User.Language.oMessage.IS_INVALID);
                    return false;
                }

                Header.lblMatrixItemDescription = moValidate.oRecordset.sField("sDescription");

                if (moValidate.oRecordset.mField("mSellUnitPrice_amt") > 0)
                {
                    Header.txtMatrixUnitPrice_amt = moMoney.ToStrMoney(moValidate.oRecordset.mField("mSellUnitPrice_amt"));
                }
                else
                {
                    Header.txtMatrixUnitPrice_amt = "";
                }

                Header.lblSystemUnitPrice_amt = Header.txtMatrixUnitPrice_amt;

                moValidate.oRecordset.Release();

                moItemMatrix.InitMatrix(false);

                moItemMatrix.LoadSizeAndColor(ref moDatabase, Header.txtMatrixItem_cd, Header.cboLocation_cd);

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtMatrixItem_cd_Verified)");
            }

            return return_value;
        }

        private bool CustomField_Changed(Models.clsCustomField.clsGrid cur_item)
        {
            FormPreEvent();

            if (moCustomFields.ValidateValue(moDatabase, cur_item) == false)
            {
                FormShowMessage(moCustomFields.GetErrorMessage());
                return false;
            }

            return FormPostEvent();
        }

        private bool cboListingBy_Clicked()
        {
            mbListingInitiated_fl = false;

            FormShowListing();

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else.
        //                                   
        //  ===============================================================================================================================================================================================================================
        private bool cmdAddMoreLines_Clicked()
        {
            FormPreEvent();
            
            FormAddMoreRows();

            return FormPostEvent();
        }
        private bool cmdAddMoreCommissionLines_Clicked()
        {
            FormPreEvent();

            moCommission.AddMoreRows();

            return FormPostEvent();
        }

        private bool btnDetailDelete_Clicked(Models.clsChargeDetail.clsGrid cur_item)
        {
            FormPreEvent();

            FormDeleteCurrentRow(cur_item);

            return FormPostEvent();
        }

        private bool btnDetailInsert_Clicked(Models.clsChargeDetail.clsGrid cur_item)
        {
            FormPreEvent();

            FormInsertNewRow(cur_item);

            return FormPostEvent();
        }

        private bool btnZoomOnDetailItem_Clicked(Models.clsChargeDetail.clsGrid cur_item)
        {
            FormPreEvent();

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "", Models.clsChargeDetail.ITEM_CODE_COL, cur_item.Row_num, moView.DETAIL_PAGE_NUM, "sItem_cd", "") == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");      // shoud not happen
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool btnZoomOnGLAccount_Clicked(Models.clsChargeDetail.clsGrid cur_item)
        {
            FormPreEvent();

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "", Models.clsChargeDetail.FULL_ACCT_CODE_COL, cur_item.Row_num, moView.DETAIL_PAGE_NUM, "sAccount_cd", "") == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");      // shoud not happen
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.
            
            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool DetailItem_cd_Changed(Models.clsChargeDetail.clsGrid cur_item)
        {
            cur_item.txtItem_cd = modCommonUtility.CleanCode(cur_item.txtItem_cd);

            if (cur_item.txtItem_cd == moDetail.Data[Models.clsChargeDetail.ITEM_CODE_COL, cur_item.Row_num])         
            {
                return true;                            
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            // If something is not right, reinstate the original.  Otherwise, save it.
            //
            if (DetailItem_cd_Verified(cur_item) == false)                                           
            {
                cur_item.txtItem_cd = moDetail.Data[Models.clsChargeDetail.ITEM_CODE_COL, cur_item.Row_num];
                return false;
            }

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return true;                // In search mode
            }

            // Generic function calls for all line item change.
            //
            if (FormCalculateCurrentRow(cur_item) == false)
            {
                cur_item.txtItem_cd = moDetail.Data[Models.clsChargeDetail.ITEM_CODE_COL, cur_item.Row_num];
                return false;
            }

            FormCalculateTotal();

            // If qty column is disabled, user must be using scanner.  Then, add more lines atumatically as needed.
            // Ned to add lines at least one line before the last line for proper cell focus.
            //
            if (chkUseScanner_fl && cur_item.Row_num >= moDetail.Grid.Count - 2)
            {
                FormAddMoreRows();
            }

            return FormPostEvent();
        }

        private bool DetailSerial_cd_Changed(Models.clsChargeDetail.clsGrid cur_item)
        {
            cur_item.txtSerial_cd = moUtility.SUCase(moUtility.STrim(moUtility.EvalQuote(cur_item.txtSerial_cd)));  // DO NOT use CleanCode()

            if (cur_item.txtSerial_cd == moDetail.Data[Models.clsChargeDetail.SERIAL_CODE_COL, cur_item.Row_num])
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsNonEmpty(cur_item.txtSerial_cd))
            {
                if (FormOpenDatabase() == false)
                {
                    cur_item.txtSerial_cd = moDetail.Data[Models.clsChargeDetail.SERIAL_CODE_COL, cur_item.Row_num];
                    return FormPostEvent();
                }
                if (DetailSerial_cd_Verified(cur_item) == false)
                {
                    cur_item.txtSerial_cd = moDetail.Data[Models.clsChargeDetail.SERIAL_CODE_COL, cur_item.Row_num];
                    return FormPostEvent();
                }
            }

            moDetail.Data[Models.clsChargeDetail.SERIAL_CODE_COL, cur_item.Row_num] = cur_item.txtSerial_cd;

            FormCalculateTotal();

            return FormPostEvent();
        }

        private bool btnSplitLot_Clicked(Models.clsChargeDetail.clsGrid cur_item)
        {
            int row_num = 0;
            int col_num = 0;

            // Basic requirement to split the current line.
            //
            if (moUtility.IsEmpty(cur_item.txtSerial_cd))
            {
                FormShowMessage(User.Language.oMessage.ENTER_SERIAL_NUM_QTY_BEFORE_SPLITTING);
                return false;
            }
            if (moUtility.ToValue(cur_item.txtShipped_qty) < 1)
            {
                FormShowMessage(User.Language.oMessage.ENTER_QUANTITY);
                return false;
            }
            if (moUtility.ToValue(cur_item.lblBackorder_qty) < 1)
            {
                FormShowMessage(User.Language.oMessage.NOT_ENOUGH_BO_QTY_FOUND_TO_SLPIT);
                return false;
            }

            // Insert a new line after the current line copying down the original except qty and lot number.
            //
            moDetail.InsertNewRow(cur_item, cur_item.Row_num + 1);

            moDetail.RecreateDetail();  // Synchronize grid and array before using array

            for (col_num = 0; col_num < Models.clsChargeDetail.TOTAL_COLUMNS - 1; col_num++)
            {
                moDetail.Data[col_num, cur_item.Row_num + 1] = moDetail.Data[col_num, cur_item.Row_num];
            }

            moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, cur_item.Row_num + 1] = "";       // Do not set qty
            moDetail.Data[Models.clsChargeDetail.QTY_BACKORDER_COL, cur_item.Row_num + 1] = moDetail.Data[Models.clsChargeDetail.QTY_ORDERED_COL, cur_item.Row_num];
            moDetail.Data[Models.clsChargeDetail.SERIAL_CODE_COL, cur_item.Row_num + 1] = "";
            moDetail.Data[Models.clsChargeDetail.LINE_ID_COL, cur_item.Row_num + 1] = moDetail.iNextLine_id.ToString();
            moDetail.iNextLine_id += 1;

            moDetail.RecreateGrid();  // Synchronize grid and array again after array is updated

            return FormPostEvent();
        }

        private bool DetailUnit_cd_Changed(Models.clsChargeDetail.clsGrid cur_item)
        {
            cur_item.txtUnit_cd = modCommonUtility.CleanCode(cur_item.txtUnit_cd);

            if (cur_item.txtUnit_cd == moDetail.Data[Models.clsChargeDetail.UNIT_CODE_COL, cur_item.Row_num])
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (DetailUnit_cd_Verified(cur_item) == false)
            {
                cur_item.txtUnit_cd = moDetail.Data[Models.clsChargeDetail.UNIT_CODE_COL, cur_item.Row_num];
                return false;
            }

            // Generic function calls for all line item change.
            //
            if (FormCalculateCurrentRow(cur_item) == false)
            {
                cur_item.txtUnit_cd = moDetail.Data[Models.clsChargeDetail.UNIT_CODE_COL, cur_item.Row_num];
                return false;
            }

            FormCalculateTotal();

            return FormPostEvent();
        }

        private bool DetailUnitPrice_amt_Changed(Models.clsChargeDetail.clsGrid cur_item)
        {
            decimal new_unit_price = 0;
            decimal sub_total = 0;

            cur_item.txtUnitPrice_amt = moUtility.STrim(cur_item.txtUnitPrice_amt);

            // 08/03/2023
            // percentage discount is allowed.
            //
            if (moUtility.SRight(cur_item.txtUnitPrice_amt, 1) == "%")
            {
                if (moUtility.IsNegativePriceCarryItemType(moUtility.ToInteger(cur_item.lblItem_typ)) == false) // percentage is applicable only to IsNegativePriceCarryItemType()
                {
                    cur_item.txtUnitPrice_amt = moDetail.Data[Models.clsChargeDetail.UNIT_PRICE_COL, cur_item.Row_num];
                    FormShowMessage(User.Language.oMessage.PERC_NOT_ALLOWED);
                    return false;
                }

                cur_item.txtUnitPrice_amt = moUtility.SReplace(cur_item.txtUnitPrice_amt, "%", "");

                sub_total = moMoney.ToNumMoney(Header.txtTaxable_amt) + moMoney.ToNumMoney(Header.txtNonTaxable_amt) - moMoney.ToNumMoney(moDetail.Data[Models.clsChargeDetail.AMT_EXTENDED_COL, cur_item.Row_num]);

                new_unit_price = moMoney.RoundToMoney(moMoney.ToNumMoney(cur_item.txtUnitPrice_amt) * sub_total / 100);

                cur_item.txtUnitPrice_amt = moMoney.ToStrMoney(new_unit_price);     // New price.
            }
            else if (moUtility.IsNonEmpty(cur_item.txtUnitPrice_amt))
            {
                cur_item.txtUnitPrice_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(cur_item.txtUnitPrice_amt));
            }

            if (moMoney.ToNumMoney(cur_item.txtUnitPrice_amt) == moMoney.ToNumMoney(moDetail.Data[Models.clsChargeDetail.UNIT_PRICE_COL, cur_item.Row_num]))
            {
                return true;
            }

            FormPreEvent();

            if (DetailUnitPrice_amt_Verified(cur_item) == false)
            {
                cur_item.txtUnitPrice_amt = moDetail.Data[Models.clsChargeDetail.UNIT_PRICE_COL, cur_item.Row_num];
                return false;
            }

            // Generic function calls for all line item change.
            //
            if (FormCalculateCurrentRow(cur_item) == false)
            {
                cur_item.txtUnitPrice_amt = moDetail.Data[Models.clsChargeDetail.UNIT_PRICE_COL, cur_item.Row_num];
                return false;
            }

            FormCalculateTotal();

            return FormPostEvent();
        }
        
        private bool DetailDiscount_pc_Changed(Models.clsChargeDetail.clsGrid cur_item)
        {
            if (moUtility.IsNonEmpty(cur_item.txtDiscount_pc))
            {
                cur_item.txtDiscount_pc = Math.Abs(moUtility.ToValue(cur_item.txtDiscount_pc)).ToString();
            }

            if (moUtility.ToValue(cur_item.txtDiscount_pc) == moUtility.ToValue(moDetail.Data[Models.clsChargeDetail.DISC_PERC_COL, cur_item.Row_num]))
            {
                return true;
            }

            FormPreEvent();


            if (DetailDiscount_pc_Verified(cur_item) == false)
            {
                cur_item.txtDiscount_pc = moDetail.Data[Models.clsChargeDetail.DISC_PERC_COL, cur_item.Row_num];
                return false;
            }

            // Generic function calls for all line item change.
            //
            if (FormCalculateCurrentRow(cur_item) == false)
            {
                cur_item.txtDiscount_pc = moDetail.Data[Models.clsChargeDetail.DISC_PERC_COL, cur_item.Row_num];
                return false;
            }

            FormRecreateDetailLine(cur_item);
            FormCalculateTotal();

            return FormPostEvent();
        }
        private bool DetailShipped_qty_Changed(Models.clsChargeDetail.clsGrid cur_item)
        {
            if (moUtility.IsNonEmpty(cur_item.txtShipped_qty))
            {
                cur_item.txtShipped_qty = Math.Abs(moUtility.ToValue(cur_item.txtShipped_qty)).ToString();
            }

            if (moUtility.ToValue(cur_item.txtShipped_qty) == moUtility.ToValue(moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, cur_item.Row_num]))
            {
                return true;
            }

            FormPreEvent();

            if (DetailShipped_qty_Verified(cur_item) == false)
            {
                cur_item.txtShipped_qty = moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, cur_item.Row_num];
                return false;
            }

            // Generic function calls for all line item change.
            //
            if (FormCalculateCurrentRow(cur_item) == false)
            {
                cur_item.txtShipped_qty = moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, cur_item.Row_num];
                return false;
            }

            FormRecreateDetailLine(cur_item);
            FormCalculateTotal();

            return FormPostEvent();
        }

        private bool DetailAccount_cd_Changed(Models.clsChargeDetail.clsGrid cur_item)
        {
            cur_item.mskGLAccount_cd = modCommonUtility.CleanCode(cur_item.mskGLAccount_cd);

            if (cur_item.mskGLAccount_cd == moDetail.Data[Models.clsChargeDetail.FULL_ACCT_CODE_COL, cur_item.Row_num])
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moUtility.IsNonEmpty(cur_item.mskGLAccount_cd))
            {
                if (moValidate.IsValidActualAcctCode(cur_item.mskGLAccount_cd) == false)
                {
                    FormShowMessage(cur_item.mskGLAccount_cd + User.Language.oMessage.IS_INVALID);
                    cur_item.mskGLAccount_cd = moDetail.Data[Models.clsChargeDetail.FULL_ACCT_CODE_COL, cur_item.Row_num];
                    return false;
                }
            }

            FormRecreateDetailLine(cur_item);
            FormCalculateTotal();

            return FormPostEvent();
        }

        private bool DetailJob_cd_Clicked(Models.clsChargeDetail.clsGrid cur_item)
        {
            if (cur_item.cboJob_cd == moDetail.Data[Models.clsChargeDetail.JOB_CODE_COL, cur_item.Row_num])
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.txtCustomer_cd))
            {
                FormShowMessage(User.Language.oMessage.ENTER_CUST_CODE_FIRST);
                cur_item.cboJob_cd = moDetail.Data[Models.clsChargeDetail.JOB_CODE_COL, cur_item.Row_num];
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            //  Use the common rountines for both Windows version and ASP version.   03/31/2020
            //  msDetailData is a dummy in ASP version
            //
            if (false == moDetail.ProcessJobCode(ref moDatabase, ref cur_item, Header.txtCustomer_cd))
            {
                FormShowMessage();
                cur_item.cboJob_cd = moDetail.Data[Models.clsChargeDetail.JOB_CODE_COL, cur_item.Row_num];
                return false;
            }

            FormRecreateDetailLine(cur_item);
            FormCalculateTotal();
            return FormPostEvent();
        }

        private bool DetailTax_cd_Clicked(Models.clsChargeDetail.clsGrid cur_item)
        {
            if (cur_item.cboTax_cd == moDetail.Data[Models.clsChargeDetail.TAX_CODE_COL, cur_item.Row_num])
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            //  Use the common rountines for both Windows version and ASP version.   03/31/2020
            //  msDetailData is a dummy in ASP version
            //
            if (false == moDetail.ProcessTaxCode(ref moDatabase, ref cur_item, moUtility.ToValue(Header.txtTax_pc)))
            {
                FormShowMessage();
                cur_item.cboTax_cd = moDetail.Data[Models.clsChargeDetail.TAX_CODE_COL, cur_item.Row_num];
                return false;
            }

            // Generic function calls for all line item change.
            //
            if (FormCalculateCurrentRow(cur_item) == false)
            {
                cur_item.cboTax_cd = moDetail.Data[Models.clsChargeDetail.TAX_CODE_COL, cur_item.Row_num];
                return false;
            }

            FormCalculateTotal();
            return FormPostEvent();
        }

        private bool OrderShipped_qty_Changed(Models.clsChargeDetail.clsGrid cur_item)
        {
            FormPreEvent();
            cur_item.txtShipped_qty = Math.Abs(moUtility.ToValue(cur_item.txtShipped_qty)).ToString();

            if (moUtility.ToValue(cur_item.txtOrdered_qty) < moUtility.ToValue(cur_item.txtShipped_qty))
            {
                cur_item.txtShipped_qty = cur_item.txtOrdered_qty;
            }
            if (moUtility.ToValue(cur_item.txtShipped_qty) > 0)
            {
                cur_item.chkInclude_fl = true;
            }

            return FormPostEvent();
        }

        private bool chkOrderInclude_fl_Clicked(Models.clsChargeDetail.clsGrid cur_item)
        {
            FormPreEvent();

            // This event kickes in before the value of chkInclude_fl changes
            // (cur_item.chkInclude_fl == false) means that chkInclude_fl is about to change to True.
            //
            if (cur_item.chkInclude_fl == false && moUtility.ToValue(cur_item.txtShipped_qty) == 0 && moUtility.ToValue(cur_item.txtOrdered_qty) > 0)
            {
                cur_item.txtShipped_qty = cur_item.txtOrdered_qty;
            }
            else
            {
                cur_item.txtShipped_qty = "";
            }

            return FormPostEvent();
        }
        private bool PaymentCash_typ_Clicked(clsTransactionPayment.clsGrid cur_item)
        {
            FormPreEvent();                                                                  

            if (moUtility.IsEmpty(Header.txtKey_id) || moUtility.IsEmpty(Header.txtCustomer_cd))
            {
                return true;
            }
            if (moUtility.IsEmpty(cur_item.cboCash_typ))
            {
                cur_item.mskGLAccount_cd = "";
                cur_item.txtPaid_amt = "";
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (PaymentCash_typ_Verified(cur_item) == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool CommissionSalesrep_Clicked(clsCommission.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id) || moUtility.IsEmpty(Header.txtCustomer_cd))
            {
                return true;
            }
            if (moUtility.IsEmpty(cur_item.cboSalesrep_cd))
            {
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moDatabase.bCalcCommissionByItem_fl)
            {
                if (cur_item.Row_num == 0)
                {
                    cur_item.txtCommission_amt = "100";
                }
            }
            else
            {
                if (moValidate.IsValidSalesrepCodeWithCommission(cur_item.cboSalesrep_cd) == false)
                {
                    return false;   // not expected.
                }

                cur_item.txtCommission_amt = moMoney.ToStrMoney(moValidate.oRecordset.mField("fCommission_amt"));
                cur_item.cboCommission_typ = moValidate.oRecordset.iField("iCommission_typ").ToString();
            }

            return FormPostEvent();
        }

        private bool PaymentScheduleAmount_Changed(clsPaymentSchedule.clsGrid cur_iem)
        {
            FormPreEvent();

            if (moUtility.IsNonEmpty(cur_iem.txtDue_amt))
            {
                cur_iem.txtDue_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(cur_iem.txtDue_amt));
            }

            CalculatePaymentSchedule();

            return FormPostEvent();
        }

        private bool PaymentScheduleDiscount_Changed(clsPaymentSchedule.clsGrid cur_iem)
        {
            FormPreEvent();

            if (moUtility.IsNonEmpty(cur_iem.txtDiscount_amt))
            {
                cur_iem.txtDiscount_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(cur_iem.txtDiscount_amt));
            }

            return FormPostEvent();
        }

        private bool PaymentScheduleDueDate_Changed(clsPaymentSchedule.clsGrid cur_iem)
        {
            FormPreEvent();

            if (moGeneral.ValidDate(ref cur_iem.txtDue_dt, true) == false)
            {
                cur_iem.txtDue_dt = "";
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                return false;
            }

            return FormPostEvent();
        }

        private bool PaymentScheduleDiscountDate_Changed(clsPaymentSchedule.clsGrid cur_iem)
        {
            FormPreEvent();

            if (moGeneral.ValidDate(ref cur_iem.txtDiscount_dt, true) == false)
            {
                cur_iem.txtDiscount_dt = "";
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                return false;
            }

            return FormPostEvent();
        }

        private bool ZoomInclude_fl_Clicked(clsZoom.clsGrid cur_item)
        {
            FormPreEvent();

            // VERY IMPORTTANT -----------------------------------------------------------------------------------------------------
            //
            // This event kickes in before the value of chkInclude_fl changes.
            // (cur_item.chkInclude_fl == true) means that the current value of chkInclude_fl is TRUE, and it will change to FALSE when it returns to UI.
            //
            if (cur_item.chkInclude_fl)
            {
                cur_item.Qty = "";
                //cur_item.Price = "";
            }

            return FormPostEvent();
        }

        private bool ZoomQty_Changed(clsZoom.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.ToValue(cur_item.Qty) <= 0)
            {
                cur_item.chkInclude_fl = false;
                cur_item.Qty = "";
            }
            else
            {
                cur_item.chkInclude_fl = true;
                cur_item.Qty = moUtility.ToValue(cur_item.Qty).ToString();
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        private bool DetailItem_cd_Verified(Models.clsChargeDetail.clsGrid cur_item)
        {
            // CPMMENTS:
            //         - If item_code is empty, reset tax, discount, unit-conversion info
            //           because they are not applied to the non-inventory items.
            //         - Item-code of description-only items should be deleted.
            //         - If non-inventory item, do not calculate the discount.
            //
            //         - KIT items:
            //               - If item_code of sub-item changes, consider it as an
            //                 exchange of items so that the new item, temporariry,
            //                 becomes a sub-item of the current kit item.
            //               - If you wants to eliminate a sub-item, then you should
            //                 delete the line.
            //'

            bool return_value = false;
            decimal sell_unit_price = 0;
            int row_num = 0;
            Models.clsChargeDetail.clsGrid temp_grid;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    return true;                // In search mode
                }

                if (moUtility.IsEmpty(Header.cboLocation_cd))
                {
                    FormShowMessage(User.Language.oMessage.ENTER_LOCATION_CODE_FIRST);
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    return false;
                }

                if (moUtility.ToInteger(cur_item.lblOrder_num) > 0)     // If this item is from the order, do not let it change.
                {
                    FormShowMessage(User.Language.oMessage.ITEM_FROM_ORDER_NOT_ALLOWED_TO_CHANGE);
                    return false;
                }
                
                if (miOrder_typ == GlobalVar.goSOConstant.BLANKET_ORDER_BY_QTY_TYPE_NUM || miOrder_typ == GlobalVar.goSOConstant.BLANKET_ORDER_BY_BOTH_TYPE_NUM)
                {
                    FormShowMessage(User.Language.oMessage.THIS_BLANKET_ORDER_DOES_NOT_ALLOW_NEW_ITEMS);
                    return false;
                }
                
                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                
                // Now called the generic item validation.
                //
                if (moDetail.ProcessItemCode(ref moDatabase, ref cur_item, Header.txtCustomer_cd, Header.cboLocation_cd, Header.cboTax_cd, Header.cboJob_cd, moUtility.ToValue(Header.txtTax_pc), mmPriceExchange_rt, mmSaleExchange_rt,ref sell_unit_price) == false)
                {
                    FormShowMessage();
                    return false;
                }

                // If qty column is disabled, default to 1.
                //
                if (chkDisableQty_fl || moSerial.IsSerialItem(moUtility.ToInteger(cur_item.lblItem_typ)))
                {
                    cur_item.txtOrdered_qty = "1";
                    cur_item.txtShipped_qty = "1";
                }
                else
                {
                    cur_item.txtShipped_qty = "";
                }

                DetailShipped_qty_Changed(cur_item);

                if (mmPriceExchange_rt == 0)
                {
                    FormCheckExchangeRate();
                }

                cur_item.lblSellUnitPrice_amt = moCurrency.GetSellingUnitPrice(sell_unit_price, mmSaleExchange_rt, mmPriceExchange_rt).ToString();
                cur_item.txtUnitPrice_amt = cur_item.lblSellUnitPrice_amt;
                cur_item.lblInIVUnit_qty = moUtility.RoundToQtyFactor(moUtility.ToValue(cur_item.txtShipped_qty) * moUtility.ToValue(cur_item.lblConversion_rt)).ToString();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (DetailItem_cd_Verified)");
            }

            return return_value;
        }

        private bool DetailShipped_qty_Verified(Models.clsChargeDetail.clsGrid cur_item)
        {
            bool return_value = false;

            int row_num;
            decimal old_ivqty = 0;
            int kit_id = 0;
            int item_type = 0;
            decimal new_qty = 0;
            decimal old_qty = 0;
            decimal ordered_qty = 0;
            int order_num = 0;
            string item_code = "";
            decimal availlable_qty = 0;

            try
            {
                row_num = cur_item.Row_num;
                new_qty = moUtility.ToValue(cur_item.txtShipped_qty);
                ordered_qty = moUtility.ToValue(cur_item.txtOrdered_qty);
                old_ivqty = moUtility.ToValue(cur_item.lblInIVUnit_qty);
                item_type = moUtility.ToInteger(cur_item.lblItem_typ);
                order_num = moUtility.ToInteger(cur_item.lblOrder_num);
                item_code = cur_item.txtItem_cd;

                if (new_qty > 0 && new_qty > ordered_qty && order_num > 0)
                {
                    FormShowMessage(User.Language.oMessage.QTY_CANNOT_EXCEED_ORDERED_QTY_WHEN_ORDER_ENTERED);
                    return false;
                }

                if (moUtility.IsEmpty(Header.cboLocation_cd))
                {
                    FormShowMessage(User.Language.oMessage.PLEASE_ENTER + User.Language.oCaption.LOCATION_CODE);
                    return false;
                }

                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                // Validate the serial number and availability in inventory
                //
                if (moSerial.IsSerialOrLotItem(item_type) && moUtility.IsNonEmpty(cur_item.txtSerial_cd) && new_qty > 0)
                {
                    if (moDetail.CheckSerialCodeAndAvailability(ref moDatabase, User, moPage, cur_item, moUtility.ToInteger(Header.txtKey_id), Header.cboLocation_cd) == false)
                    {
                        FormShowMessage();
                        return false;
                    }
                }

                if (mmSaleExchange_rt == 0)
                {
                    FormCheckExchangeRate();
                }

                if (false == moDetail.ProcessChargeQty(ref moDatabase, ref cur_item, ref cur_item.txtShipped_qty, mmSaleExchange_rt, Header.txtCustomer_cd, Header.cboPrice_cd))
                {
                    FormShowMessage();
                    return false;
                }

                CalculateQty(cur_item);

                new_qty = moUtility.ToValue(cur_item.txtShipped_qty);

                if (moUtility.IsNonEmpty(item_code))
                {

                    // If this is a kit_item(not a sub-item), update the sub-items as well.
                    //
                    if (old_ivqty == 0)
                    {
                        old_ivqty = 1;
                    }

                    if (moUtility.IsKitItem(kit_id) && old_qty > 0)
                    {
                        if (AdjustKitSubItems(kit_id, new_qty / old_qty) == false)
                        {
                            return false;
                        }
                    }

                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (DetailShipped_qty_Verified)");
            }

            return return_value;
        }

        private bool DetailDiscount_pc_Verified(Models.clsChargeDetail.clsGrid cur_item)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            // Pass false to CalculateUnitPrice so that it grabs the discount
            // on the line instead of the best price.
            //
            if (CalculateUnitPrice(cur_item, cur_item.txtItem_cd, false, cur_item.Row_num) == false)
            {
                return false;
            }

            if (false == moDetail.CalculateDiscountAmount(ref moDatabase, ref cur_item, ref cur_item.txtShipped_qty, mmSaleExchange_rt))
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool DetailUnitPrice_amt_Verified(Models.clsChargeDetail.clsGrid cur_item, bool recalc_fl = false)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (false == moDetail.ProcessUnitPrice(ref moDatabase, ref cur_item, ref cur_item.txtShipped_qty, 1, recalc_fl))
            {

                if (moDatabase.IsErrorFound())
                {
                    FormShowMessage();
                }
                return false;

            }

            // Default job code is assigned when item code is entered. However, if this line has no item, assign the default now.
            //
            if (Math.Abs(moMoney.ToNumMoney(cur_item.txtUnitPrice_amt)) > 0 && moUtility.IsNonEmpty(Header.cboJob_cd) && moUtility.IsEmpty(cur_item.txtItem_cd) && moUtility.IsEmpty(cur_item.cboJob_cd))
            {
                cur_item.cboJob_cd = Header.cboJob_cd;
            }

            return true;

        }

        private bool DetailUnit_cd_Verified(Models.clsChargeDetail.clsGrid cur_item)
        {
            bool return_value = false;

            try
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                if (false == moDetail.ProcessSalesUnit(ref moDatabase, ref cur_item, ref cur_item.txtShipped_qty, 1, Header.txtCustomer_cd, Header.cboPrice_cd))
                {
                    FormShowMessage();
                    return false;
                }

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (DetailUnit_cd_Verified)");
            }

            return return_value;
        }

        private bool PaymentCash_typ_Verified(clsTransactionPayment.clsGrid cur_item)
        {
            bool return_value = false;
            decimal paid_amt = 0;

            try
            {
                moCustomer.GetCustomer(Header.txtCustomer_cd, true);
                cur_item.mskGLAccount_cd = moCustomer.GetCashAccountCode(moUtility.ToInteger(cur_item.cboCash_typ));

                if (moMoney.ToNumMoney(cur_item.txtPaid_amt) <= 0)
                {
                    foreach (var det in moTransactionPayment.Grid)
                    {
                        if (det.Row_num != cur_item.Row_num)
                        {
                            paid_amt += moMoney.ToNumMoney(det.txtPaid_amt);
                        }
                    }

                    if (moMoney.ToNumMoney(Header.txtTotal_amt) > paid_amt)
                    {
                        cur_item.txtPaid_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.txtTotal_amt) - paid_amt);
                    }
                    else
                    {
                        cur_item.txtPaid_amt = "";
                    }
                }

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PaymentCash_typ_Verified)");
            }

            return return_value;
        }

        private bool DetailSerial_cd_Verified(Models.clsChargeDetail.clsGrid cur_item)
        {
            int row_num = 0;

            if (moUtility.IsEmpty(Header.cboLocation_cd))
            {
                FormShowMessage(User.Language.oMessage.PLEASE_ENTER + User.Language.oCaption.LOCATION_CODE);
                return false;
            }
            if (moUtility.IsEmpty(cur_item.txtItem_cd))
            {
                FormShowMessage(User.Language.oMessage.PLEASE_ENTER + User.Language.oCaption.ITEM_CODE);
                return false;
            }

            // Check duplicate serial number entry
            //
            for (row_num = 0; row_num < moDetail.Data.GetLength(1); row_num++)
            {
                if (moDetail.Data[Models.clsChargeDetail.ITEM_CODE_COL, row_num] == cur_item.txtItem_cd && moDetail.Data[Models.clsChargeDetail.SERIAL_CODE_COL, row_num] == cur_item.txtSerial_cd && row_num != cur_item.Row_num)
                {
                    FormShowMessage(cur_item.txtItem_cd + "/" + cur_item.txtSerial_cd + User.Language.oMessage.APPEARS_MORE_THAN_ONCE);
                    return false;
                }
            }

            if (moValidate.IsValidSerialCode(cur_item.txtItem_cd, cur_item.txtSerial_cd, Header.cboLocation_cd) == false)
            {
                FormShowMessage(cur_item.txtItem_cd + "/" + cur_item.txtSerial_cd + User.Language.oMessage.IS_INVALID);
                return false;
            }

            // Do this in DetailShipped_qty_Verified()
            //if (moValidate.oRecordset.mField("fAvailable_qty") < moDatabase.fSmallestNumber)
            //{
            //    FormShowMessage(cur_item.txtItem_cd + "/" + cur_item.txtSerial_cd + User.Language.oMessage.DOES_NOT_HAVE_ENOUGH_QTY);
            //    return false;
            //}

            if (moSerial.IsSerialItem(moUtility.ToInteger(cur_item.lblItem_typ)))
            {
                cur_item.txtOrdered_qty = "1";
                cur_item.txtShipped_qty = "1";
            }
            else
            {
                cur_item.txtShipped_qty = "";
            }

            CalculateQty(cur_item);

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================

        public bool ResetRestrictionClause()
        {
            moPage.sRestrictionClause = msDefaultRestrictionClause;

            return true;
        }

        public bool RecalculateTax(string original_tax_code)
        {
            bool return_value = false;
            int row_num = 0;
            Models.clsChargeDetail.clsGrid grid_item = new Models.clsChargeDetail.clsGrid();

            try
            {
                for (row_num = 0; row_num < moDetail.Data.GetLength(1); row_num ++)
                {
                    if (moDetail.FindGridLine(row_num, ref grid_item))
                    {
                        // When header tax code changes, change the the same tax in the detail and recalculate the tax.
                        //
                        if (moUtility.IsNonEmpty(grid_item.cboTax_cd) || grid_item.cboTax_cd == original_tax_code)
                        {
                            grid_item.lblTax_pc = Header.txtTax_pc;
                            grid_item.cboTax_cd = Header.cboTax_cd;
                        }

                        if (false == moDetail.CalculateRow(ref moDatabase, ref grid_item, ref grid_item.txtShipped_qty))
                        {
                            FormShowMessage();
                            return false;
                        }

                        // Need to sync moDetail.Data[].
                        //
                        if (FormRecreateDetailLine(grid_item, row_num) == false)
                        {
                            FormShowMessage();
                            return false;
                        }

                    }
                }

                FormCalculateTotal();
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (RecalculateTax)");
            }

            return return_value;
        }

        private bool CalculateQty(Models.clsChargeDetail.clsGrid cur_item)
        {
            decimal qty_ordered = 0;
            decimal qty_shipped = 0;
            decimal qty_backorder = 0;

            qty_ordered = moUtility.ToValue(cur_item.txtOrdered_qty);
            qty_shipped = moUtility.ToValue(cur_item.txtShipped_qty);
            qty_backorder = moUtility.ToValue(cur_item.lblBackorder_qty);

            if (qty_ordered < qty_shipped)
            {
                qty_ordered = qty_shipped;
            }
            else if (moUtility.ToInteger(cur_item.lblOrder_num) == 0)
            {
                qty_ordered = qty_shipped;
            }

            cur_item.txtOrdered_qty = qty_ordered.ToString();
            cur_item.lblBackorder_qty = (qty_ordered - qty_shipped).ToString();

            return true;
        }

        public bool AdjustKitSubItems(int kit_id, decimal conversion_rate)
        {
            bool return_value = false;
            int cur_kit_id = 0;

            try
            {
                // If this is not a kit item, return
                //
                if (kit_id == 0)
                {
                    return true;
                }

                foreach (var det in moDetail.Grid)
                {
                    // If this is a sub-item of the given kit-item,
                    // update the qty info of the item.
                    //
                    cur_kit_id = moUtility.ToInteger(det.lblKit_id);

                    if ((kit_id < cur_kit_id) && (cur_kit_id < (kit_id + GlobalVar.goConstant.KIT_ID_FACTOR)))
                    {
                        det.txtShipped_qty = moUtility.RoundToQtyFactor(moUtility.ToValue(det.txtShipped_qty) * conversion_rate).ToString();
                        det.lblInIVUnit_qty = moUtility.RoundToQtyFactor(moUtility.ToValue(det.lblInIVUnit_qty) * conversion_rate).ToString();

                        if (moUtility.ToInteger(det.lblOrder_num) == 0)
                        {
                            det.txtOrdered_qty = det.txtShipped_qty;
                        }

                        CalculateQty(det);
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "AdjustKitSubItems");
            }

            return return_value;
        }

        // PURPOSE:  To calculate the unit price and discount percent for the line.
        //
        public bool CalculateUnitPrice(Models.clsChargeDetail.clsGrid cur_item, string item_code, bool get_disc_flag, int row_num)
        {

            if ((mmPriceExchange_rt == 0) || (mmSaleExchange_rt == 0))
            {
                FormCheckExchangeRate();
            }

            if (!moDetail.CalculateUnitPrice(ref moDatabase, ref cur_item, mmSaleExchange_rt, Header.txtCustomer_cd, item_code, Header.cboPrice_cd, get_disc_flag))
            {
                FormShowMessage();
                return false;
            }

            return true;
        }
        public bool CheckPayment()
        {
            decimal memo_amt = 0;
            decimal total_amt = 0;
            int total_num = 0;

            foreach (var det in moTransactionPayment.Grid)
            {
                if (moMoney.ToNumMoney(det.txtPaid_amt) > 0)
                {
                    total_num += 1;

                    if (moUtility.IsEmpty(det.mskGLAccount_cd) || moUtility.ToInteger(det.cboCash_typ) == 0)
                    {
                        FormShowMessage(User.Language.oMessage.PAYMENT_TYPE_IS_MISSING_IN_PAYMENT_ENTRY_SCREEN);
                        return false;
                    }
                    else if (Header.chkRecur_fl && total_num > 1)
                    {
                        FormShowMessage("Recurring does not accept more than one payment.");
                        return false;
                    }
                    else
                    {
                        total_amt += moMoney.ToNumMoney(det.txtPaid_amt);

                        if (moUtility.ToInteger(det.cboCash_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM)
                        {
                            memo_amt += moMoney.ToNumMoney(det.txtPaid_amt);
                        }
                        else if (Header.chkRecur_fl && (moUtility.ToInteger(det.cboCash_typ) != GlobalVar.goConstant.WIRE_TRANSFER_TYPE_NUM))
                        {
                            FormShowMessage("Deposit/EFT is the only tender type accepted for invoice recurring.");
                            return false;
                        }
                    }
                }
                else 
                {
                    det.txtPaid_amt = "";               // in case negative
                    det.cboCash_typ = "";
                    det.mskGLAccount_cd = "";
                }
            }

            // Totals in the header and details should match.
            //
            if (total_amt != moMoney.ToNumMoney(Header.txtPaid_amt))
            {
                FormShowMessage("Payment details do not add up.");
                return false;
            }

            if (total_amt == 0)
            {
                return true;
            }

            // If recurring, make sure the available deposit is enough to cover all recurrence
            //
            if (Header.chkRecur_fl)
            {
                // When payment is associated, we only go with total number of recurrence, not with the expiration date.
                //
                if (memo_amt > 0 && moUtility.ToInteger(Header.txtRecurTo_num) == 0)
                {
                    FormShowMessage("You need to specify the total number of recurring when payment is specified.");
                    return false;
                }
                if (memo_amt > 0 && moCustomer.mDeposit_amt < (memo_amt * moUtility.ToInteger(Header.txtRecurTo_num)))
                {
                    FormShowMessage("Available deposit amount(" + moMoney.ToStrMoney(moCustomer.mDeposit_amt) + ") is not sufficient for this recurring payments.");
                    return false;
                }
            }
            else if (memo_amt > 0 && moCustomer.mDeposit_amt < memo_amt)
            {
                FormShowMessage("Available deposit amount(" + moMoney.ToStrMoney(moCustomer.mDeposit_amt) + ") is not sufficient to use.");
                return false;
            }

            return true;
        }

        public bool CheckPaymentSchedule()
        {
            int discount_date = 0;
            int due_date = 0;
            int total_payments = 0;
            decimal discount_amt = 0;
            decimal amt_total_splited = 0;

            if (moMoney.ToNumMoney(Header.txtDue_amt) <= 0)
            {
                Header.mskDue_dt = Header.mskApply_dt;
                discount_date = moGeneral.ToNumDate(Header.mskApply_dt);
                discount_amt = 0;
            }
            else if (moValidate.IsValidARTermsCode(Header.cboTerms_cd))
            {
                Header.mskDue_dt = moGeneral.ToStrDate(moUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, moGeneral.ToNumDate(Header.mskApply_dt), moValidate.oRecordset.iField("iDueDays")));
                discount_date = moUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, moGeneral.ToNumDate(Header.mskApply_dt), moValidate.oRecordset.iField("iDiscountDays"));
                discount_amt = moGeneral.CalculatePaymentDiscount(moMoney.ToNumMoney(Header.txtTaxable_amt) + moMoney.ToNumMoney(Header.txtNonTaxable_amt), moMoney.ToNumMoney(Header.txtTax_amt), moMoney.ToNumMoney(Header.txtFreightTax_amt), moMoney.ToNumMoney(Header.txtFreight_amt), moValidate.oRecordset.mField("fDiscount_pc"), (moUtility.ToValue(Header.txtTax_pc) < 0));
            }
            else // not expected at all
            {
                FormShowMessage(User.Language.oString.STR_TERMS_CODE + "(" + Header.cboTerms_cd + ")" + User.Language.oMessage.IS_INVALID);
                return false;
            }

            due_date = moGeneral.ToNumDate(Header.mskDue_dt);

            total_payments = 0;

            foreach (var det in moPaymentSchedule.Grid)
            {
                if (moMoney.ToNumMoney(det.txtDue_amt) > 0)
                {
                    total_payments += 1;
                }
            }

            // Recurring invoice does not accept split payment schedule
            //
            if (Header.chkRecur_fl)
            {
                if (total_payments > 1)
                {
                    FormShowMessage("Recurring invoice does not accept split payment schedule.");
                    return false;
                }
            }

            // if un-allocated amount is found in payment schedule.
            //
            if (moMoney.ToNumMoney(Header.txtRemaining_amt) != 0)
            {
                if (total_payments > 1)
                {
                    FormShowMessage("Payment schedule is not set up properly.");    // Need to adjust them manually if more than one due-date is found.
                    return false;
                }
                else
                {
                    moPaymentSchedule.Grid.Clear();                                 // Let moPaymentSchedule.CheckSchedule() take care of the allocation
                }
            }

            if (moPaymentSchedule.RecreateDetail(ref moInvoice.sSplitPayment) == false)
            {
                FormShowMessage(moPaymentSchedule.GetErrorMessage());
                return false;
            }
            if (moPaymentSchedule.CheckSchedule(ref moDatabase, ref moInvoice.sSplitPayment, moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id), moMoney.ToNumMoney(Header.txtTotal_amt)
                , ref amt_total_splited, ref due_date, discount_amt, discount_date, moMoney.ToNumMoney(Header.txtPaid_amt)) == false)
            {
                FormShowMessage();
                return false;
            }
            if (moPaymentSchedule.RecreateGrid(moInvoice.sSplitPayment) == false)           // Amounts could have been adjusted in moPaymentSchedule.CheckSchedule()
            {
                FormShowMessage();
                return false;
            }

            Header.mskDue_dt = moGeneral.ToStrDate(due_date);
            FormSyncDates(false);
            return true;
        }

        public bool CalculatePayment()
        {
            int i = 0;
            decimal amt_paid = 0;

            foreach (var det in moTransactionPayment.Grid)
            {
                det.txtPaid_amt = moMoney.ToStrMoney(Math.Abs(moMoney.ToNumMoney(det.txtPaid_amt)));
                amt_paid += moMoney.ToNumMoney(det.txtPaid_amt);

            }

            Header.txtPaid_amt = moMoney.ToStrMoney(amt_paid);

            return FormCalculateDue();
        }

        public bool CalculatePaymentSchedule()
        {
            decimal amt_due = 0;
            int due_date = 0;

            foreach (var det in moPaymentSchedule.Grid)
            {
                amt_due += moMoney.ToNumMoney(det.txtDue_amt);

                if (moGeneral.ToNumDate(det.txtDue_dt) > due_date)
                {
                    due_date = moGeneral.ToNumDate(det.txtDue_dt);
                }
            }

            Header.txtRemaining_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.txtTotal_amt) - amt_due);  // Do not use txtDue_amt

            //if (moUtility.IsEmpty(Header.mskDue_dt) || moGeneral.ToNumDate(Header.mskDue_dt) < due_date) 
            if (due_date > 0)
            {
                Header.mskDue_dt = moGeneral.ToStrDate(due_date);
                FormSyncDates(false);
            }

            return true;
        }

        private bool SaveCommission()
        {

            bool return_value = false;
            int row_num = 0;
            int max_row = 0;

            try
            {
                moInvoice.oCommission.InitCommission(moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id));
                moInvoice.oCommission.mInvoice_amt = (moMoney.ToNumMoney(Header.txtTaxable_amt) + moMoney.ToNumMoney(Header.txtNonTaxable_amt));
                moInvoice.oCommission.iStatus_typ = moUtility.ToInteger(Header.cboStatus_typ);
                moInvoice.oCommission.iApply_dt = moGeneral.ToNumDate(Header.mskApply_dt);
                moInvoice.oCommission.iEntry_dt = moGeneral.ToNumDate(Header.mskEntry_dt);
                moInvoice.oCommission.bPaid_fl = (moMoney.ToNumMoney(Header.txtDue_amt) <= 0);

                foreach (var det in moCommission.Grid)
                {
                    if (moUtility.IsNonEmpty(det.cboSalesrep_cd))
                    {
                        if (moDatabase.bCalcCommissionByItem_fl)    // Commission comes from tblIVItem.sCommission_cd in commission calculation
                        {
                            moInvoice.oCommission.AddCommission(det.cboSalesrep_cd, moMoney.ToNumMoney(det.txtCommission_amt), moUtility.ToInteger(det.cboCommission_typ));
                        }
                        else if (moMoney.ToNumMoney(det.txtCommission_amt) > 0 && moUtility.ToInteger(det.cboCommission_typ) > 0)
                        {
                            moInvoice.oCommission.AddCommission(det.cboSalesrep_cd, moMoney.ToNumMoney(det.txtCommission_amt), moUtility.ToInteger(det.cboCommission_typ));
                        }
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(SaveCommission)");
            }

            return return_value;
        }

        public bool SavePayment()
        {
            bool return_value = false;
            int row_num = 0;
            int payment_num = 0;

            try
            {
                moTransactionPayment.iTransaction_typ = moPage.iTransaction_typ;
                moTransactionPayment.iTransaction_num = moUtility.ToInteger(Header.txtKey_id);

                foreach (var det in moTransactionPayment.Grid)
                {
                    if (moMoney.ToNumMoney(det.txtPaid_amt) > 0 && moUtility.ToInteger(det.cboCash_typ) > 0)
                    {
                        payment_num += 1;
                        if (!moTransactionPayment.AddNewPayment(ref payment_num, moUtility.ToInteger(det.cboCash_typ), det.mskGLAccount_cd, det.txtDocument_num, det.txtNameOnDoc, det.txtExpiration_dt, det.txtAuthorization_num, moMoney.ToNumMoney(det.txtPaid_amt)))
                        {
                            FormShowMessage();
                            return false;
                        }
                    }
                }

                if (moTransactionPayment.KeepNewPayment() == false)
                {
                    FormShowMessage();
                    return false;
                }

                moInvoice.oTransactionPayment = moTransactionPayment;
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SavePayment)");
            }

            return return_value;
        }

        public bool GetPayment()
        {
            bool return_value = false;
            string sql_str = null;
            int row_num = 0;
            clsRecordset cur_set = new clsRecordset(ref moDatabase);
            clsTransactionPayment.clsGrid cur_item;

            try
            {
                moTransactionPayment.CreateGrid();

                sql_str = "SELECT * FROM tblARChargePaidUnposted";
                sql_str += " WHERE iTransaction_num = " + Header.txtKey_id;
                sql_str += "   AND iTransaction_typ = " + moPage.iTransaction_typ.ToString();
                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    FormShowMessage();
                    return false;
                }

                while (cur_set.EOF() == false)
                {
                    cur_item = new clsTransactionPayment.clsGrid();

                    if (moTransactionPayment.FindGridLine(row_num, ref cur_item))
                    {
                        cur_item.cboCash_typ = cur_set.iField("iCash_typ").ToString();
                        cur_item.mskGLAccount_cd = cur_set.sField("sCashAcct_cd");
                        cur_item.txtPaid_amt = moMoney.ToStrMoney(cur_set.mField("mPaid_amt"));
                        cur_item.txtDocument_num = cur_set.sField("sDocument_num");
                        cur_item.txtNameOnDoc = cur_set.sField("sAuthorization_num");
                        cur_item.txtNameOnDoc = cur_set.sField("sOnDocument_nm");
                        cur_item.txtExpiration_dt =  moGeneral.ToStrDate(cur_set.iField("iExpires_dt"));
                    }
                    cur_set.MoveNext();
                    row_num += 1;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (GetPayment)");
            }

            return return_value;
        }

        private bool GetCommission()
        {
            moCommission.InitCommission(moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id));

            if (moCommission.GetCommission() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool GetPaymentSchedule()
        {
            moPaymentSchedule.CreateGrid(10);

            if (moPaymentSchedule.GetPaymentSchedule(ref moDatabase, moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id)) == false)
            {
                FormShowMessage(moPaymentSchedule.GetErrorMessage());
                return false;
            }

            Header.txtRemaining_amt = "";

            return true;
        }

        private bool SavePaymentSchedule()
        {
            foreach (var det in moPaymentSchedule.Grid)
            {
                det.txtTotal_amt = det.txtDue_amt;
            }

            if (moPaymentSchedule.RecreateDetail(ref moInvoice.sSplitPayment) == false)
            {
                FormShowMessage(moPaymentSchedule.GetErrorMessage());
                return false;
            }

            return true;
        }

        public int GetStartingRowInMainTable()
        {

            int return_value = 0;
            int row_num = 0;

            try
            {
                FormRecreateDetail();

                return_value = -1;
                for (row_num = moDetail.Data.GetUpperBound(1); row_num >= 0; row_num--)
                {
                    if (moUtility.IsNonEmpty(moDetail.Data[Models.clsChargeDetail.ITEM_CODE_COL, row_num]) || moUtility.IsNonEmpty(moDetail.Data[Models.clsChargeDetail.DESCRIPTION_COL, row_num]) 
                        || moMoney.ToNumMoney(moDetail.Data[Models.clsChargeDetail.UNIT_PRICE_COL, row_num]) != 0)
                    {
                        return_value = row_num;
                        break;
                    }
                }

                return_value += 1;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (GetStartingRowInMainTable)");
            }

            return return_value;
        }

        private bool SecurityLock()
        {
            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            else if (moUtility.ToInteger(Header.txtOrder_num) > 0)
            {
                return true;
            }
            else if (mbMultiOrder_fl)
            {
                return true;
            }

            return false;
        }

        private bool PriceLock()
        {
            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            else if (moUtility.IsSalesStaff(moDatabase) && moDatabase.uSecurity.bBlockPriceChange_fl)
            {
                return true;
            }

            return false;
        }

        // PURPOSE:  To copy the open order to invoice screen.
        // Header.txtComment:  This should be called only WHEN cur_set is valid.
        //
        private bool CopyOrderToInvoice(ref clsRecordset order_set, clsRecordset detail_set, int order_num)
        {
            bool return_value = false;
            string sql_str = "";
            int line_num = 0;
            int row_num = 0;
            int col_num = 0;
            int i = 0;
            int next_kit_id = 0;
            decimal new_tax = 0;
            bool first_slip = false;
            decimal line_discount_amt = 0;
            bool save_packingslip = false;
            int total_serial_num = 0;

            Models.clsChargeDetail.clsGrid grid_line = null;
            clsWarehouseSlip o_wh_slip = new clsWarehouseSlip(ref moDatabase);

            try
            {
                first_slip = (order_set.iField("iInvoiced_num") == 0);

                //  Copy the invoice header.
                //
                if (moUtility.IsBlankDate(Header.mskEntry_dt))
                {
                    Header.mskEntry_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                }
                if (moUtility.IsBlankDate(Header.mskApply_dt))
                {
                    Header.mskApply_dt = moGeneral.ToStrDate(moGeneral.CurrentDate());
                }
                if (order_set.iField("iShipped_dt") > 0)
                {
                    Header.mskShipped_dt = moGeneral.ToStrDate(order_set.iField("iShipped_dt"));
                }
                else
                {
                    Header.mskShipped_dt = Header.mskEntry_dt;
                }
                if (order_set.iField("iRequired_dt") > 0)
                {
                    Header.mskRequired_dt = moGeneral.ToStrDate(order_set.iField("iRequired_dt"));
                }

                Header.txtCustomer_cd = order_set.sField("sCustomer_cd");
                modLoadUtility.LoadJobCode(ref moDatabase, ref JobCodeList, Header.txtCustomer_cd);

                Header.cboSalesrep_cd = order_set.sField("sSalesrep_cd");
                Header.txtShipTo_cd = order_set.sField("sShipTo_cd");
                Header.txtShipToAttn = order_set.sField("sShipToAttn");
                Header.txtShipTo_nm = order_set.sField("sShipTo_nm");
                Header.txtShipToAddress1 = order_set.sField("sShipToAddress1");
                Header.txtShipToAddress2 = order_set.sField("sShipToAddress2");
                Header.txtShipToAddress3 = order_set.sField("sShipToAddress3");
                Header.txtShipToCity = order_set.sField("sShipToCity");
                Header.txtShipToState = order_set.sField("sShipToState");
                Header.txtShipToZipCode = order_set.sField("sShipToZipCode");
                Header.txtShipToCountry_cd = order_set.sField("sShipToCountry_cd");
                Header.txtShipToPhone = order_set.sField("sShipToPhone");
                Header.txtShipToFax = order_set.sField("sShipToFax");

                Header.txtCustomerAttn = order_set.sField("sCustomerAttn");

                if (order_set.sField("sCustomer_cd") == GlobalVar.goARConstant.WEB_CUSTOMER_CODE)
                {
                    Header.txtCustomer_nm = order_set.sField("sLastUpdate_id");
                }
                else
                {
                    Header.txtCustomer_nm = order_set.sField("sCustomer_nm");
                }

                Header.txtCustomerAddress1 = order_set.sField("sCustomerAddress1");
                Header.txtCustomerAddress2 = order_set.sField("sCustomerAddress2");
                Header.txtCustomerAddress3 = order_set.sField("sCustomerAddress3");
                Header.cboFOB_cd = order_set.sField("sFob_cd");
                Header.cboTerms_cd = order_set.sField("sTerms_cd");
                Header.cboTax_cd = order_set.sField("sTax_cd");
                msOriginalTax_cd = order_set.sField("sTax_cd");
                Header.cboPrice_cd = order_set.sField("sPrice_cd");
                Header.cboVia_cd = order_set.sField("sVia_cd");
                Header.cboDunn_cd = order_set.sField("sDunn_cd");
                Header.cboLocation_cd = order_set.sField("sLocation_cd");
                Header.txtTaxable_amt = moMoney.ToStrMoney(order_set.mField("mTaxable_amt"));
                Header.txtNonTaxable_amt = moMoney.ToStrMoney(order_set.mField("mNonTaxable_amt"));
                Header.txtTax_amt = moMoney.ToStrMoney(order_set.mField("mTax_amt"));
                Header.txtTotal_amt = moMoney.ToStrMoney(order_set.mField("mTotal_amt"));
                Header.txtPaid_amt = moMoney.ToStrMoney(order_set.mField("mPaid_amt"));
                Header.txtDue_amt = moMoney.ToStrMoney(order_set.mField("mDue_amt"));
                Header.txtDiscount_amt = moMoney.ToStrMoney(order_set.mField("mDiscount_amt"));
                Header.txtTax_pc = order_set.mField("fTax_pc").ToString();

                Header.txtOurReference = order_set.sField("sReference");
                Header.txtYourReference = order_set.sField("sYourReference");
                Header.txtComment = moUtility.SLeft(order_set.sField("sComment"), 40);
                Header.cboRecur_typ = order_set.iField("iRecurring_typ").ToString();
                Header.txtWeight = order_set.mField("fWeight").ToString();
                Header.chkDropShipment_fl = (order_set.iField("iDropShipment_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.chkGiftShipment_fl = (order_set.iField("iGiftShipment_fl") == GlobalVar.goConstant.FLAG_ON);
                Header.txtWebUser_id = order_set.sField("sWebUser_id");

                if (first_slip)
                {
                    Header.txtFreight_amt = moMoney.ToStrMoney(order_set.mField("mFreight_amt"));
                    Header.txtFreightTax_amt = order_set.mField("mFreightTax_amt").ToString();
                }
                else
                {
                    Header.txtFreight_amt = "";
                    Header.txtFreightTax_amt = "";
                }

                if (!moCustomer.GetCustomer(Header.txtCustomer_cd, true))
                {
                    FormShowMessage(Header.txtCustomer_cd + User.Language.oMessage.IS_INVALID);
                    Header.txtCustomer_cd = "";
                }
                else if (moUtility.IsEmpty(Header.cboPosting_cd))
                {
                    Header.cboPosting_cd =moCustomer.sPosting_cd;
                }

                Header.txtTransaction_num = moGeneral.GetFormatedDocumentNumber(moPage.iTransaction_typ, Header.txtKey_id);

                moTransactionPayment.CreateGrid();
                moPaymentSchedule.CreateGrid();

                if (detail_set.EOF())
                {
                    FormClearDetail();
                    FormCalculateTotal();
                    return true;
                }

                detail_set.MoveFirst();

                while (detail_set.EOF() == false)
                {
                    if (moSerial.IsSerialItem(detail_set.iField("iItem_typ")))
                    {
                        total_serial_num += (int)detail_set.mField("fOrdered_qty");
                    }
                    detail_set.MoveNext();
                }

                moDetail.iNextLine_id = 1;
                line_num = 0;
                next_kit_id = 0;
                detail_set.MoveFirst();
                moDetail.iTotalRows = detail_set.RecordCount() + total_serial_num + 2;
                moUtility.ResizeDim(ref moDetail.Data, Models.clsChargeDetail.TOTAL_COLUMNS, moDetail.iTotalRows - 1);

                while (detail_set.EOF() == false)
                {
                    moDetail.Data[Models.clsChargeDetail.ITEM_CODE_COL, line_num] = detail_set.sField("sItem_cd");
                    moDetail.Data[Models.clsChargeDetail.ITEM_COLOR_COL, line_num] = detail_set.sField("sColor_cd");
                    moDetail.Data[Models.clsChargeDetail.ITEM_SIZE_COL, line_num] = detail_set.sField("sSize_cd");
                    moDetail.Data[Models.clsChargeDetail.ITEM_MANUFACTURER_COL, line_num] = detail_set.sField("sManufacturer_cd");
                    moDetail.Data[Models.clsChargeDetail.ITEM_BRAND_COL, line_num] = detail_set.sField("sBrand_cd");
                    moDetail.Data[Models.clsChargeDetail.ITEM_MODEL_COL, line_num] = detail_set.sField("sModel_cd");
                    moDetail.Data[Models.clsChargeDetail.ITEM_STYLE_COL, line_num] = detail_set.sField("sStyle_cd");
                    moDetail.Data[Models.clsChargeDetail.DESCRIPTION_COL, line_num] = detail_set.sField("sDescription");
                    moDetail.Data[Models.clsChargeDetail.UNIT_CODE_COL, line_num] = detail_set.sField("sUnit_cd");

                    if (moDatabase.uSecurity.bShowOriginalQtyOrdered_fl)
                    {
                            moDetail.Data[Models.clsChargeDetail.QTY_ORDERED_COL, line_num] = detail_set.mField("fOrdered_qty").ToString();
                    }
                    else if (mbFromPackingSlip_fl)
                    {
                            moDetail.Data[Models.clsChargeDetail.QTY_ORDERED_COL, line_num] = (detail_set.mField("fOrdered_qty") - detail_set.mField("fInvoiced_qty")).ToString();
                    }
                    else
                    {
                            moDetail.Data[Models.clsChargeDetail.QTY_ORDERED_COL, line_num] = detail_set.mField("fBackOrder_qty").ToString();
                    }

                    if (mbFromPackingSlip_fl == false)
                    {
                            moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, line_num] = (detail_set.mField("fAllocated_qty") - detail_set.mField("fShipped_qty")).ToString(); // QTY ALLOCATION : Do NOT USE fOrdered_qty
                    }
                    else if (detail_set.mField("fShipped_qty") > detail_set.mField("fInvoiced_qty"))
                    {
                            moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, line_num] = (detail_set.mField("fShipped_qty") - detail_set.mField("fInvoiced_qty")).ToString();
                    }
                    else if (moUtility.IsNonEmpty(detail_set.sField("sItem_cd")))
                    {
                            moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, line_num] = "0";
                    }
                    else
                    {
                            moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, line_num] = detail_set.mField("fAllocated_qty").ToString(); // QTY ALLOCATION : Do NOT USE fOrdered_qty
                    }

                    if (moMoney.ToNumMoney(moDetail.Data[Models.clsChargeDetail.QTY_ORDERED_COL, line_num]) >= moMoney.ToNumMoney(moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, line_num]))
                    {
                            moDetail.Data[Models.clsChargeDetail.QTY_BACKORDER_COL, line_num] = (moMoney.ToNumMoney( moDetail.Data[Models.clsChargeDetail.QTY_ORDERED_COL, line_num]) - moMoney.ToNumMoney( moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, line_num])).ToString();
                    }
                    else
                    {
                            moDetail.Data[Models.clsChargeDetail.QTY_BACKORDER_COL, line_num] = "0";
                    }

                    moDetail.Data[Models.clsChargeDetail.UNIT_PRICE_COL, line_num] = moMoney.ToStrMoney(detail_set.mField("mUnitPrice_amt"));
                    moDetail.Data[Models.clsChargeDetail.AMT_EXTENDED_COL, line_num] = moMoney.ToStrMoney(moMoney.RoundToMoney(detail_set.mField("mUnitPrice_amt") * moMoney.ToNumMoney(moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, line_num])));
                    moDetail.Data[Models.clsChargeDetail.TAX_CODE_COL, line_num] = detail_set.sField("sTax_cd");
                    moDetail.Data[Models.clsChargeDetail.FULL_ACCT_CODE_COL, line_num] = detail_set.sField("sRevenueAcct_cd");

                    // Discount amount needs to be prorated.
                    //
                    if (moUtility.IsEmpty(detail_set.sField("sItem_cd")))
                    {
                        line_discount_amt = 0;
                    }
                    else if (detail_set.mField("mDiscount_amt") < moDatabase.mSmallestMoney_amt)
                    {
                        line_discount_amt = 0;
                    }
                    else if (detail_set.mField("fOrdered_qty") == moUtility.ToValue( moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, line_num]))
                    {
                        line_discount_amt = detail_set.mField("mDiscount_amt");
                    }
                    else
                    {
                        line_discount_amt = detail_set.mField("mDiscount_amt") * (moUtility.ToValue( moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, line_num]) / detail_set.mField("fOrdered_qty"));
                    }

                    line_discount_amt = moMoney.RoundToMoney(line_discount_amt);

                    moDetail.Data[Models.clsChargeDetail.AMT_DISC_COL, line_num] = line_discount_amt.ToString();
                    moDetail.Data[Models.clsChargeDetail.DISC_PERC_COL, line_num] = detail_set.mField("fDiscount_pc").ToString();
                    moDetail.Data[Models.clsChargeDetail.TAX_PERC_COL, line_num] = detail_set.mField("fTax_pc").ToString();

                    if (System.Math.Abs(detail_set.mField("fTax_pc")) >= moDatabase.fSmallestNumber)
                    {
                        new_tax = detail_set.mField("mTax_amt");
                        new_tax = new_tax * moUtility.ToValue( moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, line_num]);
                        new_tax = new_tax / detail_set.mField("fOrdered_qty");
                        moDetail.Data[Models.clsChargeDetail.AMT_TAX_COL, line_num] = moMoney.RoundToMoney(new_tax).ToString();
                    }
                    else
                    {
                        moDetail.Data[Models.clsChargeDetail.AMT_TAX_COL, line_num] = "0";
                    }

                    moDetail.Data[Models.clsChargeDetail.LOCATION_COL, line_num] = detail_set.sField("sLocation_cd");
                    moDetail.Data[Models.clsChargeDetail.IVUNIT_CODE_COL, line_num] = detail_set.sField("sIVUnit_cd");
                    moDetail.Data[Models.clsChargeDetail.QTY_IN_IVUNIT_COL, line_num] = moUtility.RoundToQtyFactor(detail_set.mField("fConversionRate") * moMoney.ToNumMoney( moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, line_num])).ToString();

                    moDetail.Data[Models.clsChargeDetail.TOTAL_COST_COL, line_num] = detail_set.mField("mCost_amt").ToString();
                    moDetail.Data[Models.clsChargeDetail.ITEM_TYPE_COL, line_num] = detail_set.iField("iItem_typ").ToString();
                    moDetail.Data[Models.clsChargeDetail.CONVERSION_RATE_COL, line_num] = detail_set.mField("fConversionRate").ToString();

                    moDetail.Data[Models.clsChargeDetail.SELL_UNIT_CODE_COL, line_num] = detail_set.sField("sSellUnit_cd");
                    moDetail.Data[Models.clsChargeDetail.SELL_UNIT_PRICE_COL, line_num] = detail_set.mField("mSellUnitPrice_amt").ToString();

                    moDetail.Data[Models.clsChargeDetail.KIT_ID_COL, line_num] = detail_set.iField("iKit_id").ToString();
                    moDetail.Data[Models.clsChargeDetail.WEIGHT_PER_UNIT_COL, line_num] = detail_set.mField("fWeight").ToString();
                    moDetail.Data[Models.clsChargeDetail.FREIGHT_PER_UNIT_COL, line_num] = detail_set.mField("mFreight_amt").ToString();
                    moDetail.Data[Models.clsChargeDetail.JOB_CODE_COL, line_num] = detail_set.sField("sJob_cd");
                    moDetail.Data[Models.clsChargeDetail.PRIMARY_ITEM_CODE_COL, line_num] = detail_set.sField("sPrimaryItem_cd");
                    moDetail.Data[Models.clsChargeDetail.LINE_ID_COL, line_num] = moDetail.iNextLine_id.ToString();
                    moDetail.Data[Models.clsChargeDetail.ORDER_NUM_COL, line_num] = order_num.ToString();
                    moDetail.Data[Models.clsChargeDetail.SOURCE_DETAIL_ID_COL, line_num] = detail_set.iField("iLine_id").ToString(); // Do not delete this. This is used to communicate with S/O.

                    // 08/20/2021
                    // Local invoice has discount calculation problem because it is based on UNIT_PRICE_IN_PRIMARY_CURRENCY_COL
                    //
                    moDetail.Data[Models.clsChargeDetail.UNIT_PRICE_IN_PRIMARY_CURRENCY_COL, line_num] = moDetail.Data[Models.clsChargeDetail.UNIT_PRICE_COL, line_num];
                    moDetail.Data[Models.clsChargeDetail.AMT_DISC_IN_PRIMARY_CURRENCY_COL, line_num] = moDetail.Data[Models.clsChargeDetail.AMT_DISC_COL, line_num];

                    row_num = 1;

                    // If a serial number is found, make sure to create extra lines as many as qty
                    //
                    if (moUtility.IsNonEmpty(detail_set.sField("sItem_cd")) && moSerial.IsSerialItem(detail_set.iField("iItem_typ")) && moUtility.ToInteger(moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, line_num]) > 0)
                    {
                        while (moUtility.ToInteger(moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, line_num]) > row_num)
                        {
                            for (col_num = 0; col_num < Models.clsChargeDetail.TOTAL_COLUMNS - 1; col_num++)
                            {
                                moDetail.Data[col_num, line_num + row_num] = moDetail.Data[col_num, line_num];
                            }

                            moDetail.iNextLine_id += 1;

                            moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, line_num + row_num] = "";
                            moDetail.Data[Models.clsChargeDetail.QTY_ORDERED_COL, line_num + row_num] = "1";
                            moDetail.Data[Models.clsChargeDetail.QTY_BACKORDER_COL, line_num + row_num] = "1";
                            moDetail.Data[Models.clsChargeDetail.SOURCE_DETAIL_ID_COL, line_num + row_num] = moDetail.Data[Models.clsChargeDetail.SOURCE_DETAIL_ID_COL, line_num];
                            moDetail.Data[Models.clsChargeDetail.LINE_ID_COL, line_num + row_num] = moDetail.iNextLine_id.ToString();
                            row_num += 1;
                        }

                        moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, line_num] = "";
                        moDetail.Data[Models.clsChargeDetail.QTY_ORDERED_COL, line_num] = "1";
                        moDetail.Data[Models.clsChargeDetail.QTY_BACKORDER_COL, line_num] = "1";
                    }

                    line_num += row_num;
                    moDetail.iNextLine_id += 1;

                    detail_set.MoveNext();
                }

                if (line_num == 0)
                {
                    FormShowMessage(User.Language.oMessage.ALL_ITEM_RECEIVED);
                    Header.txtOrder_num = "";
                }
                else
                {
                    Header.txtPaid_amt = "0.00";

                    if (CopyOrderCommissionToInvoice(order_num) == false)
                    {
                        return false;
                    }
                }

                // Copy moDetail.Data[] to grid.
                //
                if (moDetail.RecreateGrid() == false)
                {
                    return false;
                }

                for (line_num = 0; line_num < moDetail.Data.GetLength(1); line_num++)
                {
                    grid_line = new Models.clsChargeDetail.clsGrid();

                    if (moDetail.FindGridLine(line_num, ref grid_line))
                    {
                        if (moDetail.CalculateQtyInIvUnit(ref moDatabase, ref grid_line, ref grid_line.txtShipped_qty) == false)
                        {
                            FormShowMessage();
                            return false;
                        }
                    }
                }

                // Copy grid back to moDetail.Data[]
                //
                if (moDetail.RecreateDetail() == false)
                {
                    return false;
                }

                FormCalculateTotal();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CopyOrderToInvoice)");
            }

            return return_value;
        }

        private string GetSearchCriteria()
        {
            string return_value = null;

            try
            {
                Header.txtTransaction_num = moUtility.EvalQuote(Header.txtTransaction_num);

                if (moUtility.IsNonEmpty(Header.txtTransaction_num))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sTransaction_num LIKE '" + Header.txtTransaction_num + "%'";
                }

                if (moUtility.IsNonEmpty(Header.mskEntry_dt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iEntry_dt = " + moGeneral.ToNumDate(Header.mskEntry_dt);
                }
                if (moUtility.IsNonEmpty(Header.mskApply_dt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iApply_dt = " + moGeneral.ToNumDate(Header.mskApply_dt);
                }
                if (moUtility.IsNonEmpty(Header.mskRequired_dt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iRequired_dt = " + moGeneral.ToNumDate(Header.mskRequired_dt);
                }
                if (moUtility.IsNonEmpty(Header.mskShipped_dt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iShipped_dt = " + moGeneral.ToNumDate(Header.mskShipped_dt);
                }
                if (!moUtility.IsEmpty(Header.mskDue_dt))
                {
                    return_value += moUtility.IIf(!moUtility.IsEmpty(return_value), " AND ", "").ToString() + "iDue_dt = " + moGeneral.ToNumDate(Header.mskDue_dt);
                }
                if (moUtility.ToInteger(Header.cboStatus_typ) > 0)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iStatus_typ = " + Header.cboStatus_typ;
                }
                if (moUtility.IsNonEmpty(Header.txtCustomer_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sCustomer_cd = '" + moUtility.EvalQuote(Header.txtCustomer_cd) + "'";
                }
                if (moUtility.IsNonEmpty(Header.txtCustomer_nm))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sCustomer_nm LIKE '" + moUtility.EvalQuote(Header.txtCustomer_nm) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtCustomerAddress1))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sCustomerAddress1 LIKE '" + moUtility.EvalQuote(Header.txtCustomerAddress1) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtCustomerAddress2))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sCustomerAddress2 LIKE '" + moUtility.EvalQuote(Header.txtCustomerAddress2) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtCustomerAddress3))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sCustomerAddress3 LIKE '" + moUtility.EvalQuote(Header.txtCustomerAddress3) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtCustomerAttn))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sCustomerAttn LIKE '" + moUtility.EvalQuote(Header.txtCustomerAttn) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtShipTo_nm))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sShipTo_nm LIKE '" + moUtility.EvalQuote(Header.txtShipTo_nm) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtShipToAddress1))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sShipToAddress1 LIKE '" + moUtility.EvalQuote(Header.txtShipToAddress1) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtShipToAddress2))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sShipToAddress2 LIKE '" + moUtility.EvalQuote(Header.txtShipToAddress2) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtShipToAddress3))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sShipToAddress3 LIKE '" + moUtility.EvalQuote(Header.txtShipToAddress3) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtShipToAttn))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sShipToAttn LIKE '" + moUtility.EvalQuote(Header.txtShipToAttn) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtOurReference))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sReference LIKE '" + moUtility.EvalQuote(Header.txtOurReference) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtYourReference))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sYourReference LIKE '" + moUtility.EvalQuote(Header.txtYourReference) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtComment))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sComment LIKE '" + moUtility.EvalQuote(Header.txtComment) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.cboFOB_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sFob_cd LIKE '" + moUtility.EvalQuote(Header.cboFOB_cd) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.cboDunn_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sDunn_cd = '" + Header.cboDunn_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboTax_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sTax_cd = '" + Header.cboTax_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboVia_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sVia_cd = '" + Header.cboVia_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboPrice_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sPrice_cd = '" + Header.cboPrice_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboTerms_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sTerms_cd = '" + Header.cboTerms_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboSalesrep_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sSalesrep_cd = '" + Header.cboSalesrep_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboLocation_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sLocation_cd = '" + Header.cboLocation_cd + "'";
                }
                if (moUtility.IsNonEmpty(Header.cboJob_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sJob_cd = '" + Header.cboJob_cd + "'";
                }
                if (Header.chkDropShipment_fl)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iDropShipment_fl = 1";
                }
                if (Header.chkGiftShipment_fl)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iGiftShipment_fl = 1";
                }
                if (Header.chkRecur_fl)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iRecurring_typ > 0 ";
                }
                if (moUtility.ToInteger(Header.cboRecur_typ) > 0)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iRecurring_typ = " + Header.cboRecur_typ;
                }
                if (moUtility.ToInteger(Header.txtRecurTo_num) > 0)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iToRecur_num = " + moUtility.ToInteger(Header.txtRecurTo_num).ToString();
                }
                if (moGeneral.ToNumDate(Header.mskToRecur_dt) > 0)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "iToRecur_dt = " + moGeneral.ToNumDate(Header.mskToRecur_dt).ToString();
                }

                if (moUtility.IsNonEmpty(Header.cboFund_cd))
                {
                    if (Header.cboFund_cd == clsNPConstant.FUND_ORGANIZATION_CODE)
                    {
                        return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sFund_cd = ''";
                    }
                    else
                    {
                        return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "").ToString() + "sFund_cd = '" + GlobalVar.goFund.GetSelectedFundCodeToSave(ref moDatabase, Header.cboFund_cd) + "'";
                    }
                }

                // CUSTOM FIELDS
                //
                if (moUtility.IsNonEmpty(moCustomFields.GetSearchList(moDatabase)))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + moCustomFields.GetSearchList(moDatabase);
                }

                return return_value;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (GetSearchCriteria)");
                return_value = "";
            }

            return return_value;

        }

        private bool ShowMultiOrder(clsRecordset detail_set)
        {

            bool return_value = false;
            int row_num = 0;
            decimal line_discount_amt = 0;

            try
            {
                moMultiOrder.Grid.Clear();
                if (detail_set.EOF())
                {
                    return true;
                }

                moUtility.ResizeDim(ref moMultiOrder.Data, Models.clsChargeDetail.TOTAL_COLUMNS - 1, detail_set.RecordCount() - 1);

                while (detail_set.EOF() == false)
                {

                    //If detail_set.mField("fShipped_qty") > detail_set.mField("fInvoiced_qty") Then

                    moMultiOrder.Data[Models.clsChargeDetail.INCLUDE_COL, row_num] = GlobalVar.goConstant.CHECKED_ON.ToString();
                    moMultiOrder.Data[Models.clsChargeDetail.ITEM_CODE_COL, row_num] = detail_set.sField("sItem_cd");
                    moMultiOrder.Data[Models.clsChargeDetail.DESCRIPTION_COL, row_num] = detail_set.sField("sDescription");
                    moMultiOrder.Data[Models.clsChargeDetail.UNIT_CODE_COL, row_num] = detail_set.sField("sUnit_cd");

                    if (moDatabase.uSecurity.bShowOriginalQtyOrdered_fl)
                    {
                        moMultiOrder.Data[Models.clsChargeDetail.QTY_ORDERED_COL, row_num] = detail_set.mField("fOrdered_qty").ToString();
                    }
                    else if (mbFromPackingSlip_fl)
                    {
                        moMultiOrder.Data[Models.clsChargeDetail.QTY_ORDERED_COL, row_num] = (detail_set.mField("fOrdered_qty") - detail_set.mField("fInvoiced_qty")).ToString();
                    }
                    else
                    {
                        moMultiOrder.Data[Models.clsChargeDetail.QTY_ORDERED_COL, row_num] = detail_set.mField("fBackOrder_qty").ToString();
                    }

                    if (mbFromPackingSlip_fl == false)
                    {
                        moMultiOrder.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, row_num] = (detail_set.mField("fAllocated_qty") - detail_set.mField("fShipped_qty")).ToString(); // QTY ALLOCATION : Do NOT USE fOrdered_qty
                    }
                    else if (detail_set.mField("fShipped_qty") > detail_set.mField("fInvoiced_qty"))
                    {
                        moMultiOrder.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, row_num] = (detail_set.mField("fShipped_qty") - detail_set.mField("fInvoiced_qty")).ToString();
                    }
                    else if (!moUtility.IsEmpty(detail_set.sField("sItem_cd")))
                    {
                        moMultiOrder.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, row_num] = "0";
                    }
                    else
                    {
                        moMultiOrder.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, row_num] = detail_set.mField("fAllocated_qty").ToString(); // QTY ALLOCATION : Do NOT USE fOrdered_qty
                    }

                    moMultiOrder.Data[Models.clsChargeDetail.UNIT_PRICE_COL, row_num] = moMoney.ToStrMoney(detail_set.mField("mUnitPrice_amt"));
                    moMultiOrder.Data[Models.clsChargeDetail.TAX_CODE_COL, row_num] = detail_set.sField("sTax_cd");
                    moMultiOrder.Data[Models.clsChargeDetail.TAX_PERC_COL, row_num] = detail_set.mField("fTax_pc").ToString();
                    moMultiOrder.Data[Models.clsChargeDetail.IVUNIT_CODE_COL, row_num] = detail_set.sField("sIVUnit_cd");
                    moMultiOrder.Data[Models.clsChargeDetail.ITEM_TYPE_COL, row_num] = detail_set.iField("iItem_typ").ToString();
                    moMultiOrder.Data[Models.clsChargeDetail.CONVERSION_RATE_COL, row_num] = detail_set.mField("fConversionRate").ToString();
                    moMultiOrder.Data[Models.clsChargeDetail.KIT_ID_COL, row_num] = detail_set.iField("iKit_id").ToString();

                    moMultiOrder.Data[Models.clsChargeDetail.SOURCE_DETAIL_ID_COL, row_num] = detail_set.iField("iLine_id").ToString(); // Do not delete this. This is used to communicate with P/O.
                    moMultiOrder.Data[Models.clsChargeDetail.LINE_ID_COL, row_num] = (row_num + 1).ToString();

                    // - If item code is not empty, then this job code will be just informative, it won't be
                    // copied over to the voucher screen.  It just stays in PO so that the items can be identified
                    // for each job when they arrive.
                    // - If the item code is empty, then this line is treated as an expense to this job.
                    // When the items are actually used in this job, you need to use Inventory Adjustment
                    // screen to enter the item and quantity.
                    //
                    if (moUtility.STrim(detail_set.sField("sItem_cd")) == "")
                    {
                        moMultiOrder.Data[Models.clsChargeDetail.JOB_CODE_COL, row_num] = detail_set.sField("sJob_cd");
                    }
                    else
                    {
                        moMultiOrder.Data[Models.clsChargeDetail.JOB_CODE_COL, row_num] = "";
                    }

                    moMultiOrder.Data[Models.clsChargeDetail.FULL_ACCT_CODE_COL, row_num] = detail_set.sField("sRevenueAcct_cd");
                    moMultiOrder.Data[Models.clsChargeDetail.PRIMARY_ITEM_CODE_COL, row_num] = detail_set.sField("sPrimaryItem_cd");
                    moMultiOrder.Data[Models.clsChargeDetail.SELL_UNIT_CODE_COL, row_num] = detail_set.sField("sSellUnit_cd");
                    moMultiOrder.Data[Models.clsChargeDetail.SELL_UNIT_PRICE_COL, row_num] = moMoney.ToStrMoney(detail_set.mField("mSellUnitPrice_amt"));

                    //End If

                    detail_set.MoveNext();
                    row_num += 1;

                }

                return_value = moMultiOrder.RecreateGrid();
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (ShowMultiOrder)");
            }

            return return_value;
        }

        public bool AddMultiOrder()
        {
            bool return_value = false;
            int row_num = 0;
            int total_rows_to_add = 0;
            int main_row_num = 0;
            int starting_row_num = 0;
            int i = 0;
            int new_row_num = 0;
            decimal line_discount_amt = 0M;

            Models.clsChargeDetail.clsGrid grid_line;

            try
            {
                total_rows_to_add = 0;
                moMultiOrder.RecreateDetail();

                foreach (var det in moMultiOrder.Grid)
                {
                    if (det.chkInclude_fl && moUtility.ToValue(det.txtShipped_qty) > 0)
                    {
                        total_rows_to_add += 1;
                    }
                }

                if (total_rows_to_add == 0)
                {
                    FormShowMessage(User.Language.oMessage.NO_RECORDS_FOUND);
                    return false;
                }

                // Add the lines to moMultiOrder.Grid and Resync moMultiOrder.Data[]
                //
                moDetail.AddMoreRows(total_rows_to_add + 1);
                moDetail.RecreateDetail();

                starting_row_num = GetStartingRowInMainTable();
                new_row_num = starting_row_num;

                for (row_num = 0; row_num < moMultiOrder.Data.GetLength(1); row_num++)
                {
                    if (moUtility.ToInteger(moMultiOrder.Data[Models.clsChargeDetail.INCLUDE_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON)
                    {

                        // Check if already included.
                        //
                        for (i = 0; i < starting_row_num; i++)
                        {
                            if (moDetail.Data[Models.clsChargeDetail.ORDER_NUM_COL, i] == Header.txtMultiOrder_num 
                                && moDetail.Data[Models.clsChargeDetail.SOURCE_DETAIL_ID_COL, i] == moMultiOrder.Data[Models.clsChargeDetail.SOURCE_DETAIL_ID_COL, row_num])
                            {
                                break;
                            }
                        }

                        if (i < starting_row_num)
                        {
                            main_row_num = i;
                        }
                        else
                        {
                            main_row_num = new_row_num;
                            new_row_num += 1;
                        }

                        moDetail.Data[Models.clsChargeDetail.ITEM_CODE_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.ITEM_CODE_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.DESCRIPTION_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.DESCRIPTION_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.UNIT_CODE_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.UNIT_CODE_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.QTY_ORDERED_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.QTY_ORDERED_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.UNIT_PRICE_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.UNIT_PRICE_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.JOB_CODE_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.JOB_CODE_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.TAX_CODE_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.TAX_CODE_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.TAX_PERC_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.TAX_PERC_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.IVUNIT_CODE_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.IVUNIT_CODE_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.ITEM_TYPE_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.ITEM_TYPE_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.CONVERSION_RATE_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.CONVERSION_RATE_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.KIT_ID_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.KIT_ID_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.FULL_ACCT_CODE_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.FULL_ACCT_CODE_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.ORDER_NUM_COL, main_row_num] = Header.txtMultiOrder_num;
                        moDetail.Data[Models.clsChargeDetail.PRIMARY_ITEM_CODE_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.PRIMARY_ITEM_CODE_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.SELL_UNIT_CODE_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.SELL_UNIT_CODE_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.SELL_UNIT_PRICE_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.SELL_UNIT_PRICE_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.SOURCE_DETAIL_ID_COL, main_row_num] = moMultiOrder.Data[Models.clsChargeDetail.SOURCE_DETAIL_ID_COL, row_num];
                        moDetail.Data[Models.clsChargeDetail.LINE_ID_COL, main_row_num] = (main_row_num + 1).ToString();

                        // All calcluations are based on clsChargeDetail.clsGrid so that we need to copy this array line to grid line for line calculation
                        // -------------------------------------------------------------------------------------------------------------------------------
                        //
                        grid_line = new Models.clsChargeDetail.clsGrid();

                        if (moDetail.FindGridLine(main_row_num, ref grid_line) == false)
                        {
                            FormShowMessage("moDetail.Grid does not match moDetail.Data");      // Should not happen
                            return false;
                        }
                        else
                        {
                            if (moDetail.RecreateGridLine(ref grid_line, main_row_num))
                            {
                                FormShowMessage(moDetail.GetErrorMessage());
                                return false;
                            }
                            if (moDetail.ProcessChargeQty(ref moDatabase, ref grid_line, ref grid_line.txtShipped_qty, 1, "", "") == false)
                            {
                                FormShowMessage();
                                return false;
                            }
                            if (moDetail.ProcessUnitPrice(ref moDatabase, ref grid_line, ref grid_line.txtShipped_qty, 1, false) == false)
                            {
                                FormShowMessage();
                                return false;
                            }
                         
                            if (FormCalculateCurrentRow(grid_line) == false)
                            {
                                FormShowMessage();
                                return false;
                            }

                            // Copy the change back to this array line.
                            //
                            if (moDetail.RecreateDetailLine(grid_line, main_row_num) == false)
                            {
                                FormShowMessage(moDetail.GetErrorMessage());
                                return false;
                            }
                        }
                        // -------------------------------------------------------------------------------------------------------------------------------
                        //  End of line calculation

                    }
                }
                
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (AddMultiOrder)");
            }

            return return_value;
        }

        private void CountColumns()
        {
            if (miMatrixColumn > moItemMatrix.TotalColumns)
            {
                miMatrixColumn = 1;
            }
            else
            {
                miMatrixColumn += 1;
            }
        }

        public bool CreateDetailLinesFromMatrix()                                                       //  To read the item matrix into moDetail.Grid & moDetail.Data[].
        {
            bool return_value = false;
            int max_row = 0;
            int row_num = 0;
            int active_row = 0;

            Models.clsChargeDetail.clsGrid grid_line = new Models.clsChargeDetail.clsGrid();

            try
            {
                FormRecreateDetail();       // Just to make sure moDetail.Data[] is in sync.

                max_row = 0;

                // Check how many rows we are adding.
                for (row_num = 0; row_num <= moItemMatrix.SegmentedData.GetLength(1) - 1; row_num++)
                {
                    if (moUtility.IsNonEmpty(moItemMatrix.SegmentedData[moItemMatrix.ITEM_CODE_COL, row_num]) && moUtility.ToValue(moItemMatrix.SegmentedData[moItemMatrix.QTY_COL, row_num]) >= moDatabase.fSmallestNumber)
                    {
                        max_row += 1;
                    }
                }

                // Check if we have empty rows for this addion.  Ok to check with moDetail.Data[] because we know it is already in sync.
                //
                for (active_row = moDetail.Data.GetUpperBound(1); active_row >= 0; active_row--)
                {
                    if (moUtility.IsNonEmpty(moDetail.Data[Models.clsChargeDetail.ITEM_CODE_COL, active_row]) || moUtility.IsNonEmpty(moDetail.Data[Models.clsChargeDetail.DESCRIPTION_COL, active_row]) 
                        || moUtility.ToValue(moDetail.Data[Models.clsChargeDetail.AMT_EXTENDED_COL, active_row]) > 0)
                    {
                        break;
                    }
                }

                active_row += 1;

                if ((moDetail.Grid.Count - active_row) <= max_row)
                {
                    FormAddMoreRows(max_row - (moDetail.Grid.Count - active_row) + 10);
                }

                for (row_num = 0; row_num <= moItemMatrix.SegmentedData.GetLength(1) - 1; row_num++)
                {
                    if (moUtility.IsNonEmpty(moItemMatrix.SegmentedData[moItemMatrix.ITEM_CODE_COL, row_num]) && moUtility.ToValue(moItemMatrix.SegmentedData[moItemMatrix.QTY_COL, row_num]) >= moDatabase.fSmallestNumber)
                    {

                        // All calcluations are based on clsChargeDetail.clsGrid so that we need to copy this item to grid line for line calculation
                        // -------------------------------------------------------------------------------------------------------------------------
                        //
                        if (moDetail.FindGridLine(active_row, ref grid_line) == false)
                        {
                            FormShowMessage("moDetail.Grid does not match moDetail.Data");      // Should not happen
                            return false;
                        }
                        else
                        {
                            grid_line.txtItem_cd = moItemMatrix.SegmentedData[moItemMatrix.ITEM_CODE_COL, row_num];
                            if (DetailItem_cd_Verified(grid_line) == false)
                            {
                                return false;
                            }

                            grid_line.txtShipped_qty = moItemMatrix.SegmentedData[moItemMatrix.QTY_COL, row_num];
                            if (DetailShipped_qty_Verified(grid_line) == false)
                            {
                                return false;
                            }

                            // 04/26/2020:  labSystemPrice_amt is introduced
                            // This will wipe-out the qty-discount if user changes price.
                            //
                            if (moMoney.ToNumMoney(Header.txtMatrixUnitPrice_amt) > 0 && moMoney.ToNumMoney(Header.txtMatrixUnitPrice_amt) != moMoney.ToNumMoney(Header.lblSystemUnitPrice_amt))
                            {
                                grid_line.txtUnitPrice_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.txtMatrixUnitPrice_amt));

                                if (DetailUnitPrice_amt_Verified(grid_line) == false)
                                {
                                    return false;
                                }
                            }

                            if (FormCalculateCurrentRow(grid_line) == false)
                            {
                                return false;
                            }

                            // Copy the change back to this array line.
                            //
                            if (moDetail.RecreateDetailLine(grid_line, active_row) == false)
                            {
                                FormShowMessage(moDetail.GetErrorMessage());
                                return false;
                            }
                        }

                        active_row += 1;
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateDetailLinesFromMatrix)");
            }

            return return_value;
        }


        //  To read the items selected into moDetail.Grid & moDetail.Data[].
        //
        public bool CreateDetailLinesFromZoom(ref int total_rows_to_add)
        {
            bool return_value = false;
            int active_row = 0;

            Models.clsChargeDetail.clsGrid grid_line = new Models.clsChargeDetail.clsGrid();

            try
            {
                FormRecreateDetail();       // Just to make sure moDetail.Data[] is in sync.

                total_rows_to_add = 0;

                // Check how many rows we are adding.
                //
                foreach (var itm in moZoom.Grid)
                {
                    if (itm.chkInclude_fl && moUtility.IsNonEmpty(itm.Col_0))
                    {
                        total_rows_to_add += 1;
                    }
                }

                // Check if we have empty rows for this addion.  Ok to check with moDetail.Data[] because we know it is already in sync.
                //
                for (active_row = moDetail.Data.GetUpperBound(1); active_row >= 0; active_row--)
                {
                    if (moUtility.IsNonEmpty(moDetail.Data[Models.clsChargeDetail.ITEM_CODE_COL, active_row]) || moUtility.IsNonEmpty(moDetail.Data[Models.clsChargeDetail.DESCRIPTION_COL, active_row])
                        || moUtility.ToValue(moDetail.Data[Models.clsChargeDetail.AMT_EXTENDED_COL, active_row]) > 0)
                    {
                        break;
                    }
                }

                active_row += 1;

                if ((moDetail.Grid.Count - active_row) <= total_rows_to_add)
                {
                    FormAddMoreRows(total_rows_to_add - (moDetail.Grid.Count - active_row) + 5);
                }

                foreach (var itm in moZoom.Grid)
                {
                    if (itm.chkInclude_fl && moUtility.IsNonEmpty(itm.Col_0))
                    {

                        // All calcluations are based on clsChargeDetail.clsGrid so that we need to copy this item to grid line for line calculation
                        // -------------------------------------------------------------------------------------------------------------------------
                        //
                        if (moDetail.FindGridLine(active_row, ref grid_line) == false)
                        {
                            FormShowMessage("moDetail.Grid does not match moDetail.Data");      // Should not happen
                            return false;
                        }
                        else
                        {
                            grid_line.txtItem_cd = itm.Col_0;
                            if (DetailItem_cd_Verified(grid_line) == false)
                            {
                                return false;
                            }

                            if (moUtility.ToValue(itm.Qty) > 0)
                            {
                                grid_line.txtShipped_qty = itm.Qty;
                                if (DetailShipped_qty_Verified(grid_line) == false)
                                {
                                    return false;
                                }
                            }

                            // This will wipe-out the qty-discount if user enters price.
                            //
                            if (moMoney.ToNumMoney(itm.Price) > 0)
                            {
                                grid_line.txtUnitPrice_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(itm.Price));

                                if (DetailUnitPrice_amt_Verified(grid_line) == false)
                                {
                                    return false;
                                }
                            }

                            if (FormCalculateCurrentRow(grid_line) == false)
                            {
                                return false;
                            }

                            // Copy the change back to this array line.
                            //
                            if (moDetail.RecreateDetailLine(grid_line, active_row) == false)
                            {
                                FormShowMessage(moDetail.GetErrorMessage());
                                return false;
                            }
                        }

                        active_row += 1;
                    }

                    itm.chkInclude_fl = false;
                    itm.Qty = "";
                    itm.Price = "";

                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateDetailLinesFromZoom)");
            }

            return return_value;
        }


        private bool SetReportSelection()
        {
            bool return_value = false;
            string sql_str = "";
            string customer_cd = "";

            if (optReportOption_typ == 2 && Header.chkDropShipment_fl)
            {
                customer_cd = Header.txtCustomer_cd;
            }
            else
            {
                customer_cd = "";
            }

            if (false == modCommonReportUtility.SetCompanyInReport(ref moDatabase, "frmQuickPrintInvoice", ref moReport, customer_cd, (moUtility.IsNonEmpty(modCommonUtility.GetCompanyLogoFile(ref moDatabase)))))
            {
                FormShowMessage();
                return false;
            }

            try
            {
                sql_str = "{tblARChargeUnposted.iTransaction_typ} = " + moPage.iTransaction_typ.ToString();
                sql_str += " and {tblARChargeUnposted.iTransaction_num} = " + Header.txtKey_id;

                if (optReportOption_typ != 1)
                {
                    if (moUtility.ToInteger(cboReport_typ) == GlobalVar.goARConstant.INVOICE_TYPE_LC1_NUM)
                    {
                        sql_str += " and {tblARChargeCompact.mExtended_amt} >= 0 "; // Exluced the discount in P/S.
                        sql_str += " and {tblARChargeCompact.iLine_typ} <> " + clsConstant.LINE_TYPE_DISCOUNT.ToString();
                        if (moUtility.ToInteger(Header.txtOrder_num) == 0)
                        {
                            //sql_str &= " and ({tblARChargeCompact.fShipped_qty} > 0 or {tblARChargeCompact.fColumn1_qty} > 0  or {tblARChargeCompact.fColumn2_qty} > 0  or {tblARChargeCompact.fColumn3_qty} > 0 or {tblARChargeCompact.fColumn4_qty} > 0  ) "    ' When S/O exists, we need to show the qty ordered
                        }
                    }
                    else
                    {

                        if (moUtility.ToInteger(cboReport_typ) != GlobalVar.goARConstant.INVOICE_TYPE_LM1_NUM)
                        {
                            //sql_str &= " and {tblARChargeDetUnposted.fShipped_qty} > 0 "
                        }

                        sql_str += " and {tblARChargeDetUnposted.mExtended_amt} >= 0 ";
                        sql_str += " and {tblARChargeDetUnposted.iLine_typ} <> " + clsConstant.LINE_TYPE_DISCOUNT.ToString();

                    }

                }

                moReport.SetSelectionFormula(sql_str);

                // Set the extra columns
                //
                if (moDatabase.uSecurity.bShowColorColumn_fl)
                {
                    moReport.SetFormula("color_caption", moDatabase.uSecurity.sColorCaption);
                }
                else
                {
                    moReport.SetFormula("color_caption", "");
                }
                if (moDatabase.uSecurity.bShowSizeColumn_fl)
                {
                    moReport.SetFormula("size_caption", moDatabase.uSecurity.sSizeCaption);
                }
                else
                {
                    moReport.SetFormula("size_caption", "");
                }
                if (moDatabase.uSecurity.bShowStyleColumn_fl)
                {
                    moReport.SetFormula("style_caption", moDatabase.uSecurity.sStyleCaption);
                }
                else
                {
                    moReport.SetFormula("style_caption", "");
                }

                if (moDatabase.uSecurity.bShowModelColumn_fl)
                {
                    moReport.SetFormula("model_caption", moDatabase.uSecurity.sModelCaption);
                }
                else
                {
                    moReport.SetFormula("model_caption", "");
                }
                if (moDatabase.uSecurity.bShowBrandColumn_fl)
                {
                    moReport.SetFormula("brand_caption", moDatabase.uSecurity.sBrandCaption);
                }
                else
                {
                    moReport.SetFormula("brand_caption", "");
                }

                if (moUtility.IsEmpty(customer_cd)) // Only if not drop sipment
                {
                    moReport.SetFormula(modConstant.CRYSTAL_LOGO_FUNCTION, modCommonUtility.GetCompanyLogoFile(ref moDatabase));
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SetReportSelection)");
            }

            return return_value;
        }

        public bool CopyOrderCommissionToInvoice(int order_num)
        {
            moCommission.GetCommission(GlobalVar.goConstant.TRX_SO_TYPE, order_num);

            return true;
        }

        private bool SaveSerial()
        {
            bool return_value = false;
            int row_num = 0;
            int total_num = 0;

            try
            {
                // Copy the serial/lot numbers from moDetail.Data[] to moSerial.sLotArray[] that will be saved at saving.
                //
                for (row_num = 0; row_num < moDetail.Data.GetUpperBound(1); row_num++)
                {
                    if (moSerial.IsSerialOrLotItem(moUtility.ToInteger(moDetail.Data[Models.clsChargeDetail.ITEM_TYPE_COL, row_num]))
                        && moUtility.IsNonEmpty(moDetail.Data[Models.clsChargeDetail.SERIAL_CODE_COL, row_num]))
                    {
                        total_num += 1;
                    }
                }

                if (total_num == 0)
                {
                    return true;
                }

                moUtility.ResizeDim(ref moSerial.sLotArray, clsSerial.TOTAL_COL - 1, total_num - 1);

                total_num = 0;
                for (row_num = 0; row_num < moDetail.Data.GetUpperBound(1); row_num++)
                {
                    if (moSerial.IsSerialOrLotItem(moUtility.ToInteger(moDetail.Data[Models.clsChargeDetail.ITEM_TYPE_COL, row_num]))
                        && moUtility.IsNonEmpty(moDetail.Data[Models.clsChargeDetail.SERIAL_CODE_COL, row_num]))
                    {
                        moSerial.sLotArray[clsSerial.ITEM_CODE_COL, total_num] = moDetail.Data[Models.clsChargeDetail.ITEM_CODE_COL, row_num];
                        moSerial.sLotArray[clsSerial.SERIAL_CODE_COL, total_num] = moDetail.Data[Models.clsChargeDetail.SERIAL_CODE_COL, row_num];
                        moSerial.sLotArray[clsSerial.QTY_COL, total_num] = moDetail.Data[Models.clsChargeDetail.QTY_SHIPPED_COL, row_num];
                        moSerial.sLotArray[clsSerial.UNIT_CODE_COL, total_num] = moDetail.Data[Models.clsChargeDetail.UNIT_CODE_COL, row_num];
                        moSerial.sLotArray[clsSerial.UNIT_COST_COL, total_num] = moDetail.Data[Models.clsChargeDetail.UNIT_COST_COL, row_num];
                        moSerial.sLotArray[clsSerial.UNIT_PRICE_COL, total_num] = moDetail.Data[Models.clsChargeDetail.UNIT_PRICE_COL, row_num];
                        moSerial.sLotArray[clsSerial.DETAIL_LINE_ID_COL, total_num] = moDetail.Data[Models.clsChargeDetail.LINE_ID_COL, row_num];
                        moSerial.sLotArray[clsSerial.LOCATION_CODE_COL, total_num] = Header.cboLocation_cd;

                        total_num += 1;
                    }
                }

                moSerial.iTotalRows = total_num;
                moInvoice.oSerial = moSerial;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SaveSerial)");
            }

            return return_value;
        }

        private bool CreateSearchHTML()
        {
            bool return_value = false;
            string html_file = "";
            string[] header_list = null;

            clsSpreadsheet o_search = new clsSpreadsheet();

            try
            {
                if (ShowSearchPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moSearch, ref o_search, ref header_list) == false)      // Listing & Search both share PrepListingDownload()
                {
                    return false;
                }

                html_file = moInquiry.CreateHTML(ref moDatabase, moPage.Title, o_search, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(html_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(html_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateSearchHTML)");
            }

            return return_value;
        }


        private bool CreateSearchExcel()
        {
            bool return_value = false;
            string csv_file = "";
            string[] header_list = null;

            clsSpreadsheet o_search = new clsSpreadsheet();

            try
            {
                if (ShowSearchPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moSearch, ref o_search, ref header_list) == false)
                {
                    return false;
                }

                csv_file = moInquiry.CreateCSV(ref moDatabase, moPage.Title, o_search, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(csv_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(csv_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateSearchExcel)");
            }

            return return_value;
        }

        private bool PrepListingDownload(clsListingCharge o_listing, ref clsSpreadsheet o_spread, ref string[] header_list)
        {
            bool return_value = false;
            int row_num = 0;
            int i = 0;

            try
            {
                moUtility.ResizeDim(ref o_spread.Data, 13, o_listing.Grid.Count - 1);

                foreach (var lst in o_listing.Grid)
                {
                    i = 0;

                    o_spread.Data[i++, row_num] = lst.Transaction_num;
                    o_spread.Data[i++, row_num] = lst.Status_typ;
                    o_spread.Data[i++, row_num] = lst.Entry_dt;
                    o_spread.Data[i++, row_num] = lst.Apply_dt;
                    o_spread.Data[i++, row_num] = lst.Due_dt;
                    o_spread.Data[i++, row_num] = lst.Entity_cd;
                    o_spread.Data[i++, row_num] = lst.Entity_nm;
                    o_spread.Data[i++, row_num] = lst.Agent_cd;
                    o_spread.Data[i++, row_num] = lst.Terms_cd;
                    o_spread.Data[i++, row_num] = lst.Reference;
                    o_spread.Data[i++, row_num] = lst.Total_amt;
                    o_spread.Data[i++, row_num] = lst.Paid_amt;
                    o_spread.Data[i++, row_num] = lst.Due_amt;
                    o_spread.Data[i++, row_num] = lst.Comment;

                    row_num += 1;
                }

                moUtility.ResizeDim(ref header_list, i - 1);
                i = 0;

                header_list[i++] = User.Language.oCaption.NUMBER;
                header_list[i++] = User.Language.oCaption.STATUS;
                header_list[i++] = User.Language.oCaption.ENTRY_DATE;
                header_list[i++] = User.Language.oCaption.APPLY_DATE;
                header_list[i++] = User.Language.oCaption.DUE_DATE;
                header_list[i++] = User.Language.oCaption.CUSTOMER;
                header_list[i++] = User.Language.oCaption.NAME;
                header_list[i++] = User.Language.oCaption.SALESREP;
                header_list[i++] = User.Language.oCaption.TERMS;
                header_list[i++] = User.Language.oCaption.REFERENCE;
                header_list[i++] = User.Language.oCaption.TOTAL_AMT;
                header_list[i++] = User.Language.oCaption.PAID;
                header_list[i++] = User.Language.oCaption.DUE;
                header_list[i++] = User.Language.oCaption.COMMENT;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PrepListingDownload)");
            }

            return return_value;
        }


        private bool CreateListingHTML()
        {
            bool return_value = false;
            string html_file = "";
            string[] header_list = null;

            clsSpreadsheet o_listing = new clsSpreadsheet();

            try
            {
                if (ShowListingPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moListing, ref o_listing, ref header_list) == false)
                {
                    return false;
                }

                html_file = moInquiry.CreateHTML(ref moDatabase, moPage.Title, o_listing, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(html_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(html_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateListingHTML)");
            }

            return return_value;
        }


        private bool CreateListingExcel()
        {
            bool return_value = false;
            string csv_file = "";
            string[] header_list = null;

            clsSpreadsheet o_listing = new clsSpreadsheet();

            try
            {
                if (ShowListingPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moListing, ref o_listing, ref header_list) == false)
                {
                    return false;
                }

                csv_file = moInquiry.CreateCSV(ref moDatabase, moPage.Title, o_listing, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(csv_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(csv_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateListingExcel)");
            }

            return return_value;
        }

    }
}
