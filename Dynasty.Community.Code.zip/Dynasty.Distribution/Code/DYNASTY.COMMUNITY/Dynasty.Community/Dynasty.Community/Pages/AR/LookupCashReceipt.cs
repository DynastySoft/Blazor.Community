﻿//  Copyright (c) DynastySoft Corporation, Since 1997.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;

using Dynasty.Database;
using Dynasty.Report;
using Dynasty.Local;
using Dynasty.ASP.Models;
using Dynasty.ASP.Models;

namespace Dynasty.ASP.Pages.AR
{
    public partial class LookupCashReceipt
    {
        //  ===============================================================================================================================================================================================================================
        //  PARAMETER SECTION  
        //  ===============================================================================================================================================================================================================================
        [Parameter]
        public string StarterValue { get; set; } = "";

        //  ===============================================================================================================================================================================================================================
        //  INJECTION SECTION  
        //  ===============================================================================================================================================================================================================================
        //[Inject]                                                                                    // This should be uncommented & activated only for development.
        //public ILogger<BinGenerator> DynastyLogger { get; set; }                                      // Logs user message.  ex: DynastyLogger.LogInformation("Dynasty: Last updated by {msOriginalLastUpdate_id}", msOriginalLastUpdate_id);

        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                               // Keeps the current page/record info & status
        private Models.clsView moView;                                                               // View/Tab info
        private Models.clsZoom moZoom;
        private Models.clsListingPayment moListing;
        private Models.clsListingPayment moSearch;

        private bool ReadOnly                                                                       // True if the current record is read only.
        {
            get
            {
                if (User == null)
                {
                    moPage.bReadOnly_fl = true;
                }
                else
                {
                    moPage.bReadOnly_fl = (moPage.bReadOnly_fl || User.ViewOnly);
                }
                return (moPage.bReadOnly_fl);           // Do NOT include  || moPage.bReserved_fl);
            }
        }

        private bool ShowNavigation
        {
            get
            {
                return (moPage.iCurrentView != moView.ZOOM_PAGE_NUM && moPage.iCurrentView != moView.PRINT_PAGE_NUM);
            }
        }

        private bool ShowSearchPrinter
        {
            get
            {
                return (mbSearchInitiated_fl && mbSearchPopulated_fl);
            }
        }


        private bool ShowListingPrinter
        {
            get
            {
                return (mbListingInitiated_fl && mbListingPopulated_fl);
            }
        }

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;                                                             // We will have these four objects as page-level variables because they are very commonly used in every page
        private clsGeneral moGeneral;                                                               // These are instantiated in FormInit().
        private clsValidate moValidate;
        private clsDynastyUtility moUtility;
        private clsMoney moMoney;
        private Models.clsPaymentDetail moDetail;
        private clsTransactionPayment moTransactionPayment;
        private clsCashReceipt moCashReceipt;
        private clsReportViewer moReport;
        private Models.clsCustomField moCustomFields;
        private clsCustomer moCustomer;
        private Models.clsSession moSession;
        private clsInquiry moInquiry;

        private List<Models.clsCombobox> PaymentTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> FundCodeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> StatusTypeList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> DocumentNumberList = new List<Models.clsCombobox>();
        private List<Models.clsCombobox> CalendarYearList = new List<Models.clsCombobox>();

        private string msFund_cd = "";
        private string msReport_id = "";

        private string msCustomerList = "";
        private int miCustomerBalance_typ = 0;
        private bool mbReceiptEntered_fl = false;
        public decimal mmTotalDiscount_amt = 0;

        private string msHoldStatusMessage = "";

        // After-fact transaction
        // When this option is on, user can enter a transaction number less than the current system number.
        //
        private bool chkAfterFact_fl = false;

        // For receipt printing
        //
        private bool chkSendEmail_fl = false;
        private string txtEmailRecipient = "";

        public bool UseMemo
        {
            get { return (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM); }
        }

        public bool BalanceForward
        {
            get { return (miCustomerBalance_typ == GlobalVar.goARConstant.FORWARD_CUSTOMER_NUM); }
        }

        private string DocumentLabel
        {
            get
            {
                if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.CHECK_TYPE_NUM)
                {
                    return User.Language.oString.STR_CHECK_NUM;
                }
                else if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.WIRE_TRANSFER_TYPE_NUM)
                {
                    return User.Language.oString.STR_EFT_NUM;
                }
                else if (moUtility.ToInteger(Header.cboPayment_typ) == GlobalVar.goConstant.MEMO_TYPE_NUM)
                {
                    return User.Language.oString.STR_DEBIT_MEMO;
                }
                else
                {
                    return User.Language.oString.STR_DOCUMENT_NUM;
                }
            }
        }

        // Listing options
        //
        private List<Models.clsCombobox> ListingByList = new List<Models.clsCombobox>();
        private string cboListingBy = "";
        private bool mbListingInitiated_fl = false;
        private bool mbListingPopulated_fl = false;

        // Search options
        //
        private string cboSearchYear = "";
        private bool mbSearchInitiated_fl = false;
        private bool mbSearchPopulated_fl = false;

        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================

        private class clsHeader
        {
            public string txtKey_id = "";
            public string cboFund_cd = "";
            public string txtPaid_amt = "";
            public string txtCustomer_cd = "";
            public string txtDescription = "";
            public string txtReference = "";
            public string mskCashAcct_cd = "";
            public string txtDocument_num = "";
            public string txtFace_nm = "";
            public string cboStatus_typ = "";
            public string cboPayment_typ = "";
            public string lblCustomer_nm = "";
            public string lblTotalUsed_amt = "";
            public string lblNewBalanceDue_amt = "";
            public string lblTotalBalance_amt = "";
            public string lblPayTo_cd = "";
            public string txtBatch_num = "";
            public string cboDocument_num = "";

            public string txtUserApproved_cd = "";
            public string txtToApprove_num = "";

            public string lblTolerance_amt = "";

            // Listing of UI items on the header
            //

            public string mskApply_dt = "";
            public string mskEntry_dt = "";
            public DateTime? dtApply_dt = null;
            public DateTime? dtEntry_dt = null;

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag
            {
                public string txtKey_id = "";
                public string cboFund_cd = "";
                public string txtPaid_amt = "";
                public string txtCustomer_cd = "";
                public string txtReference = "";
                public string mskCashAcct_cd = "";
                public string txtDocument_num = "";
                public string txtFace_nm = "";
                public string cboStatus_typ = "";
                public string cboPayment_typ = "";
                public string cboDocument_num = "";
                public string lblCustomer_nm = "";

                public string mskApply_dt = "";
                public string mskEntry_dt = "";
                public DateTime? dtApply_dt = null;
                public DateTime? dtEntry_dt = null;
            }
            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()
            {
                Tag.txtKey_id = txtKey_id;
                Tag.cboFund_cd = cboFund_cd;
                Tag.txtPaid_amt = txtPaid_amt;
                Tag.txtCustomer_cd = txtCustomer_cd;
                Tag.txtReference = txtReference;
                Tag.mskCashAcct_cd = mskCashAcct_cd;
                Tag.txtDocument_num = txtDocument_num;
                Tag.cboStatus_typ = cboStatus_typ;
                Tag.cboPayment_typ = cboPayment_typ;
                Tag.cboDocument_num = cboDocument_num;
                Tag.lblCustomer_nm = lblCustomer_nm;                // Do not delete

                Tag.mskApply_dt = mskApply_dt;
                Tag.dtApply_dt = dtApply_dt;
                Tag.mskEntry_dt = mskEntry_dt;
                Tag.dtEntry_dt = dtEntry_dt;
            }
        }
        private clsHeader Header = new clsHeader();

        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            base.OnInitialized();

            // All page initializations come in this section.
            //
            FormInit();

            if (FormLoad() == false)
            {
                return;
            }

            // Tell page loading is complete.
            // Must come at the bottom.
            //
            moPage.bLoading_fl = false;
        }

        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-rendering.  (first_render_fl == true) only for the first time.
        {
            moPage.bInPrinting_fl = false;
            moPage.bErrorFound_fl = false;

            FormReArrangeHeader();      // This is necessary because the fields to be rearranged are not accessible/visible UNTIL NOW if they are in different view, yet.

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            moSession.RemoveSession(moDatabase);        // Delete the session file.

            // Do clean-ups 
            //
            moDatabase.CloseDatabase();
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
        }

        //  ===============================================================================================================================================================================================================================
        //  JAVA SECTION  :  Java function calls
        //  ===============================================================================================================================================================================================================================
        private void FormDisableField(string field_name, bool enable_fl = true)                     // Enable/Disable a UI input object.
        {
            Models.JSFunction.DisableField(JSRuntime, moPage, field_name, enable_fl);
        }

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormOpenPDF(string file_name)                                                  // Open a PDF file in another instance of browser.
        {
            Models.JSFunction.OpenWindow(JSRuntime, moPage, User.sWebSite + "/" + file_name);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            // If user uses date-picker, we need to change the date field.
            //
            if (User.bUseDatePicker_fl && moUtility.SLeft(field_name, 3) == "msk" && moUtility.SRight(field_name, 3) == "_dt")
            {
                field_name = moUtility.SReplace(field_name, "msk", "dt");
            }

            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods/functions that appear in the most code-behind.          Naming convention:  Each method/function name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================
        private bool FormAddMoreRows(int lines_to_add = 0)
        {

            return true;
        }

        private bool FormCalculateTotal()
        {

            return true;
        }

        private bool FormCancel()                                                                  // Cancels the current update
        {
            FormClear();

            return true;
        }

        private bool FormChange()
        {
            moPage.bModified_fl = true;    // NOT-YET: At this time of VS2019 v16.6.4, FormChange() is not fired by @onchange() on page-level. However, one day, this will start working.

            return true;
        }

        private bool FormCheck()                                                                   // validate the entire page for saving.
        {

            
            return false;
        }

        private bool FormCheckDetail()
        {
            bool return_value = false;
            int row_num;

            try
            {
                
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckDetail)");
            }

            return return_value;
        }

        private bool FormCheckExtra()                                                              // validate extra other than the header and detail.
        {
            bool return_value = false;

            try
            {
                
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckExtra)");
            }

            return return_value;
        }

        private bool FormCheckHeader()                                                             // validate the header data.
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
                
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormCheckHeader)");
            }

            return return_value;
        }

        private bool FormCheckConcurrency(clsRecordset cur_set)                                    // Check if someone has changed this record while it is open in this session.
        {

            return true;
        }

        private bool FormCheckToDelete()
        {
            
            return false;
        }

        private bool FormCheckSecurity()
        {
            return (modSecurity.SystemFormSecurityCheck(ref moDatabase) && (ReadOnly == false));
        }

        private bool FormClear()                                                                   // Clear the entire page.
        {
            FormClearHeader();
            FormClearDetail();
            FormClearExtra();

            return true;
        }

        private bool FormClearDetail()                                                             // Clear the detail.
        {
            moDetail.iTotalRows = 1; // User.iLinesToIncrease;
            moUtility.ResizeDim(ref moDetail.Data, Models.clsPaymentDetail.TOTAL_COLUMNS - 1, moDetail.iTotalRows - 1);

            FormRecreateGrid();

            return true;
        }

        private bool FormClearExtra()                                                              // Clear extra other than header & detail.
        {
            moPage.Clear();
            Header.Preserve();

            miCustomerBalance_typ = 0;
            mbReceiptEntered_fl = false;
            mmTotalDiscount_amt = 0;
            DocumentNumberList.Clear();

            // Custom Fields
            //
            moCustomFields.ClearGrid();

            FormReArrangeHeader();

            return true;
        }

        private bool FormClearHeader()                                                             // Clear the entire page.
        {
            Header.txtKey_id = "";
            Header.cboStatus_typ = "";
            Header.txtPaid_amt = "";
            Header.txtCustomer_cd = "";
            Header.txtDescription = "";
            Header.txtReference = "";
            Header.mskCashAcct_cd = "";
            Header.txtDocument_num = "";
            Header.txtFace_nm = "";
            Header.cboPayment_typ = "";
            Header.lblCustomer_nm = "";
            Header.lblTotalUsed_amt = "";
            Header.lblNewBalanceDue_amt = "";
            Header.lblTotalBalance_amt = "";
            Header.lblPayTo_cd = "";
            Header.txtBatch_num = "";
            Header.cboDocument_num = "";

            Header.txtUserApproved_cd = "";
            Header.txtToApprove_num = "";

            Header.lblTolerance_amt = "";

            Header.mskApply_dt = "";
            Header.mskEntry_dt = "";
            FormSyncDates(false);

            return true;
        }

        private bool FormClearMessage()
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormDialog(Func<bool> caller, int calling_point, string dialog_msg, int input_type = -1)
        {
            moPage.bInDialog_fl = true;         // Meaning a dialog started

            // caller should be the very first event triggered by UI.
            // calling_point numbering should be in ascending order if called multiple times within a call-sequence.
            // input_type should be a data type available in Modal if this is to get an input from user.
            //
            if (Modal.IsMyTurn(calling_point))
            {
                Modal.Show(dialog_msg, input_type);
                Modal.Register(caller, calling_point);                                             //  ModalCancel() & ModalOk() will send back to the caller registered.

                return false;
            }
            else if (Modal.IsMyCall(calling_point))
            {
                if (Modal.OK == false)
                {
                    Modal.Release();
                    moPage.bInDialog_fl = false;            // Meaning a dialog is enidng with Cancel button
                    return false;
                }
                else if (Modal.ValidInput == false)
                {
                    Modal.Show(User.Language.oMessage.PLEASE_ENTER_A_VALID_VALUE, input_type);

                    return false;
                }

                Modal.Release();                                                                   // Release this call and proceed.
            }

            moPage.bInDialog_fl = false;            // Meaning a dialog is enidng with Cancel button
            return true;
        }

        private bool FormLogout()
        {
            User.Clear();
            Modal.Release();
            FormTransfer(GlobalVar.LOGIN_WEB_PAGE_NAME);
            return true;
        }

        private bool FormDelete()
        {
            bool return_value = false;

            try
            {
                if (moUtility.IsEmpty(Header.txtKey_id) || moPage.bNew_fl)
                {
                    FormClear();
                    return true;
                }
                else if (FormCheckToDelete() == false)
                {
                    return false;
                }

                // Transaction begins here.
                //
                if (moDatabase.TransactionBegin() == false)
                {
                    FormShowMessage();
                    return false;
                }

                if (modFormUtility.RecordDelete(ref moDatabase, moPage.iScreen_typ, Header.txtKey_id, moPage.sKeyField_nm, moPage.sTable_nm, moPage.sDetailTable_nm, moPage.sRestrictionClause, moPage.iTransaction_typ) == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }
                else if (FormDeleteExtra() == false)
                {
                    moDatabase.TransactionRollback();
                    return false;
                }

                // Transaction ends here.
                //
                if (moDatabase.TransactionCommit() == false)
                {
                    moDatabase.TransactionRollback();
                    FormShowMessage();
                    return false;
                }

                return_value = true;

            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormDelete)");
                moDatabase.TransactionRollback();
                return_value = false;
            }

            return return_value;
        }

        private bool FormDeleteExtra()
        {

            return true;
        }

        private bool FormExit()
        {
            FormTransfer(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            return true;
        }

        private bool FormFindRecord(ref clsRecordset cur_set, int matching_type = 0)
        {
            bool return_value = false;

            matching_type = (int)(moUtility.IIf(matching_type > 0, matching_type, GlobalVar.goConstant.MATCHING_RECORD_TYPE));
            return_value = modFormUtility.RecordRead(ref moDatabase, ref cur_set, Header.txtKey_id, moPage.sTable_nm, moPage.sKeyField_nm, moPage.sPreviousKey_id, moPage.sRestrictionClause, ref matching_type);

            return return_value;
        }

        private bool FormInit()                                                                    // Initialize the page at loading.  Only once.
        {
            moPage = new Models.clsPage();
            moView = new Models.clsView();
            moZoom = new Models.clsZoom();
            moListing = new Models.clsListingPayment();
            moSearch = new Models.clsListingPayment();

            //  These should come before SetDefaultRestriction() call because it references the user credential.
            //
            moUtility = new clsDynastyUtility();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral(ref moDatabase);
            moValidate = new clsValidate(ref moDatabase);
            moMoney = new clsMoney(ref moDatabase);
            moDetail = new Models.clsPaymentDetail();
            moTransactionPayment = new clsTransactionPayment(ref moDatabase);
            moCashReceipt = new clsCashReceipt(ref moDatabase);
            moReport = new clsReportViewer();
            moCustomFields = new Models.clsCustomField();
            moCustomer = new clsCustomer(ref moDatabase);
            moSession = new Models.clsSession();
            moInquiry = new clsInquiry();

            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            moPage.sModule_id = GlobalVar.goConstant.ARMENU_NAME;
            moPage.Title = User.Language.oCaption.LOOKUP_CASH_RECEIPT;
            moPage.iScreen_typ = GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE;
            moPage.iTransaction_typ = GlobalVar.goConstant.TRX_RECEIPT_TYPE;

            moPage.sRestrictionClause = modFormUtility.SetDefaultRestriction(ref moDatabase, moPage.iScreen_typ, moPage.iTransaction_typ);

            Modal.Release();

            FormInitHeader();
            FormInitDetail();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool FormInitDetail()                                                              // Initialize the page at loading.  Only once.
        {
            // Detail table name.
            //
            moPage.sDetailTable_nm = "tblARPaymentDet";

            moUtility.ResizeDim(ref moDetail.Data, Models.clsPaymentDetail.TOTAL_COLUMNS - 1, 0);    // These initializations are necessary

            FormClearDetail();

            return true;
        }

        private bool FormInitHeader()                                                               // Initialize the page at loading.  Only once.
        {
            moPage.sTable_nm = "tblARPayment";
            moPage.sKeyField_nm = "iTransaction_num";

            return true;
        }

        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {
            // Since we utilize User.bUseDatePicker_fl, we need to sync dt* fields to msk* fields.
            // Make sure both, dt* and msk*, are sync'ed.
            // FormSave() & FormCheck() use the plain box whose name starts with "msk"
            // dt* variables are only to interact with UI.  Internally, msk* fields are used.
            //
            FormSyncDates(User.bUseDatePicker_fl);

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();
            return true;
        }

        private bool FormSyncDates(bool use_date_picker)
        {
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtApply_dt, ref Header.mskApply_dt, use_date_picker);
            modGeneralUtility.SyncDates(ref moDatabase, ref Header.dtEntry_dt, ref Header.mskEntry_dt, use_date_picker);

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback

            return true;
        }

        private bool FormLoad()                                                                    // Load UI components such as dropdown & option lists.  Should be called only once at page loading.
        {
            bool return_value = false;
            clsCustomization custom_fields = new clsCustomization(ref moDatabase);

            try
            {
                if (FormReceiveValues() == false)                    // All pages that use session value need to capture it here before FormOpenDatabase()
                {
                    return false;
                }
                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                modLoadUtility.LoadPaymentType(ref moDatabase, ref PaymentTypeList);
                modLoadUtility.LoadPostedStatusType(ref moDatabase, ref StatusTypeList);

                modLoadUtility.LoadListingBy(ref moDatabase, ref ListingByList, moPage.iTransaction_typ, User);
                modLoadUtility.LoadCalendarYear(ref CalendarYearList);
                cboSearchYear = moGeneral.CurrentYear().ToString();

                // Sales rep sees his own customers only.
                //
                if (moUtility.IsSalesStaff(moDatabase))
                {
                    msCustomerList = modCommonUtility.GetCustomerList(ref moDatabase, moDatabase.sUser_cd);

                    if (moUtility.IsNonEmpty(msCustomerList))
                    {
                        moPage.sRestrictionClause += moUtility.IIf(moUtility.IsNonEmpty(moPage.sRestrictionClause), " AND ", "") + "sCustomer_cd IN (" + msCustomerList + ")";
                    }
                }

                // Custom Fields
                //
                if (custom_fields.ReadCustomInfo(moPage.iTransaction_typ, ""))
                {
                    moCustomFields.CreateGrid(custom_fields.sField_nm, custom_fields.sCaptions, custom_fields.bRequired);
                }

                if (moUtility.IsNonEmpty(moPage.sInitialKey_id))
                {
                    Header.txtKey_id = moPage.sInitialKey_id;
                    txtKey_id_Changed();
                }

                User.bConnected_fl = true;

                FormSwitchView(moView.MAIN_PAGE_NUM);
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormLoad)");
            }

            return return_value;
        }

        private bool FormMove(int record_move_direction)
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }

            FormClear();

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            if (FormFindRecord(ref cur_set, record_move_direction) == false)
            {
                return false;
            }

            FormShow(cur_set);
            return true;

        }

        private bool FormPostSave()
        {
            // If this is a transaction page, and transaction number has changed, let the user know.
            //
            if (moPage.sPreviousKey_id != Header.txtKey_id)
            {
                FormShowMessage(User.Language.oMessage.TRX_NUM_HAS_CHANGED_TO + "  " + Header.txtKey_id, false);
            }

            moPage.sPreviousKey_id = Header.txtKey_id;

            return true;
        }

        private bool FormOpenDatabase()
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    FormShowMessage(moDatabase.GetErrorMessage());
                    return false;
                }
            }

            return true;
        }

        private bool FormPostTransactionRealtime()
        {
            int number_failed = 0;
            string posting_error = "";

            if (moDatabase.bRealTimeMode == false || moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.HOLD_TRX_NUM)
            {
                return true;
            }

            if (moGeneral.ApplyDateIsOkToPost(moGeneral.ToNumDate(Header.mskApply_dt), false) == false)
            {
                FormShowMessage(Header.mskApply_dt + User.Language.oMessage.IS_INVALID_FOR_POSTING);
                return false;
            }

            if (modPostUtility.PostOneTransaction(ref moDatabase, 0, 0, moGeneral.ToNumDate(Header.mskApply_dt), moGeneral.ToNumDate(Header.mskApply_dt)
                                , moUtility.ToInteger(Header.txtKey_id), moUtility.ToInteger(Header.txtKey_id), moPage.iTransaction_typ, posting_error, false, ref number_failed) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormPreSave(clsRecordset cur_set)
        {
            // Put some extra validation against the existing record
            // before saving the current modification.
            //

            if (chkAfterFact_fl)
            {
                // A.f.t. transactions should have a number non-existing number less than the current transaction number in the system.
                // Duplicate entry will be checked in clsInvoice.
                //
                if (moPage.bNew_fl)
                {
                    if (moUtility.ToInteger(Header.txtKey_id) >= modGeneralUtility.ReadNextTransactionNumber(ref moDatabase, moPage.iTransaction_typ))
                    {
                        FormShowMessage(Header.txtKey_id + User.Language.oMessage.IS_INVALID);
                        return false;
                    }
                }
            }
            else if (modGeneralUtility.CheckTransactionNumber(ref moDatabase, moPage.bNew_fl, moPage.iScreen_typ, moPage.iTransaction_typ, ref Header.txtKey_id) == false)
            {
                return false;
            }

            // Someone could have saved with the same number.
            //
            if (moPage.bNew_fl && Header.txtKey_id != moPage.sPreviousKey_id)
            {
                cur_set.Release();
            }

            // moInvoice.oSerial = moSerial;

            return true;
        }

        private bool FormPrint()
        {
            bool return_value = false;
            string pdf_file = "";
            string report_name = "";
            clsFile o_file = new clsFile();
            DateTime stime_started = DateTime.Now;
            clsMail o_mail = new clsMail(ref moDatabase);

            try
            {
                if (FormOpenDatabase() == false)        // Do not delete this
                {
                    return false;
                }

                moReport.InitReport(moUtility.GetServerName(ref moDatabase), moUtility.GetDatabaseName(ref moDatabase), moUtility.GetDBUser(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_ID)
                                    , moUtility.GetDBPassword(ref moDatabase, GlobalVar.goConstant.SYSTEM_USER_PASSWORD), moDatabase.uDirectory.sPDFDirectory_nm, true, true);


                report_name = moDatabase.uDirectory.sReportDirectory_nm + "\\ar" + modCommonReportUtility.GetReportInitial(ref moDatabase) + "672cr.rpt";

                moReport.SetFileName(report_name, GlobalVar.goUtility.GetCustomReportFolder(ref moDatabase));

                if (SetReportSelection() == false)
                {
                    return false;
                }

                if (moReport.PrintReport(ref moDatabase, GlobalVar.goConstant.PRINT_TO_PDF, ref pdf_file) == false)
                {
                    FormShowMessage(moReport.GetErrorMessage());
                    return false;
                }

                if (moUtility.IsEmpty(pdf_file) || modWebReportUtility.PDFFound(pdf_file) == false)
                {
                    FormShowMessage(User.Language.oMessage.REPORT_SERVER_NOT_RESPONDING);
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(pdf_file, true));

                txtEmailRecipient = moUtility.STrim(txtEmailRecipient);

                if (chkSendEmail_fl && moUtility.IsNonEmpty(txtEmailRecipient))
                {
                    if (o_mail.SendMail(User.Language.oString.STR_RECEIPT + ": " + Header.txtKey_id, moDatabase.uCompany.sName + " sent receipt #" + Header.txtKey_id, moDatabase.sSystemEmailAddress, txtEmailRecipient, pdf_file) == false)
                    {
                        FormShowMessage();
                    }
                    else
                    {
                        FormShowMessage(User.Language.oMessage.RECEIPT_HAS_BEEN_SENT_TO + txtEmailRecipient + ". " + User.Language.oMessage.IT_MAY_TAKE_A_MINUTE_TO_ARRIVE, false);
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormPrint)");
            }

            return return_value;
        }



        private bool FormReArrangeHeader()                                                         // Arrange(show/hide, enable/disable) the fields in the header section
        {

            return true;
        }

        private bool FormRecreateDetail()
        {
            if (moDetail.RecreateDetail() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateDetailLine(Models.clsPaymentDetail.clsGrid cur_item, int row_num = -1)
        {
            if (moDetail.RecreateDetailLine(cur_item, row_num) == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormRecreateGrid()
        {
            if (moDetail.RecreateGrid() == false)
            {
                FormShowMessage();
                return false;
            }

            return true;
        }

        private bool FormReceiveValues()
        {
            // If connected already, return true.  This means this page came through the menu system.
            //
            if (moUtility.IsNonEmpty(User.sServer_nm) || moDatabase.IsConnected())
            {
                return true;
            }

            // Otherwise, need to login with the info passed from the calling page.
            //
            if (modGeneralUtility.GetPassedParameters(StarterValue, User, moSession) == false)
            {
                FormShowMessage(User.Language.oMessage.PLEASE_LOG_IN_FIRST);
                return false;
            }

            moPage.sInitialKey_id = moSession.Value.Entity;

            return true;
        }

        private bool FormSave()
        {
            return true;
        }

        private bool FormSaveDetail()
        {
            return true;
        }

        private bool FormSaveExtra(clsRecordset cur_set)
        {
            return true;
        }

        private bool FormSaveHeader(clsRecordset cur_set)
        {
            return true;
        }

        private bool FormSearch()
        {
            string search_detail = "";
            string where_clause = GetSearchCriteria();

            if (moUtility.IsEmpty(where_clause))
            {
                where_clause = search_detail;
            }
            else
            {
                where_clause += moUtility.IIf(moUtility.IsNonEmpty(search_detail), " AND ", "") + search_detail;
            }

            if (moUtility.IsEmpty(where_clause))
            {
                FormShowMessage(User.Language.oMessage.PLEASE_ENTER_THE_SEARCH_CRITERIA_ON_THE_MAIN_ENTRY_TAB);
                return false;
            }

            mbSearchPopulated_fl = false;

            where_clause = moUtility.IIf(moUtility.IsNonEmpty(moPage.sRestrictionClause), moPage.sRestrictionClause, "iTransaction_typ = " + moPage.iTransaction_typ.ToString()) + " AND " + where_clause;

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            where_clause = modCommonUtility.AddCommonTransactionSearchClause(where_clause, moPage.iTransaction_typ, cboSearchYear);

            if (moSearch.Show(moDatabase, moPage, where_clause) == false)
            {
                FormShowMessage();
                return false;
            }

            mbSearchInitiated_fl = true;
            mbSearchPopulated_fl = (moSearch.Grid.Count > 0);

            if (mbSearchPopulated_fl == false)
            {
                FormShowMessage(User.Language.oMessage.NO_MATCHING_RECORDS_FOUND);
            }

            return true;
        }

        private bool FormShow(clsRecordset cur_set)
        {
            if (FormShowHeader(cur_set) == false)
            {
                return false;
            }
            else if (FormShowExtra(cur_set) == false)
            {
                return false;
            }
            else if (FormShowDetail() == false)
            {
                return false;
            }

            FormReArrangeHeader();

            return true;
        }

        private bool FormShowDetail()
        {
            bool return_value = false; ;
            string sql_str = "";
            int row_num = 0;
            decimal disc_avail = 0;
            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                FormClearDetail();

                sql_str = "SELECT p.*, c.sFund_cd, c.iDue_dt, c.iApply_dt, c.sTransaction_num FROM tblARPaymentDet p ";
                sql_str += " LEFT JOIN tblARCharge c ON (p.iAppliedTransaction_typ = c.iTransaction_typ AND p.iAppliedTransaction_num = c.iTransaction_num)";
                sql_str += " WHERE p.iTransaction_typ = " + moPage.iTransaction_typ.ToString();
                sql_str += " AND p.iTransaction_num = " + Header.txtKey_id;
                sql_str += " ORDER BY p.iDetail_num";
                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    return false;
                }

                moDetail.iTotalRows = cur_set.RecordCount();
                moUtility.ResizeDim(ref moDetail.Data, Models.clsPaymentDetail.TOTAL_COLUMNS - 1, moDetail.iTotalRows - 1);

                for (row_num = 0; row_num < moDetail.Data.GetLength(1); row_num++)
                {

                    if (cur_set.iField("iAppliedTransaction_num") > 0)
                    {
                        moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_NUM_COL, row_num] = cur_set.iField("iAppliedTransaction_num").ToString();
                        moDetail.Data[Models.clsPaymentDetail.INVOICE_NUM_COL, row_num] = cur_set.sField("sTransaction_num");
                    }

                    moDetail.Data[Models.clsPaymentDetail.CUR_PAYMENT_COL, row_num] = moMoney.ToStrMoney(cur_set.mField("mPaid_amt"));
                    moDetail.Data[Models.clsPaymentDetail.DISC_TAKEN_COL, row_num] = moMoney.ToStrMoney(cur_set.mField("mDiscGiven_amt"));
                    moDetail.Data[Models.clsPaymentDetail.APPLIED_TRX_TYPE_COL, row_num] = cur_set.iField("iAppliedTransaction_typ").ToString();

                    cur_set.MoveNext();
                }

                FormRecreateGrid();
                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + "(FormShowDetail)");
            }

            return return_value;
        }

        private bool FormShowExtra(clsRecordset cur_set)
        {
            bool return_value = false;
            string tmp = "";

            try
            {
                moPage.Clear();
                moPage.PreserveTimestamp(cur_set);
                moPage.bNew_fl = false;

                // This is where bReadOnly_fl & bReserved_fl are set according to the nature of the current record.
                //

                mbReceiptEntered_fl = true;

                moCustomer.ClearCustomer();

                moPage.sPreviousKey_id = Header.txtKey_id;
                Header.Preserve();

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (FormShowExtra)");
            }

            return return_value;
        }

        private bool FormShowHeader(clsRecordset cur_set)
        {
            Header.txtKey_id = cur_set.sField(moPage.sKeyField_nm);
            Header.cboStatus_typ = cur_set.iField("iStatus_typ").ToString();
            Header.cboFund_cd = GlobalVar.goFund.GetSelectedFundCodeToDisplay(ref moDatabase, cur_set.sField("sFund_cd"));

            Header.cboPayment_typ = cur_set.iField("iCash_typ").ToString();
            Header.txtBatch_num = cur_set.iField("iBatch_num").ToString();
            Header.mskApply_dt = moGeneral.ToStrDate(cur_set.iField("iApply_dt"));
            Header.mskEntry_dt = moGeneral.ToStrDate(cur_set.iField("iEntry_dt"));
            Header.txtPaid_amt = moMoney.ToStrMoney(cur_set.mField("mPaid_amt"));
            Header.lblTotalUsed_amt = moMoney.ToStrMoney(cur_set.mField("mUsed_amt"));
            Header.txtCustomer_cd = cur_set.sField("sCustomer_cd");
            Header.txtDescription = cur_set.sField("sDescription");
            Header.txtReference = cur_set.sField("sReference");
            Header.mskCashAcct_cd = cur_set.sField("sCashAcct_cd");
            Header.txtDocument_num = cur_set.sField("sDocument_num");
            Header.txtFace_nm = cur_set.sField("sOnDocument_nm");

            Header.txtUserApproved_cd = cur_set.sField("sUserApproved_cd");
            Header.txtToApprove_num = cur_set.iField("iToApprove_num").ToString();

            FormSyncDates(false);

            // Custom Fields
            //
            moCustomFields.SetValues(moDatabase, cur_set);

            return true;
        }

        private bool FormShowListing()
        {
            string where_clause = "";

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (mbListingInitiated_fl)
            {
                return true;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (moListing.Show(moDatabase, moPage, where_clause, cboListingBy) == false)
            {
                FormShowMessage();
                return false;
            }

            mbListingInitiated_fl = true;
            mbListingPopulated_fl = (moListing.Grid.Count > 0);

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        private bool FormSwitchView(int cur_page)                                                              // Switch the tab-pages
        {
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            moView.SwitchView(moPage, cur_page);
            return true;
        }

        private bool FormTransfer(string page_name)
        {
            NavigationManager.NavigateTo(page_name);

            return true;
        }

        private bool FormZoom()
        {
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moZoom.Caller == "txtCustomer_cd")
            {
                if (moZoom.Customer(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }
            else if (moZoom.Caller == "mskCashAcct_cd")
            {
                if (moZoom.Account(ref moDatabase) == false)
                {
                    FormShowMessage(null, (moZoom.bShowOptionBar == false));
                    return false;
                }
            }

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  NEVIGATION BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdLogout_Clicked()
        {
            if (FormDialog(cmdLogout_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_LOGOUT) == false)
            {
                return false;
            }

            FormLogout();

            return true;
        }

        private bool btnCancel_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnCancel_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_CANCEL) == false)
                {
                    return false;
                }
            }

            FormCancel();
            return true;
        }

        private bool btnDelete_Clicked()
        {
            FormPreEvent();

            if (FormDialog(btnDelete_Clicked, 100, User.Language.oMessage.ARE_YOU_SURE_TO_DELETE) == false)
            {
                return false;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }
            else if (FormDelete() == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        private bool btnExit_Clicked()
        {
            FormPreEvent();

            FormExit();
            return true;
        }

        private bool btnFirst_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnFirst_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.FIRST_RECORD_TYPE);
        }

        private bool btnLast_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnLast_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.LAST_RECORD_TYPE);
        }

        private bool btnNext_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnNext_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.NEXT_RECORD_TYPE);
        }

        private bool btnPrevious_Clicked()
        {
            FormPreEvent();

            if (moPage.bModified_fl)
            {
                if (FormDialog(btnPrevious_Clicked, 100, User.Language.oMessage.RECORD_HAS_BEEN_CHANGED_WOULD_YOU_LIKE_TO_PROCEED) == false)
                {
                    return false;
                }
            }

            return FormMove(GlobalVar.goConstant.PREVIOUS_RECORD_TYPE);
        }

        private bool btnSave_Clicked()
        {
            FormPreEvent();

            if (FormSave() == false)
            {
                return false;
            }

            FormClear();
            return true;
        }

        private bool btnPrint_Clicked()
        {
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id) || moUtility.IsEmpty(Header.txtCustomer_cd))
            {
                return false;
            }

            if (moUtility.IsEmpty(moCustomer.sEmailAddress))
            {
                if (FormOpenDatabase() == false)
                {
                    return false;
                }
                if (moValidate.IsValidCustomerCode(Header.txtCustomer_cd) == false)
                {
                    FormShowMessage(Header.txtCustomer_cd + User.Language.oMessage.IS_INVALID);
                    FormSetFocus("txtCustomer_cd");
                    return false;
                }

                txtEmailRecipient = moValidate.oRecordset.sField("sEmailAddress");
                moValidate.Release();
            }

            FormSwitchView(moView.PRINT_PAGE_NUM);

            return FormPostEvent();
        }

        private bool cmdCancelOnSearch_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.MAIN_PAGE_NUM);

            return FormPostEvent();
        }

        private bool btnSearchToPrint_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateSearchHTML();

            return FormPostEvent();
        }

        private bool btnSearchToExcel_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateSearchExcel();

            return FormPostEvent();
        }

        private bool btnListingToPrint_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateListingHTML();

            return FormPostEvent();
        }

        private bool btnListingToExcel_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            CreateListingExcel();

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  TAB/VIEW BUTTON SECTION  :  
        //  ===============================================================================================================================================================================================================================
        private bool cmdViewHeader_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.MAIN_PAGE_NUM);

            return true;
        }

        private bool cmdViewListing_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormShowListing() == false)
            {
                return false;
            }

            FormSwitchView(moView.LISTING_PAGE_NUM);
            return true;

        }

        private bool cmdViewSearch_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.SEARCH_PAGE_NUM);

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  LISTING, SEARCH & ZOOM EVENT SECTION  :                     
        //  ===============================================================================================================================================================================================================================
        private bool btnListingSelect_Clicked(Models.clsListingPayment.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.ToInteger(cur_item.Transaction_num) <= 0)   // May have a string such as TOTAL
            {
                return false;
            }

            FormClear();
            Header.Tag.txtKey_id = "";
            Header.txtKey_id = cur_item.Transaction_num;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnSearchSelect_Clicked(Models.clsListingPayment.clsGrid cur_item)
        {
            FormPreEvent();

            if (moUtility.IsEmpty(cur_item.Transaction_num))
            {
                return false;
            }

            FormClear();
            Header.txtKey_id = cur_item.Transaction_num;
            if (txtKey_id_Changed() == false)
            {
                return false;
            }

            FormSwitchView(moView.MAIN_PAGE_NUM);
            return true;
        }

        private bool btnZoomSelect_Clicked(Models.clsZoom.clsGrid cur_item)
        {
            bool return_value = false;
            string code_selected = "";

            FormPreEvent();

            try
            {
                code_selected = cur_item.Col_0;

                if (moZoom.Caller == "txtCustomer_cd")
                {
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    Header.txtCustomer_cd = code_selected;
                    return txtCustomer_cd_Changed();
                }
                else if (moZoom.Caller == "mskCashAcct_cd")
                {
                    FormSwitchView(moView.MAIN_PAGE_NUM);
                    Header.mskCashAcct_cd = code_selected;
                    return mskCashAcct_cd_Changed();
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (btnZoomSelect_Clicked)");
            }

            return return_value;
        }

        private bool cmdZoomCancel_Clicked()
        {
            moZoom.Grid.Clear();
            FormSwitchView(moZoom.iView);
            return true;
        }

        private bool cmdZoomFindAll_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

            if (FormZoom() == false)
            {
                return false;
            }

            return true;

        }

        private bool btnZoomOnKey_id_Clicked()
        {
            FormPreEvent();

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdSearch_Clicked()
        {
            FormPreEvent();

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);
            FormSearch();
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE);

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Changed()
        {
            if (Header.txtKey_id == Header.Tag.txtKey_id)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (txtKey_id_Verified() == false)
            {
                
            }

            return FormPostEvent();
        }

        private bool mskCashAcct_cd_Changed()
        {
            Header.mskCashAcct_cd = modCommonUtility.CleanCode(Header.mskCashAcct_cd);

            if (Header.mskCashAcct_cd == Header.Tag.mskCashAcct_cd)
            {
                return true;
            }

            if (moPage.bInDialog_fl == false)
            {
                FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.
            }

            if (moUtility.IsEmpty(Header.mskCashAcct_cd) || moUtility.IsEmpty(Header.txtKey_id))
            {
                Header.txtDocument_num = "";
                return true;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (moValidate.IsValidActualAcctCode(Header.mskCashAcct_cd) ==  false)
            {
                FormShowMessage(Header.mskCashAcct_cd + User.Language.oMessage.IS_INVALID);
                Header.mskCashAcct_cd = Header.Tag.mskCashAcct_cd;
                return false;
            }

            if (moUtility.ToInteger(Header.cboPayment_typ) > 0 && moUtility.IsNonEmpty(Header.txtCustomer_cd))
            {
                if (moUtility.QualifiedTenderForCheckRegister(moUtility.ToInteger(Header.cboPayment_typ)))
                {
                    Header.txtDocument_num = moTransactionPayment.GetNextCheckNumber(Header.mskCashAcct_cd, moUtility.ToInteger(Header.cboPayment_typ)).ToString();
                    if (moDatabase.IsErrorFound())
                    {
                        FormShowMessage();
                        Header.mskCashAcct_cd = Header.Tag.mskCashAcct_cd;
                        FormSetFocus("mskCashAcct_cd");
                        return false;
                    }
                }
            }

            return FormPostEvent();
        }

        private bool txtCustomer_cd_Changed()
        {
            Header.txtCustomer_cd = modCommonUtility.CleanCode(Header.txtCustomer_cd);

            if (Header.txtCustomer_cd == Header.Tag.txtCustomer_cd)
            {
                return true;
            }

            if (moPage.bInDialog_fl == false)
            {
                FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.
            }

            FormClearDetail();

            if (txtCustomer_cd_Verified() == false)
            {
                if (moPage.bInDialog_fl == false)
                {
                    Header.txtCustomer_cd = Header.Tag.txtCustomer_cd;
                    Header.lblCustomer_nm = Header.Tag.lblCustomer_nm;
                    FormSetFocus("txtCustomer_cd");
                }
                return false;
            }

            return FormPostEvent();
        }

        private bool txtPaid_amt_Changed()
        {
            string save_payment = "";

            if (moMoney.ToNumMoney(Header.txtPaid_amt) > 0 )
            {
                Header.txtPaid_amt = moMoney.ToStrMoney(moMoney.ToNumMoney(Header.txtPaid_amt));
            }
            else
            {
                Header.txtPaid_amt = "";
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            return FormPostEvent();
        }

        private bool dtApply_dt_Changed()
        {
            if (Header.dtApply_dt == Header.Tag.dtApply_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtApply_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtApply_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtApply_dt) == false)
            {
                Header.dtApply_dt = Header.Tag.dtApply_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtApply_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskApply_dt_Changed()
        {
            if (Header.mskApply_dt == Header.Tag.mskApply_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskApply_dt) == false)
            {
                Header.mskApply_dt = Header.Tag.mskApply_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskApply_dt");
                return false;
            }

            return FormPostEvent();
        }


        private bool dtEntry_dt_Changed()
        {
            if (Header.dtEntry_dt == Header.Tag.dtEntry_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moUtility.IsEmpty(Header.dtEntry_dt))
            {
                moUtility.SetEmptyDate(ref Header.dtEntry_dt);     // May have a garbage
            }
            else if (moUtility.IsDate(Header.dtEntry_dt) == false)
            {
                Header.dtEntry_dt = Header.Tag.dtEntry_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("dtEntry_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool mskEntry_dt_Changed()
        {
            if (Header.mskEntry_dt == Header.Tag.mskEntry_dt)
            {
                return true;
            }

            FormPreEvent();                                                                   // Do NOT move this to the top.  Then, the error message currently on will disappear, which is not good.

            if (moGeneral.ValidDate(ref Header.mskEntry_dt) == false)
            {
                Header.mskEntry_dt = Header.Tag.mskEntry_dt;
                FormShowMessage(User.Language.oMessage.INVALID_DATE_ENTERED);
                FormSetFocus("mskEntry_dt");
                return false;
            }

            return FormPostEvent();
        }

        private bool btnAccount_cd_cd_Clicked()
        {
            string where_clause = "";

            FormPreEvent();
            
            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "mskCashAcct_cd", -1, -1, moView.MAIN_PAGE_NUM, "sAccount_cd", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool btnZoomOnCustomer_cd_Clicked()
        {
            string where_clause = "";

            FormPreEvent();

            if (FormOpenDatabase() == false)                // Necessary to make moDatabase.sUser_cd valid
            {
                return false;
            }
            if (moUtility.IsSalesStaff(moDatabase))
            {
                where_clause = "sSalesrep_cd = '" + moDatabase.sUser_cd + "'";
            }

            // Need to set Zoom here.
            //
            if (moZoom.Init(moPage, "txtCustomer_cd", -1, -1, moView.MAIN_PAGE_NUM, "sCustomer_cd", "", where_clause) == false)
            {
                FormShowMessage("Invalid Zoom.Init() is called.");
                return false;
            }

            FormSwitchView(moView.ZOOM_PAGE_NUM);           // Need to come before cmdZoomFindAll_Clicked() is called due to the message from Zoom.

            if (FormZoom() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdCancelOnPrint_Clicked()
        {
            FormPreEvent();
            FormSwitchView(moView.MAIN_PAGE_NUM);
            return FormPostEvent();
        }

        private bool cmdOKOnPrint_Clicked()
        {
            if (moPage.bInDialog_fl == false)           // While in dialog, do not call FormPreEvent() which will remove the possible message displayed in printing process
            {
                FormPreEvent();
            }

            if (chkSendEmail_fl && moUtility.IsEmpty(txtEmailRecipient))
            {
                FormShowMessage(User.Language.oMessage.ENTER_EMAIL_ADDRESS);
                FormSetFocus("txtEmailRecipient");
                return false;
            }

            // This has to come before FormSave() because it is referrenced in concurrency check.
            //
            moPage.bInPrinting_fl = true;

            // Should save/print for the first time only.  When comming back from dialog, need to skip.
            //
            if (Modal.ReturningTo(3000) == false)
            {
                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE, false);

                if (FormPrint() == false)
                {
                    return false;
                }
            }

            moPage.bInPrinting_fl = false;

            FormSwitchView(moView.MAIN_PAGE_NUM);
            FormClear();

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT VALIDATION SECTION  :  These are called from header event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================
        private bool txtKey_id_Verified()
        {
            bool return_value = false;
            clsRecordset cur_set;
            string key_id = "";

            try
            {
                if (moUtility.ToInteger(Header.txtKey_id) > 0)
                {
                    Header.txtKey_id = moUtility.ToInteger(Header.txtKey_id).ToString();
                }
                else
                {
                    Header.txtKey_id = "";
                }

                key_id = Header.txtKey_id;

                if (Header.txtKey_id == Header.Tag.txtKey_id)
                {
                    return true;
                }
                else if (moUtility.IsEmpty(Header.txtKey_id))
                {
                    FormClear();
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    FormClear();
                    FormShowMessage(User.Language.oMessage.CONNECTION_HAS_FAILED);
                    return false;
                }

                cur_set = new clsRecordset(ref moDatabase);

                if (FormFindRecord(ref cur_set))
                {
                    FormShow(cur_set);
                }
                else
                {
                    FormShowMessage(Header.txtKey_id + User.Language.oMessage.IS_NOT_FOUND);
                    FormClear();
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtKey_id_Verified)");
            }

            return return_value;
        }

        private bool txtCustomer_cd_Verified()
        {
            bool return_value = false;
            string sql_str = "";

            clsRecordset cur_set = new clsRecordset(ref moDatabase);

            try
            {
                if (moUtility.IsEmpty(Header.txtCustomer_cd))
                {
                    Header.lblCustomer_nm = "";
                    return true;
                }

                if (FormOpenDatabase() == false)
                {
                    return false;
                }

                if (moValidate.IsValidCustomerCode(Header.txtCustomer_cd) == false)
                {
                    FormShowMessage(Header.txtCustomer_cd + User.Language.oMessage.IS_INVALID);
                    Header.txtCustomer_cd = Header.Tag.txtCustomer_cd;
                    return false;
                }
                else
                {
                    if (moUtility.IsSalesStaff(moDatabase))
                    {
                        if (moValidate.oRecordset.sField("sSalesrep_cd") != moDatabase.sUser_cd)
                        {
                            FormShowMessage(Header.txtCustomer_cd + User.Language.oMessage.IS_NOT_ACCESSIBLE);
                            Header.txtCustomer_cd = Header.Tag.txtCustomer_cd;
                            return false;
                        }
                    }
                    Header.lblCustomer_nm = moValidate.oRecordset.sField("sCustomer_nm");
                }


                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (txtCustomer_cd_Verified)");
            }

            return return_value;
        }

        private bool cmdOKOnPrint_Verified()
        {
            int new_check_num = 0;
            int row_num = 0;

            
            return FormPostEvent();
        }

        private bool CustomField_Changed(Models.clsCustomField.clsGrid cur_item)
        {
            FormPreEvent();

            if (moCustomFields.ValidateValue(moDatabase, cur_item) == false)
            {
                FormShowMessage(moCustomFields.GetErrorMessage());
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdSourceJournal_Clicked()
        {
            Models.clsSession o_session = new Models.clsSession();
            string session_id = "";
            FormPreEvent();

            if (moUtility.IsEmpty(Header.txtKey_id))
            {
                return false;
            }
            if (moUtility.ToInteger(Header.cboStatus_typ) == GlobalVar.goConstant.VOID_TRX_NUM)
            {
                FormShowMessage(User.Language.oMessage.RECORD_IS_NOT_QUALIFIED);
                return false;
            }
            if (FormOpenDatabase() == false)
            {
                return false;
            }
            if (moValidate.IsValidInGLJournal(moPage.iTransaction_typ, moUtility.ToInteger(Header.txtKey_id)) == false)
            {
                FormShowMessage(User.Language.oMessage.NO_RECORDS_FOUND);
                return false;
            }

            o_session.SetSessionValues(moDatabase, User, ref session_id, moValidate.oRecordset.iField("iTransaction_num").ToString());

            FormOpenPDF("LookupJournal/" + session_id);

            return FormPostEvent();
        }

        private bool cboListingBy_Clicked()
        {
            mbListingInitiated_fl = false;                  // Will let the listing refresh

            FormShowListing();

            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should start with "Detail" and end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  DETAIL EVENT VALIDATION SECTION  :  These are called from event-handlers whose name ends with _Changed, _Clicked or _Selected.                   
        //                                      Naming convention : Each name should end with _Verified
        //  ===============================================================================================================================================================================================================================

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================
        private string GetSearchCriteria()
        {
            string return_value = "";

            try
            {

                if (moUtility.IsNonEmpty(Header.mskEntry_dt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "iEntry_dt = " + moGeneral.ToNumDate(Header.mskEntry_dt).ToString();
                }
                if (moUtility.IsNonEmpty(Header.mskApply_dt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "iApply_dt = " + moGeneral.ToNumDate(Header.mskApply_dt).ToString();
                }
                if (moUtility.ToInteger(Header.cboStatus_typ) > 0)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "iStatus_typ = " + Header.cboStatus_typ;
                }
                if (moUtility.IsNonEmpty(Header.txtCustomer_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sCustomer_cd = '" + moUtility.EvalQuote(Header.txtCustomer_cd) + "'";
                }
                if (moUtility.IsNonEmpty(Header.txtDescription))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sDescription LIKE '" + moUtility.EvalQuote(Header.txtDescription) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtReference))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sReference LIKE '" + moUtility.EvalQuote(Header.txtReference) + "%'";
                }
                if (moUtility.ToInteger(Header.cboPayment_typ) > 0)
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "iCash_typ =" + Header.cboPayment_typ;
                }
                if (moUtility.IsNonEmpty(Header.txtDocument_num))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sDocument_num LIKE '" + moUtility.EvalQuote(Header.txtDocument_num) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtFace_nm))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sOnDocument_nm LIKE '" + moUtility.EvalQuote(Header.txtFace_nm) + "%'";
                }
                if (moUtility.IsNonEmpty(Header.txtPaid_amt))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "mPaid_amt =" + moMoney.ToNumMoney(Header.txtPaid_amt).ToString();
                }
                if (moUtility.IsNonEmpty(Header.mskCashAcct_cd))
                {
                    return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sCashAcct_cd = '" + moUtility.EvalQuote(Header.mskCashAcct_cd) + "'";
                }

                if (moUtility.IsNonEmpty(Header.cboFund_cd))
                {
                    if (Header.cboFund_cd == clsNPConstant.FUND_ORGANIZATION_CODE)
                    {
                        return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sFund_cd = ''";
                    }
                    else
                    {
                        return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "sFund_cd = '" + GlobalVar.goFund.GetSelectedFundCodeToSave(ref moDatabase, Header.cboFund_cd) + "'";
                    }
                }

                return return_value;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (GetSearchCriteria)");
            }

            return return_value;
        }

        private bool SetReportSelection()
        {
            bool return_value = false;
            string sql_str = "";
            string report_name = "";

            try
            {
                if (false == modCommonReportUtility.SetCompanyInReport(ref moDatabase, "frmQuickPrintReceipt", ref moReport, "", (moUtility.IsNonEmpty(modCommonUtility.GetCompanyLogoFile(ref moDatabase)))))
                {
                    FormShowMessage();
                    return false;
                }

                sql_str = "{tblARPayment.iTransaction_typ} = " + moPage.iTransaction_typ.ToString();
                sql_str += " and {tblARPayment.iTransaction_num} = " + Header.txtKey_id;

                moReport.SetSelectionFormula(sql_str);

                moReport.SetFormula(modConstant.CRYSTAL_LOGO_FUNCTION, modCommonUtility.GetCompanyLogoFile(ref moDatabase));

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (SetReportSelection)");
            }

            return return_value;
        }

        private bool CreateSearchHTML()
        {
            bool return_value = false;
            string html_file = "";
            string[] header_list = null;

            clsSpreadsheet o_search = new clsSpreadsheet();

            try
            {
                if (ShowSearchPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moSearch, ref o_search, ref header_list) == false)      // Listing & Search both share PrepListingDownload()
                {
                    return false;
                }

                html_file = moInquiry.CreateHTML(ref moDatabase, moPage.Title, o_search, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(html_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(html_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateSearchHTML)");
            }

            return return_value;
        }


        private bool CreateSearchExcel()
        {
            bool return_value = false;
            string csv_file = "";
            string[] header_list = null;

            clsSpreadsheet o_search = new clsSpreadsheet();

            try
            {
                if (ShowSearchPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moSearch, ref o_search, ref header_list) == false)
                {
                    return false;
                }

                csv_file = moInquiry.CreateCSV(ref moDatabase, moPage.Title, o_search, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(csv_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(csv_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateSearchExcel)");
            }

            return return_value;
        }

        private bool PrepListingDownload(clsListingPayment o_listing, ref clsSpreadsheet o_spread, ref string[] header_list)
        {
            bool return_value = false;
            int row_num = 0;
            int i = 0;

            try
            {
                moUtility.ResizeDim(ref o_spread.Data, 10, o_listing.Grid.Count - 1);

                foreach (var lst in o_listing.Grid)
                {
                    i = 0;

                    o_spread.Data[i++, row_num] = lst.Transaction_num;
                    o_spread.Data[i++, row_num] = lst.Status_typ;
                    o_spread.Data[i++, row_num] = lst.Entry_dt;
                    o_spread.Data[i++, row_num] = lst.Apply_dt;
                    o_spread.Data[i++, row_num] = lst.Cash_typ;
                    o_spread.Data[i++, row_num] = lst.Entity_cd;
                    //o_spread.Data[i++, row_num] = lst.Entity_nm;
                    o_spread.Data[i++, row_num] = lst.Document_num;
                    o_spread.Data[i++, row_num] = lst.Reference;
                    o_spread.Data[i++, row_num] = lst.Paid_amt;
                    o_spread.Data[i++, row_num] = lst.Used_amt;
                    o_spread.Data[i++, row_num] = lst.Description;

                    row_num += 1;
                }

                moUtility.ResizeDim(ref header_list, i - 1);
                i = 0;

                header_list[i++] = User.Language.oCaption.NUMBER;
                header_list[i++] = User.Language.oCaption.STATUS;
                header_list[i++] = User.Language.oCaption.ENTRY_DATE;
                header_list[i++] = User.Language.oCaption.APPLY_DATE;
                header_list[i++] = User.Language.oCaption.PAYMENT_TYPE;
                header_list[i++] = User.Language.oCaption.CUSTOMER;
                //header_list[i++] = User.Language.oCaption.NAME;
                header_list[i++] = User.Language.oCaption.DOCCHECK_NUM;
                header_list[i++] = User.Language.oCaption.REFERENCE;
                header_list[i++] = User.Language.oCaption.PAID;
                header_list[i++] = User.Language.oCaption.USED;
                header_list[i++] = User.Language.oCaption.DESCRIPTION;

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (PrepListingDownload)");
            }

            return return_value;
        }

        private bool CreateListingHTML()
        {
            bool return_value = false;
            string html_file = "";
            string[] header_list = null;

            clsSpreadsheet o_listing = new clsSpreadsheet();

            try
            {
                if (ShowListingPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moListing, ref o_listing, ref header_list) == false)
                {
                    return false;
                }

                html_file = moInquiry.CreateHTML(ref moDatabase, moPage.Title, o_listing, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(html_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(html_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateListingHTML)");
            }

            return return_value;
        }


        private bool CreateListingExcel()
        {
            bool return_value = false;
            string csv_file = "";
            string[] header_list = null;

            clsSpreadsheet o_listing = new clsSpreadsheet();

            try
            {
                if (ShowListingPrinter == false)
                {
                    return true;
                }

                if (PrepListingDownload(moListing, ref o_listing, ref header_list) == false)
                {
                    return false;
                }

                csv_file = moInquiry.CreateCSV(ref moDatabase, moPage.Title, o_listing, header_list.GetLength(0), header_list);

                if (moUtility.IsEmpty(csv_file))
                {
                    FormShowMessage();
                    return false;
                }

                FormOpenPDF(modGeneralUtility.GetVirtualFileName(csv_file, true));          // Will open another tab for PDF and also download Excel file.

                return_value = true;
            }
            catch (Exception ex)
            {
                FormShowMessage(ex.Message + " (CreateListingExcel)");
            }

            return return_value;
        }

    }
}
