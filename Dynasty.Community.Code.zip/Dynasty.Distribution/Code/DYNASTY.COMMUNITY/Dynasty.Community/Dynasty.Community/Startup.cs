using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dynasty.ASP.Login;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP
{
    public class Startup
    {

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;

            // Dynasty:  Initialize global vars that are used system-wide
            modGeneralUtility.InitGlobalObjects();

        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddRazorPages();
            services.AddServerSideBlazor();

            //  Dynasty client service
            services.AddScoped<Models.clsUser>();
            services.AddScoped<Models.clsModal>();
            services.AddScoped<Models.clsLock>();
            services.AddScoped<Dynasty.Local.clsCaption>();
            services.AddScoped<Dynasty.Local.clsMessage>();
            services.AddScoped<Dynasty.Local.clsString>();
            services.AddScoped<Dynasty.Local.clsConstant>();

            // System-wide variable settings
            GlobalVar.gsConnectionString = Configuration.GetConnectionString("DynastyDB");

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapBlazorHub();
                endpoints.MapFallbackToPage("/_Host");
            });
        }
    }
}
