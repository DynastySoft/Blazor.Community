
function giLARGEST_DOLLAR() { return 9000000000000000; };