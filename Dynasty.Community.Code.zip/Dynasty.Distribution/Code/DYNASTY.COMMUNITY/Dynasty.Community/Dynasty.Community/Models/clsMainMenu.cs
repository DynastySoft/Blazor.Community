﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dynasty.ASP.Models
{
    public class clsMainMenu
    {
        public int iMenuLevel = 0;
        public int iMenu_id = 0;
        public int iParentMenu_id = 0;
        public string sPage_nm = "";
        public string sMenu_nm = "";
        public string sDescription = "";
        public bool bExpended_fl = false;
    }
}
