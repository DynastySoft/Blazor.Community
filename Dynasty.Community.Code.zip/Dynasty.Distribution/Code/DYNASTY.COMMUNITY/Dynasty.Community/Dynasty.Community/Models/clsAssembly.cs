﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//



using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Collections.Generic;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP.Models
{
	public class clsAssembly
	{
		private int iTransaction_typ = 0;
		private string sPostingError = "";

		private clsArray oArray = new clsArray();
		private clsDynastyUtility oUtility = new clsDynastyUtility();

        public clsAssembly(int trx_type) : base()
		{
			iTransaction_typ = trx_type;

		}

		public bool IsErrorFound()
		{
			bool return_value = false;

			return_value = (oUtility.IsNonEmpty(sPostingError));

			return return_value;
		}

		public string GetErrorMessage()
		{
			string return_value = "";

			return_value = sPostingError;
			sPostingError = "";

			return return_value;
		}

		public void SetPostingError(string error_msg)
		{
			if (oUtility.IsEmpty(error_msg))
			{
				sPostingError = "";
			}
			else if (oUtility.IsEmpty(sPostingError))
			{
				sPostingError = error_msg;
			}
			else if (oUtility.STrim(sPostingError) != oUtility.STrim(error_msg))
			{
				sPostingError += Environment.NewLine + Environment.NewLine + "AND " + error_msg;
			}
		}
		// When serial/lot items are entered, iNextLine_id will link to each item in the serial/lot list.
		// Once iNextLine_id assigned, it does not changed and maintain the uniqueness during the course of line manipulations such as delete/insert.
		//
		public int iNextLine_id = 1;
		public int iNextKit_id = 1;
		public int iTotalRows = 0;

        public string[] FieldName;                                                              // Keeps the detail field names;
		public string[,] Data;																	// Keeps the detail data.

		public const int INCLUDE_COL = 0;
		public const int ITEM_CODE_COL = 1;
        public const int LOCATION_COL = 2;
        public const int FROM_LOCATION_COL = 3;
        public const int DESCRIPTION_COL = 4;
		public const int UNIT_CODE_COL = 5;
        public const int QTY_PER_BOM_COL = 6;
        public const int QTY_COL = 7;
		public const int QTY_EXTRA_COL = 8;
		public const int UNIT_PRICE_COL = 9;
		public const int UNIT_COST_COL = 10;
		public const int TOTAL_AMOUNT_COL = 11;
		public const int TOTAL_COST_COL = 12;
        public const int QTY_IN_IVUNIT_COL = 13;
		public const int IVUNIT_CODE_COL = 14;
		public const int CONVERSION_RATE_COL = 15;
		public const int ITEM_TYPE_COL = 16;
		public const int LINE_ID_COL = 17;
		public const int LINE_TYPE_COL = 18;
        public const int SOURCE_TYPE_COL = 19;
        public const int SOURCE_NUM_COL = 20;
		public const int SOURCE_DETAIL_ID_COL = 21;
		public const int DATE_APPLY_COL = 22;
		public const int BIN_COL = 23;
		public const int DATE_STARTED_COL = 24;
		public const int DATE_FINISHED_COL = 25;
		public const int DATE_REQUIRED_COL = 26;
		public const int TIME_STARTED_COL = 27;
		public const int TIME_FINISHED_COL = 28;
		public const int PRIORITY_COL = 29;
		public const int COMPLETE_COL = 30;

        public const int INSTRUCTION1_COL = 31;
        public const int INSTRUCTION2_COL = 32;
        public const int INSTRUCTION3_COL = 33;

        public const int TOTAL_COLUMNS = 34;

		public class clsGrid
		{
			public int Row_num = 0;                                 // 0-based row number. This will identify each row.
			public bool chkInclude_fl = false;
            public string txtItem_cd = "";
            public string txtLocation_cd = "";
            public string txtFromLocation_cd = "";
            public string txtDescription = "";
            public string txtUnit_cd = "";
            public string txtBOM_qty = "";
            public string txtQty = "";
            public string txtExtra_qty = "";
            public string txtUnitPrice_amt = "";
            public string lblUnitCost_amt = "";
            public string lblTotal_amt = "";
            public string lblInIVUnit_qty = "";
            public string lblIVUnit_cd = "";
            public string lblTotalCost_amt = "";
            public string lblConversion_rt = "";
            public string lblItem_typ = "";
            public string lblLine_id = "";
            public string lblLine_typ = "";
            public string lblSource_typ = "";
            public string lblSource_num = "";
            public string lblSourceDetail_num = "";
            public string lblApply_dt = "";
            public string lblBin_cd = "";

            public string txtStarted_dt = "";			// Date manipulation is based on these string dates only.  Corresponding DateTime should be set properly on UI side.
            public string txtFinished_dt = "";
            public string txtRequired_dt = "";
            
			public DateTime? dtStarted_dt = null;		// This is only for UI.   ? means nullable.
            public DateTime? dtFinished_dt = null;		// This is only for UI
            public DateTime? dtRequired_dt = null;		// This is only for UI

            public String txtPriority = "";
			public string txtStartTime = "";
            public string txtEndTime = "";
            public string txtComplete = "";

            public TimeOnly dtStartTime = new TimeOnly();       // Only for UI
            public TimeOnly dtEndTime = new TimeOnly();

            public string txtInstruction1 = "";
            public string txtInstruction2 = "";
            public string txtInstruction3 = "";

        }
		public List<clsGrid> Grid = new List<clsGrid>();

		public bool AddMoreRows(int lines_to_add = 10)
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
                // oUtility.ResizeDimPreserved(ref Data, Data.GetUpperBound(0), Data.GetUpperBound(1) + lines_to_add);

                for (row_num = 0; row_num < lines_to_add; row_num++)
                {
                    Grid.Add(new clsGrid { Row_num = iTotalRows
										,chkInclude_fl = false
										,txtItem_cd = ""
										,txtLocation_cd = "" 
										,txtFromLocation_cd = "" 
										,txtDescription = "" 
										,txtUnit_cd = "" 
										,txtBOM_qty = "" 
										,txtQty = "" 
										,txtExtra_qty = "" 
										,txtUnitPrice_amt = "" 
										,lblUnitCost_amt = "" 
										,lblTotal_amt = "" 
										,lblInIVUnit_qty = "" 
										,lblIVUnit_cd = "" 
										,lblTotalCost_amt = "" 
										,lblConversion_rt = "" 
										,lblItem_typ = "" 
										,lblLine_id = "" 
										,lblLine_typ = ""
										,lblSource_typ = "" 
										,lblSource_num = "" 
										,lblSourceDetail_num = "" 
										,lblApply_dt = ""
										,lblBin_cd = ""
										,txtStarted_dt = ""
										,txtStartTime = ""
										,txtFinished_dt = ""
										,dtStarted_dt = null
										,dtFinished_dt = null
										,dtRequired_dt = null
										,txtEndTime = ""
										,txtPriority = ""
										,txtComplete = ""
										,txtInstruction1 = ""
										,txtInstruction2 = ""
										,txtInstruction3 = ""

                    });

                    iTotalRows += 1;
					iNextLine_id += 1;

				}
                
                RecreateDetail();
                return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (AddMoreRows)");
				RecreateDetail();
            }

            return return_value;
        }

		public bool InsertNewRow(clsGrid cur_item, int at_row_num = -1)
        {
			bool return_value = false;

			if (at_row_num < 0)
            {
				at_row_num = cur_item.Row_num;
			}

            try
            {
				Grid.Insert(at_row_num, new clsGrid { Row_num = -1
										,chkInclude_fl = false
										,txtItem_cd = ""
										,txtLocation_cd = "" 
										,txtFromLocation_cd = "" 
										,txtDescription = "" 
										,txtUnit_cd = "" 
										,txtBOM_qty = "" 
										,txtQty = "" 
										,txtExtra_qty = "" 
										,txtUnitPrice_amt = "" 
										,lblUnitCost_amt = "" 
										,lblTotal_amt = "" 
										,lblInIVUnit_qty = "" 
										,lblIVUnit_cd = "" 
										,lblTotalCost_amt = "" 
										,lblConversion_rt = "" 
										,lblItem_typ = "" 
										,lblLine_id = "" 
										,lblLine_typ = ""
										,lblSource_typ = "" 
										,lblSource_num = "" 
										,lblSourceDetail_num = "" 
										,lblApply_dt = ""
										,lblBin_cd = ""
										,txtStarted_dt = ""
										,txtStartTime = ""
										,txtFinished_dt = ""
										,dtStarted_dt = null
										,dtFinished_dt = null
										,dtRequired_dt = null
										,txtEndTime = ""
										,txtPriority = ""
										,txtComplete = ""
										,txtInstruction1 = ""
										,txtInstruction2 = ""
										,txtInstruction3 = ""

                });

                Grid.Where(i => i.Row_num >= at_row_num).Select(i => { i.Row_num += 1; return i; }).ToList();
                Grid.Single(i => i.Row_num == -1).Row_num = at_row_num;

				iNextLine_id += 1;
				iTotalRows += 1;

				RecreateDetail();

                return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (InsertNewRow)");
            }

            return return_value;
        }
		public bool DeleteCurrentRow(clsGrid cur_item)
        {
			bool return_value = false;
			int old_num = cur_item.Row_num;

			try
			{
				Grid.RemoveAt(cur_item.Row_num);
				Grid.Where(i => i.Row_num >= old_num).Select(i => { i.Row_num -= 1; return i; }).ToList();

				iTotalRows -= 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
            {
				SetPostingError(ex.Message + " (DeleteCurrentRow)");
			}

			return return_value;
		}

		public bool RecreateDetail()                                                           //  Sync Data with Grid for the items that do not have event-handler ONLY.
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				if (Grid.Count() == 0)
				{
					oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), 0);
					return true;
				}

				// We need to create it here for saving because some fields may not have been copied into the array.
				//
				iTotalRows = Grid.Count();
				oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), iTotalRows - 1);

				foreach (var det in Grid)
				{
					if (RecreateDetailLine(det, row_num) == false)
					{
						return false;
					}

					det.Row_num = row_num;      // Just to make sure.
					row_num++;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetail)");
			}

			return return_value;
		}

		public bool RecreateGridLine(int row_num)
		{
			bool return_value = false;
			clsGrid grid_line = new clsGrid();

			if (FindGridLine(row_num, ref grid_line) == false)
			{
				SetPostingError("Grid does not match array.");
				return false;
			}

			return RecreateGridLine(ref grid_line, row_num);
		}

		public bool RecreateGridLine(ref clsGrid cur_item, int row_num)
        {
			bool return_value = false;

			try
            {
				cur_item.chkInclude_fl = (oUtility.ToInteger(Data[COMPLETE_COL, row_num]) == 100);
				cur_item.txtItem_cd = Data[ITEM_CODE_COL, row_num];
                cur_item.txtLocation_cd = Data[LOCATION_COL, row_num];
				cur_item.txtFromLocation_cd = Data[FROM_LOCATION_COL, row_num];
                cur_item.txtDescription = Data[DESCRIPTION_COL, row_num];
				cur_item.txtUnit_cd = Data[UNIT_CODE_COL, row_num];
				cur_item.txtBOM_qty = Data[QTY_PER_BOM_COL, row_num];
				cur_item.txtQty = Data[QTY_COL, row_num];
				cur_item.txtExtra_qty = Data[QTY_EXTRA_COL, row_num];
				cur_item.txtUnitPrice_amt = Data[UNIT_PRICE_COL, row_num];
				cur_item.lblUnitCost_amt = Data[UNIT_COST_COL, row_num];
				cur_item.lblTotal_amt = Data[TOTAL_AMOUNT_COL, row_num];
				cur_item.lblTotalCost_amt = Data[TOTAL_COST_COL, row_num];
                cur_item.lblInIVUnit_qty = Data[QTY_IN_IVUNIT_COL, row_num];
                cur_item.lblIVUnit_cd = Data[IVUNIT_CODE_COL, row_num];
				cur_item.lblConversion_rt = Data[CONVERSION_RATE_COL, row_num];
				cur_item.lblItem_typ = Data[ITEM_TYPE_COL, row_num];
                cur_item.lblLine_id = Data[LINE_ID_COL, row_num];
                cur_item.lblLine_typ = Data[LINE_TYPE_COL, row_num];
                cur_item.lblSource_typ = Data[SOURCE_TYPE_COL, row_num];
				cur_item.lblSource_num = Data[SOURCE_NUM_COL, row_num];
				cur_item.lblSourceDetail_num = Data[SOURCE_DETAIL_ID_COL, row_num];
				cur_item.lblApply_dt = Data[DATE_APPLY_COL, row_num];
				cur_item.lblBin_cd = Data[BIN_COL, row_num];
                cur_item.txtStarted_dt = Data[DATE_STARTED_COL, row_num];
                cur_item.txtFinished_dt = Data[DATE_FINISHED_COL, row_num];
                cur_item.txtRequired_dt = Data[DATE_FINISHED_COL, row_num];
				cur_item.dtStarted_dt = (oUtility.IsNonEmpty(Data[DATE_STARTED_COL, row_num])? oUtility.ToDateTime(Data[DATE_STARTED_COL, row_num]) : null);
				cur_item.dtFinished_dt = (oUtility.IsNonEmpty(Data[DATE_FINISHED_COL, row_num])? oUtility.ToDateTime(Data[DATE_FINISHED_COL, row_num]) : null);
				cur_item.dtRequired_dt = (oUtility.IsNonEmpty(Data[DATE_REQUIRED_COL, row_num])? oUtility.ToDateTime(Data[DATE_REQUIRED_COL, row_num]) : null);

                cur_item.txtStartTime = Data[TIME_STARTED_COL, row_num];
                cur_item.txtEndTime = Data[TIME_FINISHED_COL, row_num];
                cur_item.txtPriority = Data[PRIORITY_COL, row_num];
                cur_item.txtComplete = Data[COMPLETE_COL, row_num];
                cur_item.txtInstruction1 = Data[INSTRUCTION1_COL, row_num];
                cur_item.txtInstruction2 = Data[INSTRUCTION2_COL, row_num];
                cur_item.txtInstruction3 = Data[INSTRUCTION3_COL, row_num];

            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (RecreateGridLine)");
			}
			return return_value;

		}

		public bool FindGridLine(int row_num, ref clsGrid line_found)
		{
			bool return_value = false;

			try
            {
				line_found = Grid.Single(i => i.Row_num == row_num);

				if (line_found != null)
                {
					return_value = true;
				}
			}
			catch (Exception ex)
            {
				// in case not found
            }

			return return_value;
		}

		public bool RecreateDetailLine(clsGrid cur_item, int row_num = -1)
        {
            bool return_value = false;

            try
            {
				// If this is called from UI event, get the row number of current line.
				//
                if (row_num < 0)
                {
                    row_num = cur_item.Row_num;
                }

				if (oUtility.ToInteger(cur_item.lblLine_id) == 0)
                {
					if (oUtility.ToInteger(Data[LINE_ID_COL, row_num]) > 0)
                    {
						cur_item.lblLine_id = Data[LINE_ID_COL, row_num];
					}
					else
                    {
						cur_item.lblLine_id = iNextLine_id.ToString();
						iNextLine_id += 1;
					}
				}

                Data[INCLUDE_COL, row_num] = oUtility.IIf(oUtility.ToInteger(Data[COMPLETE_COL, row_num]) == 100, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
                Data[ITEM_CODE_COL, row_num] = cur_item.txtItem_cd;
				Data[LOCATION_COL, row_num] = cur_item.txtLocation_cd;
				Data[FROM_LOCATION_COL, row_num] = cur_item.txtFromLocation_cd;
                Data[DESCRIPTION_COL, row_num] = cur_item.txtDescription;
				Data[UNIT_CODE_COL, row_num] = cur_item.txtUnit_cd;
				Data[QTY_PER_BOM_COL, row_num] = cur_item.txtBOM_qty;
				Data[QTY_COL, row_num] = cur_item.txtQty;
				Data[QTY_EXTRA_COL, row_num] = cur_item.txtExtra_qty;
				Data[UNIT_PRICE_COL, row_num] = cur_item.txtUnitPrice_amt;
				Data[UNIT_COST_COL, row_num] = cur_item.lblUnitCost_amt;
                Data[TOTAL_AMOUNT_COL, row_num] = cur_item.lblTotal_amt;
                Data[TOTAL_COST_COL, row_num] = cur_item.lblTotalCost_amt;
                Data[QTY_IN_IVUNIT_COL, row_num] = cur_item.lblInIVUnit_qty;
                Data[IVUNIT_CODE_COL, row_num] = cur_item.lblIVUnit_cd;
				Data[CONVERSION_RATE_COL, row_num] = cur_item.lblConversion_rt;
				Data[ITEM_TYPE_COL, row_num] = cur_item.lblItem_typ;
                Data[LINE_ID_COL, row_num] = cur_item.lblLine_id;
                Data[LINE_TYPE_COL, row_num] = cur_item.lblLine_typ;
                Data[SOURCE_TYPE_COL, row_num] = cur_item.lblSource_typ;
				Data[SOURCE_NUM_COL, row_num] = cur_item.lblSource_num;
				Data[SOURCE_DETAIL_ID_COL, row_num] = cur_item.lblSourceDetail_num;
                Data[DATE_APPLY_COL, row_num] = cur_item.lblApply_dt;
                Data[BIN_COL, row_num] = cur_item.lblBin_cd;
                Data[DATE_STARTED_COL, row_num] = cur_item.txtStarted_dt;
                Data[DATE_FINISHED_COL, row_num] = cur_item.txtFinished_dt;
                Data[DATE_REQUIRED_COL, row_num] = cur_item.txtRequired_dt;
                Data[TIME_STARTED_COL, row_num] = cur_item.txtStartTime;
                Data[TIME_FINISHED_COL, row_num] = cur_item.txtEndTime;
                Data[PRIORITY_COL, row_num] = cur_item.txtPriority;
                Data[COMPLETE_COL, row_num] = cur_item.txtComplete;
                Data[INSTRUCTION1_COL, row_num] = cur_item.txtInstruction1;
                Data[INSTRUCTION2_COL, row_num] = cur_item.txtInstruction2;
                Data[INSTRUCTION3_COL, row_num] = cur_item.txtInstruction3;

                return_value = true;

            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (RecreateDetailLine)");
            }

            return return_value;
        }

        public bool RecreateGrid()                                                             //  Create Grid according to Data
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
				Grid.Clear();

				if (Data == null)
                {
                    return true;
                }
                else if (Data.GetLength(1) == 0)
                {
                    return true;
                }

                iTotalRows = Data.GetLength(1);

                for (row_num = 0; row_num < iTotalRows; row_num++)
                {
					if (oUtility.ToInteger(Data[LINE_ID_COL, row_num]) == 0)
                    {
						Data[LINE_ID_COL, row_num] = iNextLine_id.ToString();
						iNextLine_id += 1;
					}

                    Grid.Add(new clsGrid { Row_num = row_num

								, chkInclude_fl = (oUtility.ToInteger(Data[COMPLETE_COL, row_num]) == 100)
								, txtItem_cd = Data[ITEM_CODE_COL, row_num]
								, txtLocation_cd = Data[LOCATION_COL, row_num]
								, txtFromLocation_cd = Data[FROM_LOCATION_COL, row_num]
								, txtDescription = Data[DESCRIPTION_COL, row_num]
								, txtUnit_cd = Data[UNIT_CODE_COL, row_num]
								, txtBOM_qty = Data[QTY_PER_BOM_COL, row_num]
								, txtQty = Data[QTY_COL, row_num]
								, txtExtra_qty = Data[QTY_EXTRA_COL, row_num]
								, txtUnitPrice_amt = Data[UNIT_PRICE_COL, row_num]
								, lblUnitCost_amt = Data[UNIT_COST_COL, row_num]
								, lblTotal_amt = Data[TOTAL_AMOUNT_COL, row_num]
								, lblTotalCost_amt = Data[TOTAL_COST_COL, row_num]
								, lblInIVUnit_qty = Data[QTY_IN_IVUNIT_COL, row_num]
								, lblIVUnit_cd = Data[IVUNIT_CODE_COL, row_num]
								, lblConversion_rt = Data[CONVERSION_RATE_COL, row_num]
								, lblItem_typ = Data[ITEM_TYPE_COL, row_num]
								, lblLine_id = Data[LINE_ID_COL, row_num]
								, lblLine_typ = Data[LINE_TYPE_COL, row_num]
                                , lblSource_typ = Data[SOURCE_TYPE_COL, row_num]
								, lblSource_num = Data[SOURCE_NUM_COL, row_num]
								, lblSourceDetail_num = Data[SOURCE_DETAIL_ID_COL, row_num]
								, lblApply_dt = Data[DATE_APPLY_COL, row_num]
								, lblBin_cd = Data[BIN_COL, row_num]
								, txtStarted_dt = Data[DATE_STARTED_COL , row_num]
								, txtFinished_dt = Data[DATE_FINISHED_COL , row_num]
								, txtRequired_dt = Data[DATE_REQUIRED_COL , row_num]
								, dtStarted_dt = (oUtility.IsNonEmpty(Data[DATE_STARTED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_STARTED_COL, row_num]) : null)
								, dtFinished_dt = (oUtility.IsNonEmpty(Data[DATE_FINISHED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_FINISHED_COL, row_num]) : null)
								, dtRequired_dt = (oUtility.IsNonEmpty(Data[DATE_REQUIRED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_REQUIRED_COL, row_num]) : null)
                                , txtStartTime = Data[TIME_STARTED_COL , row_num]
                                , txtEndTime = Data[TIME_FINISHED_COL , row_num]
								, dtStartTime = TimeOnly.Parse((Data[TIME_STARTED_COL , row_num] == ""? "12:00 AM" : Data[TIME_STARTED_COL, row_num]), System.Globalization.CultureInfo.CurrentCulture)
								, dtEndTime = TimeOnly.Parse((Data[TIME_FINISHED_COL, row_num] == ""? "12:00 AM" : Data[TIME_FINISHED_COL, row_num]), System.Globalization.CultureInfo.CurrentCulture)
								, txtPriority = Data[PRIORITY_COL , row_num]
								, txtComplete = Data[COMPLETE_COL , row_num]
                                , txtInstruction1 = Data[INSTRUCTION1_COL, row_num]
								, txtInstruction2 = Data[INSTRUCTION2_COL, row_num]
								, txtInstruction3 = Data[INSTRUCTION3_COL, row_num]




                });
                }

				return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (RecreateGrid)");
            }

            return return_value;
        }

	}

}
