﻿using Dynasty.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dynasty.ASP.Models
{

    public class clsListingPayment
    {
        clsDynastyUtility oUtility = new clsDynastyUtility();

        // Total all amunts
        //
        public decimal mPaid_amt = 0;
        public decimal mUsed_amt = 0;

        public bool Show(clsDatabase cur_db, clsPage cur_page, string where_clause = "", string order_by_clause = "")
        {
            string sql_str = "";
            string trx_str = "";
            string pay_to = "";
            string entity_nm = "";

            clsRecordset cur_set = new clsRecordset(ref cur_db);
            clsGeneral o_gen = new clsGeneral(ref cur_db);
            clsMoney o_money = new clsMoney(ref cur_db);
            clsStatus o_status = new clsStatus();

            // Clear totals
            //
            mPaid_amt = 0;
            mUsed_amt = 0;

            if (IsPayable(cur_page.iTransaction_typ))
            {
                pay_to = "sPayTo_cd";
                entity_nm = "sVendor_nm";
            }
            else
            {
                entity_nm = "sCustomer_nm";
            }

            Grid.Clear();

            order_by_clause= oUtility.STrim(order_by_clause);

            // Standard listing shows the key and description
            //
            sql_str = "SELECT * FROM " + cur_page.sTable_nm;

            if (oUtility.IsNonEmpty(where_clause))
            {
                if (oUtility.IsNonEmpty(cur_page.sRestrictionClause))
                {
                    sql_str += " WHERE " + cur_page.sRestrictionClause;
                    sql_str += " AND " + where_clause;
                }
                else
                {
                    sql_str += " WHERE " + where_clause;
                }
            }
            else if (oUtility.IsNonEmpty(cur_page.sRestrictionClause))
            {
                sql_str += " WHERE " + cur_page.sRestrictionClause;
            }

            if (oUtility.IsNonEmpty(order_by_clause))
            {
                sql_str += " ORDER BY " + order_by_clause;
            }
            else
            {
                sql_str += " ORDER BY " + cur_page.sKeyField_nm;
            }

            if (cur_set.CreateSnapshot(sql_str) == false)
            {
                return false;
            }
            else if (cur_set.EOF())
            {
                return true;
            }

            while (cur_set.EOF() == false)
            {
                mPaid_amt += cur_set.mField("mPaid_amt");
                mUsed_amt += cur_set.mField("mUsed_amt");

                Grid.Add(new clsGrid { Transaction_num = cur_set.sField(cur_page.sKeyField_nm)
		                , Entry_dt = o_gen.ToStrDate(cur_set.iField("iEntry_dt"))
                        , Apply_dt = o_gen.ToStrDate(cur_set.iField("iApply_dt"))
                        , Status_typ = GetStatus(cur_page, cur_set.iField("iStatus_typ"))
                        , Cash_typ = oUtility.GetCashTypeText(cur_set.iField("iCash_typ"))
                        , Refund_typ = oUtility.IIf(cur_set.iField("iRefund_typ") == 1, "Refund", "NSF")
                        , Paid_amt = o_money.ToStrMoney(cur_set.mField("mPaid_amt"), -1, "", true)
                        , Used_amt = o_money.ToStrMoney(cur_set.mField("mUsed_amt"), -1, "", true)
		                , Reference = cur_set.sField("sReference")
                        , Document_num = cur_set.sField("sDocument_num")
		                , PayTo_cd = cur_set.sField(pay_to)
                        , Entity_cd = cur_set.sField(oUtility.IIf(IsPayable(cur_page.iTransaction_typ), "sVendor_cd", "sCustomer_cd").ToString())
		                //, Entity_nm = cur_set.sField(oUtility.IIf(IsPayable(cur_page.iTransaction_typ), "sVendor_nm", "sCustomer_nm").ToString())
                        , Payment_num = cur_set.sField(oUtility.IIf(IsPayable(cur_page.iTransaction_typ), "iPayment_num", "iReceipt_num").ToString())
		                , Description = cur_set.sField("sDescription")
                });

                cur_set.MoveNext();
            }


            if (mPaid_amt > 0 || mUsed_amt > 0)
            {
                Grid.Add(new clsGrid { Transaction_num = cur_db.oLanguage.oString.STR_TOTALS
                            , Entry_dt = ""
                            , Apply_dt = ""
                            , Status_typ = ""
                            , Cash_typ = ""
                            , Refund_typ = ""
                            , Paid_amt = o_money.ToStrMoney(mPaid_amt, -1, "", true)
                            , Used_amt = o_money.ToStrMoney(mUsed_amt, -1, "", true)
		                    , Reference = ""
		                    , Document_num = ""
                            , PayTo_cd = ""
                            , Entity_cd = ""
                            //, Entity_nm = ""
                            , Payment_num = ""
                            , Description = ""
                });
            }

            return true;
        }

        private string GetStatus(clsPage cur_page, int status_type)
        {
            clsStatus o_status = new clsStatus();
            string status_text = "";

            // Set to default transaction status.
            //
            if (oUtility.SInStr(oUtility.SUCase(cur_page.sTable_nm), "UNPOSTED") > 0)
            {
                status_text = o_status.TransactionUnpostedStatusTypeText(status_type);
            }
            else
            {
                status_text = o_status.TransactionPostedStatusTypeText(status_type);
            }

            return status_text;
        }

        private bool IsPayable(int trx_type)
        {
            if (trx_type == GlobalVar.goConstant.TRX_PAYMENT_TYPE || trx_type == GlobalVar.goConstant.TRX_STOP_PAYMENT_TYPE)
            {
                return true;
            }

            return false;
        }

        public class clsGrid
        {
            public string Transaction_num { get; set; } = "";
            public string Entry_dt { get; set; } = "";
            public string Apply_dt { get; set; } = "";
            public string Status_typ { get; set; } = "";
            public string Cash_typ { get; set; } = "";
            public string Refund_typ { get; set; } = "";
            public string Paid_amt { get; set; } = "";
            public string Used_amt { get; set; } = "";
            public string Reference { get; set; } = "";
            public string Document_num { get; set; } = "";
            public string PayTo_cd { get; set; } = "";
            public string Entity_cd { get; set; } = "";
            //public string Entity_nm { get; set; } = "";
            public String Payment_num { get; set; } = "";
            public string Description { get; set; } = "";
        }
        public List<clsGrid> Grid = new List<clsGrid>();

    }
}
