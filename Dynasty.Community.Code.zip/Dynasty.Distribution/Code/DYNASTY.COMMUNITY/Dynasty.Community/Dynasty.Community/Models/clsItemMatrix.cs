﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Linq;
using System.Collections.Generic;

using Dynasty.Database;

namespace Dynasty.ASP.Models
{
	public class clsItemMatrix
	{
		public string[,] SegmentedData;                             // This will have the item & qty info to be added to the transactions.  This is created from MatrixData[] 
		public int COLOR_COL = 0;
		public int SIZE_COL = 1;
		public int QTY_COL = 2;
		public int ITEM_CODE_COL = 3;
		public const int TOTAL_SEGMENT_COLUMNS = 4;

		private bool bViewOnly_fl = false;
		public bool bSizeExist_fl = false;
		public bool bColorExist_fl = false;

		private clsDynastyUtility oUtility = new clsDynastyUtility();
		private string sPostingError = "";

		// MatrixData should always match Grid
		//
		public string[,] MatrixData;						// color/size marix to show in UI.  Always in sync with Grid.
		public const int TOTAL_MATRIX_COLUMNS = 50;         // total column of MatrixData and Grid

		private int _max_columns = 0;                         
        public int TotalColumns                             // Actual/valid columns used in MatrixData and Grid
		{
            get { return _max_columns; }
        }

        public class clsGrid
		{
			public int Row_num = 0;
			public string Col_0 = "";
			public string Col_1 = "";
			public string Col_2 = "";
			public string Col_3 = "";
			public string Col_4 = "";
			public string Col_5 = "";
			public string Col_6 = "";
			public string Col_7 = "";
			public string Col_8 = "";
			public string Col_9 = "";
			public string Col_10 = "";
			public string Col_11 = "";
			public string Col_12 = "";
			public string Col_13 = "";
			public string Col_14 = "";
			public string Col_15 = "";
			public string Col_16 = "";
			public string Col_17 = "";
			public string Col_18 = "";
			public string Col_19 = "";
			public string Col_20 = "";
			public string Col_21 = "";
			public string Col_22 = "";
			public string Col_23 = "";
			public string Col_24 = "";
			public string Col_25 = "";
			public string Col_26 = "";
			public string Col_27 = "";
			public string Col_28 = "";
			public string Col_29 = "";
			public string Col_30 = "";
			public string Col_31 = "";
			public string Col_32 = "";
			public string Col_33 = "";
			public string Col_34 = "";
			public string Col_35 = "";
			public string Col_36 = "";
			public string Col_37 = "";
			public string Col_38 = "";
			public string Col_39 = "";
			public string Col_40 = "";
			public string Col_41 = "";
			public string Col_42 = "";
			public string Col_43 = "";
			public string Col_44 = "";
			public string Col_45 = "";
			public string Col_46 = "";
			public string Col_47 = "";
			public string Col_48 = "";
			public string Col_49 = "";
		}
		public List<clsGrid> Grid = new List<clsGrid>();

		public bool IsErrorFound()
		{
			bool return_value = false;

			return_value = (oUtility.IsNonEmpty(sPostingError));

			return return_value;
		}

		public string GetErrorMessage()
		{
			string return_value = "";

			return_value = sPostingError;
			sPostingError = "";

			return return_value;
		}
		public void SetPostingError(string error_msg)
		{
			if (oUtility.IsEmpty(error_msg))
			{
				sPostingError = "";
			}
			else if (oUtility.IsEmpty(sPostingError))
			{
				sPostingError = error_msg;
			}
			else if (oUtility.STrim(sPostingError) != oUtility.STrim(error_msg))
			{
				sPostingError += Environment.NewLine + Environment.NewLine + "AND " + error_msg;
			}
		}

		public bool CreateGrid(int total_num)
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				Grid.Clear();

				for (row_num = 0; row_num < total_num; row_num++)
				{
					Grid.Add(new clsGrid
					{
						Row_num = row_num
						, Col_0 = ""
						, Col_1 = ""
						, Col_2 = ""
						, Col_3 = ""
						, Col_4 = ""
						, Col_5 = ""
						, Col_6 = ""
						, Col_7 = ""
						, Col_8 = ""
						, Col_9 = ""
						, Col_10 = ""
						, Col_11 = ""
						, Col_12 = ""
						, Col_13 = ""
						, Col_14 = ""
						, Col_15 = ""
						, Col_16 = ""
						, Col_17 = ""
						, Col_18 = ""
						, Col_19 = ""
						, Col_20 = ""
						, Col_21 = ""
						, Col_22 = ""
						, Col_23 = ""
						, Col_24 = ""
						, Col_25 = ""
						, Col_26 = ""
						, Col_27 = ""
						, Col_28 = ""
						, Col_29 = ""
						, Col_30 = ""
						, Col_31 = ""
						, Col_32 = ""
						, Col_33 = ""
						, Col_34 = ""
						, Col_35 = ""
						, Col_36 = ""
						, Col_37 = ""
						, Col_38 = ""
						, Col_39 = ""
						, Col_40 = ""
						, Col_41 = ""
						, Col_42 = ""
						, Col_43 = ""
						, Col_44 = ""
						, Col_45 = ""
						, Col_46 = ""
						, Col_47 = ""
						, Col_48 = ""
						, Col_49 = ""
					});
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + "(CreateGrid)");
			}

			return return_value;
		}

		public bool FindGridLine(int row_num, ref clsGrid line_found)
		{
			bool return_value = false;

			try
			{
				line_found = Grid.Single(i => i.Row_num == row_num);

				if (line_found != null)
				{
					return_value = true;
				}
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + "(FindGridLine)");
			}

			return return_value;
		}

		public bool RecreateGridLine(int row_num)
		{
			bool return_value = false;
			clsGrid grid_line = new clsGrid();

			if (FindGridLine(row_num, ref grid_line) == false)
			{
				SetPostingError("Grid does not match array.");
				return false;
			}

			return RecreateGridLine(ref grid_line, row_num);
		}

		public bool RecreateGridLine(ref clsGrid cur_item, int row_num)
		{
			bool return_value = false;

			try
			{
				cur_item.Row_num = row_num;
				cur_item.Col_0 = MatrixData[0, row_num];
				cur_item.Col_1 = MatrixData[1, row_num];
				cur_item.Col_2 = MatrixData[2, row_num];
				cur_item.Col_3 = MatrixData[3, row_num];
				cur_item.Col_4 = MatrixData[4, row_num];
				cur_item.Col_5 = MatrixData[5, row_num];
				cur_item.Col_6 = MatrixData[6, row_num];
				cur_item.Col_7 = MatrixData[7, row_num];
				cur_item.Col_8 = MatrixData[8, row_num];
				cur_item.Col_9 = MatrixData[9, row_num];
				cur_item.Col_10 = MatrixData[10, row_num];
				cur_item.Col_11 = MatrixData[11, row_num];
				cur_item.Col_12 = MatrixData[12, row_num];
				cur_item.Col_13 = MatrixData[13, row_num];
				cur_item.Col_14 = MatrixData[14, row_num];
				cur_item.Col_15 = MatrixData[15, row_num];
				cur_item.Col_16 = MatrixData[16, row_num];
				cur_item.Col_17 = MatrixData[17, row_num];
				cur_item.Col_18 = MatrixData[18, row_num];
				cur_item.Col_19 = MatrixData[19, row_num];
				cur_item.Col_20 = MatrixData[20, row_num];
				cur_item.Col_21 = MatrixData[21, row_num];
				cur_item.Col_22 = MatrixData[22, row_num];
				cur_item.Col_23 = MatrixData[23, row_num];
				cur_item.Col_24 = MatrixData[24, row_num];
				cur_item.Col_25 = MatrixData[25, row_num];
				cur_item.Col_26 = MatrixData[26, row_num];
				cur_item.Col_27 = MatrixData[27, row_num];
				cur_item.Col_28 = MatrixData[28, row_num];
				cur_item.Col_29 = MatrixData[29, row_num];
				cur_item.Col_30 = MatrixData[30, row_num];
				cur_item.Col_31 = MatrixData[31, row_num];
				cur_item.Col_32 = MatrixData[32, row_num];
				cur_item.Col_33 = MatrixData[33, row_num];
				cur_item.Col_34 = MatrixData[34, row_num];
				cur_item.Col_35 = MatrixData[35, row_num];
				cur_item.Col_36 = MatrixData[36, row_num];
				cur_item.Col_37 = MatrixData[37, row_num];
				cur_item.Col_38 = MatrixData[38, row_num];
				cur_item.Col_39 = MatrixData[39, row_num];
				cur_item.Col_40 = MatrixData[40, row_num];
				cur_item.Col_41 = MatrixData[41, row_num];
				cur_item.Col_42 = MatrixData[42, row_num];
				cur_item.Col_43 = MatrixData[43, row_num];
				cur_item.Col_44 = MatrixData[44, row_num];
				cur_item.Col_45 = MatrixData[45, row_num];
				cur_item.Col_46 = MatrixData[46, row_num];
				cur_item.Col_47 = MatrixData[47, row_num];
				cur_item.Col_48 = MatrixData[48, row_num];
				cur_item.Col_49 = MatrixData[49, row_num];

			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateGridLine)");
			}
			return return_value;

		}

		public bool RecreateDetail()                                                           //  Sync Data with Grid for the items that do not have event-handler ONLY.
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				if (Grid.Count() == 0)
				{
					oUtility.ResizeDim(ref MatrixData, MatrixData.GetUpperBound(0), 0);
					return true;
				}

				// We need to create it here for saving because some fields may not have been copied into the array.
				//
				oUtility.ResizeDim(ref MatrixData, MatrixData.GetUpperBound(0), Grid.Count() - 1);

				foreach (var det in Grid)
				{
					if (RecreateDetailLine(det, row_num) == false)
					{
						return false;
					}

					det.Row_num = row_num;      // Just to make sure.
					row_num++;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetail)");
			}

			return return_value;
		}

		public bool RecreateDetailLine(clsGrid cur_item, int row_num = -1)
		{
			bool return_value = false;

			try
			{
				// If this is called from UI event, get the row number of current line.
				//
				if (row_num < 0)
				{
					row_num = cur_item.Row_num;
				}

				MatrixData[0, row_num] = cur_item.Col_0;
				MatrixData[1, row_num] = cur_item.Col_1;
				MatrixData[2, row_num] = cur_item.Col_2;
				MatrixData[3, row_num] = cur_item.Col_3;
				MatrixData[4, row_num] = cur_item.Col_4;
				MatrixData[5, row_num] = cur_item.Col_5;
				MatrixData[6, row_num] = cur_item.Col_6;
				MatrixData[7, row_num] = cur_item.Col_7;
				MatrixData[8, row_num] = cur_item.Col_8;
				MatrixData[9, row_num] = cur_item.Col_9;
				MatrixData[10, row_num] = cur_item.Col_10;
				MatrixData[11, row_num] = cur_item.Col_11;
				MatrixData[12, row_num] = cur_item.Col_12;
				MatrixData[13, row_num] = cur_item.Col_13;
				MatrixData[14, row_num] = cur_item.Col_14;
				MatrixData[15, row_num] = cur_item.Col_15;
				MatrixData[16, row_num] = cur_item.Col_16;
				MatrixData[17, row_num] = cur_item.Col_17;
				MatrixData[18, row_num] = cur_item.Col_18;
				MatrixData[19, row_num] = cur_item.Col_19;
				MatrixData[20, row_num] = cur_item.Col_20;
				MatrixData[21, row_num] = cur_item.Col_21;
				MatrixData[22, row_num] = cur_item.Col_22;
				MatrixData[23, row_num] = cur_item.Col_23;
				MatrixData[24, row_num] = cur_item.Col_24;
				MatrixData[25, row_num] = cur_item.Col_25;
				MatrixData[26, row_num] = cur_item.Col_26;
				MatrixData[27, row_num] = cur_item.Col_27;
				MatrixData[28, row_num] = cur_item.Col_28;
				MatrixData[29, row_num] = cur_item.Col_29;
				MatrixData[30, row_num] = cur_item.Col_30;
				MatrixData[31, row_num] = cur_item.Col_31;
				MatrixData[32, row_num] = cur_item.Col_32;
				MatrixData[33, row_num] = cur_item.Col_33;
				MatrixData[34, row_num] = cur_item.Col_34;
				MatrixData[35, row_num] = cur_item.Col_35;
				MatrixData[36, row_num] = cur_item.Col_36;
				MatrixData[37, row_num] = cur_item.Col_37;
				MatrixData[38, row_num] = cur_item.Col_38;
				MatrixData[39, row_num] = cur_item.Col_39;
				MatrixData[40, row_num] = cur_item.Col_40;
				MatrixData[41, row_num] = cur_item.Col_41;
				MatrixData[42, row_num] = cur_item.Col_42;
				MatrixData[43, row_num] = cur_item.Col_43;
				MatrixData[44, row_num] = cur_item.Col_44;
				MatrixData[45, row_num] = cur_item.Col_45;
				MatrixData[46, row_num] = cur_item.Col_46;
				MatrixData[47, row_num] = cur_item.Col_47;
				MatrixData[48, row_num] = cur_item.Col_48;
				MatrixData[49, row_num] = cur_item.Col_49;

				return_value = true;

			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetailLine)");
			}

			return return_value;
		}

		public bool RecreateGrid()                                                             //  Create Grid according to Data
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				Grid.Clear();

				if (MatrixData == null)
				{
					return true;
				}
				else if (MatrixData.GetLength(1) == 0)
				{
					return true;
				}

				for (row_num = 0; row_num < MatrixData.GetLength(1); row_num++)
				{
					Grid.Add(new clsGrid
					{
						Row_num = row_num
						, Col_0 = MatrixData[0, row_num]
						, Col_1 = MatrixData[1, row_num]
						, Col_2 = MatrixData[2, row_num]
						, Col_3 = MatrixData[3, row_num]
						, Col_4 = MatrixData[4, row_num]
						, Col_5 = MatrixData[5, row_num]
						, Col_6 = MatrixData[6, row_num]
						, Col_7 = MatrixData[7, row_num]
						, Col_8 = MatrixData[8, row_num]
						, Col_9 = MatrixData[9, row_num]
						, Col_10 = MatrixData[10, row_num]
						, Col_11 = MatrixData[11, row_num]
						, Col_12 = MatrixData[12, row_num]
						, Col_13 = MatrixData[13, row_num]
						, Col_14 = MatrixData[14, row_num]
						, Col_15 = MatrixData[15, row_num]
						, Col_16 = MatrixData[16, row_num]
						, Col_17 = MatrixData[17, row_num]
						, Col_18 = MatrixData[18, row_num]
						, Col_19 = MatrixData[19, row_num]
						, Col_20 = MatrixData[20, row_num]
						, Col_21 = MatrixData[21, row_num]
						, Col_22 = MatrixData[22, row_num]
						, Col_23 = MatrixData[23, row_num]
						, Col_24 = MatrixData[24, row_num]
						, Col_25 = MatrixData[25, row_num]
						, Col_26 = MatrixData[26, row_num]
						, Col_27 = MatrixData[27, row_num]
						, Col_28 = MatrixData[28, row_num]
						, Col_29 = MatrixData[29, row_num]
						, Col_30 = MatrixData[30, row_num]
						, Col_31 = MatrixData[31, row_num]
						, Col_32 = MatrixData[32, row_num]
						, Col_33 = MatrixData[33, row_num]
						, Col_34 = MatrixData[34, row_num]
						, Col_35 = MatrixData[35, row_num]
						, Col_36 = MatrixData[36, row_num]
						, Col_37 = MatrixData[37, row_num]
						, Col_38 = MatrixData[38, row_num]
						, Col_39 = MatrixData[39, row_num]
						, Col_40 = MatrixData[40, row_num]
						, Col_41 = MatrixData[41, row_num]
						, Col_42 = MatrixData[42, row_num]
						, Col_43 = MatrixData[43, row_num]
						, Col_44 = MatrixData[44, row_num]
						, Col_45 = MatrixData[45, row_num]
						, Col_46 = MatrixData[46, row_num]
						, Col_47 = MatrixData[47, row_num]
						, Col_48 = MatrixData[48, row_num]
						, Col_49 = MatrixData[49, row_num]
				});
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateGrid)");
			}

			return return_value;
		}

		public void InitMatrix(bool view_only)
		{

			bViewOnly_fl = view_only;
            bSizeExist_fl = false;
            bColorExist_fl = false;

            oUtility.ResizeDim(ref SegmentedData, TOTAL_SEGMENT_COLUMNS - 1, 0); // Do not delete

		}

		public bool LoadSizeAndColor(ref clsDatabase cur_db, string item_code, string location_code)
		{
			bool return_value = false;
			int i = 0;
			int row_num = 0;
			int col_num = 0;
			string sql_str = "";
			string row_val = "";
			string column_code = "";
			string row_code = "";
			clsRecordset color_set = new clsRecordset(ref cur_db);
			clsRecordset size_set = new clsRecordset(ref cur_db);
			clsRecordset qty_set = new clsRecordset(ref cur_db);

			try
			{
                // Reset color & size
				//
                bSizeExist_fl = false;
                bColorExist_fl = false;

                if (oUtility.IsEmpty(item_code))
				{
					return false;
				}
				else if (bViewOnly_fl && oUtility.IsEmpty(location_code))
				{
					return false;
				}

				sql_str = "SELECT DISTINCT sSize_cd FROM tblIVItem WHERE sPrimary_cd = '" + item_code + "'";
				sql_str += " AND iStatus_typ <> " + GlobalVar.goIVConstant.CLOSED_ITEM_NUM.ToString();
				sql_str += " AND iStatus_typ <> " + GlobalVar.goIVConstant.HOLD_ITEM_NUM.ToString();
				sql_str += " AND sSize_cd <> ''";
				sql_str += " ORDER BY sSize_cd"; // Do not delete
				if (size_set.CreateSnapshot(sql_str) == false)
				{
					return false;
				}

				bSizeExist_fl = (size_set.RecordCount() > 0);

				sql_str = "SELECT DISTINCT sColor_cd FROM tblIVItem WHERE sPrimary_cd = '" + item_code + "'";
				sql_str += " AND iStatus_typ <> " + GlobalVar.goIVConstant.CLOSED_ITEM_NUM.ToString();
				sql_str += " AND iStatus_typ <> " + GlobalVar.goIVConstant.HOLD_ITEM_NUM.ToString();
				sql_str += " AND sColor_cd <> ''";
				sql_str += " ORDER BY sColor_cd"; // Do not delete
				if (color_set.CreateSnapshot(sql_str) == false)
				{
					return false;
				}

				bColorExist_fl = (color_set.RecordCount() > 0);

				// Size is displayed column-wise, & color row-wise if both exist.
				//
				if (bSizeExist_fl)
				{
					_max_columns = size_set.RecordCount();

					oUtility.ResizeDim(ref MatrixData, TOTAL_MATRIX_COLUMNS - 1, 0);
					
					if (TOTAL_MATRIX_COLUMNS < size_set.RecordCount())
                    {
						SetPostingError("Max number of size is " + TOTAL_MATRIX_COLUMNS.ToString());
						return false;
                    }

                    // - The compelete matrix of size & color will be like this when both color & size are used.
                    //			: The first row is the header of sizes, and the first column is the header of colors.
                    // - If only one, either color or size, is used, the martix will be column-wise.
					//			: The first row shows the color/size, and the second row is for the quantity entry.
                    //
                    // ---------+-----------+-----------+-----------+
                    //			|	Small	|	Medium	|	Large	|
                    // ---------+-----------+-----------+-----------+
                    //	Black	|			|			|			|
                    // ---------+-----------+-----------+-----------+
                    //	Blue	|			|			|			|
                    // ---------+-----------+-----------+-----------+
                    //	Red		|			|			|			|
                    // ---------+-----------+-----------+-----------+
                    //	White	|			|			|			|
                    // ---------+-----------+-----------+-----------+

                    for (i = 1; i <= size_set.RecordCount(); i++)
					{
						MatrixData[i, 0] = size_set.sField("sSize_cd"); // The first row is the column header with sizes
						size_set.MoveNext();
					}
					if (bColorExist_fl)
					{
						oUtility.ResizeDimPreserved(ref MatrixData, MatrixData.GetUpperBound(0), MatrixData.GetUpperBound(1) + color_set.RecordCount());
						
						for (i = 1; i <= color_set.RecordCount(); i++)
						{
							MatrixData[0, i] = color_set.sField("sColor_cd"); // The first column is the row header with colors
							color_set.MoveNext();
						}
					}
					else
					{
						oUtility.ResizeDimPreserved(ref MatrixData, MatrixData.GetUpperBound(0), MatrixData.GetUpperBound(1) + 1);
						MatrixData[0, 0] = ""; // The first row header is empty
					}
				}
				else if (bColorExist_fl)
				{
					_max_columns = color_set.RecordCount();

					oUtility.ResizeDim(ref MatrixData, TOTAL_MATRIX_COLUMNS - 1, 0);

					if (TOTAL_MATRIX_COLUMNS < color_set.RecordCount())
					{
						SetPostingError("Max number of color is " + TOTAL_MATRIX_COLUMNS.ToString());
						return false;
					}

					for (i = 1; i <= color_set.RecordCount(); i++)
					{
						MatrixData[i, 0] = color_set.sField("sColor_cd"); // The first row is the column headers
						color_set.MoveNext();
					}
					oUtility.ResizeDimPreserved(ref MatrixData, MatrixData.GetUpperBound(0), MatrixData.GetUpperBound(1) + 1);
					MatrixData[0, 0] = ""; // The first row header is empty
				}

				// For view only, show the qty info for each item.
				//
				if (bViewOnly_fl)
				{
					sql_str = "SELECT sSize_cd, sColor_cd, q.fAvailable_qty, q.fOnHand_qty FROM tblIVItem t INNER JOIN tblIVItemQty q ON q.sItem_cd = t.sItem_cd ";
					sql_str += " WHERE t.sPrimary_cd <> t.sItem_cd AND t.sPrimary_cd = '" + item_code + "' AND q.sLocation_cd = '" + location_code + "'";
					sql_str += " AND t.iStatus_typ <> " + GlobalVar.goIVConstant.CLOSED_ITEM_NUM.ToString();
					sql_str += " AND t.iStatus_typ <> " + GlobalVar.goIVConstant.HOLD_ITEM_NUM.ToString();
					sql_str += " ORDER BY sSize_cd, sColor_cd"; // Do not delete
					if (qty_set.CreateSnapshot(sql_str) == false)
					{
						return false;
					}
					if (bColorExist_fl && bSizeExist_fl)
					{
						column_code = "sSize_cd";
						row_code = "sColor_cd";
					}
					else if (bSizeExist_fl)
					{
						column_code = "sSize_cd";
						row_code = "sColor_cd";
					}
					else
					{
						column_code = "sColor_cd";
						row_code = "sSize_cd";
					}

					row_val = "";
					row_num = 1; // 0 is for the header

					while (qty_set.EOF() == false && row_num < MatrixData.GetLength(1))
					{
						row_val = MatrixData[0, row_num]; // Row header
						
						for (col_num = 1; col_num <= MatrixData.GetLength(0) - 1; col_num++) // 0 is for the header
						{
							if (qty_set.EOF())
							{
								break;
							}
							else if (row_val != qty_set.sField(row_code))
							{
								break;
							}
							else if (MatrixData[col_num, 0] == qty_set.sField(column_code))
							{
								MatrixData[col_num, row_num] = qty_set.mField("fAvailable_qty") + " / " + qty_set.mField("fOnHand_qty");
								qty_set.MoveNext();
							}
						}
						if (qty_set.EOF())
						{
							break;
						}
						row_num += 1;
					}
				}

				RecreateGrid();

				return_value = true;

			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadSizeAndColor)");
			}

			return return_value;
		}

		public bool CreateDetailLinesFromMatrix(ref clsDatabase cur_db, string ittem_code, string location_code)
		{
			bool return_value = false;
			int row_num = 0;
			int col_num = 0;
			int active_row = 0;
			string select_str = "";
			string field_name = "";
			string field_list = "";
			string value_list = "";
			string where_list = "";
			string add_list = "";

			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{

                if (oUtility.IsEmpty(ittem_code))
				{
					return return_value;
				}

				if (RecreateDetail() ==  false)
                {
					return false;
                }

                field_list = "sPrimary_cd";
				value_list = "'" + ittem_code + "'";
				where_list = "sPrimary_cd = '" + ittem_code + "'";

                oUtility.ResizeDim(ref SegmentedData, TOTAL_SEGMENT_COLUMNS - 1, (MatrixData.GetLength(1) * MatrixData.GetLength(0) - 1));

				select_str = "SELECT sItem_cd FROM tblIVItem WHERE ";

				for (row_num = 1; row_num <= MatrixData.GetLength(1) - 1; row_num++)
				{
					for (col_num = 1; col_num <= MatrixData.GetLength(0) - 1; col_num++)
					{
						if (oUtility.RoundToQtyFactor(oUtility.ToValue(MatrixData[col_num, row_num])) > 0)
						{
							add_list = "";
							if (bSizeExist_fl && bColorExist_fl)
							{
								add_list += " AND sSize_cd = '" + MatrixData[col_num, 0] + "'";
								add_list += " AND sColor_cd = '" + MatrixData[0, row_num] + "'";
							}
							else if (bSizeExist_fl)
							{
								add_list += " AND sSize_cd = '" + MatrixData[col_num, 0] + "'";
							}
							else
							{
								add_list += " AND sColor_cd = '" + MatrixData[col_num, 0] + "'";
							}
							if (cur_set.CreateSnapshot(select_str + where_list + add_list) == false)
							{
								return return_value;
							}
							else if (!cur_set.EOF())
							{
								SegmentedData[ITEM_CODE_COL, active_row] = cur_set.sField("sItem_cd");
								SegmentedData[QTY_COL, active_row] = oUtility.RoundToQtyFactor(oUtility.ToValue(MatrixData[col_num, row_num])).ToString();
								active_row += 1;
							}
						}
						
					}
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CreateDetailLinesFromMatrix)");
			}

			return return_value;
		}

	}

}
