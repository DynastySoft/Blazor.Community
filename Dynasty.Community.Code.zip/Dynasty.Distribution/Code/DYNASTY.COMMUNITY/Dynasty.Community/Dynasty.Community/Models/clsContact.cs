﻿using Dynasty.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dynasty.ASP.Models
{
    public class clsContact
    {
        private clsDynastyUtility moUtility = new clsDynastyUtility();
        private clsColumns moColumns = new clsColumns();

        public string[,] Data;
        public int iTotalRows;

        public bool Show(clsDatabase cur_db, clsPage page, string[,] contacts)
        {
            bool return_value = false;
            int i;
            clsRecordset cur_set = new clsRecordset(ref cur_db);

            try
            {
                Grid.Clear();
                iTotalRows = 0;

                if (moUtility.IsEmpty(contacts))
                {
                    return false;
                }

                iTotalRows = 10;

                if (contacts.GetLength(0) < moColumns.Contact.TOTAL_COL_NUM || contacts.GetLength(1) < iTotalRows)
                {
                    moUtility.ResizeDimPreserved(ref contacts, moColumns.Contact.TOTAL_COL_NUM - 1, moUtility.IIf(contacts.GetLength(1) < iTotalRows, iTotalRows - 1, contacts.GetLowerBound(1)));
                }

                moUtility.ResizeDim(ref Data, contacts.GetUpperBound(0), contacts.GetUpperBound(1));
                moUtility.CopyArray(ref contacts, ref Data);

                if (CreateGrid(ref cur_db) == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(clsContact.Show())");
            }

            return return_value;
        }

        public bool CreateGrid(ref clsDatabase cur_db)
        {
            bool return_value = false;
            int i;

            try
            {
                for (i = 0; i < Data.GetLength(1); i++)
                {
                    Grid.Add(new clsGrid
                    {
                        Row_num = i
                        // ,Col_0 = Data[moColumns.Contact.TYPE_COL, i]
                        ,
                        Type = Data[moColumns.Contact.TYPE_COL, i]
                        ,
                        Name = Data[moColumns.Contact.NAME_COL, i]
                        ,
                        Phone1 = Data[moColumns.Contact.PHONE1_COL, i]
                        ,
                        Phone2 = Data[moColumns.Contact.PHONE2_COL, i]
                        ,
                        Fax = Data[moColumns.Contact.FAX_COL, i]
                        ,
                        Email = Data[moColumns.Contact.EMAIL_COL, i]
                        ,
                        Title = Data[moColumns.Contact.TITLE_COL, i]
                        ,
                        Comment = Data[moColumns.Contact.COMMENT_COL, i]
                    });
                }

                iTotalRows = Data.GetLength(1);

                return_value = true;
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(clsContact.CreateGrid())");
            }

            return return_value;
        }

        public class clsGrid
        {
            public int Row_num { get; set; } = 0;
            // public string Col_0 { get; set; } = "";    Reserved for delete button
            public string Type { get; set; } = "";
            public string Name { get; set; } = "";
            public string Phone1 { get; set; } = "";
            public string Phone2 { get; set; } = "";
            public string Fax { get; set; } = "";
            public string Email { get; set; } = "";
            public string Title { get; set; } = "";
            public string Comment { get; set; } = "";

        }
        public List<clsGrid> Grid = new List<clsGrid>();

    }
}
