﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dynasty.ASP.Models
{
    public class clsView
    {
        // IMPORTANT :
        // Make sure that each page number is unique.
        //
        public readonly int LISTING_PAGE_NUM = 0;
        public readonly int SEARCH_PAGE_NUM = 1;
        public readonly int ZOOM_PAGE_NUM = 2;
        public readonly int HISTORY_PAGE_NUM = 3;
        public readonly int MAIN_PAGE_NUM = 4;
        public readonly int DETAIL_PAGE_NUM = 5;
        public readonly int SECOND_PAGE_NUM = 6;
        public readonly int THIRD_PAGE_NUM = 7;
        public readonly int FOURTH_PAGE_NUM = 8;
        public readonly int FIFTH_PAGE_NUM = 9;
        public readonly int SIXTH_PAGE_NUM = 10;
        public readonly int SEVENTH_PAGE_NUM = 11;
        public readonly int EIGHTH_PAGE_NUM = 12;
        public readonly int CHART_PAGE_NUM = 13;

        // A/R & A/P charge entries.
        //
        public readonly int MATRIX_PAGE_NUM = 51;
        public readonly int ORDER_PAGE_NUM = 52;
        public readonly int PAYMENT_PAGE_NUM = 53;
        public readonly int COMMISSION_PAGE_NUM = 54;
        public readonly int SERIAL_PAGE_NUM = 55;
        public readonly int OPTIONS_PAGE_NUM = 56;
        public readonly int PAYMENT_SCHEDULE_PAGE_NUM = 57;
        public readonly int JOB_EXPENSES_PAGE_NUM = 58;

        // Entities: customer & vendor
        //
        public readonly int CONTACT_INFO_PAGE_NUM = 81;
        public readonly int EMAIL_HISTORY_PAGE_NUM = 82;
        public readonly int CUSTOM_FIELDS_PAGE_NUM = 83;
        public readonly int CONTACT_HISTORY_PAGE_NUM = 84;

        // Item master
        //
        public readonly int SPECIFICTION_PAGE_NUM = 91;
        public readonly int ACTIVITY_PAGE_NUM = 92;

        // G/L Summary accounts
        //
        public readonly int ACCOUNT_GROUP_PAGE_NUM = 101;
        public readonly int ACCOUNT_PAGE_NUM = 102;

        // G/L Budget
        //
        public readonly int ALLOCATION_PAGE_NUM = 103;
        public readonly int ADJUSTMENT_PAGE_NUM = 104;

        // Master
        //
        public readonly int SYSTEM_OPTION_PAGE_NUM = 901;
        public readonly int SECUTITY_OPTION_PAGE_NUM = 902;
        public readonly int GL_OPTION_PAGE_NUM = 903;
        public readonly int LOCALIZATION_PAGE_NUM = 904;
        public readonly int FREIGHT_METHOD_PAGE_NUM = 905;

        // Office/Facility
        //
        public readonly int DOC_FORMAT_PAGE_NUM = 911;
        public readonly int ASSET_PAGE_NUM = 912;

        // Posting page
        //
        public readonly int ERROR_PAGE_NUM = 921;
        public readonly int IV_PAGE_NUM = 922;
        public readonly int GL_PAGE_NUM = 923;
        public readonly int AR_PAGE_NUM = 924;
        public readonly int AP_PAGE_NUM = 925;
        public readonly int SO_PAGE_NUM = 926;
        public readonly int PO_PAGE_NUM = 927;
        public readonly int BR_PAGE_NUM = 928;

        // views that do not have own tab button
        //
        public readonly int PRINT_PAGE_NUM = 10000;
        public readonly int USER_ITEM_PAGE_NUM = 10001;
        public readonly int CREATE_ITEM_PAGE_NUM = 10002;

        public class clsCSS
        {
            public string Listing = GlobalVar.CSS_TAB_BUTTON;
            public string Search = GlobalVar.CSS_TAB_BUTTON;
            public string Zoom = GlobalVar.CSS_TAB_BUTTON;
            public string History = GlobalVar.CSS_TAB_BUTTON;
            public string Header = GlobalVar.CSS_TAB_BUTTON;
            public string Detail = GlobalVar.CSS_TAB_BUTTON;
            public string Second = GlobalVar.CSS_TAB_BUTTON;
            public string Third = GlobalVar.CSS_TAB_BUTTON;
            public string Fourth = GlobalVar.CSS_TAB_BUTTON;
            public string Fifth = GlobalVar.CSS_TAB_BUTTON;
            public string Sixth = GlobalVar.CSS_TAB_BUTTON;
            public string Seventh = GlobalVar.CSS_TAB_BUTTON;
            public string Eighth = GlobalVar.CSS_TAB_BUTTON;
            public string Chart = GlobalVar.CSS_TAB_BUTTON;

            public string Matrix = GlobalVar.CSS_TAB_BUTTON;
            public string Order = GlobalVar.CSS_TAB_BUTTON;
            public string Payment = GlobalVar.CSS_TAB_BUTTON;
            public string Commission = GlobalVar.CSS_TAB_BUTTON;
            public string Serial = GlobalVar.CSS_TAB_BUTTON;
            public string Options = GlobalVar.CSS_TAB_BUTTON;

            public string ContactInfo = GlobalVar.CSS_TAB_BUTTON;
            public string EmailHistory = GlobalVar.CSS_TAB_BUTTON;
            public string CustomFields = GlobalVar.CSS_TAB_BUTTON;

            public string Specification = GlobalVar.CSS_TAB_BUTTON;
            public string Activity = GlobalVar.CSS_TAB_BUTTON;

            public string AccountGroup = GlobalVar.CSS_TAB_BUTTON;
            public string Account = GlobalVar.CSS_TAB_BUTTON;

            public string Allocation = GlobalVar.CSS_TAB_BUTTON;
            public string Adjustment = GlobalVar.CSS_TAB_BUTTON;

            public string DocFormat = GlobalVar.CSS_TAB_BUTTON;
            public string Asset = GlobalVar.CSS_TAB_BUTTON;

            public string SystemOptions = GlobalVar.CSS_TAB_BUTTON;
            public string SecurityOptions = GlobalVar.CSS_TAB_BUTTON;
            public string GLOptions = GlobalVar.CSS_TAB_BUTTON;
            public string Localizaiton = GlobalVar.CSS_TAB_BUTTON;
            public string FreightMethod = GlobalVar.CSS_TAB_BUTTON;

            public string Error = GlobalVar.CSS_TAB_BUTTON;
            public string IV = GlobalVar.CSS_TAB_BUTTON;
            public string GL = GlobalVar.CSS_TAB_BUTTON;
            public string AR = GlobalVar.CSS_TAB_BUTTON;
            public string AP = GlobalVar.CSS_TAB_BUTTON;
            public string SO = GlobalVar.CSS_TAB_BUTTON;
            public string PO = GlobalVar.CSS_TAB_BUTTON;
            public string BR = GlobalVar.CSS_TAB_BUTTON;

        }

        public clsCSS CSS = new clsCSS();

        public void SwitchView(clsPage _page, int cur_view = -1)
        {
            // Go back to the preivous tab
            //
            if (cur_view == -1)
            {
                cur_view = _page.iPreviousView;
            }
            else if (cur_view >= 10000)                     // call for the views that do not have tab button
            {
                _page.HideToolBar = true;
                _page.iPreviousView = _page.iCurrentView;
                _page.iCurrentView = cur_view;
                return;
            }

            CSS.Listing = GlobalVar.CSS_TAB_BUTTON;
            CSS.Search = GlobalVar.CSS_TAB_BUTTON;
            CSS.Zoom = GlobalVar.CSS_TAB_BUTTON;
            CSS.History = GlobalVar.CSS_TAB_BUTTON;
            CSS.Header = GlobalVar.CSS_TAB_BUTTON;
            CSS.Detail = GlobalVar.CSS_TAB_BUTTON;
            CSS.Second = GlobalVar.CSS_TAB_BUTTON;
            CSS.Third = GlobalVar.CSS_TAB_BUTTON;
            CSS.Fourth = GlobalVar.CSS_TAB_BUTTON;
            CSS.Fifth = GlobalVar.CSS_TAB_BUTTON;
            CSS.Sixth = GlobalVar.CSS_TAB_BUTTON;
            CSS.Seventh = GlobalVar.CSS_TAB_BUTTON;
            CSS.Eighth = GlobalVar.CSS_TAB_BUTTON;
            CSS.Chart = GlobalVar.CSS_TAB_BUTTON;

            CSS.Matrix = GlobalVar.CSS_TAB_BUTTON;
            CSS.Order = GlobalVar.CSS_TAB_BUTTON;
            CSS.Payment = GlobalVar.CSS_TAB_BUTTON;
            CSS.Commission = GlobalVar.CSS_TAB_BUTTON;
            CSS.Serial = GlobalVar.CSS_TAB_BUTTON;
            CSS.Options = GlobalVar.CSS_TAB_BUTTON;

            CSS.ContactInfo = GlobalVar.CSS_TAB_BUTTON;
            CSS.EmailHistory = GlobalVar.CSS_TAB_BUTTON;
            CSS.CustomFields = GlobalVar.CSS_TAB_BUTTON;

            CSS.Specification = GlobalVar.CSS_TAB_BUTTON;
            CSS.Activity = GlobalVar.CSS_TAB_BUTTON;

            CSS.AccountGroup = GlobalVar.CSS_TAB_BUTTON;
            CSS.Account = GlobalVar.CSS_TAB_BUTTON;

            CSS.Allocation = GlobalVar.CSS_TAB_BUTTON;
            CSS.Adjustment = GlobalVar.CSS_TAB_BUTTON;

            CSS.DocFormat = GlobalVar.CSS_TAB_BUTTON;
            CSS.Asset = GlobalVar.CSS_TAB_BUTTON;

            CSS.SystemOptions = GlobalVar.CSS_TAB_BUTTON;
            CSS.SecurityOptions = GlobalVar.CSS_TAB_BUTTON;
            CSS.GLOptions = GlobalVar.CSS_TAB_BUTTON;
            CSS.Localizaiton = GlobalVar.CSS_TAB_BUTTON;
            CSS.FreightMethod = GlobalVar.CSS_TAB_BUTTON;

            CSS.IV = GlobalVar.CSS_TAB_BUTTON;
            CSS.GL = GlobalVar.CSS_TAB_BUTTON;
            CSS.AR = GlobalVar.CSS_TAB_BUTTON;
            CSS.AP = GlobalVar.CSS_TAB_BUTTON;
            CSS.SO = GlobalVar.CSS_TAB_BUTTON;
            CSS.PO = GlobalVar.CSS_TAB_BUTTON;
            CSS.BR = GlobalVar.CSS_TAB_BUTTON;
            CSS.Error = GlobalVar.CSS_TAB_BUTTON;

            _page.HideToolBar = false;

            if (cur_view == LISTING_PAGE_NUM)
            {
                CSS.Listing = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
                _page.HideToolBar = true;
            }
            else if (cur_view == SEARCH_PAGE_NUM)
            {
                CSS.Search = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
                _page.HideToolBar = true;
            }
            else if (cur_view == ZOOM_PAGE_NUM)
            {
                CSS.Zoom = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
                _page.HideToolBar = true;
            }
            else if (cur_view == HISTORY_PAGE_NUM)
            {
                CSS.History = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
                _page.HideToolBar = true;
            }
            else if (cur_view == MATRIX_PAGE_NUM)
            {
                CSS.Matrix = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
                _page.HideToolBar = true;
            }
            else if (cur_view == DETAIL_PAGE_NUM)
            {
                CSS.Detail = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if ((cur_view == CONTACT_INFO_PAGE_NUM) || (cur_view == CONTACT_HISTORY_PAGE_NUM))
            {
                CSS.ContactInfo = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
                _page.HideToolBar = (cur_view == CONTACT_HISTORY_PAGE_NUM);
            }
            else if (cur_view == ORDER_PAGE_NUM)
            {
                CSS.Order = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == PAYMENT_PAGE_NUM)
            {
                CSS.Payment = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == COMMISSION_PAGE_NUM)
            {
                CSS.Commission = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == SERIAL_PAGE_NUM)
            {
                CSS.Serial = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == OPTIONS_PAGE_NUM || cur_view == PAYMENT_SCHEDULE_PAGE_NUM || cur_view == JOB_EXPENSES_PAGE_NUM)
            {
                CSS.Options = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == EMAIL_HISTORY_PAGE_NUM)
            {
                CSS.EmailHistory = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == CUSTOM_FIELDS_PAGE_NUM)
            {
                CSS.CustomFields = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == SPECIFICTION_PAGE_NUM)
            {
                CSS.Specification = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == ACTIVITY_PAGE_NUM)
            {
                CSS.Activity = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == ACCOUNT_GROUP_PAGE_NUM)
            {
                CSS.AccountGroup = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
                _page.HideToolBar = true;
            }
            else if (cur_view == ACCOUNT_PAGE_NUM)
            {
                CSS.Account = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
                _page.HideToolBar = true;
            }
            else if (cur_view == ALLOCATION_PAGE_NUM)
            {
                CSS.Allocation = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == ADJUSTMENT_PAGE_NUM)
            {
                CSS.Adjustment = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == DOC_FORMAT_PAGE_NUM)
            {
                CSS.DocFormat = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == ASSET_PAGE_NUM)
            {
                CSS.Asset = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == SYSTEM_OPTION_PAGE_NUM)
            {
                CSS.SystemOptions = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == SECUTITY_OPTION_PAGE_NUM)
            {
                CSS.SecurityOptions = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == GL_OPTION_PAGE_NUM)
            {
                CSS.GLOptions = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == LOCALIZATION_PAGE_NUM)
            {
                CSS.Localizaiton = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == FREIGHT_METHOD_PAGE_NUM)
            {
                CSS.FreightMethod = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == ERROR_PAGE_NUM)
            {
                CSS.Error = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == IV_PAGE_NUM)
            {
                CSS.IV = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == GL_PAGE_NUM)
            {
                CSS.GL = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == AR_PAGE_NUM)
            {
                CSS.AR = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == AP_PAGE_NUM)
            {
                CSS.AP = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == SO_PAGE_NUM)
            {
                CSS.SO = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == PO_PAGE_NUM)
            {
                CSS.PO = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == BR_PAGE_NUM)
            {
                CSS.BR = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == MAIN_PAGE_NUM)
            {
                CSS.Header = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == SECOND_PAGE_NUM)
            {
                CSS.Second = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == THIRD_PAGE_NUM)
            {
                CSS.Third = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == FOURTH_PAGE_NUM)
            {
                CSS.Fourth = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == FIFTH_PAGE_NUM)
            {
                CSS.Fifth = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == SIXTH_PAGE_NUM)
            {
                CSS.Sixth = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == SEVENTH_PAGE_NUM)
            {
                CSS.Seventh = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == EIGHTH_PAGE_NUM)
            {
                CSS.Eighth = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else if (cur_view == CHART_PAGE_NUM)
            {
                CSS.Chart = GlobalVar.CSS_ACTIVE_TAB_BUTTON;
            }
            else
            {
                // let it go. Some options such as print do not have its own tab.
            }

            _page.iPreviousView = _page.iCurrentView;
            _page.iCurrentView = cur_view;

        }
    }
}
