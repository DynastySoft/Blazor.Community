﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Dynasty.Database;

namespace Dynasty.ASP.Models
{
    public class clsTaxTable
    {
		public const int FROM_COL = 0;              // Should match clsPRConstant.INCOME_FROM_COL
		public const int THRU_COL = 1;              // Should match clsPRConstant.INCOME_THRU_COL
		public const int RATE_COL = 2;              // Should match clsPRConstant.INCOME_TAX_RATE_COL

		public const int TOTAL_COLUMNS = 3;

        public int iTotalRows = 0;

        public string[,] Data;                                                                  // Keeps the detail data.
		public string[] FieldName;																// Keeps the field names

		private string sPostingError = "";
		private clsDynastyUtility oUtility = new clsDynastyUtility();

		public bool IsErrorFound()
		{
			bool return_value = false;

			return_value = (oUtility.IsNonEmpty(sPostingError));

			return return_value;
		}

		public string GetErrorMessage()
		{
			string return_value = "";

			return_value = sPostingError;
			sPostingError = "";

			return return_value;
		}
		public void SetPostingError(string error_msg)
		{
			if (oUtility.IsEmpty(error_msg))
			{
				sPostingError = "";
			}
			else if (oUtility.IsEmpty(sPostingError))
			{
				sPostingError = error_msg;
			}
			else if (oUtility.STrim(sPostingError) != oUtility.STrim(error_msg))
			{
				sPostingError += Environment.NewLine + Environment.NewLine + "AND " + error_msg;
			}
		}

        public class clsGrid
        {
            public int Row_num = 0;                           // Keeps the row number
            public string txtFrom_amt = "";
            public string txtThru_amt = "";
            public string txtRate = "";

		}
		public List<clsGrid> Grid = new List<clsGrid>();

		public bool RecreateDetail()                                                           //  Sync Data with Grid for the items that do not have event-handler ONLY.
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				if (Grid.Count() == 0)
				{
					oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), 0);
					return true;
				}

				// We need to create it here for saving because some fields may not have been copied into the array.
				//
				iTotalRows = Grid.Count();
				oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), iTotalRows - 1);

				foreach (var det in Grid)
				{
					if (RecreateDetailLine(det, row_num) == false)
					{
						return false;
					}

					det.Row_num = row_num;      // Just to make sure.
					row_num++;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetail)");
			}

			return return_value;
		}

		public bool RecreateGridLine(int row_num)
		{
			clsGrid grid_line = new clsGrid();

			if (FindGridLine(row_num, ref grid_line) == false)
			{
				SetPostingError("Grid does not match array.");
				return false;
			}

			return RecreateGridLine(ref grid_line, row_num);
		}

		public bool RecreateGridLine(ref clsGrid cur_item, int row_num)
		{
			bool return_value = false;

			try
			{
				cur_item.txtFrom_amt = Data[FROM_COL, row_num];
				cur_item.txtThru_amt = Data[THRU_COL, row_num];
				cur_item.txtRate = Data[RATE_COL, row_num];
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateGridLine)");
			}
			return return_value;

		}

		public bool FindGridLine(int row_num, ref clsGrid line_found)
		{
			bool return_value = false;

			try
			{
				line_found = Grid.Single(i => i.Row_num == row_num);

				if (line_found != null)
				{
					return_value = true;
				}
			}
			catch (Exception ex)
			{
				// in case not found
			}

			return return_value;
		}

		public bool RecreateDetailLine(clsGrid cur_item, int row_num = -1)
		{
			bool return_value = false;

			try
			{
				// If this is called from UI event, get the row number of current line.
				//
				if (row_num < 0)
				{
					row_num = cur_item.Row_num;
				}
				Data[FROM_COL, row_num] = cur_item.txtFrom_amt;
				Data[THRU_COL, row_num] = cur_item.txtThru_amt;
				Data[RATE_COL, row_num] = cur_item.txtRate;

				return_value = true;

			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetailLine)");
			}

			return return_value;
		}

		public bool RecreateGrid()                                                             //  Create Grid according to Data
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				Grid.Clear();

				if (Data == null)
				{
					return true;
				}
				else if (Data.GetLength(1) == 0)
				{
					return true;
				}

				iTotalRows = Data.GetLength(1);

				for (row_num = 0; row_num < iTotalRows; row_num++)
				{
					Grid.Add(new clsGrid
					{
						Row_num = row_num
						,txtFrom_amt = Data[FROM_COL, row_num]
						,txtThru_amt = Data[THRU_COL, row_num]
						,txtRate = Data[RATE_COL, row_num]

					});
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateGrid)");
			}

			return return_value;
		}


		public bool InsertNewRow(clsGrid cur_item)
		{
			bool return_value = false;
			int old_row_num = cur_item.Row_num;

			try
			{
				Grid.Insert(old_row_num, new clsGrid
				{
					Row_num = -1
					,txtFrom_amt = ""
					,txtThru_amt = ""
					,txtRate = ""

				});

				Grid.Where(i => i.Row_num >= old_row_num).Select(i => { i.Row_num += 1; return i; }).ToList();
				Grid.Single(i => i.Row_num == -1).Row_num = old_row_num;

				iTotalRows += 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (InsertNewRow)");
			}

			return return_value;
		}
		public bool DeleteCurrentRow(clsGrid cur_item)
		{
			bool return_value = false;
			int old_num = cur_item.Row_num;

			try
			{
				Grid.RemoveAt(cur_item.Row_num);
				Grid.Where(i => i.Row_num >= old_num).Select(i => { i.Row_num -= 1; return i; }).ToList();

				iTotalRows -= 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (DeleteCurrentRow)");
			}

			return return_value;
		}

		public bool AddMoreRows(int lines_to_add = 10)
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				// oUtility.ResizeDimPreserved(ref Data, Data.GetUpperBound(0), Data.GetUpperBound(1) + lines_to_add);

				for (row_num = 0; row_num < lines_to_add; row_num++)
				{
					Grid.Add(new clsGrid
					{
						Row_num = iTotalRows
						,txtFrom_amt = ""
						,txtThru_amt = ""
						,txtRate = ""

					}); 

					iTotalRows += 1;

				}

				RecreateDetail();
				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (AddMoreRows)");
				RecreateDetail();
			}

			return return_value;
		}
	}
}
