﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Dynasty.Database;

namespace Dynasty.ASP.Models
{
    public class clsListingTransaction
    {
        clsDynastyUtility oUtility = new clsDynastyUtility();

        public bool Clear()
        {
            bool return_value = false;

            try
            {
                Grid.Clear();
                return_value = true;
            }
            catch (Exception ex)
            {
                return_value = false;
            }

            return return_value;
        }
        public bool Show(clsDatabase cur_db, clsPage cur_page, string where_clause = "", string order_by_clause = "", string[] custom_fields = null)
        {
            string sql_str;
            string entity_cd = "";
            string entity_nm = "";
            string reference = "sReference";
            string your_reference = "";
            string amount_due = "";
            string agent_cd = "";
            string department_cd = "";
            string apply_dt = "";
            string required_dt = "";
            string description = "sDescription";
            string journal = "";
            string from_dt = "";
            string thru_dt = "";
            string document_num = "";

            string extra_field_1 = "";
            string extra_field_2 = "";
            string extra_field_3 = "";
            string extra_field_4 = "";
            string extra_field_5 = "";
            string extra_field_6 = "";
            string extra_field_7 = "";
            string extra_field_8 = "";
            string extra_field_9 = "";
            string extra_field_10 = "";

            decimal total_amount = 0;
            int row_num = 0;
            int i = 0;

            clsRecordset cur_set = new clsRecordset(ref cur_db);
            clsMoney o_money = new clsMoney(ref cur_db);

            Grid.Clear();

            if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_WO_TYPE)         // Do not move down below (cur_page.iTransaction_typ >= 6000 && cur_page.iTransaction_typ <= 6999)
            {
                entity_cd = "sOrderTo_cd";
                department_cd = "sDepartment_cd";
                description = "sComment";
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_PRJOURNAL_TYPE)
            {
                entity_cd = "sDepartment_cd";
                entity_nm = "sGroup_cd";
                apply_dt = "iApply_dt";
                from_dt = "iFrom_dt";
                thru_dt = "iThru_dt";
                reference = "";
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_FA_SERVICE_PLAN_TYPE)
            {
                entity_cd = "sOrderTo_cd";
                entity_nm = "sOffice_cd";
                description = "sComment";
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_FA_RENTAL_RESERVATION_TYPE || cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_FA_RENTAL_TYPE || cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_FA_RENTAL_RETURN_TYPE)
            {
                entity_cd = "sCustomer_cd";
                entity_nm = "sCustomer_nm";
                from_dt = "iContractBegin_dt";
                thru_dt = "iContractEnd_dt";
                description = "sComment";
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_IV_MANUFACTURING_TYPE)
            {
                description = "sComment";
                required_dt = "iRequired_dt";
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_JC_EXPENSE_TYPE || cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_JC_REVENUE_TYPE)
            {
                entity_cd = "sTransactionType_cd";
                apply_dt = "iApply_dt";
                amount_due = "mTransaction_amt";
                document_num = "sDocument_num";
                your_reference = "sYourReference";
                journal = "iReimbursedInvoice_num";
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_EXPENSE_TYPE)
            {
                amount_due = "mTransaction_amt";
                entity_cd = "sEntity_cd";
                document_num = "sDocument_num";
                journal = "iExpense_typ";
                extra_field_1 = "iOrder_num";
                extra_field_2 = "sExpenseAcct_cd";
                extra_field_3 = "sCashAcct_cd";
                extra_field_4 = "iCash_typ";
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_INCOME_TYPE)
            {
                amount_due = "mTransaction_amt";
                extra_field_1 = "sIncomeAcct_cd";
                extra_field_2 = "sCashAcct_cd";
                extra_field_3 = "iCash_typ";
            }
            else if (cur_page.iTransaction_typ >= 1000 && cur_page.iTransaction_typ <= 1999)
            {
                entity_cd = "sJournal_cd";
                amount_due = "mTotalCr_amt";
                apply_dt = "iApply_dt";
                journal = "sJournal_cd";
            }

            sql_str = "SELECT * FROM " + cur_page.sTable_nm;

            if (oUtility.IsNonEmpty(where_clause))
            {
                if (oUtility.IsNonEmpty(cur_page.sRestrictionClause))
                {
                    sql_str += " WHERE " + cur_page.sRestrictionClause;
                    sql_str += " AND " + where_clause;
                }
                else
                {
                    sql_str += " WHERE " + where_clause;
                }
            }
            else if (oUtility.IsNonEmpty(cur_page.sRestrictionClause))
            {
                sql_str += " WHERE " + cur_page.sRestrictionClause;
            }

            if (oUtility.IsNonEmpty(order_by_clause))
            {
                sql_str += " ORDER BY " + order_by_clause;
            }
            else
            {
                sql_str += " ORDER BY " + cur_page.sKeyField_nm;
            }

            if (cur_set.CreateSnapshot(sql_str) == false)
            {
                return false;
            }
            else if (cur_set.EOF())
            {
                //modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NO_RECORDS_FOUND);
                return true;
            }

            if (custom_fields != null)
            {
                oUtility.ResizeDim(ref CustomFields, custom_fields.GetUpperBound(0), cur_set.RecordCount() - 1);
            }

            total_amount = 0;
            row_num = 0;

            while (cur_set.EOF() == false)
            {
                if (oUtility.IsNonEmpty(amount_due))
                {
                    total_amount += cur_set.mField(amount_due);
                }

                Grid.Add(new clsGrid {
                    Row_num = row_num
                    ,Transaction_num = modCommonUtility.GetFieldValue(cur_db, cur_set, "iTransaction_num", cur_page.iTransaction_typ)
                    , Status_typ = modCommonUtility.GetFieldValue(cur_db, cur_set, "iStatus_typ", cur_page.iTransaction_typ)
                    , Entry_dt = modCommonUtility.GetFieldValue(cur_db, cur_set, "iEntry_dt", cur_page.iTransaction_typ)
                    , Apply_dt = modCommonUtility.GetFieldValue(cur_db, cur_set, apply_dt, cur_page.iTransaction_typ)
                    , Required_dt = modCommonUtility.GetFieldValue(cur_db, cur_set, required_dt, cur_page.iTransaction_typ)
                    , From_dt = modCommonUtility.GetFieldValue(cur_db, cur_set, from_dt, cur_page.iTransaction_typ)
                    , Thru_dt = modCommonUtility.GetFieldValue(cur_db, cur_set, thru_dt, cur_page.iTransaction_typ)
                    , Reference = modCommonUtility.GetFieldValue(cur_db, cur_set, reference, cur_page.iTransaction_typ)
                    , Amount = modCommonUtility.GetFieldValue(cur_db, cur_set, amount_due, cur_page.iTransaction_typ)
                    , Entity_cd = modCommonUtility.GetFieldValue(cur_db, cur_set, entity_cd, cur_page.iTransaction_typ)
                    , Entity_nm = modCommonUtility.GetFieldValue(cur_db, cur_set, entity_nm, cur_page.iTransaction_typ)
                    , Agent_cd = modCommonUtility.GetFieldValue(cur_db, cur_set, agent_cd, cur_page.iTransaction_typ)
                    , Department_cd = modCommonUtility.GetFieldValue(cur_db, cur_set, department_cd, cur_page.iTransaction_typ)
                    , Comment = modCommonUtility.GetFieldValue(cur_db, cur_set, description, cur_page.iTransaction_typ)
                    , Journal = modCommonUtility.GetFieldValue(cur_db, cur_set, journal, cur_page.iTransaction_typ)
                    , Document_num = modCommonUtility.GetFieldValue(cur_db, cur_set, document_num, cur_page.iTransaction_typ)
                    , YourReference = modCommonUtility.GetFieldValue(cur_db, cur_set, your_reference, cur_page.iTransaction_typ)
                    , RunningBalance = (oUtility.IsNonEmpty(amount_due)? o_money.ToStrMoney(total_amount, -1, "", true): "")
                    , Extra_1 = modCommonUtility.GetFieldValue(cur_db, cur_set, extra_field_1, cur_page.iTransaction_typ)
                    , Extra_2 = modCommonUtility.GetFieldValue(cur_db, cur_set, extra_field_2, cur_page.iTransaction_typ)
                    , Extra_3 = modCommonUtility.GetFieldValue(cur_db, cur_set, extra_field_3, cur_page.iTransaction_typ)
                    , Extra_4 = modCommonUtility.GetFieldValue(cur_db, cur_set, extra_field_4, cur_page.iTransaction_typ)
                    , Extra_5 = modCommonUtility.GetFieldValue(cur_db, cur_set, extra_field_5, cur_page.iTransaction_typ)
                    , Extra_6 = modCommonUtility.GetFieldValue(cur_db, cur_set, extra_field_6, cur_page.iTransaction_typ)
                    , Extra_7 = modCommonUtility.GetFieldValue(cur_db, cur_set, extra_field_7, cur_page.iTransaction_typ)
                    , Extra_8 = modCommonUtility.GetFieldValue(cur_db, cur_set, extra_field_8, cur_page.iTransaction_typ)
                    , Extra_9 = modCommonUtility.GetFieldValue(cur_db, cur_set, extra_field_9, cur_page.iTransaction_typ)
                    , Extra_10 = modCommonUtility.GetFieldValue(cur_db, cur_set, extra_field_10, cur_page.iTransaction_typ)
                });

                // Set the custom fields
                //
                if (custom_fields != null)
                {
                    for (i = 0; i <= custom_fields.GetUpperBound(0); i++)
                    {
                        CustomFields[i, row_num] = modCommonUtility.GetFieldValue(cur_db, cur_set, custom_fields[i], cur_page.iTransaction_typ);
                    }
                }

                cur_set.MoveNext();
                row_num += 1;
            }

            return true;
        }

        public class clsGrid
        {
            public int Row_num = 0;
            public string Transaction_num { get; set; } = "";
            public string Status_typ { get; set; } = "";
            public string Entry_dt { get; set; } = "";
            public string Apply_dt { get; set; } = "";
            public string Required_dt { get; set; } = "";
            public string From_dt { get; set; } = "";
            public string Thru_dt { get; set; } = "";
            public string Reference { get; set; } = "";
            public string Amount { get; set; } = "";
            public string Entity_cd { get; set; } = "";
            public string Entity_nm { get; set; } = "";
            public string Agent_cd { get; set; } = "";
            public string Department_cd { get; set; } = "";
            public string Comment { get; set; } = "";
            public string Journal { get; set; } = "";
            public string Document_num { get; set; } = "";
            public string YourReference { get; set; } = "";
            public string RunningBalance { get; set; } = "";
            public string Extra_1 { get; set; } = "";
            public string Extra_2 { get; set; } = "";
            public string Extra_3 { get; set; } = "";
            public string Extra_4 { get; set; } = "";
            public string Extra_5 { get; set; } = "";
            public string Extra_6 { get; set; } = "";
            public string Extra_7 { get; set; } = "";
            public string Extra_8 { get; set; } = "";
            public string Extra_9 { get; set; } = "";
            public string Extra_10 { get; set; } = "";
        }
        public List<clsGrid> Grid = new List<clsGrid>();

        public string[,] CustomFields = null;                   // User defined fields

    }

}
