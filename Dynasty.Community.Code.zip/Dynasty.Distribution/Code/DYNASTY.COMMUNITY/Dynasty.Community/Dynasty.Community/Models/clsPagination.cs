﻿using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Collections;
using Dynasty.Database;

namespace Dynasty.ASP.Models
{
    public class clsPagination
    {
		private clsDynastyUtility moUtility = new clsDynastyUtility();
		private clsInquiry moInquiry = new clsInquiry();

		public clsPagination() : base()
        {
			Clear();
        }

		public class clsLinkButton
        {
            public bool Clicked { get; set; } = false;
            public bool Visible { get; set; } = false;
            public string Text { get; set; } = "";
            public int Value { get; set; } = 0;
			public string ForeColor { get; set; } = "lightgreen";
        }

		public const int TOTAL_SUMMARY_PAGES = 5;

		public readonly string ACTIVE_COLOR = "springgreen"; 
		public readonly string INACTIVE_COLOR = "skyblue"; 

		public clsLinkButton PreviousLink = new clsLinkButton();
        public clsLinkButton Link1 = new clsLinkButton();
        public clsLinkButton Link2 = new clsLinkButton();
        public clsLinkButton Link3 = new clsLinkButton();
        public clsLinkButton Link4 = new clsLinkButton();
        public clsLinkButton Link5 = new clsLinkButton();
        public clsLinkButton NextLink = new clsLinkButton();

		public string[,] EntireData = null;

		public int CurrentPage { get; set; } = 0;

		public bool Clear()
        {
			CurrentPage = 0;
			EntireData = null;

			Link1.Value = 1;
			Link2.Value = 2;
			Link3.Value = 3;
			Link4.Value = 4;
			Link5.Value = 5;
			SetText();

			return true;
        }

		public bool ArrangeLinks(int total_records, int max_lines_per_page, ref int first_row, ref int last_row, ref int cur_page)
		{
			bool return_value = false;
			int remaining_rows = 0;

			try
			{
				if (max_lines_per_page == 0)
                {
					max_lines_per_page = 500;		// Default for full listing
				}

				if (cur_page == 0)
				{
					first_row = 0;
				}
				else
				{
					first_row = (cur_page - 1) * max_lines_per_page;
				}

				if (max_lines_per_page > 0 && (total_records > first_row + max_lines_per_page))
				{
					last_row = first_row + max_lines_per_page - 1;
				}
				else
				{
					last_row = total_records - 1;
				}

				remaining_rows = total_records - first_row;

				if (cur_page == 0 || cur_page < Link1.Value || cur_page > Link5.Value) // From next button or initial call
				{

					if (cur_page == 0)
					{
						cur_page = 1;
						Link1.Value = 1;
						Link2.Value = 2;
						Link3.Value = 3;
						Link4.Value = 4;
						Link5.Value = 5;
					}

					NextLink.ForeColor = INACTIVE_COLOR;
					PreviousLink.ForeColor = INACTIVE_COLOR;

					// remaining_rows is the total rows counting from the first row of Link1 to the end of recordset.
					// When Prev button is pressed, cur_page is set to Link5 so that we need to add this number to create the actual "remaining_rows" that works in this context.
					//
					if (cur_page < Link1.Value)
					{
						remaining_rows += (TOTAL_SUMMARY_PAGES - 1) * max_lines_per_page;
					}

					NextLink.Visible = (remaining_rows > max_lines_per_page * TOTAL_SUMMARY_PAGES);

					Link2.Visible = (remaining_rows > max_lines_per_page * 1);
					Link3.Visible = (remaining_rows > max_lines_per_page * 2);
					Link4.Visible = (remaining_rows > max_lines_per_page * 3);
					Link5.Visible = (remaining_rows > max_lines_per_page * 4);
					NextLink.Visible = (remaining_rows > max_lines_per_page * TOTAL_SUMMARY_PAGES);

					Link1.Visible = Link2.Visible;      // Link1 is visible only when Link2 is

				}

				//PreviousLink.Visible = (goUtility.Link1.Value > 1)
				PreviousLink.Visible = (cur_page > TOTAL_SUMMARY_PAGES);

				Link1.ForeColor = INACTIVE_COLOR;
				Link2.ForeColor = INACTIVE_COLOR;
				Link3.ForeColor = INACTIVE_COLOR;
				Link4.ForeColor = INACTIVE_COLOR;
				Link5.ForeColor = INACTIVE_COLOR;
				Link1.Clicked = false;
				Link2.Clicked = false;
				Link3.Clicked = false;
				Link4.Clicked = false;
				Link5.Clicked = false;

				if ((cur_page % TOTAL_SUMMARY_PAGES) == 0)
				{
					Link5.ForeColor = ACTIVE_COLOR;
					Link5.Clicked = true;
				}
				if ((cur_page % TOTAL_SUMMARY_PAGES) == 1)
				{
					Link1.ForeColor = ACTIVE_COLOR;
					Link1.Clicked = true;
				}
				if ((cur_page % TOTAL_SUMMARY_PAGES) == 2)
				{
					Link2.ForeColor = ACTIVE_COLOR;
					Link2.Clicked = true;
				}
				if ((cur_page % TOTAL_SUMMARY_PAGES) == 3)
				{
					Link3.ForeColor = ACTIVE_COLOR;
					Link3.Clicked = true;
				}
				if ((cur_page % TOTAL_SUMMARY_PAGES) == 4)
				{
					Link4.ForeColor = ACTIVE_COLOR;
					Link4.Clicked = true;
				}

				SetText();

				return_value = true;

			}
			catch (Exception ex)
			{
			}

			return return_value;

		}

		public bool PreviousPage_Clicked(Func<bool> func_to_call)
        {
			if (Link1.Value > 1)
			{
				CurrentPage = (Link1.Value - 1);
				func_to_call();
				Link5.Value = Link1.Value - 1;
				Link4.Value = Link1.Value - 2;
				Link3.Value = Link1.Value - 3;
				Link2.Value = Link1.Value - 4;
				Link1.Value = Link1.Value - 5;
			}
			else
			{
				CurrentPage = 0;
				func_to_call();
			}

			SetText();

			return true;
		}

		public bool NextPage_Clicked(Func<bool> func_to_call)
		{
			if (Link5.Value > 1)
			{
				CurrentPage = (Link5.Value + 1);
				func_to_call();
				Link1.Value = Link5.Value + 1;
				Link2.Value = Link5.Value + 2;
				Link3.Value = Link5.Value + 3;
				Link4.Value = Link5.Value + 4;
				Link5.Value = Link5.Value + 5;
			}

			SetText();

			return true;
		}

		public bool Link_Clicked(int link_num)
		{
			Link1.Clicked = false;
			Link2.Clicked = false;
			Link3.Clicked = false;
			Link4.Clicked = false;
			Link5.Clicked = false;

			switch (link_num)
            {
				case 1:
					CurrentPage = Link1.Value;
					Link1.Clicked = true;
					break;
				case 2:
					CurrentPage = Link2.Value;
					Link2.Clicked = true;
					break;
				case 3:
					CurrentPage = Link3.Value;
					Link3.Clicked = true;
					break;
				case 4:
					CurrentPage = Link4.Value;
					Link4.Clicked = true;
					break;
				default :
					CurrentPage = Link5.Value;
					Link5.Clicked = true;
					break;
			}

			return true;
		}

		public string ForeColor(int link_num)
        {
			string return_value;

			return_value = INACTIVE_COLOR;

			if (link_num == 1 && Link1.Clicked)
            {
				return_value = ACTIVE_COLOR;
			}
			else if (link_num == 2 && Link2.Clicked)
			{
				return_value = ACTIVE_COLOR;
			}
			else if (link_num == 3 && Link3.Clicked)
			{
				return_value = ACTIVE_COLOR;
			}
			else if (link_num == 4 && Link4.Clicked)
			{
				return_value = ACTIVE_COLOR;
			}
			else if (link_num == 5 && Link5.Clicked)
			{
				return_value = ACTIVE_COLOR;
			}

			return return_value;
        }

		private bool  SetText()
        {
			Link1.Text = Link1.Value.ToString();
			Link2.Text = Link2.Value.ToString();
			Link3.Text = Link3.Value.ToString();
			Link4.Text = Link4.Value.ToString();
			Link5.Text = Link5.Value.ToString();

			PreviousLink.Text = GlobalVar.goConstant.PREV;
			NextLink.Text = GlobalVar.goConstant.NEXT;

			return true;
        }

		// This is to create the full set of data
		//
		public bool GetComparativeData(ref clsDatabase cur_db,  clsSpreadsheet cur_sheet, Models.clsPagination cur_page, clsRecordset cur_set, int period_type, string[] grouping_item
			, int period_col, ref int total_columns, List<clsCombobox> selected_list, List<clsCombobox> entity_type_list, string STR_ENTITY_TYPE)
		{
			bool return_value = false;
			int row_num = 0;
			int col_num = 0;
			int i = 0;
			int k = 0;
			int max_row = 0;
			string tmp = "";
			string last_period = "";
			string[,] summary_data = null;
			string[,] entity_type = null;
			try
			{
				moUtility.ResizeDim(ref summary_data, cur_set.RecordCount() + grouping_item.GetUpperBound(0), cur_set.RecordCount() + 1); // Temporarily. To be resized down below

				if (selected_list.Count == 0)
				{
					// If no grouping is specified, each record of cur_set has two fields: period and data
					//
					col_num = 0;
					while (!cur_set.EOF())
					{
						summary_data[col_num, 0] = moInquiry.GetPeriodCaption(ref cur_db, cur_set.Field(period_col).ToString(), period_type);
						summary_data[col_num, 1] = modCommonUtility.GetGenericColumnText(ref cur_db, cur_set, 1);

						modGeneralUtility.RunEvents();

						cur_set.MoveNext();
						col_num += 1;

					}

					moUtility.ResizeDimPreserved(ref summary_data, summary_data.GetUpperBound(0), 1);
					total_columns = col_num;

				}
				else
				{
					// Group-by column headings
					col_num = 0;
					foreach (var itm in selected_list)
					{
						summary_data[col_num, 0] = itm.Value;
						col_num += 1;
					}

					last_period = "";
					col_num = selected_list.Count - 1;
					max_row = -1;

					while (!cur_set.EOF())
					{
						// If new date/period comes up.
						if (last_period != cur_set.Field(period_col).ToString())
						{
							last_period = cur_set.Field(period_col).ToString();
							col_num += 1;
							summary_data[col_num, 0] = moInquiry.GetPeriodCaption(ref cur_db, last_period, period_type);
						}

						// Find a row to show the numbers.  This is necessary because items, customers & vendors may not appear from the first period.
						//
						for (row_num = 1; row_num <= max_row; row_num++)
						{
							for (i = 0; i < selected_list.Count; i++) // Check if exists.
							{
								if (summary_data[i, row_num] != cur_set.Field(i + 1).ToString())
								{
									break;
								}
							}
							if (i >= selected_list.Count)
							{
								break;
							}
						}

						for (i = 0; i < selected_list.Count; i++)
						{
							summary_data[i, row_num] = cur_set.Field(i + 1).ToString();
						}
						summary_data[col_num, row_num] = modCommonUtility.GetGenericColumnText(ref cur_db, cur_set, (cur_set.FieldCount() - 1)); 

						cur_set.MoveNext();

						if (max_row < row_num)
						{
							max_row = row_num;
						}
					}

					moUtility.ResizeDimPreserved(ref summary_data, summary_data.GetUpperBound(0), max_row);
					total_columns = (col_num + 1);

					// Set the entity type: customer & vendor types
					//
					if (entity_type_list != null && moUtility.IsNonEmpty(STR_ENTITY_TYPE))
                    {
						// Change the values of *_typ to meaningful values.
						//
						GlobalVar.goUtility.ResizeDim(ref entity_type, 1, entity_type_list.Count - 1);

						i = 0;
						foreach (var itm in entity_type_list)
						{
							entity_type[0, i] = itm.Text;
							entity_type[1, i] = itm.Value;
							i += 1;
						}

						for (col_num = 0; col_num < selected_list.Count; col_num++)
						{
							if (selected_list[col_num].Text == STR_ENTITY_TYPE)
							{
								for (row_num = 0; row_num < summary_data.GetLength(1); row_num++)
								{
									for (k = 0; k < entity_type.GetLength(1); k++)
									{
										if (entity_type[1, k] == summary_data[col_num, row_num])
										{
											summary_data[col_num, row_num] = entity_type[0, k];
											break;
										}
									}
								}
							}
						}
					}

				}

				total_columns = moUtility.IIf(total_columns < summary_data.GetLength(0), total_columns, summary_data.GetLength(0));

				// Create FieldName[] with arbirary names for display. it is used in cur_sheet.InquiryCSS().
				//
				moUtility.ResizeDim(ref cur_sheet.FieldName, total_columns - 1);

				for (col_num = 0; col_num < total_columns; col_num++)
				{
					if (col_num < selected_list.Count)
					{
						cur_sheet.FieldName[col_num] = "sTemp" + col_num.ToString();
					}
					else
					{
						cur_sheet.FieldName[col_num] = "mTemp" + col_num.ToString() + "_amt";
					}
				}

				// Create the actual data and column captions for display.
				//
				moUtility.ResizeDim(ref cur_sheet.Caption, total_columns - 1);

				// Column headings
				//
				for (col_num = 0; col_num < total_columns; col_num++)
				{
					cur_sheet.Caption[col_num] = summary_data[col_num, 0];
				}

				// For pagination
				//
				cur_page.Clear();
				moUtility.ResizeDim(ref cur_page.EntireData, clsSpreadsheet.TOTAL_COLUMNS - 1, summary_data.GetUpperBound(1) - 1);      // -1 is because summary_data[] has captions on the first row.

				for (row_num = 1; row_num < summary_data.GetLength(1); row_num++)
				{
					for (col_num = 0; col_num < total_columns; col_num++)
					{
						cur_page.EntireData[col_num, row_num - 1] = summary_data[col_num, row_num];
					}
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (GetComparativeData)");
			}

			return return_value;
		}

	}

}
