﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//



using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Collections.Generic;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP.Models
{
	public class clsChargeDetail
	{
		private int iTransaction_typ = 0;
		public int iTransaction_num = 0;						// Optional.  Used in S/O last price searching
		private string sPostingError = "";

		private clsArray oArray = new clsArray();
		private clsDynastyUtility oUtility = new clsDynastyUtility();

		// QUANTITY_COL shows the quantity column that that shows the transaction quantity.
		//
		int _qty_col = 0;
        public int QUANTITY_COL
		{
            get { return _qty_col; }
        }

        public clsChargeDetail(int trx_type) : base()
		{
			iTransaction_typ = trx_type;

			if (iTransaction_typ == GlobalVar.goConstant.TRX_INVOICE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_CM_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_WH_SHIPPING_SLIP_TYPE
			|| iTransaction_typ == GlobalVar.goConstant.TRX_PURCHASE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_DM_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_WH_RECEIVING_SLIP_TYPE)
			{
				_qty_col = QTY_SHIPPED_COL;
			}
			else
            {
				_qty_col = QTY_ORDERED_COL;
			}
		}

		public bool IsErrorFound()
		{
			bool return_value = false;

			return_value = (oUtility.IsNonEmpty(sPostingError));

			return return_value;
		}

		public string GetErrorMessage()
		{
			string return_value = "";

			return_value = sPostingError;
			sPostingError = "";

			return return_value;
		}

		public void SetPostingError(string error_msg)
		{
			if (oUtility.IsEmpty(error_msg))
			{
				sPostingError = "";
			}
			else if (oUtility.IsEmpty(sPostingError))
			{
				sPostingError = error_msg;
			}
			else if (oUtility.STrim(sPostingError) != oUtility.STrim(error_msg))
			{
				sPostingError += Environment.NewLine + Environment.NewLine + "AND " + error_msg;
			}
		}
		// When serial/lot items are entered, iNextLine_id will link to each item in the serial/lot list.
		// Once iNextLine_id assigned, it does not changed and maintain the uniqueness during the course of line manipulations such as delete/insert.
		//
		public int iNextLine_id = 1;
		public int iNextKit_id = 1;
		public int iTotalRows = 0;

        public string[] FieldName;                                                              // Keeps the detail field names;
		public string[,] Data;																	// Keeps the detail data.

		public const int ROW_DELETE_COL = 0;
		public const int ROW_INSERT_COL = 1;
		public const int ITEM_CODE_COL = 2;
		public const int ZOOM_ITEM_CODE_COL = 3;
		public const int LOCATION_COL = 4;
		public const int DESCRIPTION_COL = 5;
		public const int ITEM_MANUFACTURER_COL = 6;
		public const int ITEM_BRAND_COL = 7;
		public const int ITEM_MODEL_COL = 8;
		public const int ITEM_STYLE_COL = 9;
		public const int ITEM_COLOR_COL = 10;
		public const int ITEM_SIZE_COL = 11;
		public const int UNIT_CODE_COL = 12;
		public const int QTY_ORDERED_COL = 13;
		public const int QTY_ALLOCATED_COL = 14;			// For sales order only
		public const int QTY_SHIPPED_COL = 15;				// For invoice & credit memo.   For voucher and debit memo, this is qty-received
		public const int QTY_BACKORDER_COL = 16;
		public const int UNIT_PRICE_COL = 17;
		public const int AMT_EXTENDED_COL = 18;
		public const int UNIT_PRICE_IN_PRIMARY_CURRENCY_COL = 19;
		public const int AMT_EXTENDED_IN_PRIMARY_CURRENCY_COL = 20;
		public const int DISC_PERC_COL = 21;
		public const int JOB_CODE_COL = 22;
		public const int TAX_CODE_COL = 23;
		public const int FULL_ACCT_CODE_COL = 24;

		public const int NATURAL_ACCT_CODE_COL = 25;
		public const int SEGMENT1_COL = 26;
		public const int SEGMENT2_COL = 27;
		public const int SEGMENT3_COL = 28;
		public const int SEGMENT4_COL = 29;
		public const int SEGMENT5_COL = 30;
		public const int SEGMENT6_COL = 31;

		public const int AMT_TAX_COL = 32;
		public const int TAX_PERC_COL = 33;
		public const int QTY_IN_IVUNIT_COL = 34;
		public const int IVUNIT_CODE_COL = 35;
		public const int UNIT_COST_COL = 36;
		public const int ITEM_TYPE_COL = 37;
		public const int AMT_DISC_COL = 38;
		public const int CONVERSION_RATE_COL = 39;
		public const int LINE_ID_COL = 40;
		public const int KIT_ID_COL = 41;
		public const int SELL_UNIT_CODE_COL = 42;
		public const int SELL_UNIT_PRICE_COL = 43;
		public const int WEIGHT_PER_UNIT_COL = 44;
		public const int FREIGHT_PER_UNIT_COL = 45;
		public const int DATE_REQUIRED_COL = 46;
		public const int DATE_RECEIVED_COL = 47;
		public const int PROCESS_ID_COL = 48;
		public const int DATE_BACKORDERED_COL = 49;
		public const int PO_NUM_COL = 50;
		public const int QTY_INVOICED_COL = 51;
		public const int PRIMARY_ITEM_CODE_COL = 52;
		public const int AMT_TAX_IN_PRIMARY_CURRENCY_COL = 53;
		public const int AMT_DISC_IN_PRIMARY_CURRENCY_COL = 54;
		public const int SOURCE_TYPE_COL = 55;
		public const int SOURCE_NUM_COL = 56;
		public const int SOURCE_DETAIL_ID_COL = 57;
		public const int VENDOR_ITEM_CODE_COL = 58;
		public const int ENTITY_CODE_COL = 59;
		public const int SERIAL_CODE_COL = 60;
		public const int LAST_PRICE_COL = 61;

		// Invoice specific columns
		//
		public const int ORDER_NUM_COL = 62;
		public const int EXPENSE_TYPE_COL = 63;
		public const int EXPENSE_NUM_COL = 64;
		public const int EXPENSE_DETAIL_COL = 65;
		public const int TOTAL_COST_COL = 66;
		public const int LINE_TYPE_COL = 67;

		// Memo specific columns
		//
		public const int QTY_CUR_RETURNED_COL = 68;
		public const int QTY_PREV_RETURN_COL = 69;

		// Voucher Specific columns
		//
		public const int REIMBURSED_INVOICE_NUM_COL = 70;

		// show the current inventory available
		//
		public const int QTY_AVAILABLE_COL = 71;                          
		public const int QTY_ON_HAND_COL = 72;
		public const int QTY_ON_ORDER_COL = 73;

		// Work Order
		public const int ASSET_CODE_COL = 74;
		public const int SERVICE_CODE_COL = 75;
		public const int DATE_ESTIMATED_COL = 76;
		public const int DATE_STARTED_COL = 77;
		public const int DATE_FINISHED_COL = 78;
		public const int QTY_IN_PRODUCTION_COL = 79;
		public const int INVOICE_NUM_COL = 80;

		// commission
		public const int COMMISSION_AMT_COL = 81;
		public const int COST_AMT_COL = 82;

		// Manufacturing in W/O
		//
		public const int START_TIME_COL = 83;
        public const int END_TIME_COL = 84;

        // Etc
        //
        public const int INCLUDE_COL = 88;
		public const int BOX_CODE_COL = 89;

		// Packing slip & transfers.
		//
		public const int DEFAULT_BIN_COL = 90;
		public const int BIN_COL = 91;
		public const int BIN_QTY_COL = 92;
		public const int BIN2_COL = 93;
		public const int BIN2_QTY_COL = 94;
		public const int BIN3_COL = 95;
		public const int BIN3_QTY_COL = 96;
		public const int BIN4_COL = 97;
		public const int BIN4_QTY_COL = 98;
		public const int BIN5_COL = 99;
		public const int BIN5_QTY_COL = 100;

		// For future use
		//
		public const int USER_DEFINED1_COL = 101;
		public const int USER_DEFINED2_COL = 102;
		public const int USER_DEFINED3_COL = 103;
		public const int USER_DEFINED4_COL = 104;
		public const int USER_DEFINED5_COL = 105;
		public const int USER_DEFINED1_AMT_COL = 106;
		public const int USER_DEFINED2_AMT_COL = 107;
		public const int USER_DEFINED3_AMT_COL = 108;
		public const int USER_DEFINED4_AMT_COL = 109;
		public const int USER_DEFINED5_AMT_COL = 110;
		public const int USER_DEFINED1_DT_COL = 111;
		public const int USER_DEFINED2_DT_COL = 112;
		public const int USER_DEFINED3_DT_COL = 113;
		public const int USER_DEFINED4_DT_COL = 114;
		public const int USER_DEFINED5_DT_COL = 115;
		public const int USER_DEFINED1_NUM_COL = 116;
		public const int USER_DEFINED2_NUM_COL = 117;
		public const int USER_DEFINED3_NUM_COL = 118;
		public const int USER_DEFINED4_NUM_COL = 119;
		public const int USER_DEFINED5_NUM_COL = 120;

		public const int TOTAL_COLUMNS = 121;

		public class clsGrid
		{
			public int Row_num = 0;                                 // 0-based row number. This will identify each row.
			public string txtAllocated_qty = "";					// S/O-specific									
			public string lblBackOrdered_dt = "";                   // S/O-specific
			public string txtBrand_cd = "";
			public string txtColor_cd = "";
			public string lblConversion_rt = "";
			public string lblUnitCost_amt = "";
			public string lblTotalCost_amt = "";
			public string txtDescription = "";
			public string lblDiscount_amt = "";
			public string txtDiscount_pc = "";
			public string lblDiscountInPrimary_amt = "";			
			public string txtEntity_cd = "";                        // S/O-specific
			public string lblEPO_fl = "";                           // S/O-specific
			public string lblExpense_num = "";						// Invoice-specific
			public string lblExpense_typ = "";                      // Invoice-specific
			public string lblExpenseDetail_num = "";                // Invoice-specific
			public string lblExtended_amt = "";
			public string lblExtendedInPrimary_amt = "";
			public string lblInIVUnit_qty = "";
			public string txtItem_cd = "";
			public string lblItem_typ = "";
			public string lblIVUnit_cd = "";
			public string cboJob_cd = "";
			public string lblKit_id = "";
			public string lblLine_id = "";
			public string lblLine_typ = "";
			public string lblLocation_cd = "";
			public string txtManufacturer_cd = "";
			public string lblMarkup_pc = "";                          // S/O-specific 
			public string txtModel_cd = "";
			public string lblOrder_num = "";                          // Invoice-specific
			public string lblPO_num = "";                             // S/O-specific  
			public string lblPrimaryItem_cd = "";
			public string lblProcess_id = "";                         // S/O-specific  
			public string lblReceived_dt = "";                        // S/O-specific  
			public string txtRequired_dt = "";                          
			public string mskGLAccount_cd = "";
			public string lblSellUnit_cd = "";
			public string lblSellUnitPrice_amt = "";
			public string txtSize_cd = "";
			public string txtStyle_cd = "";
			public string txtTax_amt = "";
			public string cboTax_cd = "";
			public string lblTax_pc = "";
			public string lblTaxInPrimary_amt = "";
			public string lblFreight_amt = "";
			public string txtUnit_cd = "";
			public string txtUnitPrice_amt = "";
			public string txtUnitPriceInPrimary_amt = "";
			public string lblWeight = "";
			public string txtOrdered_qty = "";
			public string txtShipped_qty = "";						 // For voucher, this is qty-received.   For memo, this is qty-authorized.
			public string lblInvoiced_qty = "";                       
			public string lblBackorder_qty = "";
			public string lblPreviousReturned_qty = "";
			public string lblCurrentReturned_qty = "";
			public string lblReimbursedInvoice_num = "";              // A/P-specific
			public string lblSource_num = "";                         // S/O-specific  
			public string lblSource_typ = "";                         // S/O-specific  
			public string lblSourceDetail_num = "";
			public string txtSerial_cd = "";
			public string lblLastPrice_amt = "";

			public bool chkInclude_fl = false;
			public string txtBox_cd = "";
			public string txtVendorItem_cd = "";

			// Work Order
			//
			public string txtAsset_cd = "";                         
			public string txtService_cd = "";
			public string txtEstimated_dt = "";
			public string txtStarted_dt = "";
			public string txtFinished_dt = "";
			public string txtInProduction_qty = "";
			public string txtInvoice_num = "";

            public DateTime? dtStarted_dt = null;		// This is only for UI.   ? means nullable.
            public DateTime? dtEstimated_dt = null;		// This is only for UI
            public DateTime? dtFinished_dt = null;		// This is only for UI
            public DateTime? dtRequired_dt = null;      // This is only for UI

            // Commission
            //
            public string txtCommission_amt = "";
			public string txtCost_amt = "";

			// Manufacturing in W/O
			//
			public string txtStartTime = "";
			public string txtEndTime = "";

			public TimeOnly dtStartTime = new TimeOnly();		// Only for UI
			public TimeOnly dtEndTime = new TimeOnly();

			// For purchase requisision
			// These are only for display
			//
			public string lblAvailable_qty = "";
			public string lblOnHand_qty = "";
			public string lblOnOrder_qty = "";


			// Columns that are used for segment-oriented account code entry.
			//
			public string txtNaturalAcct_cd = "";
			public string txtSegment1_cd = "";
			public string txtSegment2_cd = "";
			public string txtSegment3_cd = "";
			public string txtSegment4_cd = "";
			public string txtSegment5_cd = "";
			public string txtSegment6_cd = "";
			public string txtSegment7_cd = "";
			public string txtSegment8_cd = "";

			// Packing slip & transfers.
			//
			public string txtDefaultBin_cd = "";
			public string txtBin_cd = "";
			public string txtBin_qty = "";
			public string txtBin2_cd = "";
			public string txtBin2_qty = "";
			public string txtBin3_cd = "";
			public string txtBin3_qty = "";
			public string txtBin4_cd = "";
			public string txtBin4_qty = "";
			public string txtBin5_cd = "";
			public string txtBin5_qty = "";

			// For future use.
			//
			public string txtUserDefined1 = "";
			public string txtUserDefined2 = "";
			public string txtUserDefined3 = "";
			public string txtUserDefined4 = "";
			public string txtUserDefined5 = "";
			public string txtUserDefined1_amt = "";
			public string txtUserDefined2_amt = "";
			public string txtUserDefined3_amt = "";
			public string txtUserDefined4_amt = "";
			public string txtUserDefined5_amt = "";
			public string txtUserDefined1_dt = "";
			public string txtUserDefined2_dt = "";
			public string txtUserDefined3_dt = "";
			public string txtUserDefined4_dt = "";
			public string txtUserDefined5_dt = "";
			public string txtUserDefined1_num = "";
			public string txtUserDefined2_num = "";
			public string txtUserDefined3_num = "";
			public string txtUserDefined4_num = "";
			public string txtUserDefined5_num = "";

		}
		public List<clsGrid> Grid = new List<clsGrid>();

		public bool AddMoreRows(int lines_to_add = 10)
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
                // oUtility.ResizeDimPreserved(ref Data, Data.GetUpperBound(0), Data.GetUpperBound(1) + lines_to_add);

                for (row_num = 0; row_num < lines_to_add; row_num++)
                {
                    Grid.Add(new clsGrid { Row_num = iTotalRows
							, txtAllocated_qty = ""														
							, lblBackorder_qty = ""
							, lblBackOrdered_dt = ""                   
							, txtBrand_cd = ""
							, txtColor_cd = ""
							, lblConversion_rt = ""
							, lblUnitCost_amt = ""
							, lblTotalCost_amt = ""
							, txtDescription = ""
							, lblDiscount_amt = ""
							, txtDiscount_pc = ""
							, lblDiscountInPrimary_amt = ""			
							, txtEntity_cd = ""                        
							, lblEPO_fl = ""                           
							, lblExpense_num = ""						
							, lblExpense_typ = ""                      
							, lblExpenseDetail_num = ""                
							, lblExtended_amt = ""
							, lblExtendedInPrimary_amt = ""
							, lblInIVUnit_qty = ""
							, txtItem_cd = ""
							, lblItem_typ = ""
							, lblIVUnit_cd = ""
							, cboJob_cd = ""
							, lblKit_id = ""
							, lblLine_id = iNextLine_id.ToString()
							, lblLine_typ = ""
							, lblLocation_cd = ""
							, txtManufacturer_cd = ""
							, lblMarkup_pc = ""                            
							, txtModel_cd = ""
							, lblOrder_num = ""                            
							, txtOrdered_qty = ""
							, lblPO_num = ""                               
							, lblPrimaryItem_cd = ""
							, lblProcess_id = ""                           
							, lblReceived_dt = ""                          
							, mskGLAccount_cd = ""
							, lblSellUnit_cd = ""
							, lblSellUnitPrice_amt = ""
							, txtShipped_qty = ""
							, txtSize_cd = ""
							, txtStyle_cd = ""
							, txtTax_amt = ""
							, cboTax_cd = ""
							, lblTax_pc = ""
							, lblTaxInPrimary_amt = ""
							, lblFreight_amt = ""
							, txtUnit_cd = ""
							, txtUnitPrice_amt = ""
							, txtUnitPriceInPrimary_amt = ""
							, lblWeight = ""
							, lblInvoiced_qty = ""                         
							, lblPreviousReturned_qty = ""
							, lblCurrentReturned_qty = ""
							, lblReimbursedInvoice_num = ""
							, lblSource_num = ""                           
							, lblSource_typ = ""                           
							, lblSourceDetail_num = ""
							, chkInclude_fl = false
							, txtBox_cd = ""
							, txtVendorItem_cd = ""
							, lblAvailable_qty = ""
							, lblOnHand_qty = ""
							, lblOnOrder_qty = ""
							,txtAsset_cd = ""                         
							,txtService_cd = ""
							,txtEstimated_dt = ""
							,txtStarted_dt = ""
							,txtFinished_dt = ""
							,txtRequired_dt = ""
							,dtStarted_dt = null
							,dtEstimated_dt = null
							,dtFinished_dt = null
							,dtRequired_dt = null

							,txtInProduction_qty = ""
							,txtInvoice_num = ""
							,txtCommission_amt = ""
							,txtCost_amt = ""

							, txtNaturalAcct_cd = ""
							, txtSegment1_cd = ""
							, txtSegment2_cd = ""
							, txtSegment3_cd = ""
							, txtSegment4_cd = ""
							, txtSegment5_cd = ""
							, txtSegment6_cd = ""
							, txtSegment7_cd = ""
							, txtSegment8_cd = ""
							, txtDefaultBin_cd = ""
							, txtBin_cd = ""
							, txtBin_qty = ""
							, txtBin2_cd = ""
							, txtBin2_qty = ""
							, txtBin3_cd = ""
							, txtBin3_qty = ""
							, txtBin4_cd = ""
							, txtBin4_qty = ""
							, txtBin5_cd = ""
							, txtBin5_qty = ""
							, txtUserDefined1 = ""
							, txtUserDefined2 = ""
							, txtUserDefined3 = ""
							, txtUserDefined4 = ""
							, txtUserDefined5 = ""
							, txtUserDefined1_amt = ""
							, txtUserDefined2_amt = ""
							, txtUserDefined3_amt = ""
							, txtUserDefined4_amt = ""
							, txtUserDefined5_amt = ""
							, txtUserDefined1_dt = ""
							, txtUserDefined2_dt = ""
							, txtUserDefined3_dt = ""
							, txtUserDefined4_dt = ""
							, txtUserDefined5_dt = ""
							, txtUserDefined1_num = ""
							, txtUserDefined2_num = ""
							, txtUserDefined3_num = ""
							, txtUserDefined4_num = ""
							, txtUserDefined5_num = ""

					});;;

                    iTotalRows += 1;
					iNextLine_id += 1;

				}
                
                RecreateDetail();
                return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (AddMoreRows)");
				RecreateDetail();
            }

            return return_value;
        }

		public bool InsertNewRow(clsGrid cur_item, int at_row_num = -1)
        {
			bool return_value = false;

			if (at_row_num < 0)
            {
				at_row_num = cur_item.Row_num;
			}

            try
            {
				Grid.Insert(at_row_num, new clsGrid { Row_num = -1
							, txtAllocated_qty = ""														
							, lblBackorder_qty = ""
							, lblBackOrdered_dt = ""                   
							, txtBrand_cd = ""
							, txtColor_cd = ""
							, lblConversion_rt = ""
							, lblUnitCost_amt = ""
							, lblTotalCost_amt = ""
							, txtDescription = ""
							, lblDiscount_amt = ""
							, txtDiscount_pc = ""
							, lblDiscountInPrimary_amt = ""			
							, txtEntity_cd = ""                        
							, lblEPO_fl = ""                           
							, lblExpense_num = ""						
							, lblExpense_typ = ""                      
							, lblExpenseDetail_num = ""                
							, lblExtended_amt = ""
							, lblExtendedInPrimary_amt = ""
							, lblInIVUnit_qty = ""
							, txtItem_cd = ""
							, lblItem_typ = ""
							, lblIVUnit_cd = ""
							, cboJob_cd = ""
							, lblKit_id = ""
							, lblLine_id = iNextLine_id.ToString()
							, lblLine_typ = ""
							, lblLocation_cd = ""
							, txtManufacturer_cd = ""
							, lblMarkup_pc = ""                            
							, txtModel_cd = ""
							, lblOrder_num = ""                            
							, txtOrdered_qty = ""
							, lblPO_num = ""                               
							, lblPrimaryItem_cd = ""
							, lblProcess_id = ""                           
							, lblReceived_dt = ""                          
							, mskGLAccount_cd = ""
							, lblSellUnit_cd = ""
							, lblSellUnitPrice_amt = ""
							, txtShipped_qty = ""
							, txtSize_cd = ""
							, txtStyle_cd = ""
							, txtTax_amt = ""
							, cboTax_cd = ""
							, lblTax_pc = ""
							, lblTaxInPrimary_amt = ""
							, lblFreight_amt = ""
							, txtUnit_cd = ""
							, txtUnitPrice_amt = ""
							, txtUnitPriceInPrimary_amt = ""
							, lblWeight = ""
							, lblInvoiced_qty = ""                         
							, lblPreviousReturned_qty = ""
							, lblCurrentReturned_qty = ""
							, lblReimbursedInvoice_num = ""
							, lblSource_num = ""                           
							, lblSource_typ = ""                           
							, lblSourceDetail_num = ""
							, chkInclude_fl = false
							, txtBox_cd = ""
							, txtVendorItem_cd  = ""
							, lblAvailable_qty = ""
							, lblOnHand_qty = ""
							, lblOnOrder_qty = ""
							, txtNaturalAcct_cd = ""
							,txtAsset_cd = ""                         
							,txtService_cd = ""
							,txtEstimated_dt = ""
							,txtStarted_dt = ""
							,txtFinished_dt = ""
							,txtRequired_dt = ""
							,dtStarted_dt = null
							,dtEstimated_dt = null
							,dtFinished_dt = null
							,dtRequired_dt = null

							,txtInProduction_qty = ""
							,txtInvoice_num = ""
							,txtCommission_amt = ""
							,txtCost_amt = ""

							, txtSegment1_cd = ""
							, txtSegment2_cd = ""
							, txtSegment3_cd = ""
							, txtSegment4_cd = ""
							, txtSegment5_cd = ""
							, txtSegment6_cd = ""
							, txtSegment7_cd = ""
							, txtSegment8_cd = ""
							, txtDefaultBin_cd = ""
							, txtBin_cd = ""
							, txtBin_qty = ""
							, txtBin2_cd = ""
							, txtBin2_qty = ""
							, txtBin3_cd = ""
							, txtBin3_qty = ""
							, txtBin4_cd = ""
							, txtBin4_qty = ""
							, txtBin5_cd = ""
							, txtBin5_qty = ""
							, txtUserDefined1 = ""
							, txtUserDefined2 = ""
							, txtUserDefined3 = ""
							, txtUserDefined4 = ""
							, txtUserDefined5 = ""
							, txtUserDefined1_amt = ""
							, txtUserDefined2_amt = ""
							, txtUserDefined3_amt = ""
							, txtUserDefined4_amt = ""
							, txtUserDefined5_amt = ""
							, txtUserDefined1_dt = ""
							, txtUserDefined2_dt = ""
							, txtUserDefined3_dt = ""
							, txtUserDefined4_dt = ""
							, txtUserDefined5_dt = ""
							, txtUserDefined1_num = ""
							, txtUserDefined2_num = ""
							, txtUserDefined3_num = ""
							, txtUserDefined4_num = ""
							, txtUserDefined5_num = ""

                });;

                Grid.Where(i => i.Row_num >= at_row_num).Select(i => { i.Row_num += 1; return i; }).ToList();
                Grid.Single(i => i.Row_num == -1).Row_num = at_row_num;

				iNextLine_id += 1;
				iTotalRows += 1;

				RecreateDetail();

                return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (InsertNewRow)");
            }

            return return_value;
        }
		public bool DeleteCurrentRow(clsGrid cur_item)
        {
			bool return_value = false;
			int old_num = cur_item.Row_num;

			try
			{
				Grid.RemoveAt(cur_item.Row_num);
				Grid.Where(i => i.Row_num >= old_num).Select(i => { i.Row_num -= 1; return i; }).ToList();

				iTotalRows -= 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
            {
				SetPostingError(ex.Message + " (DeleteCurrentRow)");
			}

			return return_value;
		}

		public bool RecreateDetail()                                                           //  Sync Data with Grid for the items that do not have event-handler ONLY.
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				if (Grid.Count() == 0)
				{
					oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), 0);
					return true;
				}

				// We need to create it here for saving because some fields may not have been copied into the array.
				//
				iTotalRows = Grid.Count();
				oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), iTotalRows - 1);

				foreach (var det in Grid)
				{
					if (RecreateDetailLine(det, row_num) == false)
					{
						return false;
					}

					det.Row_num = row_num;      // Just to make sure.
					row_num++;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetail)");
			}

			return return_value;
		}

		public bool RecreateGridLine(int row_num)
		{
			bool return_value = false;
			clsGrid grid_line = new clsGrid();

			if (FindGridLine(row_num, ref grid_line) == false)
			{
				SetPostingError("Grid does not match array.");
				return false;
			}

			return RecreateGridLine(ref grid_line, row_num);
		}

		public bool RecreateGridLine(ref clsGrid cur_item, int row_num)
        {
			bool return_value = false;

			try
            {
				cur_item.txtItem_cd = Data[ITEM_CODE_COL, row_num];
				cur_item.lblLocation_cd = Data[LOCATION_COL, row_num];
				cur_item.txtManufacturer_cd = Data[ITEM_MANUFACTURER_COL, row_num];
				cur_item.txtBrand_cd = Data[ITEM_BRAND_COL, row_num];
				cur_item.txtModel_cd = Data[ITEM_MODEL_COL, row_num];
				cur_item.txtStyle_cd = Data[ITEM_STYLE_COL, row_num];
				cur_item.txtColor_cd = Data[ITEM_COLOR_COL, row_num];
				cur_item.txtSize_cd = Data[ITEM_SIZE_COL, row_num];
				cur_item.txtDescription = Data[DESCRIPTION_COL, row_num];
				cur_item.txtUnit_cd = Data[UNIT_CODE_COL, row_num];
				cur_item.txtOrdered_qty = Data[QTY_ORDERED_COL, row_num];
				cur_item.txtAllocated_qty = Data[QTY_ALLOCATED_COL, row_num];
				cur_item.txtShipped_qty = Data[QTY_SHIPPED_COL, row_num];
				cur_item.lblBackorder_qty = Data[QTY_BACKORDER_COL, row_num];
				cur_item.txtUnitPrice_amt = Data[UNIT_PRICE_COL, row_num];
				cur_item.lblExtended_amt = Data[AMT_EXTENDED_COL, row_num];
				cur_item.txtDiscount_pc = Data[DISC_PERC_COL, row_num];
				cur_item.cboTax_cd = Data[TAX_CODE_COL, row_num];
				cur_item.mskGLAccount_cd = Data[FULL_ACCT_CODE_COL, row_num];

				cur_item.txtNaturalAcct_cd = Data[NATURAL_ACCT_CODE_COL, row_num];
				cur_item.txtSegment1_cd = Data[SEGMENT1_COL, row_num];
				cur_item.txtSegment2_cd = Data[SEGMENT2_COL, row_num];
				cur_item.txtSegment3_cd = Data[SEGMENT3_COL, row_num];
				cur_item.txtSegment4_cd = Data[SEGMENT4_COL, row_num];
				cur_item.txtSegment5_cd = Data[SEGMENT5_COL, row_num];
				cur_item.txtSegment6_cd = Data[SEGMENT6_COL, row_num];

				cur_item.txtTax_amt = Data[AMT_TAX_COL, row_num];
				cur_item.lblTax_pc = Data[TAX_PERC_COL, row_num];
				cur_item.lblInIVUnit_qty = Data[QTY_IN_IVUNIT_COL, row_num];
				cur_item.lblIVUnit_cd = Data[IVUNIT_CODE_COL, row_num];
				cur_item.lblUnitCost_amt = Data[UNIT_COST_COL, row_num];
				cur_item.lblItem_typ = Data[ITEM_TYPE_COL, row_num];
				cur_item.lblDiscount_amt = Data[AMT_DISC_COL, row_num];
				cur_item.lblConversion_rt = Data[CONVERSION_RATE_COL, row_num];
				cur_item.lblSellUnit_cd = Data[SELL_UNIT_CODE_COL, row_num];
				cur_item.lblSellUnitPrice_amt = Data[SELL_UNIT_PRICE_COL, row_num];
				cur_item.lblLine_id = Data[LINE_ID_COL, row_num];
				cur_item.lblKit_id = Data[KIT_ID_COL, row_num];
				cur_item.lblWeight = Data[WEIGHT_PER_UNIT_COL, row_num];
				cur_item.lblFreight_amt = Data[FREIGHT_PER_UNIT_COL, row_num];
				cur_item.lblReceived_dt = Data[DATE_RECEIVED_COL, row_num];
				cur_item.lblProcess_id = Data[PROCESS_ID_COL, row_num];
				cur_item.lblBackOrdered_dt = Data[DATE_BACKORDERED_COL, row_num];
				cur_item.lblPO_num = Data[PO_NUM_COL, row_num];
				cur_item.cboJob_cd = Data[JOB_CODE_COL, row_num];
				cur_item.lblPrimaryItem_cd = Data[PRIMARY_ITEM_CODE_COL, row_num];
				cur_item.lblExtendedInPrimary_amt = Data[AMT_EXTENDED_IN_PRIMARY_CURRENCY_COL, row_num];
				cur_item.lblTaxInPrimary_amt = Data[AMT_TAX_IN_PRIMARY_CURRENCY_COL, row_num];
				cur_item.txtUnitPriceInPrimary_amt = Data[UNIT_PRICE_IN_PRIMARY_CURRENCY_COL, row_num];
				cur_item.lblDiscountInPrimary_amt = Data[AMT_DISC_IN_PRIMARY_CURRENCY_COL, row_num];
				cur_item.txtEntity_cd = Data[ENTITY_CODE_COL, row_num];
				cur_item.txtSerial_cd = Data[SERIAL_CODE_COL, row_num];
				cur_item.lblLastPrice_amt = Data[LAST_PRICE_COL, row_num];

				cur_item.lblTotalCost_amt = Data[TOTAL_COST_COL, row_num];
				cur_item.lblExpense_typ = Data[EXPENSE_TYPE_COL, row_num];
				cur_item.lblExpense_num = Data[EXPENSE_NUM_COL, row_num];
				cur_item.lblExpenseDetail_num = Data[EXPENSE_DETAIL_COL, row_num];
				cur_item.lblOrder_num = Data[ORDER_NUM_COL, row_num];
				cur_item.lblLine_typ = Data[LINE_TYPE_COL, row_num];
				cur_item.lblInvoiced_qty = Data[QTY_INVOICED_COL, row_num];
				cur_item.lblPreviousReturned_qty = Data[QTY_PREV_RETURN_COL, row_num];
				cur_item.lblCurrentReturned_qty = Data[QTY_CUR_RETURNED_COL, row_num];
				cur_item.lblReimbursedInvoice_num = Data[REIMBURSED_INVOICE_NUM_COL, row_num];
				cur_item.lblSource_typ = Data[SOURCE_TYPE_COL, row_num];
				cur_item.lblSource_num = Data[SOURCE_NUM_COL, row_num];
				cur_item.lblSourceDetail_num = Data[SOURCE_DETAIL_ID_COL, row_num];
				cur_item.chkInclude_fl = (GlobalVar.goUtility.ToInteger(Data[INCLUDE_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON);
				cur_item.txtBox_cd = Data[BOX_CODE_COL, row_num];
				cur_item.txtVendorItem_cd = Data[VENDOR_ITEM_CODE_COL, row_num];
				cur_item.lblAvailable_qty = Data[QTY_AVAILABLE_COL, row_num];
				cur_item.lblOnHand_qty = Data[QTY_ON_HAND_COL, row_num];
				cur_item.lblOnOrder_qty = Data[QTY_ON_ORDER_COL, row_num];

				cur_item.txtAsset_cd = Data[ASSET_CODE_COL, row_num];
				cur_item.txtService_cd = Data[SERVICE_CODE_COL, row_num];
				cur_item.txtEstimated_dt = Data[DATE_ESTIMATED_COL, row_num];
				cur_item.txtStarted_dt = Data[DATE_STARTED_COL, row_num];
				cur_item.txtFinished_dt = Data[DATE_FINISHED_COL, row_num];
                cur_item.txtRequired_dt = Data[DATE_REQUIRED_COL, row_num];
                cur_item.dtEstimated_dt = (oUtility.IsNonEmpty(Data[DATE_ESTIMATED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_ESTIMATED_COL, row_num]) : null);
                cur_item.dtStarted_dt = (oUtility.IsNonEmpty(Data[DATE_STARTED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_STARTED_COL, row_num]) : null);
                cur_item.dtFinished_dt = (oUtility.IsNonEmpty(Data[DATE_FINISHED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_FINISHED_COL, row_num]) : null);
                cur_item.dtRequired_dt = (oUtility.IsNonEmpty(Data[DATE_REQUIRED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_REQUIRED_COL, row_num]) : null);

                cur_item.txtInProduction_qty = Data[QTY_IN_PRODUCTION_COL, row_num];
				cur_item.txtInvoice_num = Data[INVOICE_NUM_COL, row_num];
				cur_item.txtCommission_amt = Data[COMMISSION_AMT_COL, row_num];
				cur_item.txtCost_amt = Data[COST_AMT_COL, row_num];
				cur_item.txtStartTime = Data[START_TIME_COL, row_num];
				cur_item.txtEndTime = Data[END_TIME_COL, row_num];

                cur_item.txtDefaultBin_cd = Data[DEFAULT_BIN_COL, row_num];
				cur_item.txtBin_cd = Data[BIN_COL, row_num];
				cur_item.txtBin_qty = Data[BIN_QTY_COL, row_num];
				cur_item.txtBin2_cd = Data[BIN2_COL, row_num];
				cur_item.txtBin2_qty = Data[BIN2_QTY_COL, row_num];
				cur_item.txtBin3_cd = Data[BIN3_COL, row_num];
				cur_item.txtBin3_qty = Data[BIN3_QTY_COL, row_num];
				cur_item.txtBin4_cd = Data[BIN4_COL, row_num];
				cur_item.txtBin4_qty = Data[BIN4_QTY_COL, row_num];
				cur_item.txtBin5_cd = Data[BIN5_COL, row_num];
				cur_item.txtBin5_qty = Data[BIN5_QTY_COL, row_num];

				cur_item.txtUserDefined1 = Data[USER_DEFINED1_COL, row_num];
				cur_item.txtUserDefined2 = Data[USER_DEFINED2_COL, row_num];
				cur_item.txtUserDefined3 = Data[USER_DEFINED3_COL, row_num];
				cur_item.txtUserDefined4 = Data[USER_DEFINED4_COL, row_num];
				cur_item.txtUserDefined5 = Data[USER_DEFINED5_COL, row_num];
				cur_item.txtUserDefined1_amt = Data[USER_DEFINED1_AMT_COL, row_num];
				cur_item.txtUserDefined2_amt = Data[USER_DEFINED2_AMT_COL, row_num];
				cur_item.txtUserDefined3_amt = Data[USER_DEFINED3_AMT_COL, row_num];
				cur_item.txtUserDefined4_amt = Data[USER_DEFINED4_AMT_COL, row_num];
				cur_item.txtUserDefined5_amt = Data[USER_DEFINED5_AMT_COL, row_num];
				cur_item.txtUserDefined1_dt = Data[USER_DEFINED1_DT_COL, row_num];
				cur_item.txtUserDefined2_dt = Data[USER_DEFINED2_DT_COL, row_num];
				cur_item.txtUserDefined3_dt = Data[USER_DEFINED3_DT_COL, row_num];
				cur_item.txtUserDefined4_dt = Data[USER_DEFINED4_DT_COL, row_num];
				cur_item.txtUserDefined5_dt = Data[USER_DEFINED5_DT_COL, row_num];
				cur_item.txtUserDefined1_num = Data[USER_DEFINED1_NUM_COL, row_num];
				cur_item.txtUserDefined2_num = Data[USER_DEFINED2_NUM_COL, row_num];
				cur_item.txtUserDefined3_num = Data[USER_DEFINED3_NUM_COL, row_num];
				cur_item.txtUserDefined4_num = Data[USER_DEFINED4_NUM_COL, row_num];
				cur_item.txtUserDefined5_num = Data[USER_DEFINED5_NUM_COL, row_num];
			}
			catch (Exception ex)
            {
				SetPostingError(ex.Message + " (RecreateGridLine)");
			}
			return return_value;

		}

		public bool FindGridLine(int row_num, ref clsGrid line_found)
		{
			bool return_value = false;

			try
            {
				line_found = Grid.Single(i => i.Row_num == row_num);

				if (line_found != null)
                {
					return_value = true;
				}
			}
			catch (Exception ex)
            {
				// in case not found
            }

			return return_value;
		}

		public bool RecreateDetailLine(clsGrid cur_item, int row_num = -1)
        {
            bool return_value = false;

            try
            {
				// If this is called from UI event, get the row number of current line.
				//
                if (row_num < 0)
                {
                    row_num = cur_item.Row_num;
                }

				if (oUtility.ToInteger(cur_item.lblLine_id) == 0)
                {
					if (oUtility.ToInteger(Data[LINE_ID_COL, row_num]) > 0)
                    {
						cur_item.lblLine_id = Data[LINE_ID_COL, row_num];
					}
					else
                    {
						cur_item.lblLine_id = iNextLine_id.ToString();
						iNextLine_id += 1;
					}
				}

				Data[ITEM_CODE_COL, row_num] = cur_item.txtItem_cd;
				Data[LOCATION_COL, row_num] = cur_item.lblLocation_cd;
				Data[ITEM_MANUFACTURER_COL, row_num] = cur_item.txtManufacturer_cd;
				Data[ITEM_BRAND_COL, row_num] = cur_item.txtBrand_cd;
				Data[ITEM_MODEL_COL, row_num] = cur_item.txtModel_cd;
				Data[ITEM_STYLE_COL, row_num] = cur_item.txtStyle_cd;
				Data[ITEM_COLOR_COL, row_num] = cur_item.txtColor_cd;
				Data[ITEM_SIZE_COL, row_num] = cur_item.txtSize_cd;
				Data[DESCRIPTION_COL, row_num] = cur_item.txtDescription;
				Data[UNIT_CODE_COL, row_num] = cur_item.txtUnit_cd;
				Data[QTY_ORDERED_COL, row_num] = cur_item.txtOrdered_qty;
				Data[QTY_ALLOCATED_COL, row_num] = cur_item.txtAllocated_qty;
				Data[QTY_SHIPPED_COL, row_num] = cur_item.txtShipped_qty;
				Data[QTY_BACKORDER_COL, row_num] = cur_item.lblBackorder_qty;
				Data[UNIT_PRICE_COL, row_num] = cur_item.txtUnitPrice_amt;
				Data[AMT_EXTENDED_COL, row_num] = cur_item.lblExtended_amt;
				Data[DISC_PERC_COL, row_num] = cur_item.txtDiscount_pc;
				Data[TAX_CODE_COL, row_num] = cur_item.cboTax_cd;
				Data[FULL_ACCT_CODE_COL, row_num] = cur_item.mskGLAccount_cd;

				Data[NATURAL_ACCT_CODE_COL, row_num] = cur_item.txtNaturalAcct_cd;
				Data[SEGMENT1_COL, row_num] = cur_item.txtSegment1_cd;
				Data[SEGMENT2_COL, row_num] = cur_item.txtSegment2_cd;
				Data[SEGMENT3_COL, row_num] = cur_item.txtSegment3_cd;
				Data[SEGMENT4_COL, row_num] = cur_item.txtSegment4_cd;
				Data[SEGMENT5_COL, row_num] = cur_item.txtSegment5_cd;
				Data[SEGMENT6_COL, row_num] = cur_item.txtSegment6_cd;

				Data[AMT_TAX_COL, row_num] = cur_item.txtTax_amt;
				Data[TAX_PERC_COL, row_num] = cur_item.lblTax_pc;
				Data[QTY_IN_IVUNIT_COL, row_num] = cur_item.lblInIVUnit_qty;
				Data[IVUNIT_CODE_COL, row_num] = cur_item.lblIVUnit_cd;
				Data[UNIT_COST_COL, row_num] = cur_item.lblUnitCost_amt;
				Data[ITEM_TYPE_COL, row_num] = cur_item.lblItem_typ;
				Data[AMT_DISC_COL, row_num] = cur_item.lblDiscount_amt;
				Data[CONVERSION_RATE_COL, row_num] = cur_item.lblConversion_rt;
				Data[SELL_UNIT_CODE_COL, row_num] = cur_item.lblSellUnit_cd;
				Data[SELL_UNIT_PRICE_COL, row_num] = cur_item.lblSellUnitPrice_amt;
				Data[LINE_ID_COL, row_num] = cur_item.lblLine_id;
				Data[KIT_ID_COL, row_num] = cur_item.lblKit_id;
				Data[WEIGHT_PER_UNIT_COL, row_num] = cur_item.lblWeight;
				Data[FREIGHT_PER_UNIT_COL, row_num] = cur_item.lblFreight_amt;
				Data[DATE_RECEIVED_COL, row_num] = cur_item.lblReceived_dt;
				Data[PROCESS_ID_COL, row_num] = cur_item.lblProcess_id;
				Data[DATE_BACKORDERED_COL, row_num] = cur_item.lblBackOrdered_dt;
				Data[PO_NUM_COL, row_num] = cur_item.lblPO_num;
				Data[JOB_CODE_COL, row_num] = cur_item.cboJob_cd;
				Data[PRIMARY_ITEM_CODE_COL, row_num] = cur_item.lblPrimaryItem_cd;
				Data[AMT_EXTENDED_IN_PRIMARY_CURRENCY_COL, row_num] = cur_item.lblExtendedInPrimary_amt;
				Data[AMT_TAX_IN_PRIMARY_CURRENCY_COL, row_num] = cur_item.lblTaxInPrimary_amt;
				Data[UNIT_PRICE_IN_PRIMARY_CURRENCY_COL, row_num] = cur_item.txtUnitPriceInPrimary_amt;
				Data[AMT_DISC_IN_PRIMARY_CURRENCY_COL, row_num] = cur_item.lblDiscountInPrimary_amt;
				Data[ENTITY_CODE_COL, row_num] = cur_item.txtEntity_cd;
				Data[SERIAL_CODE_COL, row_num] = cur_item.txtSerial_cd;
				Data[LAST_PRICE_COL, row_num] = cur_item.lblLastPrice_amt;

				Data[TOTAL_COST_COL, row_num] = cur_item.lblTotalCost_amt;
				Data[EXPENSE_TYPE_COL, row_num] = cur_item.lblExpense_typ;
				Data[EXPENSE_NUM_COL, row_num] = cur_item.lblExpense_num;
				Data[EXPENSE_DETAIL_COL, row_num] = cur_item.lblExpenseDetail_num;
				Data[ORDER_NUM_COL, row_num] = cur_item.lblOrder_num;
				Data[LINE_TYPE_COL, row_num] = cur_item.lblLine_typ;

				Data[QTY_INVOICED_COL, row_num] = cur_item.lblInvoiced_qty;
				Data[QTY_PREV_RETURN_COL, row_num] = cur_item.lblPreviousReturned_qty;
				Data[QTY_CUR_RETURNED_COL, row_num] = cur_item.lblCurrentReturned_qty;
				Data[REIMBURSED_INVOICE_NUM_COL, row_num] = cur_item.lblReimbursedInvoice_num;

				Data[SOURCE_TYPE_COL, row_num] = cur_item.lblSource_typ;
				Data[SOURCE_NUM_COL, row_num] = cur_item.lblSource_num;
				Data[SOURCE_DETAIL_ID_COL, row_num] = cur_item.lblSourceDetail_num;

				Data[INCLUDE_COL, row_num] = GlobalVar.goUtility.IIf(cur_item.chkInclude_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
				Data[BOX_CODE_COL, row_num] = cur_item.txtBox_cd;
				Data[VENDOR_ITEM_CODE_COL, row_num] = cur_item.txtVendorItem_cd;

				Data[QTY_AVAILABLE_COL, row_num] = cur_item.lblAvailable_qty;
				Data[QTY_ON_HAND_COL, row_num] = cur_item.lblOnHand_qty;
				Data[QTY_ON_ORDER_COL, row_num] = cur_item.lblOnOrder_qty;

				Data[ASSET_CODE_COL, row_num] = cur_item.txtAsset_cd;
				Data[SERVICE_CODE_COL, row_num] = cur_item.txtService_cd;

                Data[DATE_STARTED_COL, row_num] = cur_item.txtStarted_dt;
                Data[DATE_ESTIMATED_COL, row_num] = cur_item.txtEstimated_dt;
                Data[DATE_FINISHED_COL, row_num] = cur_item.txtFinished_dt;
                Data[DATE_REQUIRED_COL, row_num] = cur_item.txtRequired_dt;

                Data[QTY_IN_PRODUCTION_COL, row_num] = cur_item.txtInProduction_qty;
				Data[INVOICE_NUM_COL, row_num] = cur_item.txtInvoice_num;
				Data[COMMISSION_AMT_COL, row_num] = cur_item.txtCommission_amt;
				Data[COST_AMT_COL, row_num] = cur_item.txtCost_amt;
				Data[START_TIME_COL, row_num] = cur_item.txtStartTime;
				Data[END_TIME_COL, row_num] = cur_item.txtEndTime;

                Data[DEFAULT_BIN_COL, row_num] = cur_item.txtDefaultBin_cd;
				Data[BIN_COL, row_num] = cur_item.txtBin_cd;
				Data[BIN_QTY_COL, row_num] = cur_item.txtBin_qty;
				Data[BIN2_COL, row_num] = cur_item.txtBin2_cd;
				Data[BIN2_QTY_COL, row_num] = cur_item.txtBin2_qty;
				Data[BIN3_COL, row_num] = cur_item.txtBin3_cd;
				Data[BIN3_QTY_COL, row_num] = cur_item.txtBin3_qty;
				Data[BIN4_COL, row_num] = cur_item.txtBin4_cd;
				Data[BIN4_QTY_COL, row_num] = cur_item.txtBin4_qty;
				Data[BIN5_COL, row_num] = cur_item.txtBin5_cd;
				Data[BIN5_QTY_COL, row_num] = cur_item.txtBin5_qty;

				Data[USER_DEFINED1_COL, row_num] = cur_item.txtUserDefined1;
				Data[USER_DEFINED2_COL, row_num] = cur_item.txtUserDefined2;
				Data[USER_DEFINED3_COL, row_num] = cur_item.txtUserDefined3;
				Data[USER_DEFINED4_COL, row_num] = cur_item.txtUserDefined4;
				Data[USER_DEFINED5_COL, row_num] = cur_item.txtUserDefined5;
				Data[USER_DEFINED1_AMT_COL, row_num] = cur_item.txtUserDefined1_amt;
				Data[USER_DEFINED2_AMT_COL, row_num] = cur_item.txtUserDefined2_amt;
				Data[USER_DEFINED3_AMT_COL, row_num] = cur_item.txtUserDefined3_amt;
				Data[USER_DEFINED4_AMT_COL, row_num] = cur_item.txtUserDefined4_amt;
				Data[USER_DEFINED5_AMT_COL, row_num] = cur_item.txtUserDefined5_amt;
				Data[USER_DEFINED1_DT_COL, row_num] = cur_item.txtUserDefined1_dt;
				Data[USER_DEFINED2_DT_COL, row_num] = cur_item.txtUserDefined2_dt;
				Data[USER_DEFINED3_DT_COL, row_num] = cur_item.txtUserDefined3_dt;
				Data[USER_DEFINED4_DT_COL, row_num] = cur_item.txtUserDefined4_dt;
				Data[USER_DEFINED5_DT_COL, row_num] = cur_item.txtUserDefined5_dt;
				Data[USER_DEFINED1_NUM_COL, row_num] = cur_item.txtUserDefined1_num;
				Data[USER_DEFINED2_NUM_COL, row_num] = cur_item.txtUserDefined2_num;
				Data[USER_DEFINED3_NUM_COL, row_num] = cur_item.txtUserDefined3_num;
				Data[USER_DEFINED4_NUM_COL, row_num] = cur_item.txtUserDefined4_num;
				Data[USER_DEFINED5_NUM_COL, row_num] = cur_item.txtUserDefined5_num;

				return_value = true;

            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (RecreateDetailLine)");
            }

            return return_value;
        }

        public bool RecreateGrid()                                                             //  Create Grid according to Data
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
				Grid.Clear();

				if (Data == null)
                {
                    return true;
                }
                else if (Data.GetLength(1) == 0)
                {
                    return true;
                }

                iTotalRows = Data.GetLength(1);

                for (row_num = 0; row_num < iTotalRows; row_num++)
                {
					if (oUtility.ToInteger(Data[LINE_ID_COL, row_num]) == 0)
                    {
						Data[LINE_ID_COL, row_num] = iNextLine_id.ToString();
						iNextLine_id += 1;
					}

                    Grid.Add(new clsGrid { Row_num = row_num
								, txtItem_cd = Data[ITEM_CODE_COL, row_num] 
								, lblLocation_cd = Data[LOCATION_COL, row_num] 
								, txtManufacturer_cd = Data[ITEM_MANUFACTURER_COL, row_num] 
								, txtBrand_cd = Data[ITEM_BRAND_COL, row_num] 
								, txtModel_cd = Data[ITEM_MODEL_COL, row_num] 
								, txtStyle_cd = Data[ITEM_STYLE_COL, row_num] 
								, txtColor_cd = Data[ITEM_COLOR_COL, row_num] 
								, txtSize_cd = Data[ITEM_SIZE_COL, row_num] 
								, txtDescription = Data[DESCRIPTION_COL, row_num] 
								, txtUnit_cd = Data[UNIT_CODE_COL, row_num] 
								, txtOrdered_qty = Data[QTY_ORDERED_COL, row_num] 
								, txtAllocated_qty = Data[QTY_ALLOCATED_COL, row_num] 
								, txtShipped_qty = Data[QTY_SHIPPED_COL, row_num] 
								, lblBackorder_qty = Data[QTY_BACKORDER_COL, row_num] 
								, txtUnitPrice_amt = Data[UNIT_PRICE_COL, row_num] 
								, lblExtended_amt = Data[AMT_EXTENDED_COL, row_num] 
								, txtDiscount_pc = Data[DISC_PERC_COL, row_num] 
								, cboTax_cd = Data[TAX_CODE_COL, row_num] 
								, mskGLAccount_cd = Data[FULL_ACCT_CODE_COL, row_num] 

								, txtNaturalAcct_cd = Data[NATURAL_ACCT_CODE_COL, row_num] 
								, txtSegment1_cd = Data[SEGMENT1_COL, row_num] 
								, txtSegment2_cd = Data[SEGMENT2_COL, row_num] 
								, txtSegment3_cd = Data[SEGMENT3_COL, row_num] 
								, txtSegment4_cd = Data[SEGMENT4_COL, row_num] 
								, txtSegment5_cd = Data[SEGMENT5_COL, row_num] 
								, txtSegment6_cd = Data[SEGMENT6_COL, row_num] 

								, txtTax_amt = Data[AMT_TAX_COL, row_num] 
								, lblTax_pc = Data[TAX_PERC_COL, row_num] 
								, lblInIVUnit_qty = Data[QTY_IN_IVUNIT_COL, row_num] 
								, lblIVUnit_cd = Data[IVUNIT_CODE_COL, row_num] 
								, lblItem_typ = Data[ITEM_TYPE_COL, row_num] 
								, lblDiscount_amt = Data[AMT_DISC_COL, row_num] 
								, lblConversion_rt = Data[CONVERSION_RATE_COL, row_num] 
								, lblSellUnit_cd = Data[SELL_UNIT_CODE_COL, row_num] 
								, lblSellUnitPrice_amt = Data[SELL_UNIT_PRICE_COL, row_num] 
								, lblLine_id = Data[LINE_ID_COL, row_num] 
								, lblKit_id = Data[KIT_ID_COL, row_num] 
								, lblWeight = Data[WEIGHT_PER_UNIT_COL, row_num] 
								, lblFreight_amt = Data[FREIGHT_PER_UNIT_COL, row_num] 
								, lblReceived_dt = Data[DATE_RECEIVED_COL, row_num] 
								, lblProcess_id = Data[PROCESS_ID_COL, row_num] 
								, lblBackOrdered_dt = Data[DATE_BACKORDERED_COL, row_num] 
								, lblPO_num = Data[PO_NUM_COL, row_num] 
								, cboJob_cd = Data[JOB_CODE_COL, row_num] 
								, lblPrimaryItem_cd = Data[PRIMARY_ITEM_CODE_COL, row_num] 
								, lblExtendedInPrimary_amt = Data[AMT_EXTENDED_IN_PRIMARY_CURRENCY_COL, row_num] 
								, lblTaxInPrimary_amt = Data[AMT_TAX_IN_PRIMARY_CURRENCY_COL, row_num] 
								, txtUnitPriceInPrimary_amt = Data[UNIT_PRICE_IN_PRIMARY_CURRENCY_COL, row_num] 
								, lblDiscountInPrimary_amt = Data[AMT_DISC_IN_PRIMARY_CURRENCY_COL, row_num] 
								, txtEntity_cd = Data[ENTITY_CODE_COL, row_num]
								, txtSerial_cd = Data[SERIAL_CODE_COL, row_num]
								, lblLastPrice_amt = Data[LAST_PRICE_COL, row_num]

								, lblUnitCost_amt = Data[UNIT_COST_COL, row_num] 
								, lblTotalCost_amt = Data[TOTAL_COST_COL, row_num]
								, lblExpense_typ = Data[EXPENSE_TYPE_COL, row_num] 
								, lblExpense_num = Data[EXPENSE_NUM_COL, row_num] 
								, lblExpenseDetail_num = Data[EXPENSE_DETAIL_COL, row_num] 
								, lblOrder_num = Data[ORDER_NUM_COL, row_num] 
								, lblLine_typ = Data[LINE_TYPE_COL, row_num]
								, lblInvoiced_qty = Data[QTY_INVOICED_COL, row_num] 
								, lblPreviousReturned_qty = Data[QTY_PREV_RETURN_COL, row_num]
								, lblCurrentReturned_qty = Data[QTY_CUR_RETURNED_COL, row_num]
								, lblReimbursedInvoice_num = Data[REIMBURSED_INVOICE_NUM_COL, row_num]
								, lblSource_typ = Data[SOURCE_TYPE_COL, row_num]
								, lblSource_num = Data[SOURCE_NUM_COL, row_num]
								, lblSourceDetail_num = Data[SOURCE_DETAIL_ID_COL, row_num]

								, chkInclude_fl = (GlobalVar.goUtility.ToInteger(Data[INCLUDE_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON)
								, txtBox_cd = Data[BOX_CODE_COL, row_num]
								, txtVendorItem_cd = Data[VENDOR_ITEM_CODE_COL, row_num]

								, lblAvailable_qty = Data[QTY_AVAILABLE_COL, row_num]
								, lblOnHand_qty = Data[QTY_ON_HAND_COL, row_num]
								, lblOnOrder_qty = Data[QTY_ON_ORDER_COL, row_num]

								,txtAsset_cd = Data[ASSET_CODE_COL , row_num]                        
								,txtService_cd = Data[SERVICE_CODE_COL , row_num]

								,txtStarted_dt = Data[DATE_STARTED_COL , row_num]
								,txtEstimated_dt = Data[DATE_ESTIMATED_COL , row_num]
								,txtFinished_dt = Data[DATE_FINISHED_COL , row_num]
								,txtRequired_dt = Data[DATE_REQUIRED_COL , row_num]
								, dtStarted_dt = (oUtility.IsNonEmpty(Data[DATE_STARTED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_STARTED_COL, row_num]) : null)
								, dtEstimated_dt = (oUtility.IsNonEmpty(Data[DATE_ESTIMATED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_ESTIMATED_COL, row_num]) : null)
								, dtFinished_dt = (oUtility.IsNonEmpty(Data[DATE_FINISHED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_FINISHED_COL, row_num]) : null)
								, dtRequired_dt = (oUtility.IsNonEmpty(Data[DATE_REQUIRED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_REQUIRED_COL, row_num]) : null)

								,txtInProduction_qty = Data[QTY_IN_PRODUCTION_COL , row_num]
								,txtInvoice_num = Data[INVOICE_NUM_COL , row_num]
								,txtCommission_amt = Data[COMMISSION_AMT_COL , row_num]
								,txtCost_amt = Data[COST_AMT_COL , row_num]

								,txtStartTime = Data[START_TIME_COL , row_num]
								,txtEndTime = Data[END_TIME_COL , row_num]
								,dtStartTime = TimeOnly.Parse((Data[START_TIME_COL , row_num] == ""? "12:00 AM" : Data[START_TIME_COL, row_num]), System.Globalization.CultureInfo.CurrentCulture)
								,dtEndTime = TimeOnly.Parse((Data[END_TIME_COL, row_num] == ""? "12:00 AM" : Data[END_TIME_COL, row_num]), System.Globalization.CultureInfo.CurrentCulture)

                                , txtDefaultBin_cd = Data[DEFAULT_BIN_COL, row_num]
								, txtBin_cd = Data[BIN_COL, row_num]
								, txtBin_qty = Data[BIN_QTY_COL, row_num]
								, txtBin2_cd = Data[BIN2_COL, row_num]
								, txtBin2_qty = Data[BIN2_QTY_COL, row_num]
								, txtBin3_cd = Data[BIN3_COL, row_num]
								, txtBin3_qty = Data[BIN3_QTY_COL, row_num]
								, txtBin4_cd = Data[BIN4_COL, row_num]
								, txtBin4_qty = Data[BIN4_QTY_COL, row_num]
								, txtBin5_cd = Data[BIN5_COL, row_num]
								, txtBin5_qty = Data[BIN5_QTY_COL, row_num]

								, txtUserDefined1 = Data[USER_DEFINED1_COL, row_num]
								, txtUserDefined2 = Data[USER_DEFINED2_COL, row_num]
								, txtUserDefined3 = Data[USER_DEFINED3_COL, row_num]
								, txtUserDefined4 = Data[USER_DEFINED4_COL, row_num]
								, txtUserDefined5 = Data[USER_DEFINED5_COL, row_num]
								, txtUserDefined1_amt = Data[USER_DEFINED1_AMT_COL, row_num]
								, txtUserDefined2_amt = Data[USER_DEFINED2_AMT_COL, row_num]
								, txtUserDefined3_amt = Data[USER_DEFINED3_AMT_COL, row_num]
								, txtUserDefined4_amt = Data[USER_DEFINED4_AMT_COL, row_num]
								, txtUserDefined5_amt = Data[USER_DEFINED5_AMT_COL, row_num]
								, txtUserDefined1_dt = Data[USER_DEFINED1_DT_COL, row_num]
								, txtUserDefined2_dt = Data[USER_DEFINED2_DT_COL, row_num]
								, txtUserDefined3_dt = Data[USER_DEFINED3_DT_COL, row_num]
								, txtUserDefined4_dt = Data[USER_DEFINED4_DT_COL, row_num]
								, txtUserDefined5_dt = Data[USER_DEFINED5_DT_COL, row_num]
								, txtUserDefined1_num = Data[USER_DEFINED1_NUM_COL, row_num]
								, txtUserDefined2_num = Data[USER_DEFINED2_NUM_COL, row_num]
								, txtUserDefined3_num = Data[USER_DEFINED3_NUM_COL, row_num]
								, txtUserDefined4_num = Data[USER_DEFINED4_NUM_COL, row_num]
								, txtUserDefined5_num = Data[USER_DEFINED5_NUM_COL, row_num]
                    });
                }

				return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (RecreateGrid)");
            }

            return return_value;
        }

		public bool ProcessItemCode(ref clsDatabase cur_db, ref clsGrid grid_item,  string entity_code, string location_cd, string tax_cd, string job_cd, decimal tax_pc, decimal price_exchange_rt, decimal sale_exchange_rt, ref decimal sell_unit_price)
		{
			bool return_value = false;
			bool found_by_serial_num_fl = false;
			string bin_code = "";
			string unit_code = "";
			string tmp = "";
			decimal qty_available = 0;
			decimal qty_on_hand = 0;
			decimal qty_on_order = 0;
			decimal conversion_rate = 0;
			decimal unit_price = 0;

			string serial_num = "";
			int item_type = 0;
			int kit_type = 0;

			clsValidate o_val = new clsValidate(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);
			clsCustomer o_customer = new clsCustomer(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);
			clsSerial o_serial = new clsSerial(ref cur_db);

			try
			{
				if (oUtility.IsEmpty(grid_item.txtItem_cd))
				{
                    ClearCurrentLine(grid_item.Row_num);
					return true;
				}
				if (oUtility.IsEmpty(location_cd))
				{
					modDialogUtility.DisplayBox(ref cur_db,  cur_db.oLanguage.oMessage.ENTER_LOCATION_CODE_FIRST);
					return false;
				}
				if (o_val.IsValidItemAnyCode(grid_item.txtItem_cd, location_cd, ref found_by_serial_num_fl) == false)
				{
					modDialogUtility.DisplayBox(ref cur_db,  grid_item.txtItem_cd + cur_db.oLanguage.oMessage.DOES_NOT_EXIST);
					return false;
				}
				else
				{
					if (found_by_serial_num_fl) // A serial number is entered. Then, collect the serial number.
					{
						serial_num = o_val.oRecordset.sField("sSerial_num");
					}
					grid_item.txtItem_cd = o_val.oRecordset.sField("sItem_cd"); // This is necessary because the item could have been found by other codes such as SKU, UPC & serial number.
				}

				// If this is a consignment item, the vendor code should match the vendor code in the item master.
				//
				if ((o_val.oRecordset.iField("iConsignment_typ") > 0) && IsPurchaseTransaction())
                {
					if (oUtility.IsNonEmpty(entity_code) && o_val.oRecordset.sField("sPreferredVendor_cd") != entity_code)
                    {
						modDialogUtility.DisplayBox(ref cur_db, grid_item.txtItem_cd + cur_db.oLanguage.oMessage.IS_NOT_CONSIGNED_BY_THIS_VENDOR);
						return false;
					}
                }

				item_type = o_val.oRecordset.iField("iItem_typ");
				kit_type = o_val.oRecordset.iField("iKit_typ");

				if (item_type >= GlobalVar.goIVConstant.SUMMARY_SALES_ITEM_TYPES)
				{
					modDialogUtility.DisplayBox(ref cur_db,  cur_db.oLanguage.oMessage.SUMMARY_ITEM_IS_NOT_ALLOWED);
					return false;
				}

				if (kit_type > 0 && IsPurchaseTransaction())
                {
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.IS_NOT_ALLOWED_FOR_PURCHASE);
					return false;
				}

				if (oUtility.IsInventoryItemType(item_type) == false)
				{
					grid_item.lblUnitCost_amt = o_val.oRecordset.mField("mStdCost_amt").ToString();
				}
				else
                {
					if (found_by_serial_num_fl && oUtility.IsNonEmpty(grid_item.txtSerial_cd) && o_serial.IsSerialOrLotItem(item_type))
                    {
						if (o_val.IsValidSerialCode(grid_item.txtItem_cd, grid_item.txtSerial_cd, location_cd) == false)
						{
							modDialogUtility.DisplayBox(ref cur_db, grid_item.txtItem_cd + "/" + grid_item.txtSerial_cd + cur_db.oLanguage.oMessage.IS_INVALID);
							return false;
						}
						qty_available = o_val.oRecordset.mField("fAvailable_qty");
						qty_on_hand = o_val.oRecordset.mField("fOnHand_qty");
						qty_on_order = 0;
					}
					else if (o_gen.IsValidIVQtyCode(grid_item.txtItem_cd, location_cd, iTransaction_typ, ref bin_code, ref qty_available, ref qty_on_hand, ref qty_on_order) == false)
					{
						modDialogUtility.DisplayBox(ref cur_db, grid_item.txtItem_cd + " & " + location_cd + cur_db.oLanguage.oMessage.IS_INVALID_FOR_THIS_TRX);
						return false;
					}

					grid_item.lblAvailable_qty = oUtility.SFormat(qty_available, "#,###");
					grid_item.lblOnOrder_qty = oUtility.SFormat(qty_on_order, "#,###");
					grid_item.lblOnHand_qty = oUtility.SFormat(qty_on_hand, "#,###");

					if (GlobalVar.goIVConstant.AVG_COST_NUM == cur_db.iInventoryCost_typ)
					{
						grid_item.lblUnitCost_amt = o_val.oRecordset.mField("mAvgCost_amt").ToString();
					}
					else
					{
						grid_item.lblUnitCost_amt = o_val.oRecordset.mField("mLastCost_amt").ToString();
					}
				}

				if (item_type == GlobalVar.goIVConstant.DESCRIPTION_ITEM_NUM)
                {
					grid_item.txtItem_cd = "";
				}

				// ********************************************************
				// When item_code changes, reset the qty's and item info.
				// Do unconditionally to make the job easier.
				// Unit-price will be calculated in CalculateCurrentRow().
				// ********************************************************

				grid_item.txtOrdered_qty = "";
				grid_item.txtShipped_qty = "";
				grid_item.lblBackorder_qty = "";
				grid_item.lblInIVUnit_qty = "";
				grid_item.lblLocation_cd = location_cd;
				grid_item.txtSerial_cd = serial_num;

				// 08/20/2021
				grid_item.txtDiscount_pc = "";
				grid_item.lblDiscount_amt = "";
				grid_item.lblDiscountInPrimary_amt = "";

				sell_unit_price = o_val.oRecordset.mField("mSellUnitPrice_amt");

				grid_item.lblIVUnit_cd = o_val.oRecordset.sField("sIVUnit_cd");
				grid_item.lblItem_typ = o_val.oRecordset.iField("iItem_typ").ToString();
				grid_item.lblWeight = o_val.oRecordset.mField("fWeight").ToString();
				grid_item.lblFreight_amt = o_val.oRecordset.mField("mFreight_amt").ToString();

				grid_item.lblPrimaryItem_cd = o_val.oRecordset.sField("sPrimary_cd");
				grid_item.txtDescription = o_val.oRecordset.sField("sDescription");
				grid_item.lblSellUnit_cd = o_val.oRecordset.sField("sSellUnit_cd");
				grid_item.lblSellUnitPrice_amt = o_money.ToStrMoney(o_val.oRecordset.mField("mSellUnitPrice_amt"));

				if (IsSalesTransaction())
				{
					grid_item.txtUnit_cd = o_val.oRecordset.sField("sSellUnit_cd");
					grid_item.txtUnitPrice_amt = o_money.ToStrMoney(o_val.oRecordset.mField("mSellUnitPrice_amt"));
				}
				else if (IsPurchaseTransaction())
				{
					grid_item.txtUnit_cd = o_val.oRecordset.sField("sPurchaseUnit_cd");
					grid_item.txtUnitPrice_amt = "";
				}
				else
                {
					grid_item.txtUnit_cd = o_val.oRecordset.sField("sIVUnit_cd");
					grid_item.txtUnitPrice_amt = "";
				}

				grid_item.txtManufacturer_cd = o_val.oRecordset.sField("sManufacturer_cd");
				grid_item.txtBrand_cd = o_val.oRecordset.sField("sBrand_cd");
				grid_item.txtStyle_cd = o_val.oRecordset.sField("sStyle_cd");
				grid_item.txtModel_cd = o_val.oRecordset.sField("sModel_cd");
				grid_item.txtColor_cd = o_val.oRecordset.sField("sColor_cd");
				grid_item.txtSize_cd = o_val.oRecordset.sField("sSize_cd");

				if (cur_db.uProgram.bJCExist_fl)
                {
					grid_item.cboJob_cd = job_cd;
                }

				grid_item.lblExtended_amt = "";
				grid_item.lblConversion_rt = "1";

				// Get conversion rate with inventory unit code
				//
				if (grid_item.lblIVUnit_cd == grid_item.txtUnit_cd)
                {
					conversion_rate = 1;
				}
				else if (o_val.IsValidUnitCode(grid_item.txtItem_cd, grid_item.lblIVUnit_cd, grid_item.txtUnit_cd, ref conversion_rate) == false)
				{
					modDialogUtility.DisplayBox(ref cur_db,  cur_db.oLanguage.oMessage.NO_CONVERSION_EXIST + "(" + grid_item.lblIVUnit_cd + ":" + grid_item.txtUnit_cd + ")");
					return false;
				}

				grid_item.lblConversion_rt = conversion_rate.ToString();

				// Set the default tax.
				//
				grid_item.cboTax_cd = tax_cd;
				grid_item.lblTax_pc = tax_pc.ToString();

				if (o_val.oRecordset.iField("iTaxable_fl") == GlobalVar.goConstant.FLAG_OFF)
				{
					grid_item.cboTax_cd = "";
					grid_item.lblTax_pc = "0";

				//  If the item carries a special sales tax code, then grab it.
				//
				}
				else if (oUtility.IsNonEmpty(o_val.oRecordset.sField("sTax_cd")))   // && ((Math.Abs(oUtility.ToValue(grid_item.lblTax_pc)) > 0) || (cur_db.iSalesTax_typ == GlobalVar.goConstant.TAX_VAT_TYPE_NUM))) // Meaning tax is applicable to purchase and there is a specific tax for this item.
				{
					clsValidate new_validate = new clsValidate(ref cur_db);

					if (IsSalesTransaction() == false)
					{
						if (new_validate.IsValidARTaxCode(o_val.oRecordset.sField("sTax_cd")) == false)
						{
							modDialogUtility.DisplayBox(ref cur_db, o_val.oRecordset.sField("sTax_cd") + cur_db.oLanguage.oMessage.IS_INVALID);
							return false;
						}
					}
					else
					{
						if (new_validate.IsValidAPTaxCode(o_val.oRecordset.sField("sTax_cd")) == false)
						{
							modDialogUtility.DisplayBox(ref cur_db, o_val.oRecordset.sField("sTax_cd") + cur_db.oLanguage.oMessage.IS_INVALID);
							return false;
						}
					}
					
					grid_item.cboTax_cd = o_val.oRecordset.sField("sTax_cd");
					grid_item.lblTax_pc = new_validate.oRecordset.mField("fTotalTax_pc").ToString();
				}

				if (iTransaction_typ ==  GlobalVar.goConstant.TRX_PO_TYPE)
                {
					if (o_val.IsValidVendorItemCode(entity_code, grid_item.txtItem_cd))
					{
						if (GlobalVar.goUtility.IsNonEmpty(o_val.oRecordset.sField("sDescription")))
                        {
							grid_item.txtDescription = o_val.oRecordset.sField("sDescription");
						}
						if (GlobalVar.goUtility.IsNonEmpty(o_val.oRecordset.sField("sPurchaseUnit_cd")))
						{
							grid_item.txtUnit_cd = o_val.oRecordset.sField("sPurchaseUnit_cd");
						}
						grid_item.txtVendorItem_cd = o_val.oRecordset.sField("sVendorItem_cd");
					}

					if (cur_db.uSecurity.bShowPurchasePrice_fl)
					{
						if (o_gen.GetLatestPurchasePrice(entity_code, grid_item.txtItem_cd, ref unit_price, ref unit_code, ref  qty_on_order))
						{
							grid_item.txtUnit_cd = unit_code;
							grid_item.txtUnitPrice_amt = o_money.ToStrMoney(unit_price);
                            grid_item.txtUnitPriceInPrimary_amt = o_money.ToStrMoney(o_currency.ConvertToPrimaryCurrency(o_money.ToNumMoney(grid_item.txtUnitPrice_amt), price_exchange_rt));
                        }
                        else
                        {
							grid_item.txtUnitPrice_amt = "";
							grid_item.txtUnitPriceInPrimary_amt = "";
                        }
					}

					return true;
				}

				if ((iTransaction_typ == GlobalVar.goConstant.TRX_SO_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_QUOTE_TYPE) && oUtility.IsNonEmpty(grid_item.txtItem_cd)) 
                {
					tmp = "";

					grid_item.lblLastPrice_amt = o_money.ToStrMoney(o_gen.GetLastPrice(iTransaction_typ, iTransaction_num, entity_code, grid_item.txtItem_cd, ref tmp)) + "/" + tmp;

					if (oUtility.IsEmpty(tmp))
                    {
						grid_item.lblLastPrice_amt = "";
					}
				}

				if (IsSalesTransaction() ==  false)
                {
					return true;
                }

				// BELOW THIS LINE, DO NOT REFERENCE o_val.oRecordset because the follow function calls
				// will close it.
				//

				// grid_item.lblSellUnitPrice_amt = o_currency.GetSellingUnitPrice(o_money.ToNumMoney(grid_item.lblSellUnitPrice_amt), sale_exchange_rt, price_exchange_rt).ToString();
				grid_item.lblSellUnitPrice_amt = o_currency.GetSellingUnitPrice(o_money.ToNumMoney(grid_item.lblSellUnitPrice_amt), 1, price_exchange_rt).ToString();       // For all SALES, we keep the amount in primary currency first.

				// If there is pricing for this customer class, get it.
				//
				if (cur_db.uSecurity.bApplyCustomerPricing_fl)
                {
					if (o_customer.GetCustomer(entity_code, true) == false)
					{
						return false;
					}
					else if (o_val.IsValidCustomerItemCode(o_customer.sClass_cd, grid_item.txtItem_cd))
					{
						// 05/05/2024 Customer Item Pricing may leave these fields blank.
						//
						if (oUtility.IsNonEmpty(o_val.oRecordset.sField("sDescription")))
						{
	                        grid_item.txtDescription = o_val.oRecordset.sField("sDescription");
                        }
                        if (oUtility.IsNonEmpty(o_val.oRecordset.sField("sSellUnit_cd")) && grid_item.txtUnit_cd != o_val.oRecordset.sField("sSellUnit_cd"))
                        {
                            grid_item.txtUnit_cd = o_val.oRecordset.sField("sSellUnit_cd");
                            grid_item.lblSellUnit_cd = o_val.oRecordset.sField("sSellUnit_cd");

							clsValidate local_val = new clsValidate(ref cur_db);

                            if (local_val.IsValidUnitCode(grid_item.txtItem_cd, grid_item.lblIVUnit_cd, grid_item.txtUnit_cd, ref conversion_rate) == false)
                            {
                                modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NO_CONVERSION_EXIST + "(" + grid_item.lblIVUnit_cd + ":" + grid_item.txtUnit_cd + ")");
                                return false;
                            }

                            grid_item.lblConversion_rt = conversion_rate.ToString();
							grid_item.lblSellUnitPrice_amt = o_money.ToStrMoney(o_money.RoundToMoney(o_money.ToNumMoney(grid_item.lblSellUnitPrice_amt) * conversion_rate));
                        }
                        if (o_val.oRecordset.mField("mSellUnitPrice_amt") > 0)
                        {
							grid_item.lblSellUnitPrice_amt = o_money.ToStrMoney(o_val.oRecordset.mField("mSellUnitPrice_amt"));
                        }
					}
				}

				grid_item.txtUnitPriceInPrimary_amt = grid_item.lblSellUnitPrice_amt;

				//grid_item.txtUnitPrice_amt = o_money.ToStrMoney(o_currency.ConvertToForeignCurrency(o_money.ToNumMoney(grid_item.txtUnitPriceInPrimary_amt), sale_exchange_rt));
				grid_item.txtUnitPrice_amt = o_money.ToStrMoney(o_currency.ConvertToForeignCurrency(o_money.ToNumMoney(grid_item.txtUnitPriceInPrimary_amt), price_exchange_rt));

                sell_unit_price = o_money.ToNumMoney(grid_item.lblSellUnitPrice_amt);

				//if (moSerial.IsSerialOrLotItem(item_type) & !oUtility.IsEmpty(serial_num)) // This means that scanner was used
				//{
				//	if (oUtility.ToInteger(modWebGridUtility.SpreadsheetGetCell(grdMain, LINE_ID_COL, row_num)) < 1)
				//	{
				//		modWebGridUtility.SpreadsheetSetCell(ref grdMain, LINE_ID_COL, row_num, txtNextLine_id.Text);
				//		txtNextLine_id.Text = (oUtility.ToInteger(txtNextLine_id.Text) + 1).ToString();
				//	}
				//	//cmdLot_Click(Me, New System.EventArgs)
				//	SwitchView(VIEW_DETAIL_PAGE_NUM);
				//	var tempVar = 0;
				//	if (false == moSerialUtility.AddOneSerialItem(ref cur_db, ref grdLot, ref moWebDropdownList, oUtility.ToInteger(txtTransaction_typ.Text), oUtility.ToInteger(txtKey_id.Text), item_code, serial_num, cboLocation_cd.SelectedValue, ref tempVar, 0, oUtility.ToInteger(modWebGridUtility.SpreadsheetGetCell(grdMain, LINE_ID_COL, row_num)), modWebGridUtility.SpreadsheetGetCell(grdMain, UNIT_CODE_COL, row_num), o_money.ToNumMoney(modWebGridUtility.SpreadsheetGetCell(grdMain, QTY_COL, row_num)), o_money.ToNumMoney(modWebGridUtility.SpreadsheetGetCell(grdMain, UNIT_PRICE_COL, row_num)), 0, moSerial.IsSerialItem(item_type)))
				//	{
				//		modWebGridUtility.ClearOneGridRow(ref grdMain, row_num);
				//		if (cur_db.IsErrorFound()) // IsErrorFound() will preserve the messages if exist. 5/22/2016
				//		{
				//			FormShowMessage();
				//		}
				//		return return_value;
				//	}
				//}

				// If this is a kit item, and it is supposed be assembled now,
				// then bring up the detail items so that user can edit them.
				//
				if (kit_type == GlobalVar.goIVConstant.AUTO_ASSEMBLE_TYPE)
				{

					// Save the line id and kit id because GetKitItems() will increase
					// the id's.
					//
					grid_item.lblLine_id = iNextLine_id.ToString();
					iNextLine_id += 1;

					grid_item.lblKit_id = (iNextKit_id * GlobalVar.goConstant.KIT_ID_FACTOR).ToString();
					iNextKit_id += 1;

					// Grab all the sub-items for this kit-item.
					// kit_id of this line will be set to (NextKitId * goConstant.KIT_ID_FACTOR)
					// The sub item will have sequential number starting from (NextKitId * goConstant.KIT_ID_FACTOR + 1)
					// At this moment, goConstant.KIT_ID_FACTOR is set to 1000, but check constant file
					// for the right number.
					//
					if (GetKitItems(ref cur_db, grid_item.txtItem_cd, grid_item.Row_num, location_cd, oUtility.ToInteger(grid_item.lblKit_id)) == false)
					{
						return false;
					}

				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db,  ex.Message + " (ProcessItemCode)");
			}

			return return_value;
		}

		public bool IsSalesTransaction()
        {
			return ((iTransaction_typ >= 3000 && iTransaction_typ <= 3999) || (iTransaction_typ >= 5000 && iTransaction_typ <= 5999) || iTransaction_typ == GlobalVar.goConstant.TRX_IV_SALES_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_IV_SALES_RETURN_TYPE);

		}

		public bool IsPurchaseTransaction()
		{
			return ((iTransaction_typ >= 4000 && iTransaction_typ <= 4999) || (iTransaction_typ >= 6000 && iTransaction_typ <= 6999) || iTransaction_typ == GlobalVar.goConstant.TRX_IV_PURCHASE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_IV_PURCHASE_RETURN_TYPE);

		}
		//  PURPOSE:  To copy the kit template into the order.
		//
		public bool GetKitItems(ref clsDatabase cur_db, string item_code, int cur_row, string location_cd, int kit_id)
		{

			bool return_value = false;
			string sql_str = null;
			decimal amt_due = 0;
			decimal amt_taxable = 0;
			decimal amt_nontaxable = 0;
			decimal amt_tax = 0;
			clsRecordset cur_set = null;
			int line_id = 0;
			clsGrid next_item;
			bool found_fl = false;

			try
			{
				cur_set = new clsRecordset(ref cur_db);

				sql_str = "SELECT tblIVItemKit.sPartItem_cd AS sPartItemCode";
				sql_str += ",tblIVItemKit.iDisplay_fl AS iDisplayFlag";
				sql_str += ",tblIVItemKit.sDescription AS sDescr";
				sql_str += ",tblIVItemKit.sIVUnit_cd AS sIVUnitCode";
				sql_str += ",tblIVItemKit.fQty AS fQuantity";
				sql_str += ",tblIVItem.iItem_typ AS iItemType";
				sql_str += " FROM tblIVItemKit";
				sql_str += " LEFT JOIN tblIVItem ON tblIVItemKit.sPartItem_cd = tblIVItem.sItem_cd ";
				sql_str += " WHERE tblIVItemKit.sItem_cd = '" + item_code + "'";

				if (cur_set.CreateSnapshot(sql_str) == false)
				{
					SetPostingError(cur_db.GetErrorMessage());
					return false;
				}
				else if (cur_set.EOF())
				{
					cur_set.Release();
					return true;
				}

				line_id = iNextLine_id;
				kit_id = kit_id + 1;
				cur_row = cur_row + 1;
				amt_nontaxable = 0;
				amt_taxable = 0;
				amt_tax = 0;

				while (cur_set.EOF() == false)
				{
					// Display the items with item_code or display_flag on.
					//
					if (oUtility.IsNonEmpty(cur_set.sField("sPartItemCode")) || cur_set.iField("iDisplayFlag") == GlobalVar.goConstant.FLAG_ON)
					{
						next_item = new clsGrid();

						if (FindGridLine(cur_row, ref next_item))
                        {
							next_item.txtItem_cd = cur_set.sField("sPartItemCode");
							next_item.txtDescription = cur_set.sField("sDescr");

							next_item.txtUnit_cd = cur_set.sField("sIVUnitCode");
							next_item.lblSellUnit_cd = cur_set.sField("sIVUnitCode");
							next_item.lblIVUnit_cd = cur_set.sField("sIVUnitCode");
							next_item.txtOrdered_qty = cur_set.mField("fQuantity").ToString();
							next_item.txtShipped_qty = cur_set.mField("fQuantity").ToString();

							next_item.lblBackorder_qty = "0";
							next_item.txtUnitPrice_amt = "";
							next_item.lblSellUnitPrice_amt = "0";
							next_item.lblExtended_amt = "";
							next_item.txtTax_amt = "";
							next_item.lblDiscount_amt = "";
							next_item.txtDiscount_pc = "";
							next_item.mskGLAccount_cd = "";
							next_item.lblConversion_rt = "1";

							next_item.lblInIVUnit_qty = cur_set.sField("fQuantity");
							next_item.lblItem_typ = cur_set.sField("iItemType");
							next_item.lblLocation_cd = location_cd;
							next_item.lblKit_id = kit_id.ToString();
							next_item.lblLine_id = line_id.ToString();

							RecreateDetailLine(next_item, cur_row);         // Need to sync Data[]

							kit_id += 1;
							line_id += 1;
						}

						cur_row += 1;
					}

					cur_set.MoveNext();
				}

				return_value = true;
			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db,  ex.Message + " (GetKitItems)");

			}

			return return_value;
		}

		public bool CalculateRow(ref clsDatabase cur_db, ref clsGrid grid_item, ref string new_qty, decimal exchange_rate = 1)
		{
			bool return_value = false;
			decimal qty_shipped = 0;
			decimal unit_price = 0;
			decimal line_tax_amt = 0;
			decimal tax_perc = 0;
			decimal disc_perc = 0;
			decimal amt_taxable = 0;
			decimal amt_extended = 0;
			decimal amt_nontaxable = 0;
			decimal total_tax = 0;
			decimal amt_trx = 0;
			string item_code = "";
			string tax_code = "";
			string job_code = "";

			decimal amt_disc = 0;
			int item_type = 0;

			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);

			try
			{
				unit_price = o_money.ToNumMoney(grid_item.txtUnitPrice_amt);
				item_type = oUtility.ToInteger(grid_item.lblItem_typ);
				item_code = grid_item.txtItem_cd;
				tax_code = grid_item.cboTax_cd;
				tax_perc = oUtility.ToValue(grid_item.lblTax_pc);
				job_code = grid_item.cboJob_cd;
				disc_perc = oUtility.ToValue(grid_item.txtDiscount_pc);
				amt_disc = o_money.ToNumMoney(grid_item.lblDiscount_amt);

				// Accept negative line items, now
				//
				if (unit_price < 0)
				{
					if (oUtility.IsNegativePriceCarryItemType(item_type) == false) // 07/04/2016 This will let the rebate/discount item carry the item code for report later on
					{
						item_code = "";
					}
					job_code = "";
					disc_perc = 0;
					amt_disc = 0;
				}

				// If tax_code field is empty, then it is assummed that this item is either non-taxable or exempted.
				//
				if (oUtility.IsEmpty(tax_code))
				{
					tax_perc = 0;
				}

				//  Copy to the vars in order to handle easier in the small screen.
				//
				qty_shipped = o_money.ToNumMoney(new_qty);
				unit_price = o_money.ToNumMoney(grid_item.txtUnitPrice_amt);

				amt_extended = o_money.RoundToMoney(qty_shipped * unit_price);

				if (o_money.TooLargeDollar(amt_extended))
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.TOO_LARGE_DOLLAR);
					return return_value;
				}

				// Caluculate the tax for this line.
				//
				if (o_gen.CalcSalesTax(amt_extended, tax_perc, ref line_tax_amt, (tax_perc < 0)) == false)
				{
					return return_value;
				}

				grid_item.txtItem_cd = item_code;
				grid_item.txtDiscount_pc = disc_perc.ToString();
				grid_item.lblDiscount_amt = amt_disc.ToString();
				grid_item.txtTax_amt = o_money.ToStrMoney(line_tax_amt);
				grid_item.lblExtended_amt = o_money.ToStrMoney(amt_extended);

				// 08/08/2018  Was sending wrong cost.
				//
				if (iTransaction_typ != GlobalVar.goConstant.TRX_INVOICE_TYPE && iTransaction_typ != GlobalVar.goConstant.TRX_CM_TYPE)
				{
					grid_item.lblTotalCost_amt = o_money.ToStrMoney(amt_extended);
				}

				// txtUnitPriceInPrimary_amt has to be changed in the calling routine
				// grid_item.txtUnitPriceInPrimary_amt = o_money.ToStrMoney(o_currency.ConvertToPrimaryCurrency(o_money.ToNumMoney(grid_item.txtUnitPrice_amt), exchange_rate)); 

				grid_item.lblExtendedInPrimary_amt = o_money.ToStrMoney(o_money.RoundToMoney(o_money.ToNumMoney(grid_item.txtUnitPriceInPrimary_amt) * oUtility.ToValue(new_qty)));
                grid_item.lblDiscountInPrimary_amt = o_money.ToStrMoney(o_currency.ConvertToPrimaryCurrency(o_money.ToNumMoney(grid_item.lblDiscount_amt), exchange_rate));

                if (o_gen.CalcSalesTax(o_money.ToNumMoney(grid_item.lblExtendedInPrimary_amt), tax_perc, ref line_tax_amt, (tax_perc < 0)) == false)
                {
                    return return_value;
                }

                grid_item.lblTaxInPrimary_amt = o_money.ToStrMoney(line_tax_amt);

                return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (CalculateRow)");
			}

			return return_value;
		}

		public bool WithinTaxTolerance(ref clsDatabase cur_db, decimal total_taxable, decimal freight_amt, decimal tax_pc, decimal tax_entered)
		{
			bool return_value = false;
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			decimal tax_calculated = 0;

			if (cur_db.bFreightTax_fl == false)
			{
				freight_amt = 0;
			}

			if (o_gen.CalcSalesTax(total_taxable + freight_amt, tax_pc, ref tax_calculated, cur_db.bIncludeTaxInTaxableTotal_fl) == false)
			{
				return false;
			}

			// Do not allow more than 20% because it is to adjust the roundgin errors.  Otherwise, CalculateTotals() may have a problem
			// If they need to adjust a large portion of tax, they must be adjusting the freight tax.
			// If it is the case, they need to put the freight in the detail and adjust it there.
			//
			return_value = (Math.Abs(tax_calculated - tax_entered) <= (tax_calculated * 0.2M));

			return return_value;
		}

		// 07/07/2019
		// Discount & Unit Price is calcluated in the primary currency.  The caller should convert it to f/c.
		//
		public bool CalculateDiscountAmount(ref clsDatabase cur_db, ref clsGrid grid_item, ref string new_qty, decimal exchange_rate)
		{
			bool return_value = false;
			decimal qty = 0;
			decimal sell_unit_price = 0;
			decimal price_conversion_rate = 0;
			string ivunit_code = "";
			string unit_code = "";
			string sell_unit_code = "";
			string item_code = "";
			decimal size_qty = 0;
			decimal unit_price_in_pc = 0; // amounts in primary currency
			decimal amt_disc_in_pc = 0;

			clsMoney o_money = new clsMoney(ref cur_db);
			clsValidate o_val = new clsValidate(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);

			try
			{
				if (IsSalesTransaction() == false)
                {
					return true;
                }

				// 08/20/2021
				// Local invoice has discount calculation problem without this.
				// 
				if (o_money.ToNumMoney(grid_item.txtUnitPriceInPrimary_amt) == 0 || exchange_rate <= 0 || exchange_rate == 1)
                {
					grid_item.txtUnitPriceInPrimary_amt = grid_item.txtUnitPrice_amt;
				}

				sell_unit_code = grid_item.lblSellUnit_cd;
				ivunit_code = grid_item.lblIVUnit_cd;
				unit_code = grid_item.txtUnit_cd;
				unit_price_in_pc = o_money.ToNumMoney(grid_item.txtUnitPriceInPrimary_amt);
				item_code = grid_item.txtItem_cd;
				qty = oUtility.ToValue(new_qty);

				// There is no discount for the service-item.
				//
				if (oUtility.IsInventoryItemType(oUtility.ToInteger(grid_item.lblItem_typ)) == false)
				{
					grid_item.txtDiscount_pc = "0";
					grid_item.lblDiscountInPrimary_amt = "0";
				}
				else if (oUtility.IsNonEmpty(grid_item.txtItem_cd))
				{
					size_qty = oUtility.ToValue(grid_item.txtSize_cd);

					// 07/07/2019            
					// SELL_UNIT_PRICE_COL  carries the price in primary currency
					// We calclulate "everything" here in the primary currency, first, and then, translate them in F/C
					//
					if (cur_db.uSecurity.bApplySizeToUnitPrice_fl & cur_db.uSecurity.bShowSizeColumn_fl && size_qty >= cur_db.fSmallestNumber)
					{
						sell_unit_price = oUtility.RoundToQtyFactor(o_money.ToNumMoney(grid_item.lblSellUnitPrice_amt) * size_qty);
					}
					else
					{
						sell_unit_price = o_money.ToNumMoney(grid_item.lblSellUnitPrice_amt);
					}

					if (sell_unit_code == unit_code)
					{
						price_conversion_rate = 1;
					}
					else if (o_val.IsValidUnitCode(item_code, sell_unit_code, unit_code, ref price_conversion_rate) == false) // price_conversion_rate = sell_unit_code vs. unit_code. iv_conversion_rate = iv_unit_code vs. unit_code
					{
						grid_item.txtUnit_cd = Data[UNIT_CODE_COL, grid_item.Row_num];
						modDialogUtility.DisplayBox(ref cur_db, unit_code + cur_db.oLanguage.oMessage.IS_INVALID);
						return false;
					}

					amt_disc_in_pc = o_money.RoundToMoney(qty * ((sell_unit_price * price_conversion_rate) - unit_price_in_pc));

					// if discount amount is <= 0 then, set it to 0.
					//
					if (amt_disc_in_pc > 0)
					{
						grid_item.lblDiscountInPrimary_amt = oUtility.ToStr(amt_disc_in_pc);
					}
					else
					{
						amt_disc_in_pc = 0;
						grid_item.txtDiscount_pc = "0";
						grid_item.lblDiscountInPrimary_amt = "0";
					}
				}
				else
				{
					grid_item.txtDiscount_pc = "0";
					grid_item.lblDiscountInPrimary_amt = "0";
				}

				grid_item.lblDiscount_amt = o_currency.ConvertToForeignCurrency(amt_disc_in_pc, exchange_rate).ToString();

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CalculateDiscountAmount)");
			}

			return return_value;
		}

		public bool CalculateTotals(ref clsDatabase cur_db, ref decimal header_nontaxable_amt, ref decimal header_taxable_amt, ref decimal header_tax_amt, ref decimal header_discount_amt, ref decimal header_weight
			, ref decimal amt_freight_tax, bool in_primary_fl, ref decimal total_qty)
		{
			bool return_value = false;
			int i = 0;
			int total_rows = 0;
			decimal line_tax_amt = 0;
			decimal line_wight = 0;
			decimal line_discount_amt = 0;
			decimal line_extended_amt = 0;
			decimal line_tax_pc = 0;
			bool special_tax_exists = false;
			string last_tax_code = "";
			string line_tax_code = "";
			decimal last_tax_perc = 0;
			decimal amt_trx = 0;
			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			decimal detail_tax_total_amt = 0;
			decimal amt_left = 0;
			decimal detail_taxable_total_amt = 0;
			int first_taxable_line = 0;

			try
			{
				total_qty = 0;

				header_nontaxable_amt = 0;
				header_taxable_amt = 0;
				header_discount_amt = 0;
				header_weight = 0;

				special_tax_exists = false;
				last_tax_code = "";
				last_tax_perc = 0;
				detail_tax_total_amt = 0;
				detail_taxable_total_amt = 0;

				total_rows = Grid.Count;

				// 1. Get the detail totals
				// ----------------------------------------------------------------------------------------------------------------------------------------------
				foreach (var det in Grid)
				{
					line_tax_amt = 0;
					line_extended_amt = 0;
					line_discount_amt = 0;
					line_wight = 0;
					line_tax_pc = 0;
					line_tax_code = "";

					line_tax_code = det.cboTax_cd;
					line_tax_pc = oUtility.ToValue(det.lblTax_pc);
					line_wight = oUtility.ToValue(det.lblWeight) * oUtility.ToValue(det.lblInIVUnit_qty);

					if (in_primary_fl)
                    {
						line_tax_amt = o_money.ToNumMoney(det.lblTaxInPrimary_amt);
						line_extended_amt = o_money.ToNumMoney(det.lblExtendedInPrimary_amt);
						line_discount_amt = o_money.ToNumMoney(det.lblDiscountInPrimary_amt);
					}
					else
                    {
						line_tax_amt = o_money.ToNumMoney(det.txtTax_amt);
						line_extended_amt = o_money.ToNumMoney(det.lblExtended_amt);
						line_discount_amt = o_money.ToNumMoney(det.lblDiscount_amt);
					}

					// if (header_tax_amt = 0) is entered, we will recalculate the default tax.
					// Each time tax is adjusted, the line taxes are adjusted accordingly so that, when the tax is reset, it is necessary to recalculate to default.
					// In the normal course of business, it may not happen.
					// However, in demo, tax amount can be manipulated multiple times so that it is a safe bet to recalculate the line tax.
					// And it won't take long.
					//
					//If header_tax_amt = 0 Then
					if (o_gen.CalcSalesTax(line_extended_amt, line_tax_pc, ref line_tax_amt, (line_tax_pc < 0)) == false)
					{
						return false;
					}
					//End If

					if (in_primary_fl)
					{
						det.lblTaxInPrimary_amt = line_tax_amt.ToString();
						Data[AMT_TAX_IN_PRIMARY_CURRENCY_COL, det.Row_num] = det.lblTaxInPrimary_amt;
					}
					else
					{
						det.txtTax_amt = line_tax_amt.ToString();
						Data[AMT_TAX_COL, det.Row_num] = det.txtTax_amt;
					}

					header_discount_amt += line_discount_amt;
					detail_tax_total_amt += line_tax_amt;
					header_weight += line_wight;

					if (Math.Abs(line_tax_pc) > 0)
					{
						detail_taxable_total_amt += line_extended_amt;
					}

					if (Math.Abs(line_tax_pc) > 0 && Math.Abs(last_tax_perc) > 0 && line_tax_pc != last_tax_perc)
					{
						special_tax_exists = true;
					}

					if (Math.Abs(line_tax_pc) > 0)
					{
						last_tax_code = line_tax_code;
						last_tax_perc = line_tax_pc;
					}

					if (oUtility.IsNonEmpty(line_tax_code) && Math.Abs(line_tax_pc) > 0 && line_extended_amt >= cur_db.fSmallestNumber) // do not use this--> line_tax_amt >= cur_db.fSmallestNumber Then
					{
						header_taxable_amt += line_extended_amt;

						// Included Tax
						//
						if (line_tax_pc < 0 && !cur_db.bIncludeTaxInTaxableTotal_fl)
						{
							header_taxable_amt -= line_tax_amt;
						}
					}
					else
					{
						header_nontaxable_amt += line_extended_amt;
					}

					// If the amount is too large, return false.
					//
					if (o_money.TooLargeDollar(header_nontaxable_amt + header_taxable_amt))
					{
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.TOO_LARGE_DOLLAR);
						return false;
					}

					if (oUtility.IsInventoryItemType(oUtility.ToInteger(det.lblItem_typ)))
                    {
						if (iTransaction_typ == GlobalVar.goConstant.TRX_INVOICE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_CM_TYPE
						|| iTransaction_typ == GlobalVar.goConstant.TRX_PURCHASE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_DM_TYPE)
						{
							total_qty += oUtility.ToValue(det.txtShipped_qty);
						}
						else
						{
							total_qty += oUtility.ToValue(det.txtOrdered_qty);
						}
					}

				}

				// 2. If user enters the tax, adjust the line item tax proportionally before calculation.
				// ----------------------------------------------------------------------------------------------------------------------------------------------
				if (header_tax_amt > 0)
				{
					// For inclusive tax, taxable amount should be greater than the tax.
					//
					if (detail_taxable_total_amt <= header_tax_amt && last_tax_perc < 0 && !cur_db.bIncludeTaxInTaxableTotal_fl)
					{
						return false;
					}

					if (detail_taxable_total_amt < cur_db.mSmallestMoney_amt)
					{
						amt_freight_tax = header_tax_amt;
						amt_left = 0;
					}
					else if (header_tax_amt > amt_freight_tax)
					{
						amt_left = header_tax_amt - amt_freight_tax;
					}
					else
					{
						amt_freight_tax = 0; // If the tax entered is less than freight tax, need to wipe out freight first.
						amt_left = header_tax_amt;
					}

					first_taxable_line = -1;
					header_taxable_amt = 0; // recalculate

					foreach (var det in Grid)
					{
						line_tax_amt = 0;

						// We know taxable line has tax% on each line.
						//
						if (Math.Abs(oUtility.ToValue(det.lblTax_pc)) > 0 && o_money.ToNumMoney(det.lblExtended_amt) >= cur_db.mSmallestMoney_amt)
						{
							if (amt_left > 0)
							{
								if (in_primary_fl)
								{
									line_tax_amt = o_money.RoundToMoney(header_tax_amt * o_money.ToNumMoney(det.lblExtendedInPrimary_amt) / detail_taxable_total_amt);
									header_taxable_amt += o_money.ToNumMoney(det.lblExtendedInPrimary_amt);
								}
								else
								{
									line_tax_amt = o_money.RoundToMoney(header_tax_amt * o_money.ToNumMoney(det.lblExtended_amt) / detail_taxable_total_amt);
									header_taxable_amt += o_money.ToNumMoney(det.lblExtended_amt);
								}


								if (amt_left >= line_tax_amt)
								{
									amt_left -= line_tax_amt;
								}
								else
								{
									line_tax_amt = amt_left;
									amt_left = 0;
								}
							}

							if (first_taxable_line < 0) // Remember the first taxable line.
							{
								first_taxable_line = i;
							}
						}

						if (in_primary_fl)
						{
							det.lblTaxInPrimary_amt = line_tax_amt.ToString();
							Data[AMT_TAX_IN_PRIMARY_CURRENCY_COL, det.Row_num] = det.lblTaxInPrimary_amt;
						}
						else
						{
							det.txtTax_amt = line_tax_amt.ToString();
							Data[AMT_TAX_COL, det.Row_num] = det.txtTax_amt;
						}

					}

					// If there is any remaining, put it on the first item possible.
					if (amt_left != 0)
					{
						foreach (var det in Grid)
						{
							if (Math.Abs(o_money.ToNumMoney(det.txtTax_amt)) > amt_left || (amt_left > 0 && o_money.ToNumMoney(det.txtTax_amt) > 0))
							{
								if (in_primary_fl)
								{
									det.lblTaxInPrimary_amt = (o_money.ToNumMoney(det.lblTaxInPrimary_amt) + amt_left).ToString();
									Data[AMT_TAX_IN_PRIMARY_CURRENCY_COL, det.Row_num] = det.lblTaxInPrimary_amt;
								}
								else
								{
									det.txtTax_amt = (o_money.ToNumMoney(det.txtTax_amt) + amt_left).ToString();
									Data[AMT_TAX_COL, det.Row_num] = det.txtTax_amt;
								}

								break;
							}
						}
					}

					if (last_tax_perc < 0 && !cur_db.bIncludeTaxInTaxableTotal_fl)
					{
						header_taxable_amt -= header_tax_amt;
					}
				}

				// 3. Finalize header_tax_amt
				// ----------------------------------------------------------------------------------------------------------------------------------------------
				if (header_taxable_amt == 0) // And header_nontaxable_amt = 0 Then ' 07/25/2017 Fex Tax may have freight tax only.
				{
					if (amt_freight_tax == 0)
					{
						header_tax_amt = 0;
					}
					else
					{
						header_tax_amt = amt_freight_tax;
					}

					// If a special tax exists, the total of the line items will be the total tax.
					//
					//ElseIf special_tax_exists Then
					//header_tax_amt = tax_total_amt
					//return_value = True

					// If not, the total of the line items may not be the same as the total tax calculated
					// from the total sales amount due to rounding error.
					//
				}
				else
				{
					// If header_tax_amt is not passed, calculate it with header_taxable_amt.  DO NOT use SUM(line tax).  The tax has to be always derived from the total amount.
					//
					if (header_tax_amt < cur_db.mSmallestMoney_amt)
					{
						if (o_gen.CalcSalesTax(header_taxable_amt, last_tax_perc, ref header_tax_amt, cur_db.bIncludeTaxInTaxableTotal_fl) == false)
						{
							return false;
						}

						header_tax_amt += amt_freight_tax;
					}
				}

				return_value = true;

			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (CalculateTotals)");
			}

			if (header_tax_amt < cur_db.mSmallestMoney_amt) // by any chance
			{
				header_tax_amt = 0;
			}

			if (header_taxable_amt < 0)
			{
				header_taxable_amt = 0; // Could happen when tax >> header_taxable_amt
			}

			return return_value;
		}

		public decimal CalculateSubTotal(ref clsDatabase cur_db, decimal taxable_amt, decimal non_taxable_amt, decimal freight_amt, decimal tax_amt, decimal tax_perc)
		{
			decimal return_value = 0;

			try
			{
				return_value = taxable_amt + non_taxable_amt + freight_amt;

				if (tax_perc >= 0 || !cur_db.bIncludeTaxInTaxableTotal_fl) // DO NOT use "tax_perc > 0" because flex-tax can be 0.
				{
					return_value += tax_amt;
				}
			}
			catch (Exception ex)
			{
				return_value = 0;
			}

			return return_value;
		}

		// Unlike al others in this page, this routine validates data in Data[,]
		// This is called right before saving only so that no need to sync grid.
		public bool CheckChargeDetail(ref clsDatabase cur_db, string header_location_code, decimal header_tax_perc)          
		{
			bool return_value = false;
			int i = 0;
			int row_num = 0;
			int item_type = 0;
			bool regular_tax_fl = false;
			bool included_tax_fl = false;
			string item_code = "";
			string unit_code = "";
			string location_code = "";
			decimal extended_amt = 0;
			decimal tax_perc = 0;
			decimal qty = 0;

			clsMoney o_money = new clsMoney(ref cur_db);
			clsSerial o_serial = new clsSerial(ref cur_db);

			try
			{
				if (header_tax_perc >= cur_db.fSmallestNumber)
				{
					regular_tax_fl = true;
				}
				else if (header_tax_perc <= -cur_db.fSmallestNumber)
				{
					included_tax_fl = true;
				}

				for (row_num = 0; row_num < Data.GetLength(1); row_num++)
				{

					item_code = Data[ITEM_CODE_COL, row_num];
					location_code = Data[LOCATION_COL, row_num];
					unit_code = Data[UNIT_CODE_COL, row_num];
					item_type = GlobalVar.goUtility.ToInteger(Data[ITEM_TYPE_COL, row_num]);
					tax_perc = GlobalVar.goUtility.ToValue(Data[TAX_PERC_COL, row_num]);
					extended_amt = o_money.ToNumMoney(Data[AMT_EXTENDED_COL, row_num]);

					qty = GlobalVar.goUtility.ToValue(Data[QUANTITY_COL, row_num]);          // QUANTITY_COL is set to a proper column according to this transaction type in constructor.

					// At this point, multi-location entry is not allowed.  If location code is changed in the middle of entry at UI, details may have different location code.
					// Make sure it has correct code.
					//
					Data[LOCATION_COL, row_num] = header_location_code;

					if (oUtility.IsNonEmpty(item_code))
					{

						if (Math.Abs(qty) >= cur_db.fSmallestNumber &&  GlobalVar.goUtility.IsNegativePriceCarryItemType(item_type) == false && oUtility.IsEmpty(unit_code))
						{
							modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.UNIT_CODE_IS_MISSING_ON_THE_LINE_NUMBER + (row_num + 1).ToString());
							return false;
						}

						// At this point, serial/lot numbers are tracked only in invoice, C/M, voucher & D/M.
						//
						if (iTransaction_typ == GlobalVar.goConstant.TRX_INVOICE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_CM_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_PURCHASE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_DM_TYPE)
						{
							if (cur_db.bDoNotTrackLot_fl == false && o_serial.IsLotItem(item_type))
							{
								if (oUtility.IsEmpty(Data[SERIAL_CODE_COL, row_num]))
								{
									modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.ENTER_SERIAL_NUM + "(" + (row_num + 1).ToString() + ")");
									return false;
								}
							}
							if (cur_db.bDoNotTrackSerial_fl == false && o_serial.IsSerialItem(item_type))
							{
								if (oUtility.IsEmpty(Data[SERIAL_CODE_COL, row_num]))
								{
									modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.ENTER_SERIAL_NUM + "(" + (row_num + 1).ToString() + ")");
									return false;
								}
								if (oUtility.ToInteger(Data[QTY_SHIPPED_COL, row_num]) > 1)
								{
									modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.SERIAL_ITEM_DOES_NOT_ALLOW_MORE_THAN_1);
									return false;
								}

								for (i = 0; i < row_num; i++)
								{
									if (Data[ITEM_CODE_COL, i] == Data[ITEM_CODE_COL, row_num] && Data[SERIAL_CODE_COL, i] == Data[SERIAL_CODE_COL, row_num])
									{
										modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.APPEARS_MORE_THAN_ONCE + "(" + Data[SERIAL_CODE_COL, i] + ")");
										return false;
									}
								}
							}
						}
					}

					if (extended_amt >= cur_db.mSmallestMoney_amt)
					{
						if (tax_perc >= cur_db.fSmallestNumber)
						{
							regular_tax_fl = true;
						}
						else if (tax_perc <= -cur_db.fSmallestNumber)
						{
							included_tax_fl = true;
						}
					}
				}

				if (regular_tax_fl && included_tax_fl)
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.TWO_TAX_TYPES_ARE_NOT_ALLOWED);
					return false;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CheckChargeDetail)");
			}

			return return_value;
		}

		// 07/07/2019
		// Discount & Unit Price is calcluated in the primary currency.  The caller should convert it to f/c.
		//
		public bool CalculateUnitPrice(ref clsDatabase cur_db, ref clsGrid grid_item, decimal exchange_rate, string customer_code, string item_code, string price_code, bool get_disc_flag)
		{
			bool return_value = false;
			decimal sell_unit_price = 0;
			decimal iv_qty = 0;
			decimal disc_perc = 0;
			decimal price_conversion_rate = 0;
			decimal unit_price_in_pc = 0; // in primary currency
			string sell_unit_code = "";
			string ivunit_code = "";
			string unit_code = "";
			decimal sale_price = 0;
			decimal size_qty = 0;
			string size_code = "";
			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsValidate o_val = new clsValidate(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);

			try
			{
				if (IsSalesTransaction() == false)
				{
					return true;
				}

				// 07/07/2019            
				// SELL_UNIT_PRICE_COL  carries the price in primary currency
				// We calclulate "everything" here in the primary currency, first, and then, translate them in F/C
				//
				sell_unit_price = o_money.ToNumMoney(grid_item.lblSellUnitPrice_amt);

				sell_unit_code = grid_item.lblSellUnit_cd;
				item_code = grid_item.txtItem_cd;
				unit_code = grid_item.txtUnit_cd;
				ivunit_code = grid_item.lblIVUnit_cd;
				iv_qty = oUtility.ToValue(grid_item.lblInIVUnit_qty);

				if (sell_unit_code == unit_code || !oUtility.IsInventoryItemType(oUtility.ToInteger(grid_item.lblItem_typ)))
				{
					price_conversion_rate = 1;
				}
				else if (o_val.IsValidUnitCode(item_code, sell_unit_code, unit_code, ref price_conversion_rate) == false)
				{
					grid_item.txtUnit_cd = ivunit_code;
					grid_item.lblInIVUnit_qty = iv_qty.ToString();
					modDialogUtility.DisplayBox(ref cur_db, unit_code + cur_db.oLanguage.oMessage.IS_INVALID);
				}

				// Calculate the unit-price using price code.
				// Do not forward if item_code is empty or service-item.
				//
				if (oUtility.IsEmpty(item_code))
				{
					grid_item.txtDiscount_pc = "0";
					grid_item.lblDiscountInPrimary_amt = "0";
					return true;
				}
				else if (oUtility.IsInventoryItemType(oUtility.ToInteger(grid_item.lblItem_typ)) == false)
				{
					grid_item.txtDiscount_pc = "0";
					grid_item.lblDiscountInPrimary_amt = "0";
					disc_perc = 0;
					unit_price_in_pc = o_money.RoundToMoneyFactor(sell_unit_price * price_conversion_rate * (100 - disc_perc) / 100);
				}
				else if (get_disc_flag && price_conversion_rate > 0 && sell_unit_price > 0)
				{
					// Grab the quantity discount and sale price, and compare them.
					//
					disc_perc = o_gen.GetQuantityDiscount(customer_code, price_code, item_code, ref iv_qty);
					unit_price_in_pc = o_money.RoundToMoneyFactor(sell_unit_price * price_conversion_rate * (100 - disc_perc) / 100);
					sale_price = o_money.RoundToMoneyFactor(o_gen.GetBestSalePrice(item_code, sell_unit_price) * price_conversion_rate);

					if (sale_price >= cur_db.mSmallestMoney_amt && unit_price_in_pc > sale_price)
					{
						unit_price_in_pc = sale_price;
					}

					if (sell_unit_price >= cur_db.mSmallestMoney_amt && price_conversion_rate > 0)
					{
						disc_perc = 100 - o_money.RoundToMoneyFactor(unit_price_in_pc * 100 / sell_unit_price / price_conversion_rate);
					}
					else
					{
						disc_perc = 0;
					}
				}
				else
				{
					disc_perc = o_money.ToNumMoney(grid_item.txtDiscount_pc);
					unit_price_in_pc = o_money.RoundToMoneyFactor(sell_unit_price * price_conversion_rate * (100 - disc_perc) / 100);
				}

				size_code = grid_item.txtSize_cd;
				if (cur_db.uSecurity.bApplySizeToUnitPrice_fl & cur_db.uSecurity.bShowSizeColumn_fl && o_money.ToNumMoney(size_code) >= cur_db.fSmallestNumber)
				{
					size_qty = o_money.ToNumMoney(size_code);
					unit_price_in_pc = o_money.RoundToMoney(size_qty * unit_price_in_pc);
				}

				grid_item.txtDiscount_pc = disc_perc.ToString();

				grid_item.txtUnitPriceInPrimary_amt = o_money.ToStrMoney(unit_price_in_pc); // We calclulate "everything" here in the primary currency, first, and then, translate them in F/C
				grid_item.txtUnitPrice_amt = o_money.ToStrMoney(o_currency.ConvertToForeignCurrency(unit_price_in_pc, exchange_rate));

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CalculateUnitPrice)");
			}

			return return_value;
		}

		public bool CalculateQtyInIvUnit(ref clsDatabase cur_db, ref clsGrid grid_item, ref string new_qty)
		{
			bool return_value = false;
			string ivunit_code = "";
			string unit_code = "";
			decimal iv_conversion_rate = 0;
			string item_code = "";
			decimal qty = 0;
			decimal size_qty = 0;
			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsValidate o_val = new clsValidate(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);

			try
			{
				ivunit_code = grid_item.lblIVUnit_cd;
				unit_code = grid_item.txtUnit_cd;
				item_code = grid_item.txtItem_cd;
				qty = oUtility.ToValue(new_qty);

				if (oUtility.IsEmpty(item_code))
				{
					grid_item.lblConversion_rt = "1";

				}
				else if (ivunit_code == unit_code || !oUtility.IsInventoryItemType(oUtility.ToInteger(grid_item.lblItem_typ)))
				{
					grid_item.lblConversion_rt = "1";
					grid_item.lblInIVUnit_qty = qty.ToString();

				}
				else if (o_val.IsValidUnitCode(item_code, ivunit_code, unit_code, ref iv_conversion_rate))
				{
					grid_item.lblConversion_rt = iv_conversion_rate.ToString(); // conversion_rate_col SHOULD carry the inventory conversion rate.
					grid_item.lblInIVUnit_qty = oUtility.RoundToQtyFactor(iv_conversion_rate * qty).ToString();

				}
				else
				{
					grid_item.lblConversion_rt = "1";
					grid_item.txtUnit_cd = ivunit_code;
					grid_item.lblInIVUnit_qty = qty.ToString();
				}

				if (IsSalesTransaction()) 
				{
					size_qty = o_money.ToNumMoney(grid_item.txtSize_cd);
					qty = o_money.ToNumMoney(grid_item.lblInIVUnit_qty);

					if (cur_db.uSecurity.bApplySizeToUnitPrice_fl & cur_db.uSecurity.bShowSizeColumn_fl && size_qty >= cur_db.fSmallestNumber)
					{
						grid_item.lblInIVUnit_qty = oUtility.RoundToQtyFactor(qty * size_qty).ToString();
					}
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CalculateQtyInIvUnit)");
			}

			return return_value;
		}

		// 07/07/2019
		// Discount & Unit Price is calcluated in the primary currency.  The caller should convert it to f/c.
		//
		public bool ProcessSalesUnit(ref clsDatabase cur_db, ref clsGrid grid_item, ref string new_qty, decimal exchange_rate, string customer_code, string price_code)
		{
			bool return_value = false;
			string unit_code = "";
			string item_code = "";
			decimal price_conversion_rate = 0;
			string ivunit_code = "";
			decimal new_ivqty = 0;
			decimal qty_shipped = 0;
			string tmp = "";
			string sell_unit_code = "";
			decimal unit_price_in_pc = 0; // amounts in primary currency
			decimal sale_price_in_pc = 0;
			decimal iv_qty = 0;
			decimal sell_unit_price = 0;
			decimal disc_amt = 0;
			decimal disc_perc = 0;
			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsValidate o_val = new clsValidate(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);

			try
			{
				unit_code = modCommonUtility.CleanCode(grid_item.txtUnit_cd);

				if (cur_db.uProgram.bIVExist_fl == false)
				{
					grid_item.txtUnit_cd = unit_code;
					return true;
				}

				// 07/07/2019            
				// SELL_UNIT_PRICE_COL  carries the price in primary currency
				// We calclulate everything in the primary currency, first, and then, translate them in F/C
				//
				sell_unit_price = o_money.ToNumMoney(grid_item.lblSellUnitPrice_amt);
				unit_price_in_pc = o_money.ToNumMoney(grid_item.txtUnitPriceInPrimary_amt);

				item_code = grid_item.txtItem_cd;
				disc_perc = o_money.ToNumMoney(grid_item.txtDiscount_pc);
				ivunit_code = grid_item.lblIVUnit_cd;
				sell_unit_code = grid_item.lblSellUnit_cd;

				if ((oUtility.IsEmpty(unit_code)) || oUtility.IsEmpty(item_code) || oUtility.IsInventoryItemType(oUtility.ToInteger(grid_item.lblItem_typ)) == false)
				{
					return_value = true;

				}
				else if (o_val.IsValidUnitCode(item_code, sell_unit_code, unit_code, ref price_conversion_rate) == false)
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NO_CONVERSION_EXIST + "(" + sell_unit_code + ":" + unit_code + ")");
					return false;
				}
				else
				{
					grid_item.txtUnit_cd = unit_code;
					grid_item.txtDiscount_pc = "0";
					grid_item.lblDiscount_amt = "0";
					grid_item.lblDiscountInPrimary_amt = "0";

					//  Calculate the qty in inventory unit.
					//
					if (CalculateQtyInIvUnit(ref cur_db, ref grid_item, ref new_qty) == false)
					{
						return false;
					}

					// Calculate the discount now according to the new qty.
					//
					iv_qty = o_money.ToNumMoney(grid_item.lblInIVUnit_qty);

					// Grab the quantity discount and sale price, and compare them.
					//
					disc_perc = o_gen.GetQuantityDiscount(customer_code, price_code, item_code, ref iv_qty);
					unit_price_in_pc = o_money.RoundToMoneyFactor(sell_unit_price * price_conversion_rate * ((100 - disc_perc) / 100));
					sale_price_in_pc = o_money.RoundToMoneyFactor(o_gen.GetBestSalePrice(item_code, sell_unit_price) * price_conversion_rate);

					if (unit_price_in_pc > sale_price_in_pc)
					{
						unit_price_in_pc = sale_price_in_pc;
					}

					if (sell_unit_price >= cur_db.mSmallestMoney_amt && price_conversion_rate >= cur_db.fSmallestNumber)
					{
						disc_perc = 100 - oUtility.RoundToDiscountPerc(unit_price_in_pc * 100 / sell_unit_price / price_conversion_rate);
					}
					else
					{
						disc_perc = 0;
					}

					grid_item.txtDiscount_pc = oUtility.ToStr(disc_perc);
					grid_item.txtUnitPriceInPrimary_amt = o_money.ToStrMoney(unit_price_in_pc);

					if (ProcessUnitPriceInPrimary(ref cur_db, ref grid_item, ref new_qty, exchange_rate, "") == false)
					{
						return false;
					}

					//if (CalculateDiscountAmount(ref cur_db, ref grid_item, ref new_qty, exchange_rate) == false)
					//{
					//	return false;
					//}

					return_value = true;
				}

			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessUnit)");
			}

			return return_value;
		}

		// 07/07/2019
		// Discount & Unit Price is calcluated in the primary currency.  The caller should convert it to f/c.
		//
		public bool ProcessUnitPrice(ref clsDatabase cur_db, ref clsGrid grid_item, ref string new_qty, decimal exchange_rate, bool recalc_fl = false)
		{
			bool return_value = false;
			decimal disc_perc = 0;
			decimal unit_price = 0;
			decimal sell_unit_price = 0;
			decimal unit_price_in_pc = 0; // in primary currency
			decimal price_conversion_rate = 0;
			string unit_code = "";
			string sell_unit_code = "";
			string ivunit_code = "";
			string item_code = "";
			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsValidate o_val = new clsValidate(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);
			clsSerial o_serial = new clsSerial(ref cur_db);
			int item_type = 0;

			try
			{
				item_code = grid_item.txtItem_cd;
				item_type = oUtility.ToInteger(grid_item.lblItem_typ);
				unit_price = o_money.ToNumMoney(grid_item.txtUnitPrice_amt);
				grid_item.txtUnitPrice_amt = o_money.ToStrMoney(unit_price);

				// If this is the line that has serial/lot number that is generated by moSerialUtility.InsertSerialNumbersIntoDetail().
				//
				if (oUtility.IsEmpty(item_code) && o_serial.IsSerialOrLotItem(item_type))
				{
					return true;
				}

				// Accept negative line items, now
				//
				if (unit_price < 0)
				{
					if (oUtility.IsNonEmpty(grid_item.txtItem_cd) && oUtility.IsInventoryItemType(oUtility.ToInteger(grid_item.lblItem_typ)))
					{
						grid_item.txtUnitPrice_amt = "";
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NEGATIVE_VALUE_NOT_ALLOWED);
						return false;
					}
					else if (oUtility.IsNegativePriceCarryItemType(oUtility.ToInteger(grid_item.lblItem_typ)) == false) // 07/04/2016 This will let the rebate/discount item carry the item code for report later on
					{
						grid_item.txtItem_cd = "";
					}
					// grid_item.cboJob_cd = "";
					grid_item.cboTax_cd = "";
					grid_item.txtDiscount_pc = "0";
					grid_item.lblDiscount_amt = "0";
					grid_item.lblDiscountInPrimary_amt = "0";
				}

				if (recalc_fl == false)
				{
					grid_item.txtUnitPriceInPrimary_amt = o_money.ToStrMoney(o_currency.ConvertToPrimaryCurrency(unit_price, exchange_rate));
				}

				if (IsSalesTransaction() == false)
                {
					return true;
                }

				item_code = grid_item.txtItem_cd;
				unit_code = grid_item.txtUnit_cd;
				ivunit_code = grid_item.lblIVUnit_cd;

				sell_unit_price = o_money.ToNumMoney(grid_item.lblSellUnitPrice_amt);
				sell_unit_code = grid_item.lblSellUnit_cd;

				unit_price_in_pc = o_money.ToNumMoney(grid_item.txtUnitPriceInPrimary_amt);

				if (sell_unit_code == unit_code || !oUtility.IsInventoryItemType(oUtility.ToInteger(grid_item.lblItem_typ)))
				{
					price_conversion_rate = 1;
				}
				else if (o_val.IsValidUnitCode(item_code, sell_unit_code, unit_code, ref price_conversion_rate) == false) // price_conversion_rate = sell_unit_code vs. unit_code. iv_conversion_rate = iv_unit_code vs. unit_code
				{
					grid_item.txtUnit_cd = Data[UNIT_CODE_COL, grid_item.Row_num];
					modDialogUtility.DisplayBox(ref cur_db, unit_code + cur_db.oLanguage.oMessage.IS_INVALID);
					return false;
				}

				if (oUtility.STrim(grid_item.txtItem_cd) == "")
				{
					grid_item.txtDiscount_pc = "0";
					grid_item.lblDiscount_amt = "0";
					grid_item.lblDiscountInPrimary_amt = "0";
					return_value = true;
				}
				else
				{
					if (sell_unit_price > 0 && price_conversion_rate > 0)
					{
						disc_perc = 100 - oUtility.RoundToDiscountPerc(unit_price_in_pc * 100 / sell_unit_price / price_conversion_rate);
					}
					else
					{
						disc_perc = 0;
					}

					if (disc_perc > 0)
                    {
						grid_item.txtDiscount_pc = oUtility.ToStr(disc_perc);
					}
					else
                    {
						disc_perc = 0;
						grid_item.txtDiscount_pc = "";
					}

					if (CalculateDiscountAmount(ref cur_db, ref grid_item, ref new_qty, exchange_rate) == false)
					{
						return false;
					}
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessUnitPrice)");
			}

			return return_value;
		}

		public bool ProcessUnitPriceInPrimary(ref clsDatabase cur_db, ref clsGrid grid_item, ref string new_qty, decimal exchange_rate, string job_code = "")
		{
			bool return_value = false;
			decimal unit_price_in_pc = 0;

			clsMoney o_money = new clsMoney(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);

			try
			{
				unit_price_in_pc = o_money.RoundToMoney(o_money.ToNumMoney(grid_item.txtUnitPriceInPrimary_amt));
				grid_item.txtUnitPriceInPrimary_amt = o_money.ToStrMoney(unit_price_in_pc);

				// Accept negative line items, now
				//
				if (unit_price_in_pc < 0)
				{
					if (oUtility.IsNegativePriceCarryItemType(oUtility.ToInteger(grid_item.lblItem_typ)) == false) // 07/04/2016 This will let the rebate/discount item carry the item code for report later on
					{
						grid_item.txtUnitPriceInPrimary_amt = "";
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NEGATIVE_VALUE_NOT_ALLOWED);
						return false;
					}
					//grid_item.cboJob_cd = "";
					grid_item.cboTax_cd = "";
					grid_item.txtDiscount_pc = "0";
					grid_item.lblDiscount_amt = "0";
				}

				grid_item.txtUnitPrice_amt = o_money.ToStrMoney(o_currency.ConvertToForeignCurrency(unit_price_in_pc, exchange_rate));

				if (ProcessUnitPrice(ref cur_db, ref grid_item, ref new_qty, exchange_rate, true) == false)
				{
					return false;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessUnitPriceInPrimary)");
			}

			return return_value;
		}

		// 07/07/2019
		// Discount & Unit Price is calcluated in the primary currency.  The caller should convert it to f/c.
		//
		public bool ProcessChargeQty(ref clsDatabase cur_db, ref clsGrid grid_item, ref string new_qty, decimal exchange_rate, string customer_code, string price_code)
		{
			bool return_value = false;
			decimal old_ivqty = 0;
			decimal iv_conversion_rate = 0;
			string item_code = "";
			int line_order_num = 0;
			decimal shipped_qty = 0;
			decimal order_qty = 0;
			clsRecordset cur_set = null;
			string sql_str = "";

			clsMoney o_money = new clsMoney(ref cur_db);
			clsSerial o_serial = new clsSerial(ref cur_db);

			cur_set = new clsRecordset(ref cur_db);

			try
			{
				item_code = grid_item.txtItem_cd;
				old_ivqty = oUtility.ToValue(grid_item.lblInIVUnit_qty);
				iv_conversion_rate = oUtility.ToValue(grid_item.lblConversion_rt);

				if (iTransaction_typ == GlobalVar.goConstant.TRX_SO_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_PO_TYPE
					 || iTransaction_typ == GlobalVar.goConstant.TRX_QUOTE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE)
				{
					shipped_qty = oUtility.ToValue(grid_item.txtShipped_qty);
				}
				else
				{
					shipped_qty = 0;
				}

				if (iTransaction_typ == GlobalVar.goConstant.TRX_INVOICE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_PURCHASE_TYPE)
				{
					order_qty = oUtility.ToValue(grid_item.txtOrdered_qty);
					line_order_num = oUtility.ToInteger(grid_item.lblOrder_num);
				}

				// Order qty cannot go below the shipped qty.
				//
				if (iTransaction_typ == GlobalVar.goConstant.TRX_SO_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_PO_TYPE
					 || iTransaction_typ == GlobalVar.goConstant.TRX_QUOTE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE)
				{
					if (shipped_qty >= cur_db.fSmallestNumber && shipped_qty > oUtility.ToValue(new_qty))
					{
						grid_item.txtOrdered_qty = grid_item.txtShipped_qty;
						new_qty = grid_item.txtShipped_qty;
					}
				}

				if (oUtility.ToValue(new_qty) < 0)
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NEGATIVE_VALUE_NOT_ALLOWED);
					return false;

				}

				//  Only S/O & P/O accept multiple qty for a serial item
				//
				if (oUtility.IsNonEmpty(item_code) && iTransaction_typ != GlobalVar.goConstant.TRX_SO_TYPE && iTransaction_typ != GlobalVar.goConstant.TRX_QUOTE_TYPE 
					&& iTransaction_typ != GlobalVar.goConstant.TRX_PO_TYPE && iTransaction_typ != GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE
					&& iTransaction_typ != GlobalVar.goConstant.TRX_WH_SHIPPING_SLIP_TYPE && iTransaction_typ != GlobalVar.goConstant.TRX_WH_RECEIVING_SLIP_TYPE)     
				{
					if (o_serial.IsSerialItem(oUtility.ToInteger(grid_item.lblItem_typ)) && oUtility.ToValue(new_qty) > 1)
					{
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.SERIAL_ITEM_DOES_NOT_ALLOW_MORE_THAN_1);
						return false;
					}
				}

				if ((iTransaction_typ == GlobalVar.goConstant.TRX_INVOICE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_PURCHASE_TYPE) 
					&& oUtility.ToValue(new_qty) > order_qty && line_order_num > 0)
				{

					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.QTY_CANNOT_EXCEED_ORDERED_QTY_WHEN_ORDER_ENTERED);
					return false;

				}
				else if (oUtility.IsNonEmpty(item_code))
				{

					grid_item.lblInIVUnit_qty = oUtility.RoundToQtyFactor(oUtility.ToValue(new_qty) * iv_conversion_rate).ToString();

					if (CalculateDiscountAmount(ref cur_db, ref grid_item, ref new_qty, exchange_rate) == false)
					{
						return false;
					}

				}

				new_qty = oUtility.RoundToQtyFactor(oUtility.ToValue(new_qty)).ToString();

				if (CalculateQtyInIvUnit(ref cur_db, ref grid_item, ref new_qty) == false)
				{
					return false;
				}
				else if (iTransaction_typ == GlobalVar.goConstant.TRX_INVOICE_TYPE && line_order_num > 0)
				{
					// If from Order, do not recalc unit price
				}
				else if (CalculateUnitPrice(ref cur_db, ref grid_item, exchange_rate, customer_code, item_code, price_code, true) == false)
				{
					return false;
				}

				if (CalculateDiscountAmount(ref cur_db, ref grid_item, ref new_qty, exchange_rate) == false)
				{
					return false;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessChargeQty)");
			}

			return return_value;
		}

		public bool ProcessReturnQty(ref clsDatabase cur_db, ref clsGrid grid_item, ref string new_qty, decimal exchange_rate, string customer_code, string price_code, int invoice_num)
		{
			bool return_value = false;
			decimal old_ivqty = 0;
			decimal conversion_rate = 0;
			string item_code = "";
			int kit_id = 0;
			bool recalc_flag = false;
			decimal original_qty = 0;
			decimal prev_returned_qty = 0;
			decimal cur_returned_qty = 0;
			decimal old_qty = 0;

			clsMoney o_money = new clsMoney(ref cur_db);
			clsSerial o_serial = new clsSerial(ref cur_db);

			try
			{
				item_code = grid_item.txtItem_cd;
				old_ivqty = o_money.ToNumMoney(grid_item.lblInIVUnit_qty);
				old_qty = o_money.ToNumMoney(grid_item.txtShipped_qty);
				original_qty = o_money.ToNumMoney(grid_item.lblInvoiced_qty);
				cur_returned_qty = o_money.ToNumMoney(grid_item.lblCurrentReturned_qty);
				prev_returned_qty = o_money.ToNumMoney(grid_item.lblPreviousReturned_qty);
				conversion_rate = o_money.ToNumMoney(grid_item.lblConversion_rt);

				if (oUtility.ToValue(new_qty) < 0)
				{

					grid_item.txtShipped_qty = "";
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NEGATIVE_VALUE_NOT_ALLOWED);
					return false;

				}
				else if (oUtility.IsNonEmpty(item_code))
				{
					if (oUtility.IsNonEmpty(grid_item.txtItem_cd) && oUtility.IsInventoryItemType(oUtility.ToInteger(grid_item.lblItem_typ)))
					{
                        if (oUtility.ToValue(new_qty) < cur_returned_qty)
                        {
                            grid_item.txtShipped_qty = grid_item.lblPreviousReturned_qty;
                            modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.THIS_RETURN_IS_ALREADY_COMPLETE);
                            return false;
                        }
                    }
                    if (oUtility.IsNonEmpty(grid_item.txtItem_cd) && o_serial.IsSerialItem(oUtility.ToInteger(grid_item.lblItem_typ)) && oUtility.ToValue(new_qty) > 1)
                    {
                        grid_item.txtShipped_qty = grid_item.lblPreviousReturned_qty;
                        modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.SERIAL_ITEM_DOES_NOT_ALLOW_MORE_THAN_1);
                        return false;
                    }


                    // If this is from a specific invoice, returning qty can not exceed
                    // the original qty.
                    //
                    if (invoice_num > 0)
					{
						if (o_money.RoundToMoney(oUtility.ToValue(new_qty) + prev_returned_qty) > o_money.RoundToMoney(original_qty))
						{
							grid_item.txtShipped_qty = "";
							modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.RETURN_QTY_CANNOT_EXCEED_ORIGINAL);
							return false;
						}

						// Calculate the total cost for this item.
						//
						if (old_qty >= cur_db.fSmallestNumber)
						{
							grid_item.lblTotalCost_amt = o_money.RoundToMoney(o_money.ToNumMoney(grid_item.lblTotalCost_amt) * oUtility.ToValue(new_qty) / old_qty).ToString();
						}
					}
					else
					{
						grid_item.lblInvoiced_qty = oUtility.RoundToQtyFactor(oUtility.ToValue(new_qty)).ToString();
					}

					grid_item.lblInIVUnit_qty = oUtility.RoundToQtyFactor(oUtility.ToValue(new_qty) * conversion_rate).ToString();
					grid_item.txtShipped_qty = oUtility.RoundToQtyFactor(oUtility.ToValue(new_qty)).ToString();

					//  If this is from an existing invoice, do not calculatethe discount, again.
					//  Otherwise, do it again.
					//
					recalc_flag = (invoice_num == 0);

					if (CalculateQtyInIvUnit(ref cur_db, ref grid_item, ref new_qty) == false)
					{
						return false;
					}

					if (invoice_num == 0 && IsSalesTransaction())
					{
						if (CalculateUnitPrice(ref cur_db,ref grid_item, exchange_rate, customer_code, item_code, price_code, recalc_flag) == false)
						{
							return false;
						}
					}

					// If this memo is linked to an invoice, calculate the discount amount
					// using the originaly given discount instead of the current price.
					//
					if (invoice_num > 0)
					{
						if (old_qty < cur_db.fSmallestNumber)
						{
							grid_item.lblDiscount_amt = "0";
						}
						else if ((old_qty * oUtility.ToValue(grid_item.txtShipped_qty)) > 0)
						{
							grid_item.lblDiscount_amt = o_money.RoundToMoney(oUtility.ToValue(grid_item.lblDiscount_amt) / old_qty * oUtility.ToValue(grid_item.txtShipped_qty)).ToString();
						}
					}
					else if (IsSalesTransaction())
					{
						if (CalculateDiscountAmount(ref cur_db, ref grid_item, ref new_qty, exchange_rate) == false)
						{
							return false;
						}
					}
				}
				else
				{
					grid_item.txtShipped_qty = oUtility.RoundToQtyFactor(oUtility.ToValue(new_qty)).ToString();
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessReturnQty)");
			}

			return return_value;
		}

		public bool ProcessTaxCode(ref clsDatabase cur_db, ref clsGrid grid_item, decimal tax_perc)
		{
			bool return_value = false;
			string tax_code = "";
			decimal tmp = 0;
			clsValidate o_val = new clsValidate(ref cur_db);

			try
			{
				tax_code = modCommonUtility.CleanCode(grid_item.cboTax_cd);

				// If empty tax_code, reset tax percent.
				// However, do not reset tax_amt, here because it is done CalculateCurrentRow().
				//
				if (oUtility.IsEmpty(tax_code))
				{
					tax_code = "";
					tax_perc = 0;
					return_value = true;
				}
				else
				{
					if (IsPurchaseTransaction())
					{
						if (o_val.IsValidAPTaxCode(tax_code) == false)
						{
							grid_item.cboTax_cd = "";
							grid_item.lblTax_pc = "";
							modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oString.STR_TAX_CODE + " " + tax_code + cur_db.oLanguage.oMessage.DOES_NOT_EXIST);
							return false;
						}
					}
					else
					{
						if (o_val.IsValidARTaxCode(tax_code) == false)
						{
							grid_item.cboTax_cd = "";
							grid_item.lblTax_pc = "";
							modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oString.STR_TAX_CODE + " " + tax_code + cur_db.oLanguage.oMessage.DOES_NOT_EXIST);
							return false;
						}
					}

					if ((tax_perc >= cur_db.fSmallestNumber && o_val.oRecordset.iField("iTax_typ") == GlobalVar.goConstant.INCLUDED_TAX_NUM) 
						|| (tax_perc <= -cur_db.fSmallestNumber && o_val.oRecordset.iField("iTax_typ") == GlobalVar.goConstant.REGULAR_TAX_NUM))
					{
						grid_item.cboTax_cd = "";
						grid_item.lblTax_pc = "";
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.TWO_TAX_TYPES_ARE_NOT_ALLOWED);
						return false;
					}
					else
					{
						if (o_val.oRecordset.iField("iTax_typ") == GlobalVar.goConstant.REGULAR_TAX_NUM)
						{
							tax_perc = o_val.oRecordset.mField("fTotalTax_pc");
						}
						else
						{
							tax_perc = -o_val.oRecordset.mField("fTotalTax_pc"); // Meaning included tax
						}
						return_value = true;
					}

				}

				grid_item.cboTax_cd = tax_code;
				grid_item.lblTax_pc = tax_perc.ToString();

			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessTaxCode)");
			}

			return return_value;
		}

		public bool ProcessJobCode(ref clsDatabase cur_db, ref clsGrid grid_item, string customer_code = "")
		{
			bool return_value = false;

			string job_code = "";
			string err_msg = "";
			clsValidate o_val = new clsValidate(ref cur_db);

			job_code = modCommonUtility.CleanCode(grid_item.cboJob_cd);

			// If empty Job_code, reset Job percent.
			// However, do not reset Job_amt, here because it is done CalculateCurrentRow().
			//
			if (oUtility.IsEmpty(job_code))
			{
				job_code = "";
				return_value = true;
			}
			else if (o_val.IsValidJobForTransaction(job_code, ref err_msg, customer_code) == false)
			{
				grid_item.cboJob_cd = Data[JOB_CODE_COL, grid_item.Row_num];
				modDialogUtility.DisplayBox(ref cur_db, err_msg);
				return false;
			}
			else
			{
				return_value = true;
			}

			return return_value;
		}

		public bool ProcessPurchaseUnit(ref clsDatabase cur_db, ref clsGrid grid_item)
		{
			bool return_value = false;

			string unit_code = "";
			string item_code = "";
			decimal conversion_rate = 0;
			string ivunit_code = "";
			clsValidate o_val = new clsValidate(ref cur_db);

			unit_code = modCommonUtility.CleanCode(grid_item.txtUnit_cd);

			if (cur_db.uProgram.bIVExist_fl == false)
			{
				grid_item.txtUnit_cd = unit_code;
			}

			item_code = grid_item.txtItem_cd;
			ivunit_code = grid_item.lblIVUnit_cd;

			if (oUtility.IsEmpty(unit_code) || oUtility.IsEmpty(item_code) || !oUtility.IsInventoryItemType(oUtility.ToInteger(grid_item.lblItem_typ)))
			{
				return_value = true;
			}
			else if (o_val.IsValidUnitCode(item_code, ivunit_code, unit_code, ref conversion_rate) == false)
			{
				grid_item.txtUnit_cd = "";
				modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NO_CONVERSION_EXIST + "(" + ivunit_code + ":" + unit_code + ")");
				return false;
			}
			else
			{
				return_value = true;
			}

			grid_item.txtUnit_cd = unit_code;

			return return_value;
		}

		// Recalculate the prices according to the new exchange-rates given.
		//
		public bool RecalculateForNewExchangeRate(ref clsDatabase cur_db, decimal sale_exchange_rate, decimal old_price_change_rate, decimal new_price_change_rate, bool primary_amount_changed_fl)
        {
			bool return_value = false;
			int i = 0;
			string qty = "";

			clsGrid det = new clsGrid();
			clsMoney o_money = new clsMoney(ref cur_db);

			try
            {
				for (i = 0; i < Data.GetLength(1); i++)
				{
					if (oUtility.IsNonEmpty(Data[ITEM_CODE_COL, i]) && (Math.Abs(o_money.ToNumMoney(Data[UNIT_PRICE_COL, i])) > 0 || Math.Abs(o_money.ToNumMoney(Data[SELL_UNIT_PRICE_COL, i])) > 0))
					{
						if (FindGridLine(i, ref det) == false)
                        {
							modDialogUtility.DisplayBox(ref cur_db, "Recalculation failed (RecalculateForNewExchangeRate)");   // not expected.
							return false;
						}

						if (primary_amount_changed_fl)			// For A/R
                        {
							det.lblSellUnitPrice_amt = o_money.ToStrMoney(o_money.RoundToMoney(o_money.ToNumMoney(det.lblSellUnitPrice_amt) * new_price_change_rate / old_price_change_rate));
							det.txtUnitPriceInPrimary_amt = o_money.ToStrMoney(o_money.RoundToMoney(o_money.ToNumMoney(det.txtUnitPriceInPrimary_amt) * new_price_change_rate / old_price_change_rate));
							ProcessUnitPriceInPrimary(ref cur_db, ref det, ref Data[QUANTITY_COL, i], sale_exchange_rate, "");
						}
						else									// For A/P
                        {
							det.txtUnitPrice_amt = o_money.ToStrMoney(o_money.RoundToMoney(o_money.ToNumMoney(det.txtUnitPrice_amt) * new_price_change_rate / old_price_change_rate));
							ProcessUnitPrice(ref cur_db, ref det, ref Data[QUANTITY_COL, i], sale_exchange_rate, false);
						}

						CalculateRow(ref cur_db, ref det, ref Data[QUANTITY_COL, i], sale_exchange_rate);
					}
				}

				return_value = true;
			}
			catch (Exception ex)
            {
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(RecalculateForNewExchangeRate)");
			}

			return return_value;
		}

		public decimal CalcluateTotalQTY(string[,] detail_data, int item_code_col, int item_type_col, int qty_col)
        {
			decimal total_qty = 0;
			int row_num = 0;

			try
            {
				if (detail_data == null)
				{
					return total_qty;
				}

				if (detail_data.GetUpperBound(0) < item_code_col || detail_data.GetUpperBound(0) < item_type_col || detail_data.GetUpperBound(0) < qty_col)
				{
					return total_qty;
				}

				for (row_num = 0; row_num < detail_data.GetLength(1); row_num++)
				{
					if (oUtility.IsNonEmpty(detail_data[item_code_col, row_num]) && oUtility.IsInventoryItemType(oUtility.ToInteger(detail_data[item_type_col, row_num])))
					{
						total_qty += oUtility.ToValue(detail_data[qty_col, row_num]);
					}
				}
			}
			catch
            {
				// Just in case
            }

			return total_qty;
		}

		public bool ClearCurrentLine(int cur_row)
        {
			int col_num = 0;

			for (col_num = 0; col_num < TOTAL_COLUMNS; col_num++)
            {
				if (col_num != LINE_ID_COL)		// Exclude the line-id.  If need to reset it, let the caller handle it.
                {
					Data[col_num, cur_row] = "";
				}
			}

			RecreateGridLine(cur_row);

			return true;
        }

		public bool CheckSerialCodeAndAvailability(ref clsDatabase cur_db, clsUser cur_user, clsPage cur_page, clsGrid grid_item, int trx_num, string location_code, int source_type = 0, int source_num = 0)
        {
			bool return_value = false;
			int row_num = 0;
			decimal availlable_qty = 0;

			clsValidate o_val = new clsValidate(ref cur_db);

			try
            {
				if (oUtility.IsEmpty(grid_item.txtItem_cd))
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_user.Language.oMessage.PLEASE_ENTER + cur_user.Language.oCaption.ITEM_CODE);
					return false;
				}

				// Check for duplicate apperance.
				//
				for (row_num = 0; row_num < Data.GetLength(1); row_num++)
				{
					if (Data[ITEM_CODE_COL, row_num] == grid_item.txtItem_cd && Data[SERIAL_CODE_COL, row_num] == grid_item.txtSerial_cd && row_num != grid_item.Row_num)
					{
						modDialogUtility.DisplayBox(ref cur_db, grid_item.txtItem_cd + "/" + grid_item.txtSerial_cd + cur_user.Language.oMessage.APPEARS_MORE_THAN_ONCE);
						return false;
					}
				}

				if (o_val.IsValidSerialCode(grid_item.txtItem_cd, grid_item.txtSerial_cd, location_code, source_type, source_num) == false)
				{
					if (source_num > 0)
					{
						modDialogUtility.DisplayBox(ref cur_db, grid_item.txtItem_cd + "/" + grid_item.txtSerial_cd + cur_user.Language.oMessage.DOES_NOT_APPEAR_IN + " : " + source_num.ToString());
					}
					else
					{
						modDialogUtility.DisplayBox(ref cur_db, grid_item.txtItem_cd + "/" + grid_item.txtSerial_cd + cur_user.Language.oMessage.IS_INVALID);
					}
					return false;
				}
				else if (o_val.oRecordset.mField("fAvailable_qty") < oUtility.ToValue(grid_item.txtShipped_qty))
				{
					availlable_qty = o_val.oRecordset.mField("fAvailable_qty");        // qty in inventory

					if (cur_page.bNew_fl)
					{
						modDialogUtility.DisplayBox(ref cur_db, grid_item.txtItem_cd + "/" + grid_item.txtSerial_cd + cur_user.Language.oMessage.DOES_NOT_HAVE_ENOUGH_QTY);
						return false;
					}

					if (o_val.IsValidSerialInTransaction(cur_page.iTransaction_typ, trx_num, grid_item.txtItem_cd, grid_item.txtSerial_cd))
					{
						availlable_qty += o_val.oRecordset.mField("fQty");             // Make sure to account the qty committed in previous saving
					}

					if (availlable_qty < oUtility.ToValue(grid_item.txtShipped_qty))
					{
						modDialogUtility.DisplayBox(ref cur_db, grid_item.txtItem_cd + "/" + grid_item.txtSerial_cd + cur_user.Language.oMessage.DOES_NOT_HAVE_ENOUGH_QTY);
						return false;
					}
				}

				return_value = true;
			}
			catch (Exception ex)
            {
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CheckSerialCodeAndAvailability)");
			}

			return return_value;
        }
	}

}
