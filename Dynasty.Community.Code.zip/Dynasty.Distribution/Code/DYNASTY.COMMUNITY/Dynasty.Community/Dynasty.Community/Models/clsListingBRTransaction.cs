﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Dynasty.Database;

namespace Dynasty.ASP.Models
{
    public class clsListingBRTransaction
    {
        clsDynastyUtility oUtility = new clsDynastyUtility();

        public bool Clear()
        {
            bool return_value = false;

            try
            {
                Grid.Clear();
                return_value = true;
            }
            catch (Exception ex)
            {
                return_value = false;
            }

            return return_value;
        }
        public bool Show(clsDatabase cur_db, clsPage cur_page, string where_clause = "", string order_by_clause = "")
        {
            string sql_str;

            clsRecordset cur_set = new clsRecordset(ref cur_db);
            clsMoney o_money = new clsMoney(ref cur_db);

            Grid.Clear();

            sql_str = "SELECT * FROM " + cur_page.sTable_nm;

            if (oUtility.IsNonEmpty(where_clause))
            {
                if (oUtility.IsNonEmpty(cur_page.sRestrictionClause))
                {
                    sql_str += " WHERE " + cur_page.sRestrictionClause;
                    sql_str += " AND " + where_clause;
                }
                else
                {
                    sql_str += " WHERE " + where_clause;
                }
            }
            else if (oUtility.IsNonEmpty(cur_page.sRestrictionClause))
            {
                sql_str += " WHERE " + cur_page.sRestrictionClause;
            }

            if (oUtility.IsNonEmpty(order_by_clause))
            {
                sql_str += " ORDER BY " + order_by_clause;
            }
            else
            {
                sql_str += " ORDER BY " + cur_page.sKeyField_nm;
            }

            if (cur_set.CreateSnapshot(sql_str) == false)
            {
                return false;
            }
            else if (cur_set.EOF())
            {
                //modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NO_RECORDS_FOUND);
                return true;
            }

            while (cur_set.EOF() == false)
            {
                Grid.Add(new clsGrid { 
                         Transaction_num = modCommonUtility.GetFieldValue(cur_db, cur_set, "iTransaction_num", cur_page.iTransaction_typ)
                        , Status_typ = modCommonUtility.GetFieldValue(cur_db, cur_set, "iStatus_typ", cur_page.iTransaction_typ)
                        , Entry_dt = modCommonUtility.GetFieldValue(cur_db, cur_set, "iEntry_dt", cur_page.iTransaction_typ)
                        , Apply_dt = modCommonUtility.GetFieldValue(cur_db, cur_set, "iApply_dt", cur_page.iTransaction_typ)
                        , Transaction_cd = modCommonUtility.GetFieldValue(cur_db, cur_set, "sTransaction_cd", cur_page.iTransaction_typ)
                        , Deposit_num = modCommonUtility.GetFieldValue(cur_db, cur_set, "iDeposit_num", cur_page.iTransaction_typ)
                        , Description = modCommonUtility.GetFieldValue(cur_db, cur_set, "sDescription", cur_page.iTransaction_typ)
                        , Reference = modCommonUtility.GetFieldValue(cur_db, cur_set, "sReference", cur_page.iTransaction_typ)
                        , YourReference = modCommonUtility.GetFieldValue(cur_db, cur_set, "sYourReference", cur_page.iTransaction_typ)
                        , Document_num = modCommonUtility.GetFieldValue(cur_db, cur_set, "sDocument_num", cur_page.iTransaction_typ)
                        , FromBank_cd = modCommonUtility.GetFieldValue(cur_db, cur_set, "sFromBank_cd", cur_page.iTransaction_typ)
                        , Bank_cd = modCommonUtility.GetFieldValue(cur_db, cur_set, "sBank_cd", cur_page.iTransaction_typ)
                        , Owner_nm = modCommonUtility.GetFieldValue(cur_db, cur_set, "sOwner_nm", cur_page.iTransaction_typ)
                        , Currency_cd = modCommonUtility.GetFieldValue(cur_db, cur_set, "sCurrency_cd", cur_page.iTransaction_typ)
                        , Foreign_amt = modCommonUtility.GetFieldValue(cur_db, cur_set, "Foreign_amt", cur_page.iTransaction_typ)
                        , Primary_amt = modCommonUtility.GetFieldValue(cur_db, cur_set, "mPrimary_amt", cur_page.iTransaction_typ)
                        , CheckPrinted_num = modCommonUtility.GetFieldValue(cur_db, cur_set, "iCheckPrinted_num", cur_page.iTransaction_typ)
                        , Fee_amt = modCommonUtility.GetFieldValue(cur_db, cur_set, "mFee_amt", cur_page.iTransaction_typ)
                        , Fund_cd = modCommonUtility.GetFieldValue(cur_db, cur_set, "sFund_cd", cur_page.iTransaction_typ)
                        , Tax_amt = modCommonUtility.GetFieldValue(cur_db, cur_set, "mTax_amt", cur_page.iTransaction_typ)
                        , Journal_typ = modCommonUtility.GetFieldValue(cur_db, cur_set, "iJournal_typ", cur_page.iTransaction_typ)
                });

                cur_set.MoveNext();
            }

            return true;
        }

        public class clsGrid
        {
            public string Transaction_num { get; set; } = "";
            public string Status_typ { get; set; } = "";
            public string Entry_dt { get; set; } = "";
            public string Apply_dt { get; set; } = "";
            public string Transaction_cd { get; set; } = "";
            public string Deposit_num { get; set; } = "";
            public string Description { get; set; } = "";
            public string Reference { get; set; } = "";
            public string YourReference { get; set; } = "";
            public string Document_num { get; set; } = "";
            public string FromBank_cd { get; set; } = "";
            public string Bank_cd { get; set; } = "";
            public string Owner_nm { get; set; } = "";
            public string Currency_cd { get; set; } = "";
            public string Foreign_amt { get; set; } = "";
            public string Primary_amt { get; set; } = "";
            public string CheckPrinted_num { get; set; } = "";
            public string Fee_amt { get; set; } = "";
            public string Fund_cd { get; set; } = "";
            public string Tax_amt { get; set; } = "";
            public string Journal_typ { get; set; } = "";
        }
        public List<clsGrid> Grid = new List<clsGrid>();

    }

}
