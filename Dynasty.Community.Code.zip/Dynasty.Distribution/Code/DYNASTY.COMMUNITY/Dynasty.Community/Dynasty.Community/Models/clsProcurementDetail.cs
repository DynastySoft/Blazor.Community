﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//



using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Collections.Generic;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP.Models
{
	public class clsProcurementDetail
	{
		private int iTransaction_typ = 0;
		public int iTransaction_num = 0;						// Optional.  Used in S/O last price searching
		private string sPostingError = "";

		private clsArray oArray = new clsArray();
		private clsDynastyUtility oUtility = new clsDynastyUtility();

		// QUANTITY_COL shows the quantity column that that shows the transaction quantity.
		//
		int _qty_col = 0;
        public int QUANTITY_COL
		{
            get { return _qty_col; }
        }

        public clsProcurementDetail(int trx_type) : base()
		{
			iTransaction_typ = trx_type;

			if (iTransaction_typ == GlobalVar.goConstant.TRX_INVOICE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_CM_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_WH_SHIPPING_SLIP_TYPE
			|| iTransaction_typ == GlobalVar.goConstant.TRX_PURCHASE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_DM_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_WH_RECEIVING_SLIP_TYPE)
			{
				_qty_col = QTY_SHIPPED_COL;
			}
			else
            {
				_qty_col = QTY_ORDERED_COL;
			}
		}

		public bool IsErrorFound()
		{
			bool return_value = false;

			return_value = (oUtility.IsNonEmpty(sPostingError));

			return return_value;
			return return_value;
		}

		public string GetErrorMessage()
		{
			string return_value = "";

			return_value = sPostingError;
			sPostingError = "";

			return return_value;
		}

		public void SetPostingError(string error_msg)
		{
			if (oUtility.IsEmpty(error_msg))
			{
				sPostingError = "";
			}
			else if (oUtility.IsEmpty(sPostingError))
			{
				sPostingError = error_msg;
			}
			else if (oUtility.STrim(sPostingError) != oUtility.STrim(error_msg))
			{
				sPostingError += Environment.NewLine + Environment.NewLine + "AND " + error_msg;
			}
		}
		// When serial/lot items are entered, iNextLine_id will link to each item in the serial/lot list.
		// Once iNextLine_id assigned, it does not changed and maintain the uniqueness during the course of line manipulations such as delete/insert.
		//
		public int iNextLine_id = 1;
		public int iNextKit_id = 1;
		public int iTotalRows = 0;

        public string[] FieldName;                                                              // Keeps the detail field names;
		public string[,] Data;																	// Keeps the detail data.

		public const int ITEM_CODE_COL = 0;
		public const int LOCATION_COL = 1;
		public const int DESCRIPTION_COL = 2;
		public const int UNIT_CODE_COL = 3;
		public const int QTY_ORDERED_COL = 4;
		public const int QTY_SHIPPED_COL = 5;
		public const int QTY_BACKORDER_COL = 6;
		public const int UNIT_PRICE_COL = 7;
		public const int AMT_EXTENDED_COL = 8;
		public const int AMT_TAX_COL = 9;
		public const int UNIT_PRICE_IN_PRIMARY_CURRENCY_COL = 10;
		public const int AMT_EXTENDED_IN_PRIMARY_CURRENCY_COL = 11;
		public const int AMT_TAX_IN_PRIMARY_CURRENCY_COL = 12;
		public const int JOB_CODE_COL = 13;
		public const int TAX_CODE_COL = 14;
		public const int TAX_PERC_COL = 15;
		public const int QTY_IN_IVUNIT_COL = 16;
		public const int IVUNIT_CODE_COL = 17;
		public const int ITEM_TYPE_COL = 18;
		public const int CONVERSION_RATE_COL = 19;
		public const int LINE_ID_COL = 20;
		public const int DATE_REQUIRED_COL = 21;
		public const int VENDOR_ITEM_CODE_COL = 22;
		public const int PRIMARY_ITEM_CODE_COL = 23;
		public const int SOURCE_TYPE_COL = 24;
		public const int SOURCE_NUM_COL = 25;
		public const int SOURCE_DETAIL_ID_COL = 26;
		public const int COMMENT_COL = 27;
		public const int LINE_TYPE_COL = 28;
		public const int PO_NUM_COL = 29;

		public const int VENDOR1_CODE_COL = 30;
		public const int VENDOR1_NAME_COL = 31;
		public const int TERMS1_CODE_COL = 32;
		public const int UNIT_PRICE1_AMT_COL = 33;
		public const int EXTENDED1_AMT_COL = 34;
		public const int DELIVERY1_DATE_COL = 35;
		public const int VENDOR2_CODE_COL = 36;
		public const int VENDOR2_NAME_COL = 37;
		public const int TERMS2_CODE_COL = 38;
		public const int UNIT_PRICE2_AMT_COL = 39;
		public const int EXTENDED2_AMT_COL = 40;
		public const int DELIVERY2_DATE_COL = 41;
		public const int VENDOR3_CODE_COL = 42;
		public const int VENDOR3_NAME_COL = 43;
		public const int TERMS3_CODE_COL = 44;
		public const int UNIT_PRICE3_AMT_COL = 45;
		public const int EXTENDED3_AMT_COL = 46;
		public const int DELIVERY3_DATE_COL = 47;
		public const int VENDOR4_CODE_COL = 48;
		public const int VENDOR4_NAME_COL = 49;
		public const int TERMS4_CODE_COL = 50;
		public const int UNIT_PRICE4_AMT_COL = 51;
		public const int EXTENDED4_AMT_COL = 52;
		public const int DELIVERY4_DATE_COL = 53;
		public const int VENDOR5_CODE_COL = 54;
		public const int VENDOR5_NAME_COL = 55;
		public const int TERMS5_CODE_COL = 56;
		public const int UNIT_PRICE5_AMT_COL = 57;
		public const int EXTENDED5_AMT_COL = 58;
		public const int DELIVERY5_DATE_COL = 59;

		public const int COMPLETE_COL = 60;						// Line complete
		public const int INCLUDE1_COL = 61;						// Vendor inclusion
		public const int INCLUDE2_COL = 62;
		public const int INCLUDE3_COL = 63;
		public const int INCLUDE4_COL = 64;
		public const int INCLUDE5_COL = 65;

		public const int TOTAL_COLUMNS = 66;

		public class clsGrid
		{
			public int Row_num = 0;                                 // 0-based row number. This will identify each row.
			public string txtItem_cd = "";
			public string lblLocation_cd = "";
			public string txtDescription = "";
			public string txtUnit_cd = "";
			public string txtOrdered_qty = "";
			public string txtShipped_qty = "";
			public string lblBackorder_qty = "";
			public string txtUnitPrice_amt = "";
			public string lblExtended_amt = "";
			public string txtTax_amt = "";
			public string txtUnitPriceInPrimary_amt = "";
			public string lblExtendedInPrimary_amt = "";
			public string lblTaxInPrimary_amt = "";
			public string cboJob_cd = "";
			public string cboTax_cd = "";
			public string lblTax_pc = "";
			public string lblInIVUnit_qty = "";
			public string lblIVUnit_cd = "";
			public string lblItem_typ = "";
			public string lblConversion_rt = "";
			public string lblLine_id = "";
			public string txtRequired_dt = "";                          
			public string txtVendorItem_cd = "";
			public string lblPrimaryItem_cd = "";
			public string lblSource_typ = "";                           
			public string lblSource_num = "";
			public string lblSourceDetail_num = "";
			public string txtComment = "";
			public string lblLine_typ = "";
			public string lblPO_num = "";

			public string lblVendor1_cd = "";
			public string lblVendor1_nm = "";
			public string lblTerms1_cd = "";
			public string lblUnitPrice1_amt = "";
			public string lblExtended1_amt = "";
			public string lblDelivery1_dt = "";

			public string lblVendor2_cd = "";
			public string lblVendor2_nm = "";
			public string lblTerms2_cd = "";
			public string lblUnitPrice2_amt = "";
			public string lblExtended2_amt = "";
			public string lblDelivery2_dt = "";

			public string lblVendor3_cd = "";
			public string lblVendor3_nm = "";
			public string lblTerms3_cd = "";
			public string lblUnitPrice3_amt = "";
			public string lblExtended3_amt = "";
			public string lblDelivery3_dt = "";

			public string lblVendor4_cd = "";
			public string lblVendor4_nm = "";
			public string lblTerms4_cd = "";
			public string lblUnitPrice4_amt = "";
			public string lblExtended4_amt = "";
			public string lblDelivery4_dt = "";

			public string lblVendor5_cd = "";
			public string lblVendor5_nm = "";
			public string lblTerms5_cd = "";
			public string lblUnitPrice5_amt = "";
			public string lblExtended5_amt = "";
			public string lblDelivery5_dt = "";

			public bool chkComplete_fl = false;
			public bool chkInclude1_fl = false;
			public bool chkInclude2_fl = false;
			public bool chkInclude3_fl = false;
			public bool chkInclude4_fl = false;
			public bool chkInclude5_fl = false;

            public DateTime? dtRequired_dt = null;      // This is only for UI

            // For future use.
            //
            //public string txtUserDefined1 = "";
            //public string txtUserDefined2 = "";
            //public string txtUserDefined3 = "";
            //public string txtUserDefined4 = "";
            //public string txtUserDefined5 = "";
            //public string txtUserDefined1_amt = "";
            //public string txtUserDefined2_amt = "";
            //public string txtUserDefined3_amt = "";
            //public string txtUserDefined4_amt = "";
            //public string txtUserDefined5_amt = "";
            //public string txtUserDefined1_dt = "";
            //public string txtUserDefined2_dt = "";
            //public string txtUserDefined3_dt = "";
            //public string txtUserDefined4_dt = "";
            //public string txtUserDefined5_dt = "";
            //public string txtUserDefined1_num = "";
            //public string txtUserDefined2_num = "";
            //public string txtUserDefined3_num = "";
            //public string txtUserDefined4_num = "";
            //public string txtUserDefined5_num = "";

        }
        public List<clsGrid> Grid = new List<clsGrid>();

		public bool AddMoreRows(int lines_to_add = 10)
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
                // oUtility.ResizeDimPreserved(ref Data, Data.GetUpperBound(0), Data.GetUpperBound(1) + lines_to_add);

                for (row_num = 0; row_num < lines_to_add; row_num++)
                {
                    Grid.Add(new clsGrid { Row_num = iTotalRows
							, txtItem_cd = ""
							, lblLocation_cd = ""
							, txtDescription = ""
							, txtUnit_cd = ""
							, txtOrdered_qty = ""
							, txtShipped_qty = ""
							, lblBackorder_qty = ""
							, txtUnitPrice_amt = ""
							, lblExtended_amt = ""
							, txtTax_amt = ""
							, txtUnitPriceInPrimary_amt = ""
							, lblExtendedInPrimary_amt = ""
							, lblTaxInPrimary_amt = ""
							, cboJob_cd = ""
							, cboTax_cd = ""
							, lblTax_pc = ""
							, lblInIVUnit_qty = ""
							, lblIVUnit_cd = ""
							, lblItem_typ = ""
							, lblConversion_rt = ""
							, lblLine_id = ""
							, txtRequired_dt = ""                          
							, txtVendorItem_cd = ""
							, lblPrimaryItem_cd = ""
							, lblSource_typ = ""                           
							, lblSource_num = ""
							, lblSourceDetail_num = ""
							, txtComment = ""
							, lblLine_typ = ""
							, lblPO_num = ""

							, lblVendor1_cd = ""
							, lblVendor1_nm = ""
							, lblTerms1_cd = ""
							, lblUnitPrice1_amt = ""
							, lblExtended1_amt = ""
							, lblDelivery1_dt = ""

							, lblVendor2_cd = ""
							, lblVendor2_nm = ""
							, lblTerms2_cd = ""
							, lblUnitPrice2_amt = ""
							, lblExtended2_amt = ""
							, lblDelivery2_dt = ""

							, lblVendor3_cd = ""
							, lblVendor3_nm = ""
							, lblTerms3_cd = ""
							, lblUnitPrice3_amt = ""
							, lblExtended3_amt = ""
							, lblDelivery3_dt = ""

							, lblVendor4_cd = ""
							, lblVendor4_nm = ""
							, lblTerms4_cd = ""
							, lblUnitPrice4_amt = ""
							, lblExtended4_amt = ""
							, lblDelivery4_dt = ""

							, lblVendor5_cd = ""
							, lblVendor5_nm = ""
							, lblTerms5_cd = ""
							, lblUnitPrice5_amt = ""
							, lblExtended5_amt = ""
							, lblDelivery5_dt = ""

							, chkComplete_fl = false
							, chkInclude1_fl = false
							, chkInclude2_fl = false
							, chkInclude3_fl = false
							, chkInclude4_fl = false
							, chkInclude5_fl = false

							, dtRequired_dt = null

						//, txtUserDefined1 = ""
						//, txtUserDefined2 = ""
						//, txtUserDefined3 = ""
						//, txtUserDefined4 = ""
						//, txtUserDefined5 = ""
						//, txtUserDefined1_amt = ""
						//, txtUserDefined2_amt = ""
						//, txtUserDefined3_amt = ""
						//, txtUserDefined4_amt = ""
						//, txtUserDefined5_amt = ""
						//, txtUserDefined1_dt = ""
						//, txtUserDefined2_dt = ""
						//, txtUserDefined3_dt = ""
						//, txtUserDefined4_dt = ""
						//, txtUserDefined5_dt = ""
						//, txtUserDefined1_num = ""
						//, txtUserDefined2_num = ""
						//, txtUserDefined3_num = ""
						//, txtUserDefined4_num = ""
						//, txtUserDefined5_num = ""

					});;;

                    iTotalRows += 1;
					iNextLine_id += 1;

				}
                
                RecreateDetail();
                return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (AddMoreRows)");
				RecreateDetail();
            }

            return return_value;
        }

		public bool InsertNewRow(clsGrid cur_item, int at_row_num = -1)
        {
			bool return_value = false;

			if (at_row_num < 0)
            {
				at_row_num = cur_item.Row_num;
			}

            try
            {
				Grid.Insert(at_row_num, new clsGrid { Row_num = -1
							, txtItem_cd = ""
							, lblLocation_cd = ""
							, txtDescription = ""
							, txtUnit_cd = ""
							, txtOrdered_qty = ""
							, txtShipped_qty = ""
							, lblBackorder_qty = ""
							, txtUnitPrice_amt = ""
							, lblExtended_amt = ""
							, txtTax_amt = ""
							, txtUnitPriceInPrimary_amt = ""
							, lblExtendedInPrimary_amt = ""
							, lblTaxInPrimary_amt = ""
							, cboJob_cd = ""
							, cboTax_cd = ""
							, lblTax_pc = ""
							, lblInIVUnit_qty = ""
							, lblIVUnit_cd = ""
							, lblItem_typ = ""
							, lblConversion_rt = ""
							, lblLine_id = ""
							, txtRequired_dt = ""                          
							, txtVendorItem_cd = ""
							, lblPrimaryItem_cd = ""
							, lblSource_typ = ""                           
							, lblSource_num = ""
							, lblSourceDetail_num = ""
							, txtComment = ""
							, lblLine_typ = ""
							, lblPO_num = ""

							, lblVendor1_cd = ""
							, lblVendor1_nm = ""
							, lblTerms1_cd = ""
							, lblUnitPrice1_amt = ""
							, lblExtended1_amt = ""
							, lblDelivery1_dt = ""

							, lblVendor2_cd = ""
							, lblVendor2_nm = ""
							, lblTerms2_cd = ""
							, lblUnitPrice2_amt = ""
							, lblExtended2_amt = ""
							, lblDelivery2_dt = ""

							, lblVendor3_cd = ""
							, lblVendor3_nm = ""
							, lblTerms3_cd = ""
							, lblUnitPrice3_amt = ""
							, lblExtended3_amt = ""
							, lblDelivery3_dt = ""

							, lblVendor4_cd = ""
							, lblVendor4_nm = ""
							, lblTerms4_cd = ""
							, lblUnitPrice4_amt = ""
							, lblExtended4_amt = ""
							, lblDelivery4_dt = ""

							, lblVendor5_cd = ""
							, lblVendor5_nm = ""
							, lblTerms5_cd = ""
							, lblUnitPrice5_amt = ""
							, lblExtended5_amt = ""
							, lblDelivery5_dt = ""

							, chkComplete_fl = false
							, chkInclude1_fl = false
							, chkInclude2_fl = false
							, chkInclude3_fl = false
							, chkInclude4_fl = false
							, chkInclude5_fl = false
							
							, dtRequired_dt = null

							//, txtUserDefined1 = ""
							//, txtUserDefined2 = ""
							//, txtUserDefined3 = ""
							//, txtUserDefined4 = ""
							//, txtUserDefined5 = ""
							//, txtUserDefined1_amt = ""
							//, txtUserDefined2_amt = ""
							//, txtUserDefined3_amt = ""
							//, txtUserDefined4_amt = ""
							//, txtUserDefined5_amt = ""
							//, txtUserDefined1_dt = ""
							//, txtUserDefined2_dt = ""
							//, txtUserDefined3_dt = ""
							//, txtUserDefined4_dt = ""
							//, txtUserDefined5_dt = ""
							//, txtUserDefined1_num = ""
							//, txtUserDefined2_num = ""
							//, txtUserDefined3_num = ""
							//, txtUserDefined4_num = ""
							//, txtUserDefined5_num = ""

                });;

                Grid.Where(i => i.Row_num >= at_row_num).Select(i => { i.Row_num += 1; return i; }).ToList();
                Grid.Single(i => i.Row_num == -1).Row_num = at_row_num;

				iNextLine_id += 1;
				iTotalRows += 1;

				RecreateDetail();

                return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (InsertNewRow)");
            }

            return return_value;
        }
		public bool DeleteCurrentRow(clsGrid cur_item)
        {
			bool return_value = false;
			int old_num = cur_item.Row_num;

			try
			{
				Grid.RemoveAt(cur_item.Row_num);
				Grid.Where(i => i.Row_num >= old_num).Select(i => { i.Row_num -= 1; return i; }).ToList();

				iTotalRows -= 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
            {
				SetPostingError(ex.Message + " (DeleteCurrentRow)");
			}

			return return_value;
		}

		public bool RecreateDetail()                                                           //  Sync Data with Grid for the items that do not have event-handler ONLY.
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				if (Grid.Count() == 0)
				{
					oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), 0);
					return true;
				}

				// We need to create it here for saving because some fields may not have been copied into the array.
				//
				iTotalRows = Grid.Count();
				oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), iTotalRows - 1);

				foreach (var det in Grid)
				{
					if (RecreateDetailLine(det, row_num) == false)
					{
						return false;
					}

					det.Row_num = row_num;      // Just to make sure.
					row_num++;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetail)");
			}

			return return_value;
		}

		public bool RecreateGridLine(int row_num)
		{
			bool return_value = false;
			clsGrid grid_line = new clsGrid();

			if (FindGridLine(row_num, ref grid_line) == false)
			{
				SetPostingError("Grid does not match array.");
				return false;
			}

			return RecreateGridLine(ref grid_line, row_num);
		}

		public bool RecreateGridLine(ref clsGrid cur_item, int row_num)
        {
			bool return_value = false;

			try
            {
				cur_item.txtItem_cd = Data[ITEM_CODE_COL, row_num];
				cur_item.lblLocation_cd = Data[LOCATION_COL, row_num];
				cur_item.txtDescription = Data[DESCRIPTION_COL, row_num];
				cur_item.txtUnit_cd = Data[UNIT_CODE_COL, row_num];
				cur_item.txtOrdered_qty = Data[QTY_ORDERED_COL, row_num];
				cur_item.txtShipped_qty = Data[QTY_SHIPPED_COL, row_num];
				cur_item.lblBackorder_qty = Data[QTY_BACKORDER_COL, row_num];
				cur_item.txtUnitPrice_amt = Data[UNIT_PRICE_COL, row_num];
				cur_item.lblExtended_amt = Data[AMT_EXTENDED_COL, row_num];
				cur_item.txtTax_amt = Data[AMT_TAX_COL, row_num];
				cur_item.txtUnitPriceInPrimary_amt = Data[UNIT_PRICE_IN_PRIMARY_CURRENCY_COL, row_num];
				cur_item.lblExtendedInPrimary_amt = Data[AMT_EXTENDED_IN_PRIMARY_CURRENCY_COL, row_num];
				cur_item.lblTaxInPrimary_amt = Data[AMT_TAX_IN_PRIMARY_CURRENCY_COL, row_num];
				cur_item.cboJob_cd = Data[JOB_CODE_COL, row_num];
				cur_item.cboTax_cd = Data[TAX_CODE_COL, row_num];
				cur_item.lblTax_pc = Data[TAX_PERC_COL, row_num];
				cur_item.lblInIVUnit_qty = Data[QTY_IN_IVUNIT_COL, row_num];
				cur_item.lblIVUnit_cd = Data[IVUNIT_CODE_COL, row_num];
				cur_item.lblItem_typ = Data[ITEM_TYPE_COL, row_num];
				cur_item.lblConversion_rt = Data[CONVERSION_RATE_COL, row_num];
				cur_item.lblLine_id = Data[LINE_ID_COL, row_num];
				cur_item.txtRequired_dt = Data[DATE_REQUIRED_COL, row_num];
				cur_item.txtVendorItem_cd = Data[VENDOR_ITEM_CODE_COL, row_num];
				cur_item.lblPrimaryItem_cd = Data[PRIMARY_ITEM_CODE_COL, row_num];
				cur_item.lblSource_typ = Data[SOURCE_TYPE_COL, row_num];
				cur_item.lblSource_num = Data[SOURCE_NUM_COL, row_num];
				cur_item.lblSourceDetail_num = Data[SOURCE_DETAIL_ID_COL, row_num];
				cur_item.txtComment = Data[COMMENT_COL, row_num];
				cur_item.lblLine_typ = Data[LINE_TYPE_COL, row_num];
				cur_item.lblPO_num = Data[PO_NUM_COL, row_num];

				cur_item.lblVendor1_cd = Data[VENDOR1_CODE_COL, row_num];
				cur_item.lblVendor1_nm = Data[VENDOR1_NAME_COL, row_num];
				cur_item.lblTerms1_cd = Data[TERMS1_CODE_COL, row_num];
				cur_item.lblUnitPrice1_amt = Data[UNIT_PRICE1_AMT_COL, row_num];
				cur_item.lblExtended1_amt = Data[EXTENDED1_AMT_COL, row_num];
				cur_item.lblDelivery1_dt = Data[DELIVERY1_DATE_COL, row_num];

				cur_item.lblVendor2_cd = Data[VENDOR2_CODE_COL, row_num];
				cur_item.lblVendor2_nm = Data[VENDOR2_NAME_COL, row_num];
				cur_item.lblTerms2_cd = Data[TERMS2_CODE_COL, row_num];
				cur_item.lblUnitPrice2_amt = Data[UNIT_PRICE2_AMT_COL, row_num];
				cur_item.lblExtended2_amt = Data[EXTENDED2_AMT_COL, row_num];
				cur_item.lblDelivery2_dt = Data[DELIVERY2_DATE_COL, row_num];

				cur_item.lblVendor3_cd = Data[VENDOR3_CODE_COL, row_num];
				cur_item.lblVendor3_nm = Data[VENDOR3_NAME_COL, row_num];
				cur_item.lblTerms3_cd = Data[TERMS3_CODE_COL, row_num];
				cur_item.lblUnitPrice3_amt = Data[UNIT_PRICE3_AMT_COL, row_num];
				cur_item.lblExtended3_amt = Data[EXTENDED3_AMT_COL, row_num];
				cur_item.lblDelivery3_dt = Data[DELIVERY3_DATE_COL, row_num];

				cur_item.lblVendor4_cd = Data[VENDOR4_CODE_COL, row_num];
				cur_item.lblVendor4_nm = Data[VENDOR4_NAME_COL, row_num];
				cur_item.lblTerms4_cd = Data[TERMS4_CODE_COL, row_num];
				cur_item.lblUnitPrice4_amt = Data[UNIT_PRICE4_AMT_COL, row_num];
				cur_item.lblExtended4_amt = Data[EXTENDED4_AMT_COL, row_num];
				cur_item.lblDelivery4_dt = Data[DELIVERY4_DATE_COL, row_num];

				cur_item.lblVendor5_cd = Data[VENDOR5_CODE_COL, row_num];
				cur_item.lblVendor5_nm = Data[VENDOR5_NAME_COL, row_num];
				cur_item.lblTerms5_cd = Data[TERMS5_CODE_COL, row_num];
				cur_item.lblUnitPrice5_amt = Data[UNIT_PRICE5_AMT_COL, row_num];
				cur_item.lblExtended5_amt = Data[EXTENDED5_AMT_COL, row_num];
				cur_item.lblDelivery5_dt = Data[DELIVERY5_DATE_COL, row_num];

				cur_item.chkComplete_fl = (oUtility.ToInteger(Data[COMPLETE_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON);
				cur_item.chkInclude1_fl = (oUtility.ToInteger(Data[INCLUDE1_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON);
				cur_item.chkInclude2_fl = (oUtility.ToInteger(Data[INCLUDE2_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON);
				cur_item.chkInclude3_fl = (oUtility.ToInteger(Data[INCLUDE3_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON);
				cur_item.chkInclude4_fl = (oUtility.ToInteger(Data[INCLUDE4_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON);
				cur_item.chkInclude5_fl = (oUtility.ToInteger(Data[INCLUDE5_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON);

                cur_item.dtRequired_dt = (oUtility.IsNonEmpty(Data[DATE_REQUIRED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_REQUIRED_COL, row_num]) : null);

                //cur_item.txtUserDefined1 = Data[USER_DEFINED1_COL, row_num];
                //cur_item.txtUserDefined2 = Data[USER_DEFINED2_COL, row_num];
                //cur_item.txtUserDefined3 = Data[USER_DEFINED3_COL, row_num];
                //cur_item.txtUserDefined4 = Data[USER_DEFINED4_COL, row_num];
                //cur_item.txtUserDefined5 = Data[USER_DEFINED5_COL, row_num];
                //cur_item.txtUserDefined1_amt = Data[USER_DEFINED1_AMT_COL, row_num];
                //cur_item.txtUserDefined2_amt = Data[USER_DEFINED2_AMT_COL, row_num];
                //cur_item.txtUserDefined3_amt = Data[USER_DEFINED3_AMT_COL, row_num];
                //cur_item.txtUserDefined4_amt = Data[USER_DEFINED4_AMT_COL, row_num];
                //cur_item.txtUserDefined5_amt = Data[USER_DEFINED5_AMT_COL, row_num];
                //cur_item.txtUserDefined1_dt = Data[USER_DEFINED1_DT_COL, row_num];
                //cur_item.txtUserDefined2_dt = Data[USER_DEFINED2_DT_COL, row_num];
                //cur_item.txtUserDefined3_dt = Data[USER_DEFINED3_DT_COL, row_num];
                //cur_item.txtUserDefined4_dt = Data[USER_DEFINED4_DT_COL, row_num];
                //cur_item.txtUserDefined5_dt = Data[USER_DEFINED5_DT_COL, row_num];
                //cur_item.txtUserDefined1_num = Data[USER_DEFINED1_NUM_COL, row_num];
                //cur_item.txtUserDefined2_num = Data[USER_DEFINED2_NUM_COL, row_num];
                //cur_item.txtUserDefined3_num = Data[USER_DEFINED3_NUM_COL, row_num];
                //cur_item.txtUserDefined4_num = Data[USER_DEFINED4_NUM_COL, row_num];
                //cur_item.txtUserDefined5_num = Data[USER_DEFINED5_NUM_COL, row_num];

            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (RecreateGridLine)");
			}
			return return_value;

		}

		public bool FindGridLine(int row_num, ref clsGrid line_found)
		{
			bool return_value = false;

			try
            {
				line_found = Grid.Single(i => i.Row_num == row_num);

				if (line_found != null)
                {
					return_value = true;
				}
			}
			catch (Exception ex)
            {
				// in case not found
            }

			return return_value;
		}

		public bool RecreateDetailLine(clsGrid cur_item, int row_num = -1)
        {
            bool return_value = false;

            try
            {
				// If this is called from UI event, get the row number of current line.
				//
                if (row_num < 0)
                {
                    row_num = cur_item.Row_num;
                }

				if (oUtility.ToInteger(cur_item.lblLine_id) == 0)
                {
					if (oUtility.ToInteger(Data[LINE_ID_COL, row_num]) > 0)
                    {
						cur_item.lblLine_id = Data[LINE_ID_COL, row_num];
					}
					else
                    {
						cur_item.lblLine_id = iNextLine_id.ToString();
						iNextLine_id += 1;
					}
				}

				Data[COMPLETE_COL, row_num] = oUtility.IIf(cur_item.chkComplete_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
				Data[INCLUDE1_COL, row_num] = oUtility.IIf(cur_item.chkInclude1_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
				Data[INCLUDE2_COL, row_num] = oUtility.IIf(cur_item.chkInclude2_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
				Data[INCLUDE3_COL, row_num] = oUtility.IIf(cur_item.chkInclude3_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
				Data[INCLUDE4_COL, row_num] = oUtility.IIf(cur_item.chkInclude4_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
				Data[INCLUDE5_COL, row_num] = oUtility.IIf(cur_item.chkInclude5_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();

				Data[ITEM_CODE_COL, row_num] = cur_item.txtItem_cd;
				Data[LOCATION_COL, row_num] = cur_item.lblLocation_cd;
				Data[DESCRIPTION_COL, row_num] = cur_item.txtDescription;
				Data[UNIT_CODE_COL, row_num] = cur_item.txtUnit_cd;
				Data[QTY_ORDERED_COL, row_num] = cur_item.txtOrdered_qty;
				Data[QTY_SHIPPED_COL, row_num] = cur_item.txtShipped_qty;
				Data[QTY_BACKORDER_COL, row_num] = cur_item.lblBackorder_qty;
				Data[UNIT_PRICE_COL, row_num] = cur_item.txtUnitPrice_amt;
				Data[AMT_EXTENDED_COL, row_num] = cur_item.lblExtended_amt;
				Data[AMT_TAX_COL, row_num] = cur_item.txtTax_amt;
				Data[UNIT_PRICE_IN_PRIMARY_CURRENCY_COL, row_num] = cur_item.txtUnitPriceInPrimary_amt;
				Data[AMT_EXTENDED_IN_PRIMARY_CURRENCY_COL, row_num] = cur_item.lblExtendedInPrimary_amt;
				Data[AMT_TAX_IN_PRIMARY_CURRENCY_COL, row_num] = cur_item.lblTaxInPrimary_amt;
				Data[JOB_CODE_COL, row_num] = cur_item.cboJob_cd;
				Data[TAX_CODE_COL, row_num] = cur_item.cboTax_cd;
				Data[TAX_PERC_COL, row_num] = cur_item.lblTax_pc;
				Data[QTY_IN_IVUNIT_COL, row_num] = cur_item.lblInIVUnit_qty;
				Data[IVUNIT_CODE_COL, row_num] = cur_item.lblIVUnit_cd;
				Data[ITEM_TYPE_COL, row_num] = cur_item.lblItem_typ;
				Data[CONVERSION_RATE_COL, row_num] = cur_item.lblConversion_rt;
				Data[LINE_ID_COL, row_num] = cur_item.lblLine_id;
				Data[DATE_REQUIRED_COL, row_num] = cur_item.txtRequired_dt;
				Data[VENDOR_ITEM_CODE_COL, row_num] = cur_item.txtVendorItem_cd;
				Data[PRIMARY_ITEM_CODE_COL, row_num] = cur_item.lblPrimaryItem_cd;
				Data[SOURCE_TYPE_COL, row_num] = cur_item.lblSource_typ;
				Data[SOURCE_NUM_COL, row_num] = cur_item.lblSource_num;
				Data[SOURCE_DETAIL_ID_COL, row_num] = cur_item.lblSourceDetail_num;
				Data[COMMENT_COL, row_num] = cur_item.txtComment;
				Data[LINE_TYPE_COL, row_num] = cur_item.lblLine_typ;
				Data[PO_NUM_COL, row_num] = cur_item.lblPO_num;

				Data[VENDOR1_CODE_COL, row_num] = cur_item.lblVendor1_cd;
				Data[VENDOR1_NAME_COL, row_num] = cur_item.lblVendor1_nm;
				Data[TERMS1_CODE_COL, row_num] = cur_item.lblTerms1_cd;
				Data[UNIT_PRICE1_AMT_COL, row_num] = cur_item.lblUnitPrice1_amt;
				Data[EXTENDED1_AMT_COL, row_num] = cur_item.lblExtended1_amt;
				Data[DELIVERY1_DATE_COL, row_num] = cur_item.lblDelivery1_dt;

				Data[VENDOR2_CODE_COL, row_num] = cur_item.lblVendor2_cd;
				Data[VENDOR2_NAME_COL, row_num] = cur_item.lblVendor2_nm;
				Data[TERMS2_CODE_COL, row_num] = cur_item.lblTerms2_cd;
				Data[UNIT_PRICE2_AMT_COL, row_num] = cur_item.lblUnitPrice2_amt;
				Data[EXTENDED2_AMT_COL, row_num] = cur_item.lblExtended2_amt;
				Data[DELIVERY2_DATE_COL, row_num] = cur_item.lblDelivery2_dt;

				Data[VENDOR3_CODE_COL, row_num] = cur_item.lblVendor3_cd;
				Data[VENDOR3_NAME_COL, row_num] = cur_item.lblVendor3_nm;
				Data[TERMS3_CODE_COL, row_num] = cur_item.lblTerms3_cd;
				Data[UNIT_PRICE3_AMT_COL, row_num] = cur_item.lblUnitPrice3_amt;
				Data[EXTENDED3_AMT_COL, row_num] = cur_item.lblExtended3_amt;
				Data[DELIVERY3_DATE_COL, row_num] = cur_item.lblDelivery3_dt;

				Data[VENDOR4_CODE_COL, row_num] = cur_item.lblVendor4_cd;
				Data[VENDOR4_NAME_COL, row_num] = cur_item.lblVendor4_nm;
				Data[TERMS4_CODE_COL, row_num] = cur_item.lblTerms4_cd;
				Data[UNIT_PRICE4_AMT_COL, row_num] = cur_item.lblUnitPrice4_amt;
				Data[EXTENDED4_AMT_COL, row_num] = cur_item.lblExtended4_amt;
				Data[DELIVERY4_DATE_COL, row_num] = cur_item.lblDelivery4_dt;

				Data[VENDOR5_CODE_COL, row_num] = cur_item.lblVendor5_cd;
				Data[VENDOR5_NAME_COL, row_num] = cur_item.lblVendor5_nm;
				Data[TERMS5_CODE_COL, row_num] = cur_item.lblTerms5_cd;
				Data[UNIT_PRICE5_AMT_COL, row_num] = cur_item.lblUnitPrice5_amt;
				Data[EXTENDED5_AMT_COL, row_num] = cur_item.lblExtended5_amt;
				Data[DELIVERY5_DATE_COL, row_num] = cur_item.lblDelivery5_dt;

				Data[COMPLETE_COL, row_num] = (oUtility.IIf(cur_item.chkComplete_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF)).ToString();
				Data[INCLUDE1_COL, row_num] = (oUtility.IIf(cur_item.chkInclude1_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF)).ToString();
				Data[INCLUDE2_COL, row_num] = (oUtility.IIf(cur_item.chkInclude2_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF)).ToString();
				Data[INCLUDE3_COL, row_num] = (oUtility.IIf(cur_item.chkInclude3_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF)).ToString();
				Data[INCLUDE4_COL, row_num] = (oUtility.IIf(cur_item.chkInclude4_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF)).ToString();
				Data[INCLUDE5_COL, row_num] = (oUtility.IIf(cur_item.chkInclude5_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF)).ToString();

				//Data[USER_DEFINED1_COL, row_num] = cur_item.txtUserDefined1;
				//Data[USER_DEFINED2_COL, row_num] = cur_item.txtUserDefined2;
				//Data[USER_DEFINED3_COL, row_num] = cur_item.txtUserDefined3;
				//Data[USER_DEFINED4_COL, row_num] = cur_item.txtUserDefined4;
				//Data[USER_DEFINED5_COL, row_num] = cur_item.txtUserDefined5;
				//Data[USER_DEFINED1_AMT_COL, row_num] = cur_item.txtUserDefined1_amt;
				//Data[USER_DEFINED2_AMT_COL, row_num] = cur_item.txtUserDefined2_amt;
				//Data[USER_DEFINED3_AMT_COL, row_num] = cur_item.txtUserDefined3_amt;
				//Data[USER_DEFINED4_AMT_COL, row_num] = cur_item.txtUserDefined4_amt;
				//Data[USER_DEFINED5_AMT_COL, row_num] = cur_item.txtUserDefined5_amt;
				//Data[USER_DEFINED1_DT_COL, row_num] = cur_item.txtUserDefined1_dt;
				//Data[USER_DEFINED2_DT_COL, row_num] = cur_item.txtUserDefined2_dt;
				//Data[USER_DEFINED3_DT_COL, row_num] = cur_item.txtUserDefined3_dt;
				//Data[USER_DEFINED4_DT_COL, row_num] = cur_item.txtUserDefined4_dt;
				//Data[USER_DEFINED5_DT_COL, row_num] = cur_item.txtUserDefined5_dt;
				//Data[USER_DEFINED1_NUM_COL, row_num] = cur_item.txtUserDefined1_num;
				//Data[USER_DEFINED2_NUM_COL, row_num] = cur_item.txtUserDefined2_num;
				//Data[USER_DEFINED3_NUM_COL, row_num] = cur_item.txtUserDefined3_num;
				//Data[USER_DEFINED4_NUM_COL, row_num] = cur_item.txtUserDefined4_num;
				//Data[USER_DEFINED5_NUM_COL, row_num] = cur_item.txtUserDefined5_num;

				return_value = true;

            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (RecreateDetailLine)");
            }

            return return_value;
        }

        public bool RecreateGrid()                                                             //  Create Grid according to Data
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
				Grid.Clear();

				if (Data == null)
                {
                    return true;
                }
                else if (Data.GetLength(1) == 0)
                {
                    return true;
                }

                iTotalRows = Data.GetLength(1);

                for (row_num = 0; row_num < iTotalRows; row_num++)
                {
					if (oUtility.ToInteger(Data[LINE_ID_COL, row_num]) == 0)
                    {
						Data[LINE_ID_COL, row_num] = iNextLine_id.ToString();
						iNextLine_id += 1;
					}

                    Grid.Add(new clsGrid { Row_num = row_num
								,txtItem_cd = Data[ITEM_CODE_COL, row_num]
								,lblLocation_cd = Data[LOCATION_COL, row_num]
								,txtDescription = Data[DESCRIPTION_COL, row_num]
								,txtUnit_cd = Data[UNIT_CODE_COL, row_num]
								,txtOrdered_qty = Data[QTY_ORDERED_COL, row_num]
								,txtShipped_qty = Data[QTY_SHIPPED_COL, row_num]
								,lblBackorder_qty = Data[QTY_BACKORDER_COL, row_num]
								,txtUnitPrice_amt = Data[UNIT_PRICE_COL, row_num]
								,lblExtended_amt = Data[AMT_EXTENDED_COL, row_num]
								,txtTax_amt = Data[AMT_TAX_COL, row_num]
								,txtUnitPriceInPrimary_amt = Data[UNIT_PRICE_IN_PRIMARY_CURRENCY_COL, row_num]
								,lblExtendedInPrimary_amt = Data[AMT_EXTENDED_IN_PRIMARY_CURRENCY_COL, row_num]
								,lblTaxInPrimary_amt = Data[AMT_TAX_IN_PRIMARY_CURRENCY_COL, row_num]
								,cboJob_cd = Data[JOB_CODE_COL, row_num]
								,cboTax_cd = Data[TAX_CODE_COL, row_num]
								,lblTax_pc = Data[TAX_PERC_COL, row_num]
								,lblInIVUnit_qty = Data[QTY_IN_IVUNIT_COL, row_num]
								,lblIVUnit_cd = Data[IVUNIT_CODE_COL, row_num]
								,lblItem_typ = Data[ITEM_TYPE_COL, row_num]
								,lblConversion_rt = Data[CONVERSION_RATE_COL, row_num]
								,lblLine_id = Data[LINE_ID_COL, row_num]
								,txtRequired_dt = Data[DATE_REQUIRED_COL, row_num]
								,txtVendorItem_cd = Data[VENDOR_ITEM_CODE_COL, row_num]
								,lblPrimaryItem_cd = Data[PRIMARY_ITEM_CODE_COL, row_num]
								,lblSource_typ = Data[SOURCE_TYPE_COL, row_num]
								,lblSource_num = Data[SOURCE_NUM_COL, row_num]
								,lblSourceDetail_num = Data[SOURCE_DETAIL_ID_COL, row_num]
								,txtComment = Data[COMMENT_COL, row_num]
								,lblLine_typ = Data[LINE_TYPE_COL, row_num]
								,lblPO_num = Data[PO_NUM_COL, row_num]

								,lblVendor1_cd = Data[VENDOR1_CODE_COL, row_num]
								,lblVendor1_nm = Data[VENDOR1_NAME_COL, row_num]
								,lblTerms1_cd = Data[TERMS1_CODE_COL, row_num]
								,lblUnitPrice1_amt = Data[UNIT_PRICE1_AMT_COL, row_num]
								,lblExtended1_amt = Data[EXTENDED1_AMT_COL, row_num]
								,lblDelivery1_dt = Data[DELIVERY1_DATE_COL, row_num]

								,lblVendor2_cd = Data[VENDOR2_CODE_COL, row_num]
								,lblVendor2_nm = Data[VENDOR2_NAME_COL, row_num]
								,lblTerms2_cd = Data[TERMS2_CODE_COL, row_num]
								,lblUnitPrice2_amt = Data[UNIT_PRICE2_AMT_COL, row_num]
								,lblExtended2_amt = Data[EXTENDED2_AMT_COL, row_num]
								,lblDelivery2_dt = Data[DELIVERY2_DATE_COL, row_num]

								,lblVendor3_cd = Data[VENDOR3_CODE_COL, row_num]
								,lblVendor3_nm = Data[VENDOR3_NAME_COL, row_num]
								,lblTerms3_cd = Data[TERMS3_CODE_COL, row_num]
								,lblUnitPrice3_amt = Data[UNIT_PRICE3_AMT_COL, row_num]
								,lblExtended3_amt = Data[EXTENDED3_AMT_COL, row_num]
								,lblDelivery3_dt = Data[DELIVERY3_DATE_COL, row_num]

								,lblVendor4_cd = Data[VENDOR4_CODE_COL, row_num]
								,lblVendor4_nm = Data[VENDOR4_NAME_COL, row_num]
								,lblTerms4_cd = Data[TERMS4_CODE_COL, row_num]
								,lblUnitPrice4_amt = Data[UNIT_PRICE4_AMT_COL, row_num]
								,lblExtended4_amt = Data[EXTENDED4_AMT_COL, row_num]
								,lblDelivery4_dt = Data[DELIVERY4_DATE_COL, row_num]

								,lblVendor5_cd = Data[VENDOR5_CODE_COL, row_num]
								,lblVendor5_nm = Data[VENDOR5_NAME_COL, row_num]
								,lblTerms5_cd = Data[TERMS5_CODE_COL, row_num]
								,lblUnitPrice5_amt = Data[UNIT_PRICE5_AMT_COL, row_num]
								,lblExtended5_amt = Data[EXTENDED5_AMT_COL, row_num]
								,lblDelivery5_dt = Data[DELIVERY5_DATE_COL, row_num]

								, chkComplete_fl = (oUtility.ToInteger(Data[COMPLETE_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON)
								, chkInclude1_fl = (oUtility.ToInteger(Data[INCLUDE1_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON)
								, chkInclude2_fl = (oUtility.ToInteger(Data[INCLUDE2_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON)
								, chkInclude3_fl = (oUtility.ToInteger(Data[INCLUDE3_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON)
								, chkInclude4_fl = (oUtility.ToInteger(Data[INCLUDE4_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON)
								, chkInclude5_fl = (oUtility.ToInteger(Data[INCLUDE5_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON)

								, dtRequired_dt = (oUtility.IsNonEmpty(Data[DATE_REQUIRED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_REQUIRED_COL, row_num]) : null)

                    //, txtUserDefined1 = Data[USER_DEFINED1_COL, row_num]
                    //, txtUserDefined2 = Data[USER_DEFINED2_COL, row_num]
                    //, txtUserDefined3 = Data[USER_DEFINED3_COL, row_num]
                    //, txtUserDefined4 = Data[USER_DEFINED4_COL, row_num]
                    //, txtUserDefined5 = Data[USER_DEFINED5_COL, row_num]
                    //, txtUserDefined1_amt = Data[USER_DEFINED1_AMT_COL, row_num]
                    //, txtUserDefined2_amt = Data[USER_DEFINED2_AMT_COL, row_num]
                    //, txtUserDefined3_amt = Data[USER_DEFINED3_AMT_COL, row_num]
                    //, txtUserDefined4_amt = Data[USER_DEFINED4_AMT_COL, row_num]
                    //, txtUserDefined5_amt = Data[USER_DEFINED5_AMT_COL, row_num]
                    //, txtUserDefined1_dt = Data[USER_DEFINED1_DT_COL, row_num]
                    //, txtUserDefined2_dt = Data[USER_DEFINED2_DT_COL, row_num]
                    //, txtUserDefined3_dt = Data[USER_DEFINED3_DT_COL, row_num]
                    //, txtUserDefined4_dt = Data[USER_DEFINED4_DT_COL, row_num]
                    //, txtUserDefined5_dt = Data[USER_DEFINED5_DT_COL, row_num]
                    //, txtUserDefined1_num = Data[USER_DEFINED1_NUM_COL, row_num]
                    //, txtUserDefined2_num = Data[USER_DEFINED2_NUM_COL, row_num]
                    //, txtUserDefined3_num = Data[USER_DEFINED3_NUM_COL, row_num]
                    //, txtUserDefined4_num = Data[USER_DEFINED4_NUM_COL, row_num]
                    //, txtUserDefined5_num = Data[USER_DEFINED5_NUM_COL, row_num]

                });
                }

				return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (RecreateGrid)");
            }

            return return_value;
        }

		public bool ProcessItemCode(ref clsDatabase cur_db, ref clsGrid grid_item,  string location_cd)
		{
			bool return_value = false;
			bool found_by_serial_num_fl = false;
			string unit_code = ""	;
			string tmp = "";
			decimal qty_available = 0;
			decimal qty_on_hand = 0;
			decimal qty_on_order = 0;
			decimal conversion_rate = 0;

			int item_type = 0;

			clsValidate o_val = new clsValidate(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);
			clsCustomer o_customer = new clsCustomer(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);
			clsSerial o_serial = new clsSerial(ref cur_db);

			try
			{
				if (oUtility.IsEmpty(grid_item.txtItem_cd))
				{
                    ClearCurrentLine(grid_item.Row_num);
					return true;
				}
				//if (oUtility.IsEmpty(location_cd))
				//{
				//	modDialogUtility.DisplayBox(ref cur_db,  cur_db.oLanguage.oMessage.ENTER_LOCATION_CODE_FIRST);
				//	return false;
				//}
				if (o_val.IsValidItemAnyCode(grid_item.txtItem_cd, location_cd, ref found_by_serial_num_fl) == false)
				{
					modDialogUtility.DisplayBox(ref cur_db,  grid_item.txtItem_cd + cur_db.oLanguage.oMessage.DOES_NOT_EXIST);
					return false;
				}

				grid_item.txtItem_cd = o_val.oRecordset.sField("sItem_cd");         // This is necessary because the item could have been found by other codes such as SKU, UPC & serial number.
				grid_item.txtDescription = o_val.oRecordset.sField("sDescription");
				grid_item.txtUnit_cd = o_val.oRecordset.sField("sPurchaseUnit_cd");
				grid_item.lblIVUnit_cd = o_val.oRecordset.sField("sIVUnit_cd");
				grid_item.lblItem_typ = o_val.oRecordset.iField("iItem_typ").ToString();

				if (oUtility.ToInteger(grid_item.lblItem_typ) >= GlobalVar.goIVConstant.SUMMARY_SALES_ITEM_TYPES)
				{
					modDialogUtility.DisplayBox(ref cur_db,  cur_db.oLanguage.oMessage.SUMMARY_ITEM_IS_NOT_ALLOWED);
					return false;
				}

				grid_item.txtUnitPrice_amt = "";
				grid_item.lblExtended_amt = "";
				grid_item.lblConversion_rt = "1";

				// Get conversion rate with inventory unit code
				//
				if (grid_item.lblIVUnit_cd == grid_item.txtUnit_cd)
                {
					conversion_rate = 1;
				}
				else if (o_val.IsValidUnitCode(grid_item.txtItem_cd, grid_item.lblIVUnit_cd, grid_item.txtUnit_cd, ref conversion_rate) == false)
				{
					modDialogUtility.DisplayBox(ref cur_db,  cur_db.oLanguage.oMessage.NO_CONVERSION_EXIST + "(" + grid_item.lblIVUnit_cd + ":" + grid_item.txtUnit_cd + ")");
					return false;
				}

				grid_item.lblConversion_rt = conversion_rate.ToString();

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db,  ex.Message + " (ProcessItemCode)");
			}

			return return_value;
		}

		public bool CalculateRow(ref clsDatabase cur_db, ref clsGrid grid_item, ref string new_qty, decimal exchange_rate = 1)
		{
			bool return_value = false;
			decimal qty_shipped = 0;
			decimal unit_price = 0;
			decimal line_tax_amt = 0;
			decimal tax_perc = 0;
			decimal amt_taxable = 0;
			decimal amt_extended = 0;
			decimal amt_nontaxable = 0;
			decimal total_tax = 0;
			decimal amt_trx = 0;
			string item_code = "";
			string tax_code = "";
			string job_code = "";
			int item_type = 0;

			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);

			try
			{
				unit_price = o_money.ToNumMoney(grid_item.txtUnitPrice_amt);
				item_type = oUtility.ToInteger(grid_item.lblItem_typ);
				item_code = grid_item.txtItem_cd;
				tax_code = grid_item.cboTax_cd;
				tax_perc = oUtility.ToValue(grid_item.lblTax_pc);
				job_code = grid_item.cboJob_cd;

				// If tax_code field is empty, then it is assummed that this item is either non-taxable or exempted.
				//
				if (oUtility.IsEmpty(tax_code))
				{
					tax_perc = 0;
				}

				//  Copy to the vars in order to handle easier in the small screen.
				//
				qty_shipped = o_money.ToNumMoney(new_qty);
				unit_price = o_money.ToNumMoney(grid_item.txtUnitPrice_amt);

				amt_extended = o_money.RoundToMoney(qty_shipped * unit_price);

				if (o_money.TooLargeDollar(amt_extended))
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.TOO_LARGE_DOLLAR);
					return return_value;
				}

				// Caluculate the tax for this line.
				//
				if (o_gen.CalcSalesTax(amt_extended, tax_perc, ref line_tax_amt, (tax_perc < 0)) == false)
				{
					return return_value;
				}

				grid_item.txtItem_cd = item_code;
				grid_item.txtTax_amt = o_money.ToStrMoney(line_tax_amt);
				grid_item.lblExtended_amt = o_money.ToStrMoney(amt_extended);
				grid_item.lblTaxInPrimary_amt = o_money.ToStrMoney(o_currency.ConvertToPrimaryCurrency(o_money.ToNumMoney(grid_item.txtTax_amt), exchange_rate));
				grid_item.lblExtendedInPrimary_amt = o_money.ToStrMoney(o_money.RoundToMoney(o_money.ToNumMoney(grid_item.txtUnitPriceInPrimary_amt) * oUtility.ToValue(new_qty)));

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (CalculateRow)");
			}

			return return_value;
		}

		public bool WithinTaxTolerance(ref clsDatabase cur_db, decimal total_taxable, decimal freight_amt, decimal tax_pc, decimal tax_entered)
		{
			bool return_value = false;
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			decimal tax_calculated = 0;

			if (cur_db.bFreightTax_fl == false)
			{
				freight_amt = 0;
			}

			if (o_gen.CalcSalesTax(total_taxable + freight_amt, tax_pc, ref tax_calculated, cur_db.bIncludeTaxInTaxableTotal_fl) == false)
			{
				return false;
			}

			// Do not allow more than 20% because it is to adjust the roundgin errors.  Otherwise, CalculateTotals() may have a problem
			// If they need to adjust a large portion of tax, they must be adjusting the freight tax.
			// If it is the case, they need to put the freight in the detail and adjust it there.
			//
			return_value = (Math.Abs(tax_calculated - tax_entered) <= (tax_calculated * 0.2M));

			return return_value;
		}

		public bool CalculateTotals(ref clsDatabase cur_db, ref decimal header_nontaxable_amt, ref decimal header_taxable_amt, ref decimal header_tax_amt, ref decimal header_discount_amt, ref decimal header_weight
			, ref decimal amt_freight_tax, bool in_primary_fl, ref decimal total_qty)
		{
			bool return_value = false;
			int i = 0;
			int total_rows = 0;
			decimal line_tax_amt = 0;
			decimal line_wight = 0;
			decimal line_discount_amt = 0;
			decimal line_extended_amt = 0;
			decimal line_tax_pc = 0;
			bool special_tax_exists = false;
			string last_tax_code = "";
			string line_tax_code = "";
			decimal last_tax_perc = 0;
			decimal amt_trx = 0;
			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			decimal detail_tax_total_amt = 0;
			decimal amt_left = 0;
			decimal detail_taxable_total_amt = 0;
			int first_taxable_line = 0;

			try
			{
				total_qty = 0;

				header_nontaxable_amt = 0;
				header_taxable_amt = 0;
				header_discount_amt = 0;
				header_weight = 0;

				special_tax_exists = false;
				last_tax_code = "";
				last_tax_perc = 0;
				detail_tax_total_amt = 0;
				detail_taxable_total_amt = 0;

				total_rows = Grid.Count;

				// 1. Get the detail totals
				// ----------------------------------------------------------------------------------------------------------------------------------------------
				foreach (var det in Grid)
				{
					line_tax_amt = 0;
					line_extended_amt = 0;
					line_discount_amt = 0;
					line_wight = 0;
					line_tax_pc = 0;
					line_tax_code = "";

					line_tax_code = det.cboTax_cd;
					line_tax_pc = oUtility.ToValue(det.lblTax_pc);

					if (in_primary_fl)
                    {
						line_tax_amt = o_money.ToNumMoney(det.lblTaxInPrimary_amt);
						line_extended_amt = o_money.ToNumMoney(det.lblExtendedInPrimary_amt);
					}
					else
                    {
						line_tax_amt = o_money.ToNumMoney(det.txtTax_amt);
						line_extended_amt = o_money.ToNumMoney(det.lblExtended_amt);
					}

					// if (header_tax_amt = 0) is entered, we will recalculate the default tax.
					// Each time tax is adjusted, the line taxes are adjusted accordingly so that, when the tax is reset, it is necessary to recalculate to default.
					// In the normal course of business, it may not happen.
					// However, in demo, tax amount can be manipulated multiple times so that it is a safe bet to recalculate the line tax.
					// And it won't take long.
					//
					//If header_tax_amt = 0 Then
					if (o_gen.CalcSalesTax(line_extended_amt, line_tax_pc, ref line_tax_amt, (line_tax_pc < 0)) == false)
					{
						return false;
					}
					//End If

					if (in_primary_fl)
					{
						det.lblTaxInPrimary_amt = line_tax_amt.ToString();
						Data[AMT_TAX_IN_PRIMARY_CURRENCY_COL, det.Row_num] = det.lblTaxInPrimary_amt;
					}
					else
					{
						det.txtTax_amt = line_tax_amt.ToString();
						Data[AMT_TAX_COL, det.Row_num] = det.txtTax_amt;
					}

					header_discount_amt += line_discount_amt;
					detail_tax_total_amt += line_tax_amt;
					header_weight += line_wight;

					if (Math.Abs(line_tax_pc) > 0)
					{
						detail_taxable_total_amt += line_extended_amt;
					}

					if (Math.Abs(line_tax_pc) > 0 && Math.Abs(last_tax_perc) > 0 && line_tax_pc != last_tax_perc)
					{
						special_tax_exists = true;
					}

					if (Math.Abs(line_tax_pc) > 0)
					{
						last_tax_code = line_tax_code;
						last_tax_perc = line_tax_pc;
					}

					if (oUtility.IsNonEmpty(line_tax_code) && Math.Abs(line_tax_pc) > 0 && line_extended_amt >= cur_db.fSmallestNumber) // do not use this--> line_tax_amt >= cur_db.fSmallestNumber Then
					{
						header_taxable_amt += line_extended_amt;

						// Included Tax
						//
						if (line_tax_pc < 0 && !cur_db.bIncludeTaxInTaxableTotal_fl)
						{
							header_taxable_amt -= line_tax_amt;
						}
					}
					else
					{
						header_nontaxable_amt += line_extended_amt;
					}

					// If the amount is too large, return false.
					//
					if (o_money.TooLargeDollar(header_nontaxable_amt + header_taxable_amt))
					{
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.TOO_LARGE_DOLLAR);
						return false;
					}

					if (oUtility.IsInventoryItemType(oUtility.ToInteger(det.lblItem_typ)))
                    {
						total_qty += oUtility.ToValue(det.txtOrdered_qty);
					}

				}

				// 2. If user enters the tax, adjust the line item tax proportionally before calculation.
				// ----------------------------------------------------------------------------------------------------------------------------------------------
				if (header_tax_amt > 0)
				{
					// For inclusive tax, taxable amount should be greater than the tax.
					//
					if (detail_taxable_total_amt <= header_tax_amt && last_tax_perc < 0 && !cur_db.bIncludeTaxInTaxableTotal_fl)
					{
						return false;
					}

					if (detail_taxable_total_amt < cur_db.mSmallestMoney_amt)
					{
						amt_freight_tax = header_tax_amt;
						amt_left = 0;
					}
					else if (header_tax_amt > amt_freight_tax)
					{
						amt_left = header_tax_amt - amt_freight_tax;
					}
					else
					{
						amt_freight_tax = 0; // If the tax entered is less than freight tax, need to wipe out freight first.
						amt_left = header_tax_amt;
					}

					first_taxable_line = -1;
					header_taxable_amt = 0; // recalculate

					foreach (var det in Grid)
					{
						line_tax_amt = 0;

						// We know taxable line has tax% on each line.
						//
						if (Math.Abs(oUtility.ToValue(det.lblTax_pc)) > 0 && o_money.ToNumMoney(det.lblExtended_amt) >= cur_db.mSmallestMoney_amt)
						{
							if (amt_left > 0)
							{
								line_tax_amt = o_money.RoundToMoney(header_tax_amt * o_money.ToNumMoney(det.lblExtended_amt) / detail_taxable_total_amt);
								header_taxable_amt += o_money.ToNumMoney(det.lblExtended_amt);

								if (amt_left >= line_tax_amt)
								{
									amt_left -= line_tax_amt;
								}
								else
								{
									line_tax_amt = amt_left;
									amt_left = 0;
								}
							}

							if (first_taxable_line < 0) // Remember the first taxable line.
							{
								first_taxable_line = i;
							}
						}

						if (in_primary_fl)
						{
							det.lblTaxInPrimary_amt = line_tax_amt.ToString();
							Data[AMT_TAX_IN_PRIMARY_CURRENCY_COL, det.Row_num] = det.lblTaxInPrimary_amt;
						}
						else
						{
							det.txtTax_amt = line_tax_amt.ToString();
							Data[AMT_TAX_COL, det.Row_num] = det.txtTax_amt;
						}

					}

					// If there is any remaining, put it on the first item possible.
					if (amt_left != 0)
					{
						foreach (var det in Grid)
						{
							if (Math.Abs(o_money.ToNumMoney(det.txtTax_amt)) > amt_left || (amt_left > 0 && o_money.ToNumMoney(det.txtTax_amt) > 0))
							{

								if (in_primary_fl)
								{
									det.lblTaxInPrimary_amt = (o_money.ToNumMoney(det.lblTaxInPrimary_amt) + amt_left).ToString();
									Data[AMT_TAX_IN_PRIMARY_CURRENCY_COL, det.Row_num] = det.lblTaxInPrimary_amt;
								}
								else
								{
									det.txtTax_amt = (o_money.ToNumMoney(det.txtTax_amt) + amt_left).ToString();
									Data[AMT_TAX_COL, det.Row_num] = det.txtTax_amt;
								}

								break;
							}
						}
					}

					if (last_tax_perc < 0 && !cur_db.bIncludeTaxInTaxableTotal_fl)
					{
						header_taxable_amt -= header_tax_amt;
					}
				}

				// 3. Finalize header_tax_amt
				// ----------------------------------------------------------------------------------------------------------------------------------------------
				if (header_taxable_amt == 0) // And header_nontaxable_amt = 0 Then ' 07/25/2017 Fex Tax may have freight tax only.
				{
					if (amt_freight_tax == 0)
					{
						header_tax_amt = 0;
					}
					else
					{
						header_tax_amt = amt_freight_tax;
					}

					// If a special tax exists, the total of the line items will be the total tax.
					//
					//ElseIf special_tax_exists Then
					//header_tax_amt = tax_total_amt
					//return_value = True

					// If not, the total of the line items may not be the same as the total tax calculated
					// from the total sales amount due to rounding error.
					//
				}
				else
				{
					// If header_tax_amt is not passed, calculate it with header_taxable_amt.  DO NOT use SUM(line tax).  The tax has to be always derived from the total amount.
					//
					if (header_tax_amt < cur_db.mSmallestMoney_amt)
					{
						if (o_gen.CalcSalesTax(header_taxable_amt, last_tax_perc, ref header_tax_amt, cur_db.bIncludeTaxInTaxableTotal_fl) == false)
						{
							return false;
						}

						header_tax_amt += amt_freight_tax;
					}
				}

				return_value = true;

			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (CalculateTotals)");
			}

			if (header_tax_amt < cur_db.mSmallestMoney_amt) // by any chance
			{
				header_tax_amt = 0;
			}

			if (header_taxable_amt < 0)
			{
				header_taxable_amt = 0; // Could happen when tax >> header_taxable_amt
			}

			return return_value;
		}

		public decimal CalculateSubTotal(ref clsDatabase cur_db, decimal taxable_amt, decimal non_taxable_amt, decimal freight_amt, decimal tax_amt, decimal tax_perc)
		{
			decimal return_value = 0;

			try
			{
				return_value = taxable_amt + non_taxable_amt + freight_amt;

				if (tax_perc >= 0 || !cur_db.bIncludeTaxInTaxableTotal_fl) // DO NOT use "tax_perc > 0" because flex-tax can be 0.
				{
					return_value += tax_amt;
				}
			}
			catch (Exception ex)
			{
				return_value = 0;
			}

			return return_value;
		}

		// Unlike al others in this page, this routine validates data in Data[,]
		// This is called right before saving only so that no need to sync grid.
		public bool CheckChargeDetail(ref clsDatabase cur_db, string header_location_code, decimal header_tax_perc)          
		{
			bool return_value = false;
			int i = 0;
			int row_num = 0;
			int item_type = 0;
			bool regular_tax_fl = false;
			bool included_tax_fl = false;
			string item_code = "";
			string unit_code = "";
			string location_code = "";
			decimal extended_amt = 0;
			decimal tax_perc = 0;
			decimal qty = 0;

			clsMoney o_money = new clsMoney(ref cur_db);
			clsSerial o_serial = new clsSerial(ref cur_db);

			try
			{
				if (header_tax_perc >= cur_db.fSmallestNumber)
				{
					regular_tax_fl = true;
				}
				else if (header_tax_perc <= -cur_db.fSmallestNumber)
				{
					included_tax_fl = true;
				}

				for (row_num = 0; row_num < Data.GetLength(1); row_num++)
				{

					item_code = Data[ITEM_CODE_COL, row_num];
					location_code = Data[LOCATION_COL, row_num];
					unit_code = Data[UNIT_CODE_COL, row_num];
					item_type = oUtility.ToInteger(Data[ITEM_TYPE_COL, row_num]);
					tax_perc = oUtility.ToValue(Data[TAX_PERC_COL, row_num]);
					extended_amt = o_money.ToNumMoney(Data[AMT_EXTENDED_COL, row_num]);

					qty = oUtility.ToValue(Data[QUANTITY_COL, row_num]);          // QUANTITY_COL is set to a proper column according to this transaction type in constructor.

					// At this point, multi-location entry is not allowed.  If location code is changed in the middle of entry at UI, details may have different location code.
					// Make sure it has correct code.
					//
					Data[LOCATION_COL, row_num] = header_location_code;

					if (oUtility.IsNonEmpty(item_code))
					{
						if (Math.Abs(qty) >= cur_db.fSmallestNumber &&  oUtility.IsNegativePriceCarryItemType(item_type) == false && oUtility.IsEmpty(unit_code))
						{
							modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.UNIT_CODE_IS_MISSING_ON_THE_LINE_NUMBER + (row_num + 1).ToString());
							return false;
						}
					}

					if (extended_amt >= cur_db.mSmallestMoney_amt)
					{
						if (tax_perc >= cur_db.fSmallestNumber)
						{
							regular_tax_fl = true;
						}
						else if (tax_perc <= -cur_db.fSmallestNumber)
						{
							included_tax_fl = true;
						}
					}
				}

				if (regular_tax_fl && included_tax_fl)
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.TWO_TAX_TYPES_ARE_NOT_ALLOWED);
					return false;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CheckChargeDetail)");
			}

			return return_value;
		}

		public bool CalculateQtyInIvUnit(ref clsDatabase cur_db, ref clsGrid grid_item, ref string new_qty)
		{
			bool return_value = false;
			string ivunit_code = "";
			string unit_code = "";
			decimal iv_conversion_rate = 0;
			string item_code = "";
			decimal qty = 0;
			decimal size_qty = 0;
			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsValidate o_val = new clsValidate(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);

			try
			{
				ivunit_code = grid_item.lblIVUnit_cd;
				unit_code = grid_item.txtUnit_cd;
				item_code = grid_item.txtItem_cd;
				qty = oUtility.ToValue(new_qty);

				if (oUtility.IsEmpty(item_code))
				{
					grid_item.lblConversion_rt = "1";

				}
				else if (ivunit_code == unit_code || !oUtility.IsInventoryItemType(oUtility.ToInteger(grid_item.lblItem_typ)))
				{
					grid_item.lblConversion_rt = "1";
					grid_item.lblInIVUnit_qty = qty.ToString();

				}
				else if (o_val.IsValidUnitCode(item_code, ivunit_code, unit_code, ref iv_conversion_rate))
				{
					grid_item.lblConversion_rt = iv_conversion_rate.ToString(); // conversion_rate_col SHOULD carry the inventory conversion rate.
					grid_item.lblInIVUnit_qty = oUtility.RoundToQtyFactor(iv_conversion_rate * qty).ToString();

				}
				else
				{
					grid_item.lblConversion_rt = "1";
					grid_item.txtUnit_cd = ivunit_code;
					grid_item.lblInIVUnit_qty = qty.ToString();
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CalculateQtyInIvUnit)");
			}

			return return_value;
		}

		// 07/07/2019
		// Discount & Unit Price is calcluated in the primary currency.  The caller should convert it to f/c.
		//
		public bool ProcessUnitPrice(ref clsDatabase cur_db, ref clsGrid grid_item, ref string new_qty, decimal exchange_rate, bool recalc_fl = false)
		{
			bool return_value = false;
			decimal unit_price = 0;

			clsMoney o_money = new clsMoney(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);
			int item_type = 0;

			try
			{
				unit_price = o_money.ToNumMoney(grid_item.txtUnitPrice_amt);

				if (recalc_fl == false)
				{
					grid_item.txtUnitPriceInPrimary_amt = o_money.ToStrMoney(o_currency.ConvertToPrimaryCurrency(unit_price, exchange_rate));
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessUnitPrice)");
			}

			return return_value;
		}

		public bool ProcessUnitPriceInPrimary(ref clsDatabase cur_db, ref clsGrid grid_item, ref string new_qty, decimal exchange_rate, string job_code = "")
		{
			bool return_value = false;
			decimal unit_price_in_pc = 0;

			clsMoney o_money = new clsMoney(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);

			try
			{
				unit_price_in_pc = o_money.RoundToMoney(o_money.ToNumMoney(grid_item.txtUnitPriceInPrimary_amt));
				grid_item.txtUnitPriceInPrimary_amt = o_money.ToStrMoney(unit_price_in_pc);

				// Accept negative line items, now
				//
				if (unit_price_in_pc < 0)
				{
					if (oUtility.IsNegativePriceCarryItemType(oUtility.ToInteger(grid_item.lblItem_typ)) == false) // 07/04/2016 This will let the rebate/discount item carry the item code for report later on
					{
						grid_item.txtUnitPriceInPrimary_amt = "";
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NEGATIVE_VALUE_NOT_ALLOWED);
						return false;
					}
					//grid_item.cboJob_cd = "";
					grid_item.cboTax_cd = "";
				}

				grid_item.txtUnitPrice_amt = o_money.ToStrMoney(o_currency.ConvertToForeignCurrency(unit_price_in_pc, exchange_rate));

				if (ProcessUnitPrice(ref cur_db, ref grid_item, ref new_qty, exchange_rate, true) == false)
				{
					return false;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessUnitPriceInPrimary)");
			}

			return return_value;
		}

		public bool ProcessTaxCode(ref clsDatabase cur_db, ref clsGrid grid_item, decimal tax_perc)
		{
			bool return_value = false;
			string tax_code = "";
			decimal tmp = 0;
			clsValidate o_val = new clsValidate(ref cur_db);

			try
			{
				tax_code = modCommonUtility.CleanCode(grid_item.cboTax_cd);

				// If empty tax_code, reset tax percent.
				// However, do not reset tax_amt, here because it is done CalculateCurrentRow().
				//
				if (oUtility.IsEmpty(tax_code))
				{
					tax_code = "";
					tax_perc = 0;
					return_value = true;
				}
				else
				{
					if (o_val.IsValidAPTaxCode(tax_code) == false)
					{
						grid_item.cboTax_cd = "";
						grid_item.lblTax_pc = "";
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oString.STR_TAX_CODE + " " + tax_code + cur_db.oLanguage.oMessage.DOES_NOT_EXIST);
						return false;
					}

					if ((tax_perc >= cur_db.fSmallestNumber && o_val.oRecordset.iField("iTax_typ") == GlobalVar.goConstant.INCLUDED_TAX_NUM) 
						|| (tax_perc <= -cur_db.fSmallestNumber && o_val.oRecordset.iField("iTax_typ") == GlobalVar.goConstant.REGULAR_TAX_NUM))
					{
						grid_item.cboTax_cd = "";
						grid_item.lblTax_pc = "";
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.TWO_TAX_TYPES_ARE_NOT_ALLOWED);
						return false;
					}
					else
					{
						if (o_val.oRecordset.iField("iTax_typ") == GlobalVar.goConstant.REGULAR_TAX_NUM)
						{
							tax_perc = o_val.oRecordset.mField("fTotalTax_pc");
						}
						else
						{
							tax_perc = -o_val.oRecordset.mField("fTotalTax_pc"); // Meaning included tax
						}
						return_value = true;
					}

				}

				grid_item.cboTax_cd = tax_code;
				grid_item.lblTax_pc = tax_perc.ToString();

			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessTaxCode)");
			}

			return return_value;
		}

		public bool ProcessJobCode(ref clsDatabase cur_db, ref clsGrid grid_item, string customer_code = "")
		{
			bool return_value = false;

			string job_code = "";
			string err_msg = "";
			clsValidate o_val = new clsValidate(ref cur_db);

			job_code = modCommonUtility.CleanCode(grid_item.cboJob_cd);

			// If empty Job_code, reset Job percent.
			// However, do not reset Job_amt, here because it is done CalculateCurrentRow().
			//
			if (oUtility.IsEmpty(job_code))
			{
				job_code = "";
				return_value = true;
			}
			else if (o_val.IsValidJobForTransaction(job_code, ref err_msg, customer_code) == false)
			{
				grid_item.cboJob_cd = Data[JOB_CODE_COL, grid_item.Row_num];
				modDialogUtility.DisplayBox(ref cur_db, err_msg);
				return false;
			}
			else
			{
				return_value = true;
			}

			return return_value;
		}

		public bool ProcessPurchaseUnit(ref clsDatabase cur_db, ref clsGrid grid_item)
		{
			bool return_value = false;

			string unit_code = "";
			string item_code = "";
			decimal conversion_rate = 0;
			string ivunit_code = "";
			clsValidate o_val = new clsValidate(ref cur_db);

			unit_code = modCommonUtility.CleanCode(grid_item.txtUnit_cd);

			if (cur_db.uProgram.bIVExist_fl == false)
			{
				grid_item.txtUnit_cd = unit_code;
			}

			item_code = grid_item.txtItem_cd;
			ivunit_code = grid_item.lblIVUnit_cd;

			if (oUtility.IsEmpty(unit_code) || oUtility.IsEmpty(item_code) || !oUtility.IsInventoryItemType(oUtility.ToInteger(grid_item.lblItem_typ)))
			{
				return_value = true;
			}
			else if (o_val.IsValidUnitCode(item_code, ivunit_code, unit_code, ref conversion_rate) == false)
			{
				grid_item.txtUnit_cd = "";
				modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NO_CONVERSION_EXIST + "(" + ivunit_code + ":" + unit_code + ")");
				return false;
			}
			else
			{
				return_value = true;
			}

			grid_item.txtUnit_cd = unit_code;

			return return_value;
		}

		// Recalculate the prices according to the new exchange-rates given.
		//
		public bool RecalculateForNewExchangeRate(ref clsDatabase cur_db, decimal sale_exchange_rate, decimal old_price_change_rate, decimal new_price_change_rate, bool primary_amount_changed_fl)
        {
			bool return_value = false;
			int i = 0;
			string qty = "";

			clsGrid det = new clsGrid();
			clsMoney o_money = new clsMoney(ref cur_db);

			try
            {
				for (i = 0; i < Data.GetLength(1); i++)
				{
					if (oUtility.IsNonEmpty(Data[ITEM_CODE_COL, i]) && (Math.Abs(o_money.ToNumMoney(Data[UNIT_PRICE_COL, i])) > 0))
					{
						if (FindGridLine(i, ref det) == false)
                        {
							modDialogUtility.DisplayBox(ref cur_db, "Recalculation failed (RecalculateForNewExchangeRate)");   // not expected.
							return false;
						}

						if (primary_amount_changed_fl)			// For A/R
                        {
							det.txtUnitPriceInPrimary_amt = o_money.ToStrMoney(o_money.RoundToMoney(o_money.ToNumMoney(det.txtUnitPriceInPrimary_amt) * new_price_change_rate / old_price_change_rate));
							ProcessUnitPriceInPrimary(ref cur_db, ref det, ref Data[QUANTITY_COL, i], sale_exchange_rate, "");
						}
						else									// For A/P
                        {
							det.txtUnitPrice_amt = o_money.ToStrMoney(o_money.RoundToMoney(o_money.ToNumMoney(det.txtUnitPrice_amt) * new_price_change_rate / old_price_change_rate));
							ProcessUnitPrice(ref cur_db, ref det, ref Data[QUANTITY_COL, i], sale_exchange_rate, false);
						}

						CalculateRow(ref cur_db, ref det, ref Data[QUANTITY_COL, i], sale_exchange_rate);
					}
				}

				return_value = true;
			}
			catch (Exception ex)
            {
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(RecalculateForNewExchangeRate)");
			}

			return return_value;
		}

		public decimal CalcluateTotalQTY(string[,] detail_data, int item_code_col, int item_type_col, int qty_col)
        {
			decimal total_qty = 0;
			int row_num = 0;

			try
            {
				if (detail_data == null)
				{
					return total_qty;
				}

				if (detail_data.GetUpperBound(0) < item_code_col || detail_data.GetUpperBound(0) < item_type_col || detail_data.GetUpperBound(0) < qty_col)
				{
					return total_qty;
				}

				for (row_num = 0; row_num < detail_data.GetLength(1); row_num++)
				{
					if (oUtility.IsNonEmpty(detail_data[item_code_col, row_num]) && oUtility.IsInventoryItemType(oUtility.ToInteger(detail_data[item_type_col, row_num])))
					{
						total_qty += oUtility.ToValue(detail_data[qty_col, row_num]);
					}
				}
			}
			catch
            {
				// Just in case
            }

			return total_qty;
		}

		public bool ClearCurrentLine(int cur_row)
        {
			int col_num = 0;

			for (col_num = 0; col_num < TOTAL_COLUMNS; col_num++)
            {
				if (col_num != LINE_ID_COL)		// Exclude the line-id.  If need to reset it, let the caller handle it.
                {
					Data[col_num, cur_row] = "";
				}
			}

			RecreateGridLine(cur_row);

			return true;
        }

		public bool GetBestQuotes(ref clsDatabase cur_db, int RFQ_num)
        {
			bool return_value = false;
			string sql_str = "";
			int row_num = 0;
			int col_num = 0;

			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
            {
				// Get the vendor-quotes
				//
				sql_str = "SELECT d.iSourceDetail_num, d.sDescription, d.sItem_cd, d.mUnitPrice_amt, d.mUnitPriceInPrimary_amt, d.iRequired_dt, h.sVendor_cd, h.sVendor_nm, h.sTerms_cd ";
				sql_str += " FROM tblPOQTransactionDet d INNER JOIN tblPOQTransaction h ON (h.iTransaction_typ = d.iTransaction_typ AND h.iTransaction_num = d.iTransaction_num)";
				sql_str += " WHERE h.iTransaction_typ = " + GlobalVar.goConstant.TRX_PO_QUOTE_TYPE.ToString() + " AND h.iRFQ_num = " + RFQ_num.ToString();
				sql_str += " AND h.iStatus_typ <> " + GlobalVar.goConstant.VOID_TRX_NUM.ToString();
				sql_str += " AND h.iStatus_typ <> " + GlobalVar.goConstant.HOLD_TRX_NUM.ToString();
				sql_str += " AND d.iPO_num = 0";
				sql_str += " ORDER BY d.iSourceDetail_num, d.mUnitPriceInPrimary_amt";      // in-house items do not have item code
				if (cur_set.CreateSnapshot(sql_str) == false)
                {
					return false;
                }
				if (cur_set.EOF())
                {
					cur_db.SetPostingError(cur_db.oLanguage.oMessage.NO_RECORDS_FOUND);
					return false;
                }

				for (row_num = 0; row_num <= Data.GetUpperBound(1); row_num++)
                {
					if (oUtility.IsNonEmpty(Data[ITEM_CODE_COL, row_num]) || oUtility.IsNonEmpty(Data[DESCRIPTION_COL, row_num]))
                    {
						cur_set.MoveFirst();

						// Find the first occurrence of the item. 
						//
						while (cur_set.EOF() == false && oUtility.ToInteger(Data[LINE_ID_COL, row_num]) != cur_set.iField("iSourceDetail_num"))      // in-house items do not have item code
						{
							cur_set.MoveNext();
						}

						for (col_num = VENDOR1_CODE_COL; col_num <= DELIVERY5_DATE_COL; col_num++)
                        {
							Data[col_num, row_num] = "";
						}
						for (col_num = INCLUDE1_COL; col_num <= INCLUDE5_COL; col_num++)
						{
							Data[col_num, row_num] = "";
						}

						if (cur_set.EOF() == false)
						{
							Data[VENDOR1_CODE_COL, row_num] = cur_set.sField("sVendor_cd");
							Data[VENDOR1_NAME_COL, row_num] = cur_set.sField("sVendor_nm");
							Data[TERMS1_CODE_COL, row_num] = cur_set.sField("sTerms_cd");
							Data[UNIT_PRICE1_AMT_COL, row_num] = o_money.ToStrMoney(cur_set.mField("mUnitPriceInPrimary_amt"));
							Data[EXTENDED1_AMT_COL, row_num] = o_money.ToStrMoney(o_money.ToNumMoney(Data[QTY_ORDERED_COL, row_num]) * cur_set.mField("mUnitPriceInPrimary_amt"));
							Data[DELIVERY1_DATE_COL, row_num] = o_gen.ToStrDate(cur_set.iField("iRequired_dt"));

							cur_set.MoveNext();
						}

						if (cur_set.EOF() == false && oUtility.ToInteger(Data[LINE_ID_COL, row_num]) == cur_set.iField("iSourceDetail_num"))
						{
							Data[VENDOR2_CODE_COL, row_num] = cur_set.sField("sVendor_cd");
							Data[VENDOR2_NAME_COL, row_num] = cur_set.sField("sVendor_nm");
							Data[TERMS2_CODE_COL, row_num] = cur_set.sField("sTerms_cd");
							Data[UNIT_PRICE2_AMT_COL, row_num] = o_money.ToStrMoney(cur_set.mField("mUnitPriceInPrimary_amt"));
							Data[EXTENDED2_AMT_COL, row_num] = o_money.ToStrMoney(o_money.ToNumMoney(Data[QTY_ORDERED_COL, row_num]) * cur_set.mField("mUnitPriceInPrimary_amt"));
							Data[DELIVERY2_DATE_COL, row_num] = o_gen.ToStrDate(cur_set.iField("iRequired_dt"));

							cur_set.MoveNext();
						}

						if (cur_set.EOF() == false && oUtility.ToInteger(Data[LINE_ID_COL, row_num]) == cur_set.iField("iSourceDetail_num"))
						{
							Data[VENDOR3_CODE_COL, row_num] = cur_set.sField("sVendor_cd");
							Data[VENDOR3_NAME_COL, row_num] = cur_set.sField("sVendor_nm");
							Data[TERMS3_CODE_COL, row_num] = cur_set.sField("sTerms_cd");
							Data[UNIT_PRICE3_AMT_COL, row_num] = o_money.ToStrMoney(cur_set.mField("mUnitPriceInPrimary_amt"));
							Data[EXTENDED3_AMT_COL, row_num] = o_money.ToStrMoney(o_money.ToNumMoney(Data[QTY_ORDERED_COL, row_num]) * cur_set.mField("mUnitPriceInPrimary_amt"));
							Data[DELIVERY3_DATE_COL, row_num] = o_gen.ToStrDate(cur_set.iField("iRequired_dt"));

							cur_set.MoveNext();
						}

						if (cur_set.EOF() == false && oUtility.ToInteger(Data[LINE_ID_COL, row_num]) == cur_set.iField("iSourceDetail_num"))
						{
							Data[VENDOR4_CODE_COL, row_num] = cur_set.sField("sVendor_cd");
							Data[VENDOR4_NAME_COL, row_num] = cur_set.sField("sVendor_nm");
							Data[TERMS4_CODE_COL, row_num] = cur_set.sField("sTerms_cd");
							Data[UNIT_PRICE4_AMT_COL, row_num] = o_money.ToStrMoney(cur_set.mField("mUnitPriceInPrimary_amt"));
							Data[EXTENDED4_AMT_COL, row_num] = o_money.ToStrMoney(o_money.ToNumMoney(Data[QTY_ORDERED_COL, row_num]) * cur_set.mField("mUnitPriceInPrimary_amt"));
							Data[DELIVERY4_DATE_COL, row_num] = o_gen.ToStrDate(cur_set.iField("iRequired_dt"));

							cur_set.MoveNext();
						}

						if (cur_set.EOF() == false && oUtility.ToInteger(Data[LINE_ID_COL, row_num]) == cur_set.iField("iSourceDetail_num"))
						{
							Data[VENDOR5_CODE_COL, row_num] = cur_set.sField("sVendor_cd");
							Data[VENDOR5_NAME_COL, row_num] = cur_set.sField("sVendor_nm");
							Data[TERMS5_CODE_COL, row_num] = cur_set.sField("sTerms_cd");
							Data[UNIT_PRICE5_AMT_COL, row_num] = o_money.ToStrMoney(cur_set.mField("mUnitPriceInPrimary_amt"));
							Data[EXTENDED5_AMT_COL, row_num] = o_money.ToStrMoney(o_money.ToNumMoney(Data[QTY_ORDERED_COL, row_num]) * cur_set.mField("mUnitPriceInPrimary_amt"));
							Data[DELIVERY5_DATE_COL, row_num] = o_gen.ToStrDate(cur_set.iField("iRequired_dt"));

							cur_set.MoveNext();
						}

					}
				}

				if (RecreateGrid() == false)
                {
					return false;
                }

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(GetBestQuotes)");
			}

			return return_value;
		}
	}

}
