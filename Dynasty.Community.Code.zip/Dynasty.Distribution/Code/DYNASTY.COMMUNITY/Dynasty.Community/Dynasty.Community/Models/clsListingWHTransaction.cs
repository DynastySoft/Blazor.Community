﻿using Dynasty.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dynasty.ASP.Models
{

    public class clsListingWHTransaction
    {
        clsDynastyUtility oUtility = new clsDynastyUtility();

        public bool Show(clsDatabase cur_db, clsPage cur_page, string where_clause = "", string order_by_clause = "")
        {
            string sql_str = "";

            clsRecordset cur_set = new clsRecordset(ref cur_db);
            clsGeneral o_gen = new clsGeneral(ref cur_db);
            clsMoney o_money = new clsMoney(ref cur_db);
            clsStatus o_status = new clsStatus();

            Grid.Clear();

            order_by_clause= oUtility.STrim(order_by_clause);

            // Standard listing shows the key and description
            //
            sql_str = "SELECT * FROM " + cur_page.sTable_nm;

            if (oUtility.IsNonEmpty(where_clause))
            {
                if (oUtility.IsNonEmpty(cur_page.sRestrictionClause))
                {
                    sql_str += " WHERE " + cur_page.sRestrictionClause;
                    sql_str += " AND " + where_clause;
                }
                else
                {
                    sql_str += " WHERE " + where_clause;
                }
            }
            else if (oUtility.IsNonEmpty(cur_page.sRestrictionClause))
            {
                sql_str += " WHERE " + cur_page.sRestrictionClause;
            }

            if (oUtility.IsNonEmpty(order_by_clause))
            {
                sql_str += " ORDER BY " + order_by_clause;
            }
            else
            {
                sql_str += " ORDER BY " + cur_page.sKeyField_nm;
            }

            if (cur_set.CreateSnapshot(sql_str) == false)
            {
                return false;
            }
            else if (cur_set.EOF())
            {
                return true;
            }

            while (cur_set.EOF() == false)
            {
                Grid.Add(new clsGrid { Transaction_num = cur_set.sField(cur_page.sKeyField_nm)
		                , Order_num = oUtility.IIf(cur_set.iField("iOrder_num") > 0, cur_set.iField("iOrder_num").ToString(), "")
		                , Entry_dt = o_gen.ToStrDate(cur_set.iField("iEntry_dt"))
                        , Apply_dt = o_gen.ToStrDate(cur_set.iField("iApply_dt"))
                        , Shipped_dt = o_gen.ToStrDate(cur_set.iField("iShipped_dt"))
                        , Required_dt = o_gen.ToStrDate(cur_set.iField("iRequired_dt"))
                        , Completed_dt = o_gen.ToStrDate(cur_set.iField("iCompleted_dt"))
                        , Status_typ = GetStatus(cur_page, cur_set.iField("iStatus_typ"))
                        , YourReference = cur_set.sField("sYourReference")
		                , Reference = cur_set.sField("sReference")
		                , Location_cd = cur_set.sField("sLocation_cd")
		                , Via_cd = cur_set.sField("sVia_cd")
		                , Fob_cd = cur_set.sField("sFob_cd")
		                , Agent_cd = cur_set.sField("sAgent_cd")
                        , Entity_cd = cur_set.sField("sEntity_cd")
		                , Entity_nm = cur_set.sField("sEntity_nm")
		                , Ticket_num = cur_set.sField("sTicket_num")
                        , Comment = cur_set.sField("sComment")
                });

                cur_set.MoveNext();
            }


            //if (mTotal_amt > 0 || mPaid_amt > 0 || mDue_amt > 0 || mShipped_amt > 0)
            //{
            //    Grid.Add(new clsGrid { Transaction_num = ""
            //          , Order_num = ""
            //          , Entry_dt = ""
            //                , Apply_dt = ""
            //                , Shipped_dt = ""
            //                , Required_dt = ""
            //                , Completed_dt = ""
            //                , Status_typ = ""
            //                , YourReference = ""
            //          , Reference = ""
            //          , Location_cd = ""
            //          , Via_cd = ""
            //                , Fob_cd = ""
            //                , Agent_cd = ""
            //                , Entity_cd = ""
            //                , Entity_nm = ""
            //                , Ticket_num = ""
            //                , Comment = ""
            //    });
            //}

            return true;
        }

        private string GetStatus(clsPage cur_page, int status_type)
        {
            clsStatus o_status = new clsStatus();
            string status_text = "";

            // Set to default transaction status.
            //
            status_text = o_status.TransactionUnpostedStatusTypeText(status_type);

            return status_text;
        }

        private bool IsPayable(int trx_type)
        {
            if (trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE || trx_type == GlobalVar.goConstant.TRX_DM_TYPE
            || trx_type == GlobalVar.goConstant.TRX_PO_TYPE || trx_type == GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE)
            {
                return true;
            }

            return false;
        }

        public class clsGrid
        {
            public string Transaction_num { get; set; } = "";
            public string Order_num { get; set; } = "";
            public string Entry_dt { get; set; } = "";
            public string Apply_dt { get; set; } = "";
            public string Shipped_dt { get; set; } = "";
            public string Required_dt { get; set; } = "";
            public string Completed_dt { get; set; } = "";
            public string Status_typ { get; set; } = "";
            public string YourReference { get; set; } = "";
            public string Reference { get; set; } = "";
            public string Location_cd { get; set; } = "";
            public string Via_cd { get; set; } = "";
            public string Fob_cd { get; set; } = "";
            public string Agent_cd { get; set; } = "";
            public string Entity_cd { get; set; } = "";
            public string Entity_nm { get; set; } = "";
            public string Ticket_num { get; set; } = "";
            public string Comment { get; set; } = "";
        }
        public List<clsGrid> Grid = new List<clsGrid>();

    }
}
