﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.Threading.Tasks;

namespace Dynasty.ASP.Models
{
    public class clsLinkButton
    {
        public bool Clicked { get; set; } = false;
        public bool Visible { get; set; } = false;
        public string Text { get; set; } = "";
        public Color ForeColor { get; set; } = Color.LightGreen;
    }
}
