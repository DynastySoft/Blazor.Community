﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Dynasty.Database;

namespace Dynasty.ASP.Models
{
    public class clsListingIVTransaction
    {
        clsDynastyUtility oUtility = new clsDynastyUtility();

        public bool Clear()
        {
            bool return_value = false;

            try
            {
                Grid.Clear();
                return_value = true;
            }
            catch (Exception ex)
            {
                return_value = false;
            }

            return return_value;
        }
        public bool Show(clsDatabase cur_db, clsPage cur_page, string where_clause = "", string order_by_clause = "")
        {
            string sql_str;

            clsRecordset cur_set = new clsRecordset(ref cur_db);
            clsMoney o_money = new clsMoney(ref cur_db);

            Grid.Clear();

            sql_str = "SELECT * FROM " + cur_page.sTable_nm;

            if (oUtility.IsNonEmpty(where_clause))
            {
                if (oUtility.IsNonEmpty(cur_page.sRestrictionClause))
                {
                    sql_str += " WHERE " + cur_page.sRestrictionClause;
                    sql_str += " AND " + where_clause;
                }
                else
                {
                    sql_str += " WHERE " + where_clause;
                }
            }
            else if (oUtility.IsNonEmpty(cur_page.sRestrictionClause))
            {
                sql_str += " WHERE " + cur_page.sRestrictionClause;
            }

            if (oUtility.IsNonEmpty(order_by_clause))
            {
                sql_str += " ORDER BY " + order_by_clause;
            }
            else
            {
                sql_str += " ORDER BY " + cur_page.sKeyField_nm;
            }

            if (cur_set.CreateSnapshot(sql_str) == false)
            {
                return false;
            }
            else if (cur_set.EOF())
            {
                //modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NO_RECORDS_FOUND);
                return true;
            }

            while (cur_set.EOF() == false)
            {
                Grid.Add(new clsGrid { Transaction_num = modCommonUtility.GetFieldValue(cur_db, cur_set, "iTransaction_num", cur_page.iTransaction_typ)
                    , Status_typ = modCommonUtility.GetFieldValue(cur_db, cur_set, "iStatus_typ", cur_page.iTransaction_typ)
                    , Entry_dt = modCommonUtility.GetFieldValue(cur_db, cur_set, "iEntry_dt", cur_page.iTransaction_typ)
                    , Apply_dt = modCommonUtility.GetFieldValue(cur_db, cur_set, "iApply_dt", cur_page.iTransaction_typ)
                    , Job_cd = modCommonUtility.GetFieldValue(cur_db, cur_set, "sJob_cd", cur_page.iTransaction_typ)
                    , Office_cd = modCommonUtility.GetFieldValue(cur_db, cur_set, "sOffice_cd", cur_page.iTransaction_typ)
                    , Location_cd = modCommonUtility.GetFieldValue(cur_db, cur_set, "sToLocation_cd", cur_page.iTransaction_typ)
                    , Department_cd = modCommonUtility.GetFieldValue(cur_db, cur_set, "sDepartment_cd", cur_page.iTransaction_typ)
                    , Comment = modCommonUtility.GetFieldValue(cur_db, cur_set, "sComment", cur_page.iTransaction_typ)
                    , Description = modCommonUtility.GetFieldValue(cur_db, cur_set, "sDescription", cur_page.iTransaction_typ)
                    , Reference = modCommonUtility.GetFieldValue(cur_db, cur_set, "sReference", cur_page.iTransaction_typ)
                    , WO_num = modCommonUtility.GetFieldValue(cur_db, cur_set, "iWO_num", cur_page.iTransaction_typ)
                });

                cur_set.MoveNext();
            }

            return true;
        }

        public class clsGrid
        {
            public string Transaction_num { get; set; } = "";
            public string Status_typ { get; set; } = "";
            public string Entry_dt { get; set; } = "";
            public string Apply_dt { get; set; } = "";
            public string Job_cd { get; set; } = "";
            public string Office_cd { get; set; } = "";
            public string Location_cd { get; set; } = "";
            public string Department_cd { get; set; } = "";
            public string Comment { get; set; } = "";
            public string Description { get; set; } = "";
            public string Reference { get; set; } = "";
            public string WO_num { get; set; } = "";
        }
        public List<clsGrid> Grid = new List<clsGrid>();

    }

}
