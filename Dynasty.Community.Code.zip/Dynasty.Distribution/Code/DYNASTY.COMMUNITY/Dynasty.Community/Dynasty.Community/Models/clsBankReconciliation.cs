﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Dynasty.Database;

namespace Dynasty.ASP.Models
{
    public class clsBankReconciliation
    {
		public const int INCLUDE_COL = 0;
		public const int TRX_CODE_COL = 1;
		public const int CHECK_NUM_COL = 2;
		public const int ENTITY_COL = 3;
		public const int DEPOSIT_COL = 4;
		public const int WITHDRAWAL_COL = 5;
		public const int TRX_NUM_COL = 6;
		public const int TRX_TYPE_COL = 7;
		public const int DETAIL_NUM_COL = 8;
		public const int APPLY_DATE_COL = 9;
		public const int ENTRY_DATE_COL = 10;
		public const int BR_TRX_FL_COL = 11;
		public const int LINK_ID_COL = 12;
		public const int COMMENT_COL = 13;
		public const int EDITED_COL = 14;

		public const int TOTAL_COLUMNS = 15;

		public int iNextLine_id = 1;
        public int iTotalRows = 0;

        public string[,] Data;                                                                  // Keeps the detail data.
		public string[] Caption;                                                                // List of column captions

		private string sPostingError = "";
		private clsDynastyUtility oUtility = new clsDynastyUtility();

		public const string BANK_FILE_TYPE_QBO = "QBO";
		public const string BANK_FILE_TYPE_QFX = "QFX";

		public clsBankReconciliation()
        {
			oUtility.ResizeDim(ref Data, TOTAL_COLUMNS - 1, 0);
			RecreateGrid();
		}

		public bool Clear(int initial_rows = 1)
		{
			bool return_value = false;

			iTotalRows = initial_rows;
			oUtility.ResizeDim(ref Data, TOTAL_COLUMNS - 1, initial_rows - 1);
			RecreateGrid();

			return return_value;
		}

		public bool IsErrorFound()
		{
			bool return_value = false;

			return_value = (oUtility.IsNonEmpty(sPostingError));

			return return_value;
		}

		public string GetErrorMessage()
		{
			string return_value = "";

			return_value = sPostingError;
			sPostingError = "";

			return return_value;
		}
		public void SetPostingError(string error_msg)
		{
			if (oUtility.IsEmpty(error_msg))
			{
				sPostingError = "";
			}
			else if (oUtility.IsEmpty(sPostingError))
			{
				sPostingError = error_msg;
			}
			else if (oUtility.STrim(sPostingError) != oUtility.STrim(error_msg))
			{
				sPostingError += Environment.NewLine + Environment.NewLine + "AND " + error_msg;
			}
		}

        public class clsGrid
        {
            public int Row_num = 0;                           // Keeps the row number
            public bool chkInclude_fl = false;
            public string Transaction_cd = "";
            public string Check_num = "";
            public string Entity_cd = "";
            public string Deposit_amt = "";
            public string Withdrawal_amt = "";
            public string Transaction_num = "";
            public string Transaction_typ = "";
            public string Detail_num = "";
            public string Apply_dt = "";
            public string Entry_dt = "";
            public string BR_fl = "";
            public string Link_id = "";
            public string Comment = "";
			public bool chkEdited_fl = false;

		}
		public List<clsGrid> Grid = new List<clsGrid>();
				
		public bool AddMoreRows(int lines_to_add = 10)
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
                // oUtility.ResizeDimPreserved(ref Data, Data.GetUpperBound(0), Data.GetUpperBound(1) + lines_to_add);

                for (row_num = 0; row_num < lines_to_add; row_num++)
                {
                    Grid.Add(new clsGrid { Row_num = iTotalRows
							, chkInclude_fl = false
							, chkEdited_fl = false
					});

                    iTotalRows += 1;
					iNextLine_id += 1;
				}
                
                RecreateDetail();
                return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (AddMoreRows)");
				RecreateDetail();
            }

            return return_value;
        }

		public bool InsertNewRow(clsGrid cur_item)
		{
			bool return_value = false;
			int old_row_num = cur_item.Row_num;

			try
			{
				Grid.Insert(old_row_num, new clsGrid
				{
					Row_num = -1
				}); 

				Grid.Where(i => i.Row_num >= old_row_num).Select(i => { i.Row_num += 1; return i; }).ToList();
				Grid.Single(i => i.Row_num == -1).Row_num = old_row_num;

				iNextLine_id += 1;
				iTotalRows += 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (InsertNewRow)");
			}

			return return_value;
		}

		public bool DeleteCurrentRow(clsGrid cur_item)
		{
			bool return_value = false;
			int old_num = cur_item.Row_num;

			try
			{
				Grid.RemoveAt(cur_item.Row_num);
				Grid.Where(i => i.Row_num >= old_num).Select(i => { i.Row_num -= 1; return i; }).ToList();

				iTotalRows -= 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (DeleteCurrentRow)");
			}

			return return_value;
		}


		public bool DeleteCurrentRow(int row_num)
		{
			bool return_value = false;
			int old_num = row_num;

			try
			{
				Grid.RemoveAt(row_num);
				Grid.Where(i => i.Row_num >= old_num).Select(i => { i.Row_num -= 1; return i; }).ToList();

				iTotalRows -= 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (DeleteCurrentRow)");
			}

			return return_value;
		}
		public bool RecreateDetail()                                                           //  Sync Data with Grid for the items that do not have event-handler ONLY.
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				if (Grid.Count() == 0)
				{
					oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), 0);
					return true;
				}

				// We need to create it here for saving because some fields may not have been copied into the array.
				//
				iTotalRows = Grid.Count();
				oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), iTotalRows - 1);

				foreach (var det in Grid)
				{
					if (RecreateDetailLine(det, row_num) == false)
					{
						return false;
					}

					det.Row_num = row_num;      // Just to make sure.
					row_num++;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetail)");
			}

			return return_value;
		}

		public bool RecreateGridLine(int row_num)
		{
			bool return_value = false;
			clsGrid grid_line = new clsGrid();

			if (FindGridLine(row_num, ref grid_line) == false)
			{
				SetPostingError("Grid does not match array.");
				return false;
			}

			return RecreateGridLine(ref grid_line, row_num);
		}

		public bool RecreateGridLine(ref clsGrid cur_item, int row_num)
		{
			bool return_value = false;

			try
			{
				cur_item.chkInclude_fl = (GlobalVar.goUtility.ToInteger(Data[INCLUDE_COL, row_num]) == 1);				
				cur_item.Transaction_cd = Data[TRX_CODE_COL, row_num];
				cur_item.Check_num = Data[CHECK_NUM_COL, row_num];
				cur_item.Entity_cd = Data[ENTITY_COL, row_num];
				cur_item.Deposit_amt = Data[DEPOSIT_COL, row_num];
				cur_item.Withdrawal_amt = Data[WITHDRAWAL_COL, row_num];
				cur_item.Transaction_num = Data[TRX_NUM_COL, row_num];
				cur_item.Transaction_typ = Data[TRX_TYPE_COL, row_num];
				cur_item.Detail_num = Data[DETAIL_NUM_COL, row_num];
				cur_item.Apply_dt = Data[APPLY_DATE_COL, row_num];
				cur_item.Entry_dt = Data[ENTRY_DATE_COL, row_num];
				cur_item.BR_fl = Data[BR_TRX_FL_COL, row_num];
				cur_item.Link_id = Data[LINK_ID_COL, row_num];
				cur_item.Comment = Data[COMMENT_COL, row_num];
				cur_item.chkEdited_fl = (GlobalVar.goUtility.ToInteger(Data[EDITED_COL, row_num]) == 1);
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateGridLine)");
			}
			return return_value;

		}

		public bool FindGridLine(int row_num, ref clsGrid line_found)
		{
			bool return_value = false;

			try
			{
				line_found = Grid.Single(i => i.Row_num == row_num);

				if (line_found != null)
				{
					return_value = true;
				}
			}
			catch (Exception ex)
			{
				// in case not found
			}

			return return_value;
		}

		public bool RecreateDetailLine(clsGrid cur_item, int row_num = -1)
		{
			bool return_value = false;

			try
			{
				// If this is called from UI event, get the row number of current line.
				//
				if (row_num < 0)
				{
					row_num = cur_item.Row_num;
				}

				Data[INCLUDE_COL, row_num] = cur_item.chkInclude_fl? "1" : "0";
				Data[TRX_CODE_COL, row_num] = cur_item.Transaction_cd;
				Data[CHECK_NUM_COL, row_num] = cur_item.Check_num;
				Data[ENTITY_COL, row_num] = cur_item.Entity_cd;
				Data[DEPOSIT_COL, row_num] = cur_item.Deposit_amt;
				Data[WITHDRAWAL_COL, row_num] = cur_item.Withdrawal_amt;
				Data[TRX_NUM_COL, row_num] = cur_item.Transaction_num;
				Data[TRX_TYPE_COL, row_num] = cur_item.Transaction_typ;
				Data[DETAIL_NUM_COL, row_num] = cur_item.Detail_num;
				Data[APPLY_DATE_COL, row_num] = cur_item.Apply_dt;
				Data[ENTRY_DATE_COL, row_num] = cur_item.Entry_dt;
				Data[BR_TRX_FL_COL, row_num] = cur_item.BR_fl;
				Data[LINK_ID_COL, row_num] = cur_item.Link_id;
				Data[COMMENT_COL, row_num] = cur_item.Comment;
				Data[EDITED_COL, row_num] = cur_item.chkEdited_fl ? "1" : "0";

				return_value = true;

			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetailLine)");
			}

			return return_value;
		}

		public bool RecreateGrid()                                                             //  Create Grid according to Data
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				Grid.Clear();

				if (Data == null)
				{
					return true;
				}
				else if (Data.GetLength(1) == 0)
				{
					return true;
				}

				iTotalRows = Data.GetLength(1);

				for (row_num = 0; row_num < iTotalRows; row_num++)
				{
					Grid.Add(new clsGrid
					{
						Row_num = row_num
						,chkInclude_fl = (GlobalVar.goUtility.ToInteger(Data[INCLUDE_COL, row_num]) == 1)
						,Transaction_cd = Data[TRX_CODE_COL, row_num]
						,Check_num = Data[CHECK_NUM_COL, row_num]
						,Entity_cd = Data[ENTITY_COL, row_num]
						,Deposit_amt = Data[DEPOSIT_COL, row_num]
						,Withdrawal_amt = Data[WITHDRAWAL_COL, row_num]
						,Transaction_num = Data[TRX_NUM_COL, row_num]
						,Transaction_typ = Data[TRX_TYPE_COL, row_num]
						,Detail_num = Data[DETAIL_NUM_COL, row_num]
						,Apply_dt = Data[APPLY_DATE_COL, row_num]
						,Entry_dt = Data[ENTRY_DATE_COL, row_num]
						,BR_fl = Data[BR_TRX_FL_COL, row_num]
						,Link_id = Data[LINK_ID_COL, row_num]
						,Comment = Data[COMMENT_COL, row_num]
						,chkEdited_fl = (GlobalVar.goUtility.ToInteger(Data[EDITED_COL, row_num]) == 1)
					});
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateGrid)");
			}

			return return_value;
		}

	}
}
