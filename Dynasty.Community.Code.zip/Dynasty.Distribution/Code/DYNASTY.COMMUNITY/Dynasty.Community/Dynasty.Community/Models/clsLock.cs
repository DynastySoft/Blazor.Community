﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//



using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Collections.Generic;

using Dynasty.Local;

namespace Dynasty.ASP.Models
{
    public class clsLock
    {
        public bool Entity = false;             // customer or vendor
        public bool Status = false;
        public bool Job = false;
        public bool Terms = false;
        public bool Posting = false;
        public bool Tax = false;
        public bool Price = false;
        public bool Agent = false;              // sales rep or purchasing agent
        public bool Location = false;
        public bool Fund = false;
        public bool Order = false;              // Also use for voucher/invoice number for in memo entry.
        public bool Commission = false;
        public bool Account = false;            // G/L account

        public void Clear()
        {
            Entity = false;  
            Status = false;
            Job = false;
            Terms = false;
            Posting = false;
            Tax = false;
            Price = false;
            Agent = false;      
            Location = false;
            Fund = false;
            Order = false;         
            Commission = false;
            Account = false;       
        }
    }
}
