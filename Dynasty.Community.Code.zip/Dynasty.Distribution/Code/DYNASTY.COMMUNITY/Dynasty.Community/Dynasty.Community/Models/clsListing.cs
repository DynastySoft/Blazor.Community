﻿using Dynasty.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dynasty.ASP.Models
{

    public class clsListing
    {
        public string[,] CustomFields = null;                   // User defined fields

        clsDynastyUtility oUtility = new clsDynastyUtility();

        // Total all amounts
        //
        public decimal mTotal_amt = 0;
        public decimal mPaid_amt = 0;
        public decimal mDue_amt = 0;
        public decimal mExtraValue1_amt = 0;
        public decimal mExtraValue2_amt = 0;
        public decimal mExtraValue3_amt = 0;
        public decimal mExtraValue4_amt = 0;
        public decimal mExtraValue5_amt = 0;

        public int iActualDataCount_num = 0;

        public bool Show(clsDatabase cur_db, clsPage cur_page, string key_description = "", string extra_field_1 = "", string extra_field_2 = ""
            , string status_type = "", string entry_date = "", string apply_date = "", string entity_cd = "", string where_clause = ""
            , string entity_nm = "", string reference = "", string total_amt = "", string paid_amt = "", string due_amt = ""
            , string extra_field_3 = "", string extra_field_4 = "", string extra_field_5 = "", string order_by_clause = ""
            , string[] custom_fields = null)
        {
            string sql_str = "";
            string trx_str = "";
            string extra_field_value_1 = "";
            string extra_field_value_2 = "";
            string extra_field_value_3 = "";
            string extra_field_value_4 = "";
            string extra_field_value_5 = "";
            int i = 0;

            clsRecordset cur_set = new clsRecordset(ref cur_db);
            clsGeneral o_gen = new clsGeneral(ref cur_db);
            clsMoney o_money = new clsMoney(ref cur_db);
            clsStatus o_status = new clsStatus();

            // Clear totals
            //
            mTotal_amt = 0;
            mPaid_amt = 0;
            mDue_amt = 0;
            mExtraValue1_amt = 0;
            mExtraValue2_amt = 0;
            mExtraValue3_amt = 0;
            mExtraValue4_amt = 0;
            mExtraValue5_amt = 0;

            Grid.Clear();

            order_by_clause= oUtility.STrim(order_by_clause);
            key_description = oUtility.STrim(key_description);

            if (oUtility.IsNonEmpty(key_description))
            {
                // use the page-specific description
            }
            else if (oUtility.IsEmpty(cur_page.sKeyDescription))
            {
                key_description = "sDescription";
            }
            else
            {
                key_description = cur_page.sKeyDescription;
            }

            // Standard listing shows the key and description
            //
            sql_str = "SELECT * FROM " + cur_page.sTable_nm;

            if (oUtility.IsNonEmpty(where_clause))
            {
                if (oUtility.IsNonEmpty(cur_page.sRestrictionClause))
                {
                    sql_str += " WHERE " + cur_page.sRestrictionClause;
                    sql_str += " AND " + where_clause;
                }
                else
                {
                    sql_str += " WHERE " + where_clause;
                }
            }
            else if (oUtility.IsNonEmpty(cur_page.sRestrictionClause))
            {
                sql_str += " WHERE " + cur_page.sRestrictionClause;

                if (oUtility.SUCase(cur_page.sTable_nm) == "TBLGOUSER")
                {
                    sql_str += " AND sUser_cd <> 'SA'";
                }
            }
            else if (oUtility.SUCase(cur_page.sTable_nm) == "TBLGOUSER")
            {
                sql_str += " WHERE sUser_cd <> 'SA'";
            }

            if (cur_page.iTransaction_typ > 0 && oUtility.SUCase(cur_page.sTable_nm) != "TBLPRTAX")          // Payroll tax pages have a valid cur_page.iTransaction_typ.
            {
                trx_str = "(iTransaction_typ = " + cur_page.iTransaction_typ.ToString() + ")";

                if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_WH_RECEIVING_SLIP_TYPE || cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_WH_SHIPPING_SLIP_TYPE
                     || cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_EXPENSE_TYPE || cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_INCOME_TYPE
                     || (cur_page.iTransaction_typ >= 7000 && cur_page.iTransaction_typ <= 7999))
                {
                    trx_str += " AND (iStatus_typ = " + GlobalVar.goConstant.HOLD_TRX_NUM.ToString() + ")";
                }
                else
                {
                    trx_str += " AND (iEntry_dt = 0 OR iEntry_dt > " + oUtility.AddToDate(GlobalVar.goConstant.YEAR_TYPE, o_gen.CurrentDate(), -1).ToString() + ")";       // Others show all for the last one year. iEntry_dt = 0 is for Q.Mfg & Kit assembly that may have not started yet.
                }

                if (oUtility.SInStr(sql_str, " WHERE ") == 0)
                {
                    sql_str += " WHERE " + trx_str;
                }
                else
                {
                    sql_str += " AND " + trx_str;
                }
            }

            if (oUtility.IsNonEmpty(order_by_clause))
            {
                sql_str += " ORDER BY " + order_by_clause;
            }
            else
            {
                sql_str += " ORDER BY " + cur_page.sKeyField_nm;
            }

            if (cur_set.CreateSnapshot(sql_str) == false)
            {
                return false;
            }
            else if (cur_set.EOF())
            {
                return true;
            }

            if (custom_fields != null)
            {
                oUtility.ResizeDim(ref CustomFields, custom_fields.GetUpperBound(0), cur_set.RecordCount());  // One extra line for total
            }

            iActualDataCount_num = 0;

            while (cur_set.EOF() == false)
            {
                extra_field_value_1 = GetFieldValue(ref cur_db, cur_set, extra_field_1);
                extra_field_value_2 = GetFieldValue(ref cur_db, cur_set, extra_field_2);
                extra_field_value_3 = GetFieldValue(ref cur_db, cur_set, extra_field_3);
                extra_field_value_4 = GetFieldValue(ref cur_db, cur_set, extra_field_4);
                extra_field_value_5 = GetFieldValue(ref cur_db, cur_set, extra_field_5);

                // Set totals
                //
                if (oUtility.IsNonEmpty(total_amt))
                {
                    mTotal_amt += cur_set.mField(total_amt);
                }
                if (oUtility.IsNonEmpty(paid_amt))
                {
                    mPaid_amt += cur_set.mField(paid_amt);
                }
                if (oUtility.IsNonEmpty(due_amt))
                {
                    mDue_amt += cur_set.mField(due_amt);
                }

                if (oUtility.IsNonEmpty(extra_field_1) && oUtility.IsMoneyField(extra_field_1))
                {
                    mExtraValue1_amt += cur_set.mField(extra_field_1);
                }

                if (oUtility.IsNonEmpty(extra_field_2) && oUtility.IsMoneyField(extra_field_2))
                {
                    mExtraValue2_amt += cur_set.mField(extra_field_2);
                }

                if (oUtility.IsNonEmpty(extra_field_3) && oUtility.IsMoneyField(extra_field_3))
                {
                    mExtraValue3_amt += cur_set.mField(extra_field_3);
                }

                if (oUtility.IsNonEmpty(extra_field_4) && oUtility.IsMoneyField(extra_field_4))
                {
                    mExtraValue4_amt += cur_set.mField(extra_field_4);
                }

                if (oUtility.IsNonEmpty(extra_field_5) && oUtility.IsMoneyField(extra_field_5))
                {
                    mExtraValue5_amt += cur_set.mField(extra_field_5);
                }

                Grid.Add(new clsGrid { 
                                Row_num = iActualDataCount_num
                                , Code = cur_set.sField(cur_page.sKeyField_nm)
                                , Description = cur_set.sField(key_description) 
                                , ExtraCol_1 = extra_field_value_1
                                , ExtraCol_2 = extra_field_value_2
                                , ExtraCol_3 = extra_field_value_3
                                , ExtraCol_4 = extra_field_value_4
                                , ExtraCol_5 = extra_field_value_5
                                , Status_typ = oUtility.IIf(oUtility.IsNonEmpty(status_type), GetStatus(cur_page, cur_set.iField(status_type)), "")
                                , Entry_dt = oUtility.IIf(oUtility.IsNonEmpty(entry_date), o_gen.ToStrDate(cur_set.iField(entry_date)), "")
                                , Apply_dt = oUtility.IIf(oUtility.IsNonEmpty(apply_date), o_gen.ToStrDate(cur_set.iField(apply_date)), "")
                                , Entity_cd = oUtility.IIf(oUtility.IsNonEmpty(entity_cd), cur_set.sField(entity_cd), "")
                                , Entity_nm = oUtility.IIf(oUtility.IsNonEmpty(entity_nm), cur_set.sField(entity_nm), "")
                                , Reference = oUtility.IIf(oUtility.IsNonEmpty(reference), cur_set.sField(reference), "")
                                , Total_amt = oUtility.IIf(oUtility.IsNonEmpty(total_amt), o_money.ToStrMoney(cur_set.mField(total_amt), -1, "", true), "")
                                , Paid_amt = oUtility.IIf(oUtility.IsNonEmpty(paid_amt), o_money.ToStrMoney(cur_set.mField(paid_amt), -1, "", true), "")
                                , Due_amt = oUtility.IIf(oUtility.IsNonEmpty(due_amt), o_money.ToStrMoney(cur_set.mField(due_amt), -1, "", true), "")
                });;

                // Set the custom fields
                //
                if (custom_fields != null)
                {
                    for (i = 0; i <= custom_fields.GetUpperBound(0); i++)
                    {
                        CustomFields[i, iActualDataCount_num] = GetFieldValue(ref cur_db, cur_set, custom_fields[i]);
                    }
                }

                iActualDataCount_num += 1;
                cur_set.MoveNext();
            }


            // Set totals
            //
            extra_field_value_1 = "";
            extra_field_value_2 = "";
            extra_field_value_3 = "";
            extra_field_value_4 = "";
            extra_field_value_5 = "";

            if (oUtility.IsNonEmpty(extra_field_1) && oUtility.IsMoneyField(extra_field_1))
            {
                extra_field_value_1 = o_money.ToStrMoney(mExtraValue1_amt, -1, "", true);
            }

            if (oUtility.IsNonEmpty(extra_field_2) && oUtility.IsMoneyField(extra_field_2))
            {
                extra_field_value_2 = o_money.ToStrMoney(mExtraValue2_amt, -1, "", true);
            }

            if (oUtility.IsNonEmpty(extra_field_3) && oUtility.IsMoneyField(extra_field_3))
            {
                extra_field_value_3 = o_money.ToStrMoney(mExtraValue3_amt, -1, "", true);
            }

            if (oUtility.IsNonEmpty(extra_field_4) && oUtility.IsMoneyField(extra_field_4))
            {
                extra_field_value_4 = o_money.ToStrMoney(mExtraValue4_amt, -1, "", true);
            }

            if (oUtility.IsNonEmpty(extra_field_5) && oUtility.IsMoneyField(extra_field_5))
            {
                extra_field_value_5 = o_money.ToStrMoney(mExtraValue5_amt, -1, "", true);
            }

            if (mTotal_amt > 0 || mPaid_amt > 0 || mDue_amt > 0 || mExtraValue1_amt > 0 || mExtraValue2_amt > 0 || mExtraValue3_amt > 0 || mExtraValue4_amt > 0 || mExtraValue5_amt > 0)
            {
                Grid.Add(new clsGrid { 
                                Row_num = (iActualDataCount_num + 1)
                                , Code = ""
                                , Description = "" 
                                , ExtraCol_1 = extra_field_value_1
                                , ExtraCol_2 = extra_field_value_2
                                , ExtraCol_3 = extra_field_value_3
                                , ExtraCol_4 = extra_field_value_4
                                , ExtraCol_5 = extra_field_value_5
                                , Status_typ = ""
                                , Entry_dt = ""
                                , Apply_dt = ""
                                , Entity_cd = ""
                                , Entity_nm = ""
                                , Reference = ""
                                , Total_amt = o_money.ToStrMoney(mTotal_amt, -1, "", true)
                                , Paid_amt = o_money.ToStrMoney(mPaid_amt, -1, "", true)
                                , Due_amt = o_money.ToStrMoney(mDue_amt, -1, "", true)
                });
            }

            return true;
        }

        private string GetStatus(clsPage cur_page, int status_type)
        {
            clsStatus o_status = new clsStatus();
            string status_text = "";

            // Set to default transaction status.
            //
            if (oUtility.SInStr(oUtility.SUCase(cur_page.sTable_nm), "UNPOSTED") > 0)
            {
                status_text = o_status.TransactionUnpostedStatusTypeText(status_type);
            }
            else
            {
                status_text = o_status.TransactionPostedStatusTypeText(status_type);
            }

            if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_WO_TYPE || cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_FA_SERVICE_PLAN_TYPE)
            {
                status_text = o_status.WorkOrderStatusTypeText(status_type);
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_QUOTE_TYPE)
            {
                status_text = o_status.QuoteStatusTypeText(status_type);
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_SO_TYPE)
            {
                status_text = o_status.OrderStatusTypeText(status_type);
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_PO_TYPE)
            {
                status_text = o_status.PurchaseOrderStatusTypeText(status_type);
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE)
            {
                status_text = o_status.PurchaseRequisitionStatusTypeText(status_type);
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_IV_MANUFACTURING_TYPE 
                || cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_IV_KIT_ASSEMBLY_TYPE 
                || cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_IV_KIT_DISASSEMBLY_TYPE)
            {
                status_text = o_status.AssemblyStatusTypeText(status_type);
            }
            else if (cur_page.iTransaction_typ > 7000 && cur_page.iTransaction_typ < 7200)
            {
                status_text = o_status.BankTransactionStatusTypeText(status_type);
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_FA_RENTAL_TYPE
                || cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_FA_RENTAL_RESERVATION_TYPE )
            {
                status_text = o_status.RentalStatusTypeText(status_type);
            }
            else if (oUtility.SUCase(cur_page.sTable_nm) == "TBLJCJOB")
            {
                status_text = o_status.JobStatusTypeText(status_type);
            }

            return status_text;
        }

        public string GetFieldValue(ref clsDatabase cur_db, clsRecordset cur_set, string field_name)
        {
            string return_value = "";
            string hour = "";
            string minute = "";
            string ampm = "";

            clsContactManager o_cm = new clsContactManager();

            clsGeneral o_gen = new clsGeneral(ref cur_db);
            clsMoney o_money = new clsMoney(ref cur_db);

            if (oUtility.IsNonEmpty(field_name))
            {
                if (oUtility.IsDateField(field_name))
                {
                    return_value = o_gen.ToStrDate(cur_set.iField(field_name));
                }
                else if (oUtility.IsMoneyField(field_name))
                {
                    return_value = o_money.ToStrMoney(cur_set.mField(field_name), -1, "", true);
                }
                else if (oUtility.IsIntegerField(field_name))
                {
                    return_value = cur_set.iField(field_name).ToString();
                }
                else if (oUtility.IsNumericField(field_name))
                {
                    return_value = cur_set.mField(field_name).ToString();
                }
                else
                {
                    if (oUtility.SLength(cur_set.sField(field_name)) == 4 && (oUtility.SUCase(field_name) == oUtility.SUCase("sNextTime") || oUtility.SUCase(field_name) == oUtility.SUCase("sLastTime")))
                    {
                        o_cm.GetTime(cur_set.sField(field_name), ref hour, ref minute, ref ampm);
                        return_value = hour + ":" + minute + " " + ampm;
                    }
                    else
                    {
                        return_value = cur_set.sField(field_name);
                    }
                }
            }

            return return_value;
        }

        public class clsGrid
        {
            public int Row_num { get; set; } = 0;
            public string Code { get; set; } = "";
            public string Description { get; set; } = "";
            public string ExtraCol_1 { get; set; } = "";    // any extra column such as amounts
            public string ExtraCol_2 { get; set; } = "";
            public string ExtraCol_3 { get; set; } = "";    
            public string ExtraCol_4 { get; set; } = "";
            public string ExtraCol_5 { get; set; } = "";    
            public string Status_typ { get; set; } = "";
            public string Entry_dt { get; set; } = "";
            public string Apply_dt { get; set; } = "";
            public string Entity_cd { get; set; } = "";
            public string Entity_nm { get; set; } = "";
            public string Reference { get; set; } = "";
            public string Total_amt { get; set; } = "";
            public string Paid_amt { get; set; } = "";
            public string Due_amt { get; set; } = "";
        }
        public List<clsGrid> Grid = new List<clsGrid>();

    }
}
