﻿using Dynasty.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dynasty.ASP.Models
{
    public class clsTransactionSearch
    {
        public bool Show(clsDatabase cur_db, clsPage page, string where_clause, bool ascending_fl = false)
        {
            string sql_str;
            clsRecordset cur_set = new clsRecordset(ref cur_db);
            string entity_cd = "";
            string entity_nm = "";
            string reference = "sReference";
            string amount_due = "";
            string agent_cd = "";
            string department_cd = "";

            Grid.Clear();

            if (page.iTransaction_typ == GlobalVar.goConstant.TRX_WO_TYPE)         // Do not move down below (page.iTransaction_typ >= 6000 && page.iTransaction_typ <= 6999)
            {
                entity_cd = "sOrderTo_cd";
                department_cd = "sDepartment_cd";
            }
            else if (page.iTransaction_typ == GlobalVar.goConstant.TRX_WH_SHIPPING_SLIP_TYPE)
            {
                entity_cd = "sEntity_cd";
                entity_nm = "sEntity_nm";
            }
            else if (page.iTransaction_typ == GlobalVar.goConstant.TRX_PRJOURNAL_TYPE)
            {
                entity_cd = "sDepartment_cd";
                entity_nm = "sGroup_cd";
                reference = "sDescription";
            }
            else if (page.iTransaction_typ == GlobalVar.goConstant.TRX_FA_SERVICE_PLAN_TYPE)
            {
                entity_cd = "sOrderTo_cd";
                entity_nm = "sOffice_cd";
            }
            else if (page.iTransaction_typ == GlobalVar.goConstant.TRX_FA_RENTAL_RESERVATION_TYPE)
            {
                entity_cd = "sCustomer_cd";
                entity_nm = "sCustomer_nm";
            }
            else if (page.iTransaction_typ >= 1000 && page.iTransaction_typ <= 1999)
            {
                entity_cd = "sJournal_cd";
                amount_due = "mTotalCr_amt";
            }

            sql_str = "SELECT * FROM " + page.sTable_nm;

            if (GlobalVar.goUtility.IsNonEmpty(where_clause))
            {
                sql_str += " WHERE " + where_clause;
            }

            if (ascending_fl)
            {
                sql_str += " ORDER BY iTransaction_num" ;
            }
            else
            {
                sql_str += " ORDER BY iTransaction_num DESC" ;
            }

            if (cur_set.CreateSnapshot(sql_str) == false)
            {
                return false;
            }
            else if (cur_set.EOF())
            {
                modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NO_RECORDS_FOUND);
                return false;
            }

            while (cur_set.EOF() == false)
            {
                Grid.Add(new clsGrid { Transaction_num = modCommonUtility.GetFieldValue(cur_db, cur_set, "iTransaction_num", page.iTransaction_typ)
                    , Status_typ = modCommonUtility.GetFieldValue(cur_db, cur_set, "iStatus_typ", page.iTransaction_typ)
                    , Entry_dt = modCommonUtility.GetFieldValue(cur_db, cur_set, "iEntry_dt", page.iTransaction_typ)
                    , Reference = modCommonUtility.GetFieldValue(cur_db, cur_set, reference, page.iTransaction_typ)
                    , Amount = modCommonUtility.GetFieldValue(cur_db, cur_set, amount_due, page.iTransaction_typ)
                    , Entity_cd = modCommonUtility.GetFieldValue(cur_db, cur_set, entity_cd, page.iTransaction_typ)
                    , Entity_nm = modCommonUtility.GetFieldValue(cur_db, cur_set, entity_nm, page.iTransaction_typ)
                    , Agent_cd = modCommonUtility.GetFieldValue(cur_db, cur_set, agent_cd, page.iTransaction_typ)
                    , Department_cd = modCommonUtility.GetFieldValue(cur_db, cur_set, department_cd, page.iTransaction_typ)
                });
                cur_set.MoveNext();
            }

            return true;
        }

        public class clsGrid
        {
            public string Transaction_num { get; set; } = "";
            public string Status_typ { get; set; } = "";
            public string Entry_dt { get; set; } = "";
            public string Reference { get; set; } = "";
            public string Amount { get; set; } = "";
            public string Entity_cd { get; set; } = "";
            public string Entity_nm { get; set; } = "";
            public string Agent_cd { get; set; } = "";
            public string Department_cd { get; set; } = "";
        }
        public List<clsGrid> Grid = new List<clsGrid>();

    }

}
