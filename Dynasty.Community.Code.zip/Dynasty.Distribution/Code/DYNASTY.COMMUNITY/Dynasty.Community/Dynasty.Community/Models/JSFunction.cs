﻿using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Dynasty.Database;

namespace Dynasty.ASP.Models
{

    public class clsBrowserDimension
    {
        public int Width { get; set; }
        public int Height { get; set; }
    }

    public class clsBrowserService
    {
        private readonly IJSRuntime _js;

        public clsBrowserService(IJSRuntime js)
        {
            _js = js;
        }

        public async Task<clsBrowserDimension> GetDimensions()
        {
            return await _js.InvokeAsync<clsBrowserDimension>("GetDimensions");
        }

    }

    internal static class JSFunction
    {

        public static async void DisableField(IJSRuntime js, clsPage page, string field_name, bool enable_fl = true)              
        {
            if (page.bLoading_fl == false)
            {
                await js.InvokeVoidAsync("DisableField", field_name, enable_fl);
            }
        }
        public static async void HideField(IJSRuntime js, clsPage page, string field_name, bool hide_fl = true)              
        {
            if (page.bLoading_fl == false)
            {
                await js.InvokeVoidAsync("HideField", field_name, hide_fl);
            }
        }
        public static async void SetFocus(IJSRuntime js, clsPage page, string field_name)              
        {
            if (page.bLoading_fl == false)
            {
                await js.InvokeVoidAsync("SetFocus", field_name);
            }
        }
        public static async void SetValue(IJSRuntime js, clsPage page, string field_name, string field_value)              
        {
            if (page.bLoading_fl == false)
            {
                await js.InvokeVoidAsync("SetValue", field_name, field_value);
            }
        }
        public static async Task<string> GetValue(IJSRuntime js, string field_name)
        {
            // Invoke the JavaScript function to get the input value of the fieled passed
            return await js.InvokeAsync<string>("eval", "document.getElementById('" + field_name + "').value");
        }
        public static async void ShowMessage(IJSRuntime js, clsPage page, string msg = null, bool error_fl = true)              
        {
            if (page.bLoading_fl == false)
            {
                await js.InvokeVoidAsync("ShowMessage", "divMessage", msg, error_fl);
            }
        }
        public static async void OpenWindow(IJSRuntime js, clsPage page, string page_name)              
        {
            await js.InvokeVoidAsync("OpenWindow", page_name);
        }
        public static async void DownloadFile(IJSRuntime js, clsPage page, string _url, string file_name)
        {
            // await js.InvokeVoidAsync("downloadFromUrl",new { Url = _url, FileName = file_name });
            await js.InvokeVoidAsync("DownloadFromUrl", _url, file_name);
        }

    }
}
