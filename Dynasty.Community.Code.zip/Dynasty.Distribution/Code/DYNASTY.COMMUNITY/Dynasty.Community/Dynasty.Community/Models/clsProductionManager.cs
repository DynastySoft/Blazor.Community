﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//



using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Collections.Generic;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP.Models
{
	public class clsProductionManager
	{
		private int iTransaction_typ = 0;
		private string sPostingError = "";

		private clsArray oArray = new clsArray();
		private clsDynastyUtility oUtility = new clsDynastyUtility();

  //      public clsProductionManager() : base()
		//{

		//}

		public bool IsErrorFound()
		{
			bool return_value = false;

			return_value = (oUtility.IsNonEmpty(sPostingError));

			return return_value;
		}

		public string GetErrorMessage()
		{
			string return_value = "";

			return_value = sPostingError;
			sPostingError = "";

			return return_value;
		}

		public void SetPostingError(string error_msg)
		{
			if (oUtility.IsEmpty(error_msg))
			{
				sPostingError = "";
			}
			else if (oUtility.IsEmpty(sPostingError))
			{
				sPostingError = error_msg;
			}
			else if (oUtility.STrim(sPostingError) != oUtility.STrim(error_msg))
			{
				sPostingError += Environment.NewLine + Environment.NewLine + "AND " + error_msg;
			}
		}
		// When serial/lot items are entered, iNextLine_id will link to each item in the serial/lot list.
		// Once iNextLine_id assigned, it does not changed and maintain the uniqueness during the course of line manipulations such as delete/insert.
		//
		public int iNextLine_id = 1;
		public int iNextKit_id = 1;
		public int iTotalRows = 0;

        public string[] FieldName;                                                              // Keeps the detail field names;
		public string[,] Data;																	// Keeps the detail data.

		public const int INCLUDE_COL = 0;
		public const int ITEM_CODE_COL = 1;
        public const int WO_COL = 2;
        public const int QTY_ORDERED_COL = 3;
        public const int QTY_SHIPPED_COL = 4;
		public const int QTY_TO_ORDER_COL = 5;
        public const int QTY_INASSEMBLY_COL = 6;
        public const int QTY_REORDER_LEVEL_COL = 7;
        public const int QTY_MIN_COL = 8;
        public const int QTY_ON_HAND_COL = 9;
		public const int QTY_ON_ORDER_COL = 10;
		public const int QTY_AVAILABLE_COL = 11;
		public const int IVUNIT_CODE_COL = 12;
		public const int COMMENT_COL = 13;
        public const int LEAD_TIME_COL = 14;
		public const int ITEM_TYPE_COL = 15;
		public const int LINE_TYPE_COL = 16;
		public const int PRIMARY_ITEM_COL = 17;
		public const int UNIT_CODE_COL = 18;
        public const int UNIT_PRICE_COL = 19;
        public const int SOURCE_TYPE_COL = 20;
        public const int SOURCE_NUM_COL = 21;
		public const int SOURCE_DETAIL_ID_COL = 22;
		public const int ORDER_TO_USER_COL = 23;

        public const int DATE_REQUIRED_COL = 24;
        public const int DATE_STARTED_COL = 25;
        public const int DATE_FINISHED_COL = 26;
        public const int TIME_STARTED_COL = 27;
        public const int TIME_FINISHED_COL = 28;

        public const int TOTAL_COLUMNS = 29;

		public class clsGrid
		{
			public int Row_num = 0;                                 // 0-based row number. This will identify each row.
			public bool chkInclude_fl = false;
            public string lblItem_cd = "";
            public string lblWO_num = "";
            public string lblOrdered_qty = "";
            public string lblShipped_qty = "";
            public string txtToOrder_qty = "";
            public string lblInAssembly_qty = "";
            public string lblReorderLevel_qty = "";
            public string lblMin_qty = "";
            public string lblOnHand_qty = "";
            public string lblOnOrder_qty = "";
            public string lblAvailable_qty = "";
            public string lblIVUnit_cd = "";
            public string txtComment = "";			 
            public string lblLeadTime = "";
            public string lblItem_typ = "";
            public string lblLine_typ = "";

            public string lblPrimary_cd = "";
            public string lblUnit_cd = "";
            public string lblUnitPrice_amt = "";
            public string lblSource_typ = "";
            public string lblSource_num = "";
            public string lblSourceDetail_id = "";
            public string txtOrderToUser_cd = "";

            public string txtStarted_dt = "";			// Date manipulation is based on these string dates only.  Corresponding DateTime should be set properly on UI side.
            public string txtFinished_dt = "";
            public string txtRequired_dt = "";
            
			public DateTime? dtStarted_dt = null;		// This is only for UI.   ? means nullable.
            public DateTime? dtFinished_dt = null;		// This is only for UI
            public DateTime? dtRequired_dt = null;		// This is only for UI

			public string txtStartTime = "";
            public string txtEndTime = "";

            public TimeOnly dtStartTime = new TimeOnly();       // Only for UI
            public TimeOnly dtEndTime = new TimeOnly();
        }
		public List<clsGrid> Grid = new List<clsGrid>();

		public bool AddMoreRows(int lines_to_add = 10)
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
                // oUtility.ResizeDimPreserved(ref Data, Data.GetUpperBound(0), Data.GetUpperBound(1) + lines_to_add);

                for (row_num = 0; row_num < lines_to_add; row_num++)
                {
                    Grid.Add(new clsGrid { Row_num = iTotalRows
										,chkInclude_fl = false
										,lblItem_cd = ""
										,lblWO_num = "" 
										,lblOrdered_qty = "" 
										,lblShipped_qty = "" 
										,txtToOrder_qty = "" 
										,lblInAssembly_qty = "" 
										,lblReorderLevel_qty = ""
										,lblMin_qty = "" 
										,lblOnHand_qty = "" 
										,lblOnOrder_qty = "" 
										,lblAvailable_qty = "" 
										,lblIVUnit_cd = "" 
										,txtComment = "" 
										,lblLeadTime = "" 
										,lblItem_typ = "" 
										,lblLine_typ = "" 
										,lblPrimary_cd = ""
										,lblUnit_cd = ""
										,lblUnitPrice_amt = ""
										,lblSource_typ = ""
										,lblSource_num = ""
										,lblSourceDetail_id = ""
										,txtOrderToUser_cd = ""

										,txtStarted_dt = ""
										,txtFinished_dt = ""
										,txtRequired_dt = ""
										,dtStarted_dt = null
										,dtFinished_dt = null
										,dtRequired_dt = null
										,txtStartTime = ""
										,txtEndTime = ""

                    });

                    iTotalRows += 1;
					iNextLine_id += 1;

				}
                
                RecreateDetail();
                return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (AddMoreRows)");
				RecreateDetail();
            }

            return return_value;
        }

		public bool InsertNewRow(clsGrid cur_item, int at_row_num = -1)
        {
			bool return_value = false;

			if (at_row_num < 0)
            {
				at_row_num = cur_item.Row_num;
			}

            try
            {
				Grid.Insert(at_row_num, new clsGrid { Row_num = -1
										,chkInclude_fl = false
										,lblItem_cd = ""
										,lblWO_num = "" 
										,lblOrdered_qty = "" 
										,lblShipped_qty = "" 
										,txtToOrder_qty = "" 
										,lblInAssembly_qty = "" 
										,lblReorderLevel_qty = ""
										,lblMin_qty = "" 
										,lblOnHand_qty = "" 
										,lblOnOrder_qty = "" 
										,lblAvailable_qty = "" 
										,lblIVUnit_cd = "" 
										,txtComment = "" 
										,lblLeadTime = "" 
										,lblItem_typ = "" 
										,lblLine_typ = "" 
										,lblPrimary_cd = ""
										,lblUnit_cd = ""
										,lblUnitPrice_amt = ""
										,lblSource_typ = ""
										,lblSource_num = ""
										,lblSourceDetail_id = ""
										,txtOrderToUser_cd = ""

										,txtStarted_dt = ""
										,txtFinished_dt = ""
										,txtRequired_dt = ""
										,dtStarted_dt = null
										,dtFinished_dt = null
										,dtRequired_dt = null
										,txtStartTime = ""
										,txtEndTime = ""

                });

                Grid.Where(i => i.Row_num >= at_row_num).Select(i => { i.Row_num += 1; return i; }).ToList();
                Grid.Single(i => i.Row_num == -1).Row_num = at_row_num;

				iNextLine_id += 1;
				iTotalRows += 1;

				RecreateDetail();

                return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (InsertNewRow)");
            }

            return return_value;
        }
		public bool DeleteCurrentRow(clsGrid cur_item)
        {
			bool return_value = false;
			int old_num = cur_item.Row_num;

			try
			{
				Grid.RemoveAt(cur_item.Row_num);
				Grid.Where(i => i.Row_num >= old_num).Select(i => { i.Row_num -= 1; return i; }).ToList();

				iTotalRows -= 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
            {
				SetPostingError(ex.Message + " (DeleteCurrentRow)");
			}

			return return_value;
		}

		public bool RecreateDetail()                                                           //  Sync Data with Grid for the items that do not have event-handler ONLY.
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				if (Grid.Count() == 0)
				{
					oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), 0);
					return true;
				}

				// We need to create it here for saving because some fields may not have been copied into the array.
				//
				iTotalRows = Grid.Count();
				oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), iTotalRows - 1);

				foreach (var det in Grid)
				{
					if (RecreateDetailLine(det, row_num) == false)
					{
						return false;
					}

					det.Row_num = row_num;      // Just to make sure.
					row_num++;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetail)");
			}

			return return_value;
		}

		public bool RecreateGridLine(int row_num)
		{
			bool return_value = false;
			clsGrid grid_line = new clsGrid();

			if (FindGridLine(row_num, ref grid_line) == false)
			{
				SetPostingError("Grid does not match array.");
				return false;
			}

			return RecreateGridLine(ref grid_line, row_num);
		}

		public bool RecreateGridLine(ref clsGrid cur_item, int row_num)
        {
			bool return_value = false;

			try
            {
				cur_item.chkInclude_fl = (oUtility.ToInteger(Data[INCLUDE_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON);
				cur_item.lblItem_cd = Data[ITEM_CODE_COL, row_num];
                cur_item.lblWO_num = Data[WO_COL, row_num];
				cur_item.lblOrdered_qty = Data[QTY_ORDERED_COL, row_num];
                cur_item.lblShipped_qty = Data[QTY_SHIPPED_COL, row_num];
				cur_item.txtToOrder_qty = Data[QTY_TO_ORDER_COL, row_num];
				cur_item.lblInAssembly_qty = Data[QTY_INASSEMBLY_COL, row_num];
				cur_item.lblReorderLevel_qty = Data[QTY_REORDER_LEVEL_COL, row_num];
                cur_item.lblMin_qty = Data[QTY_MIN_COL, row_num];
				cur_item.lblOnHand_qty = Data[QTY_ON_HAND_COL, row_num];
				cur_item.lblOnOrder_qty = Data[QTY_ON_ORDER_COL, row_num];
				cur_item.lblAvailable_qty = Data[QTY_AVAILABLE_COL, row_num];
				cur_item.lblIVUnit_cd = Data[IVUNIT_CODE_COL, row_num];
                cur_item.txtComment = Data[COMMENT_COL, row_num];
                cur_item.lblLeadTime = Data[LEAD_TIME_COL, row_num];
				cur_item.lblItem_typ = Data[ITEM_TYPE_COL, row_num];
				cur_item.lblLine_typ = Data[LINE_TYPE_COL, row_num];
                cur_item.lblPrimary_cd = Data[PRIMARY_ITEM_COL, row_num];
                cur_item.lblUnit_cd = Data[UNIT_CODE_COL, row_num];
                cur_item.lblUnitPrice_amt = Data[UNIT_PRICE_COL, row_num];
                cur_item.lblSource_typ = Data[SOURCE_TYPE_COL, row_num];
                cur_item.lblSource_num = Data[SOURCE_NUM_COL, row_num];
                cur_item.lblSourceDetail_id = Data[SOURCE_DETAIL_ID_COL, row_num];
                cur_item.txtOrderToUser_cd = Data[ORDER_TO_USER_COL, row_num];

                cur_item.txtStarted_dt = Data[DATE_STARTED_COL, row_num];
                cur_item.txtFinished_dt = Data[DATE_FINISHED_COL, row_num];
                cur_item.txtRequired_dt = Data[DATE_REQUIRED_COL, row_num];
				cur_item.dtStarted_dt = (oUtility.IsNonEmpty(Data[DATE_STARTED_COL, row_num])? oUtility.ToDateTime(Data[DATE_STARTED_COL, row_num]) : null);
				cur_item.dtFinished_dt = (oUtility.IsNonEmpty(Data[DATE_FINISHED_COL, row_num])? oUtility.ToDateTime(Data[DATE_FINISHED_COL, row_num]) : null);
				cur_item.dtRequired_dt = (oUtility.IsNonEmpty(Data[DATE_REQUIRED_COL, row_num])? oUtility.ToDateTime(Data[DATE_REQUIRED_COL, row_num]) : null);
                cur_item.txtStartTime = Data[TIME_STARTED_COL, row_num];
                cur_item.txtEndTime = Data[TIME_FINISHED_COL, row_num];

            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (RecreateGridLine)");
			}
			return return_value;

		}

		public bool FindGridLine(int row_num, ref clsGrid line_found)
		{
			bool return_value = false;

			try
            {
				line_found = Grid.Single(i => i.Row_num == row_num);

				if (line_found != null)
                {
					return_value = true;
				}
			}
			catch (Exception ex)
            {
				// in case not found
            }

			return return_value;
		}

		public bool RecreateDetailLine(clsGrid cur_item, int row_num = -1)
        {
            bool return_value = false;

            try
            {
				// If this is called from UI event, get the row number of current line.
				//
                if (row_num < 0)
                {
                    row_num = cur_item.Row_num;
                }

                Data[INCLUDE_COL, row_num] = oUtility.IIf(cur_item.chkInclude_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
                Data[ITEM_CODE_COL, row_num] = cur_item.lblItem_cd;
				Data[WO_COL, row_num] = cur_item.lblWO_num;
				Data[QTY_ORDERED_COL, row_num] = cur_item.lblOrdered_qty;
                Data[QTY_SHIPPED_COL, row_num] = cur_item.lblShipped_qty;
				Data[QTY_TO_ORDER_COL, row_num] = cur_item.txtToOrder_qty;
				Data[QTY_INASSEMBLY_COL, row_num] = cur_item.lblInAssembly_qty;
				Data[QTY_REORDER_LEVEL_COL, row_num] = cur_item.lblReorderLevel_qty;
                Data[QTY_MIN_COL, row_num] = cur_item.lblMin_qty;
				Data[QTY_ON_HAND_COL, row_num] = cur_item.lblOnHand_qty;
				Data[QTY_ON_ORDER_COL, row_num] = cur_item.lblOnOrder_qty;
				Data[QTY_AVAILABLE_COL, row_num] = cur_item.lblAvailable_qty;
                Data[IVUNIT_CODE_COL, row_num] = cur_item.lblIVUnit_cd;
                Data[COMMENT_COL, row_num] = cur_item.txtComment;
                Data[LEAD_TIME_COL, row_num] = cur_item.lblLeadTime;
				Data[ITEM_TYPE_COL, row_num] = cur_item.lblItem_typ;
                Data[LINE_TYPE_COL, row_num] = cur_item.lblLine_typ;
                Data[PRIMARY_ITEM_COL, row_num] = cur_item.lblPrimary_cd;
                Data[UNIT_CODE_COL, row_num] = cur_item.lblUnit_cd;
                Data[UNIT_PRICE_COL, row_num] = cur_item.lblUnitPrice_amt;
                Data[SOURCE_TYPE_COL, row_num] = cur_item.lblSource_typ;
                Data[SOURCE_NUM_COL, row_num] = cur_item.lblSource_num;
                Data[SOURCE_DETAIL_ID_COL, row_num] = cur_item.lblSourceDetail_id;
                Data[ORDER_TO_USER_COL, row_num] = cur_item.txtOrderToUser_cd;

                Data[DATE_STARTED_COL, row_num] = cur_item.txtStarted_dt;
                Data[DATE_FINISHED_COL, row_num] = cur_item.txtFinished_dt;
                Data[DATE_REQUIRED_COL, row_num] = cur_item.txtRequired_dt;
                Data[TIME_STARTED_COL, row_num] = cur_item.txtStartTime;
                Data[TIME_FINISHED_COL, row_num] = cur_item.txtEndTime;


                return_value = true;

            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (RecreateDetailLine)");
            }

            return return_value;
        }

        public bool RecreateGrid()                                                             //  Create Grid according to Data
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
				Grid.Clear();

				if (Data == null)
                {
                    return true;
                }
                else if (Data.GetLength(1) == 0)
                {
                    return true;
                }

                iTotalRows = Data.GetLength(1);

                for (row_num = 0; row_num < iTotalRows; row_num++)
                {

                    Grid.Add(new clsGrid { Row_num = row_num

								, chkInclude_fl = (oUtility.ToInteger(Data[INCLUDE_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON)
								, lblItem_cd = Data[ITEM_CODE_COL, row_num]
								, lblWO_num = Data[WO_COL, row_num]
								, lblOrdered_qty = Data[QTY_ORDERED_COL, row_num]
								, lblShipped_qty = Data[QTY_SHIPPED_COL, row_num]
								, txtToOrder_qty = Data[QTY_TO_ORDER_COL, row_num]
								, lblInAssembly_qty = Data[QTY_INASSEMBLY_COL, row_num]
								, lblReorderLevel_qty = Data[QTY_REORDER_LEVEL_COL, row_num]
                                , lblMin_qty = Data[QTY_MIN_COL, row_num]
								, lblOnHand_qty = Data[QTY_ON_HAND_COL, row_num]
								, lblOnOrder_qty = Data[QTY_ON_ORDER_COL, row_num]
								, lblAvailable_qty = Data[QTY_AVAILABLE_COL, row_num]
								, lblIVUnit_cd = Data[IVUNIT_CODE_COL, row_num]
								, txtComment = Data[COMMENT_COL, row_num]
                                , lblLeadTime = Data[LEAD_TIME_COL, row_num]
								, lblItem_typ = Data[ITEM_TYPE_COL , row_num]
                                , lblLine_typ = Data[LINE_TYPE_COL, row_num]
								, lblPrimary_cd = Data[PRIMARY_ITEM_COL, row_num]
								, lblUnit_cd = Data[UNIT_CODE_COL, row_num]
								, lblUnitPrice_amt = Data[UNIT_PRICE_COL, row_num]
								, lblSource_typ = Data[SOURCE_TYPE_COL, row_num]
								, lblSource_num = Data[SOURCE_NUM_COL, row_num]
								, lblSourceDetail_id = Data[SOURCE_DETAIL_ID_COL, row_num]
								, txtOrderToUser_cd = Data[ORDER_TO_USER_COL, row_num]

                                , txtStarted_dt = Data[DATE_STARTED_COL , row_num]
								, txtFinished_dt = Data[DATE_FINISHED_COL , row_num]
								, txtRequired_dt = Data[DATE_REQUIRED_COL , row_num]
								, dtStarted_dt = (oUtility.IsNonEmpty(Data[DATE_STARTED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_STARTED_COL, row_num]) : null)
								, dtFinished_dt = (oUtility.IsNonEmpty(Data[DATE_FINISHED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_FINISHED_COL, row_num]) : null)
								, dtRequired_dt = (oUtility.IsNonEmpty(Data[DATE_REQUIRED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_REQUIRED_COL, row_num]) : null)
                                , txtStartTime = Data[TIME_STARTED_COL , row_num]
                                , txtEndTime = Data[TIME_FINISHED_COL , row_num]
								, dtStartTime = TimeOnly.Parse((Data[TIME_STARTED_COL , row_num] == ""? "12:00 AM" : Data[TIME_STARTED_COL, row_num]), System.Globalization.CultureInfo.CurrentCulture)
								, dtEndTime = TimeOnly.Parse((Data[TIME_FINISHED_COL, row_num] == ""? "12:00 AM" : Data[TIME_FINISHED_COL, row_num]), System.Globalization.CultureInfo.CurrentCulture)

                });
                }

				return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (RecreateGrid)");
            }

            return return_value;
        }

	}

}
