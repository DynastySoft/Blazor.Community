﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Dynasty.Database;

namespace Dynasty.ASP.Models
{
    public class clsPaymentDetail
    {
		public const int INCLUDE_COL = 0;
		public const int ENTITY_CODE_COL = 1;
		public const int ENTITY_NAME_COL = 2;
		public const int APPLIED_TRX_TYPE_COL = 3;
		public const int APPLIED_TRX_NUM_COL = 4;
		public const int APPLIED_TRX_DETAIL_COL = 5;
		public const int APPLIED_TRX_DATE_COL = 6;
		public const int INVOICE_NUM_COL = 7;       // Vendor's invoice num.
		public const int TOTAL_AMT_COL = 8;
		public const int DISC_AVAIL_COL = 9;
		public const int BALANCE_DUE_COL = 10;
		public const int AMT_UNPOSTED_COL = 11;
		public const int CUR_PAYMENT_COL = 12;
		public const int DUE_DATE_COL = 13;
		public const int DISC_TAKEN_COL = 14;
		public const int DISC_DUE_DATE_COL = 15;
		public const int TOTAL_PAID_COL = 16;
		public const int TOTAL_RETURNED_COL = 17;
		public const int CHECK_NUM_COL = 18; 
		public const int CHECK_NUM_COMBINED_COL = 19; // Number is the last check number for each vendor. Multiple stubs can be used to for one check. Then, we keep the last check number and void the others. This is used when a payment transaction is created.
		public const int FUND_CODE_COL = 20;
		public const int PREPAID_TAX_AMT_COL = 21;
		public const int REFERENCE_COL = 22;

		// Multi-currency
		//
		public const int TOTAL_AMT_IN_PRIMARY_CURRENCY_COL = 23;
		public const int CUR_PAYMENT_IN_PRIMARY_CURRENCY_COL = 24;
		public const int DISC_AVAIL_IN_PRIMARY_CURRENCY_COL = 25;
		public const int DISC_TAKEN_IN_PRIMARY_CURRENCY_COL = 26;
		public const int BALANCE_DUE_IN_PRIMARY_CURRENCY_COL = 27;

		public const int TOTAL_COLUMNS = 28;

        public int iTotalRows = 0;

        public string[,] Data;                                                                  // Keeps the detail data.
		public string[] FieldName;																// Keeps the field names

		private string sPostingError = "";
		private clsDynastyUtility oUtility = new clsDynastyUtility();

		public bool IsErrorFound()
		{
			bool return_value = false;

			return_value = (oUtility.IsNonEmpty(sPostingError));

			return return_value;
		}

		public string GetErrorMessage()
		{
			string return_value = "";

			return_value = sPostingError;
			sPostingError = "";

			return return_value;
		}
		public void SetPostingError(string error_msg)
		{
			if (oUtility.IsEmpty(error_msg))
			{
				sPostingError = "";
			}
			else if (oUtility.IsEmpty(sPostingError))
			{
				sPostingError = error_msg;
			}
			else if (oUtility.STrim(sPostingError) != oUtility.STrim(error_msg))
			{
				sPostingError += Environment.NewLine + Environment.NewLine + "AND " + error_msg;
			}
		}

        public class clsGrid
        {
            public int Row_num = 0;                           // Keeps the row number
            public bool chkInclude_fl = false;
            public string txtEntity_cd = "";
            public string txtEntity_nm = "";
            public string txtAppliedTransaction_typ = "";
            public string txtAppliedTransaction_num = "";
            public string txtAppliedTransactionDetail_num = "";
            public string txtAppliedTransaction_dt = "";
            public string txtInvoice_num = "";
			public string txtTotal_amt = "";
            public string txtDiscountAvailable_amt = "";
            public string txtBalanceDue_amt = "";
            public string txtUnposted_amt = "";
            public string txtCurrentPayment_amt = "";
            public string txtDue_dt = "";
            public string txtDiscountTaken_amt = "";
            public string txtPreviousPaid_amt = "";
            public string txtPreviousReturned_amt = "";
            public string txtDiscountDue_dt = "";
            public string txtCheck_num = "";
            public string txtCheckCombined_num = "";
            public string txtFund_cd = "";
            public string txtPrePaidTax_amt = "";
            public string txtReference = "";

			// Multi-currency
			//
			public string txtCurrentPaymentInPrimary_amt = "";
			public string txtDiscountAvailableInPrimary_amt = "";
			public string txtDiscountTakenInPrimary_amt = "";
			public string txtTotalInPrimary_amt = "";
			public string txtBalanceDueInPrimary_amt = "";

		}
		public List<clsGrid> Grid = new List<clsGrid>();

		public bool RecreateDetail()                                                           //  Sync Data with Grid for the items that do not have event-handler ONLY.
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				if (Grid.Count() == 0)
				{
					oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), 0);
					return true;
				}

				// We need to create it here for saving because some fields may not have been copied into the array.
				//
				iTotalRows = Grid.Count();
				oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), iTotalRows - 1);

				foreach (var det in Grid)
				{
					if (RecreateDetailLine(det, row_num) == false)
					{
						return false;
					}

					det.Row_num = row_num;      // Just to make sure.
					row_num++;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetail)");
			}

			return return_value;
		}

		public bool RecreateGridLine(int row_num)
		{
			bool return_value = false;
			clsGrid grid_line = new clsGrid();

			if (FindGridLine(row_num, ref grid_line) == false)
			{
				SetPostingError("Grid does not match array.");
				return false;
			}

			return RecreateGridLine(ref grid_line, row_num);
		}

		public bool RecreateGridLine(ref clsGrid cur_item, int row_num)
		{
			bool return_value = false;

			try
			{
				cur_item.chkInclude_fl = (oUtility.ToInteger(Data[INCLUDE_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON);
				cur_item.txtEntity_cd = Data[ENTITY_CODE_COL, row_num];
				cur_item.txtEntity_nm = Data[ENTITY_NAME_COL, row_num];
				cur_item.txtAppliedTransaction_typ = Data[APPLIED_TRX_TYPE_COL, row_num];
				cur_item.txtAppliedTransaction_num = Data[APPLIED_TRX_NUM_COL, row_num];
				cur_item.txtAppliedTransactionDetail_num = Data[APPLIED_TRX_DETAIL_COL, row_num];
				cur_item.txtInvoice_num = Data[INVOICE_NUM_COL, row_num];
				cur_item.txtTotal_amt = Data[TOTAL_AMT_COL, row_num];
				cur_item.txtDiscountAvailable_amt = Data[DISC_AVAIL_COL, row_num];
				cur_item.txtBalanceDue_amt = Data[BALANCE_DUE_COL, row_num];
				cur_item.txtUnposted_amt = Data[AMT_UNPOSTED_COL, row_num];
				cur_item.txtCurrentPayment_amt = Data[CUR_PAYMENT_COL, row_num];
				cur_item.txtDue_dt = Data[DUE_DATE_COL, row_num];
				cur_item.txtAppliedTransaction_dt = Data[APPLIED_TRX_DATE_COL, row_num];
				cur_item.txtDiscountTaken_amt = Data[DISC_TAKEN_COL, row_num];
				cur_item.txtPreviousPaid_amt = Data[TOTAL_PAID_COL, row_num];
				cur_item.txtPreviousReturned_amt = Data[TOTAL_RETURNED_COL, row_num];
				cur_item.txtDiscountDue_dt = Data[DISC_DUE_DATE_COL, row_num];
				cur_item.txtCheck_num = Data[CHECK_NUM_COL, row_num];
				cur_item.txtCheckCombined_num = Data[CHECK_NUM_COMBINED_COL, row_num];
				cur_item.txtFund_cd = Data[FUND_CODE_COL, row_num];
				cur_item.txtPrePaidTax_amt = Data[PREPAID_TAX_AMT_COL, row_num];
				cur_item.txtReference = Data[REFERENCE_COL, row_num];
				cur_item.txtCurrentPaymentInPrimary_amt = Data[CUR_PAYMENT_IN_PRIMARY_CURRENCY_COL, row_num];
				cur_item.txtDiscountAvailableInPrimary_amt = Data[DISC_AVAIL_IN_PRIMARY_CURRENCY_COL, row_num];
				cur_item.txtDiscountTakenInPrimary_amt = Data[DISC_TAKEN_IN_PRIMARY_CURRENCY_COL, row_num];
				cur_item.txtBalanceDueInPrimary_amt = Data[BALANCE_DUE_IN_PRIMARY_CURRENCY_COL, row_num];
				cur_item.txtTotalInPrimary_amt = Data[TOTAL_AMT_IN_PRIMARY_CURRENCY_COL, row_num];
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateGridLine)");
			}
			return return_value;

		}

		public bool FindGridLine(int row_num, ref clsGrid line_found)
		{
			bool return_value = false;

			try
			{
				line_found = Grid.Single(i => i.Row_num == row_num);

				if (line_found != null)
				{
					return_value = true;
				}
			}
			catch (Exception ex)
			{
				// in case not found
			}

			return return_value;
		}

		public bool RecreateDetailLine(clsGrid cur_item, int row_num = -1)
		{
			bool return_value = false;

			try
			{
				// If this is called from UI event, get the row number of current line.
				//
				if (row_num < 0)
				{
					row_num = cur_item.Row_num;
				}
				Data[INCLUDE_COL, row_num] = oUtility.IIf(cur_item.chkInclude_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
				Data[ENTITY_CODE_COL, row_num] = cur_item.txtEntity_cd;
				Data[ENTITY_NAME_COL, row_num] = cur_item.txtEntity_nm;
				Data[APPLIED_TRX_TYPE_COL, row_num] = cur_item.txtAppliedTransaction_typ;
				Data[APPLIED_TRX_NUM_COL, row_num] = cur_item.txtAppliedTransaction_num;
				Data[APPLIED_TRX_DETAIL_COL, row_num] = cur_item.txtAppliedTransactionDetail_num;
				Data[INVOICE_NUM_COL, row_num] = cur_item.txtInvoice_num;
				Data[TOTAL_AMT_COL, row_num] = cur_item.txtTotal_amt;
				Data[DISC_AVAIL_COL, row_num] = cur_item.txtDiscountAvailable_amt;
				Data[BALANCE_DUE_COL, row_num] = cur_item.txtBalanceDue_amt;
				Data[AMT_UNPOSTED_COL, row_num] = cur_item.txtUnposted_amt;
				Data[CUR_PAYMENT_COL, row_num] = cur_item.txtCurrentPayment_amt;
				Data[DUE_DATE_COL, row_num] = cur_item.txtDue_dt;
				Data[APPLIED_TRX_DATE_COL, row_num] = cur_item.txtAppliedTransaction_dt;
				Data[DISC_TAKEN_COL, row_num] = cur_item.txtDiscountTaken_amt;
				Data[TOTAL_PAID_COL, row_num] = cur_item.txtPreviousPaid_amt;
				Data[TOTAL_RETURNED_COL, row_num] = cur_item.txtPreviousReturned_amt;
				Data[DISC_DUE_DATE_COL, row_num] = cur_item.txtDiscountDue_dt;
				Data[CHECK_NUM_COL, row_num] = cur_item.txtCheck_num;
				Data[CHECK_NUM_COMBINED_COL, row_num] = cur_item.txtCheckCombined_num;
				Data[FUND_CODE_COL, row_num] = cur_item.txtFund_cd;
				Data[PREPAID_TAX_AMT_COL, row_num] = cur_item.txtPrePaidTax_amt;
				Data[REFERENCE_COL, row_num] = cur_item.txtReference;
				Data[CUR_PAYMENT_IN_PRIMARY_CURRENCY_COL, row_num] = cur_item.txtCurrentPaymentInPrimary_amt;
				Data[DISC_AVAIL_IN_PRIMARY_CURRENCY_COL, row_num] = cur_item.txtDiscountAvailableInPrimary_amt;
				Data[DISC_TAKEN_IN_PRIMARY_CURRENCY_COL, row_num] = cur_item.txtDiscountTakenInPrimary_amt;
				Data[BALANCE_DUE_IN_PRIMARY_CURRENCY_COL, row_num] = cur_item.txtBalanceDueInPrimary_amt;
				Data[TOTAL_AMT_IN_PRIMARY_CURRENCY_COL, row_num] = cur_item.txtTotalInPrimary_amt;

				return_value = true;

			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetailLine)");
			}

			return return_value;
		}

		public bool RecreateGrid()                                                             //  Create Grid according to Data
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				Grid.Clear();

				if (Data == null)
				{
					return true;
				}
				else if (Data.GetLength(1) == 0)
				{
					return true;
				}

				iTotalRows = Data.GetLength(1);

				for (row_num = 0; row_num < iTotalRows; row_num++)
				{
					Grid.Add(new clsGrid
					{
						Row_num = row_num
						,chkInclude_fl = (oUtility.ToInteger(Data[INCLUDE_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON)
						,txtEntity_cd = Data[ENTITY_CODE_COL, row_num]
						,txtEntity_nm = Data[ENTITY_NAME_COL, row_num]
						,txtAppliedTransaction_typ = Data[APPLIED_TRX_TYPE_COL, row_num]
						,txtAppliedTransaction_num = Data[APPLIED_TRX_NUM_COL, row_num]
						,txtAppliedTransactionDetail_num = Data[APPLIED_TRX_DETAIL_COL, row_num]
						,txtInvoice_num = Data[INVOICE_NUM_COL, row_num]
						,txtTotal_amt = Data[TOTAL_AMT_COL, row_num]
						,txtDiscountAvailable_amt = Data[DISC_AVAIL_COL, row_num]
						,txtBalanceDue_amt = Data[BALANCE_DUE_COL, row_num]
						,txtUnposted_amt = Data[AMT_UNPOSTED_COL, row_num]
						,txtCurrentPayment_amt = Data[CUR_PAYMENT_COL, row_num]
						,txtDue_dt = Data[DUE_DATE_COL, row_num]
						,txtAppliedTransaction_dt = Data[APPLIED_TRX_DATE_COL, row_num]
						,txtDiscountTaken_amt = Data[DISC_TAKEN_COL, row_num]
						,txtPreviousPaid_amt = Data[TOTAL_PAID_COL, row_num]
						,txtPreviousReturned_amt = Data[TOTAL_RETURNED_COL, row_num]
						,txtDiscountDue_dt = Data[DISC_DUE_DATE_COL, row_num]
						,txtCheck_num = Data[CHECK_NUM_COL, row_num]
						,txtCheckCombined_num = Data[CHECK_NUM_COMBINED_COL, row_num]
						,txtFund_cd = Data[FUND_CODE_COL, row_num]
						,txtPrePaidTax_amt = Data[PREPAID_TAX_AMT_COL, row_num]
						,txtReference = Data[REFERENCE_COL, row_num]
						,txtCurrentPaymentInPrimary_amt = Data[CUR_PAYMENT_IN_PRIMARY_CURRENCY_COL, row_num]
						,txtDiscountAvailableInPrimary_amt = Data[DISC_AVAIL_IN_PRIMARY_CURRENCY_COL, row_num]
						,txtDiscountTakenInPrimary_amt = Data[DISC_TAKEN_IN_PRIMARY_CURRENCY_COL, row_num]
						,txtBalanceDueInPrimary_amt = Data[BALANCE_DUE_IN_PRIMARY_CURRENCY_COL, row_num]
						,txtTotalInPrimary_amt = Data[TOTAL_AMT_IN_PRIMARY_CURRENCY_COL, row_num]

					});
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateGrid)");
			}

			return return_value;
		}

	}
}
