﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Dynasty.Local;
using Dynasty.Database;

namespace Dynasty.ASP.Models
{
    public class clsUser
    {
		public string sPage_nm = "";                            // Current page name
		public int iBatch_num = 0;
		public bool bBatchEnabled_fl = false;
		public bool bHideManu_fl = false;
		public bool bEnablePageLevelSecurity_fl = false;

		public string sWebSite = "";                            //  This should be set to actual URL.
		public string sUser_cd = "";
		public string sUser_nm = "";
		public string sPassword = "";
		public string sCompany_nm = "";
        public string sConnectionString = "";
        public string sServer_nm = "";
        public string sDatabase_nm = "";
		public string sCCNServer_nm = "";
		public string sCCNDatabase_nm = "";
		public string sCCN = "";
        public string sDSN = "";						
		public string sLanguage_cd = "";
		public string sEmailAddress = "";
		public string sOffice_cd = "";					
		public string sPIN = "";
		public string sEmployee_cd = "";
		public string sLocation_cd = "";

		public bool bBlockTransaction_fl = false;
        public bool bUseSQLProcedures_fl = false;
		public bool bRestrictLocation_fl = false;
		public bool bAdmin_fl = false;
		public bool bAccounting_fl = false;
		public bool bSales_fl = false;
		public bool bAR_fl = false;
		public bool bPurchasing_fl = false;
		public bool bAP_fl = false;
		public bool bWH_fl = false;
		public bool bHelpdesk_fl = false;
		public bool bTemp_fl = false;

		public int iLinesToIncrease = 10;

		public int iWindowWidth = 0;
		public int iWindowHeight = 0;

		// Datetime component is not very user-friendly, yet, as of VS2019
		// Until we find a better way to handle datetime, we will give user an option to use either date picker or plain textbox.
		// We maintain two types of date field, one type of plain textbox whose name starts with "msk" and another type of datetime whose name starts with "dt".  
		// If bUseDatePicker_fl == false, plain textbox(msk*) become visible for faster data entry, skilled keyboard users.
		// Otherwise, datetime(dt*) will become visible for mouse users.
		// datetime(dt*) fields are for UI only. All internal process should relay on msk* fields.
		// Good example is Salesrep page.  For sample code, follow bUseDatePicker_fl in Salesrep.cs and Salesrep.razor.
		//
		public bool bUseDatePicker_fl = true;

		// User preference to disable columns in transaction pages such as invoice & order
		//
		public bool bDisableDescription_fl = false;
		public bool bDisableQuantity_fl = false;
		public bool bDisableUnitCode_fl = false;
		public bool bDisableUnitPrice_fl = false;

		// CSS for item code and description.
		public string sItemCodeCSS = ".CodeMed";
		public string sARItemDescCSS = "ARDescStd";
		public string sAPItemDescCSS = "APDescStd";

		// page style preference for each user.
		public string sBackColor = "white";					// Not yet
		public string sColor = "black";
		public int iFontSize = 11;
		public string Style
		{
            get { 

				string _style = "";
				
				if (GlobalVar.goUtility.IsNonEmpty(sColor))
				{
					_style += "color:" + sColor + ";";
				}
				if (GlobalVar.goUtility.IsNonEmpty(sBackColor))
				{
					_style += "background-color:" + sBackColor + ";";
				}
				if (iFontSize >= 8)
				{
					_style += "font-size:" + iFontSize.ToString() + "pt;";
				}

				return _style; 
			}
        }

        // Default money & date type.
        public int iDate_typ = GlobalVar.goConstant.DATE_MMDDYYYY;                    
		public int iMoney_typ = GlobalVar.goConstant.ROUND_TO_CENT;                    

		// User role & accessibility
		//
		public int iUserType_id = 0;                    // Current user-type such as member, manager, director
		public string sUserGroup_cd = ""; // Current user-group
		public int iPageSecurityLevel = 0;

		// Extra info
		public string sHomeDirectory_nm = "";
		public string sReportDirectory_nm = "";
		public bool bConnected_fl = false;

        public bool bUseComboboxForCashAccount_fl;

        public clsDatabase.clsLanguage Language = new clsDatabase.clsLanguage();

		public bool ViewOnly
		{
            get { return (iUserType_id == 0 || iUserType_id == clsConstant.USER_VIEW_ONLY_TYPE || (iUserType_id < clsConstant.USER_SA_TYPE && iPageSecurityLevel > 0)); }
        }

		public bool HideLogOut
		{
			get { return IsMobile; }										// If mobile,  We want to hide logout button because it takes up space.
		}

		public bool IsMobile
        {
			get { return (iWindowWidth > 0 && iWindowWidth < 1000); }       
		}

        public void Clear()
        {
			sConnectionString = "";
			sUser_cd = "";
			sPassword = "";
			sCompany_nm = "";
			sServer_nm = "";
			sDatabase_nm = "";
			sDSN = "";
			sCCN = "";
		}

		public bool SetPreference(ref clsDatabase cur_db)
        {
			string sql_str = "";

			sql_str = "UPDATE tblGOUser SET ";
			sql_str += " iDisableDescription_fl = " + GlobalVar.goUtility.IIf(bDisableDescription_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
			sql_str += ",iDisableQuantity_fl = " + GlobalVar.goUtility.IIf(bDisableQuantity_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
			sql_str += ",iDisableUnitCode_fl = " + GlobalVar.goUtility.IIf(bDisableUnitCode_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
			sql_str += ",iDisableUnitPrice_fl = " + GlobalVar.goUtility.IIf(bDisableUnitPrice_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
			sql_str += ",sColor = '" + sColor + "'" ;
			sql_str += ",sBackColor = '" + sBackColor + "'" ;
			sql_str += ",iFontSize = " + iFontSize.ToString();
			sql_str += " WHERE sUser_cd = '" + sUser_cd + "'";

			return cur_db.ExecuteSQL(sql_str);
		}
    }
}
