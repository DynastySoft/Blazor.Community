﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Dynasty.Database;

namespace Dynasty.ASP.Models
{
    public class clsJobPlan
    {
		private clsDynastyUtility oUtility = new clsDynastyUtility();

		public bool chkHideComment_fl = false;

		public const int INCLUDE_COL = 0;
		public const int PHASE_ID_COL = 1;
		public const int TASK_ID_COL = 2;
		public const int DETAIL_NUM_COL = 3;
		public const int TASK_TYPE_CODE_COL = 4;
		public const int ITEM_CODE_COL = 5;
		public const int ASSET_CODE_COL = 6;
		public const int RENTAL_ITEM_CODE_COL = 7;
		public const int SUPERVISOR_CODE_COL = 8;
		public const int EMPLOYEE_CODE_COL = 9;
		public const int STAFF_NAME_COL = 10;
		public const int DESCRIPTION_COL = 11;
		public const int COMMENT_COL = 12;
		public const int PERCENTAGE_DONE_COL = 13;
		public const int DATE_EXPECTED_FROM_COL = 14;
		public const int DATE_EXPECTED_THRU_COL = 15;
		public const int DATE_FROM_COL = 16;
		public const int DATE_THRU_COL = 17;
		public const int DATE_INSPECTED_COL = 18;
		public const int DATE_REQUIRED_COL = 19;
		public const int DATE_RETURN_COL = 20;
		public const int PREREQUISITE_COL = 21;
		public const int RISK_ID_COL = 22;
		public const int DAYS_EXPECTED_COL = 23;
		public const int DAYS_ACTUAL_COL = 24;
		public const int UNIT_CODE_COL = 25;
		public const int QTY_COL = 26;
		public const int PO_NUM_COL = 27;
		
		public const int TOTAL_COLUMNS = 28;

        public int iNextLine_id = 1;
        public int iTotalRows = 0;

        public string[,] Data;                                                                  // Keeps the detail data.
		public string[] FieldName;																// List of field names
		public string[] Caption;                                                                // List of column captions

		private string sPostingError = "";

		public clsJobPlan() : base()
		{
			try
			{
				oUtility.ResizeDim(ref Data, TOTAL_COLUMNS - 1, 0);
				RecreateGrid();
			}
			catch (Exception ex)
			{
				//
			}
		}


		public bool Clear(int initial_rows = 1)
		{
			bool return_value = false;

			iTotalRows = initial_rows;
			oUtility.ResizeDim(ref Data, TOTAL_COLUMNS - 1, initial_rows - 1);
			RecreateGrid();

			return return_value;
		}

		public bool IsErrorFound()
		{
			bool return_value = false;

			return_value = (oUtility.IsNonEmpty(sPostingError));

			return return_value;
		}

		public string GetErrorMessage()
		{
			string return_value = "";

			return_value = sPostingError;
			sPostingError = "";

			return return_value;
		}
		public void SetPostingError(string error_msg)
		{
			if (oUtility.IsEmpty(error_msg))
			{
				sPostingError = "";
			}
			else if (oUtility.IsEmpty(sPostingError))
			{
				sPostingError = error_msg;
			}
			else if (oUtility.STrim(sPostingError) != oUtility.STrim(error_msg))
			{
				sPostingError += Environment.NewLine + Environment.NewLine + "AND " + error_msg;
			}
		}

        public class clsGrid
        {
            public int Row_num = 0;                           // Keeps the row number
            public bool chkInclude_fl = false;				  
			public string txtPhase_id = "";
			public string txtTask_id = "";
			public string txtDetail_num = "";						// Line id of staff, material, equipment & rental
			public string txtTask_cd = "";
			public string txtItem_cd = "";
			public string txtAsset_cd = "";
			public string txtRentalItem_cd = "";
			public string txtSupervisor_cd = "";
			public string txtEmployee_cd = "";
			public string txtStaff_nm = "";
			public string txtDescription = "";
			public string txtComment = "";
			public int txtPercentageDone = 0;
			public string txtExpectedFrom_dt = "";
			public string txtExpectedThru_dt = "";
			public string txtFrom_dt = "";
			public string txtThru_dt = "";
			public string txtInspected_dt = "";
			public string txtRequired_dt = "";
			public string txtReturn_dt = "";
			public string txtPrerequisite = "";
			public string txtRisk_id = "";
			public string txtDaysExpected = "";
			public string txtDaysActual = "";
			public string txtUnit_cd = "";
			public string txtQty = "";
			public string txtPO_num = "";

            public DateTime? dtExpectedFrom_dt = null;      // These are only for UI
            public DateTime? dtExpectedThru_dt = null;      
            public DateTime? dtFrom_dt = null;      
            public DateTime? dtThru_dt = null;      
            public DateTime? dtInspected_dt = null;
            public DateTime? dtRequired_dt = null;
            public DateTime? dtReturn_dt = null;

        }
        public List<clsGrid> Grid = new List<clsGrid>();

		public bool AddMoreRows(int lines_to_add = 5)
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
                // oUtility.ResizeDimPreserved(ref Data, Data.GetUpperBound(0), Data.GetUpperBound(1) + lines_to_add);

                for (row_num = 0; row_num < lines_to_add; row_num++)
                {
                    Grid.Add(new clsGrid { Row_num = iTotalRows
							, chkInclude_fl = false
							, txtPhase_id = ""
							, txtTask_id = ""
							, txtDetail_num = ""						
							, txtTask_cd = ""
							, txtItem_cd = ""
							, txtAsset_cd = ""
							, txtRentalItem_cd = ""
							, txtSupervisor_cd = ""
							, txtEmployee_cd = ""
							, txtStaff_nm = ""
							, txtDescription = ""
							, txtComment = ""
							, txtPercentageDone = 0
							, txtExpectedFrom_dt = ""
							, txtExpectedThru_dt = ""
							, txtFrom_dt = ""
							, txtThru_dt = ""
							, txtInspected_dt = ""
							, txtRequired_dt = ""
							, txtReturn_dt = ""
							, txtPrerequisite = ""
							, txtRisk_id = ""
							, txtDaysExpected = ""
							, txtDaysActual = ""
							, txtUnit_cd = ""
							, txtQty = ""
							, txtPO_num = ""
							, dtExpectedFrom_dt = null
							, dtExpectedThru_dt =null
							, dtFrom_dt =null
							, dtThru_dt =null
							, dtInspected_dt =null
							, dtRequired_dt =null
							, dtReturn_dt = null
                    });

                    iTotalRows += 1;
					iNextLine_id += 1;
				}
                
                RecreateDetail();
                return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (AddMoreRows)");
				RecreateDetail();
            }

            return return_value;
        }

		public bool InsertNewRow(clsGrid cur_item)
		{
			bool return_value = false;
			int old_row_num = cur_item.Row_num;

			try
			{
				Grid.Insert(old_row_num, new clsGrid
				{
					Row_num = -1
					, chkInclude_fl = false
					, txtPhase_id = ""
					, txtTask_id = ""
					, txtDetail_num = ""						
					, txtTask_cd = ""
					, txtItem_cd = ""
					, txtAsset_cd = ""
					, txtRentalItem_cd = ""
					, txtSupervisor_cd = ""
					, txtEmployee_cd = ""
					, txtStaff_nm = ""
					, txtDescription = ""
					, txtComment = ""
					, txtPercentageDone = 0
					, txtExpectedFrom_dt = ""
					, txtExpectedThru_dt = ""
					, txtFrom_dt = ""
					, txtThru_dt = ""
					, txtInspected_dt = ""
					, txtRequired_dt = ""
					, txtReturn_dt = ""
					, txtPrerequisite = ""
					, txtRisk_id = ""
					, txtDaysExpected = ""
					, txtDaysActual = ""
					, txtUnit_cd = ""
					, txtQty = ""
					, txtPO_num = ""
					, dtExpectedFrom_dt = null
					, dtExpectedThru_dt =null
					, dtFrom_dt =null
					, dtThru_dt =null
					, dtInspected_dt =null
					, dtRequired_dt =null
					, dtReturn_dt = null
				}); 

				Grid.Where(i => i.Row_num >= old_row_num).Select(i => { i.Row_num += 1; return i; }).ToList();
				Grid.Single(i => i.Row_num == -1).Row_num = old_row_num;

				iNextLine_id += 1;
				iTotalRows += 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (InsertNewRow)");
			}

			return return_value;
		}

		public bool DeleteCurrentRow(clsGrid cur_item)
		{
			bool return_value = false;
			int old_num = cur_item.Row_num;

			try
			{
				Grid.RemoveAt(cur_item.Row_num);
				Grid.Where(i => i.Row_num >= old_num).Select(i => { i.Row_num -= 1; return i; }).ToList();

				iTotalRows -= 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (DeleteCurrentRow)");
			}

			return return_value;
		}


		public bool DeleteCurrentRow(int row_num)
		{
			bool return_value = false;
			int old_num = row_num;

			try
			{
				Grid.RemoveAt(row_num);
				Grid.Where(i => i.Row_num >= old_num).Select(i => { i.Row_num -= 1; return i; }).ToList();

				iTotalRows -= 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (DeleteCurrentRow)");
			}

			return return_value;
		}
		public bool RecreateDetail()                                                           //  Sync Data with Grid for the items that do not have event-handler ONLY.
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				if (Grid.Count() == 0)
				{
					oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), 0);
					return true;
				}

				// We need to create it here for saving because some fields may not have been copied into the array.
				//
				iTotalRows = Grid.Count();
				oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), iTotalRows - 1);

				foreach (var det in Grid)
				{
					if (RecreateDetailLine(det, row_num) == false)
					{
						return false;
					}

					det.Row_num = row_num;      // Just to make sure.
					row_num++;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetail)");
			}

			return return_value;
		}

		public bool RecreateGridLine(int row_num)
		{
			bool return_value = false;
			clsGrid grid_line = new clsGrid();

			if (FindGridLine(row_num, ref grid_line) == false)
			{
				SetPostingError("Grid does not match array.");
				return false;
			}

			return RecreateGridLine(ref grid_line, row_num);
		}

		public bool RecreateGridLine(ref clsGrid cur_item, int row_num)
		{
			bool return_value = false;

			try
			{
				cur_item.chkInclude_fl = (GlobalVar.goUtility.ToInteger(Data[INCLUDE_COL, row_num]) == 1);
				cur_item.txtPhase_id = Data[PHASE_ID_COL, row_num];
				cur_item.txtTask_id = Data[TASK_ID_COL, row_num];
				cur_item.txtDetail_num = Data[DETAIL_NUM_COL, row_num];
				cur_item.txtTask_cd = Data[TASK_TYPE_CODE_COL, row_num];
				cur_item.txtItem_cd = Data[ITEM_CODE_COL, row_num];
				cur_item.txtAsset_cd = Data[ASSET_CODE_COL, row_num];
				cur_item.txtRentalItem_cd = Data[RENTAL_ITEM_CODE_COL, row_num];
				cur_item.txtSupervisor_cd = Data[SUPERVISOR_CODE_COL, row_num];
				cur_item.txtEmployee_cd = Data[EMPLOYEE_CODE_COL, row_num];
				cur_item.txtStaff_nm = Data[STAFF_NAME_COL, row_num];
				cur_item.txtDescription = Data[DESCRIPTION_COL, row_num];
				cur_item.txtComment = Data[COMMENT_COL, row_num];
				cur_item.txtPercentageDone = oUtility.ToInteger(Data[PERCENTAGE_DONE_COL, row_num]);
				cur_item.txtExpectedFrom_dt = Data[DATE_EXPECTED_FROM_COL, row_num];
				cur_item.txtExpectedThru_dt = Data[DATE_EXPECTED_THRU_COL, row_num];
				cur_item.txtFrom_dt = Data[DATE_FROM_COL, row_num];
				cur_item.txtThru_dt = Data[DATE_THRU_COL, row_num];
				cur_item.txtInspected_dt = Data[DATE_INSPECTED_COL, row_num];
				cur_item.txtRequired_dt = Data[DATE_REQUIRED_COL, row_num];
				cur_item.txtReturn_dt = Data[DATE_RETURN_COL, row_num];
				cur_item.txtPrerequisite = Data[PREREQUISITE_COL, row_num];
				cur_item.txtRisk_id = Data[RISK_ID_COL, row_num];
				cur_item.txtDaysExpected = Data[DAYS_EXPECTED_COL, row_num];
				cur_item.txtDaysActual = Data[DAYS_ACTUAL_COL, row_num];
				cur_item.txtUnit_cd = Data[UNIT_CODE_COL, row_num];
				cur_item.txtQty = Data[QTY_COL, row_num];
				cur_item.txtPO_num = Data[PO_NUM_COL, row_num];
                cur_item.dtExpectedFrom_dt = (oUtility.IsNonEmpty(Data[DATE_EXPECTED_FROM_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_EXPECTED_FROM_COL, row_num]) : null);
                cur_item.dtExpectedThru_dt = (oUtility.IsNonEmpty(Data[DATE_EXPECTED_THRU_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_EXPECTED_THRU_COL, row_num]) : null);
                cur_item.dtFrom_dt = (oUtility.IsNonEmpty(Data[DATE_FROM_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_FROM_COL, row_num]) : null);
                cur_item.dtThru_dt = (oUtility.IsNonEmpty(Data[DATE_THRU_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_THRU_COL, row_num]) : null);
                cur_item.dtInspected_dt = (oUtility.IsNonEmpty(Data[DATE_INSPECTED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_INSPECTED_COL, row_num]) : null);
                cur_item.dtRequired_dt = (oUtility.IsNonEmpty(Data[DATE_REQUIRED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_REQUIRED_COL, row_num]) : null);
                cur_item.dtReturn_dt = (oUtility.IsNonEmpty(Data[DATE_RETURN_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_RETURN_COL, row_num]) : null);

            }
            catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateGridLine)");
			}
			return return_value;

		}

		public bool FindGridLine(int row_num, ref clsGrid line_found)
		{
			bool return_value = false;

			try
			{
				line_found = Grid.Single(i => i.Row_num == row_num);

				if (line_found != null)
				{
					return_value = true;
				}
			}
			catch (Exception ex)
			{
				// in case not found
			}

			return return_value;
		}

		public bool RecreateDetailLine(clsGrid cur_item, int row_num = -1)
		{
			bool return_value = false;

			try
			{
				// If this is called from UI event, get the row number of current line.
				//
				if (row_num < 0)
				{
					row_num = cur_item.Row_num;
				}

				Data[INCLUDE_COL, row_num] = (cur_item.chkInclude_fl ? "1" : "0");
				Data[PHASE_ID_COL, row_num] = cur_item.txtPhase_id;
				Data[TASK_ID_COL, row_num] = cur_item.txtTask_id;
				Data[DETAIL_NUM_COL, row_num] = cur_item.txtDetail_num;
				Data[TASK_TYPE_CODE_COL, row_num] = cur_item.txtTask_cd;
				Data[ITEM_CODE_COL, row_num] = cur_item.txtItem_cd;
				Data[ASSET_CODE_COL, row_num] = cur_item.txtAsset_cd;
				Data[RENTAL_ITEM_CODE_COL, row_num] = cur_item.txtRentalItem_cd;
				Data[SUPERVISOR_CODE_COL, row_num] = cur_item.txtSupervisor_cd;
				Data[EMPLOYEE_CODE_COL, row_num] = cur_item.txtEmployee_cd;
				Data[STAFF_NAME_COL, row_num] = cur_item.txtStaff_nm;
				Data[DESCRIPTION_COL, row_num] = cur_item.txtDescription;
				Data[COMMENT_COL, row_num] = cur_item.txtComment;
				Data[PERCENTAGE_DONE_COL, row_num] = cur_item.txtPercentageDone.ToString();
				Data[DATE_EXPECTED_FROM_COL, row_num] = cur_item.txtExpectedFrom_dt;
				Data[DATE_EXPECTED_THRU_COL, row_num] = cur_item.txtExpectedThru_dt;
				Data[DATE_FROM_COL, row_num] = cur_item.txtFrom_dt;
				Data[DATE_THRU_COL, row_num] = cur_item.txtThru_dt;
				Data[DATE_INSPECTED_COL, row_num] = cur_item.txtInspected_dt;
				Data[DATE_REQUIRED_COL, row_num] = cur_item.txtRequired_dt;
				Data[DATE_RETURN_COL, row_num] = cur_item.txtReturn_dt;
				Data[PREREQUISITE_COL, row_num] = cur_item.txtPrerequisite;
				Data[RISK_ID_COL, row_num] = cur_item.txtRisk_id;
				Data[DAYS_EXPECTED_COL, row_num] = cur_item.txtDaysExpected;
				Data[DAYS_ACTUAL_COL, row_num] = cur_item.txtDaysActual;
				Data[UNIT_CODE_COL, row_num] = cur_item.txtUnit_cd;
				Data[QTY_COL, row_num] = cur_item.txtQty;
				Data[PO_NUM_COL, row_num] = cur_item.txtPO_num;

				return_value = true;

			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetailLine)");
			}

			return return_value;
		}

		public bool RecreateGrid()                                                             //  Create Grid according to Data
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				Grid.Clear();

				if (Data == null)
				{
					return true;
				}
				else if (Data.GetLength(1) == 0)
				{
					return true;
				}

				iTotalRows = Data.GetLength(1);

				for (row_num = 0; row_num < iTotalRows; row_num++)
				{
					Grid.Add(new clsGrid
					{
						Row_num = row_num
						,chkInclude_fl = (GlobalVar.goUtility.ToInteger(Data[INCLUDE_COL, row_num]) == 1)
						,txtPhase_id = Data[PHASE_ID_COL, row_num]
						,txtTask_id = Data[TASK_ID_COL, row_num]
						,txtDetail_num = Data[DETAIL_NUM_COL, row_num]
						,txtTask_cd = Data[TASK_TYPE_CODE_COL, row_num]
						,txtItem_cd = Data[ITEM_CODE_COL, row_num]
						,txtAsset_cd = Data[ASSET_CODE_COL, row_num]
						,txtRentalItem_cd = Data[RENTAL_ITEM_CODE_COL, row_num]
						,txtSupervisor_cd = Data[SUPERVISOR_CODE_COL, row_num]
						,txtEmployee_cd = Data[EMPLOYEE_CODE_COL, row_num]
						,txtStaff_nm = Data[STAFF_NAME_COL, row_num]
						,txtDescription = Data[DESCRIPTION_COL, row_num]
						,txtComment = Data[COMMENT_COL, row_num]
						,txtPercentageDone = oUtility.ToInteger(Data[PERCENTAGE_DONE_COL, row_num])
						,txtExpectedFrom_dt = Data[DATE_EXPECTED_FROM_COL, row_num]
						,txtExpectedThru_dt = Data[DATE_EXPECTED_THRU_COL, row_num]
						,txtFrom_dt = Data[DATE_FROM_COL, row_num]
						,txtThru_dt = Data[DATE_THRU_COL, row_num]
						,txtInspected_dt = Data[DATE_INSPECTED_COL, row_num]
						,txtRequired_dt = Data[DATE_REQUIRED_COL, row_num]
						,txtReturn_dt = Data[DATE_RETURN_COL, row_num]
						,txtPrerequisite = Data[PREREQUISITE_COL, row_num]
						,txtRisk_id = Data[RISK_ID_COL, row_num]
						,txtDaysExpected = Data[DAYS_EXPECTED_COL, row_num]
						,txtDaysActual = Data[DAYS_ACTUAL_COL, row_num]
						,txtUnit_cd = Data[UNIT_CODE_COL, row_num]
						,txtQty = Data[QTY_COL, row_num]
						,txtPO_num = Data[PO_NUM_COL, row_num]
						,dtExpectedFrom_dt = (oUtility.IsNonEmpty(Data[DATE_EXPECTED_FROM_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_EXPECTED_FROM_COL, row_num]) : null)
						,dtExpectedThru_dt = (oUtility.IsNonEmpty(Data[DATE_EXPECTED_THRU_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_EXPECTED_THRU_COL, row_num]) : null)
						,dtFrom_dt = (oUtility.IsNonEmpty(Data[DATE_FROM_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_FROM_COL, row_num]) : null)
						,dtThru_dt = (oUtility.IsNonEmpty(Data[DATE_THRU_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_THRU_COL, row_num]) : null)
						,dtInspected_dt = (oUtility.IsNonEmpty(Data[DATE_INSPECTED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_INSPECTED_COL, row_num]) : null)
						,dtRequired_dt = (oUtility.IsNonEmpty(Data[DATE_REQUIRED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_REQUIRED_COL, row_num]) : null)
						,dtReturn_dt = (oUtility.IsNonEmpty(Data[DATE_RETURN_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_RETURN_COL, row_num]) : null)
                });
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateGrid)");
			}

			return return_value;
		}

		public bool Swap(int first_line, int second_line, int static_col = -1)
        {
			bool return_value = false;
			int col_num = 0;
			string temp_cell = "";

			try
            {
				if (Data.GetUpperBound(1) < first_line || Data.GetUpperBound(1) < second_line)
                {
					return true;
                }

				for (col_num = 0; col_num < Data.GetLength(1); col_num++)
                {
					if (col_num != static_col)      // Do not change static_col
					{
						temp_cell = Data[col_num, first_line];
						Data[col_num, first_line] = Data[col_num, second_line];
						Data[col_num, second_line] = temp_cell;
					}
				}

				RecreateGridLine(first_line);
				RecreateGridLine(second_line);

				return_value = true;
			}
			catch (Exception ex)
            {
				SetPostingError(ex.Message + " (Swap)");
            }


			return return_value;
		}

	}
}
