﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Linq;
using System.Collections.Generic;

using Dynasty.Database;

namespace Dynasty.ASP.Models
{
    public class clsCustomField
    {

        private clsDynastyUtility oUtility = new clsDynastyUtility();
        private string sPostingError = "";

        public class clsGrid
        {
            public int Row_num = 0;
            public string Field_nm = "";
            public string Caption = "";
            public string Value = "";
			public bool Required = false;
        }
		public List<clsGrid> Grid = new List<clsGrid>();

		public bool IsErrorFound()
		{
			bool return_value = false;

			return_value = (oUtility.IsNonEmpty(sPostingError));

			return return_value;
		}

		public string GetErrorMessage()
		{
			string return_value = "";

			return_value = sPostingError;
			sPostingError = "";

			return return_value;
		}
		public void SetPostingError(string error_msg)
		{
			if (oUtility.IsEmpty(error_msg))
			{
				sPostingError = "";
			}
			else if (oUtility.IsEmpty(sPostingError))
			{
				sPostingError = error_msg;
			}
			else if (oUtility.STrim(sPostingError) != oUtility.STrim(error_msg))
			{
				sPostingError += Environment.NewLine + Environment.NewLine + "AND " + error_msg;
			}
		}

		public bool CreateGrid(string[] field_name, string[] field_caption, bool[] field_required)
        {
			bool return_value = false;
			int row_num = 0;

			try
			{
				Grid.Clear();

				for ( row_num = 0; row_num < field_name.GetLength(0); row_num++)
				{
					if (oUtility.IsEmpty(field_name[row_num]) || oUtility.IsEmpty(field_caption[row_num]))
                    {
						break;
                    }

					Grid.Add(new clsGrid
					{
						Row_num = row_num
						, Field_nm = field_name[row_num]
						, Caption = field_caption[row_num]
						, Required = field_required[row_num]
						, Value = ""
					}); 

				}

				return_value = true;
			}
			catch (Exception ex)
            {
				SetPostingError(ex.Message);
            }

			return return_value;
		}

		public bool ClearGrid()
        {
			foreach (clsGrid det in Grid)
            {
				det.Value = "";
            }

			return true;
        }

		public bool IsNumericField(clsGrid cur_item)
        {
			return (oUtility.SUCase(oUtility.SRight(cur_item.Field_nm, 4)) == "_NUM");
		}

		public bool IsIntegerField(clsGrid cur_item)
		{
			return (oUtility.SUCase(oUtility.SLeft(cur_item.Field_nm, 1)) == "I");
		}

		public bool IsDateField(clsGrid cur_item)
		{
			return (oUtility.SUCase(oUtility.SRight(cur_item.Field_nm, 3)) == "_DT");
		}

		public bool IsMoneyField(clsGrid cur_item)
		{
			return (oUtility.SUCase(oUtility.SRight(cur_item.Field_nm, 4)) == "_AMT");
		}

		private bool IsValidLine(clsGrid cur_item)
        {
			return (oUtility.IsNonEmpty(cur_item.Field_nm) && oUtility.IsNonEmpty(cur_item.Caption));		// Do NOT check for the value
        }

		public string GetFieldList()
        {
			string return_value = "";

			foreach (clsGrid det in Grid)
            {
				if (IsValidLine(det))
                {
					return_value += ", " + det.Field_nm;
                }
            }

			return return_value;
		}

		public string GetValueList(clsDatabase cur_db)
		{
			string return_value = "";
			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			foreach (clsGrid det in Grid)
			{
				if (IsValidLine(det))
                {
					if (IsMoneyField(det))
					{
						return_value += ", " + o_money.ToNumMoney(det.Value).ToString();
					}
					else if (IsNumericField(det))
					{
						return_value += ", " + oUtility.ToValue(det.Value).ToString();
					}
					else if (IsDateField(det))
					{
						return_value += ", " + o_gen.ToNumDate(det.Value).ToString();
					}
					else
					{
						return_value += ", '" + oUtility.EvalQuote(det.Value) + "'";
					}
				}
			}

			return return_value;
		}

		public string GetSearchList(clsDatabase cur_db)
        {
			string return_value = "";
			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			foreach (clsGrid det in Grid)
			{
				if (IsValidLine(det))
				{
					if (oUtility.IsNonEmpty(det.Value))
                    {
						return_value += oUtility.IIf(oUtility.IsNonEmpty(return_value), " AND ", "") + det.Field_nm;

						if (IsMoneyField(det))
						{
							return_value += " = " + o_money.ToNumMoney(det.Value).ToString();
						}
						else if (IsNumericField(det))
						{
							return_value += " = " + oUtility.ToValue(det.Value).ToString();
						}
						else if (IsDateField(det))
						{
							return_value += " = " + o_gen.ToNumDate(det.Value).ToString();
						}
						else
						{
							return_value += " = '" + oUtility.EvalQuote(det.Value) + "'";
						}
					}
				}
			}

			return return_value;
		}
		public string GetUpdateList(clsDatabase cur_db)
		{
			string return_value = "";
			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			foreach (clsGrid det in Grid)
			{
				if (IsValidLine(det))
				{
					return_value += ", " + det.Field_nm;

					if (IsMoneyField(det))
					{
						return_value += " = " + o_money.ToNumMoney(det.Value).ToString();
					}
					else if (IsNumericField(det))
					{
						return_value += " = " + oUtility.ToValue(det.Value).ToString();
					}
					else if (IsDateField(det))
					{
						return_value += " = " + o_gen.ToNumDate(det.Value).ToString();
					}
					else
					{
						return_value += " = '" + oUtility.EvalQuote(det.Value) + "'";
					}
				}
			}

			return return_value;
		}

		public bool SetValues(clsDatabase cur_db, clsRecordset cur_set)
        {
			bool return_value = false;
			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			try
			{
				foreach (clsGrid det in Grid)
                {

					if (IsMoneyField(det))
					{
						if (det.Required == false && cur_set.mField(det.Field_nm) == 0)
                        {
							det.Value = "";		// Do not show unnecessary zero
						}
						else
                        {
							det.Value = o_money.ToStrMoney(cur_set.mField(det.Field_nm));
						}
					}
					else if (IsNumericField(det))
					{
						if (det.Required == false && cur_set.mField(det.Field_nm) == 0)
						{
							det.Value = "";     // Do not show unnecessary zero
						}
						else
						{
							det.Value = cur_set.mField(det.Field_nm).ToString();
						}
					}
					else if (IsDateField(det))
					{
						det.Value = o_gen.ToStrDate(cur_set.iField(det.Field_nm));
					}
					else
					{
						det.Value = cur_set.sField(det.Field_nm);
					}
				}

				return_value = true;
			}
			catch (Exception ex)
            {
				SetPostingError(ex.Message);
            }

			return return_value;
		}

		public bool CheckValues(clsDatabase cur_db)
        {
			bool return_value = false;

			try
            {
				foreach (clsGrid det in Grid)
				{
					if (det.Required && oUtility.IsEmpty(det.Value))
					{
						SetPostingError(det.Caption + cur_db.oLanguage.oMessage.IS_REQUIRED);
						return false;
					}
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message);
			}

			return return_value;
		}

		public bool ValidateValue(clsDatabase cur_db, clsGrid cur_item)
        {
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);

			// Need to honor zero for a valid value because we do not know what users intention is.
			//
			if (oUtility.IsNonEmpty(cur_item.Value))
			{
				if (IsDateField(cur_item))
				{
					if (o_gen.ValidDate(ref cur_item.Value) == false)
					{
						SetPostingError(cur_db.oLanguage.oMessage.INVALID_DATE_ENTERED);
						cur_item.Value = "";
						return false;
					}
				}
				else if (IsMoneyField(cur_item))
				{
					cur_item.Value = o_money.ToStrMoney(o_money.ToNumMoney(cur_item.Value));
				}
				else if (IsNumericField(cur_item))
				{
					cur_item.Value = oUtility.ToValue(cur_item.Value).ToString();
				}
			}

			return true;
		}

		public string SelectFieldList(string table_alias) 
        {
			string return_value = "";

			if (oUtility.IsNonEmpty(table_alias))
            {
				if (oUtility.SInStr(table_alias, ".") <= 0)
				{
					table_alias = table_alias + ".";
				}
			}

			// This is to create the field list in SQL select statement.
			// Since Caption is user-defined, we need to make it system-understandable
			//
			foreach (var det in Grid)
            {
				if (IsDateField(det))
                {
					return_value += "," + table_alias + det.Field_nm + " [i" + det.Caption + "_dt]";
				}
				else if (IsMoneyField(det))
				{
					return_value += "," + table_alias + det.Field_nm + "[m" + det.Caption + "]";
				}
				else if (IsIntegerField(det))
				{
					return_value += "," + table_alias + det.Field_nm + "[i" + det.Caption + "]";
				}
				else if (IsNumericField(det))
				{
					return_value += "," + table_alias + det.Field_nm + "[f" + det.Caption + "]";
				}
				else 
				{
					return_value += "," + table_alias + det.Field_nm + "[s" + det.Caption + "]";
				}
			}

			return return_value;
        }
	}
}
