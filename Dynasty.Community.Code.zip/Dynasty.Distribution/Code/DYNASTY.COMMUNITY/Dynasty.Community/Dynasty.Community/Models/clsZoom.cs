﻿using Dynasty.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime;
using System.Threading.Tasks;

using Dynasty.Database;

namespace Dynasty.ASP.Models
{
    public class clsZoom
    {
        public readonly int MAX_RECORDS = 100;                                                      //  max records per zoom

        private string _caller;

        private clsDynastyUtility moUtility = new clsDynastyUtility();

        public string Caller
        {
            get { return _caller; }
        }

        public int iView = 0;                                                                       //  Current view/tab which zoom is initiated from.          Use -1 for zoom on a header field
        public int iColumn = 0;                                                                     //  Column number of cell that zoom is initiated for.       Use -1 for zoom on a header field
        public int iRow = 0;                                                                        //  Row number of cell that zoom is initiated for.
        public string sTable_nm = "";
        public bool bShowOptionBar = true;                                                          //  Should turn on/off depending on the size of recordset
        public string cboSortField_nm = "";                                                         //  UI-Field to Sort/Search the records by
        private int iTransaction_typ = 0;
        private int iJournal_typ = 0;
        private string sWhereClause = "";
        private string sKeyField_nm = "";

        public class clsCSS
        {
            public string ShowAll = "InactiveButton";
        }
        public clsCSS CSS = new clsCSS();

        private bool _multi_select = false;

        public bool MultiSelectQualified
        {
            get { return (GlobalVar.goUtility.SUCase(sKeyField_nm) == "SITEM_CD" && GlobalVar.goUtility.SInStr(GlobalVar.goUtility.SUCase(_caller), "MATRIX") <= 0); }
        }

        public bool MultiSelect
        {
            get 
            {
                if (MultiSelectQualified)
                {
                    return _multi_select;
                }
                else
                {
                    return false;
                }
            }
            set 
            {
                _multi_select = value;
            }
        }

        private bool _exit_at_ok = false;

        public bool ExitAtOK
        {
            get { return _exit_at_ok; }
            set { _exit_at_ok = value; }
        }

        private bool _show_price = false;

        public bool ShowPrice
        {
            get { return (_show_price && MultiSelect); }
            set { _show_price = value; }
        }

        public string KeyField
        {
            get { return sKeyField_nm; }
        }

        private bool _show_all = false;     // Do not set to true. Has issue with long list 
        public bool ShowAll
        {
            get { return _show_all; }
            set
            {
                _show_all = value;

                if (_show_all)
                {
                    // _zoom_initial = "";   When they entered initials, use them.
                    CSS.ShowAll = "ActiveButton";
                }
            }
        }

        public string Key_FIELD
        {
            get { return sKeyField_nm; }
        }

        private string _zoom_initial;
        public string txtInitial                                                                    //  UI-Field to select records with
        {
            get { return _zoom_initial; }
            set
            {
                _zoom_initial = moUtility.EvalQuote(value);

                if (moUtility.IsNonEmpty(_zoom_initial))
                {
                    CSS.ShowAll = "ActiveButton";
                    _show_all = false;
                }
            }
        }


        //  Up-to 5 columns that are to be displayed in the grid.  These should match the columns in clsGrid below.
        //
        public string[] Field = new string[] { "", "", "", "", "" };                                           
        public class clsGrid
        {
            public bool chkInclude_fl = false;
            public string Col_0 { get; set; } = "";                                             // Key field
            public string Col_1 { get; set; } = "";                                             // Description/Name field
            public string Col_2 { get; set; } = "";                                             // Extra fields if used.
            public string Col_3 { get; set; } = "";
            public string Col_4 { get; set; } = "";
            public string Qty { get; set; } = "";
            public string Price { get; set; } = "";

        }
        public List<clsGrid> Grid = new List<clsGrid>();

        // This is to initialize the fields necessary for zoom.  This has to be called when zoom button is clicked  before FormZoom() is called.
        //
        public bool Init(clsPage cur_page, string caller, int col_num, int row_num, int view_num, string sort_field, string initial = "", string where_clause = "")
        {
            if ((moUtility.IsEmpty(caller) && (col_num < 0 || row_num < 0)) || moUtility.IsEmpty(sort_field))
            {
                return false;
            }

            _caller = caller;
            iRow = row_num;
            iColumn = col_num;
            iView = view_num;
            cboSortField_nm = sort_field;                   // For Code(), this should be the key field of "target" table to zoom on.
            txtInitial = initial;
            sWhereClause = where_clause;
            sKeyField_nm = sort_field;                      // DO NOT USE cur_page.sKeyField_nm

            iTransaction_typ = cur_page.iTransaction_typ;
            iJournal_typ = cur_page.iJournal_typ;

            // bShowOptionBar = false;

            return true;
        }

        public bool Code(ref clsDatabase cur_db, string table_name, string description_field = "", string extra_where_clause = "")
        {
            bool return_value = false;
            string sql_str = "";
            int trx_type = 0;
            int i = 0;
            string local_where_clause = sWhereClause;

            try
            {
                Grid.Clear();

                // Init() gets the primary sWhereClause, and there may be another clause sent here
                //
                if (GlobalVar.goUtility.IsNonEmpty(extra_where_clause) && local_where_clause != extra_where_clause)
                {
                    if (GlobalVar.goUtility.IsNonEmpty(local_where_clause))
                    {
                        local_where_clause += " AND " + extra_where_clause;
                    }
                    else
                    {
                        local_where_clause = extra_where_clause;
                    }
                }

                if (moUtility.IsEmpty(description_field))
                {
                    if (moUtility.SUCase(table_name) == "TBLARCUSTOMER")
                    {
                        description_field = "sCustomer_nm";
                    }
                    else if (moUtility.SUCase(table_name) == "TBLAPVENDOR")
                    {
                        description_field = "sVendor_nm";
                    }
                    else if (moUtility.SUCase(table_name) == "TBLFAASSET")
                    {
                        description_field = "sAsset_nm";
                    }
                    else if (moUtility.SUCase(table_name) == "TBLGOEMPLOYEE")
                    {
                        description_field = "sEmployee_nm";
                    }
                    else if (moUtility.SUCase(table_name) == "TBLARSALESREP")
                    {
                        description_field = "sSalesrep_nm";
                    }
                    else if (moUtility.SUCase(table_name) == "TBLARPROSPECT")
                    {
                        description_field = "sProspect_nm";
                    }
                    else
                    {
                        description_field = "sDescription";
                    }
                }

                if (moUtility.SUCase(table_name) == "TBLSOTRANSACTION")
                {
                    trx_type = GlobalVar.goConstant.TRX_SO_TYPE;
                }
                else if (moUtility.SUCase(table_name) == "TBLPOTRANSACTION")
                {
                    trx_type = GlobalVar.goConstant.TRX_PO_TYPE;
                }
                else if (moUtility.SUCase(table_name) == "TBLARCHARGE")
                {
                    trx_type = GlobalVar.goConstant.TRX_INVOICE_TYPE;
                }
                else if (moUtility.SUCase(table_name) == "TBLAPCHARGE")
                {
                    trx_type = GlobalVar.goConstant.TRX_PURCHASE_TYPE;
                }
                else if (moUtility.SUCase(table_name) == "TBLARPAYMENT" || moUtility.SUCase(table_name) == "TBLARMCPAYMENT")
                {
                    trx_type = GlobalVar.goConstant.TRX_RECEIPT_TYPE;
                }
                else if (moUtility.SUCase(table_name) == "TBLAPPAYMENT" || moUtility.SUCase(table_name) == "TBLAPMCPAYMENT")
                {
                    trx_type = GlobalVar.goConstant.TRX_PAYMENT_TYPE;
                }

                if (trx_type == GlobalVar.goConstant.TRX_PAYMENT_TYPE)
                {
                    Field = new string[] { "iTransaction_num", "iEntry_dt", "mPaid_amt", "sDocument_num", "sVendor_cd" };                 // Must be 5 items.
                }
                else if (trx_type == GlobalVar.goConstant.TRX_RECEIPT_TYPE)
                {
                    Field = new string[] { "iTransaction_num", "iEntry_dt", "mPaid_amt", "sDocument_num", "sCustomer_cd" };               // Must be 5 items.
                }
                else if (trx_type == GlobalVar.goConstant.TRX_PO_TYPE)
                {
                    Field = new string[] { "iTransaction_num", "iEntry_dt", "sVendor_cd", "sVendor_nm", "sYourReference" };               // Must be 5 items.
                }
                else if (trx_type > 0)
                {
                    Field = new string[] { "iTransaction_num", "iEntry_dt", "mTotal_amt", "sYourReference", "sReference"};                // Must be 5 items.
                }
                else if (moUtility.SUCase(table_name) == "TBLARPROSPECT")
                {
                    Field = new string[] { sKeyField_nm, description_field, "sEmailAddress", "", "" };                    
                }
                else if (moUtility.SUCase(table_name) == "TBLFAASSET")
                {
                    Field = new string[] { sKeyField_nm, "sClass_cd", "sAsset_nm", "sOffice_cd", "sManufacturer_nm"};                    
                }
                else
                {
                    Field = new string[] { sKeyField_nm, description_field, "", "", "" };                    
                }


                sql_str = "SELECT * FROM " + table_name;

                if (moUtility.IsNonEmpty(local_where_clause))
                {
                    if (moUtility.SInStr(sql_str, " WHERE ") > 0)
                    {
                        sql_str += " AND " + local_where_clause;
                    }
                    else
                    {
                        sql_str += " WHERE " + local_where_clause;
                    }
                }

                if (SetGrid(ref cur_db, sql_str, cboSortField_nm, trx_type) == false)
                {
                    return false;
                }


                // For display, change the field name.
                // Should be at the bottom of this routine.
                //
                if (trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE)
                {
                    for ( i = 0; i < Field.GetLength(0); i++)
                    {
                        if (Field[i] == "sYourReference")
                        {
                            Field[i] = "sInvoiceNum";       // For display only
                        }
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (Zoom.Code)");
            }

            return return_value;
        }

        public bool Transaction(ref clsDatabase cur_db, int trx_type, string table_name, string extra_where_clause = "")
        {
            bool return_value = false;
            string sql_str = "";
            int i = 0;
            string local_where_clause = sWhereClause;

            try
            {
                Grid.Clear();

                // Init() gets the primary sWhereClause, and there may be another clause sent here
                //
                if (GlobalVar.goUtility.IsNonEmpty(extra_where_clause) && local_where_clause != extra_where_clause)
                {
                    if (GlobalVar.goUtility.IsNonEmpty(local_where_clause))
                    {
                        local_where_clause += " AND " + extra_where_clause;
                    }
                    else
                    {
                        local_where_clause = extra_where_clause;
                    }
                }

                if (trx_type == GlobalVar.goConstant.TRX_PAYMENT_TYPE)
                {
                    Field = new string[] { "iTransaction_num", "iEntry_dt", "mPaid_amt", "sDocument_num", "sVendor_cd" };                 // Must be 5 items.
                }
                else if (trx_type == GlobalVar.goConstant.TRX_RECEIPT_TYPE)
                {
                    Field = new string[] { "iTransaction_num", "iEntry_dt", "mPaid_amt", "sDocument_num", "sCustomer_cd" };               // Must be 5 items.
                }
                else if (trx_type == GlobalVar.goConstant.TRX_PO_TYPE || trx_type == GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE)
                {
                    Field = new string[] { "iTransaction_num", "iEntry_dt", "iRequired_dt", "sVendor_cd", "sReference" };               // Must be 5 items.
                }
                else if (trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE || trx_type == GlobalVar.goConstant.TRX_DM_TYPE)
                {
                    Field = new string[] { "iTransaction_num", "iEntry_dt", "iRequired_dt", "sVendor_cd", "sYourReference" };               // Must be 5 items.
                }
                else if (trx_type == GlobalVar.goConstant.TRX_QUOTE_TYPE || trx_type == GlobalVar.goConstant.TRX_SO_TYPE || trx_type == GlobalVar.goConstant.TRX_INVOICE_TYPE || trx_type == GlobalVar.goConstant.TRX_CM_TYPE)
                {
                    Field = new string[] { "iTransaction_num", "iEntry_dt", "iRequired_dt", "sCustomer_cd", "sReference"};               // Must be 5 items.
                }
                else
                {
                    Field = new string[] { "iTransaction_num", "iEntry_dt", "iRequired_dt", "sReference", "" };               // Must be 5 items.
                }

                sql_str = "SELECT * FROM " + table_name;

                if (moUtility.IsNonEmpty(local_where_clause))
                {
                    if (moUtility.SInStr(sql_str, " WHERE ") > 0)
                    {
                        sql_str += " AND " + local_where_clause;
                    }
                    else
                    {
                        sql_str += " WHERE " + local_where_clause;
                    }
                }

                if (SetGrid(ref cur_db, sql_str, "iTransaction_num", trx_type) == false)
                {
                    return false;
                }


                // For display, change the field name.
                // Should be at the bottom of this routine.
                //
                if (trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE)
                {
                    for (i = 0; i < Field.GetLength(0); i++)
                    {
                        if (Field[i] == "sYourReference")
                        {
                            Field[i] = "sInvoiceNum";       // For display only
                        }
                    }
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (Zoom.Code)");
            }

            return return_value;
        }

        public bool Inventory(ref clsDatabase cur_db, int item_type = 0, int kit_type = 0, string vendor_code = "")                                                                // For iventory items
        {
            bool return_value = false;
            string sql_str;

            try
            {
                Grid.Clear();

                Field = new string[] { "sItem_cd", "sLabel", "", "", "" };                // Must be 5 items.

                sql_str = "SELECT sItem_cd, sLabel FROM tblIVItem";                             // Do not use sDescription because it is too long for serivce items
                sql_str += " WHERE iStatus_typ <> " + GlobalVar.goIVConstant.CLOSED_ITEM_NUM.ToString();
                sql_str += " AND iStatus_typ <> " + GlobalVar.goIVConstant.HOLD_ITEM_NUM.ToString();

                // Kit type is supplied, select the kits only.
                //
                if (kit_type > 0)
                {
                    sql_str += " AND iKit_typ = " + kit_type.ToString();
                }
                // If item type is supplied, select the items of such type.
                //
                else if (item_type == GlobalVar.goIVConstant.REGULAR_ITEM_NUM)
                {
                    sql_str += " AND iItem_typ IN (" + moUtility.InventoryItemTypeList() + ")";
                }
                else if (item_type == GlobalVar.goIVConstant.SUMMARY_SALES_ITEM_TYPES)
                {
                    sql_str += " AND iItem_typ >= " + GlobalVar.goIVConstant.SUMMARY_SALES_ITEM_TYPES.ToString();
                }
                else if (item_type > 0)
                {
                    sql_str += " AND iItem_typ = " + item_type.ToString();
                }
                else if (iTransaction_typ > 0 && iRow >= 0 && iColumn >= 0)     // 01/08/2022  transaction line items have no reason to show the summary items
                {
                    sql_str += " AND iItem_typ < " + GlobalVar.goIVConstant.SUMMARY_SALES_ITEM_TYPES.ToString();        
                }

                if (moUtility.IsNonEmpty(vendor_code))
                {
                    sql_str += " AND sPreferredVendor_cd = '" + vendor_code + "'";
                }

                if (moUtility.IsNonEmpty(sWhereClause))
                {
                    if (moUtility.SInStr(sql_str, " WHERE ") > 0)
                    {
                        sql_str += " AND " + sWhereClause;
                    }
                    else
                    {
                        sql_str += " WHERE " + sWhereClause;
                    }
                }

                if (SetGrid(ref cur_db, sql_str, cboSortField_nm) == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (Zoom.Inventory)");
            }

            return return_value;
        }

        public bool Employee(ref clsDatabase cur_db, int user_type = 0)
        {
            bool return_value = false;
            string sql_str;

            try
            {
                Grid.Clear();

                Field = new string[] { "sEmployee_cd", "sEmployee_nm", "sDept_cd", "", "" };                // Must be 5 items.

                sql_str = "SELECT * FROM tblGOEmployee";

                if (moUtility.IsNonEmpty(sWhereClause))
                {
                    if (moUtility.SInStr(sql_str, " WHERE ") > 0)
                    {
                        sql_str += " AND " + sWhereClause;
                    }
                    else
                    {
                        sql_str += " WHERE " + sWhereClause;
                    }
                }

                if (SetGrid(ref cur_db, sql_str, cboSortField_nm) == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (Zoom.User)");
            }

            return return_value;
        }
        public bool User(ref clsDatabase cur_db, int user_type = 0)                                                                // For iventory items
        {
            bool return_value = false;
            string sql_str;

            try
            {
                Grid.Clear();

                Field = new string[] { "sUser_cd", "sUser_nm", "", "", "" };                // Must be 5 items.

                sql_str = "SELECT * FROM tblGOUser";                            

                if (user_type > 0)
                {
                    sql_str += " WHERE iUserType_id >= " + user_type.ToString();
                }

                if (moUtility.IsNonEmpty(sWhereClause))
                {
                    if (moUtility.SInStr(sql_str, " WHERE ") > 0)
                    {
                        sql_str += " AND " + sWhereClause;
                    }
                    else
                    {
                        sql_str += " WHERE " + sWhereClause;
                    }
                }
                else
                {
                    if (moUtility.SInStr(sql_str, " WHERE ") > 0)
                    {
                        sql_str += " AND sUser_cd <> 'SA'";
                    }
                    else
                    {
                        sql_str += " WHERE sUser_cd <> 'SA'";
                    }
                }

                if (SetGrid(ref cur_db, sql_str, cboSortField_nm) == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (Zoom.User)");
            }

            return return_value;
        }

        public bool Account(ref clsDatabase cur_db, int acct_type = 0)                                                             // For G/L accounts
        {
            bool return_value = false;
            string sql_str;
            string sort_field = "";

            try
            {
                Grid.Clear();

                Field = new string[] { "sAccount_cd", "sDescription", "sAccountGroup", "", "" };                                   // Must be 5 items

                // DO NOT use alias.  The calling routines use the table name for where-clause
                //
                sql_str = "SELECT tblGLAccount.sAccount_cd, tblGLAccount.sDescription, tblGLAccountGroup.sDescription AS sAccountGroup";
                sql_str += " FROM tblGLAccount LEFT JOIN tblGLAccountGroup ON (tblGLAccount.iGroup_typ = tblGLAccountGroup.iAccount_typ)";

                if (cur_db.bUseFullAccountCode_fl == false && iJournal_typ != GlobalVar.goNPConstant.JOURNAL_BUDGETARY_TYPE_NUM)
                {
                    moUtility.SReplace(sql_str, "tblGLAccount", "tblGLAccountNatural");
                }

                // If account type is supplied, find the accounts of such type.
                //
                if (acct_type < 0)
                {
                    // select all.  Inquiry zoom on summary accounts
                }
                else if (acct_type == 0 || acct_type == GlobalVar.goGLConstant.ACTUAL_TYPE_NUM)
                {
                    sql_str += " WHERE tblGLAccount.iSummary_typ = " + GlobalVar.goGLConstant.ACTUAL_TYPE_NUM.ToString();

                    if (iJournal_typ == GlobalVar.goNPConstant.JOURNAL_BUDGETARY_TYPE_NUM)
                    {
                        sql_str += " AND tblGLAccount.iGroup_typ >= " + GlobalVar.goGLConstant.BUDGETARY_GROUP_NUM.ToString();
                    }
                    else
                    {
                        sql_str += " AND tblGLAccount.iGroup_typ < " + GlobalVar.goGLConstant.BUDGETARY_GROUP_NUM.ToString();
                    }
                }
                else
                {
                    sql_str += " WHERE tblGLAccount.iSummary_typ = " + GlobalVar.goGLConstant.ACTUAL_TYPE_NUM.ToString();

                    if ((acct_type % 1000) == 0)
                    {
                        sql_str += " AND tblGLAccount.iGroup_typ BETWEEN " + acct_type.ToString() + " AND " + (acct_type + 999).ToString();           // i.e., acct_type = 2000, then, select all accounts whose account type is between 2000 and 2999
                    }
                    else if ((acct_type % 100) == 0)
                    {
                        sql_str += " AND tblGLAccount.iGroup_typ BETWEEN " + acct_type.ToString() + " AND " + (acct_type + 99).ToString();           // i.e., acct_type = 2700, then, select all accounts whose account type is between 2700 and 2799
                    }
                    else if ((acct_type % 10) == 0)
                    {
                        sql_str += " AND tblGLAccount.iGroup_typ BETWEEN " + acct_type.ToString() + " AND " + (acct_type + 9).ToString();           // i.e., acct_type = 2720, then, select all accounts whose account type is between 2720 and 2729
                    }
                    else
                    {
                        sql_str += " AND tblGLAccount.iGroup_typ = " + acct_type.ToString();
                    }
                }

                if (moUtility.IsNonEmpty(sWhereClause))
                {
                    if (moUtility.SInStr(sql_str, " WHERE ") > 0)
                    {
                        sql_str += " AND " + sWhereClause;
                    }
                    else
                    {
                        sql_str += " WHERE " + sWhereClause;
                    }
                }

                if (cboSortField_nm == "sDescription")
                {
                    sort_field = "tblGLAccount.sDescription";
                }
                else if (cboSortField_nm == "sAccountGroup")
                {
                    sort_field = "tblGLAccount.iGroup_typ";
                }
                else 
                {
                    sort_field = "tblGLAccount.sAccount_cd";
                }

                if (SetGrid(ref cur_db, sql_str, sort_field) == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (Zoom.Account)");
            }

            return return_value;
        }

        public bool Customer(ref clsDatabase cur_db, int status_type = 0)                                                             // For A/R customers
        {
            bool return_value = false;
            string sql_str;

            try
            {
                Grid.Clear();

                Field = new string[] { "sCustomer_cd", "sCustomer_nm", "sCity", "sAttention_nm", "sPhone1" };                                // Must be 5 items

                sql_str = "SELECT sCustomer_cd, sCustomer_nm, sCity, sAttention_nm, sPhone1";
                sql_str += " FROM tblARCustomer";

                if (status_type > 0)
                {
                    sql_str += " WHERE iStatus_typ = " + status_type.ToString();
                }
                else
                {
                    sql_str += " WHERE iStatus_typ <> " + GlobalVar.goARConstant.CLOSED_CUSTOMER_NUM.ToString();
                }

                if (moUtility.IsNonEmpty(sWhereClause))
                {
                    if (moUtility.SInStr(sql_str, " WHERE ") > 0)
                    {
                        sql_str += " AND " + sWhereClause;
                    }
                    else
                    {
                        sql_str += " WHERE " + sWhereClause;
                    }
                }

                if (GlobalVar.goUtility.IsSalesStaff(cur_db))
                {
                    if (moUtility.SInStr(sql_str, " WHERE ") > 0)
                    {
                        sql_str += " AND ";
                    }
                    else
                    {
                        sql_str += " WHERE ";
                    }
                    sql_str += " sCustomer_cd IN (SELECT sCustomer_cd FROM tblARCustomer WHERE sSalesrep_cd = '" + cur_db.sUser_cd + "')";
                }

                if (SetGrid(ref cur_db, sql_str, cboSortField_nm) == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (Zoom.Customer)");
            }

            return return_value;
        }
        public bool Vendor(ref clsDatabase cur_db, int status_type = 0)                                                               // For A/P vendors
        {
            bool return_value = false;
            string sql_str;

            try
            {
                Grid.Clear();

                Field = new string[] { "sVendor_cd", "sVendor_nm", "sCity", "sAttention_nm", "sPhone1" };                                     // Must be 5 items

                sql_str = "SELECT sVendor_cd, sVendor_nm, sCity, sAttention_nm, sPhone1";
                sql_str += " FROM tblAPVendor";
                if (status_type > 0)
                {
                    sql_str += " WHERE iStatus_typ = " + status_type.ToString();
                }
                else
                {
                    sql_str += " WHERE iStatus_typ <> " + GlobalVar.goAPConstant.CLOSED_VENDOR_NUM.ToString();
                }

                if (moUtility.IsNonEmpty(sWhereClause))
                {
                    if (moUtility.SInStr(sql_str, " WHERE ") > 0)
                    {
                        sql_str += " AND " + sWhereClause;
                    }
                    else
                    {
                        sql_str += " WHERE " + sWhereClause;
                    }
                }

                if (SetGrid(ref cur_db, sql_str, cboSortField_nm) == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (Zoom.Vendor)");
            }

            return return_value;
        }

        public bool Loan(ref clsDatabase cur_db)
        {
            bool return_value = false;
            string sql_str;

            try
            {
                Grid.Clear();

                Field = new string[] { "sLoan_num", "sEmployee_cd", "sDescription", "iHoldLoan_fl", "sComment" };                // Must be 5 items.

                sql_str = "SELECT * FROM tblPREmployeeLoan";

                if (moUtility.IsNonEmpty(sWhereClause))
                {
                    if (moUtility.SInStr(sql_str, " WHERE ") > 0)
                    {
                        sql_str += " AND " + sWhereClause;
                    }
                    else
                    {
                        sql_str += " WHERE " + sWhereClause;
                    }
                }

                if (SetGrid(ref cur_db, sql_str, cboSortField_nm) == false)
                {
                    return false;
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (Zoom.User)");
            }

            return return_value;
        }
        private bool SetGrid(ref clsDatabase cur_db, string sql_str, string sort_field, int trx_type = 0)
        {
            bool return_value = false;
            int row_num;
            clsRecordset cur_set = new clsRecordset(ref cur_db);

            try
            {
                if (moUtility.IsEmpty(sort_field))
                {
                    sort_field = Field[0];
                }

                // If initial is supplied, find the items that start with the initial.
                //
                if (moUtility.IsNonEmpty(txtInitial))       // Do not include (ShowAll == false)
                {
                    sql_str += GlobalVar.goUtility.IIf((GlobalVar.goUtility.SInStr(sql_str, " WHERE ") > 0), " AND ", " WHERE ");

                    if (moUtility.IsIntegerField(sort_field))
                    {
                        txtInitial = moUtility.ToInteger(txtInitial).ToString();            // This will display back on the UI page.
                        sql_str += sort_field + " = " + txtInitial;
                    }
                    else if (moUtility.IsNumericField(sort_field))
                    {
                        txtInitial = moUtility.ToValue(txtInitial).ToString();            
                        sql_str += sort_field + " = " + txtInitial;
                    }
                    else
                    {
                        txtInitial = moUtility.EvalQuote(txtInitial);
                        sql_str += sort_field + " LIKE '" + txtInitial + "%'";
                    }
                }

                if ((trx_type == GlobalVar.goConstant.TRX_SO_TYPE) || (trx_type == GlobalVar.goConstant.TRX_PO_TYPE))
                {
                    sql_str += GlobalVar.goUtility.IIf((GlobalVar.goUtility.SInStr(sql_str, " WHERE ") > 0), " AND ", " WHERE ");
                    sql_str += " (iStatus_typ <> " + GlobalVar.goConstant.HOLD_TRX_NUM.ToString() + " AND iStatus_typ <> " + GlobalVar.goConstant.VOID_TRX_NUM.ToString() + ")";
                    sql_str += " AND iShippingStatus_typ <> " + GlobalVar.goConstant.HOLD_TRX_NUM.ToString();
                    sql_str += " AND iCompleted_dt = 0";
                }

                if (moUtility.SUCase(sort_field) ==  "ITRANSACTION_NUM")
                {
                    sql_str += " ORDER BY iTransaction_num DESC";
                }
                else
                {
                    sql_str += " ORDER BY " + sort_field;
                }

                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    return false;
                }
                else if ((ShowAll == false && moUtility.IsEmpty(txtInitial)) && (cur_set.RecordCount() > MAX_RECORDS))
                {
                    modDialogUtility.DisplayBox(ref cur_db, cur_set.RecordCount() + " " + cur_db.oLanguage.oMessage.RECORDS_ARE_FOUND + " " + cur_db.oLanguage.oMessage.ENTER_INITIALS_CLICK_BUTTON_AGAIN);
                    bShowOptionBar = true;
                    return false;
                }

                for (row_num = 0; row_num < cur_set.RecordCount(); row_num++)
                {
                    Grid.Add(new clsGrid { 
                        Col_0 = modCommonUtility.GetFieldValue(cur_db, cur_set, Field[0], 0)
                        , Col_1 = modCommonUtility.GetFieldValue(cur_db, cur_set, Field[1], 0)
                        , Col_2 = modCommonUtility.GetFieldValue(cur_db, cur_set, Field[2], 0)
                        , Col_3 = modCommonUtility.GetFieldValue(cur_db, cur_set, Field[3], 0)
                        , Col_4 = modCommonUtility.GetFieldValue(cur_db, cur_set, Field[4], 0) 
                    });
                    cur_set.MoveNext();
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (Zoom.SetGrid)");
            }

            return return_value;
        }

    }
}
