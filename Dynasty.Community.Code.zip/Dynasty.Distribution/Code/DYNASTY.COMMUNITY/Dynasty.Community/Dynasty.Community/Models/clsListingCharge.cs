﻿using Dynasty.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dynasty.ASP.Models
{

    public class clsListingCharge
    {
        clsDynastyUtility oUtility = new clsDynastyUtility();

        // Total all amunts
        //
        public decimal mTotal_amt = 0;
        public decimal mPaid_amt = 0;
        public decimal mDue_amt = 0;
        public decimal mShipped_amt = 0;

        public bool Show(clsDatabase cur_db, clsPage cur_page, string where_clause = "", string order_by_clause = "")
        {
            string sql_str = "";
            string trx_str = "";
            decimal shipped_amt = 0;
            string department_cd = "";
            string order_num = "iOrder_num";
            string total_amount = "mTotal_amt";

            clsRecordset cur_set = new clsRecordset(ref cur_db);
            clsGeneral o_gen = new clsGeneral(ref cur_db);
            clsMoney o_money = new clsMoney(ref cur_db);
            clsStatus o_status = new clsStatus();

            // Clear totals
            //
            mTotal_amt = 0;
            mPaid_amt = 0;
            mDue_amt = 0;
            mShipped_amt = 0;

            Grid.Clear();

            order_by_clause= oUtility.STrim(order_by_clause);

            // Standard listing shows the key and description
            //
            sql_str = "SELECT * FROM " + cur_page.sTable_nm;

            if (oUtility.IsNonEmpty(where_clause))
            {
                if (oUtility.IsNonEmpty(cur_page.sRestrictionClause))
                {
                    sql_str += " WHERE " + cur_page.sRestrictionClause;
                    sql_str += " AND " + where_clause;
                }
                else
                {
                    sql_str += " WHERE " + where_clause;
                }
            }
            else if (oUtility.IsNonEmpty(cur_page.sRestrictionClause))
            {
                sql_str += " WHERE " + cur_page.sRestrictionClause;
            }

            if (oUtility.IsNonEmpty(order_by_clause))
            {
                sql_str += " ORDER BY " + order_by_clause;
            }
            else
            {
                sql_str += " ORDER BY " + cur_page.sKeyField_nm;
            }

            if (cur_set.CreateSnapshot(sql_str) == false)
            {
                return false;
            }
            else if (cur_set.EOF())
            {
                return true;
            }

            while (cur_set.EOF() == false)
            {
                mPaid_amt += cur_set.mField("mPaid_amt");
                mDue_amt += cur_set.mField("mDue_amt");

                if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_PO_TYPE)
                {
                    mTotal_amt += cur_set.mField("mTotalInPrimary_amt");
                    mShipped_amt += cur_set.mField("mReceived_amt");
                    shipped_amt = cur_set.mField("mReceived_amt");
                    order_num = "iQuote_num";
                    total_amount = "mTotalInPrimary_amt";
                }
                else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_PO_QUOTE_TYPE)
                {
                    mTotal_amt += cur_set.mField("mTotalInPrimary_amt");
                    order_num = "iRFQ_num";
                    total_amount = "mTotalInPrimary_amt";
                }
                else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_SO_TYPE)
                {
                    mTotal_amt += cur_set.mField("mTotalInPrimary_amt");
                    mShipped_amt += cur_set.mField("mShipped_amt");
                    shipped_amt = cur_set.mField("mShipped_amt");
                    total_amount = "mTotalInPrimary_amt";
                }
                else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_QUOTE_TYPE)
                {
                    mTotal_amt += cur_set.mField("mTotalInPrimary_amt");
                    total_amount = "mTotalInPrimary_amt";
                }
                else
                {
                    mTotal_amt += cur_set.mField("mTotal_amt");
                }

                if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE)
                {
                    department_cd = cur_set.sField("sDepartment_cd");
                    order_num = "iQuote_num";
                }
                if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_RFQ_TYPE)
                {
                    department_cd = cur_set.sField("sDepartment_cd");
                }

                Grid.Add(new clsGrid { Transaction_num = cur_set.sField(cur_page.sKeyField_nm)
		                , Order_num = oUtility.IIf(cur_set.iField(order_num) > 0, cur_set.iField(order_num).ToString(), "")
		                , Entry_dt = o_gen.ToStrDate(cur_set.iField("iEntry_dt"))
                        , Apply_dt = o_gen.ToStrDate(cur_set.iField("iApply_dt"))
                        , Shipped_dt = o_gen.ToStrDate(cur_set.iField(oUtility.IIf(IsPayable(cur_page.iTransaction_typ), "iReceived_dt", "iShipped_dt").ToString()))
                        , Required_dt = o_gen.ToStrDate(cur_set.iField("iRequired_dt"))
                        , Due_dt = o_gen.ToStrDate(cur_set.iField("iDue_dt"))
                        , Invoice_dt = oUtility.IIf(IsPayable(cur_page.iTransaction_typ), o_gen.ToStrDate(cur_set.iField("iInvoice_dt")),"")
                        , Completed_dt = o_gen.ToStrDate(cur_set.iField("iCompleted_dt"))
                        , Status_typ = GetStatus(cur_page, cur_set.iField("iStatus_typ"))
		                , Total_amt = o_money.ToStrMoney(cur_set.mField(total_amount), -1, "", true)
                        , Paid_amt = o_money.ToStrMoney(cur_set.mField("mPaid_amt"), -1, "", true)
                        , Due_amt = o_money.ToStrMoney(cur_set.mField("mDue_amt"), -1, "", true)
                        , Shipped_amt = o_money.ToStrMoney(shipped_amt, -1, "", true)
                        , YourReference = cur_set.sField("sYourReference")
		                , Reference = cur_set.sField("sReference")
                        , Job_cd = cur_set.sField("sJob_cd")
		                , Location_cd = cur_set.sField("sLocation_cd")
                        , Tax_cd = cur_set.sField("sTax_cd")
		                , Via_cd = cur_set.sField("sVia_cd")
		                , Price_cd = cur_set.sField("sPrice_cd")
		                , Agent_cd = cur_set.sField(oUtility.IIf(IsPayable(cur_page.iTransaction_typ), "sAgent_cd", "sSalesrep_cd").ToString())
                        , Terms_cd = cur_set.sField("sTerms_cd")
		                , Fob_cd = cur_set.sField("sFob_cd")
		                , Department_cd = department_cd
                        , Entity_cd = cur_set.sField(oUtility.IIf(IsPayable(cur_page.iTransaction_typ), "sVendor_cd", "sCustomer_cd").ToString())
		                , Entity_nm = cur_set.sField(oUtility.IIf(IsPayable(cur_page.iTransaction_typ), "sVendor_nm", "sCustomer_nm").ToString())
		                , Comment = cur_set.sField("sComment")
                });

                cur_set.MoveNext();
            }


            if (mTotal_amt > 0 || mPaid_amt > 0 || mDue_amt > 0 || mShipped_amt > 0)
            {
                Grid.Add(new clsGrid { Transaction_num = cur_db.oLanguage.oString.STR_TOTALS
                            , Order_num = ""
		                    , Entry_dt = ""
                            , Apply_dt = ""
                            , Shipped_dt = ""
                            , Required_dt = ""
                            , Due_dt = ""
                            , Invoice_dt = ""
                            , Completed_dt = ""
                            , Status_typ = ""
		                    , Total_amt = o_money.ToStrMoney(mTotal_amt, -1, "", true)
                            , Paid_amt = o_money.ToStrMoney(mPaid_amt, -1, "", true)
                            , Due_amt = o_money.ToStrMoney(mDue_amt, -1, "", true)
                            , Shipped_amt = o_money.ToStrMoney(mShipped_amt, -1, "", true)
                            , YourReference = ""
		                    , Reference = ""
                            , Job_cd = ""
		                    , Location_cd = ""
                            , Tax_cd = ""
		                    , Via_cd = ""
                            , Price_cd = ""
                            , Agent_cd = ""
                            , Terms_cd = ""
                            , Fob_cd = ""
                            , Department_cd = ""
                            , Entity_cd = ""
                            , Entity_nm = ""
                            , Comment = ""
                });
            }

            return true;
        }

        private string GetStatus(clsPage cur_page, int status_type)
        {
            clsStatus o_status = new clsStatus();
            string status_text = "";

            // Set to default transaction status.
            //
            if (oUtility.SInStr(oUtility.SUCase(cur_page.sTable_nm), "UNPOSTED") > 0)
            {
                status_text = o_status.TransactionUnpostedStatusTypeText(status_type);
            }
            else
            {
                status_text = o_status.TransactionPostedStatusTypeText(status_type);
            }

            if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_QUOTE_TYPE)
            {
                status_text = o_status.QuoteStatusTypeText(status_type);
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_SO_TYPE)
            {
                status_text = o_status.OrderStatusTypeText(status_type);
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_PO_TYPE)
            {
                status_text = o_status.PurchaseOrderStatusTypeText(status_type);
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE)
            {
                status_text = o_status.PurchaseRequisitionStatusTypeText(status_type);
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_PO_QUOTE_TYPE)
            {
                status_text = o_status.PurchaseQuoteStatusTypeText(status_type);
            }
            else if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_RFQ_TYPE)
            {
                status_text = o_status.PurchaseRFQStatusTypeText(status_type);
            }

            return status_text;
        }

        private bool IsPayable(int trx_type)
        {
            if (trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE || trx_type == GlobalVar.goConstant.TRX_DM_TYPE
            || trx_type == GlobalVar.goConstant.TRX_PO_TYPE || trx_type == GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE)
            {
                return true;
            }

            return false;
        }

        public class clsGrid
        {
            public bool chkInclude_fl { get; set; } = false;
            public string Transaction_num { get; set; } = "";
            public string Order_num { get; set; } = "";
            public string Entry_dt { get; set; } = "";
            public string Apply_dt { get; set; } = "";
            public string Shipped_dt { get; set; } = "";
            public string Required_dt { get; set; } = "";
            public string Due_dt { get; set; } = "";
            public string Invoice_dt { get; set; } = "";
            public string Completed_dt { get; set; } = "";
            public string Status_typ { get; set; } = "";
            public string Total_amt { get; set; } = "";
            public string Paid_amt { get; set; } = "";
            public string Due_amt { get; set; } = "";
            public string Shipped_amt { get; set; } = "";
            public string Job_cd { get; set; } = "";
            public string YourReference { get; set; } = "";
            public string Reference { get; set; } = "";
            public string Location_cd { get; set; } = "";
            public string Tax_cd { get; set; } = "";
            public string Via_cd { get; set; } = "";
            public string Price_cd { get; set; } = "";
            public string Agent_cd { get; set; } = "";
            public string Terms_cd { get; set; } = "";
            public string Fob_cd { get; set; } = "";
            public string Department_cd { get; set; } = "";
            public string Entity_cd { get; set; } = "";
            public string Entity_nm { get; set; } = "";
            public string Comment { get; set; } = "";
        }
        public List<clsGrid> Grid = new List<clsGrid>();

    }
}
