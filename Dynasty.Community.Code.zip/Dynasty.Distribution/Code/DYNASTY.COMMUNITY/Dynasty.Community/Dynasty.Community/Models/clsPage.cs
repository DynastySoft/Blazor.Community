﻿using Microsoft.AspNetCore.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Dynasty.Database;

namespace Dynasty.ASP.Models
{
    public class clsPage
    {
        // Listing of items that are to be initilaied manually for each page.
        //
        public string Title { get; set; }                          // ....... Keeps the page title.
        public int iScreen_typ = 0;                                // ....... Keeps the screen type.
        public int iTransaction_typ = 0;                           // ....... Keeps the transaction type if this page is a transaction screen.
        public int iJournal_typ = 0;                               // ....... Currently, used in journal, order, invoice and memo entry pages. 
        public string sModule_id = "";                             // ....... Keeps the module id such as AR, AP & IV.
        public string sTable_nm = "";                              // ....... Keeps the main table name.
        public string sDetailTable_nm = "";                        // ....... Keeps the main detail table name if exists.
        public string sKeyField_nm = "";                           // ....... Keeps the key field name.
        public string sInitialKey_id = "";                         // ....... Used only when another page calls this page with key-id. 
        public string sPreviousKey_id = "";                        // ....... Keeps the key-id of previous record.
        public string sRestrictionClause = "";                     // ....... Filtering clause used when a record is selected from table sTable_nm.
        public string sSearchClause = "";                          // ....... Keeps the search criteria used when Search button is clicked.
        public string sKeyDescription = "";                        // ....... Keeps the description of key field name.  Default is sDescription
        public string sReference = "";                             // ....... Can be any field for Entity-search

        // Listing of items that change according to event-handlers.
        //
        public bool bInPrinting_fl = false;                        // ....... True if page-printing is in progress.  Initiated by print button if exists.
        public bool bErrorFound_fl = false;                        // ....... True if error has occurred in the current post back.
        public bool bLoading_fl = true;                            // ....... Initialized to true for initial page loading
        public bool bInProgress_fl = false;                        // ....... something is in progress
        public bool bInDialog_fl = false;                          // ....... used in FormDialog()
        public int iCurrentView = 0;                               // ....... Current view/tab shown.
        public int iPreviousView = 0;                              // ....... Previous view/tab before .

        private bool _hide_toolbar;
        public bool HideToolBar
        {
            get { return _hide_toolbar; }
            set { _hide_toolbar = value; }
        }

        // Listing of items related to the status of record on the page.
        //
        public bool bNew_fl = true;                                // ....... True when this is a new record to create.
        public bool bModified_fl = false;                          // ....... To track any specific field data changes. This will work when FormChange() works correctly on each razor page.
        public bool bReadOnly_fl = false;                          // ....... True if the current record is read-only.
        public bool bReserved_fl = false;                          // ....... True if the current record is reserved.  can be modified, but cannot be deleted.
        public bool bSuspended_fl = false;                         // ....... True if the current record is suspended.  Read only

        public void Clear()
        {
            bNew_fl = true;                               
            bModified_fl = false;                          
            bReadOnly_fl = false;                          
            bReserved_fl = false;
            bSuspended_fl = false;

            bInPrinting_fl = false;
            bInProgress_fl = false;
            bInDialog_fl = false;
            bErrorFound_fl = false;

            Original.iStatus_typ = 0;
            Original.sTax_cd = "";
            Original.sAgent_cd = "";
            Original.mTotal_amt = 0;
            Original.bFromPackingClip_fl = false;

            Original.sCreator_id = "";
            Original.sLastUpdate_id = "";
            Original.dtLastUpdate_dt = Convert.ToDateTime("01/01/1000");
        }

        public class clsMessage
        {
            public bool Found = false;
            public string Text = "";
            public string Style = "";

            public void Clear()
            {
                Show("", false);
            }

            public void Show(string msg, bool error_fl)
            {
                Text = msg;
                Found = GlobalVar.goUtility.IsNonEmpty(Text);

                if (GlobalVar.goUtility.IsNonEmpty(Text))
                {
                    if (error_fl)
                    {
                        Style = ";color:red; border:2px red solid";
                    }
                    else
                    {
                        Style = ";color:royalblue; border:2px green solid";
                    }
                }
                else
                {
                    Style = "";
                }
            }
        }
        public clsMessage Message = new clsMessage();

        public class clsOriginal                                    // ....... Original values that are used in validation at a later time. 
        {
            public int iStatus_typ = 0;
            public string sTax_cd = "";
            public string sAgent_cd = "";
            public decimal mTotal_amt = 0;
            public bool bFromPackingClip_fl = false;
            public int iBalance_typ = 0;

            public string sCreator_id = "";                         // DO NOT include this in PreserveOriginal() below because not many tables have this field.
            public string sLastUpdate_id = "";
            public DateTime dtLastUpdate_dt;
        }

        public clsOriginal Original = new clsOriginal();

        public void PreserveTimestamp(clsRecordset cur_set)
        {
            if (cur_set.EOF() ==  false)
            {
                Original.sLastUpdate_id = cur_set.sField("sLastUpdate_id");
                Original.dtLastUpdate_dt  = cur_set.dtField("dtLastUpdate_dt");
            }
            else
            {
                Original.sLastUpdate_id = "";
                Original.dtLastUpdate_dt = Convert.ToDateTime("01/01/1000");
            }
        }

        public void PreserveOriginal(clsRecordset cur_set)
        {
            Original.iStatus_typ = 0;
            Original.sTax_cd = "";
            Original.sAgent_cd = "";
            Original.mTotal_amt = 0;
            Original.bFromPackingClip_fl = false;

            if (cur_set.EOF())
            {
                return;
            }

            if (iTransaction_typ > 0)
            {
                Original.iStatus_typ = cur_set.iField("iStatus_typ");

                // Only A/R and A/P charge types need these originals.
                //
                if (iTransaction_typ == GlobalVar.goConstant.TRX_INVOICE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_CM_TYPE
                || iTransaction_typ == GlobalVar.goConstant.TRX_SO_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_QUOTE_TYPE
                || iTransaction_typ == GlobalVar.goConstant.TRX_PURCHASE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_DM_TYPE
                || iTransaction_typ == GlobalVar.goConstant.TRX_PO_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE)
                {
                    Original.sTax_cd = cur_set.sField("sTax_cd");
                    Original.mTotal_amt = cur_set.mField("mTotal_amt");

                    // AR & AP Charge types carry iFromPackingSlip_fl
                    //
                    if (iTransaction_typ == GlobalVar.goConstant.TRX_INVOICE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_CM_TYPE
                    || iTransaction_typ == GlobalVar.goConstant.TRX_PURCHASE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_DM_TYPE)
                    {
                        Original.bFromPackingClip_fl = (cur_set.iField("iFromPackingSlip_fl") == GlobalVar.goConstant.FLAG_ON);
                    }

                    if (iTransaction_typ == GlobalVar.goConstant.TRX_INVOICE_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_CM_TYPE
                    || iTransaction_typ == GlobalVar.goConstant.TRX_SO_TYPE || iTransaction_typ == GlobalVar.goConstant.TRX_QUOTE_TYPE)
                    {
                        Original.sAgent_cd = cur_set.sField("sSalesrep_cd");            // A/R
                    }
                    else
                    {
                        Original.sAgent_cd = cur_set.sField("sAgent_cd");               // A/P
                    }
                }
            }
            else if (GlobalVar.goUtility.SUCase(sTable_nm) == GlobalVar.goUtility.SUCase("tblARCustomer") || GlobalVar.goUtility.SUCase(sTable_nm) == GlobalVar.goUtility.SUCase("tblAPVendor"))
            {
                Original.iStatus_typ = cur_set.iField("iStatus_typ");
                Original.iBalance_typ = cur_set.iField("iBalance_typ");
            }

        }

        public bool CheckForConcurrency(clsRecordset cur_set)
        {
            if (GlobalVar.goUtility.IsEmpty(Original.sLastUpdate_id))
            {
                return true;
            }
            else if (cur_set.EOF() == false)
            {
                // During printing, saving takes a place, and it causes the discrepancy bewteen Original.dtLastUpdate_dt and cur_set.dtField("dtLastUpdate_dt")
                //
                if (bInPrinting_fl && (Original.sLastUpdate_id == cur_set.sField("sLastUpdate_id")))
                {
                    return true;
                }
                else if (Original.sLastUpdate_id != cur_set.sField("sLastUpdate_id") 
                || GlobalVar.goUtility.SFormat(Original.dtLastUpdate_dt, clsDatabase.sSQLDateFormat) != GlobalVar.goUtility.SFormat(cur_set.dtField("dtLastUpdate_dt"), clsDatabase.sSQLDateFormat))
                {
                    return false;
                }
            }

            return true;
        }
    }
}
