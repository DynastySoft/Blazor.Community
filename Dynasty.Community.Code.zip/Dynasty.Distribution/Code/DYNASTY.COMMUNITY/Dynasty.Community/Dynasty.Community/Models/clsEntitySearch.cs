﻿using Dynasty.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dynasty.ASP.Models
{
    public class clsEntitySearch
    {
        public class clsGrid
        {
            public int Row_num { get; set; } = 0;
            public string Code { get; set; } = "";
            public string Description { get; set; } = "";
            public string Reference { get; set; } = "";
            public string ExtraCol_1 { get; set; } = "";    // any extra column such as amounts
            public string ExtraCol_2 { get; set; } = "";
            public string ExtraCol_3 { get; set; } = "";
            public string ExtraCol_4 { get; set; } = "";
            public string ExtraCol_5 { get; set; } = "";
            public string ExtraCol_6 { get; set; } = "";
            public string ExtraCol_7 { get; set; } = "";
            public string ExtraCol_8 { get; set; } = "";
            public string ExtraCol_9 { get; set; } = "";
            public string ExtraCol_10 { get; set; } = "";

        }

        public List<clsGrid> Grid = new List<clsGrid>();

        public string[,] CustomFields = null;                   // User defined fields

        clsDynastyUtility oUtility = new clsDynastyUtility();

        private string sTable_nm = "";

        clsRecordset AssetType_set;
        clsRecordset CustomerReason_set;

        public bool Show(clsDatabase cur_db, clsPage page, string where_clause
            , string extra_field_1 = "", string extra_field_2 = "", string extra_field_3 = "", string extra_field_4 = "", string extra_field_5 = ""
            , string extra_field_6 = "", string extra_field_7 = "", string extra_field_8 = "", string extra_field_9 = "", string extra_field_10 = ""
            , string[] custom_fields = null)
        {
            string sql_str;
            string extra_field_value_1 = "";
            string extra_field_value_2 = "";
            string extra_field_value_3 = "";
            string extra_field_value_4 = "";
            string extra_field_value_5 = "";
            string extra_field_value_6 = "";
            string extra_field_value_7 = "";
            string extra_field_value_8 = "";
            string extra_field_value_9 = "";
            string extra_field_value_10 = "";

            int row_num = 0;
            int i = 0;

            clsRecordset cur_set = new clsRecordset(ref cur_db);

            Grid.Clear();

            sTable_nm = page.sTable_nm;

            if (oUtility.IsEmpty(page.sKeyDescription))
            {
                page.sKeyDescription = "sDescription";
            }

            sql_str = "SELECT * FROM " + sTable_nm;
            if (oUtility.IsNonEmpty(where_clause))
            {
                sql_str += " WHERE " + where_clause;
            }
            if (oUtility.SInStr(oUtility.SUCase(where_clause), "ORDER BY") == 0)
            {
                sql_str += " ORDER BY " + page.sKeyField_nm;
            }

            if (cur_set.CreateSnapshot(sql_str) == false)
            {
                return false;
            }
            else if (cur_set.EOF())
            {
                modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NO_RECORDS_FOUND);
                return false;
            }

            if (custom_fields != null)
            {
                oUtility.ResizeDim(ref CustomFields, custom_fields.GetUpperBound(0), cur_set.RecordCount() - 1);
            }

            if (oUtility.SUCase(sTable_nm) == "TBLFAASSET")
            {
                AssetType_set = new clsRecordset(ref cur_db);

                if (AssetType_set.CreateSnapshot("SELECT * FROM tblFAAssetType ORDER BY iAsset_typ") == false)
                {
                    return false;
                }
            }
            else if (oUtility.SUCase(sTable_nm) == oUtility.SUCase("tblARCustomerSupport"))
            {
                CustomerReason_set = new clsRecordset(ref cur_db);

                if (CustomerReason_set.CreateSnapshot("SELECT * FROM tblARCustomerCallReason ORDER BY iReason_id") == false)
                {
                    return false;
                }
            }

            row_num = 0;

            while (cur_set.EOF() == false)
            {
                extra_field_value_1 = GetFieldValue(ref cur_db, cur_set, extra_field_1);
                extra_field_value_2 = GetFieldValue(ref cur_db, cur_set, extra_field_2);
                extra_field_value_3 = GetFieldValue(ref cur_db, cur_set, extra_field_3);
                extra_field_value_4 = GetFieldValue(ref cur_db, cur_set, extra_field_4);
                extra_field_value_5 = GetFieldValue(ref cur_db, cur_set, extra_field_5);
                extra_field_value_6 = GetFieldValue(ref cur_db, cur_set, extra_field_6);
                extra_field_value_7 = GetFieldValue(ref cur_db, cur_set, extra_field_7);
                extra_field_value_8 = GetFieldValue(ref cur_db, cur_set, extra_field_8);
                extra_field_value_9 = GetFieldValue(ref cur_db, cur_set, extra_field_9);
                extra_field_value_10 = GetFieldValue(ref cur_db, cur_set, extra_field_10);

                Grid.Add(new clsGrid {
                    Row_num = row_num
                    , Code = cur_set.sField(page.sKeyField_nm)
                    , Description = cur_set.sField(page.sKeyDescription)
                    , Reference = cur_set.sField(page.sReference)
                    , ExtraCol_1 = extra_field_value_1
                    , ExtraCol_2 = extra_field_value_2
                    , ExtraCol_3 = extra_field_value_3
                    , ExtraCol_4 = extra_field_value_4
                    , ExtraCol_5 = extra_field_value_5
                    , ExtraCol_6 = extra_field_value_6
                    , ExtraCol_7 = extra_field_value_7
                    , ExtraCol_8 = extra_field_value_8
                    , ExtraCol_9 = extra_field_value_9
                    , ExtraCol_10 = extra_field_value_10
                }); ;

                // Set the custom fields
                //
                if (custom_fields != null)
                {
                    for (i = 0; i <= custom_fields.GetUpperBound(0); i++)
                    {
                        CustomFields[i, row_num] = GetFieldValue(ref cur_db, cur_set, custom_fields[i]);
                    }
                }

                row_num += 1;
                cur_set.MoveNext();
            }

            return true;
        }

        public string GetFieldValue(ref clsDatabase cur_db, clsRecordset cur_set, string field_name)
        {
            string return_value = "";

            clsGeneral o_gen = new clsGeneral(ref cur_db);
            clsMoney o_money = new clsMoney(ref cur_db);

            if (oUtility.IsNonEmpty(field_name))
            {
                if (oUtility.IsDateField(field_name))
                {
                    return_value = o_gen.ToStrDate(cur_set.iField(field_name));
                }
                else if (oUtility.IsMoneyField(field_name))
                {
                    return_value = o_money.ToStrMoney(cur_set.mField(field_name));
                }
                else if (oUtility.IsIntegerField(field_name))
                {
                    return_value = cur_set.iField(field_name).ToString();

                    if (oUtility.SUCase(sTable_nm) == "TBLFAASSET" && oUtility.SUCase(oUtility.SRight(field_name, 4)) == "_TYP")
                    {
                        return_value = GetAssetTypeValue(field_name, return_value);
                    }
                    else if (oUtility.SUCase(sTable_nm) == oUtility.SUCase("tblARCustomerSupport") && (oUtility.SUCase(oUtility.SRight(field_name, 4)) == "_TYP" || oUtility.SUCase(oUtility.SRight(field_name, 3)) == "_ID"))
                    {
                        return_value = GetCustomerSupportTypeValue(field_name, return_value);
                    }
                }
                else if (oUtility.IsNumericField(field_name))
                {
                    return_value = cur_set.mField(field_name).ToString();
                }
                else
                {
                    return_value = cur_set.sField(field_name);
                }
            }

            return return_value;
        }

        private string GetCustomerSupportTypeValue(string field_name, string field_value)
        {
            string return_value = "";

            field_name = oUtility.SUCase(field_name);

            if (field_name == oUtility.SUCase("iReason_id"))
            {
                if (CustomerReason_set.FindRecord(field_name, field_value))
                {
                    return_value = CustomerReason_set.sField("sDescription");
                }
            }
            else if (field_name == oUtility.SUCase("iPriority_typ"))
            {
                return_value = GlobalVar.goStatus.WorkOrderPriorityTypeText(oUtility.ToInteger(field_value));
            }
            else if (field_name == oUtility.SUCase("iStatus_typ"))
            {
                return_value = GlobalVar.goStatus.SupportStatusTypeText(oUtility.ToInteger(field_value));
            }
            else
            {
                return_value = field_value;
            }

            return return_value;
        }
        private string GetAssetTypeValue(string field_name, string field_value)
        {
            string return_value = "";

            field_name = oUtility.SUCase(field_name);

            if (field_name == oUtility.SUCase("iAsset_typ"))
            {
                if (AssetType_set.FindRecord(field_name, field_value))
                {
                    return_value = AssetType_set.sField("sDescription");
                }
            }
            else if (field_name == oUtility.SUCase("iProperty_typ"))
            {
                return_value = GlobalVar.goStatus.AssetPropertyTypeText(oUtility.ToInteger(field_value));
            }
            else if (field_name == oUtility.SUCase("iStatus_typ"))
            {
                return_value = GlobalVar.goStatus.AssetStatusTypeText(oUtility.ToInteger(field_value));
            }
            else
            {
                return_value = field_value;
            }

            return return_value;
        }

    }
}
