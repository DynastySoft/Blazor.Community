﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Threading.Tasks;

namespace Dynasty.ASP.Models
{
    //  ===============================================================================================================================================================================================================================
    //  Pop-up window.  We will replace this method when we find a better later.
    //  ===============================================================================================================================================================================================================================
    public class clsModal
    {
        private readonly int STATUS_CANCEL = 1;
        private readonly int STATUS_OK = 2;

        public readonly int INPUT_TYPE_STRING = 1;
        public readonly int INPUT_TYPE_INTEGER =  11;
        public readonly int INPUT_TYPE_POSITIVE_INTEGER =  12;
        public readonly int INPUT_TYPE_DECIMAL =  21;                // float & money
        public readonly int INPUT_TYPE_POSITIVE_DECIMAL =  22;                

        public Func<bool> Caller = null;                        //  function that initiated this call.

        private int _caller_id = 0;
        public int Caller_id                                    // calling point inside calling function, Caller.
        {
            get { return _caller_id; }
        }

        public string OnChangeEvent { get; set; } = "";
        public string Message { get; set; } = "";
        public string InputText { get; set; } = "";
        public bool GetInput { get; set; } = false;

        private int _status = 0;
        public int Status
        {
            get { return _status; }
        }

        private bool _activated;
        public bool Activated
        {
            get { return _activated; }
        }

        public bool Valid
        {
            get { return (Caller != null && Caller_id != 0); }
        }

        public bool Register(Func<bool> func_caller, int func_id)
        {
            Caller = func_caller;
            _caller_id = func_id;
            return true;
        }
        public bool Release()
        {
            Caller = null;
            _caller_id = 0;
            _activated = false;
            // _status = 0;      DO NOT reset this.  This is still referenced after Release()

            return true;
        }
        public bool IsMyTurn(int func_id)
        {
            return  (Caller == null || Caller_id < func_id);
        }
        public bool IsMyCall(int func_id)
        {
            return (Caller == null || Caller_id == func_id);
        }
        public bool ReturningTo(int func_id)
        {
            return (Caller_id == func_id);
        }
        public bool OK
        {
            get { return (_status == STATUS_OK); }
        }
        public bool Cancel
        {
            get { return (_status == STATUS_CANCEL); }
        }

        private int _input_type = 0;
        public void Show(string msg, int get_type = -1)
        {
            GetInput = (get_type >= 0);
            Message = msg;
            InputText = "";         // Need to reset

            _status = 0;
            _activated = true;
            _input_type = get_type;

            if (_input_type ==  INPUT_TYPE_INTEGER)
            {
                OnChangeEvent = "IsValidInteger(this)";
            }
            else if (_input_type == INPUT_TYPE_DECIMAL)
            {
                OnChangeEvent = "IsValidMoney(this, false)";
            }
            else
            {
                OnChangeEvent = "";
            }
        }
        public bool OK_Clicked()
        {
            Message = "";
            _activated = false;
            _status = STATUS_OK;

            if (Valid)
            {
                Caller();
            }

            return true;
        }
        public bool Cancel_Clicked()
        {
            Message = "";
            _activated = false;
            _status = STATUS_CANCEL;

            if (Valid)
            {
                Caller();
            }

            return true;
        }
        public bool ValidInput
        {
            get {
                if (_input_type > 0)
                {
                    InputText = GlobalVar.goUtility.STrim(InputText);

                    if (GlobalVar.goUtility.IsEmpty(InputText))  // || ((_input_type != INPUT_TYPE_STRING) && GlobalVar.goUtility.ToValue(InputText) == (decimal)0))
                    {
                        return false;
                    }

                    if (_input_type == INPUT_TYPE_STRING)
                    {
                        // InputText = GlobalVar.goUtility.EvalQuote(InputText);
                    }
                    else if ((_input_type == INPUT_TYPE_INTEGER)  || (_input_type == INPUT_TYPE_POSITIVE_INTEGER))
                    {
                        if ((_input_type == INPUT_TYPE_POSITIVE_INTEGER) && (GlobalVar.goUtility.ToInteger(InputText) <= 0))
                        {
                            return false;
                        }
                        InputText = GlobalVar.goUtility.ToInteger(InputText).ToString();
                    }
                    else if ((_input_type == INPUT_TYPE_DECIMAL) || (_input_type == INPUT_TYPE_POSITIVE_DECIMAL))
                    {
                        if ((_input_type == INPUT_TYPE_POSITIVE_DECIMAL) && (GlobalVar.goUtility.ToValue(InputText) <= (decimal)0))
                        {
                            return false;
                        }
                        InputText = GlobalVar.goUtility.ToValue(InputText).ToString();
                    }
                }
                return true;
            }

        }
    }
}
