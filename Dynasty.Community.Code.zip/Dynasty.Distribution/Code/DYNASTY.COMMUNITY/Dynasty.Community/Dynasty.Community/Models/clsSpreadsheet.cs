﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Dynasty.Database;

namespace Dynasty.ASP.Models
{
    public class clsSpreadsheet
    {
        public const int TOTAL_COLUMNS = 100;

        public int iNextLine_id = 1;
        public int iTotalRows = 0;

        public string[,] Data;                                                                  // Keeps the detail data.
		public string[] FieldName;																// List of field names
		public string[] Caption;                                                                // List of column captions

		private string sPostingError = "";
		private clsDynastyUtility oUtility = new clsDynastyUtility();

		private bool bUtilizeCheckbox_fl = false;

		public clsSpreadsheet(bool utilize_checkbox_fl = false)
        {
			oUtility.ResizeDim(ref Data, TOTAL_COLUMNS - 1, 0);
			RecreateGrid();
			bUtilizeCheckbox_fl = utilize_checkbox_fl;
		}

		public bool Clear(int initial_rows = 1)
		{
			bool return_value = false;

			iTotalRows = initial_rows;
			oUtility.ResizeDim(ref Data, TOTAL_COLUMNS - 1, initial_rows - 1);
			RecreateGrid();

			return return_value;
		}

		public bool IsErrorFound()
		{
			bool return_value = false;

			return_value = (oUtility.IsNonEmpty(sPostingError));

			return return_value;
		}

		public string GetErrorMessage()
		{
			string return_value = "";

			return_value = sPostingError;
			sPostingError = "";

			return return_value;
		}
		public void SetPostingError(string error_msg)
		{
			if (oUtility.IsEmpty(error_msg))
			{
				sPostingError = "";
			}
			else if (oUtility.IsEmpty(sPostingError))
			{
				sPostingError = error_msg;
			}
			else if (oUtility.STrim(sPostingError) != oUtility.STrim(error_msg))
			{
				sPostingError += Environment.NewLine + Environment.NewLine + "AND " + error_msg;
			}
		}

		public bool Show(clsDatabase cur_db, clsPage cur_page, string table_name, string[] field_list, string where_clause, string sort_key = "")
        {

            bool return_value = false;
            int i;
            string sql_str;
            clsRecordset cur_set = new clsRecordset(ref cur_db);
			FieldName = field_list;


			try
            {
                Grid.Clear();

                if (oUtility.IsEmpty(table_name) || oUtility.IsEmpty(field_list))
                {
                    return false;
                }
                else if (oUtility.IsEmpty(field_list[0]))                                  // Should have at least one field
                {
                    return false;
                }

                if (field_list.GetLength(0) < TOTAL_COLUMNS)
                {
                    oUtility.ResizeDimPreserved(ref field_list, TOTAL_COLUMNS - 1);
                }

                sql_str = "SELECT " + field_list[0];

                for (i = 1; (i <= field_list.GetUpperBound(0) && i < TOTAL_COLUMNS); i++)
                {
                    if (oUtility.IsNonEmpty(field_list[i]))
                    {
                        sql_str += ", " + field_list[i];
                    }
                }
                sql_str += " FROM " + table_name;

                if (oUtility.IsNonEmpty(where_clause))
                {
                    sql_str += " WHERE " + where_clause;
                }

                if (oUtility.IsNonEmpty(sort_key))
                {
                    sql_str += " ORDER BY " + sort_key;
                }
                else
                {
                    sql_str += " ORDER BY " + field_list[0];
                }

                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    return false;
                }
                else if (cur_set.EOF())
                {
                    return true;
                }

                i = 0;
                while (cur_set.EOF() == false)
                {
                    Grid.Add(new clsGrid
                    {
                        Row_num = i
                        , Col_0 = GetFieldValue(cur_db, cur_set, field_list[0])
                        , Col_1 = GetFieldValue(cur_db, cur_set, field_list[1])
                        , Col_2 = GetFieldValue(cur_db, cur_set, field_list[2])
                        , Col_3 = GetFieldValue(cur_db, cur_set, field_list[3])
                        , Col_4 = GetFieldValue(cur_db, cur_set, field_list[4])
                        , Col_5 = GetFieldValue(cur_db, cur_set, field_list[5])
                        , Col_6 = GetFieldValue(cur_db, cur_set, field_list[6])
                        , Col_7 = GetFieldValue(cur_db, cur_set, field_list[7])
                        , Col_8 = GetFieldValue(cur_db, cur_set, field_list[8])
                        , Col_9 = GetFieldValue(cur_db, cur_set, field_list[9])
                        , Col_10 = GetFieldValue(cur_db, cur_set, field_list[10])
                        , Col_11 = GetFieldValue(cur_db, cur_set, field_list[11])
                        , Col_12 = GetFieldValue(cur_db, cur_set, field_list[12])
                        , Col_13 = GetFieldValue(cur_db, cur_set, field_list[13])
                        , Col_14 = GetFieldValue(cur_db, cur_set, field_list[14])
                        , Col_15 = GetFieldValue(cur_db, cur_set, field_list[15])
                        , Col_16 = GetFieldValue(cur_db, cur_set, field_list[16])
                        , Col_17 = GetFieldValue(cur_db, cur_set, field_list[17])
                        , Col_18 = GetFieldValue(cur_db, cur_set, field_list[18])
                        , Col_19 = GetFieldValue(cur_db, cur_set, field_list[19])
                        , Col_20 = GetFieldValue(cur_db, cur_set, field_list[20])
                        , Col_21 = GetFieldValue(cur_db, cur_set, field_list[21])
                        , Col_22 = GetFieldValue(cur_db, cur_set, field_list[22])
                        , Col_23 = GetFieldValue(cur_db, cur_set, field_list[23])
                        , Col_24 = GetFieldValue(cur_db, cur_set, field_list[24])
                        , Col_25 = GetFieldValue(cur_db, cur_set, field_list[25])
                        , Col_26 = GetFieldValue(cur_db, cur_set, field_list[26])
                        , Col_27 = GetFieldValue(cur_db, cur_set, field_list[27])
                        , Col_28 = GetFieldValue(cur_db, cur_set, field_list[28])
                        , Col_29 = GetFieldValue(cur_db, cur_set, field_list[29])
                        , Col_30 = GetFieldValue(cur_db, cur_set, field_list[30])
                        , Col_31 = GetFieldValue(cur_db, cur_set, field_list[31])
                        , Col_32 = GetFieldValue(cur_db, cur_set, field_list[32])
                        , Col_33 = GetFieldValue(cur_db, cur_set, field_list[33])
                        , Col_34 = GetFieldValue(cur_db, cur_set, field_list[34])
                        , Col_35 = GetFieldValue(cur_db, cur_set, field_list[35])
                        , Col_36 = GetFieldValue(cur_db, cur_set, field_list[36])
                        , Col_37 = GetFieldValue(cur_db, cur_set, field_list[37])
                        , Col_38 = GetFieldValue(cur_db, cur_set, field_list[38])
                        , Col_39 = GetFieldValue(cur_db, cur_set, field_list[39])
                        , Col_40 = GetFieldValue(cur_db, cur_set, field_list[40])
                        , Col_41 = GetFieldValue(cur_db, cur_set, field_list[41])
                        , Col_42 = GetFieldValue(cur_db, cur_set, field_list[42])
                        , Col_43 = GetFieldValue(cur_db, cur_set, field_list[43])
                        , Col_44 = GetFieldValue(cur_db, cur_set, field_list[44])
                        , Col_45 = GetFieldValue(cur_db, cur_set, field_list[45])
                        , Col_46 = GetFieldValue(cur_db, cur_set, field_list[46])
                        , Col_47 = GetFieldValue(cur_db, cur_set, field_list[47])
                        , Col_48 = GetFieldValue(cur_db, cur_set, field_list[48])
                        , Col_49 = GetFieldValue(cur_db, cur_set, field_list[49])
                        , Col_50 = GetFieldValue(cur_db, cur_set, field_list[50])
                        , Col_51 = GetFieldValue(cur_db, cur_set, field_list[51])
                        , Col_52 = GetFieldValue(cur_db, cur_set, field_list[52])
                        , Col_53 = GetFieldValue(cur_db, cur_set, field_list[53])
                        , Col_54 = GetFieldValue(cur_db, cur_set, field_list[54])
                        , Col_55 = GetFieldValue(cur_db, cur_set, field_list[55])
                        , Col_56 = GetFieldValue(cur_db, cur_set, field_list[56])
                        , Col_57 = GetFieldValue(cur_db, cur_set, field_list[57])
                        , Col_58 = GetFieldValue(cur_db, cur_set, field_list[58])
                        , Col_59 = GetFieldValue(cur_db, cur_set, field_list[59])
                        , Col_60 = GetFieldValue(cur_db, cur_set, field_list[60])
                        , Col_61 = GetFieldValue(cur_db, cur_set, field_list[61])
                        , Col_62 = GetFieldValue(cur_db, cur_set, field_list[62])
                        , Col_63 = GetFieldValue(cur_db, cur_set, field_list[63])
                        , Col_64 = GetFieldValue(cur_db, cur_set, field_list[64])
                        , Col_65 = GetFieldValue(cur_db, cur_set, field_list[65])
                        , Col_66 = GetFieldValue(cur_db, cur_set, field_list[66])
                        , Col_67 = GetFieldValue(cur_db, cur_set, field_list[67])
                        , Col_68 = GetFieldValue(cur_db, cur_set, field_list[68])
                        , Col_69 = GetFieldValue(cur_db, cur_set, field_list[69])
                        , Col_70 = GetFieldValue(cur_db, cur_set, field_list[70])
                        , Col_71 = GetFieldValue(cur_db, cur_set, field_list[71])
                        , Col_72 = GetFieldValue(cur_db, cur_set, field_list[72])
                        , Col_73 = GetFieldValue(cur_db, cur_set, field_list[73])
                        , Col_74 = GetFieldValue(cur_db, cur_set, field_list[74])
                        , Col_75 = GetFieldValue(cur_db, cur_set, field_list[75])
                        , Col_76 = GetFieldValue(cur_db, cur_set, field_list[76])
                        , Col_77 = GetFieldValue(cur_db, cur_set, field_list[77])
                        , Col_78 = GetFieldValue(cur_db, cur_set, field_list[78])
                        , Col_79 = GetFieldValue(cur_db, cur_set, field_list[79])                    
                        , Col_80 = GetFieldValue(cur_db, cur_set, field_list[80])
                        , Col_81 = GetFieldValue(cur_db, cur_set, field_list[81])
                        , Col_82 = GetFieldValue(cur_db, cur_set, field_list[82])
                        , Col_83 = GetFieldValue(cur_db, cur_set, field_list[83])
                        , Col_84 = GetFieldValue(cur_db, cur_set, field_list[84])
                        , Col_85 = GetFieldValue(cur_db, cur_set, field_list[85])
                        , Col_86 = GetFieldValue(cur_db, cur_set, field_list[86])
                        , Col_87 = GetFieldValue(cur_db, cur_set, field_list[87])
                        , Col_88 = GetFieldValue(cur_db, cur_set, field_list[88])
                        , Col_89 = GetFieldValue(cur_db, cur_set, field_list[89])
                        , Col_90 = GetFieldValue(cur_db, cur_set, field_list[90])
                        , Col_91 = GetFieldValue(cur_db, cur_set, field_list[91])
                        , Col_92 = GetFieldValue(cur_db, cur_set, field_list[92])
                        , Col_93 = GetFieldValue(cur_db, cur_set, field_list[93])
                        , Col_94 = GetFieldValue(cur_db, cur_set, field_list[94])
                        , Col_95 = GetFieldValue(cur_db, cur_set, field_list[95])
                        , Col_96 = GetFieldValue(cur_db, cur_set, field_list[96])
                        , Col_97 = GetFieldValue(cur_db, cur_set, field_list[97])
                        , Col_98 = GetFieldValue(cur_db, cur_set, field_list[98])
                        , Col_99 = GetFieldValue(cur_db, cur_set, field_list[99])
					});

                    i++;
                    cur_set.MoveNext();
                }

                return_value = true;
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(clsSpreadsheet.Show())");
            }

            return return_value;
        }

        public class clsGrid
        {
            public int Row_num = 0;                           // Keeps the row number
            public bool chkExclude_fl = false;				  
            public bool chkInclude_fl = false;
			public string Col_0 = "";
            public string Col_1 = "";
            public string Col_2 = "";
            public string Col_3 = "";
            public string Col_4 = "";
            public string Col_5 = "";
            public string Col_6 = "";
            public string Col_7 = "";
            public string Col_8 = "";
            public string Col_9 = "";
            public string Col_10 = "";
            public string Col_11 = "";
            public string Col_12 = "";
            public string Col_13 = "";
            public string Col_14 = "";
            public string Col_15 = "";
            public string Col_16 = "";
            public string Col_17 = "";
            public string Col_18 = "";
            public string Col_19 = "";
            public string Col_20 = "";
            public string Col_21 = "";
            public string Col_22 = "";
            public string Col_23 = "";
            public string Col_24 = "";
            public string Col_25 = "";
            public string Col_26 = "";
            public string Col_27 = "";
            public string Col_28 = "";
            public string Col_29 = "";
			public string Col_30 = "";
			public string Col_31 = "";
			public string Col_32 = "";
			public string Col_33 = "";
			public string Col_34 = "";
			public string Col_35 = "";
			public string Col_36 = "";
			public string Col_37 = "";
			public string Col_38 = "";
			public string Col_39 = "";
			public string Col_40 = "";
			public string Col_41 = "";
			public string Col_42 = "";
			public string Col_43 = "";
			public string Col_44 = "";
			public string Col_45 = "";
			public string Col_46 = "";
			public string Col_47 = "";
			public string Col_48 = "";
			public string Col_49 = "";
			public string Col_50 = "";
			public string Col_51 = "";
			public string Col_52 = "";
			public string Col_53 = "";
			public string Col_54 = "";
			public string Col_55 = "";
			public string Col_56 = "";
			public string Col_57 = "";
			public string Col_58 = "";
			public string Col_59 = "";
			public string Col_60 = "";
			public string Col_61 = "";
			public string Col_62 = "";
			public string Col_63 = "";
			public string Col_64 = "";
			public string Col_65 = "";
			public string Col_66 = "";
			public string Col_67 = "";
			public string Col_68 = "";
			public string Col_69 = "";
			public string Col_70 = "";
			public string Col_71 = "";
			public string Col_72 = "";
			public string Col_73 = "";
			public string Col_74 = "";
			public string Col_75 = "";
			public string Col_76 = "";
			public string Col_77 = "";
			public string Col_78 = "";
			public string Col_79 = "";
			public string Col_80 = "";
			public string Col_81 = "";
			public string Col_82 = "";
			public string Col_83 = "";
			public string Col_84 = "";
			public string Col_85 = "";
			public string Col_86 = "";
			public string Col_87 = "";
			public string Col_88 = "";
			public string Col_89 = "";
			public string Col_90 = "";
			public string Col_91 = "";
			public string Col_92 = "";
			public string Col_93 = "";
			public string Col_94 = "";
			public string Col_95 = "";
			public string Col_96 = "";
			public string Col_97 = "";
			public string Col_98 = "";
			public string Col_99 = "";

		}
		public List<clsGrid> Grid = new List<clsGrid>();

        private string GetFieldValue(clsDatabase cur_db, clsRecordset cur_set, string field_name)
        {
            string return_value = "";
            clsGeneral o_gen = new clsGeneral(ref cur_db);
            clsMoney o_mon = new clsMoney(ref cur_db);

            if (oUtility.IsEmpty(field_name))
            {
                return "";
            }
            if (oUtility.SInStr(field_name, " AS ") > 0)           // Alias found
            {
                field_name = oUtility.STrim(oUtility.SRight(field_name, oUtility.SLength(field_name) - oUtility.SInStr(field_name, " AS ") - 3));
            }
            else if (oUtility.SInStr(field_name, ") ") > 0)        // Alias found
            {
                field_name = oUtility.STrim(oUtility.SRight(field_name, oUtility.SLength(field_name) - oUtility.SInStr(field_name, ") ") - 1));
            }

            if (oUtility.SUCase(oUtility.SLeft(field_name, 1)) == "I" && oUtility.SUCase(oUtility.SRight(field_name, 3)) == "_DT")
            {
                return_value = o_gen.ToStrDate(cur_set.iField(field_name));
            }
            else if (oUtility.SUCase(oUtility.SLeft(field_name, 1)) == "M")
            {
                return_value = o_mon.ToStrMoney(cur_set.mField(field_name));
            }
            else
            {
                return_value = cur_set.Field(field_name).ToString();
            }

            return return_value;
        }

		
		public bool AddMoreRows(int lines_to_add = 10)
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
                // oUtility.ResizeDimPreserved(ref Data, Data.GetUpperBound(0), Data.GetUpperBound(1) + lines_to_add);

                for (row_num = 0; row_num < lines_to_add; row_num++)
                {
                    Grid.Add(new clsGrid { Row_num = iTotalRows
							, chkInclude_fl = false
							, chkExclude_fl = false
					});

                    iTotalRows += 1;
					iNextLine_id += 1;
				}
                
                RecreateDetail();
                return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (AddMoreRows)");
				RecreateDetail();
            }

            return return_value;
        }

		public bool InsertNewRow(clsGrid cur_item)
		{
			bool return_value = false;
			int old_row_num = cur_item.Row_num;

			try
			{
				Grid.Insert(old_row_num, new clsGrid
				{
					Row_num = -1
				}); 

				Grid.Where(i => i.Row_num >= old_row_num).Select(i => { i.Row_num += 1; return i; }).ToList();
				Grid.Single(i => i.Row_num == -1).Row_num = old_row_num;

				iNextLine_id += 1;
				iTotalRows += 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (InsertNewRow)");
			}

			return return_value;
		}

		public bool DeleteCurrentRow(clsGrid cur_item)
		{
			bool return_value = false;
			int old_num = cur_item.Row_num;

			try
			{
				Grid.RemoveAt(cur_item.Row_num);
				Grid.Where(i => i.Row_num >= old_num).Select(i => { i.Row_num -= 1; return i; }).ToList();

				iTotalRows -= 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (DeleteCurrentRow)");
			}

			return return_value;
		}


		public bool DeleteCurrentRow(int row_num)
		{
			bool return_value = false;
			int old_num = row_num;

			try
			{
				Grid.RemoveAt(row_num);
				Grid.Where(i => i.Row_num >= old_num).Select(i => { i.Row_num -= 1; return i; }).ToList();

				iTotalRows -= 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (DeleteCurrentRow)");
			}

			return return_value;
		}
		public bool RecreateDetail()                                                           //  Sync Data with Grid for the items that do not have event-handler ONLY.
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				if (Grid.Count() == 0)
				{
					oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), 0);
					return true;
				}

				// We need to create it here for saving because some fields may not have been copied into the array.
				//
				iTotalRows = Grid.Count();
				oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), iTotalRows - 1);

				foreach (var det in Grid)
				{
					if (RecreateDetailLine(det, row_num) == false)
					{
						return false;
					}

					det.Row_num = row_num;      // Just to make sure.
					row_num++;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetail)");
			}

			return return_value;
		}

		public bool RecreateGridLine(int row_num)
		{
			bool return_value = false;
			clsGrid grid_line = new clsGrid();

			if (FindGridLine(row_num, ref grid_line) == false)
			{
				SetPostingError("Grid does not match array.");
				return false;
			}

			return RecreateGridLine(ref grid_line, row_num);
		}

		public bool RecreateGridLine(ref clsGrid cur_item, int row_num)
		{
			bool return_value = false;

			try
			{
				cur_item.chkInclude_fl = (GlobalVar.goUtility.ToInteger(Data[0, row_num]) == 1);				
				cur_item.Col_0 = Data[0, row_num];
				cur_item.Col_1 = Data[1, row_num];
				cur_item.Col_2 = Data[2, row_num];
				cur_item.Col_3 = Data[3, row_num];
				cur_item.Col_4 = Data[4, row_num];
				cur_item.Col_5 = Data[5, row_num];
				cur_item.Col_6 = Data[6, row_num];
				cur_item.Col_7 = Data[7, row_num];
				cur_item.Col_8 = Data[8, row_num];
				cur_item.Col_9 = Data[9, row_num];
				cur_item.Col_10 = Data[10, row_num];
				cur_item.Col_11 = Data[11, row_num];
				cur_item.Col_12 = Data[12, row_num];
				cur_item.Col_13 = Data[13, row_num];
				cur_item.Col_14 = Data[14, row_num];
				cur_item.Col_15 = Data[15, row_num];
				cur_item.Col_16 = Data[16, row_num];
				cur_item.Col_17 = Data[17, row_num];
				cur_item.Col_18 = Data[18, row_num];
				cur_item.Col_19 = Data[19, row_num];
				cur_item.Col_20 = Data[20, row_num];
				cur_item.Col_21 = Data[21, row_num];
				cur_item.Col_22 = Data[22, row_num];
				cur_item.Col_23 = Data[23, row_num];
				cur_item.Col_24 = Data[24, row_num];
				cur_item.Col_25 = Data[25, row_num];
				cur_item.Col_26 = Data[26, row_num];
				cur_item.Col_27 = Data[27, row_num];
				cur_item.Col_28 = Data[28, row_num];
				cur_item.Col_29 = Data[29, row_num];
				cur_item.Col_30 = Data[30, row_num];
				cur_item.Col_31 = Data[31, row_num];
				cur_item.Col_32 = Data[32, row_num];
				cur_item.Col_33 = Data[33, row_num];
				cur_item.Col_34 = Data[34, row_num];
				cur_item.Col_35 = Data[35, row_num];
				cur_item.Col_36 = Data[36, row_num];
				cur_item.Col_37 = Data[37, row_num];
				cur_item.Col_38 = Data[38, row_num];
				cur_item.Col_39 = Data[39, row_num];
				cur_item.Col_40 = Data[40, row_num];
				cur_item.Col_41 = Data[41, row_num];
				cur_item.Col_42 = Data[42, row_num];
				cur_item.Col_43 = Data[43, row_num];
				cur_item.Col_44 = Data[44, row_num];
				cur_item.Col_45 = Data[45, row_num];
				cur_item.Col_46 = Data[46, row_num];
				cur_item.Col_47 = Data[47, row_num];
				cur_item.Col_48 = Data[48, row_num];
				cur_item.Col_49 = Data[49, row_num];
				cur_item.Col_50 = Data[50, row_num];
				cur_item.Col_51 = Data[51, row_num];
				cur_item.Col_52 = Data[52, row_num];
				cur_item.Col_53 = Data[53, row_num];
				cur_item.Col_54 = Data[54, row_num];
				cur_item.Col_55 = Data[55, row_num];
				cur_item.Col_56 = Data[56, row_num];
				cur_item.Col_57 = Data[57, row_num];
				cur_item.Col_58 = Data[58, row_num];
				cur_item.Col_59 = Data[59, row_num];
				cur_item.Col_60 = Data[60, row_num];
				cur_item.Col_61 = Data[61, row_num];
				cur_item.Col_62 = Data[62, row_num];
				cur_item.Col_63 = Data[63, row_num];
				cur_item.Col_64 = Data[64, row_num];
				cur_item.Col_65 = Data[65, row_num];
				cur_item.Col_66 = Data[66, row_num];
				cur_item.Col_67 = Data[67, row_num];
				cur_item.Col_68 = Data[68, row_num];
				cur_item.Col_69 = Data[69, row_num];
				cur_item.Col_70 = Data[70, row_num];
				cur_item.Col_71 = Data[71, row_num];
				cur_item.Col_72 = Data[72, row_num];
				cur_item.Col_73 = Data[73, row_num];
				cur_item.Col_74 = Data[74, row_num];
				cur_item.Col_75 = Data[75, row_num];
				cur_item.Col_76 = Data[76, row_num];
				cur_item.Col_77 = Data[77, row_num];
				cur_item.Col_78 = Data[78, row_num];
				cur_item.Col_79 = Data[79, row_num];
				cur_item.Col_80 = Data[80, row_num];
				cur_item.Col_81 = Data[81, row_num];
				cur_item.Col_82 = Data[82, row_num];
				cur_item.Col_83 = Data[83, row_num];
				cur_item.Col_84 = Data[84, row_num];
				cur_item.Col_85 = Data[85, row_num];
				cur_item.Col_86 = Data[86, row_num];
				cur_item.Col_87 = Data[87, row_num];
				cur_item.Col_88 = Data[88, row_num];
				cur_item.Col_89 = Data[89, row_num];
				cur_item.Col_90 = Data[90, row_num];
				cur_item.Col_91 = Data[91, row_num];
				cur_item.Col_92 = Data[92, row_num];
				cur_item.Col_93 = Data[93, row_num];
				cur_item.Col_94 = Data[94, row_num];
				cur_item.Col_95 = Data[95, row_num];
				cur_item.Col_96 = Data[96, row_num];
				cur_item.Col_97 = Data[97, row_num];
				cur_item.Col_98 = Data[98, row_num];
				cur_item.Col_99 = Data[99, row_num];
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateGridLine)");
			}
			return return_value;

		}

		public bool FindGridLine(int row_num, ref clsGrid line_found)
		{
			bool return_value = false;

			try
			{
				line_found = Grid.Single(i => i.Row_num == row_num);

				if (line_found != null)
				{
					return_value = true;
				}
			}
			catch (Exception ex)
			{
				// in case not found
			}

			return return_value;
		}

		public bool RecreateDetailLine(clsGrid cur_item, int row_num = -1)
		{
			bool return_value = false;

			try
			{
				// If this is called from UI event, get the row number of current line.
				//
				if (row_num < 0)
				{
					row_num = cur_item.Row_num;
				}

				// When bUtilizeCheckbox_fl == true, we sync Data[0, row_num] to  chkInclude_fl
				//
				if (bUtilizeCheckbox_fl)
                {
					Data[0, row_num] = cur_item.chkInclude_fl? "1" : "0";
				}
				else
                {
					Data[0, row_num] = cur_item.Col_0;
				}
				Data[1, row_num] = cur_item.Col_1;
				Data[2, row_num] = cur_item.Col_2;
				Data[3, row_num] = cur_item.Col_3;
				Data[4, row_num] = cur_item.Col_4;
				Data[5, row_num] = cur_item.Col_5;
				Data[6, row_num] = cur_item.Col_6;
				Data[7, row_num] = cur_item.Col_7;
				Data[8, row_num] = cur_item.Col_8;
				Data[9, row_num] = cur_item.Col_9;
				Data[10, row_num] = cur_item.Col_10;
				Data[11, row_num] = cur_item.Col_11;
				Data[12, row_num] = cur_item.Col_12;
				Data[13, row_num] = cur_item.Col_13;
				Data[14, row_num] = cur_item.Col_14;
				Data[15, row_num] = cur_item.Col_15;
				Data[16, row_num] = cur_item.Col_16;
				Data[17, row_num] = cur_item.Col_17;
				Data[18, row_num] = cur_item.Col_18;
				Data[19, row_num] = cur_item.Col_19;
				Data[20, row_num] = cur_item.Col_20;
				Data[21, row_num] = cur_item.Col_21;
				Data[22, row_num] = cur_item.Col_22;
				Data[23, row_num] = cur_item.Col_23;
				Data[24, row_num] = cur_item.Col_24;
				Data[25, row_num] = cur_item.Col_25;
				Data[26, row_num] = cur_item.Col_26;
				Data[27, row_num] = cur_item.Col_27;
				Data[28, row_num] = cur_item.Col_28;
				Data[29, row_num] = cur_item.Col_29;
				Data[30, row_num] = cur_item.Col_30;
				Data[31, row_num] = cur_item.Col_31;
				Data[32, row_num] = cur_item.Col_32;
				Data[33, row_num] = cur_item.Col_33;
				Data[34, row_num] = cur_item.Col_34;
				Data[35, row_num] = cur_item.Col_35;
				Data[36, row_num] = cur_item.Col_36;
				Data[37, row_num] = cur_item.Col_37;
				Data[38, row_num] = cur_item.Col_38;
				Data[39, row_num] = cur_item.Col_39;
				Data[40, row_num] = cur_item.Col_40;
				Data[41, row_num] = cur_item.Col_41;
				Data[42, row_num] = cur_item.Col_42;
				Data[43, row_num] = cur_item.Col_43;
				Data[44, row_num] = cur_item.Col_44;
				Data[45, row_num] = cur_item.Col_45;
				Data[46, row_num] = cur_item.Col_46;
				Data[47, row_num] = cur_item.Col_47;
				Data[48, row_num] = cur_item.Col_48;
				Data[49, row_num] = cur_item.Col_49;
				Data[50, row_num] = cur_item.Col_50;
				Data[51, row_num] = cur_item.Col_51;
				Data[52, row_num] = cur_item.Col_52;
				Data[53, row_num] = cur_item.Col_53;
				Data[54, row_num] = cur_item.Col_54;
				Data[55, row_num] = cur_item.Col_55;
				Data[56, row_num] = cur_item.Col_56;
				Data[57, row_num] = cur_item.Col_57;
				Data[58, row_num] = cur_item.Col_58;
				Data[59, row_num] = cur_item.Col_59;
				Data[60, row_num] = cur_item.Col_60;
				Data[61, row_num] = cur_item.Col_61;
				Data[62, row_num] = cur_item.Col_62;
				Data[63, row_num] = cur_item.Col_63;
				Data[64, row_num] = cur_item.Col_64;
				Data[65, row_num] = cur_item.Col_65;
				Data[66, row_num] = cur_item.Col_66;
				Data[67, row_num] = cur_item.Col_67;
				Data[68, row_num] = cur_item.Col_68;
				Data[69, row_num] = cur_item.Col_69;
				Data[70, row_num] = cur_item.Col_70;
				Data[71, row_num] = cur_item.Col_71;
				Data[72, row_num] = cur_item.Col_72;
				Data[73, row_num] = cur_item.Col_73;
				Data[74, row_num] = cur_item.Col_74;
				Data[75, row_num] = cur_item.Col_75;
				Data[76, row_num] = cur_item.Col_76;
				Data[77, row_num] = cur_item.Col_77;
				Data[78, row_num] = cur_item.Col_78;
				Data[79, row_num] = cur_item.Col_79;
				Data[80, row_num] = cur_item.Col_80;
				Data[81, row_num] = cur_item.Col_81;
				Data[82, row_num] = cur_item.Col_82;
				Data[83, row_num] = cur_item.Col_83;
				Data[84, row_num] = cur_item.Col_84;
				Data[85, row_num] = cur_item.Col_85;
				Data[86, row_num] = cur_item.Col_86;
				Data[87, row_num] = cur_item.Col_87;
				Data[88, row_num] = cur_item.Col_88;
				Data[89, row_num] = cur_item.Col_89;
				Data[90, row_num] = cur_item.Col_90;
				Data[91, row_num] = cur_item.Col_91;
				Data[92, row_num] = cur_item.Col_92;
				Data[93, row_num] = cur_item.Col_93;
				Data[94, row_num] = cur_item.Col_94;
				Data[95, row_num] = cur_item.Col_95;
				Data[96, row_num] = cur_item.Col_96;
				Data[97, row_num] = cur_item.Col_97;
				Data[98, row_num] = cur_item.Col_98;
				Data[99, row_num] = cur_item.Col_99;

				return_value = true;

			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetailLine)");
			}

			return return_value;
		}

		public bool RecreateGrid()                                                             //  Create Grid according to Data
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				Grid.Clear();

				if (Data == null)
				{
					return true;
				}
				else if (Data.GetLength(1) == 0)
				{
					return true;
				}

				iTotalRows = Data.GetLength(1);

				for (row_num = 0; row_num < iTotalRows; row_num++)
				{
					Grid.Add(new clsGrid
					{
						Row_num = row_num
						,chkExclude_fl = false
						,chkInclude_fl = (bUtilizeCheckbox_fl? (GlobalVar.goUtility.ToInteger(Data[0, row_num]) == 1) : false)
						,Col_0 = Data[0, row_num]
						,Col_1 = Data[1, row_num]
						,Col_2 = Data[2, row_num]
						,Col_3 = Data[3, row_num]
						,Col_4 = Data[4, row_num]
						,Col_5 = Data[5, row_num]
						,Col_6 = Data[6, row_num]
						,Col_7 = Data[7, row_num]
						,Col_8 = Data[8, row_num]
						,Col_9 = Data[9, row_num]
						,Col_10 = Data[10, row_num]
						,Col_11 = Data[11, row_num]
						,Col_12 = Data[12, row_num]
						,Col_13 = Data[13, row_num]
						,Col_14 = Data[14, row_num]
						,Col_15 = Data[15, row_num]
						,Col_16 = Data[16, row_num]
						,Col_17 = Data[17, row_num]
						,Col_18 = Data[18, row_num]
						,Col_19 = Data[19, row_num]
						,Col_20 = Data[20, row_num]
						,Col_21 = Data[21, row_num]
						,Col_22 = Data[22, row_num]
						,Col_23 = Data[23, row_num]
						,Col_24 = Data[24, row_num]
						,Col_25 = Data[25, row_num]
						,Col_26 = Data[26, row_num]
						,Col_27 = Data[27, row_num]
						,Col_28 = Data[28, row_num]
						,Col_29 = Data[29, row_num]
						,Col_30 = Data[30, row_num]
						,Col_31 = Data[31, row_num]
						,Col_32 = Data[32, row_num]
						,Col_33 = Data[33, row_num]
						,Col_34 = Data[34, row_num]
						,Col_35 = Data[35, row_num]
						,Col_36 = Data[36, row_num]
						,Col_37 = Data[37, row_num]
						,Col_38 = Data[38, row_num]
						,Col_39 = Data[39, row_num]
						,Col_40 = Data[40, row_num]
						,Col_41 = Data[41, row_num]
						,Col_42 = Data[42, row_num]
						,Col_43 = Data[43, row_num]
						,Col_44 = Data[44, row_num]
						,Col_45 = Data[45, row_num]
						,Col_46 = Data[46, row_num]
						,Col_47 = Data[47, row_num]
						,Col_48 = Data[48, row_num]
						,Col_49 = Data[49, row_num]
						,Col_50 = Data[50, row_num]
						,Col_51 = Data[51, row_num]
						,Col_52 = Data[52, row_num]
						,Col_53 = Data[53, row_num]
						,Col_54 = Data[54, row_num]
						,Col_55 = Data[55, row_num]
						,Col_56 = Data[56, row_num]
						,Col_57 = Data[57, row_num]
						,Col_58 = Data[58, row_num]
						,Col_59 = Data[59, row_num]
						,Col_60 = Data[60, row_num]
						,Col_61 = Data[61, row_num]
						,Col_62 = Data[62, row_num]
						,Col_63 = Data[63, row_num]
						,Col_64 = Data[64, row_num]
						,Col_65 = Data[65, row_num]
						,Col_66 = Data[66, row_num]
						,Col_67 = Data[67, row_num]
						,Col_68 = Data[68, row_num]
						,Col_69 = Data[69, row_num]
						,Col_70 = Data[70, row_num]
						,Col_71 = Data[71, row_num]
						,Col_72 = Data[72, row_num]
						,Col_73 = Data[73, row_num]
						,Col_74 = Data[74, row_num]
						,Col_75 = Data[75, row_num]
						,Col_76 = Data[76, row_num]
						,Col_77 = Data[77, row_num]
						,Col_78 = Data[78, row_num]
						,Col_79 = Data[79, row_num]
						,Col_80 = Data[80, row_num]
						,Col_81 = Data[81, row_num]
						,Col_82 = Data[82, row_num]
						,Col_83 = Data[83, row_num]
						,Col_84 = Data[84, row_num]
						,Col_85 = Data[85, row_num]
						,Col_86 = Data[86, row_num]
						,Col_87 = Data[87, row_num]
						,Col_88 = Data[88, row_num]
						,Col_89 = Data[89, row_num]
						,Col_90 = Data[90, row_num]
						,Col_91 = Data[91, row_num]
						,Col_92 = Data[92, row_num]
						,Col_93 = Data[93, row_num]
						,Col_94 = Data[94, row_num]
						,Col_95 = Data[95, row_num]
						,Col_96 = Data[96, row_num]
						,Col_97 = Data[97, row_num]
						,Col_98 = Data[98, row_num]
						,Col_99 = Data[99, row_num]
					});
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateGrid)");
			}

			return return_value;
		}

		public bool SetCellValue(int col_num, int row_num, string new_value)
        {
			bool return_value = false;

			try
            {
				switch (col_num)
                {
					case 0:
						Grid.Single(i => i.Row_num == row_num).Col_0 = new_value;
						break;
					case 1:
						Grid.Single(i => i.Row_num == row_num).Col_1 = new_value;
						break;
					case 2:
						Grid.Single(i => i.Row_num == row_num).Col_2 = new_value;
						break;
					case 3:
						Grid.Single(i => i.Row_num == row_num).Col_3 = new_value;
						break;
					case 4:
						Grid.Single(i => i.Row_num == row_num).Col_4 = new_value;
						break;
					case 5:
						Grid.Single(i => i.Row_num == row_num).Col_5 = new_value;
						break;
					case 6:
						Grid.Single(i => i.Row_num == row_num).Col_6 = new_value;
						break;
					case 7:
						Grid.Single(i => i.Row_num == row_num).Col_7 = new_value;
						break;
					case 8:
						Grid.Single(i => i.Row_num == row_num).Col_8 = new_value;
						break;
					case 9:
						Grid.Single(i => i.Row_num == row_num).Col_9 = new_value;
						break;
					case 10:
						Grid.Single(i => i.Row_num == row_num).Col_10 = new_value;
						break;
					case 11:
						Grid.Single(i => i.Row_num == row_num).Col_11 = new_value;
						break;
					case 12:
						Grid.Single(i => i.Row_num == row_num).Col_12 = new_value;
						break;
					case 13:
						Grid.Single(i => i.Row_num == row_num).Col_13 = new_value;
						break;
					case 14:
						Grid.Single(i => i.Row_num == row_num).Col_14 = new_value;
						break;
					case 15:
						Grid.Single(i => i.Row_num == row_num).Col_15 = new_value;
						break;
					case 16:
						Grid.Single(i => i.Row_num == row_num).Col_16 = new_value;
						break;
					case 17:
						Grid.Single(i => i.Row_num == row_num).Col_17 = new_value;
						break;
					case 18:
						Grid.Single(i => i.Row_num == row_num).Col_18 = new_value;
						break;
					case 19:
						Grid.Single(i => i.Row_num == row_num).Col_19 = new_value;
						break;
					case 20:
						Grid.Single(i => i.Row_num == row_num).Col_20 = new_value;
						break;
					case 21:
						Grid.Single(i => i.Row_num == row_num).Col_21 = new_value;
						break;
					case 22:
						Grid.Single(i => i.Row_num == row_num).Col_22 = new_value;
						break;
					case 23:
						Grid.Single(i => i.Row_num == row_num).Col_23 = new_value;
						break;
					case 24:
						Grid.Single(i => i.Row_num == row_num).Col_24 = new_value;
						break;
					case 25:
						Grid.Single(i => i.Row_num == row_num).Col_25 = new_value;
						break;
					case 26:
						Grid.Single(i => i.Row_num == row_num).Col_26 = new_value;
						break;
					case 27:
						Grid.Single(i => i.Row_num == row_num).Col_27 = new_value;
						break;
					case 28:
						Grid.Single(i => i.Row_num == row_num).Col_28 = new_value;
						break;
					case 29:
						Grid.Single(i => i.Row_num == row_num).Col_29 = new_value;
						break;
					case 30:
						Grid.Single(i => i.Row_num == row_num).Col_30 = new_value;
						break;
					case 31:
						Grid.Single(i => i.Row_num == row_num).Col_31 = new_value;
						break;
					case 32:
						Grid.Single(i => i.Row_num == row_num).Col_32 = new_value;
						break;
					case 33:
						Grid.Single(i => i.Row_num == row_num).Col_33 = new_value;
						break;
					case 34:
						Grid.Single(i => i.Row_num == row_num).Col_34 = new_value;
						break;
					case 35:
						Grid.Single(i => i.Row_num == row_num).Col_35 = new_value;
						break;
					case 36:
						Grid.Single(i => i.Row_num == row_num).Col_36 = new_value;
						break;
					case 37:
						Grid.Single(i => i.Row_num == row_num).Col_37 = new_value;
						break;
					case 38:
						Grid.Single(i => i.Row_num == row_num).Col_38 = new_value;
						break;
					case 39:
						Grid.Single(i => i.Row_num == row_num).Col_39 = new_value;
						break;
					case 40:
						Grid.Single(i => i.Row_num == row_num).Col_40 = new_value;
						break;
					case 41:
						Grid.Single(i => i.Row_num == row_num).Col_41 = new_value;
						break;
					case 42:
						Grid.Single(i => i.Row_num == row_num).Col_42 = new_value;
						break;
					case 43:
						Grid.Single(i => i.Row_num == row_num).Col_43 = new_value;
						break;
					case 44:
						Grid.Single(i => i.Row_num == row_num).Col_44 = new_value;
						break;
					case 45:
						Grid.Single(i => i.Row_num == row_num).Col_45 = new_value;
						break;
					case 46:
						Grid.Single(i => i.Row_num == row_num).Col_46 = new_value;
						break;
					case 47:
						Grid.Single(i => i.Row_num == row_num).Col_47 = new_value;
						break;
					case 48:
						Grid.Single(i => i.Row_num == row_num).Col_48 = new_value;
						break;
					case 49:
						Grid.Single(i => i.Row_num == row_num).Col_49 = new_value;
						break;
					case 50:
						Grid.Single(i => i.Row_num == row_num).Col_50 = new_value;
						break;
					case 51:
						Grid.Single(i => i.Row_num == row_num).Col_51 = new_value;
						break;
					case 52:
						Grid.Single(i => i.Row_num == row_num).Col_52 = new_value;
						break;
					case 53:
						Grid.Single(i => i.Row_num == row_num).Col_53 = new_value;
						break;
					case 54:
						Grid.Single(i => i.Row_num == row_num).Col_54 = new_value;
						break;
					case 55:
						Grid.Single(i => i.Row_num == row_num).Col_55 = new_value;
						break;
					case 56:
						Grid.Single(i => i.Row_num == row_num).Col_56 = new_value;
						break;
					case 57:
						Grid.Single(i => i.Row_num == row_num).Col_57 = new_value;
						break;
					case 58:
						Grid.Single(i => i.Row_num == row_num).Col_58 = new_value;
						break;
					case 59:
						Grid.Single(i => i.Row_num == row_num).Col_59 = new_value;
						break;
					case 60:
						Grid.Single(i => i.Row_num == row_num).Col_60 = new_value;
						break;
					case 61:
						Grid.Single(i => i.Row_num == row_num).Col_61 = new_value;
						break;
					case 62:
						Grid.Single(i => i.Row_num == row_num).Col_62 = new_value;
						break;
					case 63:
						Grid.Single(i => i.Row_num == row_num).Col_63 = new_value;
						break;
					case 64:
						Grid.Single(i => i.Row_num == row_num).Col_64 = new_value;
						break;
					case 65:
						Grid.Single(i => i.Row_num == row_num).Col_65 = new_value;
						break;
					case 66:
						Grid.Single(i => i.Row_num == row_num).Col_66 = new_value;
						break;
					case 67:
						Grid.Single(i => i.Row_num == row_num).Col_67 = new_value;
						break;
					case 68:
						Grid.Single(i => i.Row_num == row_num).Col_68 = new_value;
						break;
					case 69:
						Grid.Single(i => i.Row_num == row_num).Col_69 = new_value;
						break;
					case 70:
						Grid.Single(i => i.Row_num == row_num).Col_70 = new_value;
						break;
					case 71:
						Grid.Single(i => i.Row_num == row_num).Col_71 = new_value;
						break;
					case 72:
						Grid.Single(i => i.Row_num == row_num).Col_72 = new_value;
						break;
					case 73:
						Grid.Single(i => i.Row_num == row_num).Col_73 = new_value;
						break;
					case 74:
						Grid.Single(i => i.Row_num == row_num).Col_74 = new_value;
						break;
					case 75:
						Grid.Single(i => i.Row_num == row_num).Col_75 = new_value;
						break;
					case 76:
						Grid.Single(i => i.Row_num == row_num).Col_76 = new_value;
						break;
					case 77:
						Grid.Single(i => i.Row_num == row_num).Col_77 = new_value;
						break;
					case 78:
						Grid.Single(i => i.Row_num == row_num).Col_78 = new_value;
						break;
					case 79:
						Grid.Single(i => i.Row_num == row_num).Col_79 = new_value;
						break;
					case 80:
						Grid.Single(i => i.Row_num == row_num).Col_80 = new_value;
						break;
					case 81:
						Grid.Single(i => i.Row_num == row_num).Col_81 = new_value;
						break;
					case 82:
						Grid.Single(i => i.Row_num == row_num).Col_82 = new_value;
						break;
					case 83:
						Grid.Single(i => i.Row_num == row_num).Col_83 = new_value;
						break;
					case 84:
						Grid.Single(i => i.Row_num == row_num).Col_84 = new_value;
						break;
					case 85:
						Grid.Single(i => i.Row_num == row_num).Col_85 = new_value;
						break;
					case 86:
						Grid.Single(i => i.Row_num == row_num).Col_86 = new_value;
						break;
					case 87:
						Grid.Single(i => i.Row_num == row_num).Col_87 = new_value;
						break;
					case 88:
						Grid.Single(i => i.Row_num == row_num).Col_88 = new_value;
						break;
					case 89:
						Grid.Single(i => i.Row_num == row_num).Col_89 = new_value;
						break;
					case 90:
						Grid.Single(i => i.Row_num == row_num).Col_90 = new_value;
						break;
					case 91:
						Grid.Single(i => i.Row_num == row_num).Col_91 = new_value;
						break;
					case 92:
						Grid.Single(i => i.Row_num == row_num).Col_92 = new_value;
						break;
					case 93:
						Grid.Single(i => i.Row_num == row_num).Col_93 = new_value;
						break;
					case 94:
						Grid.Single(i => i.Row_num == row_num).Col_94 = new_value;
						break;
					case 95:
						Grid.Single(i => i.Row_num == row_num).Col_95 = new_value;
						break;
					case 96:
						Grid.Single(i => i.Row_num == row_num).Col_96 = new_value;
						break;
					case 97:
						Grid.Single(i => i.Row_num == row_num).Col_97 = new_value;
						break;
					case 98:
						Grid.Single(i => i.Row_num == row_num).Col_98 = new_value;
						break;
					case 99:
						Grid.Single(i => i.Row_num == row_num).Col_99 = new_value;
						break;
					default:
						break;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (SetCellValue)");
			}

			return return_value;
		}

		public bool IsReal(int cur_index)
        {
			return (oUtility.SUCase(oUtility.SLeft(FieldName[cur_index], 1)) == "M" || oUtility.SUCase(oUtility.SLeft(FieldName[cur_index], 1)) == "F");
		}
		public bool IsNumeric(int cur_index)
		{
			return (oUtility.SUCase(oUtility.SLeft(FieldName[cur_index], 1)) == "M" || oUtility.SUCase(oUtility.SLeft(FieldName[cur_index], 1)) == "F" || oUtility.SUCase(oUtility.SLeft(FieldName[cur_index], 1)) == "I");
		}
		public string InquiryCSS(int cur_index)
		{
			string return_value = "CellS";      // For string types;

			if (FieldName == null || FieldName.GetUpperBound(0) < cur_index)
            {
				return "CellText";
            }
			if (oUtility.SUCase(FieldName[cur_index]) == "IITEM_TYP" || oUtility.SUCase(FieldName[cur_index]) == "ISTATUS_TYP" || oUtility.SUCase(FieldName[cur_index]) == "IORDER_TYP"
				 || oUtility.SUCase(FieldName[cur_index]) == "IPAYMENT_TYP" || oUtility.SUCase(FieldName[cur_index]) == "ICASH_TYP" || oUtility.SUCase(FieldName[cur_index]) == "IGROUP_TYP")		// Types show the description
            {
				return_value = "CellText";
			}
			else if (IsReal(cur_index))
            {
				return_value = "CellM";
			}
			else if (oUtility.SUCase(oUtility.SRight(FieldName[cur_index], 4)) == "YEAR")
			{
				return_value = "CellI";
			}
			else if (oUtility.SUCase(oUtility.SLeft(FieldName[cur_index], 1)) == "I" && oUtility.SUCase(oUtility.SRight(FieldName[cur_index], 3)) == "_DT")
            {
				return_value = "CellDT";
			}
			else if (oUtility.SUCase(oUtility.SLeft(FieldName[cur_index], 1)) == "I")
			{
				return_value = "CellI";
			}

			return return_value;
        }

		public bool Swap(int first_line, int second_line, int static_col = -1)
        {
			bool return_value = false;
			int col_num = 0;
			string temp_cell = "";

			try
            {
				if (Data.GetUpperBound(1) < first_line || Data.GetUpperBound(1) < second_line)
                {
					return true;
                }

				for (col_num = 0; col_num < Data.GetLength(1); col_num++)
                {
					if (col_num != static_col)      // Do not change static_col
					{
						temp_cell = Data[col_num, first_line];
						Data[col_num, first_line] = Data[col_num, second_line];
						Data[col_num, second_line] = temp_cell;
					}
				}

				RecreateGridLine(first_line);
				RecreateGridLine(second_line);

				return_value = true;
			}
			catch (Exception ex)
            {
				SetPostingError(ex.Message + " (Swap)");
            }


			return return_value;
		}
	}
}
