﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Dynasty.Database;

namespace Dynasty.ASP.Models
{
    public class clsDashBoard
	{
		public const int DASHBOARD_CUSTOMER_TYPE_NUM = 101;
		public const int DASHBOARD_VENDOR_TYPE_NUM = 102;
		public const int DASHBOARD_BEST_SELLER_TYPE_NUM = 103;
		public const int DASHBOARD_BEST_PROFITOR_TYPE_NUM = 104;
		public const int DASHBOARD_RECEIVABLE_AGING_TYPE_NUM = 105;
		public const int DASHBOARD_PAYABLE_AGING_TYPE_NUM = 106;
		public const int DASHBOARD_RECEIVABLE_FORECAST_TYPE_NUM = 107;
		public const int DASHBOARD_PAYABLE_FORECAST_TYPE_NUM = 108;
		public const int DASHBOARD_PROSPECT_TYPE_NUM = 109;
		public const int DASHBOARD_APPROVAL_TO_MAKE_TYPE_NUM = 110;
		public const int DASHBOARD_APPROVAL_WAITING_TYPE_NUM = 111;
		public const int DASHBOARD_CUSTOMER_SUPPORT_TYPE_NUM = 112;

		public const int DASHBOARD_CODE_NUM = 1;
		public const int DASHBOARD_COL_2_NUM = 2;
		public const int DASHBOARD_COL_3_NUM = 3;
		public const int DASHBOARD_COL_4_NUM = 4;
		public const int DASHBOARD_COL_5_NUM = 5;
		public const int DASHBOARD_COL_6_NUM = 6;
		public const int DASHBOARD_COL_7_NUM = 7;
		public const int DASHBOARD_COL_8_NUM = 8;
		public const int DASHBOARD_COL_9_NUM = 9;
		public const int DASHBOARD_COL_10_NUM = 10;
		public const int DASHBOARD_COL_11_NUM = 11;

		public const int DASHBOARD_DEPTH_NUM = 21;
		public const int DASHBOARD_TYPE_NUM = 22;

		public const int TOTAL_COLUMNS = 50;

        public int iNextLine_id = 1;
        public int iTotalRows = 0;

        public string[,] Data;																		// Keeps the detail data.
		public string[] ColumnCaption;                                                              // List column captions
		public bool[] HideColumn;

		public string sCustomersToContact = "Customers To Contact ( 0 )";
		public string sVendorsToContact = "Vendors To Contact ( 0 )";
		public string sProspectsToContact = "Prospects To Contact ( 0 )";
		public string sCustomerSupport = "Customer Support ( 0 )";

		public string sInvoicesOverDue = "Invoices Overdue ( 0 )";
		public string sReceivableForecast = "Receivable Forecast";
		public string sReceivableAging = "Receivable Aging Report";

		public string sBillsOverDue = "Bills Overdue ( 0 )";
		public string sPayableForecast = "Payable Forecast";
		public string sPayableAging = "Payable Aging Report";

		// public string sApprovalsToMake = "Approvals To Make ( 0 )";
		public string sApprovalsPending = "Approvals Pending ( 0 )";

		public string sOrdersToShip = "Orders To Ship ( 0 )";
		public string sQuotesNotApproved = "Quotes Not Approved ( 0 )";

		public string sBestSellers = "20 Best Selling Items";
		public string sBestProfitors = "20 Most Profitable Items";
		public string sPostingError = "";

		private clsDynastyUtility oUtility = new clsDynastyUtility();
		private static clsInquiry oInquiry = new clsInquiry();

		private bool bUtilizeCheckbox_fl = false;

		public clsDashBoard(bool utilize_checkbox_fl = false)
        {
			oUtility.ResizeDim(ref Data, TOTAL_COLUMNS - 1, 0);
			RecreateGrid();
			bUtilizeCheckbox_fl = utilize_checkbox_fl;
		}

		public bool Clear(int initial_rows = 1)
		{
			bool return_value = false;

			iTotalRows = initial_rows;
			oUtility.ResizeDim(ref Data, TOTAL_COLUMNS - 1, initial_rows - 1);
			RecreateGrid();

			if (initial_rows == 1)
            {
				oUtility.ResizeDim(ref ColumnCaption, 0);
				oUtility.ResizeDim(ref HideColumn, 0);
			}

			return return_value;
		}

		public bool IsErrorFound()
		{
			bool return_value = false;

			return_value = (oUtility.IsNonEmpty(sPostingError));

			return return_value;
		}

		public string GetErrorMessage()
		{
			string return_value = "";

			return_value = sPostingError;
			sPostingError = "";

			return return_value;
		}
		public void SetPostingError(string error_msg)
		{
			if (oUtility.IsEmpty(error_msg))
			{
				sPostingError = "";
			}
			else if (oUtility.IsEmpty(sPostingError))
			{
				sPostingError = error_msg;
			}
			else if (oUtility.STrim(sPostingError) != oUtility.STrim(error_msg))
			{
				sPostingError += Environment.NewLine + Environment.NewLine + "AND " + error_msg;
			}
		}

        public class clsGrid
        {
            public int Row_num = 0;                           // Keeps the row number
            public bool chkExclude_fl = false;				  
            public bool chkInclude_fl = false;
			public string Col_0 = "";
            public string Col_1 = "";
            public string Col_2 = "";
            public string Col_3 = "";
            public string Col_4 = "";
            public string Col_5 = "";
            public string Col_6 = "";
            public string Col_7 = "";
            public string Col_8 = "";
            public string Col_9 = "";
            public string Col_10 = "";
            public string Col_11 = "";
            public string Col_12 = "";
            public string Col_13 = "";
            public string Col_14 = "";
            public string Col_15 = "";
            public string Col_16 = "";
            public string Col_17 = "";
            public string Col_18 = "";
            public string Col_19 = "";
            public string Col_20 = "";
            public string Col_21 = "";
            public string Col_22 = "";
            public string Col_23 = "";
            public string Col_24 = "";
            public string Col_25 = "";
            public string Col_26 = "";
            public string Col_27 = "";
            public string Col_28 = "";
            public string Col_29 = "";
			public string Col_30 = "";
			public string Col_31 = "";
			public string Col_32 = "";
			public string Col_33 = "";
			public string Col_34 = "";
			public string Col_35 = "";
			public string Col_36 = "";
			public string Col_37 = "";
			public string Col_38 = "";
			public string Col_39 = "";
			public string Col_40 = "";
			public string Col_41 = "";
			public string Col_42 = "";
			public string Col_43 = "";
			public string Col_44 = "";
			public string Col_45 = "";
			public string Col_46 = "";
			public string Col_47 = "";
			public string Col_48 = "";
			public string Col_49 = "";

		}
		public List<clsGrid> Grid = new List<clsGrid>();
				
		public bool AddMoreRows(int lines_to_add = 10)
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
                // oUtility.ResizeDimPreserved(ref Data, Data.GetUpperBound(0), Data.GetUpperBound(1) + lines_to_add);

                for (row_num = 0; row_num < lines_to_add; row_num++)
                {
                    Grid.Add(new clsGrid { Row_num = iTotalRows
							, chkInclude_fl = false
							, chkExclude_fl = false
					});

                    iTotalRows += 1;
					iNextLine_id += 1;
				}
                
                RecreateDetail();
                return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (AddMoreRows)");
				RecreateDetail();
            }

            return return_value;
        }

		public bool InsertNewRow(clsGrid cur_item)
		{
			bool return_value = false;
			int old_row_num = cur_item.Row_num;

			try
			{
				Grid.Insert(old_row_num, new clsGrid
				{
					Row_num = -1
				}); 

				Grid.Where(i => i.Row_num >= old_row_num).Select(i => { i.Row_num += 1; return i; }).ToList();
				Grid.Single(i => i.Row_num == -1).Row_num = old_row_num;

				iNextLine_id += 1;
				iTotalRows += 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (InsertNewRow)");
			}

			return return_value;
		}

		public bool DeleteCurrentRow(clsGrid cur_item)
		{
			bool return_value = false;
			int old_num = cur_item.Row_num;

			try
			{
				Grid.RemoveAt(cur_item.Row_num);
				Grid.Where(i => i.Row_num >= old_num).Select(i => { i.Row_num -= 1; return i; }).ToList();

				iTotalRows -= 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (DeleteCurrentRow)");
			}

			return return_value;
		}


		public bool DeleteCurrentRow(int row_num)
		{
			bool return_value = false;
			int old_num = row_num;

			try
			{
				Grid.RemoveAt(row_num);
				Grid.Where(i => i.Row_num >= old_num).Select(i => { i.Row_num -= 1; return i; }).ToList();

				iTotalRows -= 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (DeleteCurrentRow)");
			}

			return return_value;
		}
		public bool RecreateDetail()                                                           //  Sync Data with Grid for the items that do not have event-handler ONLY.
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				if (Grid.Count() == 0)
				{
					oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), 0);
					return true;
				}

				// We need to create it here for saving because some fields may not have been copied into the array.
				//
				iTotalRows = Grid.Count();
				oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), iTotalRows - 1);

				foreach (var det in Grid)
				{
					if (RecreateDetailLine(det, row_num) == false)
					{
						return false;
					}

					det.Row_num = row_num;      // Just to make sure.
					row_num++;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetail)");
			}

			return return_value;
		}

		public bool RecreateGridLine(int row_num)
		{
			bool return_value = false;
			clsGrid grid_line = new clsGrid();

			if (FindGridLine(row_num, ref grid_line) == false)
			{
				SetPostingError("Grid does not match array.");
				return false;
			}

			return RecreateGridLine(ref grid_line, row_num);
		}

		public bool RecreateGridLine(ref clsGrid cur_item, int row_num)
		{
			bool return_value = false;

			try
			{
				cur_item.chkInclude_fl = (GlobalVar.goUtility.ToInteger(Data[0, row_num]) == 1);				
				cur_item.Col_0 = Data[0, row_num];
				cur_item.Col_1 = Data[1, row_num];
				cur_item.Col_2 = Data[2, row_num];
				cur_item.Col_3 = Data[3, row_num];
				cur_item.Col_4 = Data[4, row_num];
				cur_item.Col_5 = Data[5, row_num];
				cur_item.Col_6 = Data[6, row_num];
				cur_item.Col_7 = Data[7, row_num];
				cur_item.Col_8 = Data[8, row_num];
				cur_item.Col_9 = Data[9, row_num];
				cur_item.Col_10 = Data[10, row_num];
				cur_item.Col_11 = Data[11, row_num];
				cur_item.Col_12 = Data[12, row_num];
				cur_item.Col_13 = Data[13, row_num];
				cur_item.Col_14 = Data[14, row_num];
				cur_item.Col_15 = Data[15, row_num];
				cur_item.Col_16 = Data[16, row_num];
				cur_item.Col_17 = Data[17, row_num];
				cur_item.Col_18 = Data[18, row_num];
				cur_item.Col_19 = Data[19, row_num];
				cur_item.Col_20 = Data[20, row_num];
				cur_item.Col_21 = Data[21, row_num];
				cur_item.Col_22 = Data[22, row_num];
				cur_item.Col_23 = Data[23, row_num];
				cur_item.Col_24 = Data[24, row_num];
				cur_item.Col_25 = Data[25, row_num];
				cur_item.Col_26 = Data[26, row_num];
				cur_item.Col_27 = Data[27, row_num];
				cur_item.Col_28 = Data[28, row_num];
				cur_item.Col_29 = Data[29, row_num];
				cur_item.Col_30 = Data[30, row_num];
				cur_item.Col_31 = Data[31, row_num];
				cur_item.Col_32 = Data[32, row_num];
				cur_item.Col_33 = Data[33, row_num];
				cur_item.Col_34 = Data[34, row_num];
				cur_item.Col_35 = Data[35, row_num];
				cur_item.Col_36 = Data[36, row_num];
				cur_item.Col_37 = Data[37, row_num];
				cur_item.Col_38 = Data[38, row_num];
				cur_item.Col_39 = Data[39, row_num];
				cur_item.Col_40 = Data[40, row_num];
				cur_item.Col_41 = Data[41, row_num];
				cur_item.Col_42 = Data[42, row_num];
				cur_item.Col_43 = Data[43, row_num];
				cur_item.Col_44 = Data[44, row_num];
				cur_item.Col_45 = Data[45, row_num];
				cur_item.Col_46 = Data[46, row_num];
				cur_item.Col_47 = Data[47, row_num];
				cur_item.Col_48 = Data[48, row_num];
				cur_item.Col_49 = Data[49, row_num];
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateGridLine)");
			}
			return return_value;

		}

		public bool FindGridLine(int row_num, ref clsGrid line_found)
		{
			bool return_value = false;

			try
			{
				line_found = Grid.Single(i => i.Row_num == row_num);

				if (line_found != null)
				{
					return_value = true;
				}
			}
			catch (Exception ex)
			{
				// in case not found
			}

			return return_value;
		}

		public bool RecreateDetailLine(clsGrid cur_item, int row_num = -1)
		{
			bool return_value = false;

			try
			{
				// If this is called from UI event, get the row number of current line.
				//
				if (row_num < 0)
				{
					row_num = cur_item.Row_num;
				}

				// When bUtilizeCheckbox_fl == true, we sync Data[0, row_num] to  chkInclude_fl
				//
				if (bUtilizeCheckbox_fl)
                {
					Data[0, row_num] = cur_item.chkInclude_fl? "1" : "0";
				}
				else
                {
					Data[0, row_num] = cur_item.Col_0;
				}
				Data[1, row_num] = cur_item.Col_1;
				Data[2, row_num] = cur_item.Col_2;
				Data[3, row_num] = cur_item.Col_3;
				Data[4, row_num] = cur_item.Col_4;
				Data[5, row_num] = cur_item.Col_5;
				Data[6, row_num] = cur_item.Col_6;
				Data[7, row_num] = cur_item.Col_7;
				Data[8, row_num] = cur_item.Col_8;
				Data[9, row_num] = cur_item.Col_9;
				Data[10, row_num] = cur_item.Col_10;
				Data[11, row_num] = cur_item.Col_11;
				Data[12, row_num] = cur_item.Col_12;
				Data[13, row_num] = cur_item.Col_13;
				Data[14, row_num] = cur_item.Col_14;
				Data[15, row_num] = cur_item.Col_15;
				Data[16, row_num] = cur_item.Col_16;
				Data[17, row_num] = cur_item.Col_17;
				Data[18, row_num] = cur_item.Col_18;
				Data[19, row_num] = cur_item.Col_19;
				Data[20, row_num] = cur_item.Col_20;
				Data[21, row_num] = cur_item.Col_21;
				Data[22, row_num] = cur_item.Col_22;
				Data[23, row_num] = cur_item.Col_23;
				Data[24, row_num] = cur_item.Col_24;
				Data[25, row_num] = cur_item.Col_25;
				Data[26, row_num] = cur_item.Col_26;
				Data[27, row_num] = cur_item.Col_27;
				Data[28, row_num] = cur_item.Col_28;
				Data[29, row_num] = cur_item.Col_29;
				Data[30, row_num] = cur_item.Col_30;
				Data[31, row_num] = cur_item.Col_31;
				Data[32, row_num] = cur_item.Col_32;
				Data[33, row_num] = cur_item.Col_33;
				Data[34, row_num] = cur_item.Col_34;
				Data[35, row_num] = cur_item.Col_35;
				Data[36, row_num] = cur_item.Col_36;
				Data[37, row_num] = cur_item.Col_37;
				Data[38, row_num] = cur_item.Col_38;
				Data[39, row_num] = cur_item.Col_39;
				Data[40, row_num] = cur_item.Col_40;
				Data[41, row_num] = cur_item.Col_41;
				Data[42, row_num] = cur_item.Col_42;
				Data[43, row_num] = cur_item.Col_43;
				Data[44, row_num] = cur_item.Col_44;
				Data[45, row_num] = cur_item.Col_45;
				Data[46, row_num] = cur_item.Col_46;
				Data[47, row_num] = cur_item.Col_47;
				Data[48, row_num] = cur_item.Col_48;
				Data[49, row_num] = cur_item.Col_49;

				return_value = true;

			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetailLine)");
			}

			return return_value;
		}

		public bool RecreateGrid()                                                             //  Create Grid according to Data
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				Grid.Clear();

				if (Data == null)
				{
					return true;
				}
				else if (Data.GetLength(1) == 0)
				{
					return true;
				}

				iTotalRows = Data.GetLength(1);

				for (row_num = 0; row_num < iTotalRows; row_num++)
				{
					Grid.Add(new clsGrid
					{
						Row_num = row_num
						,chkExclude_fl = false
						,chkInclude_fl = (GlobalVar.goUtility.ToInteger(Data[0, row_num]) == 1)
						,Col_0 = Data[0, row_num]
						,Col_1 = Data[1, row_num]
						,Col_2 = Data[2, row_num]
						,Col_3 = Data[3, row_num]
						,Col_4 = Data[4, row_num]
						,Col_5 = Data[5, row_num]
						,Col_6 = Data[6, row_num]
						,Col_7 = Data[7, row_num]
						,Col_8 = Data[8, row_num]
						,Col_9 = Data[9, row_num]
						,Col_10 = Data[10, row_num]
						,Col_11 = Data[11, row_num]
						,Col_12 = Data[12, row_num]
						,Col_13 = Data[13, row_num]
						,Col_14 = Data[14, row_num]
						,Col_15 = Data[15, row_num]
						,Col_16 = Data[16, row_num]
						,Col_17 = Data[17, row_num]
						,Col_18 = Data[18, row_num]
						,Col_19 = Data[19, row_num]
						,Col_20 = Data[20, row_num]
						,Col_21 = Data[21, row_num]
						,Col_22 = Data[22, row_num]
						,Col_23 = Data[23, row_num]
						,Col_24 = Data[24, row_num]
						,Col_25 = Data[25, row_num]
						,Col_26 = Data[26, row_num]
						,Col_27 = Data[27, row_num]
						,Col_28 = Data[28, row_num]
						,Col_29 = Data[29, row_num]
						,Col_30 = Data[30, row_num]
						,Col_31 = Data[31, row_num]
						,Col_32 = Data[32, row_num]
						,Col_33 = Data[33, row_num]
						,Col_34 = Data[34, row_num]
						,Col_35 = Data[35, row_num]
						,Col_36 = Data[36, row_num]
						,Col_37 = Data[37, row_num]
						,Col_38 = Data[38, row_num]
						,Col_39 = Data[39, row_num]
						,Col_40 = Data[40, row_num]
						,Col_41 = Data[41, row_num]
						,Col_42 = Data[42, row_num]
						,Col_43 = Data[43, row_num]
						,Col_44 = Data[44, row_num]
						,Col_45 = Data[45, row_num]
						,Col_46 = Data[46, row_num]
						,Col_47 = Data[47, row_num]
						,Col_48 = Data[48, row_num]
						,Col_49 = Data[49, row_num]
					});
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateGrid)");
			}

			return return_value;
		}

		public bool SetCellValue(int col_num, int row_num, string new_value)
        {
			bool return_value = false;

			try
            {
				switch (col_num)
                {
					case 0:
						Grid.Single(i => i.Row_num == row_num).Col_0 = new_value;
						break;
					case 1:
						Grid.Single(i => i.Row_num == row_num).Col_1 = new_value;
						break;
					case 2:
						Grid.Single(i => i.Row_num == row_num).Col_2 = new_value;
						break;
					case 3:
						Grid.Single(i => i.Row_num == row_num).Col_3 = new_value;
						break;
					case 4:
						Grid.Single(i => i.Row_num == row_num).Col_4 = new_value;
						break;
					case 5:
						Grid.Single(i => i.Row_num == row_num).Col_5 = new_value;
						break;
					case 6:
						Grid.Single(i => i.Row_num == row_num).Col_6 = new_value;
						break;
					case 7:
						Grid.Single(i => i.Row_num == row_num).Col_7 = new_value;
						break;
					case 8:
						Grid.Single(i => i.Row_num == row_num).Col_8 = new_value;
						break;
					case 9:
						Grid.Single(i => i.Row_num == row_num).Col_9 = new_value;
						break;
					case 10:
						Grid.Single(i => i.Row_num == row_num).Col_10 = new_value;
						break;
					case 11:
						Grid.Single(i => i.Row_num == row_num).Col_11 = new_value;
						break;
					case 12:
						Grid.Single(i => i.Row_num == row_num).Col_12 = new_value;
						break;
					case 13:
						Grid.Single(i => i.Row_num == row_num).Col_13 = new_value;
						break;
					case 14:
						Grid.Single(i => i.Row_num == row_num).Col_14 = new_value;
						break;
					case 15:
						Grid.Single(i => i.Row_num == row_num).Col_15 = new_value;
						break;
					case 16:
						Grid.Single(i => i.Row_num == row_num).Col_16 = new_value;
						break;
					case 17:
						Grid.Single(i => i.Row_num == row_num).Col_17 = new_value;
						break;
					case 18:
						Grid.Single(i => i.Row_num == row_num).Col_18 = new_value;
						break;
					case 19:
						Grid.Single(i => i.Row_num == row_num).Col_19 = new_value;
						break;
					case 20:
						Grid.Single(i => i.Row_num == row_num).Col_20 = new_value;
						break;
					case 21:
						Grid.Single(i => i.Row_num == row_num).Col_21 = new_value;
						break;
					case 22:
						Grid.Single(i => i.Row_num == row_num).Col_22 = new_value;
						break;
					case 23:
						Grid.Single(i => i.Row_num == row_num).Col_23 = new_value;
						break;
					case 24:
						Grid.Single(i => i.Row_num == row_num).Col_24 = new_value;
						break;
					case 25:
						Grid.Single(i => i.Row_num == row_num).Col_25 = new_value;
						break;
					case 26:
						Grid.Single(i => i.Row_num == row_num).Col_26 = new_value;
						break;
					case 27:
						Grid.Single(i => i.Row_num == row_num).Col_27 = new_value;
						break;
					case 28:
						Grid.Single(i => i.Row_num == row_num).Col_28 = new_value;
						break;
					case 29:
						Grid.Single(i => i.Row_num == row_num).Col_29 = new_value;
						break;
					case 30:
						Grid.Single(i => i.Row_num == row_num).Col_30 = new_value;
						break;
					case 31:
						Grid.Single(i => i.Row_num == row_num).Col_31 = new_value;
						break;
					case 32:
						Grid.Single(i => i.Row_num == row_num).Col_32 = new_value;
						break;
					case 33:
						Grid.Single(i => i.Row_num == row_num).Col_33 = new_value;
						break;
					case 34:
						Grid.Single(i => i.Row_num == row_num).Col_34 = new_value;
						break;
					case 35:
						Grid.Single(i => i.Row_num == row_num).Col_35 = new_value;
						break;
					case 36:
						Grid.Single(i => i.Row_num == row_num).Col_36 = new_value;
						break;
					case 37:
						Grid.Single(i => i.Row_num == row_num).Col_37 = new_value;
						break;
					case 38:
						Grid.Single(i => i.Row_num == row_num).Col_38 = new_value;
						break;
					case 39:
						Grid.Single(i => i.Row_num == row_num).Col_39 = new_value;
						break;
					case 40:
						Grid.Single(i => i.Row_num == row_num).Col_40 = new_value;
						break;
					case 41:
						Grid.Single(i => i.Row_num == row_num).Col_41 = new_value;
						break;
					case 42:
						Grid.Single(i => i.Row_num == row_num).Col_42 = new_value;
						break;
					case 43:
						Grid.Single(i => i.Row_num == row_num).Col_43 = new_value;
						break;
					case 44:
						Grid.Single(i => i.Row_num == row_num).Col_44 = new_value;
						break;
					case 45:
						Grid.Single(i => i.Row_num == row_num).Col_45 = new_value;
						break;
					case 46:
						Grid.Single(i => i.Row_num == row_num).Col_46 = new_value;
						break;
					case 47:
						Grid.Single(i => i.Row_num == row_num).Col_47 = new_value;
						break;
					case 48:
						Grid.Single(i => i.Row_num == row_num).Col_48 = new_value;
						break;
					case 49:
						Grid.Single(i => i.Row_num == row_num).Col_49 = new_value;
						break;
					default:
						break;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (SetCellValue)");
			}

			return return_value;
		}

		public int InvoicesOverDue(ref clsDatabase cur_db, int cur_date, bool get_count_only)
		{
			int return_value = 0;
			string sql_str = "";
			int row_num = 0;

			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{
				Clear();

				if (get_count_only == false)
				{
					oUtility.ResizeDim(ref ColumnCaption, DASHBOARD_COL_7_NUM);
					oUtility.ResizeDim(ref HideColumn, DASHBOARD_COL_7_NUM);

					ColumnCaption[DASHBOARD_CODE_NUM] = "Invoice Num";
					ColumnCaption[DASHBOARD_COL_2_NUM] = "Invoice Date";
					ColumnCaption[DASHBOARD_COL_3_NUM] = "Due Date";
					ColumnCaption[DASHBOARD_COL_4_NUM] = "Amount Due";
					ColumnCaption[DASHBOARD_COL_5_NUM] = "Customer Code";
					ColumnCaption[DASHBOARD_COL_6_NUM] = "Name";
					ColumnCaption[DASHBOARD_COL_7_NUM] = "Comment";
				}

				sql_str = "SELECT * FROM tblARCharge WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_INVOICE_TYPE.ToString();
				sql_str += " AND iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM.ToString();
				sql_str += " AND iDue_dt <= " + cur_date.ToString();
				sql_str += " AND mDue_amt <> 0"; // 06/19/2018 Negative voucher/invoice is implemented

				if (GlobalVar.goUtility.IsSalesStaff(cur_db))
				{
					sql_str += " AND sSalesrep_cd = '" + cur_db.sUser_cd + "'";
				}

				sql_str += " ORDER BY iDue_dt";

				if (cur_set.CreateSnapshot(sql_str) == false)
				{
					return 0;
				}
				else if (cur_set.RecordCount() == 0)
				{
					return 0;
				}
				else if (get_count_only)
				{
					return_value = cur_set.RecordCount();
					return return_value;
				}

				row_num = 0;
				iTotalRows = cur_set.RecordCount();
				oUtility.ResizeDim(ref Data, TOTAL_COLUMNS, iTotalRows - 1);

				while (cur_set.EOF() == false)
				{
					Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
					Data[DASHBOARD_TYPE_NUM, row_num] = GlobalVar.goConstant.TRX_INVOICE_TYPE.ToString();
					Data[DASHBOARD_CODE_NUM, row_num] = cur_set.iField("iTransaction_num").ToString();
					Data[DASHBOARD_COL_2_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iApply_dt"));
					Data[DASHBOARD_COL_3_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iDue_dt"));
					Data[DASHBOARD_COL_4_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
					Data[DASHBOARD_COL_5_NUM, row_num] = cur_set.sField("sCustomer_cd");
					Data[DASHBOARD_COL_6_NUM, row_num] = cur_set.sField("sCustomer_nm");
					Data[DASHBOARD_COL_7_NUM, row_num] = cur_set.sField("sComment");

					cur_set.MoveNext();
					row_num += 1;
				}

				RecreateGrid();
				return_value = cur_set.RecordCount();

				return cur_set.RecordCount();
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(InvoicesOverDue)");
			}

			return return_value;
		}


        public int BillsOverDue(ref clsDatabase cur_db, int cur_date, bool get_count_only)
        {
            int return_value = 0;
            clsGeneral o_gen = new clsGeneral(ref cur_db);
            clsMoney o_money = new clsMoney(ref cur_db);
            clsRecordset cur_set = new clsRecordset(ref cur_db);
            string sql_str = "";
            int row_num = 0;

            try
            {
				Clear();

                if (get_count_only == false)
                {
					oUtility.ResizeDim(ref ColumnCaption, DASHBOARD_COL_8_NUM);
					oUtility.ResizeDim(ref HideColumn, DASHBOARD_COL_8_NUM);

					ColumnCaption[DASHBOARD_CODE_NUM] = "Voucher Num";
                    ColumnCaption[DASHBOARD_COL_2_NUM] = "Invoice Date";
                    ColumnCaption[DASHBOARD_COL_3_NUM] = "Due Date";
                    ColumnCaption[DASHBOARD_COL_4_NUM] = "Amount Due";
                    ColumnCaption[DASHBOARD_COL_5_NUM] = "Invoice Num";
                    ColumnCaption[DASHBOARD_COL_6_NUM] = "Vendor Code";
                    ColumnCaption[DASHBOARD_COL_7_NUM] = "Name";
                    ColumnCaption[DASHBOARD_COL_8_NUM] = "Comment";
                }

                sql_str = "SELECT * FROM tblAPCharge WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_PURCHASE_TYPE.ToString();
                sql_str += " AND iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM.ToString();
                sql_str += " AND iDue_dt <= " + cur_date.ToString();
                sql_str += " AND mDue_amt <> 0 "; // 06/19/2018 Negative voucher is implemented
                sql_str += " ORDER BY iDue_dt";

                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    return 0;
                }
                else if (cur_set.RecordCount() == 0)
                {
                    cur_set.Release();
                    return 0;
                }
                else if (get_count_only)
                {
                    return_value = cur_set.RecordCount();
                    cur_set.Release();
                    return return_value;
                }

				row_num = 0;
				iTotalRows = cur_set.RecordCount();
				oUtility.ResizeDim(ref Data, TOTAL_COLUMNS, iTotalRows - 1);

				while (cur_set.EOF() == false)
                {
                    Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
                    Data[DASHBOARD_TYPE_NUM, row_num] = GlobalVar.goConstant.TRX_PURCHASE_TYPE.ToString();
                    Data[DASHBOARD_CODE_NUM, row_num] = cur_set.iField("iTransaction_num").ToString();
                    Data[DASHBOARD_COL_2_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iInvoice_dt"));
                    Data[DASHBOARD_COL_3_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iDue_dt"));
                    Data[DASHBOARD_COL_4_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
                    Data[DASHBOARD_COL_5_NUM, row_num] = cur_set.sField("sYourReference");
                    Data[DASHBOARD_COL_6_NUM, row_num] = cur_set.sField("sVendor_cd");
                    Data[DASHBOARD_COL_7_NUM, row_num] = cur_set.sField("sVendor_nm");
                    Data[DASHBOARD_COL_8_NUM, row_num] = cur_set.sField("sComment");

                    cur_set.MoveNext();
					row_num += 1;
				}

				RecreateGrid();
                return_value = cur_set.RecordCount();
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(BillsOverDue)");
            }

			return return_value;

		}


        public int OrdersToShip(ref clsDatabase cur_db, int cur_date, bool get_count_only)
        {
            int return_value = 0;
            string sql_str = "";
            int row_num = 0;

			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{
				Clear();

                if (get_count_only == false)
                {
					oUtility.ResizeDim(ref ColumnCaption, DASHBOARD_COL_7_NUM);
					oUtility.ResizeDim(ref HideColumn, DASHBOARD_COL_7_NUM);

					ColumnCaption[DASHBOARD_CODE_NUM] = "Order Num";
                    ColumnCaption[DASHBOARD_COL_2_NUM] = "Date Ordered";
                    ColumnCaption[DASHBOARD_COL_3_NUM] = "Date Required";
                    ColumnCaption[DASHBOARD_COL_4_NUM] = "Date Shipped";
                    ColumnCaption[DASHBOARD_COL_5_NUM] = "Customer Code";
                    ColumnCaption[DASHBOARD_COL_6_NUM] = "Name";
                    ColumnCaption[DASHBOARD_COL_7_NUM] = "Comment";
                }

                sql_str = "SELECT * FROM tblSOTransaction WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_SO_TYPE.ToString();
                sql_str += " AND iStatus_typ = " + GlobalVar.goConstant.OPEN_TRX_NUM.ToString();
                sql_str += " AND ((iRequired_dt <= " + cur_date.ToString() + ") OR ((iShipped_dt > 0) AND (iShipped_dt<=" + cur_date.ToString() + ")))";
                sql_str += " AND iTransaction_num IN (SELECT iTransaction_num FROM tblSOTransactionDet";
                sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_SO_TYPE.ToString();
				sql_str += " AND fBackorder_qty > 0)";

				if (GlobalVar.goUtility.IsSalesStaff(cur_db))
				{
					sql_str += " AND sSalesrep_cd = '" + cur_db.sUser_cd + "'";
				}

				sql_str += " ORDER BY iTransaction_num";

				if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    return_value = 0;
                    return 0;
                }
                else if (cur_set.RecordCount() == 0)
                {
                    cur_set.Release();
                    return 0;
                }
                else if (get_count_only)
                {
                    return_value = cur_set.RecordCount();
                    cur_set.Release();
                    return return_value;
                }

				row_num = 0;
				iTotalRows = cur_set.RecordCount();
				oUtility.ResizeDim(ref Data, TOTAL_COLUMNS, iTotalRows - 1);

				while (cur_set.EOF() == false)
                {
                    Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
                    Data[DASHBOARD_TYPE_NUM, row_num] = GlobalVar.goConstant.TRX_SO_TYPE.ToString();
                    Data[DASHBOARD_CODE_NUM, row_num] = cur_set.iField("iTransaction_num").ToString();
                    Data[DASHBOARD_COL_2_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iApply_dt"));
                    Data[DASHBOARD_COL_3_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iRequired_dt"));
                    Data[DASHBOARD_COL_4_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iShipped_dt"));
                    Data[DASHBOARD_COL_5_NUM, row_num] = cur_set.sField("sCustomer_cd");
                    Data[DASHBOARD_COL_6_NUM, row_num] = cur_set.sField("sCustomer_nm");
                    Data[DASHBOARD_COL_7_NUM, row_num] = cur_set.sField("sComment");

					cur_set.MoveNext();
					row_num += 1;
				}

				RecreateGrid();
				return_value = cur_set.RecordCount();
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(OrdersToShip)");
            }

			return return_value;
		}

        public int QuotesNotApproved(ref clsDatabase cur_db, int cur_date, bool get_count_only)
        {
            int return_value = 0;
            string sql_str = "";
            int row_num = 0;

            clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{
				Clear();

                if (get_count_only == false)
                {
					oUtility.ResizeDim(ref ColumnCaption, DASHBOARD_COL_7_NUM);
					oUtility.ResizeDim(ref HideColumn, DASHBOARD_COL_7_NUM);

					ColumnCaption[DASHBOARD_CODE_NUM] = "Quote Num";
                    ColumnCaption[DASHBOARD_COL_2_NUM] = "Date Quoated";
                    ColumnCaption[DASHBOARD_COL_3_NUM] = "Date Required";
                    ColumnCaption[DASHBOARD_COL_4_NUM] = "Customer Code";
                    ColumnCaption[DASHBOARD_COL_5_NUM] = "Name";
                    ColumnCaption[DASHBOARD_COL_6_NUM] = "Amount Quoated";
                    ColumnCaption[DASHBOARD_COL_7_NUM] = "Comment";
                }

                sql_str = "SELECT * FROM tblSOTransaction WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_QUOTE_TYPE.ToString();
                sql_str += " AND iStatus_typ <= " + GlobalVar.goConstant.HOLD_TRX_NUM.ToString();

				if (GlobalVar.goUtility.IsSalesStaff(cur_db))
				{
					sql_str += " AND sSalesrep_cd = '" + cur_db.sUser_cd + "'";
				}

				sql_str += " ORDER BY iTransaction_num";

				if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    return_value = 0;
                    return return_value;
                }
                else if (cur_set.RecordCount() == 0)
                {
                    cur_set.Release();
                    return_value = 0;
                    return return_value;
                }
                else if (get_count_only)
                {
                    return_value = cur_set.RecordCount();
                    cur_set.Release();
                    return return_value;
                }

				row_num = 0;
				iTotalRows = cur_set.RecordCount();
				oUtility.ResizeDim(ref Data, TOTAL_COLUMNS, iTotalRows - 1);

				while (cur_set.EOF() == false)
                {
                    Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
                    Data[DASHBOARD_TYPE_NUM, row_num] = GlobalVar.goConstant.TRX_QUOTE_TYPE.ToString();
                    Data[DASHBOARD_CODE_NUM, row_num] = cur_set.iField("iTransaction_num").ToString();
                    Data[DASHBOARD_COL_2_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iEntry_dt"));
                    Data[DASHBOARD_COL_3_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iRequired_dt"));
                    Data[DASHBOARD_COL_4_NUM, row_num] = cur_set.sField("sCustomer_cd");
                    Data[DASHBOARD_COL_5_NUM, row_num] = cur_set.sField("sCustomer_nm");
                    Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mTotal_amt"));
                    Data[DASHBOARD_COL_7_NUM, row_num] = cur_set.sField("sComment");

					cur_set.MoveNext();
					row_num += 1;
				}

				RecreateGrid();
				return_value = cur_set.RecordCount();
			}
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(QuotesNotApproved)");
            }

            return return_value;
		}

        public int BestSellers(ref clsDatabase cur_db, int cur_date)
        {
            int return_value = 0;
            string sql_str = "";
            int row_num = 0;

			clsMoney o_money = new clsMoney(ref cur_db);
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{
				Clear();
				oUtility.ResizeDim(ref ColumnCaption, DASHBOARD_COL_7_NUM);
				oUtility.ResizeDim(ref HideColumn, DASHBOARD_COL_7_NUM);

				ColumnCaption[DASHBOARD_CODE_NUM] = "Item Code";
                ColumnCaption[DASHBOARD_COL_2_NUM] = "Description";
                ColumnCaption[DASHBOARD_COL_3_NUM] = "Amount Sold";
                ColumnCaption[DASHBOARD_COL_4_NUM] = "Qty Sold";
                ColumnCaption[DASHBOARD_COL_5_NUM] = "CGS";
                ColumnCaption[DASHBOARD_COL_6_NUM] = "Profit";
                ColumnCaption[DASHBOARD_COL_7_NUM] = "Margin(%)";

                sql_str = "SELECT b.sItem_cd AS sItemCode, i.sDescription AS sDesc, (mSales_amt - mSalesReturn_amt) AS mNetSold, (fSales_qty - fSalesReturn_qty) AS fNetQty";
                sql_str += ",mCGS_amt, (mSales_amt - mSalesReturn_amt - mCGS_amt) AS mProfit, sFiscalYear";
                sql_str += " FROM tblIVBalance b INNER JOIN tblIVItem i ON b.sItem_cd=i.sItem_cd";
                sql_str += " WHERE b.sFiscalYear = '" + GlobalVar.goUtility.GetYear(cur_date) + "'";
                sql_str += " AND i.iItem_typ IN (" + oUtility.InventoryItemTypeList() + ")";
                sql_str += " AND iQuarter = 0";
                sql_str += " AND sLocation_cd='" + GlobalVar.goConstant.FOR_ALL + "'";
                sql_str += " ORDER BY (fSales_qty - fSalesReturn_qty) DESC";

                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    return_value = 0;
                    return return_value;
                }
                else if (cur_set.RecordCount() == 0)
                {
                    cur_set.Release();
                    return_value = 0;
                    return return_value;
                }

				if (cur_set.RecordCount() < 20)
                {
					iTotalRows = cur_set.RecordCount();
				}
				else
                {
					iTotalRows = 20;
				}

				oUtility.ResizeDim(ref Data, TOTAL_COLUMNS, iTotalRows - 1);
				row_num = 0;

				while ((cur_set.EOF() == false) && (row_num < iTotalRows))
                {
                    Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
                    Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_BEST_SELLER_TYPE_NUM.ToString();
                    Data[DASHBOARD_CODE_NUM, row_num] = cur_set.sField("sItemCode");
                    Data[DASHBOARD_COL_2_NUM, row_num] = cur_set.sField("sDesc");
                    Data[DASHBOARD_COL_3_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mNetSold"));
                    Data[DASHBOARD_COL_4_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("fNetQty"));
                    Data[DASHBOARD_COL_5_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mCGS_amt"));
                    Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mProfit"));
                    if (cur_set.mField("mNetSold") > 0)
                    {
                        Data[DASHBOARD_COL_7_NUM, row_num] = Math.Round(100 * cur_set.mField("mProfit") / cur_set.mField("mNetSold"), 2).ToString() + "%";
                    }
                    else
                    {
                        Data[DASHBOARD_COL_7_NUM, row_num] = "n/a";
                    }

                    cur_set.MoveNext();
                    row_num += 1;

                }

				RecreateGrid();
				return_value = cur_set.RecordCount();
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(BestSellers)");
            }

            return return_value;
		}

        public int BestProfitors(ref clsDatabase cur_db, int cur_date)
        {
            int return_value = 0;
            string sql_str = "";
            int row_num = 0;

			clsMoney o_money = new clsMoney(ref cur_db);
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{
				Clear();
				oUtility.ResizeDim(ref ColumnCaption, DASHBOARD_COL_7_NUM);
				oUtility.ResizeDim(ref HideColumn, DASHBOARD_COL_7_NUM);

				ColumnCaption[DASHBOARD_CODE_NUM] = "Item Code";
                ColumnCaption[DASHBOARD_COL_2_NUM] = "Description";
                ColumnCaption[DASHBOARD_COL_3_NUM] = "Profit";
                ColumnCaption[DASHBOARD_COL_4_NUM] = "Amount Sold";
                ColumnCaption[DASHBOARD_COL_5_NUM] = "Qty Sold";
                ColumnCaption[DASHBOARD_COL_6_NUM] = "CGS";
                ColumnCaption[DASHBOARD_COL_7_NUM] = "Margin(%)";

                sql_str = "SELECT b.sItem_cd AS sItemCode, i.sDescription AS sDesc, (mSales_amt - mSalesReturn_amt) AS mNetSold, (fSales_qty - fSalesReturn_qty) AS fNetQty";
                sql_str += ",mCGS_amt, (mSales_amt - mSalesReturn_amt - mCGS_amt) AS mProfit, sFiscalYear";
                sql_str += " FROM tblIVBalance b INNER JOIN tblIVItem i ON b.sItem_cd=i.sItem_cd";
                sql_str += " WHERE b.sFiscalYear = '" + GlobalVar.goUtility.GetYear(cur_date) + "'";
                sql_str += " AND i.iItem_typ IN (" + oUtility.InventoryItemTypeList() + ")";
				sql_str += " AND iQuarter = 0";
                sql_str += " AND sLocation_cd = '" + GlobalVar.goConstant.FOR_ALL + "'";
                sql_str += " ORDER BY (mSales_amt - mSalesReturn_amt - mCGS_amt) DESC";

                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    return_value = 0;
                    return return_value;
                }
                else if (cur_set.RecordCount() == 0)
                {
                    cur_set.Release();
                    return_value = 0;
                    return return_value;
                }

				if (cur_set.RecordCount() < 20)
				{
					iTotalRows = cur_set.RecordCount();
				}
				else
				{
					iTotalRows = 20;
				}

				oUtility.ResizeDim(ref Data, TOTAL_COLUMNS, iTotalRows - 1);
				row_num = 0;

				while ((cur_set.EOF() == false) && (row_num < 20))
                {
                    Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
                    Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_BEST_PROFITOR_TYPE_NUM.ToString();
                    Data[DASHBOARD_CODE_NUM, row_num] = cur_set.sField("sItemCode");
                    Data[DASHBOARD_COL_2_NUM, row_num] = cur_set.sField("sDesc");
                    Data[DASHBOARD_COL_3_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mProfit"));
                    Data[DASHBOARD_COL_4_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mNetSold"));
                    Data[DASHBOARD_COL_5_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("fNetQty"));
                    Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mCGS_amt"));
                    if (cur_set.mField("mNetSold") > 0)
                    {
                        Data[DASHBOARD_COL_7_NUM, row_num] = Math.Round(100 * cur_set.mField("mProfit") / cur_set.mField("mNetSold"), 2).ToString() + "%";
                    }
                    else
                    {
                        Data[DASHBOARD_COL_7_NUM, row_num] = "n/a";
                    }

                    cur_set.MoveNext();
                    row_num += 1;
                }

				RecreateGrid();
                return_value = cur_set.RecordCount();
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(BestProfitors)");
            }

            return return_value;
		}

        public int ApprovalsPending(ref clsDatabase cur_db, int cur_date, bool get_count_only)
        {
            int return_value = 0;
            int row_num = 0;
            string sql_str = "";
            string trx_type = null;

			clsMoney o_money = new clsMoney(ref cur_db);
			clsApproval o_approval = new clsApproval(ref cur_db);
			clsGeneral o_general = new clsGeneral(ref cur_db);
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{
				Clear();

				if (get_count_only == false)
                {
					oUtility.ResizeDim(ref ColumnCaption, DASHBOARD_COL_6_NUM);
					oUtility.ResizeDim(ref HideColumn, DASHBOARD_COL_6_NUM);

					ColumnCaption[DASHBOARD_CODE_NUM] = "Transaction Num";
                    ColumnCaption[DASHBOARD_COL_2_NUM] = "Transaction Type";
                    ColumnCaption[DASHBOARD_COL_3_NUM] = "Transaction Amount";
                    ColumnCaption[DASHBOARD_COL_4_NUM] = "Discount Amount";
                    ColumnCaption[DASHBOARD_COL_5_NUM] = "Discount %";
                    ColumnCaption[DASHBOARD_COL_6_NUM] = "Date Created";
                }

                sql_str = "SELECT * FROM tblGOApprovalStatus WHERE iApprovalStatus_typ = " + clsApproval.APPROVAL_REQUESTED_TYPE_NUM;
                sql_str += " AND sLastUpdate_id = '" + cur_db.sUser_cd + "'";

                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    return 0;
                }
                else if (cur_set.RecordCount() == 0 || get_count_only)
                {
                    return_value = cur_set.RecordCount();
                    return return_value;
                }

				iTotalRows = cur_set.RecordCount();
				oUtility.ResizeDim(ref Data, TOTAL_COLUMNS, iTotalRows - 1);
				row_num = 0;

				while (cur_set.EOF() == false)
                {
                    if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_JOURNAL_TYPE)
                    {
                        trx_type = cur_db.oLanguage.oString.STR_JOURNAL;
                    }
                    else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_INVOICE_TYPE)
                    {
                        trx_type = cur_db.oLanguage.oString.STR_INVOICE;
                    }
					else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_CM_TYPE)
					{
						trx_type = cur_db.oLanguage.oString.STR_CREDIT_MEMO;
					}
					else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_RECEIPT_TYPE)
					{
						trx_type = cur_db.oLanguage.oString.STR_CASH_RECEIPT;
					}
					else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_SO_TYPE)
                    {
                        trx_type = cur_db.oLanguage.oString.STR_ORDER;
                    }
                    else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_QUOTE_TYPE)
                    {
                        trx_type = cur_db.oLanguage.oString.STR_QUOTE;
                    }
                    else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_PURCHASE_TYPE)
                    {
                        trx_type = cur_db.oLanguage.oString.STR_VOUCHER;
                    }
					else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_DM_TYPE)
					{
						trx_type = cur_db.oLanguage.oString.STR_DEBIT_MEMO;
					}
					else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_PAYMENT_TYPE)
					{
						trx_type = cur_db.oLanguage.oString.STR_CASH_PAYMENT;
					}
					else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_PO_TYPE)
                    {
                        trx_type = cur_db.oLanguage.oString.STR_PURCHASE_ORDER;
                    }
					else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE)
					{
						trx_type = cur_db.oLanguage.oString.STR_PURCHASE_REQUISITION;
					}
					else
					{
                        trx_type = cur_db.oLanguage.oString.STR_NA;
                    }

                    Data[DASHBOARD_DEPTH_NUM, row_num] = DASHBOARD_APPROVAL_WAITING_TYPE_NUM.ToString();
                    Data[DASHBOARD_TYPE_NUM, row_num] = cur_set.iField("iTransaction_typ").ToString();
                    Data[DASHBOARD_CODE_NUM, row_num] = cur_set.iField("iTransaction_num").ToString();
                    Data[DASHBOARD_COL_2_NUM, row_num] = trx_type;
                    Data[DASHBOARD_COL_3_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mTransaction_amt"));
                    Data[DASHBOARD_COL_4_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDiscount_amt"));
                    Data[DASHBOARD_COL_5_NUM, row_num] = GlobalVar.goUtility.RoundToDiscountPerc(cur_set.mField("fDiscount_pc")).ToString();
                    Data[DASHBOARD_COL_6_NUM, row_num] = o_general.ToStrDate(GlobalVar.goUtility.ToInteger(GlobalVar.goUtility.SFormat(cur_set.dtField("dtLastUpdate_dt"), "yyyyMMdd")));

					cur_set.MoveNext();
					row_num += 1;
				}

				RecreateGrid();
				return_value = cur_set.RecordCount();

			}
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ApprovalsPending)");
            }

			return return_value;
		}

		public int CustomersToContact(ref clsDatabase cur_db, int cur_date, bool get_count_only)
		{
			int return_value = 0;
			string sql_str = "";
			int row_num = 0;

			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{
				Clear();

				if (get_count_only == false)
				{
					oUtility.ResizeDim(ref ColumnCaption, DASHBOARD_COL_7_NUM);
					oUtility.ResizeDim(ref HideColumn, DASHBOARD_COL_7_NUM);

					ColumnCaption[DASHBOARD_CODE_NUM] = "Customer Code";
					ColumnCaption[DASHBOARD_COL_2_NUM] = "Contact Time";
					ColumnCaption[DASHBOARD_COL_3_NUM] = "Customer Name";
					ColumnCaption[DASHBOARD_COL_4_NUM] = "Contact Name";
					ColumnCaption[DASHBOARD_COL_5_NUM] = "Contact Phone";
					ColumnCaption[DASHBOARD_COL_6_NUM] = "Email Address";
					ColumnCaption[DASHBOARD_COL_7_NUM] = "Next Remark";
				}

				sql_str = "SELECT * FROM tblARCustomer";
				sql_str += " WHERE iNext_dt = " + cur_date.ToString();

				if (GlobalVar.goUtility.IsSalesStaff(cur_db))
                {
					sql_str += " AND sSalesrep_cd = '" + cur_db.sUser_cd + "'";
				}

				sql_str += " ORDER BY sNextTime";

				if (cur_set.CreateSnapshot(sql_str) == false)
				{
					return 0;
				}
				else if (cur_set.RecordCount() == 0)
				{
					return 0;
				}
				else if (get_count_only)
				{
					return_value = cur_set.RecordCount();
					return return_value;
				}

				iTotalRows = cur_set.RecordCount();
				oUtility.ResizeDim(ref Data, TOTAL_COLUMNS, iTotalRows - 1);
				row_num = 0;

				while (cur_set.EOF() == false)
				{
					Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
					Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_CUSTOMER_TYPE_NUM.ToString();
					Data[DASHBOARD_CODE_NUM, row_num] = cur_set.sField("sCustomer_cd");
					Data[DASHBOARD_COL_2_NUM, row_num] = cur_set.sField("sNextTime");
					Data[DASHBOARD_COL_3_NUM, row_num] = cur_set.sField("sCustomer_nm");
					Data[DASHBOARD_COL_4_NUM, row_num] = cur_set.sField("sContact_nm");
					Data[DASHBOARD_COL_5_NUM, row_num] = cur_set.sField("sContactPhone");
					Data[DASHBOARD_COL_6_NUM, row_num] = cur_set.sField("sEmailAddress");
					Data[DASHBOARD_COL_7_NUM, row_num] = cur_set.sField("sNextRemark");

					cur_set.MoveNext();
					row_num += 1;
				}

				RecreateGrid();
				return_value = cur_set.RecordCount();
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CustomersToContact)");
			}

			return return_value;
		}

		public int ProspectsToContact(ref clsDatabase cur_db, int cur_date, bool get_count_only)
		{
			int return_value = 0;
			string sql_str = "";
			int row_num = 0;

			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{
				Clear();

				if (get_count_only == false)
				{
					oUtility.ResizeDim(ref ColumnCaption, DASHBOARD_COL_7_NUM);
					oUtility.ResizeDim(ref HideColumn, DASHBOARD_COL_7_NUM);

					ColumnCaption[DASHBOARD_CODE_NUM] = "Contact Phone";
					ColumnCaption[DASHBOARD_COL_2_NUM] = "Contact Time";
					ColumnCaption[DASHBOARD_COL_3_NUM] = "Contact Name";
					ColumnCaption[DASHBOARD_COL_4_NUM] = "Contact Reason";
					ColumnCaption[DASHBOARD_COL_5_NUM] = "Mobile Phone";
					ColumnCaption[DASHBOARD_COL_6_NUM] = "Email Address";
					ColumnCaption[DASHBOARD_COL_7_NUM] = "Next Remark";
				}
				sql_str = "SELECT * FROM tblARProspect p LEFT JOIN tblARProspectNextContactReason r ON p.iNextReason_id = r.iNextContactReason_id";
				sql_str += " WHERE iNext_dt = " + cur_date.ToString();
				sql_str += " AND sCreator_id = '" + cur_db.sUser_cd + "'";
				sql_str += " ORDER BY sNextTime";

				if (cur_set.CreateSnapshot(sql_str) == false)
				{
					return 0;
				}
				else if (cur_set.RecordCount() == 0)
				{
					return 0;
				}
				else if (get_count_only)
				{
					return_value = cur_set.RecordCount();
					return return_value;
				}

				iTotalRows = cur_set.RecordCount();
				oUtility.ResizeDim(ref Data, TOTAL_COLUMNS, iTotalRows - 1);
				row_num = 0;

				while (cur_set.EOF() == false)
				{
					Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
					Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_PROSPECT_TYPE_NUM.ToString();
					Data[DASHBOARD_CODE_NUM, row_num] = cur_set.sField("sProspect_cd");
					Data[DASHBOARD_COL_2_NUM, row_num] = cur_set.sField("sNextTime");
					Data[DASHBOARD_COL_3_NUM, row_num] = cur_set.sField("sProspect_nm");
					Data[DASHBOARD_COL_4_NUM, row_num] = cur_set.sField("sDescription");
					Data[DASHBOARD_COL_5_NUM, row_num] = cur_set.sField("sMobilePhone");
					Data[DASHBOARD_COL_6_NUM, row_num] = cur_set.sField("sEmailAddress");
					Data[DASHBOARD_COL_7_NUM, row_num] = cur_set.sField("sNextRemark");

					cur_set.MoveNext();
					row_num += 1;
				}

				RecreateGrid();
				return_value = cur_set.RecordCount();
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProspectsToContact)");
			}

			return return_value;
		}

		public int VendorsToContact(ref clsDatabase cur_db, int cur_date, bool get_count_only)
		{
			int return_value = 0;
			string sql_str = "SELECT * FROM tblAPVendor WHERE iNext_dt = " + cur_date.ToString() + " ORDER BY sNextTime";
			int row_num = 0;

			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{
				Clear();

				if (get_count_only == false)
				{
					oUtility.ResizeDim(ref ColumnCaption, DASHBOARD_COL_7_NUM);
					oUtility.ResizeDim(ref HideColumn, DASHBOARD_COL_7_NUM);

					ColumnCaption[DASHBOARD_CODE_NUM] = "Vendor Code";
					ColumnCaption[DASHBOARD_COL_2_NUM] = "Contact Time";
					ColumnCaption[DASHBOARD_COL_3_NUM] = "Vendor Name";
					ColumnCaption[DASHBOARD_COL_4_NUM] = "Contact Name";
					ColumnCaption[DASHBOARD_COL_5_NUM] = "Contact Phone";
					ColumnCaption[DASHBOARD_COL_6_NUM] = "Email Address";
					ColumnCaption[DASHBOARD_COL_7_NUM] = "Next Remark";
				}

				if (cur_set.CreateSnapshot(sql_str) == false)
				{
					return 0;
				}
				else if (cur_set.RecordCount() == 0)
				{
					return 0;
				}
				else if (get_count_only)
				{
					return_value = cur_set.RecordCount();
					return return_value;
				}

				iTotalRows = cur_set.RecordCount();
				oUtility.ResizeDim(ref Data, TOTAL_COLUMNS, iTotalRows - 1);
				row_num = 0;

				while (cur_set.EOF() == false)
				{
					Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
					Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_VENDOR_TYPE_NUM.ToString();
					Data[DASHBOARD_CODE_NUM, row_num] = cur_set.sField("sVendor_cd");
					Data[DASHBOARD_COL_2_NUM, row_num] = cur_set.sField("sNextTime");
					Data[DASHBOARD_COL_3_NUM, row_num] = cur_set.sField("sVendor_nm");
					Data[DASHBOARD_COL_4_NUM, row_num] = cur_set.sField("sContact_nm");
					Data[DASHBOARD_COL_5_NUM, row_num] = cur_set.sField("sContactPhone");
					Data[DASHBOARD_COL_6_NUM, row_num] = cur_set.sField("sEmailAddress");
					Data[DASHBOARD_COL_7_NUM, row_num] = cur_set.sField("sNextRemark");

					cur_set.MoveNext();
					row_num += 1;
				}

				RecreateGrid();
				return_value = cur_set.RecordCount();
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(VendorsToContact)");
			}

			return return_value;
		}

		public int CustomerSupport(ref clsDatabase cur_db, int cur_date, bool get_count_only)
		{
			int return_value = 0;
			string sql_str = "";
			string reason_str = null;
			int row_num = 0;

			clsRecordset reason_set = new clsRecordset(ref cur_db);
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{
				Clear();

				if (get_count_only == false)
				{
					oUtility.ResizeDim(ref ColumnCaption, DASHBOARD_COL_3_NUM);
					oUtility.ResizeDim(ref HideColumn, DASHBOARD_COL_3_NUM);

					ColumnCaption[DASHBOARD_CODE_NUM] = "Case ID";
					ColumnCaption[DASHBOARD_COL_2_NUM] = "Date Requested";
					ColumnCaption[DASHBOARD_COL_3_NUM] = "Resolution Requested";
				}

				sql_str = "SELECT * FROM tblARCustomerSupport";
				sql_str += " WHERE iStatus_typ <> " + GlobalVar.goConstant.SUPPORT_CLOSED_NUM.ToString() + " AND iStatus_typ <> " + GlobalVar.goConstant.SUPPORT_CANCELED_NUM.ToString();
				if (GlobalVar.goUtility.IsSupervisor(cur_db) == false)
				{
					sql_str += " AND (sCreator_id = '" + cur_db.sUser_cd + "' OR sAssignedTo_cd = '" + cur_db.sUser_cd + "')";
				}

				if (cur_set.CreateSnapshot(sql_str) == false)
				{
					return 0;
				}
				else if (cur_set.RecordCount() == 0)
				{
					return 0;
				}
				else if (get_count_only)
				{
					return_value = cur_set.RecordCount();
					return return_value;
				}

				sql_str = "SELECT * FROM tblARCustomerCallReason ORDER BY iReason_id";

				if (!reason_set.CreateSnapshot(sql_str))
				{
					return 0;
				}

				iTotalRows = cur_set.RecordCount();
				oUtility.ResizeDim(ref Data, TOTAL_COLUMNS, iTotalRows - 1);
				row_num = 0;

				while (cur_set.EOF() == false)
				{
					reason_str = "";
					if (reason_set.FindRecord("iReason_id", cur_set.iField("iReason_id").ToString()))
					{
						reason_str = reason_set.sField("sDescription");
					}
					Data[DASHBOARD_DEPTH_NUM, row_num] = "1";
					Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_CUSTOMER_SUPPORT_TYPE_NUM.ToString();
					Data[DASHBOARD_CODE_NUM, row_num] = cur_set.iField("iSupport_num").ToString();
					Data[DASHBOARD_COL_2_NUM, row_num] = cur_set.dtField("dtReported_dt").ToString();
					Data[DASHBOARD_COL_3_NUM, row_num] = reason_str;

					cur_set.MoveNext();
					row_num += 1;
				}

				RecreateGrid();
				return_value = cur_set.RecordCount();
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CustomerSupport)");
			}

			return return_value;
		}

		public int ReceivableAging(ref clsDatabase cur_db, int cur_date, bool show_details = false)
		{
			int return_value = 0;
			decimal total_amt = 0;
			decimal current_amt = 0;
			decimal pastdue_amt = 0;
			decimal in30_amt = 0;
			decimal in60_amt = 0;
			decimal in90_amt = 0;
			decimal in120_amt = 0;
			decimal over120_amt = 0;
			string sql_str = "";
			int row_num = 0;

			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{

				Clear();
				oUtility.ResizeDim(ref ColumnCaption, DASHBOARD_COL_11_NUM);
				oUtility.ResizeDim(ref HideColumn, DASHBOARD_COL_11_NUM);

				HideColumn[DASHBOARD_CODE_NUM] = (show_details == false);
				HideColumn[DASHBOARD_COL_2_NUM] = (show_details == false);
				HideColumn[DASHBOARD_COL_3_NUM] = (show_details == false);

				ColumnCaption[DASHBOARD_CODE_NUM] = "Invoice Num";
				ColumnCaption[DASHBOARD_COL_2_NUM] = "Date Applied";
				ColumnCaption[DASHBOARD_COL_3_NUM] = "Date Due";
				ColumnCaption[DASHBOARD_COL_4_NUM] = "Total Receivable";
				ColumnCaption[DASHBOARD_COL_5_NUM] = "Past Due";
				ColumnCaption[DASHBOARD_COL_6_NUM] = "Current";
				ColumnCaption[DASHBOARD_COL_7_NUM] = "1 ~ 30";
				ColumnCaption[DASHBOARD_COL_8_NUM] = "31 ~ 60";
				ColumnCaption[DASHBOARD_COL_9_NUM] = "61 ~ 90";
				ColumnCaption[DASHBOARD_COL_10_NUM] = "91 ~ 120";
				ColumnCaption[DASHBOARD_COL_11_NUM] = "Over 120";

				sql_str = "SELECT * FROM tblARChargeDue WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_INVOICE_TYPE.ToString();
				sql_str += " AND iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM.ToString();
				sql_str += " AND mDue_amt <> 0 "; // 06/19/2018 Negative voucher/invoice is implemented

				if (GlobalVar.goUtility.IsSalesStaff(cur_db))
				{
					sql_str += " AND sCustomer_cd IN (SELECT sCustomer_cd FROM tblARCustomer WHERE sSalesrep_cd = '" + cur_db.sUser_cd + "')";
				}

				sql_str += " ORDER BY iDue_dt";

				if (cur_set.CreateSnapshot(sql_str) == false)
				{
					return 0;
				}
				else if (cur_set.RecordCount() == 0)
				{
					return 0;
				}

				if (show_details)
                {
					iTotalRows = cur_set.RecordCount() + 1;		// For details + one total line
				}
				else
                {
					iTotalRows = 1;								// Just for total
				}

				oUtility.ResizeDim(ref Data, TOTAL_COLUMNS, iTotalRows - 1);
				row_num = 0;

				while (cur_set.EOF() == false)
				{
					if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -120))
					{
						over120_amt += cur_set.mField("mDue_amt");
					}
					else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -90))
					{
						in120_amt += cur_set.mField("mDue_amt");
					}
					else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -60))
					{
						in90_amt += cur_set.mField("mDue_amt");
					}
					else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -30))
					{
						in60_amt += cur_set.mField("mDue_amt");
					}
					else if (cur_set.iField("iDue_dt") <= cur_date)
					{
						in30_amt += cur_set.mField("mDue_amt");
					}

					total_amt += cur_set.mField("mDue_amt");

					if (cur_set.iField("iDue_dt") <= cur_date)
                    {
						pastdue_amt += cur_set.mField("mDue_amt");
					}

					cur_set.MoveNext();

				}

				current_amt = total_amt - pastdue_amt;

				Data[DASHBOARD_DEPTH_NUM, row_num] = "0";
				Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_RECEIVABLE_AGING_TYPE_NUM.ToString();
				Data[DASHBOARD_CODE_NUM, row_num] = "";
				Data[DASHBOARD_COL_2_NUM, row_num] = "";
				Data[DASHBOARD_COL_3_NUM, row_num] = "";
				Data[DASHBOARD_COL_4_NUM, row_num] = o_money.ToStrMoney(total_amt);
				Data[DASHBOARD_COL_5_NUM, row_num] = o_money.ToStrMoney(pastdue_amt);
				Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(current_amt);
				Data[DASHBOARD_COL_7_NUM, row_num] = o_money.ToStrMoney(in30_amt);
				Data[DASHBOARD_COL_8_NUM, row_num] = o_money.ToStrMoney(in60_amt);
				Data[DASHBOARD_COL_9_NUM, row_num] = o_money.ToStrMoney(in90_amt);
				Data[DASHBOARD_COL_10_NUM, row_num] = o_money.ToStrMoney(in120_amt);
				Data[DASHBOARD_COL_11_NUM, row_num] = o_money.ToStrMoney(over120_amt);

				if (show_details)
				{
					cur_set.MoveFirst();
					row_num += 1;
					while (cur_set.EOF() == false)
					{
						Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_RECEIVABLE_AGING_TYPE_NUM.ToString();
						Data[DASHBOARD_CODE_NUM, row_num] = cur_set.iField("iTransaction_num").ToString();
						Data[DASHBOARD_COL_2_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iApply_dt"));
						Data[DASHBOARD_COL_3_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iDue_dt"));

						if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -120))
						{
							Data[DASHBOARD_COL_11_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
						}
						else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -90))
						{
							Data[DASHBOARD_COL_10_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
						}
						else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -60))
						{
							Data[DASHBOARD_COL_9_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
						}
						else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -30))
						{
							Data[DASHBOARD_COL_8_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
						}
						else if (cur_set.iField("iDue_dt") <= cur_date)
						{
							Data[DASHBOARD_COL_7_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
						}
						else 
						{
							Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
						}

						cur_set.MoveNext();
						row_num += 1;
					}
				}

				RecreateGrid();
				return_value = cur_set.RecordCount();
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ReceivableAging)");
			}

			return return_value;
		}


		public int PayableAging(ref clsDatabase cur_db, int cur_date, bool show_details = false)
		{
			int return_value = 0;
			decimal total_amt = 0;
			decimal current_amt = 0;
			decimal pastdue_amt = 0;
			decimal in30_amt = 0;
			decimal in60_amt = 0;
			decimal in90_amt = 0;
			decimal in120_amt = 0;
			decimal over120_amt = 0;
			string sql_str = "";
			int row_num = 0;

			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{

				Clear();
				oUtility.ResizeDim(ref ColumnCaption, DASHBOARD_COL_11_NUM);
				oUtility.ResizeDim(ref HideColumn, DASHBOARD_COL_11_NUM);

				HideColumn[DASHBOARD_CODE_NUM] = (show_details == false);
				HideColumn[DASHBOARD_COL_2_NUM] = (show_details == false);
				HideColumn[DASHBOARD_COL_3_NUM] = (show_details == false);

				ColumnCaption[DASHBOARD_CODE_NUM] = "Voucher Num";
				ColumnCaption[DASHBOARD_COL_2_NUM] = "Date Applied";
				ColumnCaption[DASHBOARD_COL_3_NUM] = "Date Due";
				ColumnCaption[DASHBOARD_COL_4_NUM] = "Total Payable";
				ColumnCaption[DASHBOARD_COL_5_NUM] = "Past Due";
				ColumnCaption[DASHBOARD_COL_6_NUM] = "Current";
				ColumnCaption[DASHBOARD_COL_7_NUM] = "1 ~ 30";
				ColumnCaption[DASHBOARD_COL_8_NUM] = "31 ~ 60";
				ColumnCaption[DASHBOARD_COL_9_NUM] = "61 ~ 90";
				ColumnCaption[DASHBOARD_COL_10_NUM] = "91 ~ 120";
				ColumnCaption[DASHBOARD_COL_11_NUM] = "Over 120";

				sql_str = "SELECT * FROM tblAPChargeDue WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_PURCHASE_TYPE.ToString();
				sql_str += " AND iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM.ToString();
				sql_str += " AND mDue_amt <> 0 "; // 06/19/2018 Negative voucher/invoice is implemented
				sql_str += " ORDER BY iDue_dt";

				if (cur_set.CreateSnapshot(sql_str) == false)
				{
					return 0;
				}
				else if (cur_set.RecordCount() == 0)
				{
					return 0;
				}

				if (show_details)
				{
					iTotalRows = cur_set.RecordCount() + 1;     // For details + one total line
				}
				else
				{
					iTotalRows = 1;                             // Just for total
				}

				oUtility.ResizeDim(ref Data, TOTAL_COLUMNS, iTotalRows - 1);
				row_num = 0;

				while (cur_set.EOF() == false)
				{
					if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -120))
					{
						over120_amt += cur_set.mField("mDue_amt");
					}
					else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -90))
					{
						in120_amt += cur_set.mField("mDue_amt");
					}
					else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -60))
					{
						in90_amt += cur_set.mField("mDue_amt");
					}
					else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -30))
					{
						in60_amt += cur_set.mField("mDue_amt");
					}
					else if (cur_set.iField("iDue_dt") <= cur_date)
					{
						in30_amt += cur_set.mField("mDue_amt");
					}

					total_amt += cur_set.mField("mDue_amt");

					if (cur_set.iField("iDue_dt") <= cur_date)
					{
						pastdue_amt += cur_set.mField("mDue_amt");
					}

					cur_set.MoveNext();

				}

				current_amt = total_amt - pastdue_amt;

				Data[DASHBOARD_DEPTH_NUM, row_num] = "0";
				Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_PAYABLE_AGING_TYPE_NUM.ToString();
				Data[DASHBOARD_CODE_NUM, row_num] = "";
				Data[DASHBOARD_COL_2_NUM, row_num] = "";
				Data[DASHBOARD_COL_3_NUM, row_num] = "";
				Data[DASHBOARD_COL_4_NUM, row_num] = o_money.ToStrMoney(total_amt);
				Data[DASHBOARD_COL_5_NUM, row_num] = o_money.ToStrMoney(pastdue_amt);
				Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(current_amt);
				Data[DASHBOARD_COL_7_NUM, row_num] = o_money.ToStrMoney(in30_amt);
				Data[DASHBOARD_COL_8_NUM, row_num] = o_money.ToStrMoney(in60_amt);
				Data[DASHBOARD_COL_9_NUM, row_num] = o_money.ToStrMoney(in90_amt);
				Data[DASHBOARD_COL_10_NUM, row_num] = o_money.ToStrMoney(in120_amt);
				Data[DASHBOARD_COL_11_NUM, row_num] = o_money.ToStrMoney(over120_amt);

				if (show_details)
				{
					cur_set.MoveFirst();
					row_num += 1;
					while (cur_set.EOF() == false)
					{
						Data[DASHBOARD_TYPE_NUM, row_num] = DASHBOARD_PAYABLE_AGING_TYPE_NUM.ToString();
						Data[DASHBOARD_CODE_NUM, row_num] = cur_set.iField("iTransaction_num").ToString();
						Data[DASHBOARD_COL_2_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iApply_dt"));
						Data[DASHBOARD_COL_3_NUM, row_num] = o_gen.ToStrDate(cur_set.iField("iDue_dt"));

						if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -120))
						{
							Data[DASHBOARD_COL_11_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
						}
						else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -90))
						{
							Data[DASHBOARD_COL_10_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
						}
						else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -60))
						{
							Data[DASHBOARD_COL_9_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
						}
						else if (cur_set.iField("iDue_dt") <= GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, cur_date, -30))
						{
							Data[DASHBOARD_COL_8_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
						}
						else if (cur_set.iField("iDue_dt") <= cur_date)
						{
							Data[DASHBOARD_COL_7_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
						}
						else
						{
							Data[DASHBOARD_COL_6_NUM, row_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
						}

						cur_set.MoveNext();
						row_num += 1;
					}
				}

				RecreateGrid();
				return_value = cur_set.RecordCount();
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(PayableAging)");
			}

			return return_value;
		}

	}
}
