﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP.Models
{
    public class clsSession
    {
        public class clsKey
        {
            public const string SERVER = "SERVER";
            public const string DATABASE = "DATABASE";
            public const string USER = "USER";
            public const string PASSWORD = "PASSWORD";
            public const string CCN = "CCN";
            public const string DSN = "DSN";
            public const string ENTITY = "ENTITY";               // Entity code such as customer code, vendor code, item code & account code.  Also, transaction number.
            public const string EXTRA1 = "EXTRA1";               // Any values to pass
            public const string EXTRA2 = "EXTRA2";
            public const string EXTRA3 = "EXTRA3";
        }
        public clsKey Key = new clsKey();

        public class clsValue
        {
            public string Server;
            public string Database;
            public string User;
            public string Password;
            public string CCN;
            public string DSN;
            public string Entity;               
            public string Extra1;               
            public string Extra2;
            public string Extra3;
        }
        public clsValue Value = new clsValue();

        private clsDynastyUtility oUtility = new clsDynastyUtility();
        private const string FILE_EXTENTION = "para";

        private string _session_id = "";

        // As of November 2020, using session storage creats a conflict with our renderring method, render-mode="ServerPrerendered" in _Host.cshtml.
        // For now, we use a file to send values to another page.
        // Later on, when we find a better way to use session storage, this should be revisited.
        //
        public bool SetSessionValues(clsDatabase cur_db, Models.clsUser cur_user, ref string session_id, string entity_code = "", string extra1 = "", string extra2 = "", string extra3 = "")
        {
            clsFileIO o_fileIO = new clsFileIO();
            clsGeneral o_gen = new clsGeneral(ref cur_db);

            string file_text = "";
            string file_name = "";

            modWebUtility.CopyUserCredentials(ref cur_db, cur_user);

            if (modGeneralUtility.GetHomeDirectory(ref cur_db) ==  false)
            {
                return false;
            }

            file_text = clsKey.SERVER + "=" + cur_db.sServer_nm;
            file_text += "," + clsKey.DATABASE + "=" + cur_db.sDatabase_nm;
            file_text += "," + clsKey.USER + "=" + cur_db.sUser_cd;
            file_text += "," + clsKey.PASSWORD + "=" + cur_db.sPassword;
            file_text += "," + clsKey.CCN + "=" + cur_db.sCCN;
            file_text += "," + clsKey.DSN + "=" + cur_db.sDSN;
            file_text += "," + clsKey.ENTITY + "=" + entity_code;
            file_text += "," + clsKey.EXTRA1 + "=" + extra1;
            file_text += "," + clsKey.EXTRA2 + "=" + extra2;
            file_text += "," + clsKey.EXTRA3 + "=" + extra3;

            //session_id = cur_db.sServer_nm + cur_db.sDatabase_nm + o_gen.GetSurrogateKey("SESSION_KEY").ToString();

            //if (o_fileIO.OpenFileToWrite(cur_db.uDirectory.sParameterDirectory_nm + "\\" + session_id + "." + FILE_EXTENTION) == false)
            //{
            //    return false;
            //}

            //o_fileIO.WriteOneLine(file_text);
            //o_fileIO.CloseFile();

            session_id = oUtility.PasswordEncode(file_text);            //  session_id);

            return true;
        }

        public bool GetSessionValues(string session_id)
        {
            bool return_value = false;

            clsDatabase o_db = new clsDatabase();
            clsFileIO o_fileIO = new clsFileIO();
            clsFile o_file = new clsFile();

            string file_text = "";
            string one_text = "";
            string key_id = "";
            string key_value = "";
            int trial = 0;

            string file_name = "";

            try
            {
                //_session_id = session_id;

                //file_name = oUtility.PasswordDecode(session_id) + "." + FILE_EXTENTION;

                //if (modGeneralUtility.GetHomeDirectory(ref o_db) == false)
                //{
                //    return false;
                //}
                //if (o_file.FileExists(o_db.uDirectory.sParameterDirectory_nm + "\\" + file_name) == false)
                //{
                //    return false;
                //}
                //if (o_fileIO.OpenFileToRead(o_db.uDirectory.sParameterDirectory_nm + "\\" + file_name) == false)
                //{
                //    return false;
                //}

                //file_text = o_fileIO.ReadOneLine();

                file_text = oUtility.PasswordDecode(session_id);

                while (oUtility.IsNonEmpty(file_text))
                {
                    one_text = oUtility.STrim(oUtility.NextValueInCSVTextLine(ref file_text, true));
                    file_text = oUtility.STrim(file_text);

                    key_id = oUtility.SLeft(one_text, oUtility.SInStr(one_text, "=") - 1);
                    key_value = oUtility.SReplace(one_text, key_id + "=", "");

                    switch (key_id)
                    {
                        case clsKey.SERVER:
                            Value.Server = key_value;
                            break;
                        case clsKey.DATABASE:
                            Value.Database = key_value;
                            break;
                        case clsKey.USER:
                            Value.User = key_value;
                            break;
                        case clsKey.PASSWORD:
                            Value.Password = key_value;
                            break;
                        case clsKey.CCN:
                            Value.CCN = key_value;
                            break;
                        case clsKey.DSN:
                            Value.DSN = key_value;
                            break;
                        case clsKey.ENTITY:
                            Value.Entity = key_value;
                            break;
                        case clsKey.EXTRA1:
                            Value.Extra1 = key_value;
                            break;
                        case clsKey.EXTRA2:
                            Value.Extra2 = key_value;
                            break;
                        case clsKey.EXTRA3:
                            Value.Extra3 = key_value;
                            break;
                        default:
                            break;
                    }
                }

                //o_fileIO.CloseFile();

                return_value = true;
            }
            catch (Exception ex)
            {

            }

            return return_value;
        }

        public bool RemoveSession(clsDatabase cur_db)
        {
            clsFile o_file = new clsFile();

            if (oUtility.IsEmpty(_session_id))
            {
                return true;
            }

            string file_name = oUtility.PasswordDecode(_session_id) + "." + FILE_EXTENTION;

            if (modGeneralUtility.GetHomeDirectory(ref cur_db) == false)
            {
                return false;
            }
            if (o_file.FileExists(cur_db.uDirectory.sParameterDirectory_nm + "\\" + file_name) == false)
            {
                return true;
            }

            o_file.Remove(cur_db.uDirectory.sParameterDirectory_nm + "\\" + file_name);

            _session_id = "";

            return true;
        }
    }
}
