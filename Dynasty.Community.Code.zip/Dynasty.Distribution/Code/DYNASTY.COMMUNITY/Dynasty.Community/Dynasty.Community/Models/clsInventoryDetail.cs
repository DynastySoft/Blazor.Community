﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//



using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Collections.Generic;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP.Models
{
	public class clsInventoryDetail
	{
		private int iTransaction_typ = 0;
		private string sPostingError = "";

		private clsArray oArray = new clsArray();
		private clsDynastyUtility oUtility = new clsDynastyUtility();

		public bool IsErrorFound()
		{
			bool return_value = false;

			return_value = (oUtility.IsNonEmpty(sPostingError));

			return return_value;
		}

		public string GetErrorMessage()
		{
			string return_value = "";

			return_value = sPostingError;
			sPostingError = "";

			return return_value;
		}

		public void SetPostingError(string error_msg)
		{
			if (oUtility.IsEmpty(error_msg))
			{
				sPostingError = "";
			}
			else if (oUtility.IsEmpty(sPostingError))
			{
				sPostingError = error_msg;
			}
			else if (oUtility.STrim(sPostingError) != oUtility.STrim(error_msg))
			{
				sPostingError += Environment.NewLine + Environment.NewLine + "AND " + error_msg;
			}
		}
		public int iTotalRows = 0;

        public string[] FieldName;                                                              // Keeps the detail field names;
		public string[,] Data;                                                                  // Keeps the detail data.

		public const int INCLUDE_COL = 0;
		public const int ITEM_CODE_COL = 1;
		public const int PRIMARY_ITEM_COL = 2;
		public const int ITEM_TYPE_COL = 3;
		public const int TAXABLE_FLAG_COL = 4;
		public const int ITEM_NAME_COL = 5;
		public const int COMMENT_COL = 6;
		public const int PURCHASE_UNIT_CODE_COL = 7;
		public const int SELL_UNIT_CODE_COL = 8;
		public const int IVUNIT_CODE_COL = 9;
		public const int SELL_UNIT_PRICE_COL = 10;
		public const int STD_COST_COL = 11;
		public const int AVG_COST_COL = 12;
		public const int LAST_COST_COL = 13;
		public const int LAST_VENDOR_COL = 14;
		public const int PREF_VENDOR_COL = 15;
		public const int LOCATION_COL = 16;
		public const int STATUS_COL = 17;
		public const int BIN_COL = 18;
		public const int MIN_LEVEL_COL = 19;
		public const int MAX_LEVEL_COL = 20;
		public const int REORDER_LEVEL_COL = 21;
		public const int QTY_TO_ORDER_COL = 22;
		public const int QTY_BACKORDER_COL = 23;
		public const int QTY_ON_ORDER_COL = 24;
		public const int QTY_ON_HAND_COL = 25;
		public const int QTY_ALLOC_TO_ORDER_COL = 26;
		public const int QTY_ALLOC_TO_ASSEMBLY_COL = 27;
		public const int QTY_COMM_TO_ORDER_COL = 28;
		public const int QTY_COMM_TO_INVOICE_COL = 29;
		public const int QTY_COMM_TO_DM_COL = 30;
		public const int QTY_COMM_TO_TRF_COL = 31;
		public const int QTY_COMM_ASSEMBLY_COL = 32;
		public const int QTY_COMM_SPOILAGE_COL = 33;
		public const int QTY_IN_TRF_OUT_COL = 34;
		public const int QTY_IN_TRF_IN_COL = 35;
		public const int QTY_IN_REPAIR_COL = 36;
		public const int QTY_IN_ASSEMBLY_COL = 37;
		public const int QTY_AVAILABLE_COL = 38;
		public const int QTY_UNPOSTED_COL = 39;
		public const int AMT_ORDER_COST_COL = 40;
		public const int AMT_CARRY_COST_COL = 41;
		public const int YEARLY_SOLD_COL = 42;
		public const int QUARTERLY_SOLD_COL = 43;
		public const int MONTHLY_SOLD_COL = 44;
		public const int WEEKLY_SOLD_COL = 45;
		public const int DATE_REQUIRED_COL = 46;
		public const int DATE_LAST_SALES_COL = 47;
		public const int DATE_LAST_SALES_RETURN_COL = 48;
		public const int DATE_LAST_PURCHASE_COL = 49;
		public const int DATE_LAST_PURCHASE_RETURN_COL = 50;
		public const int DATE_PHYSICAL_COL = 51;
		public const int EXTRA_COL = 52;

		public const int ITEM_MANUFACTURER_COL = 60;
		public const int ITEM_BRAND_COL = 61;
		public const int ITEM_MODEL_COL = 62;
		public const int ITEM_STYLE_COL = 63;
		public const int ITEM_SIZE_COL = 64;
		public const int ITEM_COLOR_COL = 65;
		public const int SOURCE_TYPE_COL = 66;
		public const int SOURCE_NUM_COL = 67;
		public const int SOURCE_DETAIL_COL = 68;
		public const int PO_NUM_COL = 69;
		public const int PO_DETAIL_COL = 70;
		public const int GL_ACCT_CODE_COL = 71;
		public const int UNIT_PRICE_COL = 72;

		// For future use
		//
		public const int USER_DEFINED1_COL = 101;
		public const int USER_DEFINED2_COL = 102;
		public const int USER_DEFINED3_COL = 103;
		public const int USER_DEFINED4_COL = 104;
		public const int USER_DEFINED5_COL = 105;
		public const int USER_DEFINED1_AMT_COL = 106;
		public const int USER_DEFINED2_AMT_COL = 107;
		public const int USER_DEFINED3_AMT_COL = 108;
		public const int USER_DEFINED4_AMT_COL = 109;
		public const int USER_DEFINED5_AMT_COL = 110;
		public const int USER_DEFINED1_DT_COL = 111;
		public const int USER_DEFINED2_DT_COL = 112;
		public const int USER_DEFINED3_DT_COL = 113;
		public const int USER_DEFINED4_DT_COL = 114;
		public const int USER_DEFINED5_DT_COL = 115;
		public const int USER_DEFINED1_NUM_COL = 116;
		public const int USER_DEFINED2_NUM_COL = 117;
		public const int USER_DEFINED3_NUM_COL = 118;
		public const int USER_DEFINED4_NUM_COL = 119;
		public const int USER_DEFINED5_NUM_COL = 120;

		public const int TOTAL_COLUMNS = 121;

		public class clsGrid
		{
			public int Row_num = 0;                                 // 0-based row number. This will identify each row.
			public bool chkInclude_fl = false;
			public string txtItem_cd = "";
			public string txtPrimaryItem_cd = "";
			public string txtItem_typ = "";
			public string txtTaxable_fl = "";
			public string txtItem_nm = "";
			public string txtComment = "";
			public string txtPurchaseUnit_cd = "";
			public string txtSellUnit_cd = "";
			public string txtIVUnit_cd = "";
			public string txtUnitPrice_amt = "";
			public string txtSellUnitPrice_amt = "";
			public string txtStdCost_amt = "";
			public string txtAvgCost_amt = "";
			public string txtLastCost_amt = "";
			public string txtLastVendor_cd = "";
			public string txtPreferredVendor_cd = "";
			public string txtLocation_cd = "";
			public string txtStatus_typ = "";
			public string txtBin_cd = "";
			public string txtMinLevel_qty = "";
			public string txtMaxLevel_qty = "";
			public string txtReorderLevel_qty = "";
			public string txtToOrder_qty = "";
			public string txtBackOrder_qty = "";
			public string txtOnOrder_qty = "";
			public string txtOnHand_qty = "";
			public string txtAllocToOrder_qty = "";
			public string txtAllocToAssembly_qty = "";
			public string txtCommToOrder_qty = "";
			public string txtCommToInvoice_qty = "";
			public string txtCommToDM_qty = "";
			public string txtCommToTransfer_qty = "";
			public string txtCommToAssembly_qty = "";
			public string txtCommToSpoilage_qty = "";
			public string txtInTransferOut_qty = "";
			public string txtInTransferIn_qty = "";
			public string txtInRepair_qty = "";
			public string txtInAssembly_qty = "";
			public string txtAvailable_qty = "";
			public string txtUnposted_qty = "";
			public string txtOrderCost_amt = "";
			public string txtCarryCost_amt = "";
			public string txtYearlySold_amt = "";
			public string txtQuarterlySold_qty = "";
			public string txtMonthlySold_amt = "";
			public string txtWeeklySold_amt = "";
			public string txtRequired_dt = "";
			public string txtLastSales_dt = "";
			public string txtLastSalesRet_dt = "";
			public string txtLastPurchase_dt = "";
			public string txtLastPurchaseRet_dt = "";
			public string txtLastPhysical_dt = "";

			public string txtManufacturer_cd = "";
			public string txtBrand_cd = "";
			public string txtModel_cd = "";
			public string txtStyle_cd = "";
			public string txtColor_cd = "";
			public string txtSize_cd = "";

			public string txtSource_typ = "";
			public string txtSource_num = "";
			public string txtSourceDetail_num = "";
			public string txtPO_num = "";
			public string txtPODetail_num = "";
			public string txtGLAccount_cd = "";
			public string txtExtra = "";

			public string txtLine_id = "";

            public DateTime? dtRequired_dt = null;      // This is only for UI

            // For future use.
            //
            public string txtUserDefined1 = "";
			public string txtUserDefined2 = "";
			public string txtUserDefined3 = "";
			public string txtUserDefined4 = "";
			public string txtUserDefined5 = "";
			public string txtUserDefined1_amt = "";
			public string txtUserDefined2_amt = "";
			public string txtUserDefined3_amt = "";
			public string txtUserDefined4_amt = "";
			public string txtUserDefined5_amt = "";
			public string txtUserDefined1_dt = "";
			public string txtUserDefined2_dt = "";
			public string txtUserDefined3_dt = "";
			public string txtUserDefined4_dt = "";
			public string txtUserDefined5_dt = "";
			public string txtUserDefined1_num = "";
			public string txtUserDefined2_num = "";
			public string txtUserDefined3_num = "";
			public string txtUserDefined4_num = "";
			public string txtUserDefined5_num = "";

		}
		public List<clsGrid> Grid = new List<clsGrid>();

		public bool AddMoreRows(int lines_to_add = 10)
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
                // oUtility.ResizeDimPreserved(ref Data, Data.GetUpperBound(0), Data.GetUpperBound(1) + lines_to_add);

                for (row_num = 0; row_num < lines_to_add; row_num++)
                {
                    Grid.Add(new clsGrid { Row_num = iTotalRows
							, chkInclude_fl = false
							, txtItem_cd = ""
							, txtPrimaryItem_cd = ""
							, txtItem_typ = ""
							, txtTaxable_fl = ""
							, txtItem_nm = ""
							, txtComment = ""
							, txtPurchaseUnit_cd = ""
							, txtSellUnit_cd = ""
							, txtIVUnit_cd = ""
							, txtUnitPrice_amt = "" 
							, txtSellUnitPrice_amt = ""
							, txtStdCost_amt = "" 
							, txtAvgCost_amt = "" 
							, txtLastCost_amt = "" 
							, txtLastVendor_cd = "" 
							, txtPreferredVendor_cd = "" 
							, txtLocation_cd = "" 
							, txtStatus_typ = "" 
							, txtBin_cd = "" 
							, txtMinLevel_qty = "" 
							, txtMaxLevel_qty = "" 
							, txtReorderLevel_qty = "" 
							, txtToOrder_qty = ""
							, txtBackOrder_qty = ""
							, txtOnOrder_qty = "" 
							, txtOnHand_qty = "" 
							, txtAllocToOrder_qty = "" 
							, txtAllocToAssembly_qty = "" 
							, txtCommToOrder_qty = "" 
							, txtCommToInvoice_qty = "" 
							, txtCommToDM_qty = "" 
							, txtCommToTransfer_qty = "" 
							, txtCommToAssembly_qty = "" 
							, txtCommToSpoilage_qty = "" 
							, txtInTransferOut_qty = "" 
							, txtInTransferIn_qty = "" 
							, txtInRepair_qty = "" 
							, txtInAssembly_qty = "" 
							, txtAvailable_qty = "" 
							, txtUnposted_qty = "" 
							, txtOrderCost_amt = "" 
							, txtCarryCost_amt = "" 
							, txtYearlySold_amt = "" 
							, txtQuarterlySold_qty = ""
							, txtMonthlySold_amt = "" 
							, txtWeeklySold_amt = "" 
							, txtRequired_dt = "" 
							, txtLastSales_dt = "" 
							, txtLastSalesRet_dt = "" 
							, txtLastPurchase_dt = "" 
							, txtLastPurchaseRet_dt = "" 
							, txtLastPhysical_dt = "" 
							, txtManufacturer_cd = ""
							, txtBrand_cd = ""
							, txtModel_cd = ""
							, txtStyle_cd = ""
							, txtSize_cd = ""
							, txtColor_cd = ""
							, txtSource_typ = ""
							, txtSource_num = ""
							, txtSourceDetail_num = ""
							, txtPO_num = ""
							, txtPODetail_num = ""
							, txtGLAccount_cd = ""
							, txtExtra = ""
							,dtRequired_dt = null

							, txtUserDefined1 = ""
							, txtUserDefined2 = ""
							, txtUserDefined3 = ""
							, txtUserDefined4 = ""
							, txtUserDefined5 = ""
							, txtUserDefined1_amt = ""
							, txtUserDefined2_amt = ""
							, txtUserDefined3_amt = ""
							, txtUserDefined4_amt = ""
							, txtUserDefined5_amt = ""
							, txtUserDefined1_dt = ""
							, txtUserDefined2_dt = ""
							, txtUserDefined3_dt = ""
							, txtUserDefined4_dt = ""
							, txtUserDefined5_dt = ""
							, txtUserDefined1_num = ""
							, txtUserDefined2_num = ""
							, txtUserDefined3_num = ""
							, txtUserDefined4_num = ""
							, txtUserDefined5_num = ""

					});;;;

                    iTotalRows += 1;

				}
                
                RecreateDetail();
                return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (FormAddMoreRows)");
				RecreateDetail();
            }

            return return_value;
        }

		public bool InsertNewRow(clsGrid cur_item)
        {
			bool return_value = false;
            int old_row_num = cur_item.Row_num;

            try
            {
				Grid.Insert(old_row_num, new clsGrid { Row_num = -1
							, chkInclude_fl = false
							, txtItem_cd = ""
							, txtPrimaryItem_cd = ""
							, txtItem_typ = ""
							, txtTaxable_fl = ""
							, txtItem_nm = ""
							, txtComment = ""
							, txtPurchaseUnit_cd = ""
							, txtSellUnit_cd = ""
							, txtIVUnit_cd = ""
							, txtUnitPrice_amt = "" 
							, txtSellUnitPrice_amt = ""
							, txtStdCost_amt = "" 
							, txtAvgCost_amt = "" 
							, txtLastCost_amt = "" 
							, txtLastVendor_cd = "" 
							, txtPreferredVendor_cd = "" 
							, txtLocation_cd = "" 
							, txtStatus_typ = "" 
							, txtBin_cd = "" 
							, txtMinLevel_qty = "" 
							, txtMaxLevel_qty = "" 
							, txtReorderLevel_qty = "" 
							, txtToOrder_qty = ""
							, txtBackOrder_qty = ""
							, txtOnOrder_qty = "" 
							, txtOnHand_qty = "" 
							, txtAllocToOrder_qty = "" 
							, txtAllocToAssembly_qty = "" 
							, txtCommToOrder_qty = "" 
							, txtCommToInvoice_qty = "" 
							, txtCommToDM_qty = "" 
							, txtCommToTransfer_qty = "" 
							, txtCommToAssembly_qty = "" 
							, txtCommToSpoilage_qty = "" 
							, txtInTransferOut_qty = "" 
							, txtInTransferIn_qty = "" 
							, txtInRepair_qty = "" 
							, txtInAssembly_qty = "" 
							, txtAvailable_qty = "" 
							, txtUnposted_qty = "" 
							, txtOrderCost_amt = "" 
							, txtCarryCost_amt = "" 
							, txtYearlySold_amt = "" 
							, txtQuarterlySold_qty = ""
							, txtMonthlySold_amt = "" 
							, txtWeeklySold_amt = "" 
							, txtRequired_dt = "" 
							, txtLastSales_dt = "" 
							, txtLastSalesRet_dt = "" 
							, txtLastPurchase_dt = "" 
							, txtLastPurchaseRet_dt = "" 
							, txtLastPhysical_dt = "" 
							, txtManufacturer_cd = ""
							, txtBrand_cd = ""
							, txtModel_cd = ""
							, txtStyle_cd = ""
							, txtSize_cd = ""
							, txtColor_cd = ""
							, txtSource_typ = ""
							, txtSource_num = ""
							, txtSourceDetail_num = ""
							, txtPO_num = ""
							, txtPODetail_num = ""
							, txtGLAccount_cd = ""
							, txtExtra = ""
							,dtRequired_dt = null

							, txtUserDefined1 = ""
							, txtUserDefined2 = ""
							, txtUserDefined3 = ""
							, txtUserDefined4 = ""
							, txtUserDefined5 = ""
							, txtUserDefined1_amt = ""
							, txtUserDefined2_amt = ""
							, txtUserDefined3_amt = ""
							, txtUserDefined4_amt = ""
							, txtUserDefined5_amt = ""
							, txtUserDefined1_dt = ""
							, txtUserDefined2_dt = ""
							, txtUserDefined3_dt = ""
							, txtUserDefined4_dt = ""
							, txtUserDefined5_dt = ""
							, txtUserDefined1_num = ""
							, txtUserDefined2_num = ""
							, txtUserDefined3_num = ""
							, txtUserDefined4_num = ""
							, txtUserDefined5_num = ""

                });;

                Grid.Where(i => i.Row_num >= old_row_num).Select(i => { i.Row_num += 1; return i; }).ToList();
                Grid.Single(i => i.Row_num == -1).Row_num = old_row_num;

				iTotalRows += 1;

				RecreateDetail();

                return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (InsertNewRow)");
            }

            return return_value;
        }
		public bool DeleteCurrentRow(clsGrid cur_item)
        {
			bool return_value = false;
			int old_num = cur_item.Row_num;

			try
			{
				Grid.RemoveAt(cur_item.Row_num);
				Grid.Where(i => i.Row_num >= old_num).Select(i => { i.Row_num -= 1; return i; }).ToList();

				iTotalRows -= 1;

				RecreateDetail();

				return_value = true;
			}
			catch (Exception ex)
            {
				SetPostingError(ex.Message + " (DeleteCurrentRow)");
			}

			return return_value;
		}

		public bool RecreateDetail()                                                           //  Sync Data with Grid for the items that do not have event-handler ONLY.
		{
			bool return_value = false;
			int row_num = 0;

			try
			{
				if (Grid.Count() == 0)
				{
					oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), 0);
					return true;
				}

				// We need to create it here for saving because some fields may not have been copied into the array.
				//
				iTotalRows = Grid.Count();
				oUtility.ResizeDim(ref Data, Data.GetUpperBound(0), iTotalRows - 1);

				foreach (var det in Grid)
				{
					if (RecreateDetailLine(det, row_num) == false)
					{
						return false;
					}

					det.Row_num = row_num;      // Just to make sure.
					row_num++;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				SetPostingError(ex.Message + " (RecreateDetail)");
			}

			return return_value;
		}

		public bool RecreateGridLine(int row_num)
		{
			bool return_value = false;
			clsGrid grid_line = new clsGrid();

			if (FindGridLine(row_num, ref grid_line) == false)
			{
				SetPostingError("Grid does not match array.");
				return false;
			}

			return RecreateGridLine(ref grid_line, row_num);
		}

		public bool RecreateGridLine(ref clsGrid cur_item, int row_num)
        {
			bool return_value = false;

			try
            {
				cur_item.chkInclude_fl = (GlobalVar.goUtility.ToInteger(Data[INCLUDE_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON);
				cur_item.txtItem_cd = Data[ITEM_CODE_COL, row_num];
				cur_item.txtPrimaryItem_cd = Data[PRIMARY_ITEM_COL, row_num];
				cur_item.txtItem_typ = Data[ITEM_TYPE_COL, row_num];
				cur_item.txtTaxable_fl = Data[TAXABLE_FLAG_COL, row_num];
				cur_item.txtItem_nm = Data[ITEM_NAME_COL, row_num];
				cur_item.txtComment = Data[COMMENT_COL, row_num];
				cur_item.txtPurchaseUnit_cd = Data[PURCHASE_UNIT_CODE_COL, row_num];
				cur_item.txtSellUnit_cd = Data[SELL_UNIT_CODE_COL, row_num];
				cur_item.txtIVUnit_cd = Data[IVUNIT_CODE_COL, row_num];
				cur_item.txtUnitPrice_amt = Data[UNIT_PRICE_COL, row_num];
				cur_item.txtSellUnitPrice_amt = Data[SELL_UNIT_PRICE_COL, row_num];
				cur_item.txtStdCost_amt = Data[STD_COST_COL, row_num];
				cur_item.txtAvgCost_amt = Data[AVG_COST_COL, row_num];
				cur_item.txtLastCost_amt = Data[LAST_COST_COL, row_num];
				cur_item.txtLastVendor_cd = Data[LAST_VENDOR_COL, row_num];
				cur_item.txtPreferredVendor_cd = Data[PREF_VENDOR_COL, row_num];
				cur_item.txtLocation_cd = Data[LOCATION_COL, row_num];
				cur_item.txtStatus_typ = Data[STATUS_COL, row_num];
				cur_item.txtBin_cd = Data[BIN_COL, row_num];
				cur_item.txtMinLevel_qty = Data[MIN_LEVEL_COL, row_num];
				cur_item.txtMaxLevel_qty = Data[MAX_LEVEL_COL, row_num];
				cur_item.txtReorderLevel_qty = Data[REORDER_LEVEL_COL, row_num];
				cur_item.txtToOrder_qty = Data[QTY_TO_ORDER_COL, row_num];
				cur_item.txtBackOrder_qty = Data[QTY_BACKORDER_COL, row_num];
				cur_item.txtOnOrder_qty = Data[QTY_ON_ORDER_COL, row_num];
				cur_item.txtOnHand_qty = Data[QTY_ON_HAND_COL, row_num];
				cur_item.txtAllocToOrder_qty = Data[QTY_ALLOC_TO_ORDER_COL, row_num];
				cur_item.txtAllocToAssembly_qty = Data[QTY_ALLOC_TO_ASSEMBLY_COL, row_num];
				cur_item.txtCommToOrder_qty = Data[QTY_COMM_TO_ORDER_COL, row_num];
				cur_item.txtCommToInvoice_qty = Data[QTY_COMM_TO_INVOICE_COL, row_num];
				cur_item.txtCommToDM_qty = Data[QTY_COMM_TO_DM_COL, row_num];
				cur_item.txtCommToTransfer_qty = Data[QTY_COMM_TO_TRF_COL, row_num];
				cur_item.txtCommToAssembly_qty = Data[QTY_COMM_ASSEMBLY_COL, row_num];
				cur_item.txtCommToSpoilage_qty = Data[QTY_COMM_SPOILAGE_COL, row_num];
				cur_item.txtInTransferOut_qty = Data[QTY_IN_TRF_OUT_COL, row_num];
				cur_item.txtInTransferIn_qty = Data[QTY_IN_TRF_IN_COL, row_num];
				cur_item.txtInRepair_qty = Data[QTY_IN_REPAIR_COL, row_num];
				cur_item.txtInAssembly_qty = Data[QTY_IN_ASSEMBLY_COL, row_num];
				cur_item.txtAvailable_qty = Data[QTY_AVAILABLE_COL, row_num];
				cur_item.txtUnposted_qty = Data[QTY_UNPOSTED_COL, row_num];
				cur_item.txtOrderCost_amt = Data[AMT_ORDER_COST_COL, row_num];
				cur_item.txtCarryCost_amt = Data[AMT_CARRY_COST_COL, row_num];
				cur_item.txtYearlySold_amt = Data[YEARLY_SOLD_COL, row_num];
				cur_item.txtQuarterlySold_qty = Data[QUARTERLY_SOLD_COL, row_num];
				cur_item.txtMonthlySold_amt = Data[MONTHLY_SOLD_COL, row_num];
				cur_item.txtWeeklySold_amt = Data[WEEKLY_SOLD_COL, row_num];
				cur_item.txtRequired_dt = Data[DATE_REQUIRED_COL, row_num];
				cur_item.txtLastSales_dt = Data[DATE_LAST_SALES_COL, row_num];
				cur_item.txtLastSalesRet_dt = Data[DATE_LAST_SALES_RETURN_COL, row_num];
				cur_item.txtLastPurchase_dt = Data[DATE_LAST_PURCHASE_COL, row_num];
				cur_item.txtLastPurchaseRet_dt = Data[DATE_LAST_PURCHASE_RETURN_COL, row_num];
				cur_item.txtLastPhysical_dt = Data[DATE_PHYSICAL_COL, row_num];
				cur_item.txtManufacturer_cd = Data[ITEM_MANUFACTURER_COL, row_num];
				cur_item.txtBrand_cd = Data[ITEM_BRAND_COL, row_num];
				cur_item.txtModel_cd = Data[ITEM_MODEL_COL, row_num];
				cur_item.txtStyle_cd = Data[ITEM_STYLE_COL, row_num];
				cur_item.txtSize_cd = Data[ITEM_SIZE_COL, row_num];
				cur_item.txtColor_cd = Data[ITEM_COLOR_COL, row_num];
				cur_item.txtSource_typ = Data[SOURCE_TYPE_COL, row_num];
				cur_item.txtSource_num = Data[SOURCE_NUM_COL, row_num];
				cur_item.txtSourceDetail_num = Data[SOURCE_DETAIL_COL, row_num];
				cur_item.txtPO_num = Data[PO_NUM_COL, row_num];
				cur_item.txtPODetail_num = Data[PO_DETAIL_COL, row_num];
				cur_item.txtGLAccount_cd = Data[GL_ACCT_CODE_COL, row_num];
				cur_item.txtExtra = Data[EXTRA_COL, row_num];
                cur_item.dtRequired_dt = (oUtility.IsNonEmpty(Data[DATE_REQUIRED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_REQUIRED_COL, row_num]) : null);

                cur_item.txtUserDefined1 = Data[USER_DEFINED1_COL, row_num];
				cur_item.txtUserDefined2 = Data[USER_DEFINED2_COL, row_num];
				cur_item.txtUserDefined3 = Data[USER_DEFINED3_COL, row_num];
				cur_item.txtUserDefined4 = Data[USER_DEFINED4_COL, row_num];
				cur_item.txtUserDefined5 = Data[USER_DEFINED5_COL, row_num];
				cur_item.txtUserDefined1_amt = Data[USER_DEFINED1_AMT_COL, row_num];
				cur_item.txtUserDefined2_amt = Data[USER_DEFINED2_AMT_COL, row_num];
				cur_item.txtUserDefined3_amt = Data[USER_DEFINED3_AMT_COL, row_num];
				cur_item.txtUserDefined4_amt = Data[USER_DEFINED4_AMT_COL, row_num];
				cur_item.txtUserDefined5_amt = Data[USER_DEFINED5_AMT_COL, row_num];
				cur_item.txtUserDefined1_dt = Data[USER_DEFINED1_DT_COL, row_num];
				cur_item.txtUserDefined2_dt = Data[USER_DEFINED2_DT_COL, row_num];
				cur_item.txtUserDefined3_dt = Data[USER_DEFINED3_DT_COL, row_num];
				cur_item.txtUserDefined4_dt = Data[USER_DEFINED4_DT_COL, row_num];
				cur_item.txtUserDefined5_dt = Data[USER_DEFINED5_DT_COL, row_num];
				cur_item.txtUserDefined1_num = Data[USER_DEFINED1_NUM_COL, row_num];
				cur_item.txtUserDefined2_num = Data[USER_DEFINED2_NUM_COL, row_num];
				cur_item.txtUserDefined3_num = Data[USER_DEFINED3_NUM_COL, row_num];
				cur_item.txtUserDefined4_num = Data[USER_DEFINED4_NUM_COL, row_num];
				cur_item.txtUserDefined5_num = Data[USER_DEFINED5_NUM_COL, row_num];
			}
			catch (Exception ex)
            {
				SetPostingError(ex.Message + " (RecreateGridLine)");
			}
			return return_value;

		}

		public bool FindGridLine(int row_num, ref clsGrid line_found)
		{
			bool return_value = false;

			try
            {
				line_found = Grid.Single(i => i.Row_num == row_num);

				if (line_found != null)
                {
					return_value = true;
				}
			}
			catch (Exception ex)
            {
				// in case not found
            }

			return return_value;
		}

		public bool RecreateDetailLine(clsGrid cur_item, int row_num = -1)
        {
            bool return_value = false;

            try
            {
				// If this is called from UI event, get the row number of current line.
				//
                if (row_num < 0)
                {
                    row_num = cur_item.Row_num;
                }

				Data[INCLUDE_COL, row_num] = GlobalVar.goUtility.IIf(cur_item.chkInclude_fl, GlobalVar.goConstant.CHECKED_ON, GlobalVar.goConstant.CHECKED_OFF).ToString();
				Data[ITEM_CODE_COL, row_num] = cur_item.txtItem_cd;
				Data[PRIMARY_ITEM_COL, row_num] = cur_item.txtPrimaryItem_cd;
				Data[ITEM_TYPE_COL, row_num] = cur_item.txtItem_typ;
				Data[TAXABLE_FLAG_COL, row_num] = cur_item.txtTaxable_fl;
				Data[ITEM_NAME_COL, row_num] = cur_item.txtItem_nm;
				Data[COMMENT_COL, row_num] = cur_item.txtComment;
				Data[PURCHASE_UNIT_CODE_COL, row_num] = cur_item.txtPurchaseUnit_cd;
				Data[SELL_UNIT_CODE_COL, row_num] = cur_item.txtSellUnit_cd;
				Data[IVUNIT_CODE_COL, row_num] = cur_item.txtIVUnit_cd;
				Data[UNIT_PRICE_COL, row_num] = cur_item.txtUnitPrice_amt;
				Data[SELL_UNIT_PRICE_COL, row_num] = cur_item.txtSellUnitPrice_amt;
				Data[STD_COST_COL, row_num] = cur_item.txtStdCost_amt;
				Data[AVG_COST_COL, row_num] = cur_item.txtAvgCost_amt;
				Data[LAST_COST_COL, row_num] = cur_item.txtLastCost_amt;
				Data[LAST_VENDOR_COL, row_num] = cur_item.txtLastVendor_cd;
				Data[PREF_VENDOR_COL, row_num] = cur_item.txtPreferredVendor_cd;
				Data[LOCATION_COL, row_num] = cur_item.txtLocation_cd;
				Data[STATUS_COL, row_num] = cur_item.txtStatus_typ;
				Data[BIN_COL, row_num] = cur_item.txtBin_cd;
				Data[MIN_LEVEL_COL, row_num] = cur_item.txtMinLevel_qty;
				Data[MAX_LEVEL_COL, row_num] = cur_item.txtMaxLevel_qty;
				Data[REORDER_LEVEL_COL, row_num] = cur_item.txtReorderLevel_qty;
				Data[QTY_TO_ORDER_COL, row_num] = cur_item.txtToOrder_qty;
				Data[QTY_BACKORDER_COL, row_num] = cur_item.txtBackOrder_qty;
				Data[QTY_ON_ORDER_COL, row_num] = cur_item.txtOnOrder_qty;
				Data[QTY_ON_HAND_COL, row_num] = cur_item.txtOnHand_qty;
				Data[QTY_ALLOC_TO_ORDER_COL, row_num] = cur_item.txtAllocToOrder_qty;
				Data[QTY_ALLOC_TO_ASSEMBLY_COL, row_num] = cur_item.txtAllocToAssembly_qty;
				Data[QTY_COMM_TO_ORDER_COL, row_num] = cur_item.txtCommToOrder_qty;
				Data[QTY_COMM_TO_INVOICE_COL, row_num] = cur_item.txtCommToInvoice_qty;
				Data[QTY_COMM_TO_DM_COL, row_num] = cur_item.txtCommToDM_qty;
				Data[QTY_COMM_TO_TRF_COL, row_num] = cur_item.txtCommToTransfer_qty;
				Data[QTY_COMM_ASSEMBLY_COL, row_num] = cur_item.txtCommToAssembly_qty;
				Data[QTY_COMM_SPOILAGE_COL, row_num] = cur_item.txtCommToSpoilage_qty;
				Data[QTY_IN_TRF_OUT_COL, row_num] = cur_item.txtInTransferOut_qty;
				Data[QTY_IN_TRF_IN_COL, row_num] = cur_item.txtInTransferIn_qty;
				Data[QTY_IN_REPAIR_COL, row_num] = cur_item.txtInRepair_qty;
				Data[QTY_IN_ASSEMBLY_COL, row_num] = cur_item.txtInAssembly_qty;
				Data[QTY_AVAILABLE_COL, row_num] = cur_item.txtAvailable_qty;
				Data[QTY_UNPOSTED_COL, row_num] = cur_item.txtUnposted_qty;
				Data[AMT_ORDER_COST_COL, row_num] = cur_item.txtOrderCost_amt;
				Data[AMT_CARRY_COST_COL, row_num] = cur_item.txtCarryCost_amt;
				Data[YEARLY_SOLD_COL, row_num] = cur_item.txtYearlySold_amt;
				Data[QUARTERLY_SOLD_COL, row_num] = cur_item.txtQuarterlySold_qty;
				Data[MONTHLY_SOLD_COL, row_num] = cur_item.txtMonthlySold_amt;
				Data[WEEKLY_SOLD_COL, row_num] = cur_item.txtWeeklySold_amt;
				Data[DATE_REQUIRED_COL, row_num] = cur_item.txtRequired_dt;
				Data[DATE_LAST_SALES_COL, row_num] = cur_item.txtLastSales_dt;
				Data[DATE_LAST_SALES_RETURN_COL, row_num] = cur_item.txtLastSalesRet_dt;
				Data[DATE_LAST_PURCHASE_COL, row_num] = cur_item.txtLastPurchase_dt;
				Data[DATE_LAST_PURCHASE_RETURN_COL, row_num] = cur_item.txtLastPurchaseRet_dt;
				Data[DATE_PHYSICAL_COL, row_num] = cur_item.txtLastPhysical_dt;
				Data[ITEM_MANUFACTURER_COL, row_num] = cur_item.txtManufacturer_cd;
				Data[ITEM_BRAND_COL, row_num] = cur_item.txtBrand_cd;
				Data[ITEM_MODEL_COL, row_num] = cur_item.txtModel_cd;
				Data[ITEM_STYLE_COL, row_num] = cur_item.txtStyle_cd;
				Data[ITEM_SIZE_COL, row_num] = cur_item.txtSize_cd;
				Data[ITEM_COLOR_COL, row_num] = cur_item.txtColor_cd;
				Data[SOURCE_TYPE_COL, row_num] = cur_item.txtSource_typ;
				Data[SOURCE_NUM_COL, row_num] = cur_item.txtSource_num;
				Data[SOURCE_DETAIL_COL, row_num] = cur_item.txtSourceDetail_num;
				Data[PO_NUM_COL, row_num] = cur_item.txtPO_num;
				Data[PO_DETAIL_COL, row_num] = cur_item.txtPODetail_num;
				Data[GL_ACCT_CODE_COL, row_num] = cur_item.txtGLAccount_cd;
				Data[EXTRA_COL, row_num] = cur_item.txtExtra;

				Data[USER_DEFINED1_COL, row_num] = cur_item.txtUserDefined1;
				Data[USER_DEFINED2_COL, row_num] = cur_item.txtUserDefined2;
				Data[USER_DEFINED3_COL, row_num] = cur_item.txtUserDefined3;
				Data[USER_DEFINED4_COL, row_num] = cur_item.txtUserDefined4;
				Data[USER_DEFINED5_COL, row_num] = cur_item.txtUserDefined5;
				Data[USER_DEFINED1_AMT_COL, row_num] = cur_item.txtUserDefined1_amt;
				Data[USER_DEFINED2_AMT_COL, row_num] = cur_item.txtUserDefined2_amt;
				Data[USER_DEFINED3_AMT_COL, row_num] = cur_item.txtUserDefined3_amt;
				Data[USER_DEFINED4_AMT_COL, row_num] = cur_item.txtUserDefined4_amt;
				Data[USER_DEFINED5_AMT_COL, row_num] = cur_item.txtUserDefined5_amt;
				Data[USER_DEFINED1_DT_COL, row_num] = cur_item.txtUserDefined1_dt;
				Data[USER_DEFINED2_DT_COL, row_num] = cur_item.txtUserDefined2_dt;
				Data[USER_DEFINED3_DT_COL, row_num] = cur_item.txtUserDefined3_dt;
				Data[USER_DEFINED4_DT_COL, row_num] = cur_item.txtUserDefined4_dt;
				Data[USER_DEFINED5_DT_COL, row_num] = cur_item.txtUserDefined5_dt;
				Data[USER_DEFINED1_NUM_COL, row_num] = cur_item.txtUserDefined1_num;
				Data[USER_DEFINED2_NUM_COL, row_num] = cur_item.txtUserDefined2_num;
				Data[USER_DEFINED3_NUM_COL, row_num] = cur_item.txtUserDefined3_num;
				Data[USER_DEFINED4_NUM_COL, row_num] = cur_item.txtUserDefined4_num;
				Data[USER_DEFINED5_NUM_COL, row_num] = cur_item.txtUserDefined5_num;

				return_value = true;

            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (RecreateDetailLine)");
            }

            return return_value;
        }

        public bool RecreateGrid()                                                             //  Create Grid according to Data
        {
            bool return_value = false;
            int row_num = 0;

            try
            {
				Grid.Clear();

				if (Data == null)
                {
                    return true;
                }
                else if (Data.GetLength(1) == 0)
                {
                    return true;
                }

                iTotalRows = Data.GetLength(1);

                for (row_num = 0; row_num < iTotalRows; row_num++)
                {
                    Grid.Add(new clsGrid { Row_num = row_num
								, chkInclude_fl = (GlobalVar.goUtility.ToInteger(Data[INCLUDE_COL, row_num]) == GlobalVar.goConstant.CHECKED_ON)
								, txtItem_cd = Data[ITEM_CODE_COL, row_num] 
								, txtPrimaryItem_cd = Data[PRIMARY_ITEM_COL, row_num]
								, txtItem_typ = Data[ITEM_TYPE_COL, row_num]
								, txtTaxable_fl = Data[TAXABLE_FLAG_COL, row_num]
								, txtItem_nm = Data[ITEM_NAME_COL, row_num]
								, txtComment = Data[COMMENT_COL, row_num]
								, txtPurchaseUnit_cd = Data[PURCHASE_UNIT_CODE_COL, row_num]
								, txtSellUnit_cd = Data[SELL_UNIT_CODE_COL, row_num]
								, txtIVUnit_cd = Data[IVUNIT_CODE_COL, row_num]
								, txtUnitPrice_amt = Data[UNIT_PRICE_COL, row_num]
								, txtSellUnitPrice_amt = Data[SELL_UNIT_PRICE_COL, row_num]
								, txtStdCost_amt = Data[STD_COST_COL, row_num]
								, txtAvgCost_amt = Data[AVG_COST_COL, row_num]
								, txtLastCost_amt = Data[LAST_COST_COL, row_num]
								, txtLastVendor_cd = Data[LAST_VENDOR_COL, row_num]
								, txtPreferredVendor_cd = Data[PREF_VENDOR_COL, row_num]
								, txtLocation_cd = Data[LOCATION_COL, row_num]
								, txtStatus_typ = Data[STATUS_COL, row_num]
								, txtBin_cd = Data[BIN_COL, row_num]
								, txtMinLevel_qty = Data[MIN_LEVEL_COL, row_num]
								, txtMaxLevel_qty = Data[MAX_LEVEL_COL, row_num]
								, txtReorderLevel_qty = Data[REORDER_LEVEL_COL, row_num]
								, txtToOrder_qty = Data[QTY_TO_ORDER_COL, row_num]
								, txtBackOrder_qty = Data[QTY_BACKORDER_COL, row_num]
								, txtOnOrder_qty = Data[QTY_ON_ORDER_COL, row_num]
								, txtOnHand_qty = Data[QTY_ON_HAND_COL, row_num]
								, txtAllocToOrder_qty = Data[QTY_ALLOC_TO_ORDER_COL, row_num]
								, txtAllocToAssembly_qty = Data[QTY_ALLOC_TO_ASSEMBLY_COL, row_num]
								, txtCommToOrder_qty = Data[QTY_COMM_TO_ORDER_COL, row_num]
								, txtCommToInvoice_qty = Data[QTY_COMM_TO_INVOICE_COL, row_num]
								, txtCommToDM_qty = Data[QTY_COMM_TO_DM_COL, row_num]
								, txtCommToTransfer_qty = Data[QTY_COMM_TO_TRF_COL, row_num]
								, txtCommToAssembly_qty = Data[QTY_COMM_ASSEMBLY_COL, row_num]
								, txtCommToSpoilage_qty = Data[QTY_COMM_SPOILAGE_COL, row_num]
								, txtInTransferOut_qty = Data[QTY_IN_TRF_OUT_COL, row_num]
								, txtInTransferIn_qty = Data[QTY_IN_TRF_IN_COL, row_num]
								, txtInRepair_qty = Data[QTY_IN_REPAIR_COL, row_num]
								, txtInAssembly_qty = Data[QTY_IN_ASSEMBLY_COL, row_num]
								, txtAvailable_qty = Data[QTY_AVAILABLE_COL, row_num]
								, txtUnposted_qty = Data[QTY_UNPOSTED_COL, row_num]
								, txtOrderCost_amt = Data[AMT_ORDER_COST_COL, row_num]
								, txtCarryCost_amt = Data[AMT_CARRY_COST_COL, row_num]
								, txtYearlySold_amt = Data[YEARLY_SOLD_COL, row_num]
								, txtQuarterlySold_qty = Data[QUARTERLY_SOLD_COL, row_num]
								, txtMonthlySold_amt = Data[MONTHLY_SOLD_COL, row_num]
								, txtWeeklySold_amt = Data[WEEKLY_SOLD_COL, row_num]
								, txtRequired_dt = Data[DATE_REQUIRED_COL, row_num]
								, txtLastSales_dt = Data[DATE_LAST_SALES_COL, row_num]
								, txtLastSalesRet_dt = Data[DATE_LAST_SALES_RETURN_COL, row_num]
								, txtLastPurchase_dt = Data[DATE_LAST_PURCHASE_COL, row_num]
								, txtLastPurchaseRet_dt = Data[DATE_LAST_PURCHASE_RETURN_COL, row_num]
								, txtLastPhysical_dt = Data[DATE_PHYSICAL_COL, row_num]
								, txtManufacturer_cd = Data[ITEM_MANUFACTURER_COL, row_num]
								, txtBrand_cd = Data[ITEM_BRAND_COL, row_num]
								, txtModel_cd = Data[ITEM_MODEL_COL, row_num]
								, txtStyle_cd = Data[ITEM_STYLE_COL, row_num]
								, txtSize_cd = Data[ITEM_SIZE_COL, row_num]
								, txtColor_cd = Data[ITEM_COLOR_COL, row_num]
								, txtSource_typ = Data[SOURCE_TYPE_COL, row_num]
								, txtSource_num = Data[SOURCE_NUM_COL, row_num]
								, txtSourceDetail_num = Data[SOURCE_DETAIL_COL, row_num]
								, txtPO_num = Data[PO_NUM_COL, row_num]
								, txtPODetail_num = Data[PO_DETAIL_COL, row_num]
								, txtGLAccount_cd = Data[GL_ACCT_CODE_COL, row_num]
								, txtExtra = Data[EXTRA_COL, row_num]
								, dtRequired_dt = (oUtility.IsNonEmpty(Data[DATE_REQUIRED_COL, row_num]) ? oUtility.ToDateTime(Data[DATE_REQUIRED_COL, row_num]) : null)

								, txtUserDefined1 = Data[USER_DEFINED1_COL, row_num]
								, txtUserDefined2 = Data[USER_DEFINED2_COL, row_num]
								, txtUserDefined3 = Data[USER_DEFINED3_COL, row_num]
								, txtUserDefined4 = Data[USER_DEFINED4_COL, row_num]
								, txtUserDefined5 = Data[USER_DEFINED5_COL, row_num]
								, txtUserDefined1_amt = Data[USER_DEFINED1_AMT_COL, row_num]
								, txtUserDefined2_amt = Data[USER_DEFINED2_AMT_COL, row_num]
								, txtUserDefined3_amt = Data[USER_DEFINED3_AMT_COL, row_num]
								, txtUserDefined4_amt = Data[USER_DEFINED4_AMT_COL, row_num]
								, txtUserDefined5_amt = Data[USER_DEFINED5_AMT_COL, row_num]
								, txtUserDefined1_dt = Data[USER_DEFINED1_DT_COL, row_num]
								, txtUserDefined2_dt = Data[USER_DEFINED2_DT_COL, row_num]
								, txtUserDefined3_dt = Data[USER_DEFINED3_DT_COL, row_num]
								, txtUserDefined4_dt = Data[USER_DEFINED4_DT_COL, row_num]
								, txtUserDefined5_dt = Data[USER_DEFINED5_DT_COL, row_num]
								, txtUserDefined1_num = Data[USER_DEFINED1_NUM_COL, row_num]
								, txtUserDefined2_num = Data[USER_DEFINED2_NUM_COL, row_num]
								, txtUserDefined3_num = Data[USER_DEFINED3_NUM_COL, row_num]
								, txtUserDefined4_num = Data[USER_DEFINED4_NUM_COL, row_num]
								, txtUserDefined5_num = Data[USER_DEFINED5_NUM_COL, row_num]
                    });
                }

				return_value = true;
            }
            catch (Exception ex)
            {
				SetPostingError(ex.Message + " (RecreateGrid)");
            }

            return return_value;
        }

	}

}
