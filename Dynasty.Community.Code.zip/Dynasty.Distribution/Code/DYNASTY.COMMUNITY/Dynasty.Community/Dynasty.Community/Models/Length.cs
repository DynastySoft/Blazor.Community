﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dynasty.ASP.Models
{
    internal static class Length
    {
        public const string ACCOUNT_CODE = "40";                // G/L Account
        public const string ACCOUNT_NAME = "60";
        public const string ADDRESS = "40";                     // One address line fpr customer & vendor
        public const string CITY = "30";
        public const string COMMENT = "250";                    // General comments.  there maybe exceptions
        public const string CUSTOMER_CODE = "30";
        public const string CUSTOMER_NAME = "40";
        public const string DOCUMENT = "30";
        public const string EMAIL_ADDRESS = "40";               // General email address 
        public const string INTEGER = "10";                     // Inventory item
        public const string ITEM_CODE = "30";                   // Inventory item
        public const string KEY_CODE = "10";                    // Primary key code other than customer, vendor, inventory & G/L account
        public const string KEY_DESCRIPTION = "40";             // General code description 
        public const string MONEY = "12";
        public const string NAME = "40";                        // General entity name
        public const string PHONE = "20";
        public const string QUANTITY = "10";                    // general quantity
        public const string REFERENCE = "20";                   // General reference 
        public const string SERIAL = "40";                      // Serial/Lot number
        public const string SORT_KEY = "30";                    // Extra sort keys in customer, vendor & item master
        public const string STATE = "20";
        public const string TRX_NUM = "10";                 
        public const string VENDOR_CODE = "30";
        public const string VENDOR_NAME = "40";                 

    }
}
