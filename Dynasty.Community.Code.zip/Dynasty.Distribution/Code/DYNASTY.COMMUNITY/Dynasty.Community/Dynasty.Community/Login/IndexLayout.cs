﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written approval from the manufacturer is strictly prohibited by the International Copyright Law.
//
using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using System.Linq;
using System.Threading.Tasks;

using Dynasty.Database;
using Dynasty.Local;
using System.Collections.Generic;
using System.Collections;
using Microsoft.AspNetCore.Components.Web;

namespace Dynasty.ASP.Login
{
    public partial class IndexLayout
    {
        //  ===============================================================================================================================================================================================================================
        //  GENERIC-DECLATION SECTION  :  Generic variables and properties used in most code-behind.    
        //  ===============================================================================================================================================================================================================================
        private Models.clsPage moPage;                                                              // ....... Keeps the current page/record info & status

        //  ===============================================================================================================================================================================================================================
        //  PAGE-DECLATION SECTION  :  Page-specific variables and properties.    NAMIMG CONVENSTION:  Each starts with "m" followed by a letter indicating data type
        //  ===============================================================================================================================================================================================================================
        private clsDatabase moDatabase;
        private clsGeneral moGeneral;
        private clsMail moMail;
        private clsDynastyUtility moUtility;

        private bool ShowLogin { get; set; } = false;

        private List<Models.clsCombobox> CompanyList = new List<Models.clsCombobox>();

        private bool MultiCompany
        {
            get { return (CompanyList.Count > 1); }
        }


        //  ===============================================================================================================================================================================================================================
        //  HEADER/DETAIL SECTION  :  UI-binding variables and properties.    
        //                            Naming convention:  regular textbox starts with "txt", date textbox with "msk", datetime with "dt", combox/dropdown with "cbo", checkbox with "chk" & radio/option button with "opt"
        //  ===============================================================================================================================================================================================================================
        private class clsHeader
        {
            // Listing of UI items on the header
            //
            public string cboCompany_nm = "";
            public string txtUser_cd = "";
            public string txtPassword = "";

            // Listing of significant fields for the page event-handlers to check if data has changed.
            //
            public class clsTag
            {
                public string cboCompany_nm = "";
                public string txtUser_cd = "";
                public string txtPassword = "";
            }

            public clsTag Tag = new clsTag();

            // Preserve the value of significant fields that have been updated in this postback.
            //
            public void Preserve()
            {
                Tag.cboCompany_nm = cboCompany_nm;
                Tag.txtUser_cd = txtUser_cd;
                Tag.txtPassword = txtPassword;
            }
        }
        private clsHeader Header = new clsHeader();

        //  ===============================================================================================================================================================================================================================
        //  SYSTEM SECTION  :  System methods
        //  ===============================================================================================================================================================================================================================
        protected override void OnInitialized()                                                    // Called once only when this page is loaded
        {
            try
            {
                base.OnInitialized();

                // All page initializations come in this section.
                //
                FormInit();
                FormLoad();

                // User login-info will be reset when this page is called when logged out of other pages.
                //
                User.Clear();

                //Header.cboCompany_nm = "erp001";
                //Header.txtPassword = "sa";
                //Header.txtUser_cd = "sa";

                // Loading is complete
                moPage.bLoading_fl = false;
            }
            catch
            {

            }
        }
        protected override void OnAfterRender(bool first_render_fl)                                // Called after each page-redering.  (first_render_fl == true) only for the first time.
        {
            try
            {
                FormHideField(GlobalVar.goConstant.SPINNER_IMAGE_SMALL);

                // Do clean-ups such as DB discunnection if need to stay offline.
                moDatabase.CloseDatabase();
            }
            catch { }

        }

        //  ===============================================================================================================================================================================================================================
        //  HEADER EVENT HANDLER SECTION  :  UI-component event handlers.                        
        //                                   Naming convention:  Each method name should end with "_Changed" or "_Clicked" proceeded by the component name.
        //                                   IMPORTANT : All event postbacks need to call FormPreEvent() before anything else
        //  ===============================================================================================================================================================================================================================
        private bool cmdLoginOK_Clicked()
        {
            FormPreEvent();
      
            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE_SMALL, false);

            if (LoginOk() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdForgotPassword_Clicked()
        {
            FormPreEvent();

            if (ForgotPassword() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        private bool cmdLoginCancel_Clicked()
        {
            FormPreEvent();

            if (LoginCancel() == false)
            {
                return false;
            }

            return FormPostEvent();
        }

        //  ===============================================================================================================================================================================================================================
        //  METHOD SECTION  :  Generic methods whose name appears in most code-behind.          NAMIMG CONVENSTION:  Each method name starts with "Form" and is in Pascal format
        //  ===============================================================================================================================================================================================================================

        private void FormHideField(string field_name, bool hide_fl = true)                          // Hide/Show a UI input object.
        {
            Models.JSFunction.HideField(JSRuntime, moPage, field_name, hide_fl);
        }

        private void FormSetFocus(string field_name)                                                // Sets focus on a UI input object.
        {
            Models.JSFunction.SetFocus(JSRuntime, moPage, field_name);
        }

        private void FormSetValue(string field_name, string field_value)                            // Sets focus on a UI input object.
        {
            Models.JSFunction.SetValue(JSRuntime, moPage, field_name, field_value);
        }

        private bool FormClearMessage()
        {
            moPage.Message.Clear();

            return true;
        }

        private bool FormInit()
        {
            moPage = new Models.clsPage();
            moDatabase = new clsDatabase();
            moGeneral = new clsGeneral( ref moDatabase);

            moMail = new clsMail(ref moDatabase);
            moUtility = new clsDynastyUtility();

            return true;
        }
        private bool FormPostEvent()                                                               // Needs to be at the end of each UI-event.
        {

            // When an event is complete, we preserve the signifient field values that have been updated in this Postback.
            //
            Header.Preserve();

            return true;
        }

        private bool FormPreEvent()                                                          // This needs to be called by all UI-events, UP FRONT, before anything else.
        {
            FormClearMessage();                                                                    // FormClearMessage() will clear the possible message displayed by the last postback

            return true;
        }
        private bool FormLoad()
        {
#if (SaaS)
            moDatabase.bIsSAASVersion_fl = true;
#else
			moDatabase.bIsSAASVersion_fl = false;
#endif

            if (moDatabase.bIsSAASVersion_fl == false)
            {
                modGeneralUtility.GetHomeDirectory(ref moDatabase);
                GlobalVar.goCompany.LoadCompanyNames(ref moDatabase, ref CompanyList);
            }

            FormHideField(GlobalVar.goConstant.SPINNER_IMAGE_SMALL);   

            return true;
        }

        
        private bool FormOpenDatabase()
        {
            if (moDatabase.IsConnected() == false)
            {
                if (modWebUtility.SystemInit(ref moDatabase, User) == false)
                {
                    if (moDatabase.IsErrorFound())
                    {
                        FormShowMessage(moDatabase.GetErrorMessage());
                    }
                    else
                    {
                        FormShowMessage(User.Language.oMessage.DATABASE_CONNECTION_FAILED);
                    }
                    return false;
                }
            }

            return true;
        }

        private bool FormShowMessage(string msg = null, bool error_fl = true)
        {
            if (error_fl)
            {
                moPage.bErrorFound_fl = error_fl;                                                   // Let all others know an eror has occurreed in this postback.
            }

            if (msg == null)
            {
                if (moDatabase.IsErrorFound())
                {
                    msg = moDatabase.GetErrorMessage();
                }
                else
                {
                    msg = "";
                }
            }

            moPage.Message.Show(msg, error_fl);
            return true;
        }

        //  ===============================================================================================================================================================================================================================
        //  SUPPORTIVE-PROCESS SECTION                                                              Extra functions/methods that are needed in event handling.
        //  ===============================================================================================================================================================================================================================
        private bool ForgotPassword ()
        {
            string new_password = "";

            if (moUtility.IsEmpty(Header.cboCompany_nm))
            {
                FormShowMessage(PageMessage.PLEASE_ENTER + PageCaption.COMPANY_NAME);
                return false;
            }
            if (moUtility.IsEmpty(Header.txtUser_cd))
            {
                FormShowMessage(PageMessage.PLEASE_ENTER + PageCaption.USER_ID);
                return false;
            }

            if (LoginOk(true) == false)
            {
                return false;
            }

            if (moUtility.IsEmpty(moDatabase.sSystemEmailAddress))
            {
                FormShowMessage("System email is not set up, yet.");
                return false;
            }

            if (moUtility.IsEmpty(moDatabase.sEmailAddress))
            {
                FormShowMessage("Your email address is not found in the user profile.");
                return false;
            }

            if (moGeneral.ResetPassword(Header.txtUser_cd, ref new_password) == false)
            {
                FormShowMessage();
                return false;
            }

            if (moMail.SendMail("New Password : " + new_password, "Your new password has arrived.", moDatabase.sSystemEmailAddress, moDatabase.sEmailAddress) == false)
            {
                FormShowMessage();
            }
            else
            {
                FormShowMessage("You new password has been sent to " + moDatabase.sEmailAddress + ". Pease, login with the new password, again.", false);
            }

            return true;
        }

        private bool LoginCancel()
        {
            ShowLogin = false;
            FormShowMessage("");

            User.Clear();

            return true;
        }

        private bool LoginOk(bool to_reset_password = false)
        {
            string ipaddress = "";
            string server_name = "";
            string company_name = Header.cboCompany_nm;
            string user_id = "";
            string password = "";
            string db_name = "";
            string dsn = "";
            int db_type = 0;
            string[,] company_names = null;

            string user_password = Header.txtPassword;

            if (moDatabase.bIsSAASVersion_fl || MultiCompany == false)
            {
                if (moUtility.IsEmpty(GlobalVar.gsConnectionString))
                {
                    FormShowMessage("Connection string is not found.");           // in appsettings.json file 
                    return false;
                }

                // Need to switch the database from the system default to the one user entered.
                //
                if (moUtility.GetUserInfoFromConnectionStr(GlobalVar.gsConnectionString, ref server_name, ref db_name, ref user_id, ref password) == false) // This will extract the user id/password.
                {
                    FormShowMessage("Connection string is not properly structured.");
                    return false;
                }

                moDatabase.sDSN = Header.cboCompany_nm;
                moDatabase.sCCN = Header.cboCompany_nm;

                if (moDatabase.bIsSAASVersion_fl)
                {
                    moDatabase.sServer_nm = "";
                    moDatabase.sDatabase_nm = "";
                }
            }
            else 
            {
                // ODBC-based Multi-company
                //
                company_name = Header.cboCompany_nm;

                if (GlobalVar.goCompany.ReadCompanyNames(ref moDatabase, ref company_names) == false)
                {
                    FormShowMessage(PageMessage.READING_COMPANY_FILE_FAILED);
                    return false;
                }
                else if (GlobalVar.goCompany.GetDatabaseNameFromCompanyName(ref moDatabase, ref company_name, ref db_name, ref server_name, ref dsn, ref db_type, "") == false)
                {
                    FormShowMessage(PageMessage.READING_COMPANY_FILE_FAILED);
                    return false; // Not expected
                }

                // IMPORTANT
                // All databases other than SQL Server must use DSN for Crystal Repot.
                //
                moDatabase.sDSN = dsn;                      
                moDatabase.sCCN = db_name;

                // DO NOT DELETE THIS.  When DB is not connected, CopyUserCredentials() will overwrite moDatabase.bUseSQLProcedures_fl with User.bUseSQLProcedures_fl
                //
                User.bUseSQLProcedures_fl = moDatabase.bUseSQLProcedures_fl;

                moDatabase.sServer_nm = server_name;
                moDatabase.sDatabase_nm = db_name;
            }

            if (FormOpenDatabase() == false)
            {
                return false;
            }

            if (to_reset_password)
            {
                if (moDatabase.CheckUser(Header.txtUser_cd, "", false) == false)
                {
                    FormShowMessage(Header.txtUser_cd + PageMessage.IS_INVALID);
                    return false;
                }

                return true;
            }

            if (moDatabase.CheckUser(Header.txtUser_cd, user_password, true) == false)  
            {
                FormShowMessage(PageMessage.LOGIN_FAILED);
                Header.txtPassword = "";
                return false;
            }


            // If this user uses a different language, reset the captions/messages
            //
            if (GlobalVar.goUtility.IsNonEmpty(moDatabase.sLanguage_cd))
            {
                if (modLocalize.ReadLabelFile(ref moDatabase, moDatabase.sLanguage_cd, PageCaption))
                {
                    // Let it go.
                }
                if (modLocalize.ReadMessageFile(ref moDatabase, moDatabase.sLanguage_cd, PageMessage))
                {
                    // Let it go.
                }
                if (modLocalize.ReadStringFile(ref moDatabase, moDatabase.sLanguage_cd, PageString))
                {
                    // Let it go.
                }

                User.Language = moDatabase.oLanguage;
            }

            moGeneral.UpdateLogInHistory(Header.txtUser_cd, ipaddress);

            // Set URL 
            //
            if (moUtility.IsEmpty(User.sWebSite))
            {
                User.sWebSite = NavigationManager.BaseUri;

                if (moUtility.SRight(User.sWebSite, 1) == "/")        // Eliminate the initial /.
                {
                    User.sWebSite = moUtility.SLeft(User.sWebSite, moUtility.SLength(User.sWebSite) - 1);
                }
            }

            User.sCompany_nm = Header.cboCompany_nm;
            User.sUser_cd = Header.txtUser_cd;
            User.sPassword = Header.txtPassword;

            //  Save the credentials that will be available acrossed pages.
            //
            modWebUtility.CopyUserCredentials(ref moDatabase, User);

            User.bConnected_fl = true;          // For the first time, connected.
            ShowLogin = false;

            if (moUtility.IsEmpty(moDatabase.sCurFiscalYear) && GlobalVar.goUtility.IsDirector(moDatabase))
            {
                NavigationManager.NavigateTo(GlobalVar.SETUP_ADVISOR_PAGE_NAME);
            }
            else if (GlobalVar.goUtility.IsDirector(moDatabase) || User.ViewOnly)        // Let demo see the dashboard by default
            {
                NavigationManager.NavigateTo(GlobalVar.DASHBOARD_PAGE_NAME);
            }
            else
            {
                NavigationManager.NavigateTo(GlobalVar.DEFAULT_WEB_PAGE_NAME);
            }

            return true;
        }

        // IMPORTANT :
        // "async Task" is necessary to make GetDimensions() work.
        //
        async Task EnableLogIn()
        {
            Models.clsBrowserService _service = new Models.clsBrowserService(JSRuntime);

            var dimension = await _service.GetDimensions();

            User.iWindowWidth = dimension.Width;
            User.iWindowHeight = dimension.Height;

            if (User.IsMobile)
            {
                User.iLinesToIncrease = 5;
            }
            else
            {
                User.iLinesToIncrease = 10;
            }

            // This will show the login popup.
            //
            ShowLogin = true;

        }

        // ProcessEnterKey() will handle Enter key which will mimic OK button.
        // Issues found:
        //          When login fails, it shows delayed/previous message.
        //          i.e., the first error does not show any message. The second message shows the message for the first trial error. The third shows the seond error. and so on.
        //          Probably it is because of "async", but I do not have resolution for now.  Maybe later.
        //          cmdLoginOK_Clicked() alone works fine.  
        //
        private async void ProcessEnterKey(KeyboardEventArgs e)
        {
            // Without try{}, works in debug mode, but it crashes in Release.  With try{}, it does not work either mode.
            // We will put this on hold until we find a way.
            try
            {
                if (e.Code == "Enter" || e.Code == "NumpadEnter")
                {
                    // Finish input text
                    //
                    Header.cboCompany_nm = await Models.JSFunction.GetValue(JSRuntime, "cboCompany_nm");       // This is to get the actual value of input field. Necessary because this is called before postback.
                    Header.txtUser_cd = await Models.JSFunction.GetValue(JSRuntime, "txtUser_cd");
                    Header.txtPassword = await Models.JSFunction.GetValue(JSRuntime, "txtPassword");

                    if (cmdLoginOK_Clicked() == false)
                    {
                        // nothing
                    }
                }
            }
            catch
            {
                
            }

        }

    }
}
