﻿
namespace Dynasty.ASP
{
    internal class modvbConstant
    {

        //**********************************************************************
        //  THIS FILE IS FROM VB.
        //**********************************************************************

        // DragOver
        public const int ENTER = 0;
        //Public Const LEAVE = 1
        //Public Const OVER = 2

        // Drag (controls)
        public const int Cancel = 0;
        //Public Const BEGIN_DRAG = 1
        //Public Const END_DRAG = 2

        // Arrange Method
        // for MDI Forms
        public const int CASCADE = 0;
        public const int TILE_HORIZONTAL = 1;
        public const int TILE_VERTICAL = 2;
        public const int ARRANGE_ICONS = 3;

        //ZOrder Method
        //Public Const BRINGTOFRONT = 0
        //Public Const SENDTOBACK = 1

        // Key Codes
        public const int KEY_CANCEL = 0x3;
        public const int KEY_BACK = 0x8;
        public const int KEY_TAB = 0x9;
        public const int KEY_CLEAR = 0xC;
        public const int KEY_RETURN = 0xD;
        public const int KEY_SHIFT = 0x10;
        public const int KEY_CONTROL = 0x11;
        //Public Const KEY_MENU = &H12
        //Public Const KEY_PAUSE = &H13
        //Public Const KEY_CAPITAL = &H14
        public const int KEY_ESCAPE = 0x1B;
        public const int KEY_SPACE = 0x20;
        //Public Const KEY_PRIOR = &H21
        //Public Const KEY_NEXT = &H22
        public const int KEY_END = 0x23;
        public const int KEY_HOME = 0x24;
        public const int KEY_LEFT = 0x25;
        public const int KEY_UP = 0x26;
        public const int KEY_RIGHT = 0x27;
        public const int KEY_DOWN = 0x28;
        //Public Const KEY_SELECT = &H29
        //Public Const KEY_PRINT = &H2A
        //Public Const KEY_EXECUTE = &H2B
        //Public Const KEY_SNAPSHOT = &H2C
        public const int KEY_INSERT = 0x2D;
        public const int KEY_DELETE = 0x2E;
        //Public Const KEY_HELP = &H2F

        // KEY_A thru KEY_Z are the same as their ASCII equivalents: 'A' thru 'Z'
        // KEY_0 thru KEY_9 are the same as their ASCII equivalents: '0' thru '9'

        //Public Const KEY_NUMPAD0 = &H60
        //Public Const KEY_NUMPAD1 = &H61
        //Public Const KEY_NUMPAD2 = &H62
        //Public Const KEY_NUMPAD3 = &H63
        //Public Const KEY_NUMPAD4 = &H64
        //Public Const KEY_NUMPAD5 = &H65
        //Public Const KEY_NUMPAD6 = &H66
        //Public Const KEY_NUMPAD7 = &H67
        //Public Const KEY_NUMPAD8 = &H68
        //Public Const KEY_NUMPAD9 = &H69
        //Public Const KEY_MULTIPLY = &H6A
        //Public Const KEY_ADD = &H6B
        //Public Const KEY_SEPARATOR = &H6C
        //Public Const KEY_SUBTRACT = &H6D
        //Public Const KEY_DECIMAL = &H6E
        //Public Const KEY_DIVIDE = &H6F
        public const int KEY_F1 = 0x70;
        public const int KEY_F2 = 0x71;
        public const int KEY_F3 = 0x72;
        public const int KEY_F4 = 0x73;
        public const int KEY_F5 = 0x74;
        public const int KEY_F6 = 0x75;
        public const int KEY_F7 = 0x76;
        public const int KEY_F8 = 0x77;
        public const int KEY_F9 = 0x78;
        public const int KEY_F10 = 0x79;
        public const int KEY_F11 = 0x7A;
        public const int KEY_F12 = 0x7B;
        public const int KEY_F13 = 0x7C;
        public const int KEY_F14 = 0x7D;
        public const int KEY_F15 = 0x7E;
        public const int KEY_F16 = 0x7F;

        //Public Const KEY_NUMLOCK = &H90

        // Colors
        public const int COLOR_BLACK = 0x0;
        public const int COLOR_BLUE = 0xFF0000;

        //Public Const CHECK_BLUE = &HFFFFC0
        //Public Const CHECK_GREEN = &HC0FFC0
        //Public Const CHECK_GREY = &HE0E0E0
        //Public Const CHECK_RED = &HC0C0FF
        //Public Const CHECK_PURPLE = &HFFC0C0
        //Public Const CHECK_MIGENTA = &HFFC0FF

        public const int COLOR_CYAN = 0xFFFF00;
        public const int COLOR_GREY = 0xC0C0C0;
        public const int COLOR_GREEN = 0xFF00;
        public const int COLOR_MAGENTA = 0xFF00FF;
        public const int COLOR_RED = 0xFF;
        public const int COLOR_WHITE = 0xFFFFFF;
        public const int COLOR_YELLOW = 0xFFFF;

        // System Colors
        //Public Const SCROLL_BARS = &H80000000           ' Scroll-bars gray area.
        //Public Const DESKTOP = &H80000001               ' Desktop.
        //Public Const ACTIVE_TITLE_BAR = &H80000002      ' Active window caption.
        //Public Const INACTIVE_TITLE_BAR = &H80000003    ' Inactive window caption.
        //Public Const MENU_BAR = &H80000004              ' Menu background.
        //Public Const WINDOW_BACKGROUND = &H80000005     ' Window background.
        //Public Const WINDOW_FRAME = &H80000006          ' Window frame.
        //Public Const MENU_TEXT = &H80000007             ' Text in menus.
        //Public Const WINDOW_TEXT = &H80000008           ' Text in windows.
        //Public Const GlobalVar.goConstant.TITLE_BAR_TEXT = &H80000009        ' Text in caption, size box, scroll-bar arrow box..
        //Public Const ACTIVE_BORDER = &H8000000A         ' Active window border.
        //Public Const INACTIVE_BORDER = &H8000000B       ' Inactive window border.
        //Public Const APPLICATION_WORKSPACE = &H8000000C ' Background color of multiple document interface (MDI) applications.
        //Public Const HIGHLIGHT = &H8000000D             ' Items selected item in a control.
        //Public Const HIGHLIGHT_TEXT = &H8000000E        ' Text of item selected in a control.
        //Public Const BUTTON_FACE = &H8000000F           ' Face shading on command buttons.
        //Public Const BUTTON_SHADOW = &H80000010         ' Edge shading on command buttons.
        //Public Const GRAY_TEXT = &H80000011             ' Grayed (disabled) text.  This color is set to 0 if the current display driver does not support a solid gray color.
        //Public Const BUTTON_TEXT = &H80000012           ' Text on push buttons.

        // Enumerated Types

        // Align (picture box)
        //Public Const NONE = 0
        //Public Const ALIGN_TOP = 1
        //Public Const ALIGN_BOTTOM = 2

        // Alignment
        //Public Const LEFT_JUSTIFY = 0  ' 0 - Left Justify
        //Public Const RIGHT_JUSTIFY = 1 ' 1 - Right Justify
        //Public Const CENTER = 2        ' 2 - Center

        // BorderStyle (form)
        //Public Const NONE = 0          ' 0 - None
        //Public Const FIXED_SINGLE = 1   ' 1 - Fixed Single
        //Public Const SIZABLE = 2        ' 2 - Sizable (Forms only)
        //Public Const FIXED_DOUBLE = 3   ' 3 - Fixed Double (Forms only)

        // MousePointer

        public const int DEFAULT_Renamed = 0; // 0 - Default
        public const int ARROW = 1; // 1 - Arrow
        public const int CROSSHAIR = 2; // 2 - Cross
        public const int IBEAM = 3; // 3 - I-Beam
        public const int ICON_POINTER = 4; // 4 - Icon
        public const int SIZE_POINTER = 5; // 5 - Size
        public const int SIZE_NE_SW = 6; // 6 - Size NE SW
        public const int SIZE_N_S = 7; // 7 - Size N S
        public const int SIZE_NW_SE = 8; // 8 - Size NW SE
        public const int SIZE_W_E = 9; // 9 - Size W E
        public const int UP_ARROW = 10; // 10 - Up Arrow
        public const int HOURGLASS = 11; // 11 - Hourglass
        public const int NO_DROP = 12; // 12 - No drop

        // DragMode
        //Public Const MANUAL = 0    ' 0 - Manual
        //Public Const AUTOMATIC = 1 ' 1 - Automatic

        // DrawStyle
        //Public Const SOLID = 0        ' 0 - Solid
        //Public Const DASH = 1         ' 1 - Dash
        //Public Const DOT = 2          ' 2 - Dot
        //Public Const DASH_DOT = 3     ' 3 - Dash-Dot
        //Public Const DASH_DOT_DOT = 4 ' 4 - Dash-Dot-Dot
        //Public Const INVISIBLE = 5    ' 5 - Invisible
        //Public Const INSIDE_SOLID = 6 ' 6 - Inside Solid

        // FillStyle
        // Public Const SOLID = 0           ' 0 - Solid
        //Public Const TRANSPARENT = 1       ' 1 - Transparent
        //Public Const HORIZONTAL_LINE = 2   ' 2 - Horizontal Line
        //Public Const VERTICAL_LINE = 3     ' 3 - Vertical Line
        //Public Const UPWARD_DIAGONAL = 4   ' 4 - Upward Diagonal
        //Public Const DOWNWARD_DIAGONAL = 5 ' 5 - Downward Diagonal
        //Public Const CROSS = 6             ' 6 - Cross
        //Public Const DIAGONAL_CROSS = 7    ' 7 - Diagonal Cross

        // LinkMode (kept for VB1.0 compatibility, use new constants instead)
        //Public Const HOT = 1    ' 1 - Hot (controls only)
        //Public Const SERVER = 1 ' 1 - Server (forms only)
        //Public Const COLD = 2   ' 2 - Cold (controls only)

        // ScrollBar
        // Public Const NONE     = 0 ' 0 - None
        //Public Const HORIZONTAL = 1 ' 1 - Horizontal
        //Public Const VERTICAL = 2   ' 2 - Vertical
        //Public Const BOTH = 3       ' 3 - Both

        // WindowState
        //Public Const NORMAL = 0    ' 0 - Normal
        //Public Const MINIMIZED = 1 ' 1 - Minimized
        //Public Const MAXIMIZED = 2 ' 2 - Maximized

        // Check Value
        //Public Const UNCHECKED = 0 ' 0 - Unchecked
        //Public Const CHECKED = 1   ' 1 - Checked
        //Public Const GRAYED = 2    ' 2 - Grayed

        // Function Parameters
        // MsgBox parameters
        public const int MB_OK = 0; // OK button only
        public const int MB_OKCANCEL = 1; // OK and Cancel buttons
        public const int MB_ABORTRETRYIGNORE = 2; // Abort, Retry, and Ignore buttons
        public const int MB_YESNOCANCEL = 3; // Yes, No, and Cancel buttons
        public const int MB_YESNO = 4; // Yes and No buttons
        public const int MB_RETRYCANCEL = 5; // Retry and Cancel buttons

        public const int MB_ICONSTOP = 16; // Critical message
        public const int MB_ICONQUESTION = 32; // Warning query
        public const int MB_ICONEXCLAMATION = 48; // Warning message
        public const int MB_ICONINFORMATION = 64; // Information message

        public const int MB_APPLMODAL = 0; // Application Modal Message Box
        //Public Const MB_DEFBUTTON1 = 0         ' First button is default
        //Public Const MB_DEFBUTTON2 = 256       ' Second button is default
        //Public Const MB_DEFBUTTON3 = 512       ' Third button is default
        //Public Const MB_SYSTEMMODAL = 4096      'System Modal

        // MsgBox return values
        public int IDOK { get { return 1; } }
        public int IDCANCEL { get { return 2; } }
        public int IDABORT { get { return 3; } }
        public int IDRETRY { get { return 4; } }
        public int IDIGNORE { get { return 5; } }
        public int IDYES { get { return 6; } }
        public int IDNO { get { return 7; } }

        // Options property values
        //Public Const DATA_DENYWRITE = &H1
        //Public Const DATA_DENYREAD = &H2
        //Public Const DATA_READONLY = &H4
        //Public Const DATA_APPENDONLY = &H8
        //Public Const DATA_INCONSISTENT = &H10
        //Public Const DATA_CONSISTENT = &H20
        //Public Const DATA_SQLPASSTHROUGH = &H40

        //Common Dialog Control
        //Action Property
        //Public Const DLG_FILE_OPEN = 1
        //Public Const DLG_FILE_SAVE = 2
        //Public Const DLG_COLOR = 3
        //Public Const DLG_FONT = 4
        //Public Const DLG_PRINT = 5
        //Public Const DLG_HELP = 6

        //---------------------------------------
        //Key Status Control
        //---------------------------------------
        //Style
        public const int KEYSTAT_CAPSLOCK = 0;
        public const int KEYSTAT_NUMLOCK = 1;
        public const int KEYSTAT_INSERT = 2;
        public const int KEYSTAT_SCROLLLOCK = 3;

        //Printer Dialog Flags
        public const int PD_ALLPAGES = 0x0;
        public const int PD_SELECTION = 0x1;
        public const int PD_PAGENUMS = 0x2;
        public const int PD_NOSELECTION = 0x4;
        public const int PD_NOPAGENUMS = 0x8;
        public const int PD_COLLATE = 0x10;
        public const int PD_PRINTTOFILE = 0x20;
        public const int PD_PRINTSETUP = 0x40;
        public const int PD_NOWARNING = 0x80;
        public const int PD_RETURNDC = 0x100;
        public const int PD_RETURNIC = 0x200;
        public const int PD_RETURNDEFAULT = 0x400;
        public const int PD_SHOWHELP = 0x800;
        public const int PD_USEDEVMODECOPIES = 0x40000;
        public const int PD_DISABLEPRINTTOFILE = 0x80000;
        public const int PD_HIDEPRINTTOFILE = 0x100000;

        //**********************************************************************
        // This portion is from DATACONS.TXT from VB
        //**********************************************************************

        // Option argument values for CreateDynaset, etc
        public const int DB_DENYWRITE = 0x1;
        public const int DB_DENYREAD = 0x2;
        public const int DB_READONLY = 0x4;
        public const int DB_APPENDONLY = 0x8;
        public const int DB_INCONSISTENT = 0x10;
        public const int DB_CONSISTENT = 0x20;
        public const int DB_SQLPASSTHROUGH = 0x40;
    }
}
