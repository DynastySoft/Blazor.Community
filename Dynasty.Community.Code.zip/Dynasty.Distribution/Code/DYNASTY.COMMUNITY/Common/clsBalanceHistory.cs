﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//



using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Database;
using Dynasty.Local;
using Dynasty.ASP.Pages.SM;

namespace Dynasty.ASP
{
	public class clsBalanceHistory
	{

		public const int APPLY_DATE_COL = 0;
		public const int TRANS_TYPE_TEXT_COL = 1;
		public const int TRANS_NUM_COL = 2;
		public const int CURRENCY_CODE_COL = 3;
		public const int FOREIGN_AMT_COL = 4;
		public const int AMOUNT_COL = 5;
		public const int PAY_DISC_COL = 6;
		public const int RESTOCK_CHG_COL = 7;
		public const int BALANCE_COL = 8;
		public const int ON_ACCT_COL = 9;
		public const int TRANS_TYPE_COL = 10;
		public const int COMMENT_COL = 11;

        public const int TOTAL_COLUMNS = 12;

		public bool GetBalanceHistory(ref clsDatabase cur_db, ref string[,] detail_data, string module_id, string entity_code, string history_year, ref bool foreign_trx_fl)
		{

			bool return_value = false;
			clsRecordset cur_set = null;
			string sql_str = "";
			int row_num = 0;
			string tmp = "";
			bool refund_fl = false;
			int max_col = 0;

			clsRecordset sp_set = null;
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);

			try
			{

				cur_set = new clsRecordset(ref cur_db);
				sp_set = new clsRecordset(ref cur_db);

				if (module_id == clsAPConstant.MODULE_ID)
				{
					sql_str = modConstant.APBALANCE_HISTORY_DYNASET + " WHERE sVendor_cd = '" + entity_code + "'";
				}
				else
				{
					sql_str = modConstant.ARBALANCE_HISTORY_DYNASET + " WHERE sCustomer_cd = '" + entity_code + "'";
				}
				sql_str += " AND NOT (iTransaction_typ = " + GlobalVar.goConstant.TRX_AR_FIN_CHARGE_TYPE.ToString() + " AND iTransaction_num = 0 AND mTransaction_amt = 0)"; // Exclude filler records generated for monthly statement for inactive customers
				sql_str += " AND iApply_dt >= " + history_year + "0000 ORDER BY iApply_dt, iDetail_num";
				if (!cur_set.CreateSnapshot(sql_str))
				{
					return false;
				}
				else if (cur_set.EOF())
                {
					return true;
                }

				if (module_id == clsAPConstant.MODULE_ID)
				{
					sql_str = "SELECT iTransaction_num FROM tblAPPayment WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_PAYMENT_TYPE.ToString() + " AND sVendor_cd = '" + entity_code + "' AND iStatus_typ=" + GlobalVar.goConstant.SP_TRX_NUM.ToString();
				}
				else
				{
					sql_str = "SELECT iTransaction_num FROM tblARPayment WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_RECEIPT_TYPE.ToString() + " AND sCustomer_cd = '" + entity_code + "' AND iStatus_typ=" + GlobalVar.goConstant.NSF_TRX_NUM.ToString();
				}
				sql_str += " ORDER BY iTransaction_num";
				if (!sp_set.CreateSnapshot(sql_str))
				{
					return false;
				}

				row_num = 0;
				foreign_trx_fl = false;

				if (detail_data == null)
                {
					max_col = TOTAL_COLUMNS;
                }
				else if (detail_data.GetLength(0) > TOTAL_COLUMNS)				// Caller may have sent pre-defined array.
                {
					max_col = detail_data.GetLength(0);
				}
				else
                {
					max_col = TOTAL_COLUMNS;
				}

				GlobalVar.goUtility.ResizeDim(ref detail_data, max_col - 1, cur_set.RecordCount() - 1);

				while (!cur_set.EOF())
				{

					if (GlobalVar.goUtility.IsNonEmpty(cur_set.sField("sCurrency_cd")))
					{
						foreign_trx_fl = true;
					}

					refund_fl = false;

					tmp = o_gen.ToStrDate((cur_set.iField("iApply_dt")));
					detail_data[APPLY_DATE_COL, row_num] = tmp;

					if ((cur_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_INVOICE_TYPE)
					{
						tmp = cur_db.oLanguage.oString.STR_INVOICE;
					}
					else if ((cur_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_RECEIPT_TYPE)
					{
						//if (sp_set.FindRecord("iTransaction_num", cur_set.iField("iTransaction_num").ToString()))		// Taken care of comment
						//                  {
						//	tmp = cur_db.oLanguage.oString.STR_RECEIPT + " / " + cur_db.oLanguage.oString.STR_STOPPED;
						//}
						//else
						//{
						tmp = cur_db.oLanguage.oString.STR_RECEIPT;
						//}
					}
					else if ((cur_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_CM_TYPE)
					{
						tmp = cur_db.oLanguage.oString.STR_CM;
					}
					else if ((cur_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_NSF_TYPE)
					{

						// Refund sends mUnused_amt > 0 and mTransaction_amt = 0.
						// NSF sends mTransaction_amt > 0.
						//
                        if (cur_set.iField("iPayment_typ") != GlobalVar.goConstant.MEMO_TYPE_NUM && cur_set.mField("mUnused_amt") >= cur_db.mSmallestMoney_amt && GlobalVar.goUtility.ToValue(o_money.ToStrMoney(cur_set.mField("mTransaction_amt"))) < cur_db.mSmallestMoney_amt)
						{
							refund_fl = true;
							tmp = cur_db.oLanguage.oString.STR_REFUND;
						}
						else
						{
							tmp = cur_db.oLanguage.oString.STR_NSF;
						}

					}
					else if ((cur_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_AR_FIN_CHARGE_TYPE)
					{
						tmp = cur_db.oLanguage.oString.STR_FC;
					}
					else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_PURCHASE_TYPE)
					{
						tmp = cur_db.oLanguage.oString.STR_VOUCHER;
					}
					else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_PAYMENT_TYPE)
					{
						//if (sp_set.FindRecord("iTransaction_num", cur_set.iField("iTransaction_num").ToString()))			Taken care of by comment
						//{
						//	tmp = cur_db.oLanguage.oString.STR_PAYMENT + " / " + cur_db.oLanguage.oString.STR_STOPPED;
						//                  }
						//else
						//{
						tmp = cur_db.oLanguage.oString.STR_PAYMENT;
						//}
					}
					else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_DM_TYPE)
					{
						tmp = cur_db.oLanguage.oString.STR_DM;
					}
					else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_STOP_PAYMENT_TYPE)
					{

						// Refund sends mUnused_amt > 0 and mTransaction_amt = 0.
						// Stop payment sends mTransaction_amt > 0.
						//
						if (cur_set.iField("iPayment_typ") != GlobalVar.goConstant.MEMO_TYPE_NUM && cur_set.mField("mUnused_amt") >= cur_db.mSmallestMoney_amt && cur_set.mField("mTransaction_amt") < cur_db.mSmallestMoney_amt)
						{
							refund_fl = true;
							tmp = cur_db.oLanguage.oString.STR_REFUND;
						}
						else
						{
							tmp = cur_db.oLanguage.oString.STR_STOP_PAYMENT;
						}

					}
					else if (cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_AP_FIN_CHARGE_TYPE)
					{
						tmp = cur_db.oLanguage.oString.STR_FC;
					}

					detail_data[TRANS_TYPE_TEXT_COL, row_num] = tmp;
					detail_data[TRANS_TYPE_COL, row_num] = cur_set.iField("iTransaction_typ").ToString();

					tmp = GlobalVar.goUtility.ToStr((cur_set.iField("iTransaction_num")));
					detail_data[TRANS_NUM_COL, row_num] = tmp;

					// Refund sends mUnused_amt > 0 and mTransaction_amt = 0.
					// NSF/Stop payment sends mTransaction_amt > 0.
					//
					if ((cur_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_NSF_TYPE || cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_STOP_PAYMENT_TYPE)
					{
						if (cur_set.mField("mTransaction_amt") >= cur_db.mSmallestMoney_amt)
						{
							tmp = o_money.ToStrMoney(cur_set.mField("mTransaction_amt"));
						}
						else
						{
							tmp = o_money.ToStrMoney(cur_set.mField("mUnused_amt"));
						}
					}
					else
					{
						tmp = o_money.ToStrMoney((cur_set.mField("mTransaction_amt")));
					}
					detail_data[AMOUNT_COL, row_num] = tmp;

					detail_data[CURRENCY_CODE_COL, row_num] = cur_set.sField("sCurrency_cd").ToString();
					detail_data[FOREIGN_AMT_COL, row_num] = o_money.ToStrMoney(cur_set.mField("mDiscForEarlyPayment_amt"));

					if ((cur_set.mField("mDiscForEarlyPayment_amt")) >= cur_db.mSmallestMoney_amt)
					{
						tmp = o_money.ToStrMoney((cur_set.mField("mDiscForEarlyPayment_amt")));
						detail_data[PAY_DISC_COL, row_num] = tmp;
					}

					if ((cur_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_INVOICE_TYPE || cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_PURCHASE_TYPE)
					{
						if ((cur_set.mField("mRestockCharge_amt")) >= cur_db.mSmallestMoney_amt)
						{
							tmp = o_money.ToStrMoney((cur_set.mField("mRestockCharge_amt")));
							detail_data[RESTOCK_CHG_COL, row_num] = tmp;
						}
					}
					else if ((cur_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_RECEIPT_TYPE || (cur_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_PAYMENT_TYPE)
					{
						if ((cur_set.mField("mUnused_amt")) >= cur_db.mSmallestMoney_amt)
						{
							tmp = o_money.ToStrMoney((cur_set.mField("mUnused_amt")));
							detail_data[ON_ACCT_COL, row_num] = tmp;
						}
						else
						{
							// Payment with the amount on account.
							//
							if ((cur_set.iField("iPayment_typ")) == GlobalVar.goConstant.MEMO_TYPE_NUM)
							{
								tmp = "(" + o_money.ToStrMoney((cur_set.mField("mTransaction_amt"))) + ")";
								detail_data[ON_ACCT_COL, row_num] = tmp;
							}
						}
					}
					else if ((cur_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_CM_TYPE || cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_DM_TYPE)
					{
						if ((cur_set.mField("mUnused_amt")) >= cur_db.mSmallestMoney_amt)
						{
							tmp = o_money.ToStrMoney((cur_set.mField("mUnused_amt")));
							detail_data[ON_ACCT_COL, row_num] = tmp;
						}
						if ((cur_set.mField("mRestockCharge_amt")) >= cur_db.mSmallestMoney_amt)
						{
							tmp = o_money.ToStrMoney((cur_set.mField("mRestockCharge_amt")));
							detail_data[RESTOCK_CHG_COL, row_num] = tmp;
						}
					}
					else if ((cur_set.iField("iTransaction_typ")) == GlobalVar.goConstant.TRX_NSF_TYPE || cur_set.iField("iTransaction_typ") == GlobalVar.goConstant.TRX_STOP_PAYMENT_TYPE)
					{

						if (refund_fl)
						{
							tmp = "(" + o_money.ToStrMoney(cur_set.mField("mUnused_amt")) + ")";
						}
						else if (cur_set.mField("mUnused_amt") >= cur_db.mSmallestMoney_amt) // The original amount-unused.
						{
							if (cur_set.iField("iPayment_typ") == GlobalVar.goConstant.MEMO_TYPE_NUM)
							{
								tmp = o_money.ToStrMoney(cur_set.mField("mUnused_amt"));
							}
							else
							{
								tmp = "(" + o_money.ToStrMoney(cur_set.mField("mUnused_amt")) + ")";
							}
						}
						else
						{
							tmp = "";
						}

						detail_data[ON_ACCT_COL, row_num] = tmp;

					}

					tmp = o_money.ToStrMoney((cur_set.mField("mBalance_amt")));
					detail_data[BALANCE_COL, row_num] = tmp;

					detail_data[CURRENCY_CODE_COL, row_num] = cur_set.sField("sCurrency_cd");
					if (cur_set.mField("mTransactionInFC_amt") > 0)
					{
						detail_data[FOREIGN_AMT_COL, row_num] = o_money.ToStrMoney(cur_set.mField("mTransactionInFC_amt"));
					}

                    detail_data[COMMENT_COL, row_num] = cur_set.sField("sComment");

                    cur_set.MoveNext();
					row_num += 1;

				}

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "((GetBalanceHistory))");

			}

			return return_value;

		}
	}

}
