﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP
{
	internal static class modLocalize
	{
		private static clsDynastyUtility moUtility = new clsDynastyUtility();

		public static bool WriteMenuToFile(ref clsDatabase cur_db, string language_typ)
        {
			bool return_value = false;
			string sql_str = "";
			string form_name = "MAINMENU";

			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{
				// If new menu items are found, add them.
				//
				sql_str = "SELECT COUNT(*) AS iCount FROM tblGOMenuNames";
				sql_str += " WHERE sModule_id = '" + GlobalVar.WEB_MODULE_ID + "' AND sMenu_nm NOT IN (SELECT sMenu_nm FROM tblGOLanguageTranslator WHERE sPage_nm = '" + form_name  + "' AND sLanguage_cd = '" + language_typ + "')";

				if (cur_set.CreateSnapshot(sql_str) == false)
                {
					return false;
                }
				if (cur_set.iField("iCount") == 0)
                {
					return true;
                }

				sql_str = "INSERT INTO tblGOLanguageTranslator (";
				sql_str += "sLanguage_cd";
				sql_str += ",sPage_nm";
				sql_str += ",sOriginal";
				sql_str += ",sLocal";
				sql_str += ",sMenu_nm";
				sql_str += ") SELECT ";
				sql_str += "'" + language_typ + "'";
				sql_str += ",'MAINMENU'";
				sql_str += ",sDescription";
				sql_str += ",sDescription";
				sql_str += ",sMenu_nm";
				sql_str += " FROM tblGOMenuNames";
				sql_str += " WHERE sModule_id = '" + GlobalVar.WEB_MODULE_ID + "'";
                sql_str += " AND sMenu_nm NOT IN (SELECT sMenu_nm FROM tblGOLanguageTranslator WHERE sPage_nm = '" + form_name + "' AND sLanguage_cd = '" + language_typ + "')";

                sql_str += moUtility.SReplace(modMenuUtility.SelectMenuItemsByVersion(ref cur_db, GlobalVar.WEB_MODULE_ID), " WHERE ", " AND ");

#if (SaaS == false)
                sql_str += " AND sWebPage_nm <> 'pathfinder'";      // Let SAAS version have this feature only for now.
#endif

                //sql_str += " ORDER BY sMenu_nm";
                sql_str += " ORDER BY sDisplayOrder_id";

                if (cur_db.ExecuteSQL(sql_str) == false)
                {
					return false;
                }

				return_value = true;

			}
			catch (Exception ex)
            {
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (LocalizeMenu)");
            }

			return return_value;
		}

		// FUNCTION: To write the local constants into the language file
		//
		public static bool WriteLabelToFile(ref clsDatabase cur_db, string language_typ, string[,] captions)
		{
			bool return_value = false;
			int i = 0;
			string sql_str = "";
			string form_name = "CAPTION";

			try
			{
				if (moUtility.IsEmpty(form_name) || moUtility.IsEmpty(language_typ))   // || !cur_db.oLanguage.bNewLabelIsAdded_fl)
				{
					return false;
				}

				sql_str = "DELETE FROM tblGOLanguageTranslator";
				sql_str += " WHERE sLanguage_cd = '" + language_typ + "'";
				sql_str += " AND sPage_nm = '" + form_name + "'";
				if (cur_db.ExecuteSQL(sql_str) == false)
				{
					return false;
				}

				for (i = 0; i <= captions.GetUpperBound(1); i++)
				{
					if (moUtility.IsNonEmpty(captions[clsConstant.LANGUAGE_ORIGINAL_COL, i]))
                    {
						sql_str = "INSERT INTO tblGOLanguageTranslator(";
						sql_str += " sLanguage_cd";
						sql_str += ",sPage_nm";
						sql_str += ",sOriginal";
						sql_str += ",sLocal";
						sql_str += ",sMenu_nm";
						sql_str += ") VALUES (";
						sql_str += " '" + language_typ + "'";
						sql_str += ",'" + form_name + "'";
						sql_str += ",'" + captions[clsConstant.LANGUAGE_ORIGINAL_COL, i] + "'";
						sql_str += ",'" + captions[clsConstant.LANGUAGE_LOCAL_COL, i] + "'";
						sql_str += ",''";
						sql_str += ")";
						if (cur_db.ExecuteSQL(sql_str) == false)
						{
							return false;
						}
					}
				}

				//cur_db.oLanguage.bLabelFileIsRead_fl = false;
				//cur_db.oLanguage.bNewLabelIsAdded_fl = false;

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (WriteLabelsToFile)");
			}

			return return_value;
		}

		// FUNCTION: To write the local constants into the language file
		//
		public static bool WriteMessageToFile(ref clsDatabase cur_db, string language_typ, string[,] messages)
		{
			bool return_value = false;
			int i = 0;
			string sql_str = "";
			string form_name = "MESSAGE";

			try
			{
				if (moUtility.IsEmpty(form_name) || moUtility.IsEmpty(language_typ))   // || !cur_db.oLanguage.bNewLabelIsAdded_fl)
				{
					return false;
				}

				sql_str = "DELETE FROM tblGOLanguageTranslator";
				sql_str += " WHERE sLanguage_cd = '" + language_typ + "'";
				sql_str += " AND sPage_nm = '" + form_name + "'";
				if (cur_db.ExecuteSQL(sql_str) == false)
				{
					return false;
				}

				for (i = 0; i <= messages.GetUpperBound(1); i++)
				{
					if (moUtility.IsNonEmpty(messages[clsConstant.LANGUAGE_ORIGINAL_COL, i]))
					{
						sql_str = "INSERT INTO tblGOLanguageTranslator(";
						sql_str += " sLanguage_cd";
						sql_str += ",sPage_nm";
						sql_str += ",sOriginal";
						sql_str += ",sLocal";
						sql_str += ",sMenu_nm";
						sql_str += ") VALUES (";
						sql_str += " '" + language_typ + "'";
						sql_str += ",'" + form_name + "'";
						sql_str += ",'" + messages[clsConstant.LANGUAGE_ORIGINAL_COL, i] + "'";
						sql_str += ",'" + messages[clsConstant.LANGUAGE_LOCAL_COL, i] + "'";
						sql_str += ",''";
						sql_str += ")";
						if (cur_db.ExecuteSQL(sql_str) == false)
						{
							return false;
						}
					}
				}

				//cur_db.oLanguage.bLabelFileIsRead_fl = false;
				//cur_db.oLanguage.bNewLabelIsAdded_fl = false;

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (WriteMessageToFile)");
			}

			return return_value;
		}

		// FUNCTION: To write the local constants into the language file
		//
		public static bool WriteStringToFile(ref clsDatabase cur_db, string language_typ, string[,] strings)
		{
			bool return_value = false;
			int i = 0;
			string sql_str = "";
			string form_name = "STRING";

			try
			{
				if (moUtility.IsEmpty(form_name) || moUtility.IsEmpty(language_typ))   // || !cur_db.oLanguage.bNewLabelIsAdded_fl)
				{
					return false;
				}

				sql_str = "DELETE FROM tblGOLanguageTranslator";
				sql_str += " WHERE sLanguage_cd = '" + language_typ + "'";
				sql_str += " AND sPage_nm = '" + form_name + "'";
				if (cur_db.ExecuteSQL(sql_str) == false)
				{
					return false;
				}

				for (i = 0; i <= strings.GetUpperBound(1); i++)
				{
					if (moUtility.IsNonEmpty(strings[clsConstant.LANGUAGE_ORIGINAL_COL, i]))
					{
						sql_str = "INSERT INTO tblGOLanguageTranslator(";
						sql_str += " sLanguage_cd";
						sql_str += ",sPage_nm";
						sql_str += ",sOriginal";
						sql_str += ",sLocal";
						sql_str += ",sMenu_nm";
						sql_str += ") VALUES (";
						sql_str += " '" + language_typ + "'";
						sql_str += ",'" + form_name + "'";
						sql_str += ",'" + strings[clsConstant.LANGUAGE_ORIGINAL_COL, i] + "'";
						sql_str += ",'" + strings[clsConstant.LANGUAGE_LOCAL_COL, i] + "'";
						sql_str += ",''";
						sql_str += ")";
						if (cur_db.ExecuteSQL(sql_str) == false)
						{
							return false;
						}
					}
				}

				//cur_db.oLanguage.bLabelFileIsRead_fl = false;
				//cur_db.oLanguage.bNewLabelIsAdded_fl = false;

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (WriteStringToFile)");
			}

			return return_value;
		}

		public static bool ReadLabelFile(ref clsDatabase cur_db, string language_typ, clsCaption page_caption)
		{
			bool return_value = false;
			string sql_str = "";
			int line_num = 0;
			string form_name = "CAPTION";

			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{
				if (moUtility.IsEmpty(language_typ))
				{
					return true;
				}

				sql_str = "SELECT * FROM tblGOLanguageTranslator ";
				sql_str += " WHERE sLanguage_cd = '" + language_typ + "'";
				sql_str += " AND sPage_nm = '" + form_name + "'";
				sql_str += " ORDER BY sOriginal"; // Make sure sorted by sOriginal because of BinarySearch() later on.
				if (!cur_set.CreateSnapshot(sql_str))
				{
					return false;
				}

				//cur_db.oLanguage.bLabelFileIsRead_fl = true;

                if (cur_set.EOF())
                {
                    cur_db.oLanguage.sLabelCaption = cur_db.oLanguage.oCaption.sCaption;
                    return true;
                }

                moUtility.ResizeDim(ref cur_db.oLanguage.sLabelCaption, clsConstant.LANGUAGE_LOCAL_COL, cur_set.RecordCount() - 1);

                line_num = 0;

				while (!cur_set.EOF())
				{
                    cur_db.oLanguage.sLabelCaption[clsConstant.LANGUAGE_MODULE_COL, line_num] = cur_set.sField("sPage_nm");
                    cur_db.oLanguage.sLabelCaption[clsConstant.LANGUAGE_ORIGINAL_COL, line_num] = cur_set.sField("sOriginal");
                    cur_db.oLanguage.sLabelCaption[clsConstant.LANGUAGE_LOCAL_COL, line_num] = cur_set.sField("sLocal");
                    cur_set.MoveNext();
					line_num += 1;
				}

				// This will make the page-captions available in this user's language.
				//
				page_caption.sCaption = cur_db.oLanguage.sLabelCaption;
				page_caption.InitCaptions(true);
				cur_db.oLanguage.oCaption = page_caption;

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db,  ex.Message + " (ReadLabelToFile)");
			}

			return return_value;
		}

		public static bool ReadMessageFile(ref clsDatabase cur_db, string language_typ, clsMessage page_caption)
		{
			bool return_value = false;
			string sql_str = "";
			int line_num = 0;
			string form_name = "MESSAGE";

			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{
				if (moUtility.IsEmpty(language_typ))
				{
					return true;
				}

				sql_str = "SELECT * FROM tblGOLanguageTranslator ";
				sql_str += " WHERE sLanguage_cd = '" + language_typ + "'";
				sql_str += " AND sPage_nm = '" + form_name + "'";
				sql_str += " ORDER BY sOriginal"; // Make sure sorted by sOriginal because of BinarySearch() later on.
				if (!cur_set.CreateSnapshot(sql_str))
				{
					return false;
				}

				//cur_db.oLanguage.bLabelFileIsRead_fl = true;

				if (cur_set.EOF())
				{
					cur_db.oLanguage.sMessage = cur_db.oLanguage.oMessage.sMessage;
					return true;
				}

				moUtility.ResizeDim(ref cur_db.oLanguage.sMessage, clsConstant.LANGUAGE_LOCAL_COL, cur_set.RecordCount() - 1);

				line_num = 0;

				while (!cur_set.EOF())
				{
					cur_db.oLanguage.sMessage[clsConstant.LANGUAGE_MODULE_COL, line_num] = cur_set.sField("sPage_nm");
					cur_db.oLanguage.sMessage[clsConstant.LANGUAGE_ORIGINAL_COL, line_num] = cur_set.sField("sOriginal");
					cur_db.oLanguage.sMessage[clsConstant.LANGUAGE_LOCAL_COL, line_num] = cur_set.sField("sLocal");
					cur_set.MoveNext();
					line_num += 1;
				}

				// This will make the page-captions available in this user's language.
				//
				page_caption.sMessage = cur_db.oLanguage.sMessage;
				page_caption.InitMessages(true);
				cur_db.oLanguage.oMessage = page_caption;

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (ReadMessageToFile)");
			}

			return return_value;
		}

		public static bool ReadStringFile(ref clsDatabase cur_db, string language_typ, clsString page_caption)
		{
			bool return_value = false;
			string sql_str = "";
			int line_num = 0;
			string form_name = "STRING";

			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{
				if (moUtility.IsEmpty(language_typ))
				{
					return true;
				}

				sql_str = "SELECT * FROM tblGOLanguageTranslator ";
				sql_str += " WHERE sLanguage_cd = '" + language_typ + "'";
				sql_str += " AND sPage_nm = '" + form_name + "'";
				sql_str += " ORDER BY sOriginal"; // Make sure sorted by sOriginal because of BinarySearch() later on.
				if (!cur_set.CreateSnapshot(sql_str))
				{
					return false;
				}

				//cur_db.oLanguage.bLabelFileIsRead_fl = true;

				if (cur_set.EOF())
				{
					cur_db.oLanguage.sString = cur_db.oLanguage.oString.sString;
					return true;
				}

				moUtility.ResizeDim(ref cur_db.oLanguage.sString, clsConstant.LANGUAGE_LOCAL_COL, cur_set.RecordCount() - 1);

				line_num = 0;

				while (!cur_set.EOF())
				{
					cur_db.oLanguage.sString[clsConstant.LANGUAGE_MODULE_COL, line_num] = cur_set.sField("sPage_nm");
					cur_db.oLanguage.sString[clsConstant.LANGUAGE_ORIGINAL_COL, line_num] = cur_set.sField("sOriginal");
					cur_db.oLanguage.sString[clsConstant.LANGUAGE_LOCAL_COL, line_num] = cur_set.sField("sLocal");
					cur_set.MoveNext();
					line_num += 1;
				}

				// This will make the page-captions available in this user's language.
				//
				page_caption.sString = cur_db.oLanguage.sString;
				page_caption.InitStrings(true);
				cur_db.oLanguage.oString = page_caption;

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (ReadStringToFile)");
			}

			return return_value;
		}

	}


}
