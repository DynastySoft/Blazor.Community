﻿
namespace Dynasty.ASP
{
    internal class modCSConstant
    {

        //**********************************************************************
        //  THIS FILE IS FROM C#.
        //**********************************************************************

        // Key Codes
        public const string KEY_BACK = "\b";
        public const string KEY_TAB = "\t";
        public const string KEY_RETURN = "\r";

    }
}
