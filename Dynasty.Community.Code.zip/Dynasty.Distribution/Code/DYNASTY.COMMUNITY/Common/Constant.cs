﻿//  Copyright (c) DynastySoft Corporation, 2001.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


namespace Dynasty.ASP
{
	internal static class modConstant
	{

		// **************************************************************************************************************
		// COMMON CONSTANTS USED BY BOTH, WINDOWS & ASP
		// **************************************************************************************************************
		//

		// These are the module id's in tblGOMenuNames.
		// Should use "LIKE" to select from sDisplayOrder_id at menu loading
		// Should not change unless menu system is revisited.
		//
		public const string WEB_MENU_ORDER_OF_TRANSACTION = "01";
		public const string WEB_MENU_ORDER_OF_LOOKUP = "02";
		public const string WEB_MENU_ORDER_OF_SETUP = "03";
		public const string WEB_MENU_ORDER_OF_REPORT = "04";
		public const string WEB_MENU_ORDER_OF_INQUIRY = "05";
		public const string WEB_MENU_ORDER_OF_CRM = "06";
		public const string WEB_MENU_ORDER_OF_DAILY = "07";

		public const string WEB_MENU_ORDER_OF_SO = "01";
		public const string WEB_MENU_ORDER_OF_AR = "02";
		public const string WEB_MENU_ORDER_OF_PO = "03";
		public const string WEB_MENU_ORDER_OF_AP = "04";
		public const string WEB_MENU_ORDER_OF_GL = "05";
		public const string WEB_MENU_ORDER_OF_NP = "06";
		public const string WEB_MENU_ORDER_OF_IV = "07";
		public const string WEB_MENU_ORDER_OF_WH = "08";
		public const string WEB_MENU_ORDER_OF_RM = "09"; // RMA
		public const string WEB_MENU_ORDER_OF_MF = "10"; // MANUFACTURING
		public const string WEB_MENU_ORDER_OF_WO = "11";
		public const string WEB_MENU_ORDER_OF_JC = "12";
		public const string WEB_MENU_ORDER_OF_PR = "13";
		public const string WEB_MENU_ORDER_OF_HR = "14";
		public const string WEB_MENU_ORDER_OF_BR = "15";
		public const string WEB_MENU_ORDER_OF_FA = "16";
		public const string WEB_MENU_ORDER_OF_CM = "17"; // CRM/Help desk
		public const string WEB_MENU_ORDER_OF_FC = "70";
		public const string WEB_MENU_ORDER_OF_SM = "9_"; // Anything starting with 9 is system-related
		public const string WEB_MENU_ORDER_OF_EN = "100"; // Enterprise features. i.e. 113 means Enterprise-specific payroll
		public const string WEB_MENU_ORDER_OF_PL = "200"; // Platinum features. i.e. 201 means Platinum-specific S/O.

		public const string BLOCK_ACCOUNT_BALANCE = "Block Account Balance";
		public const string BLOCK_APPLY_DATE = "Block Apply Date";
		public const string BLOCK_ENTRY_DATE = "Block Entry Date";
		public const string BLOCK_ITEM_DATA_CHANGE = "Block Item Data Change"; // data change on item screen in other than inventory module.
		public const string BLOCK_ITEM_SCREEN = "Block Item Screen";
		public const string BLOCK_PRICE_CHANGE = "Block Item Price Change"; // Price change at invoice and order entry screen
		public const string BLOCK_TRANSACTION = "Block Transaction";
		public const string BLOCK_PAYMENT_DISCOUNT_CHANGE = "Block Payment Discount";
		public const string DO_NOT_CLOSE_PERIOD = "Do Not Close Period"; // To close the period automatically.
		public const string ALLOW_QUANTITY_ALLOCATION = "Allow Quantity Allocation";
		public const string LOCK_CLOSED_PERIODS = "Lock Closed Periods"; // To prevent entering into closed periods.
		public const string INCLUDE_SERIAL_IN_INVOICE = "Include Serial In Invoice";
		public const string SHIPPING_QA_IS_REQUIRED = "Shipping QA is required";
		public const string SHOW_COLOR_COLUMN = "Show Color Column";
		public const string SHOW_SIZE_COLUMN = "Show Size Column";
		public const string SHOW_MANUFACTURER_COLUMN = "Show Manufacturer Column";
		public const string SHOW_BRAND_COLUMN = "Show Brand Column";
		public const string SHOW_MODEL_COLUMN = "Show Model Column";
		public const string SHOW_STYLE_COLUMN = "Show Style Column";
		public const string SHOW_PURCHASE_PRICE = "Show Purchase Price";
		public const string APPLY_CUSTOMER_PRICING = "Apply Customer Pricing";
		public const string PRINT_DETAILS_ON_CHECK_STUB = "Print details on check stub";
		public const string INVOICE_NUMBERING_BY_CUSTOMER = "Invoice numbering by customer";
		public const string TAX_IS_DISCOUNTABLE = "Tax is discountable";
		public const string FREIGHT_IS_DISCOUNTABLE = "Freight is discountable";
		public const string PRIMARY_RULES_SUBITEMS = "Primary item rules sub-items";
		public const string ALLOW_ITEM_CODE_CHANGE = "Allow item code change";
		public const string EDITABLE_INVOICE_NUMBER = "Make invoice number editable";
		public const string INVOICE_NUMBERING_BY_JOB = "Invoice numbering by job/project";

		public const string SECURITY_MY_FAVORITES = "MyFavorites";
		public const string SECURITY_DASHBOARD = "Dashboard";

		public const string VALIDATE_COLOR_COLUMN = "Validate Color Column";
		public const string VALIDATE_SIZE_COLUMN = "Validate Size Column";
		public const string VALIDATE_MANUFACTURER_COLUMN = "Validate Manufacturer Column";
		public const string VALIDATE_BRAND_COLUMN = "Validate Brand Column";
		public const string VALIDATE_MODEL_COLUMN = "Validate Model Column";
		public const string VALIDATE_STYLE_COLUMN = "Validate Style Column";

		public const string APPLY_SIZE_TO_UNIT_PRICE = "Apply size to unit price";
		public const string LOCK_PRINTED_INVOICE = "Lock printed invoice";
		public const string LOCK_PRINTED_PACKING_SLIP = "Lock printed packing slip";
		public const string USE_MATRIX_FORM = "Use Matrix Form";

		public const string COLOR_CAPTION = "Color Caption";
		public const string SIZE_CAPTION = "Size Caption";
		public const string MANUFACTURER_CAPTION = "Manufacturer Caption";
		public const string BRAND_CAPTION = "Brand Caption";
		public const string MODEL_CAPTION = "Model Caption";
		public const string STYLE_CAPTION = "Style Caption";

		public const string USE_PROCESS_DATE = "Use Process Date";
		public const string PROCESS_ENTRY_DATE = "Process Entry Date";
		public const string PROCESS_APPLY_DATE = "Process Apply Date";
		public const string MAX_TOLERANCE_AMOUNT = "Tolerance Amt";
		public const string FREIGHT_CALCULATION_METHOD = "Freight Calculation Method";

		public const string SMTP_SERVER_NAME = "SMTP Server Name";
		public const string SHOW_ORIGINAL_QTY_ORDERED_ON_INVOICE_QTY = "Show Original Qty Ordered";
		public const string LOCK_POSTED_TRANSACTIONS = "Lock Posted Transactions"; // To lock the posted invoices/vouchers. Only for Lite version that allows editing the posted invoice/vouchers
		public const string SHOW_MESSAGE_ON_TOP_OF_PAGE = "Show Message on Top of Page";

		public const string LOCK_RENTAL_ONECE_BILLED = "Lock Rental Once Bill Starts";
        public const string USE_COMBOBOX_FOR_CASH_ACCOUNTS = "Use Combobox for Cash Accounts";

		public const int DISABLED_COLOR = 0xC0C0C0; // Disabled field color
		public const int EDITABLE_COLOR = 0xFFFFFF; // Editable field color
		public const int COLOR_GRAY = 0xC0C0C0;
		public const int GREY_LIGHT = 0xC0C0C0;
		public const int GREY_DARK = 0x808080;
		public const int ZOOM_COLOR = 0xFFFF00; // Zoomable field color

		public const string SPREAD_MAX_SIZE_ARROW = ">>";
		public const string SPREAD_MIN_SIZE_ARROW = "<<";

		public const string COMPANY_LOGO_FILE_NAME = "company_logo";
		public const string CRYSTAL_LOGO_FUNCTION = "logo_file";

		// *******************************************************************
		// Constants that are used only in the forms.
		// *******************************************************************
		//
		public const int FREIGHT_BY_WEIGHT_NUM = 1;
		public const int FREIGHT_BY_PRICE_NUM = 2;
		public const int FREIGHT_BY_QUANTITY_NUM = 3;
		public const int FREIGHT_BY_UPS_NUM = 4;

		public const int MAX_MY_FAVORITE_BUTTONS = 25;

		// *******************************************************************
		// Item matrix generation options.
		// *******************************************************************
		//
		public const string ITEM_MATRIX = "ITEM_MATRIX";
		public const string ITEM_MATRIX_CODE_SEPARATOR = "CODE_SEPARATOR";
		public const string ITEM_MATRIX_COPY_LABEL = "COPY_LABEL";
		public const string ITEM_MATRIX_COPY_DESCRIPTION = "COPY_DESCRIPTION";
		public const string ITEM_MATRIX_COPY_UNIT_PRICE = "COPY_UNIT_PRICE";
		public const string ITEM_MATRIX_USE_SIZE = "USE_SIZE";
		public const string ITEM_MATRIX_USE_COLOR = "USE_COLOR";
		public const string ITEM_MATRIX_USE_STYLE = "USE_STYLE";
		public const string ITEM_MATRIX_USE_MODEL = "USE_MODEL";
		public const string ITEM_MATRIX_USE_BRAND = "USE_BRAND";
		public const string ITEM_MATRIX_USE_MANUFACTURER = "USE_MANUFACTURER";

		//********************************************************************
		// SQL STATEMENTS to create the recordsets.
		//********************************************************************
		//
		public const string ACCT_DYNASET = "SELECT * FROM tblGLAccount";
		public const string ACCT_DYNASET_ACTUAL_ONLY = "SELECT * FROM tblGLAccount WHERE iSummary_typ = 1";

		public const string APBALANCE_DYNASET = "SELECT * FROM tblAPBalance";
		public const string APBALANCE_HISTORY_DYNASET = "SELECT * FROM tblAPBalanceHistory";
		public const string APCASH_ACCT_DYNASET = "SELECT * FROM tblAPCash";
		public const string APCHARGE_DYNASET = "SELECT * FROM tblAPCharge";
		public const string APCHARGE_DET_DYNASET = "SELECT * FROM tblAPChargeDet";
		public const string APCHARGE_DUE_DYNASET = "SELECT * FROM tblAPChargeDue";
		public const string APCHARGE_PAID_DYNASET = "SELECT * FROM tblAPChargePaidUnposted";
		public const string APCHARGE_UNPOSTED_DYNASET = "SELECT * FROM tblAPChargeUnposted";
		public const string APCHARGE_DET_UNPOSTED_DYNASET = "SELECT * FROM tblAPChargeDetUnposted";
		public const string APCLASS_DYNASET = "SELECT * FROM tblAPClass";

		public const string APMCCHARGE_DYNASET = "SELECT * FROM tblAPMCCharge";
		public const string APMCCHARGE_DET_DYNASET = "SELECT * FROM tblAPMCChargeDet";
		public const string APMCCHARGE_DUE_DYNASET = "SELECT * FROM tblAPMCChargeDue";
		public const string APMCCHARGE_PAID_DYNASET = "SELECT * FROM tblAPMCChargePaidUnposted";
		public const string APMCCHARGE_UNPOSTED_DYNASET = "SELECT * FROM tblAPMCChargeUnposted";
		public const string APMCCHARGE_DET_UNPOSTED_DYNASET = "SELECT * FROM tblAPMCChargeDetUnposted";
		public const string APMCPAYMENT_DYNASET = "SELECT * FROM tblAPMCPayment";
		public const string APMCPAYMENT_DET_DYNASET = "SELECT * FROM tblAPMCPaymentDet";
		public const string APMCPAYMENT_UNPOSTED_DYNASET = "SELECT * FROM tblAPMCPaymentUnposted";
		public const string APMCPAYMENT_DET_UNPOSTED_DYNASET = "SELECT * FROM tblAPMCPaymentDetUnposted";

		public const string APPAYMENT_DYNASET = "SELECT * FROM tblAPPayment";
		public const string APPAYMENT_DET_DYNASET = "SELECT * FROM tblAPPaymentDet";
		public const string APPAYMENT_UNPOSTED_DYNASET = "SELECT * FROM tblAPPaymentUnposted";
		public const string APPAYMENT_DET_UNPOSTED_DYNASET = "SELECT * FROM tblAPPaymentDetUnposted";

		public const string APPOSTING_DYNASET = "SELECT * FROM tblAPAccounts";
		public const string APTAX_DYNASET = "SELECT * FROM tblAPTax";
		public const string APTAXDET_DYNASET = "SELECT * FROM tblAPTaxDet";
		public const string APTERMS_DYNASET = "SELECT * FROM tblAPTerms";

		public const string ARBALANCE_DYNASET = "SELECT * FROM tblARBalance";
		public const string ARBALANCE_HISTORY_DYNASET = "SELECT * FROM tblARBalanceHistory";
		public const string ARCASH_ACCT_DYNASET = "SELECT * FROM tblARCash";
		public const string ARCHARGE_DYNASET = "SELECT * FROM tblARCharge";
		public const string ARCHARGE_COMM_DYNASET = "SELECT * FROM tblARChargeCommUnposted";
		public const string ARCHARGE_DET_DYNASET = "SELECT * FROM tblARChargeDet";
		public const string ARCHARGE_DUE_DYNASET = "SELECT * FROM tblARChargeDue";
		public const string ARCHARGE_PAID_DYNASET = "SELECT * FROM tblARChargePaidUnposted";
		public const string ARCHARGE_UNPOSTED_DYNASET = "SELECT * FROM tblARChargeUnposted";
		public const string ARCHARGE_DET_UNPOSTED_DYNASET = "SELECT * FROM tblARChargeDetUnposted";
		public const string ARCLASS_DYNASET = "SELECT * FROM tblARClass";

		public const string ARMCCHARGE_DYNASET = "SELECT * FROM tblARMCCharge";
		public const string ARMCCHARGE_DET_DYNASET = "SELECT * FROM tblARMCChargeDet";
		public const string ARMCCHARGE_DUE_DYNASET = "SELECT * FROM tblARMCChargeDue";
		public const string ARMCCHARGE_PAID_DYNASET = "SELECT * FROM tblARMCChargePaidUnposted";
		public const string ARMCCHARGE_UNPOSTED_DYNASET = "SELECT * FROM tblARMCChargeUnposted";
		public const string ARMCCHARGE_DET_UNPOSTED_DYNASET = "SELECT * FROM tblARMCChargeDetUnposted";
		public const string ARMCPAYMENT_DYNASET = "SELECT * FROM tblARMCPayment";
		public const string ARMCPAYMENT_DET_DYNASET = "SELECT * FROM tblARMCPaymentDet";
		public const string ARMCPAYMENT_UNPOSTED_DYNASET = "SELECT * FROM tblARMCPaymentUnposted";
		public const string ARMCPAYMENT_DET_UNPOSTED_DYNASET = "SELECT * FROM tblARMCPaymentDetUnposted";

		public const string ARPAYMENT_DYNASET = "SELECT * FROM tblARPayment";
		public const string ARPAYMENT_DET_DYNASET = "SELECT * FROM tblARPaymentDet";
		public const string ARPAYMENT_UNPOSTED_DYNASET = "SELECT * FROM tblARPaymentUnposted";
		public const string ARPAYMENT_DET_UNPOSTED_DYNASET = "SELECT * FROM tblARPaymentDetUnposted";
		public const string ARPOSTING_DYNASET = "SELECT * FROM tblARAccounts";
		public const string ARTAX_DYNASET = "SELECT * FROM tblARTax";
		public const string ARTAXDET_DYNASET = "SELECT * FROM tblARTaxDet";
		public const string ARTERMS_DYNASET = "SELECT * FROM tblARTerms";
		public const string ARTERRITORY_DYNASET = "SELECT * FROM tblARTerritory";

		public const string BANK_DYNASET = "SELECT * FROM tblBRBankAccount";
		public const string BANK_TRANSACTION_DYNASET = "SELECT * FROM tblBRTransaction";
		public const string BEST_PRICE_DYNASET = "SELECT * FROM tblARPriceDet ORDER BY sPrice_cd, sItem_cd desc, fThru_qty";
		public const string BRBALANCE_HISTORY_DYNASET = "SELECT * FROM tblBRBalance";
		public const string BUDGET_DYNASET = "SELECT * FROM tblGLBudget";
		public const string BUDGETDET_DYNASET = "SELECT * FROM tblGLBudgetDet ";
		public const string COLINFO_DYNASET = "SELECT * FROM tblGOColumnSize";
		public const string COMMISSION_DYNASET = "SELECT * FROM tblARCommission";
		public const string CURRENCY_DYNASET = "SELECT * FROM tblBRCurrency";
		public const string CUSTOMER_DYNASET = "SELECT * FROM tblARCustomer";
		public const string DEDUCTION_DYNASET = "SELECT * FROM tblPRDeduct";
		public const string DISCOUNT_DYNASET = "SELECT * FROM tblARDiscount";
		public const string DUNN_DYNASET = "SELECT * FROM tblARDunn";
		public const string EXCHANGE_RATE_DYNASET = "SELECT * FROM tblBRExchangeRate";
		public const string EMPLOYEE_DYNASET = "SELECT * FROM tblGOEmployee";
		public const string FREIGHT_DYNASET = "SELECT * FROM tblARVia";
		public const string GLBAL_DYNASET = "SELECT * FROM tblGLBalance";
		public const string INCOMETAX_DYNASET = "SELECT * FROM tblPRTax";
		public const string IVACCTS_DYNASET = "SELECT * FROM tblIVAccounts";
		public const string IVBALANCE_DYNASET = "SELECT * FROM tblIVBalance";
		public const string IVCLASS_DYNASET = "SELECT * FROM tblIVClass";
		public const string IVCOST_DYNASET = "SELECT * FROM tblIVCost";
		public const string IVITEM_DYNASET = "SELECT * FROM tblIVItem";
		public const string IVITEM_SERIAL_DYNASET = "SELECT * FROM tblIVItemSerial";
		public const string IVITEMKIT_DYNASET = "SELECT * FROM tblIVItemKit";
		public const string IVITEMQTY_DYNASET = "SELECT * FROM tblIVItemQty";
		public const string IVPOSTING_DYNASET = "SELECT * FROM tblIVAccounts";
		public const string IVTRX_DYNASET = "SELECT * FROM tblIVTransaction";
		public const string IVTRX_UNPOSTED_DYNASET = "SELECT * FROM tblIVTransactionUnposted";
		public const string IVTRXDET_DYNASET = "SELECT * FROM tblIVTransactionDet";
		public const string IVTRXDET_UNPOSTED_DYNASET = "SELECT * FROM tblIVTransactionDetUnposted";
		public const string JOB_DYNASET = "SELECT * FROM tblJCJob";
		public const string JOBRENTAL_ITEM_DYNASET = "SELECT * FROM tblJCRentalItem";
		public const string JOBSTATUS_DYNASET = "SELECT * FROM tblJCJobStatus";
		public const string JOBTYPE_DYNASET = "SELECT * FROM tblJCJobType";
		public const string JOBTRANSACTIONTYPE_DYNASET = "SELECT * FROM tblJCTransactionType";
		public const string JOURNAL_DYNASET = "SELECT * FROM tblGLTransactionUnposted";
		public const string JOURNALDET_DYNASET = "SELECT * FROM tblGLTransactionDetUnposted";
		public const string JOURNAL_CODE_DYNASET = "SELECT * FROM tblGLJournalTable";
		public const string LOCATION_DYNASET = "SELECT * FROM tblIVLocation";
		public const string MASTER_DYNASET = "SELECT * FROM tblGOMaster";
		public const string MCPAYMENT_DYNASET = "SELECT * FROM tblAPMCPayment WHERE iTransaction_typ = 4121 AND iStatus_typ = 4 ";
		public const string MCRECEIPT_DYNASET = "SELECT * FROM tblARMCPayment where iTransaction_typ = 3121 AND iStatus_typ = 4 ";
		public const string OPENINVOICE_DYNASET = "SELECT * FROM tblARCharge WHERE ( iTransaction_typ = 3111 or iTransaction_typ = 3141 ) AND mDue_amt <> 0 AND iStatus_typ = 4 ";
		public const string OPENAPCHARGE_UNPOSTED_DYNASET = "SELECT * FROM tblAPChargeUnposted WHERE ( iTransaction_typ = 4111 OR iTransaction_typ = 4141 ) AND mDue_amt <> 0 AND iStatus_typ = 4 ";
		public const string ORDER_DYNASET = "SELECT * FROM tblSOTransaction WHERE iTransaction_typ = 5111";
		public const string OVERTIME_DYNASET = "SELECT * FROM tblPROvertime";
		public const string PAYMENT_DYNASET = "SELECT * FROM tblAPPayment WHERE iTransaction_typ = 4121 AND iStatus_typ = 4 ";
		public const string PAYMENT_DETAIL_DYNASET = "SELECT * FROM tblAPPaymentDet";
		public const string PERIOD_DYNASET = "SELECT * FROM tblGLPeriod";
		public const string PERIODDET_DYNASET = "SELECT * FROM tblGLPeriodDet";
		public const string POTRANS_DET_DYNASET = "SELECT * FROM tblPOTransactionDet";
		public const string POTRANS_PAID_DYNASET = "SELECT * FROM tblPOTransactionPaid";
		public const string POTRANS_DYNASET = "SELECT * FROM tblPOTransaction";
		public const string POSTED_APCHARGE_DYNASET = "SELECT * FROM tblAPCharge WHERE iTransaction_typ = 4111 AND iStatus_typ = 4 ";
		public const string POSTED_APMCCHARGE_DYNASET = "SELECT * FROM tblAPMCCharge WHERE iTransaction_typ = 4111 AND iStatus_typ = 4 ";
		public const string POSTED_ARCHARGE_DYNASET = "SELECT * FROM tblARCharge WHERE ( iTransaction_typ = 3111 OR iTransaction_typ = 3141 ) AND iStatus_typ = 4 ";
		public const string POSTED_ARCHARGE_DET_DYNASET = "SELECT * FROM tblARChargeDet WHERE ( iTransaction_typ = 3111 OR iTransaction_typ = 3141 ) AND iStatus_typ = 4 ";
		public const string POSTED_ARMCCHARGE_DYNASET = "SELECT * FROM tblARCharge WHERE ( iTransaction_typ = 3111 OR iTransaction_typ = 3141 ) AND iStatus_typ = 4 ";
		public const string POSTED_ARMCCHARGE_DET_DYNASET = "SELECT * FROM tblARChargeDet WHERE ( iTransaction_typ = 3111 OR iTransaction_typ = 3141 ) AND iStatus_typ = 4 ";
		public const string POSTED_INVOICE_DYNASET = "SELECT * FROM tblARCharge WHERE iTransaction_typ = 3111 AND iStatus_typ = 4 ";
		public const string POSTED_INVOICE_DET_DYNASET = "SELECT * FROM tblARChargeDet WHERE iTransaction_typ = 3111 AND iStatus_typ = 4 ";
		public const string POSTED_MC_INVOICE_DYNASET = "SELECT * FROM tblARMCCharge WHERE iTransaction_typ = 3111 AND iStatus_typ = 4 ";
		public const string POSTED_MC_INVOICE_DET_DYNASET = "SELECT * FROM tblARMCChargeDet WHERE iTransaction_typ = 3111 AND iStatus_typ = 4 ";
		public const string POSTED_VOUCHER_DYNASET = "SELECT * FROM tblAPCharge WHERE iTransaction_typ = 4111 AND iStatus_typ = 4 ";
		public const string POSTED_VOUCHER_DET_DYNASET = "SELECT * FROM tblAPChargeDet WHERE iTransaction_typ = 4111 AND iStatus_typ = 4 ";
		public const string POSTED_MC_VOUCHER_DYNASET = "SELECT * FROM tblAPMCCharge WHERE iTransaction_typ = 4111 AND iStatus_typ = 4 ";
		public const string POSTED_MC_VOUCHER_DET_DYNASET = "SELECT * FROM tblAPMCChargeDet WHERE iTransaction_typ = 4111 AND iStatus_typ = 4 ";
		public const string PRBAL_DYNASET = "SELECT * FROM tblPRBalance";
		public const string PRBALER_DYNASET = "SELECT * FROM tblPRBalanceER";
		public const string PRDEDUCTION_DYNSET = "SELECT * FROM tblPRDeduct";
		public const string PRDEDUCTTOTAL_DYNSET = "SELECT * FROM tblPRDeductTotal";
		public const string PRDEPARTMENT_DYNSET = "SELECT * FROM tblPRDepartment";
		public const string PRGROUP_DYNASET = "SELECT * FROM tblPRGroup";
		public const string PRWAGE_DYNASET = "SELECT * FROM tblPRExtraWage";
		public const string PRICE_DYNASET = "SELECT * FROM tblARPrice";
		public const string PRJOURNAL_DYNASET = "SELECT * FROM tblPRTransaction";
		public const string PRPOSTING_DYNASET = "SELECT * FROM tblPRAccounts";
		public const string PURCHASEACCT_DYNASET = "SELECT * FROM tblGLAccount where iGroup_typ >= 5000 AND iGroup_typ < 6000 AND iSummary_typ = 1";
		public const string PURCHASE_ORDER_DYNASET = "SELECT * FROM tblPOTransaction WHERE iTransaction_typ = 6111";
		public const string QUOTE_DYNASET = "SELECT * FROM tblSOTransaction WHERE iTransaction_typ = 5121";
		public const string RECEIPT_DYNASET = "SELECT * FROM tblARPayment where iTransaction_typ = 3121 AND iStatus_typ = 4 ";
		public const string REVENUEACCT_DYNASET = "SELECT * FROM tblGLAccount WHERE iGroup_typ >= 4000 and iGroup_typ < 5000 and iSummary_typ = 1";
		public const string SALESREP_DYNASET = "SELECT * FROM tblARSalesrep";
		public const string SEGMENT_DYNASET = "SELECT * FROM tblGLSegment";
		public const string SOTRANS_DYNASET = "SELECT * FROM tblSOTransaction";
		public const string SOTRANS_COMM_DYNASET = "SELECT * FROM tblSOTransactionComm";
		public const string SOTRANS_DET_DYNASET = "SELECT * FROM tblSOTransactionDet";
		public const string SOTRANS_PAID_DYNASET = "SELECT * FROM tblSOTransactionPaid";
		public const string TAXACCT_DYNASET = "SELECT * FROM tblGLAccount WHERE iGroup_typ >= 2000 and iGroup_typ < 3000 and iSummary_typ = 1";
		public const string TRANSACTION_CODE_DYNASET = "SELECT * FROM tblBRTransactionCode";
		public const string UNIT_DYNASET = "SELECT * FROM tblGOunit "; // do not put ORDER BY sItem_cd desc, sFromUnit_cd"
		public const string USER_SECURITY_DYNASET = "SELECT * FROM tblGOUserGroupSecurity";
		public const string VENDOR_CLASS_DYNASET = "SELECT * FROM tblAPClass";
		public const string VENDOR_DYNASET = "SELECT * FROM tblAPVendor";
		public const string WORK_DYNASET = "SELECT * FROM tblPRWork";
	}

}
