﻿
using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP
{
    public class clsInquiry
    {

        private clsDynastyUtility oUtility = new clsDynastyUtility();

        public const string REPORT_NET_SALES = "Net Sales(Sales - Return)";
        public const string REPORT_SALES = "Sales";
        public const string REPORT_SALES_RETURN = "Sales Return";
        public const string REPORT_SEPARATOR = "-";
        public const string REPORT_NET_PURCHASE = "Net Purchase(Purchase - Return)";
        public const string REPORT_PURCHASE = "Purchase";
        public const string REPORT_PURCHASE_RETURN = "Purchase Return";
        public const string REPORT_ASJUSTMENT = "Adjustment";
        public const string REPORT_SPOILAGE = "Spoilage/Internal Use";
        public const string REPORT_NET_TRANSFER = "Net Transfer(In - Out)";
        public const string REPORT_TRANSFER_IN = "Transfer-In";
        public const string REPORT_TRANSFER_OUT = "Transfer-Out";

        public const string REPORT_MFG = "Items Manufactured";
        public const string REPORT_USED_IN_MFG = "Items Used in Mfg.";
        public const string REPORT_ASSEMBLY = "Kit Assembled";
        public const string REPORT_USED_IN_ASSEMBLY = "Items Used in Assembly";
        //Public Const REPORT_DISASSEMBLY As String = "Kit Disassembled"  We do not remember this in balance table
        //Public Const REPORT_NET_ASSEMBLY As String = "Net(Assembly - Disassembly)"

        public const int PERIOD_TYPE_MONTHLY = 1;
        public const int PERIOD_TYPE_QUARTERLY = 2;
        public const int PERIOD_TYPE_YEARLY = 3;
        public const int PERIOD_TYPE_QTD = 4;
        public const int PERIOD_TYPE_YTD = 5;
        public const int PERIOD_TYPE_WEEKLY = 6;
        public const int PERIOD_TYPE_DAILY = 7;

        public const int QUERY_BY_AMOUNT = 1;
        public const int QUERY_BY_FREQUENCY = 2;
        public const int QUERY_BY_QTY = 3;
        public const int QUERY_BY_PROFIT = 4;

        public const int QUERY_BY_NET = 1;
        public const int QUERY_BY_DEBIT = 2;
        public const int QUERY_BY_CREDIT = 3;

        public const int COMPARISON_TYPE_CONSECUTIVE = 1;
        public const int COMPARISON_TYPE_SAME_PERIOD_OF_YEAR = 2;

        public string GetCssClassName(string field_name)
        {

            string return_value = "";
            string tmp = "";

            field_name = oUtility.STrim(oUtility.SUCase(field_name));

            if (oUtility.SRight(field_name, 3) == "_DT" || oUtility.SRight(field_name, 4) == "_TYP")
            {
                tmp = "ATCP";
            }
            else if (oUtility.SLeft(field_name, 1) == "I" && oUtility.SRight(field_name, 4) == "_NUM")
            {
                tmp = "ATCP";
            }
            else if (oUtility.SLeft(field_name, 1) == "I" && (oUtility.SInStr(oUtility.SUCase(field_name), "QTR") > 0 || oUtility.SInStr(oUtility.SUCase(field_name), oUtility.SUCase("Quarter")) > 0))
            {
                tmp = "ATCP";
            }
            else if (oUtility.SLeft(field_name, 1) == "M" || oUtility.SLeft(field_name, 1) == "I" || oUtility.SLeft(field_name, 1) == "F" || oUtility.SRight(field_name, 3) == "QTY")
            {
                tmp = "ATRP";
            }
            else
            {
                tmp = "ATLP";
            }

            return_value = tmp;

            return return_value;

        }

        public bool EmailCSVFile(ref clsDatabase cur_db, string mail_topic, string mail_message, ref string csv_file, string[,] csv_data, string recipient_name = "")
        {

            bool return_value = false;
            int row_num = 0;
            int col_num = 0;
            string line_str = "";
            string tmp = "";
            clsMail o_mail = new clsMail(ref cur_db);
            clsFileIO o_file = new clsFileIO();

            try
            {

                if (oUtility.IsEmpty(recipient_name))
                {
                    recipient_name = cur_db.sEmailAddress;
                }

                if (oUtility.IsEmpty(recipient_name))
                {
                    return false;
                }
                else if (oUtility.IsEmpty(csv_file) && (csv_data == null))
                {
                    return false;
                }

                if (oUtility.IsNonEmpty(csv_file))
                {
                    if (!GlobalVar.goFile.FileExists(csv_file))
                    {
                        return false;
                    }
                }
                else
                {

                    csv_file = cur_db.uDirectory.sCSVExportDirectory_nm + "\\" + oUtility.SFormat(DateTime.Now, cur_db.sUser_cd + "yyMMddss") + ".csv";

                    o_file.OpenFileToWrite(csv_file);

                    for (row_num = 0; row_num < csv_data.GetLength(1); row_num++)
                    {
                        line_str = "";
                        for (col_num = 0; col_num < csv_data.GetLength(0); col_num++)
                        {
                            tmp = "\"" + oUtility.SReplace(csv_data[col_num, row_num], ",", "") + "\""; // comma create an issue in CSV file.
                            line_str += oUtility.IIf(oUtility.IsNonEmpty(line_str), ",", "").ToString() + tmp;
                            modGeneralUtility.RunEvents();
                        }
                        o_file.WriteOneLine(line_str);
                    }

                    o_file.CloseFile();
                    modGeneralUtility.RunEvents();

                }

                return_value = o_mail.SendMail(mail_message, mail_topic, cur_db.sSystemEmailAddress, recipient_name, csv_file);

                if (return_value)
                {
                    modGeneralUtility.RunEvents();
                    GlobalVar.goFile.Remove(csv_file);
                }

            }
            catch
            {
                // Just in case
            }

            return return_value;

        }

        public string SelectMonths(ref clsDatabase cur_db, int comparison_type, string period_from, int total_periods)
        {

            string return_value = "";
            string qtr_from = "";
            string qtr_thru = "";
            string year_from = "";
            string year_thru = "";
            string period_selected = "";
            string year_selected = "";
            string select_str = "";
            int full_years = 0;
            int temp = 0;
            int i = 0;

            try
            {

                // period_from has period_id such as 1, 2, 3, ...
                period_selected = oUtility.SRight("00" + period_from, 2);
                year_selected = cur_db.sCurFiscalYear;

                if (comparison_type == COMPARISON_TYPE_SAME_PERIOD_OF_YEAR)
                {
                    select_str = " WHERE sFiscalYear BETWEEN '" + (oUtility.ToInteger(year_selected) - total_periods + 1).ToString() + "' AND  '" + year_selected + "'";
                    select_str += " AND  iPeriod_id = " + oUtility.ToInteger(period_selected).ToString();
                }
                else
                {
                    qtr_thru = period_selected;
                    year_thru = year_selected;

                    if (total_periods <= oUtility.ToInteger(period_selected)) //The same year
                    {
                        select_str = " WHERE sFiscalYear = '" + year_selected + "'";
                        select_str += " AND  iPeriod_id BETWEEN " + (oUtility.ToInteger(period_selected) - total_periods + 1) + " AND " + period_selected;
                    }
                    else
                    {
                        full_years = Convert.ToInt32(total_periods - oUtility.ToInteger(period_selected)) / 12;
                        temp = (total_periods - oUtility.ToInteger(period_selected)) - (full_years * 12);
                        qtr_from = (12 - temp + 1).ToString(); // Starting qtr
                        year_from = (oUtility.ToInteger(year_selected) - full_years - 1).ToString(); // starting year

                        select_str = " WHERE iPeriod_id > 0";
                        select_str += " AND (";
                        select_str += " (sFiscalYear = '" + year_selected + "' AND  iPeriod_id <= " + period_selected + ")"; // Last year
                        select_str += " OR (sFiscalYear = '" + year_from + "' AND  iPeriod_id >= " + qtr_from + ")"; // First year
                        for (i = 1; i <= full_years; i++)
                        {
                            select_str += " OR (sFiscalYear = '" + (oUtility.ToInteger(year_selected) - i).ToString() + "')";
                        }
                        select_str += ")";
                    }

                }

                return_value = select_str;

            }
            catch
            {
                // Just in case
            }

            return return_value;

        }

        public string SelectYears(ref clsDatabase cur_db, int comparison_type, string period_from, int total_periods)
        {

            string return_value = "";
            string period_selected = "";
            string year_selected = "";
            string select_str = "";

            year_selected = period_from;

            select_str = " WHERE sFiscalYear BETWEEN '" + (oUtility.ToInteger(year_selected) - total_periods + 1).ToString() + "' AND '" + year_selected + "'";
            select_str += " AND  iQuarter = 0";

            return_value = select_str;

            return return_value;

        }

        public string SelectPRYears(ref clsDatabase cur_db, int comparison_type, string period_from, int total_periods)
        {

            string return_value = "";
            string period_selected = "";
            string year_selected = "";
            string select_str = "";

            year_selected = period_from;

            select_str = " WHERE sFiscalYear BETWEEN '" + (oUtility.ToInteger(year_selected) - total_periods + 1).ToString() + "' AND '" + year_selected + "'";

            return_value = select_str;

            return return_value;

        }

        public string SelectGLYears(ref clsDatabase cur_db, int comparison_type, string period_from, int total_periods)
        {

            string return_value = "";
            string period_selected = "";
            string year_selected = "";
            string select_str = "";

            year_selected = period_from;

            select_str = " WHERE sFiscalYear BETWEEN '" + (oUtility.ToInteger(year_selected) - total_periods + 1).ToString() + "' AND '" + year_selected + "'";
            select_str += " AND  iQuarter = 4";
            select_str += " AND  iQuarter_typ = 3";

            return_value = select_str;

            return return_value;

        }

        public string SelectYTD(ref clsDatabase cur_db, int comparison_type, string period_from, int total_periods)
        {

            string return_value = "";
            string period_selected = "";
            string year_selected = "";
            string select_str = "";

            period_selected = oUtility.SRight("00" + period_from, 2).ToString();
            year_selected = cur_db.sCurFiscalYear;

            select_str = " WHERE sFiscalYear BETWEEN '" + (oUtility.ToInteger(year_selected) - total_periods + 1).ToString() + "' AND '" + year_selected + "'";
            select_str += " AND  iPeriod_id BETWEEN 1 AND " + oUtility.ToInteger(period_selected).ToString();

            return_value = select_str;

            return return_value;

        }

        public string SelectGLYTD(ref clsDatabase cur_db, int comparison_type, string period_from, int total_periods)
        {

            string return_value = "";
            string period_selected = "";
            string year_selected = "";
            string select_str = "";

            period_selected = oUtility.SRight("00" + period_from, 2).ToString();
            year_selected = cur_db.sCurFiscalYear;

            select_str = " WHERE sFiscalYear BETWEEN '" + (oUtility.ToInteger(year_selected) - total_periods + 1).ToString() + "' AND '" + year_selected + "'";
            select_str += " AND  iPeriod_id = " + oUtility.ToInteger(period_selected).ToString();

            return_value = select_str;

            return return_value;

        }

        public string SelectQuarters(ref clsDatabase cur_db, int comparison_type, string period_from, int total_periods)
        {

            string return_value = "";
            string qtr_from = "";
            string qtr_thru = "";
            string year_from = "";
            string year_thru = "";
            string period_selected = "";
            string year_selected = "";
            string select_str = "";
            int full_years = 0;
            int temp = 0;
            int i = 0;

            try
            {

                period_selected = oUtility.SRight(period_from, 1);
                year_selected = oUtility.SLeft(period_from, 4);

                if (comparison_type == COMPARISON_TYPE_SAME_PERIOD_OF_YEAR)
                {
                    select_str = " WHERE sFiscalYear BETWEEN '" + (oUtility.ToInteger(year_selected) - total_periods + 1).ToString() + "' AND '" + year_selected + "'";
                    select_str += " AND  iQuarter = " + oUtility.ToInteger(period_selected).ToString();
                    select_str += " AND  iPeriodBegin_dt = 0";
                }
                else
                {
                    qtr_thru = period_selected;
                    year_thru = year_selected;

                    if (total_periods <= oUtility.ToInteger(period_selected)) //The same year
                    {
                        select_str = " WHERE sFiscalYear = '" + year_selected + "'";
                        select_str += " AND  iQuarter BETWEEN " + (oUtility.ToInteger(period_selected) - total_periods + 1) + " AND " + period_selected;
                        select_str += " AND  iPeriodBegin_dt = 0";
                    }
                    else
                    {
                        full_years = Convert.ToInt32(total_periods - oUtility.ToInteger(period_selected)) / 4;
                        temp = (total_periods - oUtility.ToInteger(period_selected)) - (full_years * 4);
                        qtr_from = (4 - temp + 1).ToString(); // Starting qtr
                        year_from = (oUtility.ToInteger(year_selected) - full_years - 1).ToString(); // starting year

                        select_str = " WHERE iPeriodBegin_dt = 0 AND iQuarter > 0";
                        select_str += " AND (";
                        select_str += " (sFiscalYear = '" + year_selected + "' AND  iQuarter <= " + period_selected + ")"; // Last year
                        select_str += " OR (sFiscalYear = '" + year_from + "' AND  iQuarter >= " + qtr_from + ")"; // First year
                        for (i = 1; i <= full_years; i++)
                        {
                            select_str += " OR (sFiscalYear = '" + (oUtility.ToInteger(year_selected) - i).ToString() + "')";
                        }
                        select_str += ")";
                    }

                }

                return_value = select_str;

            }
            catch
            {
                // Just in case
            }

            return return_value;

        }

        public string SelectPRQuarters(ref clsDatabase cur_db, int comparison_type, string period_from, int total_periods)
        {

            string return_value = "";
            string qtr_from = "";
            string qtr_thru = "";
            string year_from = "";
            string year_thru = "";
            string period_selected = "";
            string year_selected = "";
            string select_str = "";
            int full_years = 0;
            int temp = 0;
            int i = 0;

            try
            {

                period_selected = oUtility.SRight(period_from, 1);
                year_selected = oUtility.SLeft(period_from, 4);

                if (comparison_type == COMPARISON_TYPE_SAME_PERIOD_OF_YEAR)
                {
                    select_str = " WHERE sFiscalYear BETWEEN '" + (oUtility.ToInteger(year_selected) - total_periods + 1).ToString() + "' AND '" + year_selected + "'";
                    select_str += " AND  iQuarter = " + oUtility.ToInteger(period_selected).ToString();
                }
                else
                {
                    qtr_thru = period_selected;
                    year_thru = year_selected;

                    if (total_periods <= oUtility.ToInteger(period_selected)) //The same year
                    {
                        select_str = " WHERE sFiscalYear = '" + year_selected + "'";
                        select_str += " AND  iQuarter BETWEEN " + (oUtility.ToInteger(period_selected) - total_periods + 1) + " AND " + period_selected;
                    }
                    else
                    {
                        full_years = Convert.ToInt32(total_periods - oUtility.ToInteger(period_selected)) / 4;
                        temp = (total_periods - oUtility.ToInteger(period_selected)) - (full_years * 4);
                        qtr_from = (4 - temp + 1).ToString(); // Starting qtr
                        year_from = (oUtility.ToInteger(year_selected) - full_years - 1).ToString(); // starting year

                        select_str = " WHERE (sFiscalYear = '" + year_selected + "' AND  iQuarter <= " + period_selected + ")"; // Last year
                        select_str += " OR (sFiscalYear = '" + year_from + "' AND  iQuarter >= " + qtr_from + ")"; // First year
                        for (i = 1; i <= full_years; i++)
                        {
                            select_str += " OR (sFiscalYear = '" + (oUtility.ToInteger(year_selected) - i).ToString() + "')";
                        }
                    }

                }

                return_value = select_str;

            }
            catch
            {
                // Just in case
            }

            return return_value;

        }

        public string SelectGLQuarters(ref clsDatabase cur_db, int comparison_type, string period_from, int total_periods)
        {

            string return_value = "";
            string qtr_from = "";
            string qtr_thru = "";
            string year_from = "";
            string year_thru = "";
            string period_selected = "";
            string year_selected = "";
            string select_str = "";
            int full_years = 0;
            int temp = 0;
            int i = 0;

            try
            {

                period_selected = oUtility.SRight(period_from, 1);
                year_selected = oUtility.SLeft(period_from, 4);

                if (comparison_type == COMPARISON_TYPE_SAME_PERIOD_OF_YEAR)
                {
                    select_str = " WHERE sFiscalYear BETWEEN '" + (oUtility.ToInteger(year_selected) - total_periods + 1).ToString() + "' AND '" + year_selected + "'";
                    select_str += " AND  iQuarter = " + oUtility.ToInteger(period_selected).ToString();
                    select_str += " AND  iQuarter_typ = 3"; // Qtr-end
                }
                else
                {
                    qtr_thru = period_selected;
                    year_thru = year_selected;

                    if (total_periods <= oUtility.ToInteger(period_selected)) //The same year
                    {
                        select_str = " WHERE sFiscalYear = '" + year_selected + "'";
                        select_str += " AND  iQuarter BETWEEN " + (oUtility.ToInteger(period_selected) - total_periods + 1) + " AND " + period_selected;
                        select_str += " AND  iQuarter_typ = 3"; // Qtr-end
                    }
                    else
                    {
                        full_years = Convert.ToInt32(total_periods - oUtility.ToInteger(period_selected)) / 4;
                        temp = (total_periods - oUtility.ToInteger(period_selected)) - (full_years * 4);
                        qtr_from = (4 - temp + 1).ToString(); // Starting qtr
                        year_from = (oUtility.ToInteger(year_selected) - full_years - 1).ToString(); // starting year

                        select_str = " WHERE iQuarter_typ = 3"; // Qtr-end
                        select_str += " AND (";
                        select_str += " (sFiscalYear = '" + year_selected + "' AND  iQuarter <= " + period_selected + ")"; // Last year
                        select_str += " OR (sFiscalYear = '" + year_from + "' AND  iQuarter >= " + qtr_from + ")"; // First year
                        for (i = 1; i <= full_years; i++)
                        {
                            select_str += " OR (sFiscalYear = '" + (oUtility.ToInteger(year_selected) - i).ToString() + "')";
                        }
                        select_str += ")";
                    }

                }

                return_value = select_str;

            }
            catch
            {
                // Just in case
            }

            return return_value;

        }

        public string SelectQTD(ref clsDatabase cur_db, int comparison_type, string period_from, int total_periods)
        {

            string return_value = "";
            string period_selected = "";
            string year_selected = "";
            string select_str = "";

            period_selected = period_from;
            year_selected = cur_db.sCurFiscalYear;

            select_str = " WHERE sFiscalYear BETWEEN '" + (oUtility.ToInteger(year_selected) - total_periods + 1).ToString() + "' AND '" + year_selected + "'";
            select_str += " AND  iPeriod_id BETWEEN " + ((Convert.ToInt32(oUtility.ToInteger(period_selected) - 1) / 3) * 3 + 1).ToString() + " AND " + period_selected;

            return_value = select_str;

            return return_value;

        }

        public string SelectGLQTD(ref clsDatabase cur_db, int comparison_type, string period_from, int total_periods)
        {

            string return_value = "";

            clsRecordset cur_set = new clsRecordset(ref cur_db);
            int qtr_id = 0;
            int qtr_type = 0;
            string qtr_from = "";
            string qtr_thru = "";
            string year_from = "";
            string year_thru = "";
            string period_selected = "";
            string year_selected = "";
            string select_str = "";
            int full_years = 0;
            int temp = 0;
            int i = 0;

            period_selected = period_from;
            year_selected = cur_db.sCurFiscalYear;

            if (!cur_set.CreateSnapshot("SELECT * FROM tblGLPeriodDet WHERE sFiscalYear = '" + year_selected + "' AND iPeriodBegin_dt = " + year_selected + oUtility.SRight("00" + period_selected, 2) + "01"))
            {
                return return_value;
            }
            else if (cur_set.EOF())
            {
                return return_value;
            }

            qtr_id = (cur_set.iField("iQuarter"));
            qtr_type = (cur_set.iField("iQuarter_typ")); // first/second/third month of each qtr.

            if (comparison_type == COMPARISON_TYPE_SAME_PERIOD_OF_YEAR)
            {
                select_str = " WHERE sFiscalYear BETWEEN '" + (oUtility.ToValue(year_selected) - total_periods + 1).ToString() + "' AND '" + year_selected + "'";
                select_str += " AND  iQuarter = " + qtr_id;
                select_str += " AND  iQuarter_typ = " + qtr_type;
            }
            else
            {
                qtr_thru = qtr_id.ToString();
                year_thru = year_selected;

                if (total_periods <= qtr_id) //The same year
                {
                    select_str = " WHERE sFiscalYear = '" + year_selected + "'";
                    select_str += " AND  iQuarter BETWEEN " + (qtr_id - total_periods + 1) + " AND " + qtr_id;
                    select_str += " AND  iQuarter_typ = " + qtr_type;
                }
                else
                {
                    full_years = (total_periods - qtr_id) / 4;
                    temp = (total_periods - qtr_id) - (full_years * 4);
                    qtr_from = (4 - temp + 1).ToString(); // Starting qtr
                    year_from = (oUtility.ToValue(year_selected) - full_years - 1).ToString(); // starting year

                    select_str = " WHERE iQuarter_typ = " + qtr_type;
                    select_str += " AND (";
                    select_str += " (sFiscalYear = '" + year_selected + "' AND  iQuarter <= " + qtr_id + ")"; // Last year
                    select_str += " OR (sFiscalYear = '" + year_from + "' AND  iQuarter >= " + qtr_from + ")"; // First year
                    for (i = 1; i <= full_years; i++)
                    {
                        select_str += " OR (sFiscalYear = '" + (oUtility.ToValue(year_selected) - i).ToString() + "')";
                    }
                    select_str += ")";
                }

            }

            return_value = select_str;

            return return_value;

        }

        public string SelectWeeks(ref clsDatabase cur_db, int comparison_type, string period_value, int total_periods, string period_text)
        {

            string return_value = "";
            string week_selected = "";
            string period_selected = "";
            string year_selected = "";
            string select_str = "";
            clsGeneral o_gen = new clsGeneral(ref cur_db);

            try
            {

                // period_value has the year followed the week_id
                week_selected = oUtility.SRight("00" + period_value, 2);
                period_selected = o_gen.ToNumDate(oUtility.SLeft(oUtility.STrim(oUtility.SRight(period_text, oUtility.SLength(period_text) - oUtility.SInStr(period_text, "~"))), 10)).ToString();
                year_selected = oUtility.SLeft(period_value, 4);

                if (comparison_type == COMPARISON_TYPE_CONSECUTIVE)
                {

                    select_str = " WHERE iPeriodBegin_dt BETWEEN " + oUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, oUtility.ToInteger(period_selected), -(total_periods * 7) + 1).ToString();
                    select_str += " AND  " + period_selected;

                }
                else // Compare the same period of each year
                {

                    select_str = " WHERE sFiscalYear BETWEEN '" + (oUtility.ToInteger(year_selected) - total_periods + 1).ToString() + "' AND '" + year_selected + "'";
                    select_str += " AND  iWeek = " + oUtility.ToInteger(week_selected).ToString();

                }

                return_value = select_str;

            }
            catch
            {
                // Just in case
            }

            return return_value;

        }

        public string SelectDays(ref clsDatabase cur_db, int comparison_type, string period_from, int total_periods, string table_alias = "")
        {

            string return_value = "";
            string select_str = "";
            clsGeneral o_gen = new clsGeneral(ref cur_db);

            try
            {

                select_str = " WHERE " + oUtility.IIf(oUtility.IsNonEmpty(table_alias), table_alias + ".", "").ToString() + "iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM.ToString();

                if (comparison_type == COMPARISON_TYPE_CONSECUTIVE)
                {
                    select_str += " AND " + oUtility.IIf(oUtility.IsNonEmpty(table_alias), table_alias + ".", "").ToString() + "iApply_dt BETWEEN " + oUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, o_gen.ToNumDate(period_from), -total_periods + 1).ToString() + " AND " + o_gen.ToNumDate(period_from);
                }
                else // The same days of year
                {
                    select_str += " AND " + oUtility.IIf(oUtility.IsNonEmpty(table_alias), table_alias + ".", "").ToString() + "iApply_dt BETWEEN " + oUtility.AddToDate(GlobalVar.goConstant.YEAR_TYPE, o_gen.ToNumDate(period_from), -total_periods + 1).ToString() + " AND " + o_gen.ToNumDate(period_from);
                    if (cur_db.CurrentDatabaseType() == GlobalVar.goConstant.DB_ORACLE_TYPE)
                    {
                        select_str += " AND MOD(" + oUtility.IIf(oUtility.IsNonEmpty(table_alias), table_alias + ".", "").ToString() + "iApply_dt, 10000) = " + oUtility.SRight(o_gen.ToNumDate(period_from).ToString(), 4);
                    }
                    else if (cur_db.CurrentDatabaseType() == GlobalVar.goConstant.DB_SQLSERVER_TYPE)
                    {
                        select_str += " AND (" + oUtility.IIf(oUtility.IsNonEmpty(table_alias), table_alias + ".", "").ToString() + "iApply_dt % 10000) = " + oUtility.SRight(o_gen.ToNumDate(period_from).ToString(), 4);
                    }
                    else // Access & MySQL
                    {
                        select_str += " AND (" + oUtility.IIf(oUtility.IsNonEmpty(table_alias), table_alias + ".", "").ToString() + "iApply_dt MOD 10000) = " + oUtility.SRight(o_gen.ToNumDate(period_from).ToString(), 4);
                    }
                }

                return_value = select_str;

            }
            catch
            {
                // Just in case
            }

            return return_value;

        }

        public string SelectMFDays(ref clsDatabase cur_db, int comparison_type, string period_from, int total_periods, string report_type)
        {

            string return_value = "";
            string select_str = "";
            clsGeneral o_gen = new clsGeneral(ref cur_db);

            if (report_type == REPORT_MFG || report_type == REPORT_USED_IN_MFG)
            {
                select_str = " WHERE (iTransaction_typ = " + GlobalVar.goConstant.TRX_IV_MANUFACTURING_TYPE + ")";
            }
            else // Assembly/DisAssemply
            {
                select_str = " WHERE (iTransaction_typ = " + GlobalVar.goConstant.TRX_IV_KIT_ASSEMBLY_TYPE + " OR iTransaction_typ  = " + GlobalVar.goConstant.TRX_IV_KIT_DISASSEMBLY_TYPE + ")";
            }

            select_str += " AND iStatus_typ = " + GlobalVar.goIVConstant.ASSEMBLY_FINISH_STATUS_NUM.ToString();

            if (comparison_type == COMPARISON_TYPE_CONSECUTIVE)
            {
                select_str += " AND iApply_dt BETWEEN " + oUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, o_gen.ToNumDate(period_from), -total_periods + 1).ToString() + " AND " + o_gen.ToNumDate(period_from);
            }
            else // The same days of year
            {
                select_str += " AND iApply_dt BETWEEN " + oUtility.AddToDate(GlobalVar.goConstant.YEAR_TYPE, o_gen.ToNumDate(period_from), -total_periods + 1).ToString() + " AND " + o_gen.ToNumDate(period_from);
                if (cur_db.CurrentDatabaseType() == GlobalVar.goConstant.DB_ORACLE_TYPE)
                {
                    select_str += " AND MOD(iApply_dt, 10000) = " + oUtility.SRight(o_gen.ToNumDate(period_from).ToString(), 4);
                }
                else if (cur_db.CurrentDatabaseType() == GlobalVar.goConstant.DB_SQLSERVER_TYPE)
                {
                    select_str += " AND (iApply_dt % 10000) = " + oUtility.SRight(o_gen.ToNumDate(period_from).ToString(), 4);
                }
                else // Access & MySQL
                {
                    select_str += " AND (iApply_dt MOD 10000) = " + oUtility.SRight(o_gen.ToNumDate(period_from).ToString(), 4);
                }
            }

            return_value = select_str;

            return return_value;

        }

        public string SelectIVDays(ref clsDatabase cur_db, int comparison_type, string period_from, int total_periods, string report_type)
        {

            string return_value = "";
            string select_str = "";
            clsGeneral o_gen = new clsGeneral(ref cur_db);

            if (report_type == REPORT_NET_SALES)
            {
                select_str = " WHERE (iTransaction_typ = " + GlobalVar.goConstant.TRX_IV_SALES_TYPE + " OR iTransaction_typ = " + GlobalVar.goConstant.TRX_IV_SALES_RETURN_TYPE + ")";
            }
            else if (report_type == REPORT_SALES)
            {
                select_str = " WHERE (iTransaction_typ = " + GlobalVar.goConstant.TRX_IV_SALES_TYPE + ")";
            }
            else if (report_type == REPORT_SALES_RETURN)
            {
                select_str = " WHERE (iTransaction_typ = " + GlobalVar.goConstant.TRX_IV_SALES_RETURN_TYPE + ")";
            }
            else if (report_type == REPORT_NET_PURCHASE)
            {
                select_str = " WHERE (iTransaction_typ = " + GlobalVar.goConstant.TRX_IV_PURCHASE_TYPE + " OR iTransaction_typ = " + GlobalVar.goConstant.TRX_IV_PURCHASE_RETURN_TYPE + ")";
            }
            else if (report_type == REPORT_PURCHASE)
            {
                select_str = " WHERE (iTransaction_typ = " + GlobalVar.goConstant.TRX_IV_PURCHASE_TYPE + ")";
            }
            else if (report_type == REPORT_PURCHASE_RETURN)
            {
                select_str = " WHERE (iTransaction_typ = " + GlobalVar.goConstant.TRX_IV_PURCHASE_RETURN_TYPE + ")";
            }
            else if (report_type == REPORT_ASJUSTMENT)
            {
                select_str = " WHERE (iTransaction_typ = " + GlobalVar.goConstant.TRX_PHYSICAL_TYPE + ")";
            }
            else if (report_type == REPORT_SPOILAGE)
            {
                select_str = " WHERE (iTransaction_typ = " + GlobalVar.goConstant.TRX_SPOILAGE_TYPE + ")";
            }
            else if (report_type == REPORT_NET_TRANSFER)
            {
                select_str = " WHERE (iTransaction_typ = " + GlobalVar.goConstant.TRX_TRANSFER_IN_TYPE + " OR iTransaction_typ = " + GlobalVar.goConstant.TRX_TRANSFER_OUT_TYPE + ")";
            }
            else if (report_type == REPORT_TRANSFER_IN)
            {
                select_str = " WHERE (iTransaction_typ = " + GlobalVar.goConstant.TRX_TRANSFER_IN_TYPE + ")";
            }
            else if (report_type == REPORT_TRANSFER_OUT)
            {
                select_str = " WHERE (iTransaction_typ = " + GlobalVar.goConstant.TRX_TRANSFER_OUT_TYPE + ")";
            }
            else
            {
                // Not expected
                return return_value;
            }

            select_str += " AND iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM.ToString();

            if (comparison_type == COMPARISON_TYPE_CONSECUTIVE)
            {
                select_str += " AND iApply_dt BETWEEN " + oUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, o_gen.ToNumDate(period_from), -total_periods + 1).ToString() + " AND " + o_gen.ToNumDate(period_from);
            }
            else // The same days of year
            {
                select_str += " AND iApply_dt BETWEEN " + oUtility.AddToDate(GlobalVar.goConstant.YEAR_TYPE, o_gen.ToNumDate(period_from), -total_periods + 1).ToString() + " AND " + o_gen.ToNumDate(period_from);
                if (cur_db.CurrentDatabaseType() == GlobalVar.goConstant.DB_ORACLE_TYPE)
                {
                    select_str += " AND MOD(iApply_dt, 10000) = " + oUtility.SRight(o_gen.ToNumDate(period_from).ToString(), 4);
                }
                else if (cur_db.CurrentDatabaseType() == GlobalVar.goConstant.DB_SQLSERVER_TYPE)
                {
                    select_str += " AND (iApply_dt % 10000) = " + oUtility.SRight(o_gen.ToNumDate(period_from).ToString(), 4);
                }
                else // Access & MySQL
                {
                    select_str += " AND (iApply_dt MOD 10000) = " + oUtility.SRight(o_gen.ToNumDate(period_from).ToString(), 4);
                }
            }

            return_value = select_str;

            return return_value;

        }

        public string GetPeriodCaption(ref clsDatabase cur_db, string period_val, int period_type)
        {

            string return_value = "";

            clsGeneral o_gen = new clsGeneral(ref cur_db);

            try
            {

                if (period_type == PERIOD_TYPE_MONTHLY)
                {
                    return_value = oUtility.GetStrMonth(oUtility.GetMonth(oUtility.ToInteger(period_val)), true) + " " + oUtility.GetYear(oUtility.ToInteger(period_val), true);

                    //return_value = CultureInfo.CurrentCulture.DateTimeFormat.GetAbbreviatedMonthName(oUtility.GetMonth(oUtility.ToInteger(period_val))) + " " + oUtility.SLeft(period_val, 4);
                }
                else if (oUtility.SLength(period_val) == 8 && oUtility.ToInteger(period_val).ToString() == period_val)
                {
                    return_value = o_gen.ToStrDate(oUtility.ToInteger(period_val));
                }
                else
                {
                    return_value = period_val;
                }

            }
            catch
            {
                // Just in case
            }

            return return_value;

        }

        public string CreateHTML(ref clsDatabase cur_db, string page_title, Models.clsSpreadsheet cur_sheet, int total_columns, string[] header_list = null)
        {
            string return_value = "";
            int row_num = 0;
            int col_num = 0;
            int first_col_num = 0;
            string col_width = "";
            string progress_str = "";
            int progress_col_num = -1;

            clsFileIO file_io = new clsFileIO();
            clsGeneral o_gen = new clsGeneral(ref cur_db);

            try
            {
                if (cur_sheet == null || cur_sheet.Data == null)
                {
                    modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NO_RECORDS_SELECTED_TO_PROCESS + " (CreateHTML)");
                    return "";
                }
                if (header_list == null && (cur_sheet.FieldName == null))
                {
				    modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NO_RECORDS_SELECTED_TO_PROCESS + " (CreateHTML)");
                    return "";
                }

                return_value = cur_db.uDirectory.sPDFDirectory_nm + "\\" + cur_db.sUser_cd + "_Inqury.html";

                file_io.OpenFileToWrite(return_value);

                file_io.WriteOneLine("<!DOCTYPE html>");
                file_io.WriteOneLine("<html lang=\"en-us\">");
                file_io.WriteOneLine("<head>");
                file_io.WriteOneLine("    <meta charset=\"utf-8\" />");
                file_io.WriteOneLine("    <meta name=\"viewport\" content=\"width = device-width, initial-scale = 1.0\" />");
                file_io.WriteOneLine("    <title>" + page_title + "</title>");
                file_io.WriteOneLine("    <base href=\"~/\" />");
                file_io.WriteOneLine("    <link rel=\"stylesheet\" href=\"../../../../css/bootstrap/bootstrap.min.css\" />");
                file_io.WriteOneLine("    <link rel=\"stylesheet\" href=\"../../../../css/site.css\" />");
                file_io.WriteOneLine("    <link rel=\"stylesheet\" href=\"../../../../Dynasty/css/Dynasty.css\" />");
                file_io.WriteOneLine("</head>");
                file_io.WriteOneLine("<body style=\"font-family: Arial; font-size: 11pt\">");

                if (oUtility.IsNonEmpty(page_title))
                {
                    file_io.WriteOneLine("<a style =\"font-family: Arial; font-size: 13pt\">" + page_title + "</a>");
                    file_io.WriteOneLine("<br/>");
                }

                file_io.WriteOneLine("<table style=\"border: 1px solid silver\">");

                if (header_list != null)
                {
                    if (total_columns > header_list.GetLength(0))
                    {
                        total_columns = header_list.GetLength(0);
                    }
                }
                else
                {
                    if (total_columns > cur_sheet.FieldName.GetLength(0))
                    {
                        total_columns = cur_sheet.FieldName.GetLength(0);
                    }
                }

                // Check is the first column id valid.  Some times, the first column is used for buttons.
                //
                if (header_list == null || oUtility.IsEmpty(header_list[0]))
                {
                    first_col_num = 1;

                    for (row_num = 0; row_num <= cur_sheet.Data.GetUpperBound(1); row_num++)
                    {
                        if (oUtility.IsNonEmpty(cur_sheet.Data[0, row_num]))
                        {
                            first_col_num = 0;
                            break;
                        }
                    }
                }

                //   Header
                //
                file_io.WriteOneLine("<tr style=\"border-top:1px solid silver; font-weight: bold \" class=\"GroupHeader\">");

                for (col_num = first_col_num; col_num < total_columns; col_num++)
                {
                    file_io.WriteOneLine("<td style=\"text-align: center; padding: 2px\"> ");

                    if (header_list != null && col_num < header_list.GetLength(0))
                    {
                        if (header_list[col_num] == "%")
                        {
                            progress_col_num = col_num;
                        }

                        file_io.WriteOneLine(header_list[col_num]);
                    }
                    else if (cur_sheet.FieldName != null && col_num < cur_sheet.FieldName.GetLength(0))
                    {
                        file_io.WriteOneLine(o_gen.GetReadableFieldName(cur_sheet.FieldName[col_num], true));
                    }

                    file_io.WriteOneLine("</td> ");
                }

                file_io.WriteOneLine("</tr> ");

                // Details
                //
                for (row_num = 0; row_num < cur_sheet.Data.GetLength(1); row_num++)
                {
                    file_io.WriteOneLine("<tr>");

                    for (col_num = first_col_num; col_num < total_columns; col_num++)
                    {
                        file_io.WriteOneLine("<td style=\"border-left:1px solid silver; border-top: 1px silver solid; padding: 4px\"> ");

                        //if (oUtility.IsNonEmpty(cur_sheet.InquiryCSS(col_num)))
                        //{
                        //    file_io.WriteOneLine("<a class=\"" + cur_sheet.InquiryCSS(col_num) + "\">" + cur_sheet.Data[col_num, row_num] + "</a> ");
                        //}
                        //else
                        //{

                        //if (col_num == progress_col_num && oUtility.ToInteger(cur_sheet.Data[col_num, row_num]) > 0)
                        //{
                        //    file_io.WriteOneLine("<table style=\"border: none \">");
                        //    file_io.WriteOneLine("<tr>");

                        //    progress_str = "";
                        //    for (int i = 1; i <= 50; i++)
                        //    {
                        //        progress_str += "<td style = \"" + "width:1px; height: 18px; background-color:" + ((oUtility.ToInteger(cur_sheet.Data[col_num, row_num]) + 1) / 2 >= i? "cornflowerblue": "silver") + "\"></ td >";
                        //    }
                        //    file_io.WriteOneLine(progress_str);
                        //    file_io.WriteOneLine("</tr>");
                        //    file_io.WriteOneLine("</table>");
                        //}
                        //else
                        //{
                        file_io.WriteOneLine(cur_sheet.Data[col_num, row_num]);
                        //}

                        //}

                        file_io.WriteOneLine("</td> ");
                    }

                    file_io.WriteOneLine("</tr> ");
                }

                file_io.WriteOneLine("</table> ");
                file_io.WriteOneLine("</body> ");

                // This will freeze the app if user closes the tab without clicking print/cancel button.
                //
                //file_io.WriteOneLine("<script type=\"text/javascript\"> ");
                //file_io.WriteOneLine(" window.print(); ");
                //file_io.WriteOneLine("</script> ");

                file_io.WriteOneLine("</html> ");

                file_io.CloseFile();
            }
            catch (Exception ex)
            {
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (Inquiry.CreateHTML)");
                return_value = "";
            }
            return return_value;
        }


        public string CreateCSV(ref clsDatabase cur_db, string page_title, Models.clsSpreadsheet cur_sheet, int total_columns, string[] header_list = null, string page_sub_title = "")
        {
            string return_value = "";
            int row_num = 0;
            int col_num = 0;
            int first_col = 0;
            string one_line = "";

            clsFileIO file_io = new clsFileIO();
            clsGeneral o_gen = new clsGeneral(ref cur_db);

            try
            {
                if (cur_sheet == null || cur_sheet.Data == null)
                {
                    modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NO_RECORDS_SELECTED_TO_PROCESS + " (CreateCSV)");
                    return "";
                }
                if (header_list == null && (cur_sheet.FieldName == null))
                {
                    modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NO_RECORDS_SELECTED_TO_PROCESS + " (CreateCSV)");
                    return "";
                }

                return_value = cur_db.uDirectory.sCSVExportDirectory_nm + "\\" + cur_db.sUser_cd + "_Inqury.csv";

                file_io.OpenFileToWrite(return_value);

                if (header_list != null)
                {
                    if (total_columns > header_list.GetLength(0))
                    {
                        total_columns = header_list.GetLength(0);
                    }

                    if (oUtility.IsEmpty(header_list[0]))
                    {
                        first_col = 1;
                    }
                }
                else
                {
                    if (total_columns > cur_sheet.FieldName.GetLength(0))
                    {
                        total_columns = cur_sheet.FieldName.GetLength(0);
                    }

                    if (oUtility.IsEmpty(cur_sheet.FieldName[0]))
                    {
                        first_col = 1;
                    }
                }

                if (oUtility.IsNonEmpty(page_title))
                {
                    file_io.WriteOneLine(oUtility.SReplace(page_title, ":", "\t"));     //  : in the tile is treated as a column separator

                    if (oUtility.IsNonEmpty(page_sub_title))
                    {
                        file_io.WriteOneLine(oUtility.SReplace(page_sub_title, ":", "\t"));     
                    }
                    
                    file_io.WriteOneLine("");
                }

                //   Header
                //
                one_line = "";
                for (col_num = first_col; col_num < total_columns; col_num++)
                {
                    if (header_list != null)
                    {
                        one_line += oUtility.IIf(col_num == first_col, "", "\t") + oUtility.SReplace(oUtility.SReplace(header_list[col_num], "<br/>", " "), "<br />"," ");
                    }
                    else
                    {
                        one_line += oUtility.IIf(col_num == first_col, "", "\t") + o_gen.GetReadableFieldName(cur_sheet.FieldName[col_num], true);
                    }
                }

                file_io.WriteOneLine(one_line);

                // Details
                //
                for (row_num = 0; row_num < cur_sheet.Data.GetLength(1); row_num++)
                {
                    one_line = "";

                    for (col_num = first_col; col_num < total_columns; col_num++)
                    {
                        one_line += oUtility.IIf(col_num == first_col, "", "\t") + cur_sheet.Data[col_num, row_num];
                    }

                    file_io.WriteOneLine(one_line);
                }

                file_io.CloseFile();
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (CreateCSV)");
                return_value = "";
            }
            return return_value;
        }
    }
}
