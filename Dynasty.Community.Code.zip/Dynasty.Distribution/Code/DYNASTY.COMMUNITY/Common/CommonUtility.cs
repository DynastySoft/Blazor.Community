﻿//  Copyright (c) DynastySoft Corporation, 2012.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Collections.Generic;
using System.Linq;

using Dynasty.Database;
using Dynasty.Local;
using Dynasty.ASP.Models;

namespace Dynasty.ASP
{
	internal static class modCommonUtility
	{

		private static clsDynastyUtility moUtility = new clsDynastyUtility();

		// Delete the existing detail records and get an empty record that will carry the field name and size.
		public static bool GetEmptyRecordset(ref clsDatabase cur_db, ref clsRecordset cur_set, string table_name, int trx_type, string key_id, string key_field_name)
		{

			bool return_value = false;
			string sql_str = "";
			string dummy_val = "";
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			try
			{

				if (moUtility.IsEmpty(table_name) || moUtility.IsEmpty(key_id))
				{
					return false;
				}

				cur_set = new clsRecordset(ref cur_db);

				// Delete the existing records, first.
				//
				sql_str = "DELETE FROM " + table_name;
				sql_str += " WHERE " + key_field_name + "=" + o_gen.EncloseField(key_field_name, key_id);
				if (trx_type > 0)
				{
					sql_str += " AND iTransaction_typ = " + trx_type;
				}
				if (cur_db.ExecuteSQL(sql_str) == false)
				{
					return false;
				}

				// Grab the name and size of each field.
				//
				if (moUtility.SLeft(key_field_name, moUtility.SLength(GlobalVar.goRule.INTEGER_FIELD_PREFIX)) == GlobalVar.goRule.INTEGER_FIELD_PREFIX)
				{
					dummy_val = "-100";
				}
				else
				{
					dummy_val = "'!!!'";
				}

				sql_str = "SELECT * FROM " + table_name;
				sql_str += " WHERE " + key_field_name + " = " + dummy_val;
				if (!cur_set.CreateSnapshot(sql_str))
				{
					return false;
				}

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (GetEmptyRecordset)");

			}

			return return_value;
		}

		public static void CleanCode(ref string cur_text, bool upper_case_fl = true)
        {
			cur_text = CleanCode(cur_text, upper_case_fl);
		}

		public static string CleanCode(string cur_text, bool upper_case_fl = true)
		{

			string return_value = "";

			return_value = cur_text;
			return_value = moUtility.SReplace(moUtility.SReplace(moUtility.SReplace(moUtility.EvalQuote(moUtility.STrim(return_value)), "\"", ""), "_", "-"), "*", "");
			return_value = moUtility.SReplace(moUtility.SReplace(return_value, "&", ""), " ", "");
			return_value = moUtility.SReplace(return_value, ",", ".");		
			//return_value = moUtility.SReplace(return_value, "\\", "");

			if (upper_case_fl) 
			{
				return_value = moUtility.SUCase(return_value);
			}

			return return_value;
		}

		public static string GetSearchClauseForOpenSalesOrders()
		{

			string return_value = "";

			return_value = " (iShippingStatus_typ = 0) "; // Not suspended
			return_value += " AND ((iStatus_typ = " + GlobalVar.goConstant.OPEN_TRX_NUM.ToString() + ") OR (iStatus_typ >= " + GlobalVar.goConstant.SHIPPED_TRX_NUM.ToString() + " AND mTotal_amt > mShipped_amt))"; // Unshipped yet or partially shipped

			return return_value;

		}

		public static string GetSearchClauseForOpenPurchaseOrders()
		{

			string return_value = "";

			return_value = " (iShippingStatus_typ = 0) "; // Not suspended
			return_value += " AND ((iStatus_typ = " + GlobalVar.goConstant.OPEN_TRX_NUM.ToString() + ") OR (iStatus_typ >= " + GlobalVar.goConstant.RECEIVED_TRX_NUM.ToString() + " AND mTotal_amt > mReceived_amt))"; // Unshipped yet or partially shipped

			return return_value;

		}

		public static string GetSearchClauseForOpenPurchaseRequisitions()
		{

			string return_value = "";

			//return_value = "((iStatus_typ = " & goConstant.OPEN_TRX_NUM.ToString & ") OR (iStatus_typ = " & goConstant.HOLD_TRX_NUM.ToString & "))"
			return_value = "(iStatus_typ = " + GlobalVar.goConstant.OPEN_TRX_NUM.ToString() + ")";

			return return_value;

		}

		public static bool IsLargeTableForZoom(string table_name)
		{

			bool return_value = false;

			return_value = moUtility.SUCase(table_name) == "TBLIVITEM" || moUtility.SUCase(table_name) == "TBLARCUSTOMER" || moUtility.SUCase(table_name) == "TBLAPVENDOR" || moUtility.SUCase(table_name) == "TBLAPVENDOR" || moUtility.SUCase(table_name) == moUtility.SUCase("tblIVLocationBin");

			return return_value;

		}

		public static string GetDefaultDepreciationConventionType(ref clsDatabase cur_db)
		{

			string return_value = "";
			clsRecordset cur_set = new clsRecordset(ref cur_db);
			string sql_str = "";

			sql_str = "SELECT sDepreciationConvention_typ FROM tblFAAsset WHERE sDepreciationConvention_typ <> '' AND iMethod_typ <> " + GlobalVar.goFAConstant.METHOD_NOT_DEPRECIABLE_NUM.ToString();
			sql_str += " AND iCreated_dt = (SELECT MAX(iCreated_dt) FROM tblFAAsset WHERE sDepreciationConvention_typ <> '' AND iMethod_typ <> " + GlobalVar.goFAConstant.METHOD_NOT_DEPRECIABLE_NUM.ToString() + ")";
			if (!cur_set.CreateSnapshot(sql_str))
			{
				return_value = "";
			}
			else if (cur_set.RecordCount() > 0)
			{
				return_value = cur_set.sField("sDepreciationConvention_typ");
			}

			return return_value;

		}

		// Scenario 
		//           1: The initial schedule with the given numbers on the asset master.
		//           2: Reschedule before depreciation takes place.  
		//           3: Reschedule after depreciation took place.
		//              - The starting month of reschedule is the month next to the last depreciation month.
		//              - The amounts and useful years could change along with the method.
		//              - Since the depreciation already started, the convention of FM will apply regardless of the original convention.
		//

		public static string GetSelectSecurityClause(clsDatabase cur_db, string table_name, bool for_crystal_fl)
		{

			string return_value = "";
			string table_list = "";

			if (moUtility.SInStr(moUtility.SUCase(ListOfTransactionTables()), moUtility.SUCase(table_name)) <= 0)
			{
				return "";
			}
			else if (cur_db.ViewOnly() || cur_db.iUserType_id >= clsConstant.USER_SUPERVISOR_TYPE)
			{
				return_value = "";
			}
			else if (cur_db.uSecurity.bBlockTransaction_fl)
			{

				if (for_crystal_fl)
				{
					return_value = "({" + table_name + ".sLastUpdate_id} = '" + cur_db.sUser_cd + "')";
				}
				else
				{
					return_value = "(" + table_name + ".sLastUpdate_id = '" + cur_db.sUser_cd + "')";
				}

			}
			else
			{
				return_value = "";
			}

			return return_value;

		}

		public static string ListOfTransactionTables()
		{

			string return_value = "";

			return_value = "tblAPCharge, tblAPPayment,tblAPChargeUnposted, tblAPPaymentUnposted";
			return_value += ",tblAPMCCharge, tblAPMCPayment,tblAPMCChargeUnposted, tblAPMCPaymentUnposted";
			return_value += ",tblARCharge, tblARPayment,tblARChargeUnposted, tblARPaymentUnposted";
			return_value += ",tblARMCCharge, tblARMCPayment,tblARMCChargeUnposted, tblARMCPaymentUnposted";
			return_value += ",tblGLTransaction,tblGLTransactionUnposted";
			return_value += ",tblIVTransaction,tblIVTransactionUnposted";
			return_value += ",tblSOTransaction,tblPOTransaction,tblBRTransaction";
			return_value += ",tblPRTransaction,tblPRTransactionUnposted";

			return return_value;

		}

		public static void ResetLastUpdateTimestamp(clsRecordset cur_set, ref DateTime last_update_dt, ref string last_update_id)
		{
			if (!cur_set.EOF())
			{
				last_update_id = cur_set.sField("sLastUpdate_id");
				last_update_dt = cur_set.dtField("dtLastUpdate_dt");
			}
			else
            {
				last_update_id = "";
				last_update_dt = Convert.ToDateTime("01/01/1000");
			}
		}

		// PURPOSE:  To validate apply-date field of a transaction form.
		//
		public static bool ValidApplyDate(ref clsDatabase cur_db, ref string date_passed)
		{

			bool return_value = false;
			string apply_date = "";
			string post_rear = "";
			clsRecordset cur_set = null;
			clsGeneral o_gen = new clsGeneral(ref cur_db);


				cur_set = new clsRecordset(ref cur_db);

				return_value = true;

				if (moUtility.IsBlankDate(date_passed) & !cur_db.uProgram.bGLExist_fl)
				{
					date_passed = o_gen.ToStrDate(o_gen.CurrentDate());
				}
				else if (moUtility.IsBlankDate(date_passed))
				{
					if (o_gen.CurrentDate() < cur_db.iCurPeriodBegin_dt)
					{
						date_passed = o_gen.ToStrDate(cur_db.iCurPeriodBegin_dt);
					}
					else if (o_gen.CurrentDate() > cur_db.iCurPeriodEnd_dt)
					{
						date_passed = o_gen.ToStrDate(cur_db.iCurPeriodEnd_dt);
					}
					else
					{
						date_passed = o_gen.ToStrDate(o_gen.CurrentDate());
					}
				}

				apply_date = date_passed;

				if (!o_gen.ValidDate(ref apply_date))
				{
					date_passed = moUtility.GetEmptyMaskedDate();
					return false;
				}
				else if (!o_gen.ValidDateForPosting(o_gen.ToNumDate(apply_date), ref post_rear))
				{
					date_passed = moUtility.GetEmptyMaskedDate();
					return false;
				}
				else
				{
					date_passed = apply_date;
				}

				return return_value;

		}

		// PURPOSE:  To validate entry-date field of a transaction form.
		//
		public static bool ValidEntryDate(ref clsDatabase cur_db, ref string date_passed)
		{

			return ValidApplyDate(ref cur_db, ref date_passed); // Make it the same.

		}

		// PURPOSE:  To validate a date range.
		//
		public static void ValidateDateRange(ref clsDatabase cur_db, ref string text_from, ref string text_thru)
		{
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			if (o_gen.ToNumDate(text_from) > o_gen.ToNumDate(text_thru))
			{
				moUtility.Swap(ref text_from, ref text_thru);				// 02/18/2025  ref is added
			}
		}

		// PURPOSE:  To validate a number range.
		//
		public static void ValidateNumRange(ref string text_from, ref string text_thru)
		{
			if (moUtility.ToInteger(text_from) > moUtility.ToInteger(text_thru))
			{
				moUtility.Swap(ref text_from, ref text_thru);               // 02/18/2025  ref is added
            }
		}

		// PURPOSE:  To validate a string range.
		//
		public static void ValidateStringRange(ref string text_from, ref string text_thru)
		{
			if (text_from.CompareTo(text_thru) > 0)
			{
				moUtility.Swap(ref text_from, ref text_thru);               // 02/18/2025  ref is added
            }
		}

		// This is to check if text_val has a value for range selection.
		//
		//public static bool ValidRangeValue(string text_val)
		//{

		//	bool return_value = false;

		//	text_val = moUtility.STrim(text_val);

		//	if (moUtility.IsEmpty(text_val) || text_val == cur_db.oLanguage.oString.STR_FIRST || text_val == cur_db.oLanguage.oString.STR_LAST || text_val == GlobalVar.goConstant.SMALLEST_CHAR || text_val == GlobalVar.goConstant.LARGEST_CHAR)
		//	{
		//		return_value = false;
		//	}
		//	else
		//	{
		//		return_value = true;
		//	}

		//	return return_value;

		//}

		//public static bool ValidRangeValue(int integer_val)
		//{

		//	bool return_value = false;

		//	return_value = (integer_val > 0 && integer_val != GlobalVar.goConstant.BIG_NUMBER);

		//	return return_value;

		//}

		public static bool ActivatePeriods(ref clsDatabase cur_db, string fiscal_year)
		{

			bool return_value = false;
			string sql_str = "";

			try
			{

				sql_str = "UPDATE tblGLPeriod ";
				sql_str += " SET iStatus_typ = " + GlobalVar.goConstant.STATUS_OPEN;
				sql_str += " WHERE sFiscalYear = '" + fiscal_year + "'";

				if (!cur_db.ExecuteSQL(sql_str))
				{
					return return_value;
				}

				sql_str = "UPDATE tblGLPeriodDet ";
				sql_str += " SET iStatus_typ = " + GlobalVar.goConstant.STATUS_OPEN;
				sql_str += " WHERE sFiscalYear = '" + fiscal_year + "'";

				if (!cur_db.ExecuteSQL(sql_str))
				{
					return return_value;
				}

				if (!CreatePeriodsInGLBalance(ref cur_db, fiscal_year))
				{
					return return_value;
				}

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ActivatePeriods)");

			}

			return return_value;

		}

		public static bool CreatePeriodsInGLBalance(ref clsDatabase cur_db, string fiscal_year)
		{

			bool return_value = false;
			clsRecordset period_set = null;
			clsRecordset acct_set = null;
			clsRecordset peridet_set = null;
			clsRecordset glbal_set = null;
			int res = 0;
			int total_rec = 0;
			int cur_rec = 0;
			bool was_in_trx = false;
			clsGLAccount o_glacct = new clsGLAccount(ref cur_db);

			try
			{

				acct_set = new clsRecordset(ref cur_db);
				period_set = new clsRecordset(ref cur_db);
				peridet_set = new clsRecordset(ref cur_db);
				glbal_set = new clsRecordset(ref cur_db);

				// Create the GLACCT snapshot.
				//
				if (!acct_set.CreateSnapshot(modConstant.ACCT_DYNASET))
				{
					return false;
				}
				else if (acct_set.EOF())
				{
					return true;
				}

				total_rec = acct_set.RecordCount();
				acct_set.MoveFirst();

				// Create the GLPERIDET dynaset.
				//
				if (!peridet_set.CreateSnapshot(modConstant.PERIODDET_DYNASET + " WHERE sFiscalYear = '" + fiscal_year + "' ORDER BY iPeriodBegin_dt"))
				{
					return return_value;
				}
				else if (peridet_set.IsEmpty())
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oString.STR_GIVEN_YEAR + "(" + fiscal_year + ")" + cur_db.oLanguage.oMessage.IS_INVALID_IN_GLPERIOD);
					return return_value;
				}
				else
				{
					peridet_set.MoveFirst();
				}

				cur_rec = 1;

				// o_gen.CreateAcctInGLBalance to create an account with full periods in tblGLBalance.
				//
				while (!acct_set.EOF())
				{
					if (!o_glacct.CreateGLAccountInGLBalance(fiscal_year, acct_set.sField("sAccount_cd"), acct_set.iField("iAcctLevel"), acct_set.iField("iGroup_typ"), acct_set.mField("mBalance_amt")))
					{
						return return_value;
					}
					acct_set.MoveNext();
					peridet_set.MoveFirst();
					cur_rec = cur_rec + 1;
					modGeneralUtility.RunEvents();
				}

				acct_set.Release();
				period_set.Release();
				peridet_set.Release();

				was_in_trx = false;
				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CreatePeriodsInGLBalance)");

				acct_set.Release();
				period_set.Release();
				peridet_set.Release();
				glbal_set.Release();

				return_value = false;

			}

			return return_value;

		}

		//  PURPOSE:  To read the split-Payment info from the database.
		//
		public static bool GetSplitPayment(ref clsDatabase cur_db, int trx_type, int trx_num, ref string[,] split_payment, bool from_foreign_currency = false)
		{

			bool return_value = false;
			string sql_str = "";
			int line_num = 0;
			clsRecordset cur_set = null;
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);

			try
			{

				cur_set = new clsRecordset(ref cur_db);

				if (trx_type == GlobalVar.goConstant.TRX_INVOICE_TYPE)
				{
					if (from_foreign_currency)
					{
						sql_str = modConstant.ARMCCHARGE_DUE_DYNASET;
					}
					else
					{
						sql_str = modConstant.ARCHARGE_DUE_DYNASET;
					}
				}
				else
				{
					if (from_foreign_currency)
					{
						sql_str = modConstant.APMCCHARGE_DUE_DYNASET;
					}
					else
					{
						sql_str = modConstant.APCHARGE_DUE_DYNASET;
					}
				}

				sql_str += " WHERE iTransaction_typ = " + trx_type.ToString();
				sql_str += " AND iTransaction_num = " + trx_num.ToString();
				sql_str += " AND ((iStatus_typ <> " + GlobalVar.goConstant.POSTED_TRX_NUM.ToString() + ") OR (iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM.ToString() + " AND  mDue_amt > 0))";
				sql_str += " ORDER BY iDetail_num ";
				if (!cur_set.CreateSnapshot(sql_str))
				{
					return false;
				}

				line_num = 0;
				if ((split_payment == null))
				{
                    moUtility.ResizeDim(ref split_payment, GlobalVar.goConstant.SPLIT_PAYMENT_TOTAL_DETAIL_COL - 1, cur_set.RecordCount() + 4);
				}
				else if (split_payment.GetLength(1) <= cur_set.RecordCount())
				{
                    moUtility.ResizeDim(ref split_payment, GlobalVar.goConstant.SPLIT_PAYMENT_TOTAL_DETAIL_COL - 1, cur_set.RecordCount() + 4);
				}

				while (!cur_set.EOF())
				{
					split_payment[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, line_num] = o_gen.ToStrDate(cur_set.iField("iDue_dt"));
					if (cur_set.iField("iStatus_typ") == GlobalVar.goConstant.POSTED_TRX_NUM)
					{
						split_payment[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, line_num] = o_money.ToStrMoney(cur_set.mField("mDue_amt"));
					}
					else
					{
						split_payment[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, line_num] = o_money.ToStrMoney(cur_set.mField("mTotal_amt"));
					}
					split_payment[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_DATE_COL, line_num] = o_gen.ToStrDate(cur_set.iField("iDiscountDue_dt"));
					split_payment[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_AMOUNT_COL, line_num] = o_money.ToStrMoney(cur_set.mField("mDiscountAvailable_amt"));
					cur_set.MoveNext();
					line_num += 1;
				}

				line_num = 0;
				return_value = true;
				cur_set.Release();

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(GetSplitPayment)");
				cur_set.Release();

			}

			return return_value;

		}

		public static bool DeleteEntity(ref clsDatabase cur_db, string entity_nm, string entity_value)
		{

			bool return_value = false;
			string sql_str = "";
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{

				sql_str = "SELECT o.name AS sTable_nm FROM syscolumns c INNER JOIN sysobjects o ON c.id = o.id ";
				sql_str += " WHERE c.name = '" + entity_nm + "'";
				if (!cur_set.CreateSnapshot(sql_str))
				{
                    modDialogUtility.DisplayBox(ref cur_db, cur_set.GetErrorMessage());
					return return_value;
				}
				else if (cur_set.EOF())
				{
					modDialogUtility.DisplayBox(ref cur_db, "No table found.");
					return return_value;
				}

				while (!cur_set.EOF())
				{
					sql_str = "DELETE FROM " + cur_set.sField("sTable_nm");
					sql_str += " WHERE " + entity_nm + " = '" + entity_value + "'";
					if (!cur_db.ExecuteSQL(sql_str))
					{
                        modDialogUtility.DisplayBox(ref cur_db, cur_db.GetErrorMessage());
						return return_value;
					}
					cur_set.MoveNext();
				}

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(DeleteEntity)");

			}

			return return_value;

		}

		public static string GetInitials(string str_value)
		{

			string return_value = "";
			bool first_char_fl = false;
			int i = 0;
			string initials = "";

			str_value = moUtility.SUCase(str_value);
			first_char_fl = true;

			for (i = 1; i <= moUtility.SLength(str_value); i++)
			{
				if (moUtility.SMid(str_value, i, 1).CompareTo("A") < 0 || moUtility.SMid(str_value, i, 1).CompareTo("Z") > 0)
				{
					first_char_fl = true;
				}
				else if (first_char_fl)
				{
					initials += moUtility.SMid(str_value, i, 1);
					first_char_fl = false;
				}
			}

			return_value = initials;

			return return_value;

		}

		public static bool WorkOrderExists(ref clsDatabase cur_db)
		{

			bool return_value = false;
			string sql_str = "";
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{

				sql_str = "SELECT COUNT(*) AS iCount FROM tblWOTransaction ";
				sql_str += " WHERE (iStatus_typ = " + GlobalVar.goWOConstant.WO_STATUS_OPEN_NUM + " OR iStatus_typ = " + GlobalVar.goWOConstant.WO_STATUS_START_NUM + ")";
				sql_str += " AND ((sAttentionTo_cd = '" + cur_db.sUser_cd + "' AND iAttentionAcknowledged_dt = 0 )";
				sql_str += " OR (sOrderTo_cd = '" + cur_db.sUser_cd + "' AND iOrderAcknowledged_dt = 0))";

				if (!cur_set.CreateSnapshot(sql_str))
				{
					return return_value;
				}

				return_value = (cur_set.iField("iCount") > 0);

			}
			catch (Exception ex)
			{

			}

			return return_value;

		}

		public static string GetTransactionDetailSearchCriteria(List<Models.clsChargeDetail.clsGrid> cur_grid, string table_name, int trx_type, int item_code_col, int order_num = 0)
		{ 
			string return_value = null;

			string tmp = null;
			int i = 0;

			if (moUtility.IsEmpty(table_name))
			{
				return return_value;
			}
			else if (order_num > 0 && trx_type == 0)
			{
				return return_value;
			}
			else if (order_num == 0 && (item_code_col < 0 || item_code_col >= cur_grid.Count))
			{
				return return_value;
			}

			try
			{
				if ((trx_type == GlobalVar.goConstant.TRX_INVOICE_TYPE || trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE) && order_num > 0) // 09/30/2018 Multi-order is implemeneted so that need to check the order number in the detail.
				{
					return " iTransaction_num IN (SELECT DISTINCT iTransaction_num FROM " + table_name + " WHERE iTransaction_typ = " + trx_type.ToString() + " AND iOrder_num = " + order_num.ToString() + ")";
				}

				foreach (var det in cur_grid)
                {
					if (moUtility.IsNonEmpty(det.txtItem_cd))
                    {
						tmp += moUtility.IIf(!moUtility.IsEmpty(tmp), " AND ", "")
							+ " iTransaction_num IN (SELECT DISTINCT iTransaction_num FROM " + table_name;

						if (trx_type == GlobalVar.goConstant.TRX_JOURNAL_TYPE || trx_type == GlobalVar.goConstant.TRX_MULTI_JOURNAL_TYPE)
                        {
							tmp += " WHERE sAccount_cd = '" + det.txtItem_cd + "'";
						}
						else
                        {
							tmp += " WHERE sItem_cd = '" + det.txtItem_cd + "'";

							if (trx_type > 0)
							{
								tmp += " AND iTransaction_typ = " + trx_type.ToString();
							}
						}
						tmp += ")";
					}
				}

				return_value = tmp;
			}
			catch (Exception ex)
			{
				return_value = "";
			}

			return return_value;
		}

		public static string GetProcurementDetailSearchCriteria(List<Models.clsProcurementDetail.clsGrid> cur_grid, string table_name, int trx_type)
		{
			string return_value = null;

			string tmp = null;
			int i = 0;

			if (moUtility.IsEmpty(table_name))
			{
				return return_value;
			}

			try
			{
				foreach (var det in cur_grid)
				{
					if (moUtility.IsNonEmpty(det.txtItem_cd))
					{
						tmp += moUtility.IIf(!moUtility.IsEmpty(tmp), " AND ", "")
							+ " iTransaction_num IN (SELECT DISTINCT iTransaction_num FROM " + table_name;

						tmp += " WHERE sItem_cd = '" + det.txtItem_cd + "'";

						if (trx_type > 0)
						{
							tmp += " AND iTransaction_typ = " + trx_type.ToString();
						}

						tmp += ")";
					}
				}

				return_value = tmp;
			}
			catch (Exception ex)
			{
				return_value = "";
			}

			return return_value;
		}

		public static string GetIVTransactionDetailSearchCriteria(List<clsIVTransaction.clsDetail.clsGrid> cur_grid, string table_name, int trx_type, int item_code_col)
		{
			string return_value = null;

			string tmp = null;
			int i = 0;

			if (moUtility.IsEmpty(table_name))
			{
				return return_value;
			}
			else if (trx_type == 0)
			{
				return return_value;
			}
			else if (item_code_col < 0 || item_code_col >= cur_grid.Count)
			{
				return return_value;
			}

			try
			{

				foreach (var det in cur_grid)
				{
					if (moUtility.IsNonEmpty(det.txtItem_cd))
					{
						tmp += moUtility.IIf(!moUtility.IsEmpty(tmp), " AND ", "")
							+ " iTransaction_num IN (SELECT DISTINCT iTransaction_num FROM " + table_name;

						tmp += " WHERE sItem_cd = '" + det.txtItem_cd + "'";
						tmp += " AND iTransaction_typ = " + trx_type.ToString();

						tmp += ")";
					}
				}

				return_value = tmp;
			}
			catch (Exception ex)
			{
				return_value = "";
			}

			return return_value;
		}

		public static string GetRentalDetailSearchCriteria(List<clsFARental.clsGrid> cur_grid, string table_name, int trx_type)
		{
			string return_value = null;

			string tmp = null;
			int i = 0;

			if (moUtility.IsEmpty(table_name))
			{
				return return_value;
			}
			else if (trx_type == 0)
			{
				return return_value;
			}

			try
			{

				foreach (var det in cur_grid)
				{
					if (moUtility.IsNonEmpty(det.txtAsset_cd))
					{
						tmp += moUtility.IIf(!moUtility.IsEmpty(tmp), " AND ", "")
							+ " iTransaction_num IN (SELECT DISTINCT iTransaction_num FROM " + table_name;

						tmp += " WHERE sAsset_cd = '" + moUtility.EvalQuote(det.txtAsset_cd) + "'";
						tmp += " AND iTransaction_typ = " + trx_type.ToString();

						tmp += ")";
					}
					else if (moUtility.IsNonEmpty(det.txtClass_cd))
					{
						tmp += moUtility.IIf(!moUtility.IsEmpty(tmp), " AND ", "")
							+ " iTransaction_num IN (SELECT DISTINCT iTransaction_num FROM " + table_name;

						tmp += " WHERE sClass_cd = '" + moUtility.EvalQuote(det.txtClass_cd) + "'";
						tmp += " AND iTransaction_typ = " + trx_type.ToString();

						tmp += ")";
					}
				}

				return_value = tmp;
			}
			catch (Exception ex)
			{
				return_value = "";
			}

			return return_value;
		}

		public static bool CheckSurrogateKey(ref clsDatabase cur_db, bool new_fl, string table_name, ref string key_box)
		{

			bool return_value = false;
			int new_num = 0;
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			try
			{

				if (new_fl)
				{
					new_num = o_gen.GetSurrogateKey(table_name);
					if (new_num < moUtility.ToInteger(key_box))
					{
						return return_value; // Not expected at all.
					}
					else if (new_num > moUtility.ToInteger(key_box))
					{
						key_box = new_num.ToString();
					}
				}

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CheckSurrogateKey)");

			}

			return return_value;

		}

		public static bool NeedToResizeItemCodeColumn(ref clsDatabase cur_db)
		{

			bool return_value = false;

			if (cur_db.iItemCodeSize_typ == clsConstant.COLUMN_CSS_MIN_NUM)
			{
				cur_db.sItemCodeSizeCSS = "CodeMin";
				return_value = true;
			}
			else if (cur_db.iItemCodeSize_typ == clsConstant.COLUMN_CSS_MAX_NUM)
			{
				cur_db.sItemCodeSizeCSS = "CodeMax";
				return_value = true;
			}
			else
			{
				cur_db.sItemCodeSizeCSS = "CodeMed";
			}

			if (cur_db.iAPDescSize_typ == clsConstant.COLUMN_CSS_MIN_NUM)
			{
				cur_db.sAPDescSizeCSS = "APDescMin";
				return_value = true;
			}
			else if (cur_db.iAPDescSize_typ == clsConstant.COLUMN_CSS_MAX_NUM)
			{
				cur_db.sAPDescSizeCSS = "APDescMax";
				return_value = true;
			}
			else
			{
				cur_db.sAPDescSizeCSS = "APDescStd";
			}

			if (cur_db.iARDescSize_typ == clsConstant.COLUMN_CSS_MIN_NUM)
			{
				cur_db.sARDescSizeCSS = "ARDescMin";
				return_value = true;
			}
			else if (cur_db.iARDescSize_typ == clsConstant.COLUMN_CSS_MAX_NUM)
			{
				cur_db.sARDescSizeCSS = "ARDescMax";
				return_value = true;
			}
			else if (cur_db.iARDescSize_typ == clsConstant.COLUMN_CSS_SERVICE_NUM)
			{
				cur_db.sARDescSizeCSS = "ARDescService";
				return_value = true;
			}
			else
			{
				cur_db.sARDescSizeCSS = "ARDescStd";
			}

			return return_value;

		}

		public static string CustomizeCSS(ref clsDatabase cur_db, string cur_css)
		{

			string return_value = "";

			if (!NeedToResizeItemCodeColumn(ref cur_db))
			{
				return cur_css;
			}

			return_value = cur_css;

			if (cur_db.iItemCodeSize_typ != clsConstant.COLUMN_CSS_STD_NUM && cur_db.sItemCodeSizeCSS != "")
			{
				return_value = moUtility.SReplace(return_value, "CodeStd", cur_db.sItemCodeSizeCSS);
			}

			if (cur_db.iAPDescSize_typ != clsConstant.COLUMN_CSS_STD_NUM && cur_db.sAPDescSizeCSS != "")
			{
				return_value = moUtility.SReplace(return_value, "APDescStd", cur_db.sAPDescSizeCSS);
			}

			if (cur_db.iARDescSize_typ != clsConstant.COLUMN_CSS_STD_NUM && cur_db.sARDescSizeCSS != "")
			{
				return_value = moUtility.SReplace(return_value, "ARDescStd", cur_db.sARDescSizeCSS);
			}

			return return_value;

		}

		public static string GetCompanyLogoFile(ref clsDatabase cur_db)
		{

			string return_value = "";
			string[] file_list;

			try
            {
				file_list = Directory.GetFiles(cur_db.uDirectory.sLogoDirectory_nm,  modConstant.COMPANY_LOGO_FILE_NAME + ".*");

				if (moUtility.IsEmpty(file_list[0]))
				{
					return "";
				}

				return_value = file_list[0];
			}
			catch (Exception ex)
            {
				// Directory.GetFiles() may generate an error.
			}

			return return_value;
		}

		public static int FindVoucherWithSameInvoiceNumber(ref clsDatabase cur_db, string vendor_code, string invoice_num, decimal voucher_amt)
		{

			int voucher_num = 0;
			string sql_str = "";
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			invoice_num = moUtility.EvalQuote(moUtility.STrim(invoice_num));
			vendor_code = moUtility.SUCase(moUtility.EvalQuote(moUtility.STrim(vendor_code)));

			if (moUtility.IsEmpty(invoice_num))
			{
				return 0;
			}

			sql_str = "SELECT iTransaction_num FROM tblAPChargeUnposted";
			sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_PURCHASE_TYPE.ToString();
			sql_str += " AND sVendor_cd = '" + vendor_code + "'";
			sql_str += " AND sYourReference = '" + invoice_num + "'";

			if (!cur_set.CreateSnapshot(sql_str))
			{
				return -1;
			}
			else if (!cur_set.EOF())
			{
				return cur_set.iField("iTransaction_num");
			}

			sql_str = "SELECT * FROM tblAPCharge";
			sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_PURCHASE_TYPE.ToString();
			sql_str += " AND sVendor_cd = '" + vendor_code + "'";
			sql_str += " AND sYourReference = '" + invoice_num + "'";
			sql_str += " AND iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM.ToString();
			sql_str += " ORDER BY iTransaction_num";

			if (!cur_set.CreateSnapshot(sql_str))
			{

				return -1;

			}
			else if (!cur_set.EOF())
			{

				// 08/30/2019
				// No more than one reference is allowed for each invoice unless it is cancelled/returned in full.
				// 1 : If a valid voucher with this invoice number exists, no more positive charge is allowed, but one and only one credit is allowed.
				// 2 : If original invoice is cancelled/returned in full, allow another invoice entry, but do not allow any credit.
				// With these two rules kept, we just need check the very last voucher as follows
				//
				cur_set.MoveLast();

				if (cur_set.mField("mTotal_amt") > 0 && cur_set.mField("mReturned_amt") > 0 && cur_set.mField("mDue_amt") <= 0 && cur_set.mField("mPaid_amt") <= 0)
				{

					// Last voucher is cancelled.  
					//
					if (voucher_amt >= 0)
					{
						voucher_num = 0; // Allow another voucher
					}
					else
					{
						cur_db.SetPostingError(invoice_num + cur_db.oLanguage.oMessage.HAS_BEEN_CANCELED_ALREADY); // No credit is allowed.
						return -1;
					}

				}
				else if (cur_set.mField("mTotal_amt") >= 0)
				{

					// Last voucher is valid
					//
					if (voucher_amt >= 0)
					{
						voucher_num = cur_set.iField("iTransaction_num");
					}
					else
					{
						voucher_num = 0; // credit is allowed
					}

				}
				else
				{

					// Last voucher is a credit
					// No more credit or charge is allowed.
					//
					voucher_num = cur_set.iField("iTransaction_num");

				}

			}

			return voucher_num;

		}

		public static string GetListText(List<Models.clsCombobox> cur_list, string list_value)
        {
			string return_value = "";

			try
            {
				return_value = cur_list.Find(i => i.Value == list_value).Text;
			}
			catch
            {
				return_value = "";
			}

			return return_value;
		}

		public static int GetNextLineId(string[,] cur_data, int line_id_col)
        {
			int return_value = 1;
			int row_num = 0;

			try
            {
				if (cur_data.GetUpperBound(0) >= line_id_col)
				{
					for (row_num = 0; row_num <= cur_data.GetUpperBound(1); row_num++)
					{
						if (return_value <= moUtility.ToInteger(cur_data[line_id_col, row_num]))
						{
							return_value = moUtility.ToInteger(cur_data[line_id_col, row_num]) + 1;
						}
					}
				}
			}
			catch
            {
				// cur_data could in valid
			}

			return return_value;
        }
		public static string GetFieldValue(clsDatabase cur_db, clsRecordset cur_set, string field_name, int trx_type)
		{
			string return_value = "";
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);

			if (moUtility.IsEmpty(field_name))		// Can send empty field name.  DO NOT DELETE
            {
				return_value = "";
			}
			else if (moUtility.SUCase(field_name) == moUtility.SUCase("iExpense_typ") && trx_type == GlobalVar.goConstant.TRX_EXPENSE_TYPE)
            {
				return_value = GlobalVar.goStatus.QuickExpenseTypeText(cur_set.iField(field_name));
			}
			else if (moUtility.SUCase(field_name) == moUtility.SUCase("iOrder_num") && trx_type == GlobalVar.goConstant.TRX_EXPENSE_TYPE)
			{
				if (cur_set.iField(field_name) > 0)
                {
					return_value = cur_set.iField(field_name).ToString();
				}
			}
			else if (moUtility.SUCase(field_name) == moUtility.SUCase("iCash_typ"))
            {
				return_value = GlobalVar.goStatus.CashTypeText(cur_set.iField(field_name));
			}
			else if (moUtility.SUCase(field_name) == moUtility.SUCase("iStatus_typ"))
            {
				if (trx_type == GlobalVar.goConstant.TRX_SO_TYPE)
				{
					return_value = GlobalVar.goStatus.OrderStatusTypeText(cur_set.iField(field_name));
				}
				else if (trx_type == GlobalVar.goConstant.TRX_QUOTE_TYPE)
				{
					return_value = GlobalVar.goStatus.QuoteStatusTypeText(cur_set.iField(field_name));
				}
				else if (trx_type == GlobalVar.goConstant.TRX_PO_TYPE)
				{
					return_value = GlobalVar.goStatus.PurchaseOrderStatusTypeText(cur_set.iField(field_name));
				}
				else if (trx_type == GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE)
				{
					return_value = GlobalVar.goStatus.PurchaseRequisitionStatusTypeText(cur_set.iField(field_name));
				}
				else if (trx_type == GlobalVar.goConstant.TRX_WO_TYPE || trx_type == GlobalVar.goConstant.TRX_FA_SERVICE_PLAN_TYPE)
                {
					return_value = GlobalVar.goStatus.WorkOrderStatusTypeText(cur_set.iField(field_name));
				}
				else if (trx_type == GlobalVar.goConstant.TRX_IV_MANUFACTURING_TYPE)
				{
					return_value = GlobalVar.goStatus.AssemblyStatusTypeText(cur_set.iField(field_name));
				}
				else if (trx_type == GlobalVar.goConstant.TRX_FA_RENTAL_RESERVATION_TYPE || trx_type == GlobalVar.goConstant.TRX_FA_RENTAL_TYPE || trx_type == GlobalVar.goConstant.TRX_FA_RENTAL_RETURN_TYPE)
				{
					return_value = GlobalVar.goStatus.RentalStatusTypeText(cur_set.iField(field_name));
				}
				else if (trx_type == 0)
				{
					return_value = "";
				}
				else
				{
					return_value = GlobalVar.goStatus.TransactionPostedStatusTypeText(cur_set.iField(field_name));
				}
			}
			else if (moUtility.SUCase(moUtility.SLeft(field_name, 2)) == "DT")
			{
				return_value = cur_set.dtField(field_name).ToString();
			}
			else if (moUtility.IsNumericField(field_name))
			{
				if (moUtility.IsDateField(field_name))
				{
					return_value = o_gen.ToStrDate(cur_set.iField(field_name));
				}
				else if (moUtility.SUCase(moUtility.SLeft(field_name, 1)) == "M")
				{
					return_value = o_money.ToStrMoney(cur_set.mField(field_name), -1, "", true);
				}
				else if (moUtility.SUCase(moUtility.SLeft(field_name, 1)) == "I" && moUtility.SUCase(moUtility.SRight(field_name, 3)) == "_FL")
				{
					if (cur_set.iField(field_name) > 0)
                    {
						return_value = "Yes";
					}
					else
                    {
						return_value = "No";
					}
				}
				else
				{
					return_value = cur_set.iField(field_name).ToString();
				}
			}
			else if (moUtility.SUCase(moUtility.SLeft(field_name, 1)) == "S")
            {
				return_value = cur_set.sField(field_name);
			}
			else
			{
				return_value = cur_set.Field(field_name).ToString();
			}

			return return_value;
		}

		public static  string GetComboText(List<Models.clsCombobox> cur_box, string cur_value)
		{
			try
			{
				return cur_box.Single(i => i.Value == cur_value).Text;
			}
			catch
			{
				return "";
			}
		}

		public static string GetComboValue(List<Models.clsCombobox> cur_box, string cur_text)
		{
			try
			{
				return cur_box.Single(i => i.Text == cur_text).Value;
			}
			catch
			{
				return "";
			}
		}

		public static int GetComboIndex(List<Models.clsCombobox> cur_box, string cur_value)
		{
			int value_index = 0;

			try
			{
				for (value_index = 0; value_index < cur_box.Count; value_index++)
                {
					if (cur_box[value_index].Value == cur_value)
                    {
						return value_index;
					}
				}

				return -1;

				// We need to find a better way later.
				//
				//foreach (var ea in cur_box)
    //            {
				//	value_index = 0;

				//	if (ea.Value == cur_value)
    //                {
				//		return value_index;
				//	}
    //            }
			}
			catch
			{
			}

			return value_index;
		}

		public static bool CompleteMemo(ref clsDatabase cur_db, string[,] detail_data, int item_type_col, int qty_authorized_col, int qty_returned_col, bool from_complete_button_fl, ref string date_completed)
		{ 
			bool return_value = false;
			bool inventory_exist_fl = false;
			int row_num = 0;

			clsGeneral o_gen = new clsGeneral(ref cur_db);

			try
			{
				if (from_complete_button_fl)
				{
					if (moUtility.IsBlankDate(date_completed))
					{
						date_completed = o_gen.ToStrDate(o_gen.CurrentDate());
					}
				}
				else if (cur_db.uProgram.bWHExist_fl == false || cur_db.uProgram.bIVExist_fl == false)
				{
					if (moUtility.IsBlankDate(date_completed))
					{
						date_completed = o_gen.ToStrDate(o_gen.CurrentDate());
					}
				}
				else
				{
					// Inventory items need to be shipped at W/H deck unless it completes here.
					//
					inventory_exist_fl = false;

					for (row_num = 0; row_num < detail_data.GetLength(1); row_num++)
					{

						if (moUtility.IsInventoryItemType(moUtility.ToInteger(detail_data[item_type_col, row_num])) && moUtility.ToValue(detail_data[qty_authorized_col, row_num]) > moUtility.ToValue(detail_data[qty_returned_col, row_num]))
						{
							inventory_exist_fl = true;
							break;
						}

					}

					if (inventory_exist_fl)
					{
						date_completed = "";
					}
					else
					{
						date_completed = o_gen.ToStrDate(o_gen.CurrentDate());
					}
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CompleteMemo)");
			}

			return return_value;
		}

		public static string GetDummyCheckFileName(ref clsDatabase cur_db)
		{

			string return_value = null;

			return_value = modCommonReportUtility.GetReportInitial(ref cur_db) + "DummyCheck.rpt";

			return return_value;

		}


		public static void GetColumnNames(ref clsDatabase cur_db, clsRecordset cur_set, ref string[] captions, int max_col, bool eliminate_all_suffix_fl = false, bool eliminate_amt_fl = false, bool eliminate_qty_fl = false, bool wrap_down_fl = true)
		{
			int i = 0;
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			if (cur_set.FieldCount() < max_col)
            {
				max_col = cur_set.FieldCount();
			}

			moUtility.ResizeDim(ref captions, max_col);       // max_col should be the upper bound of captions

			try
			{
				for (i = 0; i < max_col; i++)
				{
					captions[i + 1] = o_gen.GetReadableFieldName(cur_set.Name(i), eliminate_all_suffix_fl, eliminate_amt_fl, eliminate_qty_fl, wrap_down_fl);       // Do not use captions[0]
				}

			}
			catch (Exception ex)
			{
				
			}

		}
		public static bool GetDepreciationPlan(ref clsDatabase cur_db, ref clsFixedAsset fixed_asset, ref string[,] plan_data, ref decimal amt_total_depreciated, int year_col_num, int yearly_total_col_num, int period_1_col_num, bool generate_fl)
		{
			bool return_value = false;
			string first_year = null;
			string last_year = null;
			int row_num = 0;
			int col_num = 0;
			int i = 0;
			int total_rows = 0;
			int months_in_year = 0;
			int total_years = 0;
			int year_id = 0;
			int period_id = 0;
			decimal amt_yearly_total = 0;
			string[,] monthly_data = null;

			clsRecordset cur_set = new clsRecordset(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);
			clsValidate o_valid = new clsValidate(ref cur_db);

			try
			{
				moUtility.ResizeDim(ref plan_data, plan_data.GetUpperBound(0), 0);

				if (cur_db.bUseCalendarYearForDepreciation_fl) // User can pick calendar year instead of fiscal year.
				{
					months_in_year = 12;
				}
				else
				{
					if (!cur_set.CreateSnapshot("SELECT COUNT(*) AS iCount FROM tblGLPeriodDet WHERE sFiscalYear = '" + cur_db.sCurFiscalYear + "'"))
					{
						return false;
					}
					else if (cur_set.EOF()) // Not expected
					{
						return false;
					}
					else
					{
						months_in_year = cur_set.iField("iCount");
					}
				}

				if (months_in_year != 12 && months_in_year != 13)
                {
					modDialogUtility.DisplayBox(ref cur_db, "Depreciation periods should be 12 or 13.");			// Not expected
					return false;
                }

				fixed_asset.iFiscalPeriods = months_in_year;
				fixed_asset.iStartingYear_id = 0;
				fixed_asset.iStartingMonth_id = 0;
				fixed_asset.iTotalMonthsAlreadyDepreciated_num = 0;

				amt_total_depreciated = 0;

				// Grab the depreciation schedule if exist already.
				// ************************************************************************************
				//
				if (!cur_set.CreateSnapshot("SELECT * FROM tblFAAssetDetPeriodic WHERE sAsset_cd = '" + fixed_asset.sAsset_cd + "' ORDER BY sDepreciateYear, iPeriod_id"))
				{
					return false;
				}

				if (cur_set.EOF() == false)
				{
					cur_set.MoveLast();
					last_year = cur_set.sField("sDepreciateYear");
					cur_set.MoveFirst();
					first_year = cur_set.sField("sDepreciateYear");

					if (moUtility.ToInteger(last_year) - moUtility.ToInteger(first_year) > fixed_asset.iUsefulLife_num)
					{
						total_rows = (moUtility.ToInteger(last_year) - moUtility.ToInteger(first_year) + 3); // Need 3 extra years just in case they need adjustments.
					}
					else
					{
						total_rows = (fixed_asset.iUsefulLife_num + 3);
					}

					moUtility.ResizeDim(ref plan_data, plan_data.GetUpperBound(0), total_rows - 1);

					last_year = "";
					row_num = 0;

					while (cur_set.EOF() == false)
					{

						if (last_year != cur_set.sField("sDepreciateYear"))
						{
							last_year = cur_set.sField("sDepreciateYear");
						}

						plan_data[year_col_num, row_num] = last_year;
						amt_yearly_total = 0;

						while (cur_set.EOF() == false)
						{
							if (last_year != cur_set.sField("sDepreciateYear"))
							{
								break;
							}

							amt_total_depreciated += cur_set.mField("mDepreciation_amt");
							amt_yearly_total += cur_set.mField("mDepreciation_amt");
							col_num = period_1_col_num - 1 + cur_set.iField("iPeriod_id");

							// Lock the periods that have been processed already.
							//
							if (cur_set.mField("mDepreciation_amt") > 0)
							{
								if (cur_set.iField("iDepreciation_dt") > 0)
								{
									plan_data[col_num, row_num] = o_money.ToStrMoney(cur_set.mField("mDepreciation_amt"));
									fixed_asset.iStartingYear_id = moUtility.ToInteger(cur_set.sField("sDepreciateYear"));
									fixed_asset.iStartingMonth_id = cur_set.iField("iPeriod_id");
									fixed_asset.iTotalMonthsAlreadyDepreciated_num += 1;
								}
								else if (fixed_asset.iStartingMonth_id == 0 || !fixed_asset.bRefresh_fl)
								{
									plan_data[col_num, row_num] = o_money.ToStrMoney(cur_set.mField("mDepreciation_amt"));
								}
							}

							cur_set.MoveNext();
						}

						plan_data[yearly_total_col_num, row_num] = o_money.ToStrMoney(amt_yearly_total);

						row_num += 1; // DO NOT move up.
					}

					// Set the years.
					//
					for (i = row_num; i < plan_data.GetLength(1); i++)
					{
						plan_data[year_col_num, i] = (moUtility.ToInteger(last_year) + i - row_num + 1).ToString();
					}

					// Deactivate the initial cells that are not used.
					//
					for (i = period_1_col_num; i < period_1_col_num + months_in_year; i++)
					{
						if (moUtility.IsNonEmpty(plan_data[i, 0]))
						{
							break;
						}
					}

					// If not to refresh, return.
					//
					if (fixed_asset.bRefresh_fl == false)
					{
						return true;
					}

				}

				// If there exists periods that has been processed already, start from the next period.
				// ************************************************************************************
				//
				if (fixed_asset.iTotalMonthsAlreadyDepreciated_num > 0 && fixed_asset.AmountToDepreciate() > 100)
				{
					fixed_asset.iStartingMonth_id += 1;

					if (fixed_asset.iStartingMonth_id > months_in_year)
					{
						fixed_asset.iStartingMonth_id -= months_in_year;
						fixed_asset.iStartingYear_id += 1;
					}
				}
				else
				{
					if (generate_fl == false)
					{
						return true;
					}
				}

				// Create the plan.
				// ************************************************************************************
				//
				if (fixed_asset.CreatePlan(ref monthly_data, ref amt_total_depreciated) == false)
				{
					return false;
				}

				// goUtility.PrintOutArray(plan_data, "c:\temp\print_out.txt")

				//if (plan_data.GetLength(1) <= 1)
				//{
						moUtility.ResizeDim(ref plan_data, plan_data.GetUpperBound(0), fixed_asset.iUsefulLife_num + 3);
				//}

				// If depreciation started already, preserve the years processed already.
				// ************************************************************************************
				//
				if (!moUtility.IsEmpty(first_year))
				{

					year_id = moUtility.ToInteger(first_year);

				}
				else
				{

					if (cur_db.bUseCalendarYearForDepreciation_fl)
					{
						year_id = moUtility.GetYear(fixed_asset.iInUse_dt);
					}
					else if (o_valid.IsValidGLPeriod(fixed_asset.iInUse_dt))
					{
						year_id = moUtility.ToInteger(o_valid.oRecordset.sField("sFiscalYear"));
					}
					else
					{
						year_id = moUtility.ToInteger(cur_db.sCurFiscalYear);
					}

				}

				for (i = 0; i < plan_data.GetLength(1); i++)
				{
					plan_data[year_col_num, i] = year_id.ToString();
					year_id += 1;
				}

				// Show the periods that are already processed.
				// ************************************************************************************
				//
				if (fixed_asset.mDepreciated_amt > 0)
				{
					if (!cur_set.CreateSnapshot("SELECT * FROM tblFAAssetDetPeriodic WHERE sAsset_cd = '" + fixed_asset.sAsset_cd + "' AND iDepreciation_dt > 0 ORDER BY sDepreciateYear, iPeriod_id"))
					{
						return false;
					}

					row_num = 0;

					while (!cur_set.EOF())
					{
						if (row_num >= plan_data.GetLength(1))
						{
							cur_db.SetPostingError("Cannot find periods depreciated, already.");
							return false;
						}

						if (plan_data[year_col_num, row_num] != cur_set.sField("sDepreciateYear"))
						{
							row_num += 1;
						}
						else
						{
							plan_data[period_1_col_num + cur_set.iField("iPeriod_id") - 1, row_num] = o_money.ToStrMoney(cur_set.mField("mDepreciation_amt"));
							cur_set.MoveNext();
						}
					}
				}

				// Move the year pointer to the starting year.
				//
				for (year_id = 0; year_id < plan_data.GetLength(1); year_id++)
				{
					if (fixed_asset.iStartingYear_id <= moUtility.ToInteger(plan_data[year_col_num, year_id]))
					{
						break;
					}
				}

				// By now, Data in monthly_data() has been already pushed back to the starting month 
				// so that all periods prior to the starting month are empty.
				// ************************************************************************************
				// 
				i = 0;

				while (i <= monthly_data.GetUpperBound(1))
				{

					if (year_id > moUtility.ToInteger(plan_data[year_col_num, year_id]))
					{
						break;
					}

					for (col_num = period_1_col_num; col_num < period_1_col_num + months_in_year; col_num++)
					{

						period_id = col_num - period_1_col_num + 1;

						if (i > monthly_data.GetUpperBound(1))
						{

							break;

						}
						else if (moUtility.ToInteger(plan_data[year_col_num, year_id]) > fixed_asset.iStartingYear_id && moUtility.IsEmpty(monthly_data[clsFixedAsset.AMOUNT_COL, i]))
						{

							plan_data[col_num, year_id] = ""; // If to refresh, there could be leftovers.
							i += 1;

						}
						else if (moUtility.ToInteger(plan_data[year_col_num, year_id]) > fixed_asset.iStartingYear_id && period_id > moUtility.ToInteger(monthly_data[clsFixedAsset.PERIOD_COL, i]))
						{

							break; // Move down to the next year.

						}
						else
						{

							if (o_money.ToNumMoney(monthly_data[clsFixedAsset.AMOUNT_COL, i]) > 0)
							{

								plan_data[col_num, year_id] = o_money.ToStrMoney(o_money.ToNumMoney(monthly_data[clsFixedAsset.AMOUNT_COL, i]));

							}

							i += 1;

						}

					}

					year_id += 1;
				}

				// Just recreate the totals.  Due to the adjustments, totals may not match.
				// ************************************************************************************
				//
				amt_total_depreciated = 0;

				for (row_num = 0; row_num < plan_data.GetLength(1); row_num++)
				{

					amt_yearly_total = 0;

					for (col_num = period_1_col_num; col_num < period_1_col_num + months_in_year; col_num++)
					{
						amt_yearly_total += o_money.ToNumMoney(plan_data[col_num, row_num]);
						amt_total_depreciated += o_money.ToNumMoney(plan_data[col_num, row_num]);
					}

					if (amt_yearly_total > 0)
					{
						plan_data[yearly_total_col_num, row_num] = o_money.ToStrMoney(amt_yearly_total);
					}
					else
					{
						plan_data[yearly_total_col_num, row_num] =  "";
					}

				}

				return_value = true;

			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(GetDepreciationPlan)");
			}

			return return_value;
		}
		public static bool SaveYearlyPlan(ref clsDatabase cur_db, ref string[,] plan_data, string asset_code, int year_col, int yearly_amt_col)
		{
			bool return_value = false;
			string sql_str = null;
			int row_num = 0;
			int next_num = 0;
			int last_row = 0;

			clsRecordset cur_set = new clsRecordset(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);

			try
			{
				sql_str = "SELECT * FROM tblFAAssetDet WHERE sAsset_cd='" + asset_code + "' AND iDepreciation_dt > 0"; // Save the years that depreciation is complete
				if (cur_set.CreateSnapshot(sql_str) == false)
				{
					return false;
				}

				// Recreate the whole plan because method can change and yearly totals can change.
				//
				sql_str = "DELETE FROM tblFAAssetDet WHERE sAsset_cd='" + asset_code + "'";
				if (cur_db.ExecuteSQL(sql_str) == false)
				{
					return false;
				}

				for (last_row = plan_data.GetUpperBound(1); last_row >= 0; last_row--)
				{
					if (o_money.ToNumMoney(plan_data[yearly_amt_col, last_row]) > 0)
					{
						break;
					}
				}

				next_num = 0;

				for (row_num = 0; row_num <= last_row; row_num++)
				{
					if (o_money.ToNumMoney(plan_data[yearly_amt_col, row_num]) > 0) // If nothing is planned, do not create the blank ones.
					{
						next_num += 1;

						sql_str = "INSERT INTO tblFAAssetDet(";
						sql_str += "sAsset_cd";
						sql_str += ",iDetail_num";
						sql_str += ",sDepreciateYear";
						sql_str += ",iDepreciation_dt";
						sql_str += ",mDepreciation_amt";
						sql_str += ",sLastUpdate_id";
						sql_str += ",dtLastUpdate_dt";
						sql_str += ") VALUES (";
						sql_str += "'" + asset_code + "'";
						sql_str += "," + next_num.ToString();
						sql_str += ",'" + plan_data[year_col, row_num] + "'";

						// Preserve the yearly depreciation date
						//
						if (cur_set.FindRecord("sDepreciateYear", plan_data[year_col, row_num]))
						{
							sql_str += "," + cur_set.iField("iDepreciation_dt").ToString();
						}
						else
						{
							sql_str += ",0";
						}

						sql_str += "," + o_money.ToNumMoney(plan_data[yearly_amt_col, row_num]).ToString();
						sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
						sql_str += ")";
						if (cur_db.ExecuteSQL(sql_str) == false)
						{
							return false;
						}
					}

				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(SaveYearlyPlan)");
			}

			return return_value;
		}

		public static bool SaveMonthlyPlan(ref clsDatabase cur_db, ref string[,] plan_data, string asset_code, int year_col, int yearly_amt_col, int period_1_col, int last_period_col)
		{
			bool return_value = false;
			string sql_str = null;
			int row_num = 0;
			int col_num = 0;
			int next_num = 0;
			int last_row = 0;
			decimal total_amt = 0M;
			decimal yearly_amt = 0M;
			clsRecordset cur_set = new clsRecordset(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);

			try
			{
				sql_str = "DELETE FROM tblFAAssetDetPeriodic WHERE sAsset_cd='" + asset_code + "' AND iDepreciation_dt = 0";
				if (cur_db.ExecuteSQL(sql_str) == false)
				{
					cur_db.TransactionRollback();
					return return_value;
				}

				for (last_row = plan_data.GetUpperBound(1); last_row >= 0; last_row--)
				{
					if (o_money.ToNumMoney(plan_data[yearly_amt_col, last_row]) > 0)
					{
						break;
					}
				}

				for (row_num = 0; row_num <= last_row; row_num++)
				{
					for (col_num = period_1_col; col_num <= last_period_col; col_num++)
					{
						if (o_money.ToNumMoney(plan_data[col_num, row_num]) > 0)
						{
							sql_str = "INSERT INTO tblFAAssetDetPeriodic(";
							sql_str += "sAsset_cd";
							sql_str += ",sDepreciateYear";
							sql_str += ",iPeriod_id";
							sql_str += ",iDepreciation_dt";
							sql_str += ",mDepreciation_amt";
							sql_str += ",sLastUpdate_id";
							sql_str += ",dtLastUpdate_dt";
							sql_str += ") VALUES (";
							sql_str += "'" + asset_code + "'";
							sql_str += ",'" + plan_data[year_col, row_num] + "'";
							sql_str += "," + (col_num - period_1_col + 1).ToString();
							sql_str += ",0";
							sql_str += "," + o_money.ToNumMoney(plan_data[col_num, row_num]).ToString();
							sql_str += ",'" + cur_db.sUser_cd + "'";
							sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
							sql_str += ")";
							if (cur_db.ExecuteSQL(sql_str) == false)
							{
								return return_value;
							}
						}

					}

				}

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(SaveMonthlyPlan)");

			}

			return return_value;

		}

		public static string GetCustomerList(ref clsDatabase cur_db, string salesrep_code)
        {
			string return_value = "";
			string sql_str = "SELECT sCustomer_cd FROM tblARCustomer WHERE sSalesrep_cd = '" + salesrep_code + "'";
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			if (cur_set.CreateSnapshot(sql_str))
            {
				while (cur_set.EOF() == false)
                {
					return_value += moUtility.IIf(moUtility.IsEmpty(return_value), "'", ",'") + cur_set.sField("sCustomer_cd") + "'";
					cur_set.MoveNext();
				}
			}

			return return_value;
        }

		public static string GetGenericColumnText(ref clsDatabase cur_db, clsRecordset cur_set, int field_num, bool supress_zero_amt_fl = false, bool integer_money_fl = false)
		{

			string return_value = null;
			string tmp = null;
			string ret_val = null;
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);

			try
			{

				ret_val = "";
				tmp = cur_set.Field(field_num).ToString();

				if (moUtility.SUCase(moUtility.SLeft(cur_set.Name(field_num), 1)) == "I" && moUtility.SUCase(moUtility.SRight(cur_set.Name(field_num), 3)) == "_DT")
				{
					if (moUtility.ToValue(tmp) > 10000000)
					{
						ret_val = o_gen.ToStrDate(moUtility.ToInteger(tmp));
					}
					else
					{
						ret_val = "";
					}
				}
				else if (moUtility.SUCase(moUtility.SLeft(cur_set.Name(field_num), 1)) == "I")
				{
					if (moUtility.SUCase(moUtility.SRight(cur_set.Name(field_num), 3)) == "_FL")
					{
						if (moUtility.ToValue(tmp) > 0)
						{
							ret_val = cur_db.oLanguage.oString.STR_YES;
						}
						else
						{
							ret_val = cur_db.oLanguage.oString.STR_NO;
						}
					}
					else if (moUtility.SUCase(cur_set.Name(field_num)) == "ITRX_TYP" || moUtility.SUCase(cur_set.Name(field_num)) == "ITRX_TYPE" || moUtility.SUCase(cur_set.Name(field_num)) == "ITRANSACTION_TYP")
                    {
						ret_val = moUtility.GetTransactionTypeText(cur_db, moUtility.ToInteger(tmp)) ;
					}
					else
					{
						ret_val = tmp;
					}
				}
				else if (moUtility.SUCase(moUtility.SLeft(cur_set.Name(field_num), 1)) == "M")
				{
					if (supress_zero_amt_fl && moUtility.ToValue(tmp) == 0)
					{
						ret_val = "";
					}
					else
					{
						if (integer_money_fl)
                        {
							ret_val = o_money.ToStrMoney(moUtility.ToValue(tmp), 0);
						}
						else
                        {
							ret_val = o_money.ToStrMoney(moUtility.ToValue(tmp));
						}
					}
				}
				else if (moUtility.SUCase(moUtility.SLeft(cur_set.Name(field_num), 1)) == "F")
				{
					ret_val = moUtility.RoundToQtyFactor(moUtility.ToValue(tmp)).ToString();
				}
				else
				{
					ret_val = tmp;
				}

				return_value = ret_val;

			}
			catch (Exception ex)
			{

			}

			return return_value;

		}

		public static string AddCommonTransactionSearchClause(string where_clause, int trx_type, string year_from = "")
        {
			string return_value = where_clause;

			if (moUtility.IsNonEmpty(year_from))
            {
				// All transactions have iEntry_dt field
				//
				if (moUtility.SInStr(moUtility.SUCase(where_clause), "_DT") <= 0)
				{
					return_value += moUtility.IIf(moUtility.IsNonEmpty(return_value), " AND ", "") + "(iEntry_dt >= " + year_from + "0000)";
				}
			}

			return return_value;
		}

		public static decimal GetDepositAmount(ref clsDatabase cur_db, Models.clsPage cur_page, string document_num, string entity_code, string currency_code = "")
        {
			decimal return_value = 0;
			string sql_str = "";
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			document_num = moUtility.STrim(document_num);

			if (moUtility.IsEmpty(document_num))
            {
				return 0;
            }

			// If this is memo
			//
			if (moUtility.IsNumeric(document_num))
            {
				if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_PAYMENT_TYPE)
				{
					sql_str = "SELECT * FROM tblAPCharge WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_DM_TYPE.ToString();
				}
				else
				{
					sql_str = "SELECT * FROM tblARCharge WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_CM_TYPE.ToString();
				}

				sql_str += " AND iTransaction_num = " + document_num;
				if (cur_set.CreateSnapshot(sql_str) == false)
                {
					return 0;
                }
				if (cur_set.EOF())
                {
					return 0;
                }

				return cur_set.mField("mDue_amt");
			}

			// If this is a deposit
			//
			if (moUtility.IsEmpty(currency_code))
            {
				currency_code = cur_db.sCurrency_cd;
			}

			if (cur_page.iTransaction_typ == GlobalVar.goConstant.TRX_PAYMENT_TYPE)
			{
				sql_str = "SELECT * FROM tblAPVendorDeposit WHERE sVendor_cd = '" + entity_code + "' AND sCurrency_cd = '" + currency_code + "'";
			}
			else
			{
				sql_str = "SELECT * FROM tblARCustomerDeposit WHERE sCustomer_cd = '" + entity_code + "' AND sCurrency_cd = '" + currency_code + "'";
			}

			if (cur_set.CreateSnapshot(sql_str) == false)
			{
				return 0;
			}
			if (cur_set.EOF())
			{
				return 0;
			}

			return cur_set.mField("mDepositInPrimary_amt");
		}

		public static bool CheckPageAccessibility(ref clsDatabase cur_db, clsUser cur_user, string page_name)
		{
			bool return_value = false;
			string sql_str = "";

			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{
                if (moUtility.IsSystemAdministrator(cur_db))	// SA can access all pages
				{
					return true;
				}

                sql_str = "SELECT sWebPage_nm from tblGOMenuNames";
				sql_str += " WHERE sWebPage_nm = '" + page_name+ "'";
                sql_str += " AND sDisplayOrder_id IN (SELECT sMenu_nm FROM tblGOUserGroupSecurity WHERE sModule_id = '" + modGeneralUtility.GetWebModuleID() + "' AND sUserGroup_cd = '" + cur_user.sUserGroup_cd + "')";
				if (cur_set.CreateSnapshot(sql_str) == false)
				{
					return false;
				}
				if (cur_set.EOF())
				{
					return false;
				}

                return_value = true; 
			}
			catch (Exception ex)
			{
				cur_db.SetPostingError(ex.Message + " (CheckPageAccessibility)");
			}

			return return_value;
		}
    }

}
