﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Local;
using Dynasty.Database;
namespace Dynasty.ASP
{
#if WEB
#else
using System.Windows.Forms;
//	Imports System.Windows.Forms.Application
#endif

    //  THIS IS THE COLLECTION OF LOADING FOR BOTH WEB/WIN VERSION.
    //  THIS WORKS WITH WinLoadUtility and WebLoadUtility.
    //
    internal static class modLoadUtility
    {

        private static clsDynastyUtility moUtility = new clsDynastyUtility();

#if WEB
        public static void LoadBusinessType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadBusinessType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.SERVICE_BUSINESS, Convert.ToString(GlobalVar.goConstant.SERVICE_BUSINESS_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.INVENTORY_BUSINESS, Convert.ToString(GlobalVar.goConstant.INVENTORY_BUSINESS_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.NP_BUSINESS, Convert.ToString(GlobalVar.goConstant.NP_BUSINESS_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadInventoryCostType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadInventoryCostType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goIVConstant.AVG_COST, Convert.ToString(GlobalVar.goIVConstant.AVG_COST_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goIVConstant.FIFO_COST, Convert.ToString(GlobalVar.goIVConstant.FIFO_COST_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goIVConstant.LIFO_COST, Convert.ToString(GlobalVar.goIVConstant.LIFO_COST_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadInventoryOversoldType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadInventoryOversoldType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.OVERSOLD_WITH_NO_RESTRICTION, Convert.ToString(GlobalVar.goConstant.OVERSOLD_WITH_NO_RESTRICTION_NUM)));
#if !WEB
        			item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.OVERSOLD_WITH_WARNING, Convert.ToString(GlobalVar.goConstant.OVERSOLD_WITH_WARNING_NUM))); // WEB has no way to communicate with user
#endif
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.OVERSOLD_NOT_ALLOWED, Convert.ToString(GlobalVar.goConstant.OVERSOLD_NOT_ALLOWED_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

        // This routine should work with
        //       GetInvoiceType() and GetInvoiceTypeNum()
        //
#if WEB
        public static void LoadInvoiceType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadInvoiceType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LI1, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LI1_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LI2, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LI2_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LW1, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LW1_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LS1, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LS1_NUM)));
            //item_list.Add(New clsComboBoxItem(goARConstant.INVOICE_TYPE_LM1, CStr(goARConstant.INVOICE_TYPE_LM1_NUM)))
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LC1, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LC1_NUM)));

#if !WEB
        			if (!IsLiteVersion())
        			{
        				item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LM1, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LM1_NUM)));
        			}
#endif

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadReprintInvoiceType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadReprintInvoiceType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LI1, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LI1_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LW1, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LW1_NUM)));
            //item_list.Add(New clsComboBoxItem(goARConstant.INVOICE_TYPE_LM1, CStr(goARConstant.INVOICE_TYPE_LM1_NUM)))
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LC1, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LC1_NUM)));

#if !WEB
        			if (!IsLiteVersion())
        			{
        				item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LM1, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LM1_NUM)));
        			}
#endif

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadCMType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCMType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LI1, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LI1_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LW1, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LW1_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LC1, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LC1_NUM)));
            //item_list.Add(New clsComboBoxItem(goARConstant.INVOICE_TYPE_LM1, CStr(goARConstant.INVOICE_TYPE_LM1_NUM)))

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadReprintCMType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadReprintCMType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LI1, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LI1_NUM)));
            //item_list.Add(New clsComboBoxItem(goARConstant.INVOICE_TYPE_LW1, CStr(goARConstant.INVOICE_TYPE_LW1_NUM)))
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LC1, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LC1_NUM)));
            //item_list.Add(New clsComboBoxItem(goARConstant.INVOICE_TYPE_LM1, CStr(goARConstant.INVOICE_TYPE_LM1_NUM)))

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadStatementType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadStatementType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.STATEMENT_TYPE_F, Convert.ToString(GlobalVar.goARConstant.STATEMENT_TYPE_F_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.STATEMENT_TYPE_L, Convert.ToString(GlobalVar.goARConstant.STATEMENT_TYPE_L_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadSegmentType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_blank_fl = false)
        {
#else
        		public static void LoadSegmentType(ref ComboBox cur_box, bool add_blank_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                cur_box.Clear();

                sql_str = "SELECT * FROM tblGLSegmentType ORDER BY iSegmentLevel";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                if (add_blank_fl)
                {
                    item_list.Add(new clsComboBoxItem("", "0"));
                }

                while (!cur_set.EOF())
                {

                    if (moUtility.IsNonEmpty(cur_set.sField("sSegment_nm")))
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sSegment_nm"), Convert.ToString(cur_set.iField("iSegmentLevel"))));
                    }

                    cur_set.MoveNext();

                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                if (add_blank_fl)
                {

                }
                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadSegmentType)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadSegmentType)");
#endif
                return;

            }

        }

#if WEB
        public static void LoadItemStatusType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool include_trx_status_fl)
        {
#else
        		public static void LoadItemStatusType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));

            item_list.Add(new clsComboBoxItem(GlobalVar.goIVConstant.OPEN_ITEM, Convert.ToString(GlobalVar.goIVConstant.OPEN_ITEM_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goIVConstant.CLOSED_ITEM, Convert.ToString(GlobalVar.goIVConstant.CLOSED_ITEM_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goIVConstant.HOLD_ITEM, Convert.ToString(GlobalVar.goIVConstant.HOLD_ITEM_NUM)));

            if (include_trx_status_fl)
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goIVConstant.SELL_ONLY_ITEM, Convert.ToString(GlobalVar.goIVConstant.SELL_ONLY_ITEM_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goIVConstant.PURCHASE_ONLY_ITEM, Convert.ToString(GlobalVar.goIVConstant.PURCHASE_ONLY_ITEM_NUM)));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadReturnCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool clear_flag = true)
        {
#else
        		public static void LoadReturnCode(ref ComboBox cur_box, bool clear_flag = true)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sReturn_cd, sDescription FROM tblIVReturn";
            sql_str += " ORDER BY sReturn_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sReturn_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sReturn_cd"), cur_set.sField("sReturn_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

        public static void LoadLocationCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool clear_flag = true, bool add_all_flag = false, bool add_description_fl = false)
        {

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);

            try
            {
                cur_box.Clear();
                item_list.Add(new clsComboBoxItem("", ""));

                if (cur_db.bRestrictLocation_fl && moUtility.IsNonEmpty(cur_db.sCurLocation_cd))
                {
                    item_list.Add(new clsComboBoxItem(cur_db.sCurLocation_cd, cur_db.sCurLocation_cd));
                    modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                    return;
                }

                sql_str = "SELECT * FROM tblIVLocation";
                sql_str += " ORDER BY sLocation_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                if (add_all_flag)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL, cur_db.oLanguage.oString.STR_ALL));
                }

                while (!cur_set.EOF())
                {
                    if (add_description_fl)
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sLocation_cd") + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + cur_set.sField("sDescription"), cur_set.sField("sLocation_cd")));
                    }
                    else
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sLocation_cd"), cur_set.sField("sLocation_cd")));
                    }
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadARDunnCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadARDunnCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sDunn_cd FROM tblARDunn";
            sql_str += " ORDER BY sDunn_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sDunn_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDunn_cd"), cur_set.sField("sDunn_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadAPDunnCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadAPDunnCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sDunn_cd FROM tblAPDunn";
            sql_str += " ORDER BY sDunn_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sDunn_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDunn_cd"), cur_set.sField("sDunn_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadARPriceCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadARPriceCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sPrice_cd FROM tblARPrice";
            sql_str += " ORDER BY sPrice_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sPrice_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sPrice_cd"), cur_set.sField("sPrice_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadARTermsCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_blank_fl = true)
        {
#else
        		public static void LoadARTermsCode(ref ComboBox cur_box, bool add_blank_fl = true)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            if (add_blank_fl) // Do not remove this option. This is necessary when it has to be enforced to begin with.
            {
                item_list.Add(new clsComboBoxItem("", ""));
            }

            sql_str = "SELECT sTerms_cd FROM tblARTerms";
            sql_str += " ORDER BY sTerms_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sTerms_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sTerms_cd"), cur_set.sField("sTerms_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadAPTermsCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_blank_fl = true)
        {
#else
        		public static void LoadAPTermsCode(ref ComboBox cur_box, bool add_blank_fl = true)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            if (add_blank_fl) // Do not remove this option. This is necessary when it has to be enforced to begin with. LookupVoucher uses this for payment schedule change.
            {
                item_list.Add(new clsComboBoxItem("", ""));
            }

            sql_str = "SELECT sTerms_cd FROM tblAPTerms";
            sql_str += " ORDER BY sTerms_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sTerms_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sTerms_cd"), cur_set.sField("sTerms_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadARTaxCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadARTaxCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sTax_cd FROM tblARTax";
            sql_str += " ORDER BY sTax_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sTax_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sTax_cd"), cur_set.sField("sTax_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadAPTaxCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadAPTaxCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sTax_cd FROM tblAPTax";
            sql_str += " ORDER BY sTax_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sTax_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sTax_cd"), cur_set.sField("sTax_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadItemClassCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadItemClassCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sClass_cd FROM tblIVClass";
            sql_str += " ORDER BY sClass_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sClass_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sClass_cd"), cur_set.sField("sClass_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadInventoryItemType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadInventoryItemType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            int i = 0;
            bool first_one = false;

            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

                sql_str = "SELECT * FROM tblIVItemType WHERE iItem_typ < " + GlobalVar.goIVConstant.SUMMARY_SALES_ITEM_TYPES;
                sql_str += " ORDER BY iItem_typ";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                i = 0;
                first_one = true;

                while (!cur_set.EOF())
                {

                    if (moUtility.IsNonEmpty(cur_set.sField("sDescription")) & moUtility.IsInventoryItemType(cur_set.iField("iItem_typ")))
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), Convert.ToString(cur_set.iField("iItem_typ"))));
                        //gsItemTypes(goConstant.INDEX_BASE, i) = (cur_set.iField("iItem_typ"))
                        //gsItemTypes(goConstant.INDEX_BASE + 1, i) = (cur_set.sField("sDescription"))
                        i = i + 1;
                    }

                    cur_set.MoveNext();

                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadInventoryItemType)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "LoadInventoryItemType");
#endif
                return;

            }

        }

#if WEB
        public static void LoadSalesrepPaymentType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadSalesrepPaymentType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.PAYROLL_SREP, Convert.ToString(GlobalVar.goARConstant.PAYROLL_SREP_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.PAYABLE_SREP, Convert.ToString(GlobalVar.goARConstant.PAYABLE_SREP_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadPaymentType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool cash_only_fl = false, bool exclude_write_off_fl = false
            , bool add_blank_fl = false, bool exclude_check_fl = false, bool exclude_memo_fl = false, bool use_deposit_fl = false, bool exclude_cash_fl = false)
        {
#else
        		public static void LoadPaymentType(ref ComboBox cur_box, ref bool cash_only_fl, ref bool exclude_write_off_fl, bool add_blank_fl, bool exclude_check_fl, bool exclude_memo_fl, bool use_deposit_fl)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

#if WEB
            item_list.Add(new clsComboBoxItem("", "0"));
#else
        			if (add_blank_fl)
        			{
        				item_list.Add(new clsComboBoxItem("", "0"));
        			}
#endif

            if (!exclude_check_fl)
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.CHECK_TYPE, Convert.ToString(GlobalVar.goConstant.CHECK_TYPE_NUM)));
            }

            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.WIRE_TRANSFER_TYPE, Convert.ToString(GlobalVar.goConstant.WIRE_TRANSFER_TYPE_NUM)));
            
            if (!exclude_cash_fl)
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.CASH_TYPE, Convert.ToString(GlobalVar.goConstant.CASH_TYPE_NUM)));
            }
            
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.VISA_TYPE, Convert.ToString(GlobalVar.goConstant.VISA_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.MC_TYPE, Convert.ToString(GlobalVar.goConstant.MC_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.AMX_TYPE, Convert.ToString(GlobalVar.goConstant.AMX_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.DINERS_TYPE, Convert.ToString(GlobalVar.goConstant.DINERS_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.DISCOVER_TYPE, Convert.ToString(GlobalVar.goConstant.DISCOVER_TYPE_NUM)));
            //item_list.Add(New clsComboBoxItem(goConstant.FOREIGN_BANK_DEPOSIT_TYPE, CStr(goConstant.FOREIGN_BANK_DEPOSIT_TYPE_NUM)))  ' 07/18/2016 EFT will take care of this.

            if (cash_only_fl)
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.OTHER_TYPE, Convert.ToString(GlobalVar.goConstant.OTHER_TYPE_NUM)));
            }
            else
            {
                if (!exclude_memo_fl)
                {
                    item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.MEMO_TYPE, Convert.ToString(GlobalVar.goConstant.MEMO_TYPE_NUM)));
                }
                else if (use_deposit_fl)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DEPOSIT, Convert.ToString(GlobalVar.goConstant.MEMO_TYPE_NUM))); // 08/03/2019 for the payment at invoice and voucher entry
                }
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.OTHER_TYPE, Convert.ToString(GlobalVar.goConstant.OTHER_TYPE_NUM)));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadRecurringType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadRecurringType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            int i = 0;

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_WEEKLY, Convert.ToString(GlobalVar.goConstant.RECUR_WEEKLY_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_BIWEEKLY, Convert.ToString(GlobalVar.goConstant.RECUR_BIWEEKLY_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_SEMIMONTHLY, Convert.ToString(GlobalVar.goConstant.RECUR_SEMIMONTHLY_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_MONTHLY, Convert.ToString(GlobalVar.goConstant.RECUR_MONTHLY_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_MONTHLY_AT_FIRST, Convert.ToString(GlobalVar.goConstant.RECUR_MONTHLY_AT_FIRST_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_MONTHLY_AT_MIDDLE, Convert.ToString(GlobalVar.goConstant.RECUR_MONTHLY_AT_MIDDLE_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_MONTHLY_AT_LAST, Convert.ToString(GlobalVar.goConstant.RECUR_MONTHLY_AT_LAST_NUM)));

#if WEB
                if (cur_db.sCurProgram_nm == GlobalVar.goConstant.BRMENU_NAME || cur_db.sCurProgram_nm == GlobalVar.goConstant.ENMENU_NAME || cur_db.sCurProgram_nm == GlobalVar.goConstant.PLMENU_NAME)
                {
#else
        				if (goDatabase.sCurProgram_nm == GlobalVar.goConstant.BRMENU_NAME || goDatabase.sCurProgram_nm == GlobalVar.goConstant.ENMENU_NAME || goDatabase.sCurProgram_nm == GlobalVar.goConstant.PLMENU_NAME)
        				{
#endif

                    item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_QUARTERLY, Convert.ToString(GlobalVar.goConstant.RECUR_QUARTERLY_NUM)));
                    item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_SEMIYEARLY, Convert.ToString(GlobalVar.goConstant.RECUR_SEMIYEARLY_NUM)));
                    item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_YEARLY, Convert.ToString(GlobalVar.goConstant.RECUR_YEARLY_NUM)));
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadStatusType)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadStatusType)");
#endif
                return;

            }

        }

#if WEB
        public static void LoadSalesTaxType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
		public static void LoadSalesTaxType(ref ComboBox cur_box)
		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.REGULAR_TAX, Convert.ToString(GlobalVar.goConstant.REGULAR_TAX_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.INCLUDED_TAX, Convert.ToString(GlobalVar.goConstant.INCLUDED_TAX_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadSalespersonCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool code_only = false, bool manager_only = false)
        {
#else
        		public static void LoadSalespersonCode(ref ComboBox cur_box, bool code_only = false, bool manager_only = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sSalesrep_cd, sSalesrep_nm FROM tblARSalesrep";

            if (moUtility.IsSalesStaff(cur_db))
            {
                sql_str += " WHERE sSalesrep_cd = '" + cur_db.sUser_cd + "'";
            }
            else if (manager_only)
            {
                sql_str += " WHERE iManager_fl = 1";
            }

            sql_str += " ORDER BY sSalesrep_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                if (code_only || moUtility.IsEmpty(cur_set.sField("sSalesrep_nm")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sSalesrep_cd"), cur_set.sField("sSalesrep_cd").ToString()));
                }
                else
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sSalesrep_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sSalesrep_nm"), cur_set.sField("sSalesrep_cd").ToString()));
                }
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadCreditCard(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCreditCard(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            int i = 0;
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT sCard_cd FROM tblBRCreditCard ORDER BY sCard_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sCard_cd"), cur_set.sField("sCard_cd")));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                modGeneralUtility.MouseDefault();
                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

                cur_set.Release();
                modGeneralUtility.MouseDefault();
#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadCreditCard)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadCreditCard)");
#endif
                return;

            }

        }

        public static void LoadBankAccountType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.CHECKING_ACCT_TYPE, GlobalVar.goBRConstant.CHECKING_ACCT_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.SAVINGS_ACCT_TYPE, GlobalVar.goBRConstant.SAVINGS_ACCT_TYPE_NUM.ToString()));
            // item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.INVESTMENT_ACCT_TYPE, GlobalVar.goBRConstant.INVESTMENT_ACCT_TYPE_NUM.ToString()));  Not yet
            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.CREDIT_CARD_ACCT_TYPE, GlobalVar.goBRConstant.CREDIT_CARD_ACCT_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.LOAN_ACCT_TYPE, GlobalVar.goBRConstant.LOAN_ACCT_TYPE_NUM.ToString()));
            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

        public static void LoadCreditTransactionType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.CREDIT_CHARGE_TYPE, GlobalVar.goBRConstant.CREDIT_CHARGE_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.CREDIT_LOAN_TYPE, GlobalVar.goBRConstant.CREDIT_LOAN_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.CREDIT_INTEREST_CHARGE_TYPE, GlobalVar.goBRConstant.CREDIT_INTEREST_CHARGE_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.CREDIT_SERVICE_CHARGE_TYPE, GlobalVar.goBRConstant.CREDIT_SERVICE_CHARGE_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.CREDIT_LATE_CHARGE_TYPE, GlobalVar.goBRConstant.CREDIT_LATE_CHARGE_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.CREDIT_OVERLIMIT_CHARGE_TYPE, GlobalVar.goBRConstant.CREDIT_OVERLIMIT_CHARGE_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.CREDIT_ADJUSTED_CHARGE_TYPE, GlobalVar.goBRConstant.CREDIT_ADJUSTED_CHARGE_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.CREDIT_PAYMENT_TYPE, GlobalVar.goBRConstant.CREDIT_PAYMENT_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.CREDIT_ADJUSTED_CREDIT_TYPE, GlobalVar.goBRConstant.CREDIT_ADJUSTED_CREDIT_TYPE_NUM.ToString()));
            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
        }

#if WEB
        public static void LoadBankCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool code_only = true, string bank_to_exclude = "", bool add_all_fl = false, bool include_foreign_acct_fl = false, string currency_code = "", bool credit_acct_fl = false)
        {
#else
        		public static void LoadBankCode(ref ComboBox cur_box, bool code_only = true, string bank_to_exclude = "", bool add_all_fl = false, bool include_foreign_acct_fl = false, string currency_code = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string currency_cd = "";
            string where_str = "";
            int i = 0;
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            currency_cd = cur_db.sCurrency_cd;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			currency_cd = goDatabase.sCurrency_cd;
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = "SELECT * FROM tblBRBankAccount ";

                if (credit_acct_fl)
                {
                    where_str += moUtility.IIf(moUtility.IsEmpty(where_str), "", " AND ").ToString() + " (iAccount_typ = " + GlobalVar.goBRConstant.CREDIT_CARD_ACCT_TYPE_NUM.ToString() + " OR iAccount_typ = " + GlobalVar.goBRConstant.LOAN_ACCT_TYPE_NUM.ToString() + ")";
                }
                else
                {
                    where_str += moUtility.IIf(moUtility.IsEmpty(where_str), "", " AND ").ToString() + " (iAccount_typ <> " + GlobalVar.goBRConstant.CREDIT_CARD_ACCT_TYPE_NUM.ToString() + " AND iAccount_typ <> " + GlobalVar.goBRConstant.LOAN_ACCT_TYPE_NUM.ToString() + ")";
                }

                if (moUtility.IsNonEmpty(currency_code))
                {
                    where_str += moUtility.IIf(moUtility.IsEmpty(where_str), "", " AND ").ToString() + " sCurrency_cd = '" + currency_code + "'";
                }
                if (moUtility.IsNonEmpty(bank_to_exclude))
                {
                    where_str += moUtility.IIf(moUtility.IsEmpty(where_str), "", " AND ").ToString() + " sBank_cd <> '" + bank_to_exclude + "'";
                }

                if (!include_foreign_acct_fl)
                {
                    where_str += moUtility.IIf(moUtility.IsEmpty(where_str), "", " AND ").ToString() + " (sCurrency_cd = '" + currency_cd + "' OR sCurrency_cd= '' OR sCurrency_cd IS NULL)";
                }

                if (moUtility.IsNonEmpty(where_str))
                {
                    where_str = " WHERE " + where_str;
                }

                if (!cur_set.CreateSnapshot(sql_str + where_str + " ORDER BY sBank_cd"))
                {
                    return;
                }

                if (add_all_fl)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL, cur_db.oLanguage.oString.STR_ALL));
                }

                while (!cur_set.EOF())
                {
                    if (code_only || moUtility.IsEmpty(cur_set.sField("sBank_nm")))
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sBank_cd"), cur_set.sField("sBank_cd").ToString()));
                    }
                    else
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sBank_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sBank_nm"), cur_set.sField("sBank_cd").ToString()));
                    }
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

                cur_set.Release();
                modGeneralUtility.MouseDefault();
#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadBankCode)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadBankCode)");
#endif
                return;

            }

        }

#if WEB
        public static void LoadLocalBankCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool code_only = true, string bank_to_exclude = "", bool add_all_fl = false)
        {
#else
        		public static void LoadLocalBankCode(ref ComboBox cur_box, bool code_only = true, string bank_to_exclude = "", bool add_all_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string currency_cd = "";
            int i = 0;
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            currency_cd = cur_db.sCurrency_cd;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			currency_cd = goDatabase.sCurrency_cd;
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                if (add_all_fl)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL, cur_db.oLanguage.oString.STR_ALL));
                }

                sql_str = "SELECT sBank_cd, sBank_nm FROM tblBRBankAccount WHERE sCurrency_cd = '" + currency_cd + "'";
                sql_str += moUtility.IIf(moUtility.IsNonEmpty(bank_to_exclude), " AND sBank_cd <> '" + bank_to_exclude + "'", "").ToString() + " ORDER BY sBank_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    if (code_only || moUtility.IsEmpty(cur_set.sField("sBank_nm")))
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sBank_cd"), cur_set.sField("sBank_cd")));
                    }
                    else
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sBank_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sBank_nm"), cur_set.sField("sBank_cd")));
                    }
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                modGeneralUtility.MouseDefault();
                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

                cur_set.Release();
                modGeneralUtility.MouseDefault();
#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadLocalBankCode)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadLocalBankCode)");
#endif
                return;

            }

        }

#if WEB
        public static void LoadForeignBankCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool code_only = true, string bank_to_exclude = "", bool add_all_fl = false)
        {
#else
        		public static void LoadForeignBankCode(ref ComboBox cur_box, bool code_only = true, string bank_to_exclude = "", bool add_all_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string currency_cd = "";
            int i = 0;
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            currency_cd = cur_db.sCurrency_cd;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			currency_cd = goDatabase.sCurrency_cd;
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                if (add_all_fl)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL, cur_db.oLanguage.oString.STR_ALL));
                }

                sql_str = "SELECT sBank_cd, sBank_nm FROM tblBRBankAccount WHERE sCurrency_cd <> '" + currency_cd + "'";
                sql_str += moUtility.IIf(moUtility.IsNonEmpty(bank_to_exclude), " AND sBank_cd <> '" + bank_to_exclude + "'", "").ToString() + " ORDER BY sBank_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    if (code_only || moUtility.IsEmpty(cur_set.sField("sBank_nm")))
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sBank_cd"), cur_set.sField("sBank_cd")));
                    }
                    else
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sBank_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sBank_nm"), cur_set.sField("sBank_cd")));
                    }
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                modGeneralUtility.MouseDefault();
                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

                cur_set.Release();
                modGeneralUtility.MouseDefault();
#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadForeignBankCode)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadForeignBankCode)");
#endif
                return;

            }

        }

#if WEB
        public static void LoadBankPeriod(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string bank_code, bool period_end_date_fl = true)
        {
#else
        		public static void LoadBankPeriod(ref ComboBox cur_box, string bank_code, bool period_end_date_fl = true)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string field_name = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                if (period_end_date_fl)
                {
                    field_name = "iPeriodEnd_dt";
                }
                else
                {
                    field_name = "iPeriodBegin_dt";
                }

                sql_str = "SELECT " + field_name + " FROM tblBRBalance WHERE sBank_cd = '" + bank_code + "'";
                sql_str += " ORDER BY " + field_name + " DESC";
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(o_gen.ToStrDate(cur_set.iField(field_name)), cur_set.iField(field_name).ToString()));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                modGeneralUtility.MouseDefault();
                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

                cur_set.Release();
                modGeneralUtility.MouseDefault();
#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadBankPeriod)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadBankPeriod)");
#endif
                return;

            }

        }

#if WEB
        public static void LoadCurrencyCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool code_only = false, bool foreign_currency_only = false, bool add_all_fl = false)
        {
#else
        		public static void LoadCurrencyCode(ref ComboBox cur_box, bool code_only = false, bool foreign_currency_only = false, bool add_all_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string currency_cd = "";
            int i = 0;
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            currency_cd = cur_db.sCurrency_cd;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			currency_cd = goDatabase.sCurrency_cd;
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));
                if (add_all_fl)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL, cur_db.oLanguage.oString.STR_ALL));
                }

                sql_str = "SELECT sCurrency_cd, sDescription FROM tblBRCurrency";
                if (foreign_currency_only)
                {
                    sql_str += " WHERE sCurrency_cd <> '" + currency_cd + "'";
                }
                sql_str += " ORDER BY sCurrency_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }
                else if (cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(currency_cd, currency_cd));
                }
                else
                {
                    while (!cur_set.EOF())
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sCurrency_cd"), cur_set.sField("sCurrency_cd")));
                        cur_set.MoveNext();
                    }
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                modGeneralUtility.MouseDefault();
                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

                cur_set.Release();
                modGeneralUtility.MouseDefault();
#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadCurrencyCode)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadCurrencyCode)");
#endif
                return;

            }

        }

#if WEB
        public static void LoadTransactionCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, int trx_type, bool code_only_fl = true)
        {
#else
        		public static void LoadTransactionCode(ref ComboBox cur_box, int trx_type, bool code_only_fl = true)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            int i = 0;
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = "SELECT sTransaction_cd, sDescription FROM tblBRTransactionCode ";
                sql_str += " WHERE iTransaction_typ = " + trx_type;
                sql_str += " ORDER BY sTransaction_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    if (code_only_fl || moUtility.IsEmpty(cur_set.sField("sDescription")))
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sTransaction_cd"), cur_set.sField("sTransaction_cd")));
                    }
                    else
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sTransaction_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sTransaction_cd")));
                    }
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                modGeneralUtility.MouseDefault();
                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

                cur_set.Release();
                modGeneralUtility.MouseDefault();
#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadTransactionCode)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadTransactionCode)");
#endif
                return;

            }

        }

#if WEB
        public static void LoadCashAcctType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCashAcctType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            int i = 0;
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            // Create the list of cash account, income, and earning accts.
            // Only get the actual account type.
            //
            sql_str = modConstant.ACCT_DYNASET;
            sql_str += " WHERE iSummary_typ = " + GlobalVar.goGLConstant.ACTUAL_TYPE_NUM;
            sql_str += " AND (iGroup_typ = " + GlobalVar.goGLConstant.PETTY_CASH_NUM;
            sql_str += " OR iGroup_typ = " + GlobalVar.goGLConstant.CHECK_CASH_NUM + ")";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sAccount_cd") + GlobalVar.goConstant.ID_DELIMITER + (cur_set.sField("sDescription")), cur_set.sField("sAccount_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadCommissionType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCommissionType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            bool calc_by_item = false;

#if WEB
            calc_by_item = cur_db.bCalcCommissionByItem_fl;
#else
        			calc_by_item = goDatabase.bCalcCommissionByItem_fl;
#endif

            try
            {

                cur_box.Clear();


#if WEB
                item_list.Add(new clsComboBoxItem("", ""));
#endif
                item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.FLAT_AMOUNT_COMM, Convert.ToString(GlobalVar.goARConstant.FLAT_AMOUNT_COMM_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.SALES_PERCENT_COMM, Convert.ToString(GlobalVar.goARConstant.SALES_PERCENT_COMM_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.PROFIT_PERCENT_COMM, Convert.ToString(GlobalVar.goARConstant.PROFIT_PERCENT_COMM_NUM)));

                if (calc_by_item)
                {
                    item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.EXCEEDING_PERCENT_COMM, Convert.ToString(GlobalVar.goARConstant.EXCEEDING_PERCENT_COMM_NUM)));
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadExpenseType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_liability_accounts_fl = false)
        {
#else
        		public static void LoadExpenseType(ref ComboBox cur_box, bool add_liability_accounts_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            bool used_fl = false;

            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            // Create the list of cash account, income, and earning accts.
            // Only get the actual account type.
            //
            sql_str = modConstant.ACCT_DYNASET;
            sql_str += " WHERE iSummary_typ = " + GlobalVar.goGLConstant.ACTUAL_TYPE_NUM;
            sql_str += " AND ((iGroup_typ BETWEEN " + GlobalVar.goGLConstant.EXPENSE_GROUP_NUM;
            sql_str += " AND " + GlobalVar.goGLConstant.EXPENSE_GROUP_ENDING_NUM + ")";
            if (add_liability_accounts_fl)
            {
                sql_str += " OR (iGroup_typ BETWEEN " + GlobalVar.goGLConstant.LIABILITY_GROUP_NUM;
                sql_str += " AND " + GlobalVar.goGLConstant.LIABILITY_GROUP_ENDING_NUM + ")";
            }
            sql_str += ")";
#if WEB
            sql_str += " ORDER BY sAccount_cd";
#else
        			if (IsLiteVersion())
        			{
        				sql_str += " ORDER BY fUserDefined5_num DESC, sAccount_cd"; // fUserDefined1_num keeps the frequency of usages
        			}
        			else
        			{
        				sql_str += " ORDER BY sAccount_cd";
        			}
#endif

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            used_fl = false;
            while (!cur_set.EOF())
            {
#if WEB
                item_list.Add(new clsComboBoxItem(cur_set.sField("sAccount_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sAccount_cd")));
#else
        				if ((cur_set.mField("fUserDefined5_num")) == 0 && used_fl && IsLiteVersion())
        				{
        					item_list.Add(new clsComboBoxItem("- - - - - - - - -", ""));
        					used_fl = false;
        				}
        				item_list.Add(new clsComboBoxItem((cur_set.sField("sAccount_cd")) + GlobalVar.goConstant.ID_DELIMITER + (cur_set.sField("sDescription")), (cur_set.sField("sAccount_cd"))));
        				if ((cur_set.mField("fUserDefined5_num")) > 0)
        				{
        					used_fl = true;
        				}
#endif
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadIncomeType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadIncomeType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            bool used_fl = false;

            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            // Create the list of cash account, income, and earning accts.
            // Only get the actual account type.
            //
            sql_str = modConstant.ACCT_DYNASET;
            sql_str += " WHERE iSummary_typ = " + GlobalVar.goGLConstant.ACTUAL_TYPE_NUM;
            sql_str += " AND iGroup_typ >= " + GlobalVar.goGLConstant.REVENUE_GROUP_NUM;
            sql_str += " AND iGroup_typ <= " + GlobalVar.goGLConstant.REVENUE_GROUP_ENDING_NUM;
#if WEB
            sql_str += " ORDER BY sAccount_cd";
#else
        			if (IsLiteVersion())
        			{
        				sql_str += " ORDER BY fUserDefined5_num DESC, sAccount_cd"; // fUserDefined1_num keeps the frequency of usages
        			}
        			else
        			{
        				sql_str += " ORDER BY sAccount_cd";
        			}
#endif
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            used_fl = false;
            while (!cur_set.EOF())
            {
#if WEB
                item_list.Add(new clsComboBoxItem(cur_set.sField("sAccount_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sAccount_cd")));
#else
        				if ((cur_set.mField("fUserDefined5_num")) == 0 && used_fl && IsLiteVersion())
        				{
        					item_list.Add(new clsComboBoxItem("- - - - - - - - -", ""));
        					used_fl = false;
        				}
        				item_list.Add(new clsComboBoxItem((cur_set.sField("sAccount_cd")) + GlobalVar.goConstant.ID_DELIMITER + (cur_set.sField("sDescription")), (cur_set.sField("sAccount_cd"))));
        				if ((cur_set.mField("fUserDefined5_num")) > 0)
        				{
        					used_fl = true;
        				}
#endif
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadModuleId(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadModuleId(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT * FROM tblGOModule";

#if WEB
            if (cur_db.sCurProgram_nm == GlobalVar.goConstant.SMMENU_NAME)
            {
                sql_str += " WHERE iSort_id < 1000";
                sql_str += " ORDER BY iSort_id";
            }
            else if (moUtility.IsEmpty(cur_db.sCurProgram_nm))
            {
                sql_str += " WHERE sModule_id = '" + GlobalVar.goConstant.PLMENU_NAME + "'";
            }
            else
            {
                sql_str += " WHERE sModule_id = '" + cur_db.sCurProgram_nm + "'";
            }
#else
        			if (goDatabase.sCurProgram_nm == GlobalVar.goConstant.SMMENU_NAME)
        			{
        				sql_str += " WHERE iSort_id < 1000";
        				sql_str += " ORDER BY iSort_id";
        			}
        			else
        			{
        				sql_str += " WHERE sModule_id = '" + goDatabase.sCurProgram_nm + "'";
        				//sql_str &= " ORDER BY iSort_id DESC"
        			}
#endif

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sModule_id") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sModule_id")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadYears(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadYears(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));
                item_list.Add(new clsComboBoxItem((moUtility.GetYear(o_gen.CurrentDate()) + 1).ToString(), (moUtility.GetYear(o_gen.CurrentDate()) + 1).ToString()));
                item_list.Add(new clsComboBoxItem(moUtility.GetYear(o_gen.CurrentDate()).ToString(), moUtility.GetYear(o_gen.CurrentDate()).ToString()));
                item_list.Add(new clsComboBoxItem((moUtility.GetYear(o_gen.CurrentDate()) - 1).ToString(), (moUtility.GetYear(o_gen.CurrentDate()) - 1).ToString()));
                item_list.Add(new clsComboBoxItem((moUtility.GetYear(o_gen.CurrentDate()) - 2).ToString(), (moUtility.GetYear(o_gen.CurrentDate()) - 2).ToString()));
                item_list.Add(new clsComboBoxItem((moUtility.GetYear(o_gen.CurrentDate()) - 3).ToString(), (moUtility.GetYear(o_gen.CurrentDate()) - 3).ToString()));
                item_list.Add(new clsComboBoxItem((moUtility.GetYear(o_gen.CurrentDate()) - 4).ToString(), (moUtility.GetYear(o_gen.CurrentDate()) - 4).ToString()));
                item_list.Add(new clsComboBoxItem((moUtility.GetYear(o_gen.CurrentDate()) - 5).ToString(), (moUtility.GetYear(o_gen.CurrentDate()) - 5).ToString()));
                item_list.Add(new clsComboBoxItem((moUtility.GetYear(o_gen.CurrentDate()) - 6).ToString(), (moUtility.GetYear(o_gen.CurrentDate()) - 6).ToString()));
                item_list.Add(new clsComboBoxItem((moUtility.GetYear(o_gen.CurrentDate()) - 7).ToString(), (moUtility.GetYear(o_gen.CurrentDate()) - 7).ToString()));
                item_list.Add(new clsComboBoxItem((moUtility.GetYear(o_gen.CurrentDate()) - 8).ToString(), (moUtility.GetYear(o_gen.CurrentDate()) - 8).ToString()));
                item_list.Add(new clsComboBoxItem((moUtility.GetYear(o_gen.CurrentDate()) - 9).ToString(), (moUtility.GetYear(o_gen.CurrentDate()) - 9).ToString()));
                item_list.Add(new clsComboBoxItem((moUtility.GetYear(o_gen.CurrentDate()) - 10).ToString(), (moUtility.GetYear(o_gen.CurrentDate()) - 10).ToString()));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                ////modCommonUtility.SetSelectedValue(ref cur_box, moUtility.GetYear(o_gen.CurrentDate()).ToString());

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadMonths(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadMonths(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.MONTH_1, Convert.ToString(GlobalVar.goConstant.MONTH_1_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.MONTH_2, Convert.ToString(GlobalVar.goConstant.MONTH_2_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.MONTH_3, Convert.ToString(GlobalVar.goConstant.MONTH_3_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.MONTH_4, Convert.ToString(GlobalVar.goConstant.MONTH_4_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.MONTH_5, Convert.ToString(GlobalVar.goConstant.MONTH_5_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.MONTH_6, Convert.ToString(GlobalVar.goConstant.MONTH_6_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.MONTH_7, Convert.ToString(GlobalVar.goConstant.MONTH_7_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.MONTH_8, Convert.ToString(GlobalVar.goConstant.MONTH_8_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.MONTH_9, Convert.ToString(GlobalVar.goConstant.MONTH_9_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.MONTH_10, Convert.ToString(GlobalVar.goConstant.MONTH_10_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.MONTH_11, Convert.ToString(GlobalVar.goConstant.MONTH_11_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.MONTH_12, Convert.ToString(GlobalVar.goConstant.MONTH_12_NUM)));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

#if WEB

#else
                //modCommonUtility.SetSelectedValue(ref cur_box, moUtility.GetMonth(o_gen.CurrentDate()).ToString());
#endif
            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadDays(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, int days_num = 31)
        {
#else
        		public static void LoadDays(ref ComboBox cur_box, int days_num = 31)
        		{
#endif

            int i = 0;
            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));

            for (i = 1; i <= days_num; i++)
            {
                item_list.Add(new clsComboBoxItem(i.ToString(), i.ToString()));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadFiscalPeriod(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string cur_year, bool next_periods_only = false, bool format_value_fl = true)
        {
#else
        		public static void LoadFiscalPeriod(ref ComboBox cur_box, string cur_year, bool next_periods_only = false, bool format_value_fl = true, bool add_blank_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string value_text = "";
            int i = 0;
            int period_begin = 0;
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            period_begin = cur_db.iCurPeriodBegin_dt;
            if (moUtility.IsEmpty(moUtility.STrim(cur_year)))
            {
                cur_year = cur_db.sCurFiscalYear;
            }
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			period_begin = goDatabase.iCurPeriodBegin_dt;
        			if (moUtility.IsEmpty(moUtility.STrim(cur_year)))
        			{
        				cur_year = goDatabase.sCurFiscalYear;
        			}
#endif

            try
            {

                if (moUtility.IsEmpty(moUtility.STrim(cur_year)))
                {
                    return;
                }

                cur_box.Clear();

#if WEB
                item_list.Add(new clsComboBoxItem("", ""));
#else
        				if (add_blank_fl)
        				{
        					item_list.Add(new clsComboBoxItem("", ""));
        				}
#endif

                sql_str = modConstant.PERIODDET_DYNASET + " WHERE sFiscalYear = '" + cur_year + "'";
                if (next_periods_only)
                {
                    sql_str += " AND iPeriodBegin_dt > " + period_begin;
                }

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    value_text = moUtility.IIf(format_value_fl, o_gen.ToStrDate(cur_set.iField("iPeriodBegin_dt")), cur_set.iField("iPeriodBegin_dt").ToString());
                    item_list.Add(new clsComboBoxItem(o_gen.ToStrDate((cur_set.iField("iPeriodBegin_dt"))) + GlobalVar.goConstant.ID_DELIMITER + o_gen.ToStrDate((cur_set.iField("iPeriodEnd_dt"))), value_text));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                modGeneralUtility.MouseDefault();
                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

                cur_set.Release();
                modGeneralUtility.MouseDefault();
#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadFiscalPeriod)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadFiscalPeriod)");
#endif
                return;

            }

        }

#if WEB
        public static void LoadFiscalYear(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool exclude_this_year_fl = false, bool ascending_order_fl = false, bool add_all_fl = false)
        {
#else
        		public static void LoadFiscalYears(ref ComboBox cur_box, bool exclude_this_year_fl = false, bool ascending_order_fl = false, bool add_blank_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string fiscal_year = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            fiscal_year = cur_db.sCurFiscalYear;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			fiscal_year = goDatabase.sCurFiscalYear;
#endif

            try
            {

                cur_box.Clear();

#if WEB
                if (add_all_fl)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL, ""));
                }
                else
                {
                    item_list.Add(new clsComboBoxItem("", ""));
                }
#else
        				if (add_blank_fl)
        				{
        					item_list.Add(new clsComboBoxItem("", ""));
        				}
#endif

                if (exclude_this_year_fl)
                {
                    sql_str = modConstant.PERIOD_DYNASET + " WHERE sFiscalYear <> '" + fiscal_year + "'";
                }
                else
                {
                    sql_str = modConstant.PERIOD_DYNASET;
                }
                sql_str += " ORDER BY sFiscalYear";
                if (!ascending_order_fl)
                {
                    sql_str += " DESC";
                }

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sFiscalYear"), cur_set.sField("sFiscalYear")));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

#if !WEB
        				if (!exclude_this_year_fl)
        				{
        					//modCommonUtility.SetSelectedValue(ref cur_box, goDatabase.sCurFiscalYear);
        				}
#endif

                modGeneralUtility.MouseDefault();
                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

                cur_set.Release();
                modGeneralUtility.MouseDefault();
#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadFiscalPeriod)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadFiscalPeriod)");
#endif
                return;

            }

        }

#if WEB
        public static void LoadProfitCenter(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadProfitCenter(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = modConstant.SEGMENT_DYNASET;

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sSegment_cd")));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                modGeneralUtility.MouseDefault();
                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

                cur_set.Release();
                modGeneralUtility.MouseDefault();
#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadProfitCenter)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadProfitCenter)");
#endif
                return;
            }

        }

#if WEB
        public static void LoadCheckType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCheckType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.MUTI_PURPOSE_CHECK, Convert.ToString(GlobalVar.goConstant.MUTI_PURPOSE_CHECK_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadCustomerBalanceType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCustomerBalanceType(ref ComboBox cur_box, bool add_blank_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

#if WEB
            item_list.Add(new clsComboBoxItem("", ""));
#else
        			if (add_blank_fl)
        			{
        				item_list.Add(new clsComboBoxItem("", ""));
        			}
#endif
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.OPEN_CUSTOMER, Convert.ToString(GlobalVar.goARConstant.OPEN_CUSTOMER_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.FORWARD_CUSTOMER, Convert.ToString(GlobalVar.goARConstant.FORWARD_CUSTOMER_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.CASH_CUSTOMER, Convert.ToString(GlobalVar.goARConstant.CASH_CUSTOMER_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadCustomerStatusType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_all_fl = true)
        {
#else
        		public static void LoadCustomerStatusType(ref ComboBox cur_box, bool add_all_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            if (add_all_fl)
            {
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL_CUSTOMERS, "0")); //Convert.ToString(goString.STR_ALL_CUSTOMERS)))
            }
            else
            {
                item_list.Add(new clsComboBoxItem("", ""));
            }

            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.ACTIVE_CUSTOMER, Convert.ToString(GlobalVar.goARConstant.ACTIVE_CUSTOMER_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.PROSPECTIVE_CUSTOMER, Convert.ToString(GlobalVar.goARConstant.PROSPECTIVE_CUSTOMER_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.SUSPENDED_CUSTOMER, Convert.ToString(GlobalVar.goARConstant.SUSPENDED_CUSTOMER_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INACTIVE_CUSTOMER, Convert.ToString(GlobalVar.goARConstant.INACTIVE_CUSTOMER_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.CLOSED_CUSTOMER, Convert.ToString(GlobalVar.goARConstant.CLOSED_CUSTOMER_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }

#if WEB
        public static void LoadVendorBalanceType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadVendorBalanceType(ref ComboBox cur_box, bool add_blank_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

#if WEB
            item_list.Add(new clsComboBoxItem("", ""));
#else
        			if (add_blank_fl)
        			{
        				item_list.Add(new clsComboBoxItem("", ""));
        			}
#endif

            item_list.Add(new clsComboBoxItem(GlobalVar.goAPConstant.OPEN_VENDOR, Convert.ToString(GlobalVar.goAPConstant.OPEN_VENDOR_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goAPConstant.FORWARD_VENDOR, Convert.ToString(GlobalVar.goAPConstant.FORWARD_VENDOR_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goAPConstant.CASH_VENDOR, Convert.ToString(GlobalVar.goAPConstant.CASH_VENDOR_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadVendorStatusType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadVendorStatusType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem(GlobalVar.goAPConstant.ACTIVE_VENDOR, Convert.ToString(GlobalVar.goAPConstant.ACTIVE_VENDOR_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goAPConstant.PROSPECTIVE_VENDOR, Convert.ToString(GlobalVar.goAPConstant.PROSPECTIVE_VENDOR_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goAPConstant.SUSPENDED_VENDOR, Convert.ToString(GlobalVar.goAPConstant.SUSPENDED_VENDOR_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goAPConstant.INACTIVE_VENDOR, Convert.ToString(GlobalVar.goAPConstant.INACTIVE_VENDOR_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goAPConstant.CLOSED_VENDOR, Convert.ToString(GlobalVar.goAPConstant.CLOSED_VENDOR_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadVendorPostingCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadVendorPostingCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sPosting_cd FROM tblAPAccounts";
            sql_str += " ORDER BY sPosting_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sPosting_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sPosting_cd"), cur_set.sField("sPosting_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadVendorTaxCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadVendorTaxCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sTax_cd FROM tblAPTax";
            sql_str += " ORDER BY sTax_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sTax_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sTax_cd"), cur_set.sField("sTax_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadVendorTermsCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadVendorTermsCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sTerms_cd FROM tblAPTerms";
            sql_str += " ORDER BY sTerms_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sTerms_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sTerms_cd"), cur_set.sField("sTerms_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadVendorClassCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadVendorClassCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sClass_cd FROM tblAPClass";
            sql_str += " ORDER BY sClass_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sClass_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sClass_cd"), cur_set.sField("sClass_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadCustomerClassCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCustomerClassCode(ref ComboBox cur_box, bool addnew_flag = true)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sClass_cd FROM tblARClass";
            sql_str += " ORDER BY sClass_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sClass_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sClass_cd"), cur_set.sField("sClass_cd")));
                }

                cur_set.MoveNext();

            }

#if !WEB
            			if (IsLiteVersion() && addnew_flag)
            			{
            				item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ADDNEW, cur_db.oLanguage.oString.STR_ADDNEW));
            			}
#endif
            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadShipToCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string customer_cd)
        {
#else
            		public static void LoadShipToCode(ref ComboBox cur_box, string customer_cd)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            if (moUtility.IsEmpty(customer_cd))
            {
                return;
            }

            cur_box.Clear();

            sql_str = "SELECT sCustomer_cd, sCustomer_nm FROM tblARCustomer";
            sql_str += " WHERE sBillTo_cd = '" + customer_cd + "'";
            sql_str += " OR sCustomer_cd = '" + customer_cd + "'";
            sql_str += " ORDER BY sCustomer_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sCustomer_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sCustomer_nm"), cur_set.sField("sCustomer_cd").ToString()));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            ////modCommonUtility.SetSelectedValue(ref cur_box, customer_cd);
            cur_set.Release();

        }

#if WEB
        public static void LoadCustomerPostingCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadCustomerPostingCode(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sPosting_cd FROM tblARAccounts";
            sql_str += " ORDER BY sPosting_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sPosting_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sPosting_cd"), cur_set.sField("sPosting_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadItemPostingCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadItemPostingCode(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sPosting_cd FROM tblIVAccounts";
            sql_str += " ORDER BY sPosting_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sPosting_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sPosting_cd"), cur_set.sField("sPosting_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadCustomerPriceCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCustomerPriceCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sPrice_cd FROM tblARPrice";
            sql_str += " ORDER BY sPrice_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sPrice_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sPrice_cd"), cur_set.sField("sPrice_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadCustomerTerritoryCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCustomerTerritoryCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT * FROM tblARTerritory";
            sql_str += " ORDER BY sTerritory_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sTerritory_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sTerritory_cd"), cur_set.sField("sTerritory_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadCustomerShipToCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string customer_cd)
        {
#else
            		public static void LoadCustomerShipToCode(ref ComboBox cur_box, string customer_cd)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            if (moUtility.IsEmpty(customer_cd))
            {
                return;
            }

            sql_str = "SELECT sCustomer_cd FROM tblARCustomer";
            sql_str += " WHERE (sCustomer_cd = '" + customer_cd + "')";
            sql_str += " OR (sBillTo_cd = '" + customer_cd + "')";
            sql_str += " ORDER BY sCustomer_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sCustomer_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sCustomer_cd"), cur_set.sField("sCustomer_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadCustomerTaxCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCustomerTaxCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sTax_cd FROM tblARTax";
            sql_str += " ORDER BY sTax_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sTax_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sTax_cd"), cur_set.sField("sTax_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadCustomerTermsCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadCustomerTermsCode(ref ComboBox cur_box, bool addnew_flag = false)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sTerms_cd FROM tblARTerms";
            sql_str += " ORDER BY sTerms_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sTerms_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sTerms_cd"), cur_set.sField("sTerms_cd")));
                }

                cur_set.MoveNext();

            }

#if !WEB
            			if (IsLiteVersion() && addnew_flag)
            			{
            				item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ADDNEW, cur_db.oLanguage.oString.STR_ADDNEW));
            			}
#endif
            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

        //This function should work with
        //      GetUnpostedTransactionType() and GetUnpostedTransactionTypeNum()

#if WEB
        public static void LoadStatusType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_invoiced_type = false, bool add_posted_type = false)
        {
#else
            		public static void LoadStatusType(ref ComboBox cur_box, bool add_invoiced_type = false, bool add_blank_fl = false)
            		{
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

#if WEB
                item_list.Add(new clsComboBoxItem("", ""));
#else
            				if (add_blank_fl)
            				{
            					item_list.Add(new clsComboBoxItem("", "0"));
            				}
#endif
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.OPEN_TRX, Convert.ToString(GlobalVar.goConstant.OPEN_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.HOLD_TRX, Convert.ToString(GlobalVar.goConstant.HOLD_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.VOID_TRX, Convert.ToString(GlobalVar.goConstant.VOID_TRX_NUM)));

                if (add_invoiced_type)
                {
                    item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.INVOICED_TRX, Convert.ToString(GlobalVar.goConstant.INVOICED_TRX_NUM)));
                }

#if WEB
                if (add_posted_type)
                {
                    item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.POSTED_TRX, Convert.ToString(GlobalVar.goConstant.POSTED_TRX_NUM)));
                }
#endif

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadStatusType)");
#else
            				modDialogUtility.DisplayBox(ex.Message + "(LoadStatusType)");
#endif
                return;

            }

        }

#if WEB
        public static void LoadBankTransactionStatusType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool posted_fl = true)
        {
#else
            		public static void LoadBankTransactionStatusType(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

                if (posted_fl == false)
                {
                    item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.OPEN_TRX, Convert.ToString(GlobalVar.goConstant.OPEN_TRX_NUM)));
                    item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.HOLD_TRX, Convert.ToString(GlobalVar.goConstant.HOLD_TRX_NUM)));
                }

                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.VOID_TRX, Convert.ToString(GlobalVar.goConstant.VOID_TRX_NUM)));

                if (posted_fl)
                {
                    item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.POSTED_TRX, Convert.ToString(GlobalVar.goConstant.POSTED_TRX_NUM)));
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadBankTransactionStatusType)");
#else
            				modDialogUtility.DisplayBox(ex.Message + "(LoadBankTransactionStatusType)");
#endif
                return;

            }

        }

        // This function should work with
        //       GetPostedTransactionType() and GetPostedTransactionTypeNum()
        //
#if WEB
        public static void LoadPostedStatusType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool regular_types_only = false)
        {
#else
            		public static void LoadPostedStatusType(ref ComboBox cur_box, bool regular_types_only = false)
            		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.POSTED_TRX, Convert.ToString(GlobalVar.goConstant.POSTED_TRX_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.VOID_TRX, Convert.ToString(GlobalVar.goConstant.VOID_TRX_NUM)));

            if (!regular_types_only)
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.SP_TRX, Convert.ToString(GlobalVar.goConstant.SP_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.NSF_TRX, Convert.ToString(GlobalVar.goConstant.NSF_TRX_NUM)));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

        // This function should work with
        //       GetOrderStatusType() and GetOrderStatusType()
        //
#if WEB
        public static void LoadOrderStatusType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, int order_type, bool add_suspended_fl = false)
        {
#else
            		public static void LoadOrderStatusType(ref ComboBox cur_box, int order_type, bool add_blank_fl = false, bool add_suspended_fl = false)
            		{
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

#if WEB
                item_list.Add(new clsComboBoxItem("", "0")); // Needed for searching
#else
            				if (add_blank_fl)
            				{
            					item_list.Add(new clsComboBoxItem("", "0"));
            				}
#endif
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.OPEN_TRX, Convert.ToString(GlobalVar.goConstant.OPEN_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.HOLD_TRX, Convert.ToString(GlobalVar.goConstant.HOLD_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.VOID_TRX, Convert.ToString(GlobalVar.goConstant.VOID_TRX_NUM)));

                // 12/31/2019   more specific order statuses
                //
                if (order_type == GlobalVar.goConstant.TRX_SO_TYPE)
                {
                    item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.SHIPPED_TRX, Convert.ToString(GlobalVar.goConstant.SHIPPED_TRX_NUM)));
                }
                else
                {
                    item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECEIVED_TRX, Convert.ToString(GlobalVar.goConstant.RECEIVED_TRX_NUM)));
                }

                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.INVOICED_TRX, Convert.ToString(GlobalVar.goConstant.INVOICED_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.FULFILLED_TRX, Convert.ToString(GlobalVar.goConstant.FULFILLED_TRX_NUM)));

                if (add_suspended_fl)
                {
                    item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.SUSPENDED_TRX, Convert.ToString(GlobalVar.goConstant.SUSPENDED_TRX_NUM)));
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadOrderStatusType)");
#else
            				modDialogUtility.DisplayBox(ex.Message + "(LoadOrderStatusType)");
#endif
                return;

            }

        }

        // This function should work with
        //       GetQuoteStatusType() and GetQuoteStatusTypeNum()
        //
#if WEB
        public static void LoadQuoteStatusType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadQuoteStatusType(ref ComboBox cur_box, bool add_blank_fl = false)
            		{
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

#if WEB
                item_list.Add(new clsComboBoxItem("", "0")); // Needed for searching
#else
            				if (add_blank_fl)
            				{
            					item_list.Add(new clsComboBoxItem("", "0"));
            				}
#endif
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.OPEN_TRX, Convert.ToString(GlobalVar.goConstant.OPEN_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.HOLD_TRX, Convert.ToString(GlobalVar.goConstant.HOLD_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.VOID_TRX, Convert.ToString(GlobalVar.goConstant.VOID_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.APPROVED_TRX, Convert.ToString(GlobalVar.goConstant.APPROVED_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.ORDERED_TRX, Convert.ToString(GlobalVar.goConstant.ORDERED_TRX_NUM)));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadQuoteStatusType)");
#else
            				modDialogUtility.DisplayBox(ex.Message + "(LoadQuoteStatusType)");
#endif
                return;

            }

        }

        // This function should work with
        //       GetQuoteStatusType() and GetQuoteStatusTypeNum()
        //
#if WEB
        public static void LoadPurchaseRequisitionStatusType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        public static void LoadPurchaseRequisitionStatusType(ref ComboBox cur_box)
        {
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0")); // Needed for searching

                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.OPEN_TRX, Convert.ToString(GlobalVar.goConstant.OPEN_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.HOLD_TRX, Convert.ToString(GlobalVar.goConstant.HOLD_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.VOID_TRX, Convert.ToString(GlobalVar.goConstant.VOID_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.DECLINED_TRX, Convert.ToString(GlobalVar.goConstant.DECLINED_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.ORDERED_TRX, Convert.ToString(GlobalVar.goConstant.ORDERED_TRX_NUM)));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadPurchaseRequisitionStatusType)");
#else
            	modDialogUtility.DisplayBox(ex.Message + "(LoadPurchaseRequisitionStatusType)");
#endif
                return;

            }

        }

        // This function should work with
        //       GetQuoteStatusType() and GetQuoteStatusTypeNum()
        //
#if WEB
        public static void LoadProcurementStatusType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        public static void LoadPurchaseRequisitionStatusType(ref ComboBox cur_box)
        {
#endif

            ArrayList item_list = new ArrayList();

            try
            {
                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0")); // Needed for searching

                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.OPEN_TRX, Convert.ToString(GlobalVar.goConstant.OPEN_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.HOLD_TRX, Convert.ToString(GlobalVar.goConstant.HOLD_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.VOID_TRX, Convert.ToString(GlobalVar.goConstant.VOID_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.QUOTED_TRX, Convert.ToString(GlobalVar.goConstant.QUOTED_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.FULFILLED_TRX, Convert.ToString(GlobalVar.goConstant.FULFILLED_TRX_NUM)));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadProcurementStatusType)");
#else
            	modDialogUtility.DisplayBox(ex.Message + "(LoadProcurementStatusType)");
#endif
                return;

            }

        }

        // This routine should work with
        //       GetAssemblyStatusType() and GetAssemblyStatusTypeNum()
        //
#if WEB
        public static void LoadAssemblyStatusType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadAssemblyStatusType(ref ComboBox cur_box, bool add_all_fl = false)
            		{
#endif

            ArrayList item_list = new ArrayList();
            bool box_enabled = false;

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

#if WEB
#else
            				if (add_all_fl)
            				{
            					item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL, cur_db.oLanguage.oString.STR_ALL));
            				}
#endif

                item_list.Add(new clsComboBoxItem(GlobalVar.goIVConstant.ASSEMBLY_START_STATUS, Convert.ToString(GlobalVar.goIVConstant.ASSEMBLY_START_STATUS_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goIVConstant.ASSEMBLY_HOLD_STATUS, Convert.ToString(GlobalVar.goIVConstant.ASSEMBLY_HOLD_STATUS_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goIVConstant.ASSEMBLY_CANCEL_STATUS, Convert.ToString(GlobalVar.goIVConstant.ASSEMBLY_CANCEL_STATUS_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goIVConstant.ASSEMBLY_FINISH_STATUS, Convert.ToString(GlobalVar.goIVConstant.ASSEMBLY_FINISH_STATUS_NUM)));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadAssemblyStatusType)");
#else
            				modDialogUtility.DisplayBox(ex.Message + "(LoadAssemblyStatusType)");
#endif
                return;

            }

        }

#if WEB
        public static void LoadJobStatusType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool for_reporting = false)
        {
#else
            		public static void LoadJobStatusType(ref ComboBox cur_box, bool for_reporting = false)
            		{
#endif

            ArrayList item_list = new ArrayList();
            int i = 0;

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                if (for_reporting)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL_EXCEPT_CANCELED_DECLINED, cur_db.oLanguage.oString.STR_ALL_EXCEPT_CANCELED_DECLINED));
                }

                item_list.Add(new clsComboBoxItem(GlobalVar.goJCConstant.JOB_PROPOSED_STATUS, Convert.ToString(GlobalVar.goJCConstant.JOB_PROPOSED_STATUS_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goJCConstant.JOB_DECLINED_STATUS, Convert.ToString(GlobalVar.goJCConstant.JOB_DECLINED_STATUS_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goJCConstant.JOB_ACCEPTED_STATUS, Convert.ToString(GlobalVar.goJCConstant.JOB_ACCEPTED_STATUS_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goJCConstant.JOB_STARTED_STATUS, Convert.ToString(GlobalVar.goJCConstant.JOB_STARTED_STATUS_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goJCConstant.JOB_HOLD_STATUS, Convert.ToString(GlobalVar.goJCConstant.JOB_HOLD_STATUS_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goJCConstant.JOB_CANCELED_STATUS, Convert.ToString(GlobalVar.goJCConstant.JOB_CANCELED_STATUS_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goJCConstant.JOB_FINISHED_STATUS, Convert.ToString(GlobalVar.goJCConstant.JOB_FINISHED_STATUS_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goJCConstant.JOB_CLOSED_STATUS, Convert.ToString(GlobalVar.goJCConstant.JOB_CLOSED_STATUS_NUM)));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadJobStatusType)");
#else
            				modDialogUtility.DisplayBox(ex.Message + "(LoadJobStatusType)");
#endif
                return;

            }

        }

#if WEB
        public static void LoadJobStatusCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadJobStatusCode(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = "SELECT sJobStatus_cd, sDescription FROM tblJCJobStatus";
                sql_str += " ORDER BY sJobStatus_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {

                    if (moUtility.IsNonEmpty(cur_set.sField("sJobStatus_cd")))
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sJobStatus_cd"), cur_set.sField("sJobStatus_cd")));
                    }

                    cur_set.MoveNext();

                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadJobStatusCode)");
#else
            				modDialogUtility.DisplayBox(ex.Message + "(LoadJobStatusCode)");
#endif
                cur_set.Release();
                return;

            }

        }

#if WEB
        public static void LoadJobTypeCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadJobTypeCode(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = "SELECT sJobType_cd,sDescription FROM tblJCJobType";
                sql_str += " ORDER BY sJobType_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {

                    if (moUtility.IsNonEmpty(cur_set.sField("sJobType_cd")))
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sJobType_cd"), cur_set.sField("sJobType_cd")));
                    }

                    cur_set.MoveNext();

                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadJobTypeCode)");
#else
            				modDialogUtility.DisplayBox(ex.Message + "(LoadJobTypeCode)");
#endif
                cur_set.Release();
                return;

            }

        }

#if WEB
        public static void LoadJournalCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadJournalCode(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = "SELECT sJournal_cd, sDescription FROM tblGLJournalTable";
                sql_str += " ORDER BY sJournal_cd";
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sJournal_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sJournal_cd")));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadJournalCode)");
#else
            				modDialogUtility.DisplayBox(ex.Message + "(LoadJournalCode)");
#endif
                cur_set.Release();
                return;

            }

        }

#if WEB
        public static void LoadLanguage(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadLanguage(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = "SELECT sLanguage_cd, sDescription FROM tblGOLanguage";
                sql_str += " ORDER BY sLanguage_cd";
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sLanguage_cd"), cur_set.sField("sLanguage_cd")));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadLanguageCode)");
#else
            				modDialogUtility.DisplayBox(ex.Message + "(LoadLanguageCode)");
#endif
                cur_set.Release();
                return;

            }

        }

#if WEB
        public static void LoadDepartmentCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_all_fl = false, string manager_cd = "", string all_caption = "", bool department_only = false)
        {
#else
            		public static void LoadDepartmentCode(ref ComboBox cur_box, bool add_all_fl = false, string manager_cd = "")
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                if (moUtility.IsEmpty(manager_cd))
                {
                    sql_str = "SELECT * FROM tblPRDepartment ORDER BY sDepartment_cd";
                }
                else
                {
                    sql_str = "SELECT * FROM tblPRDepartment WHERE sManager_cd = '" + manager_cd + "' ORDER BY sDepartment_cd";
                }

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                if (add_all_fl)
                {
                    if (moUtility.IsNonEmpty(all_caption))
                    {
                        item_list.Add(new clsComboBoxItem(all_caption, cur_db.oLanguage.oString.STR_ALL));
                    }
                    else
                    {
                        item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL, cur_db.oLanguage.oString.STR_ALL));
                    }
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sDepartment_cd")));
                    cur_set.MoveNext();
                }

                if (department_only == false)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DAILY_DISPATCH, cur_db.oLanguage.oString.STR_DAILY_DISPATCH));
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadDepartmentCode)");
#else
            				modDialogUtility.DisplayBox(ex.Message + "(LoadDepartmentCode)");
#endif
                cur_set.Release();
                return;

            }

        }

#if WEB
        public static void LoadPayrollGroupCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_all_fl = false)
        {
#else
            		public static void LoadPayrollGroupCode(ref ComboBox cur_box, bool add_all_fl = false)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                if (add_all_fl)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL, cur_db.oLanguage.oString.STR_ALL));
                }

                sql_str = "SELECT * FROM tblPRGroup ORDER BY sGroup_cd";
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sGroup_cd")));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadPayrollGroupCode)");
#else
            				modDialogUtility.DisplayBox(ex.Message + "(LoadPayrollGroupCode)");
#endif
                cur_set.Release();
                return;

            }

        }

#if WEB
        public static void LoadJobCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string customer_cd = "", bool include_all = false)
        {
#else
            		public static void LoadJobCode(ref ComboBox cur_box, string customer_cd = "", bool include_all = false)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;
            clsJobCost o_jc = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            o_jc = new clsJobCost(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
            			o_jc = new clsJobCost(goDatabase);
#endif


            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = "SELECT sJob_cd, sDescription FROM tblJCJob";
                sql_str += " WHERE iTransactionNotAllowed_fl = 0";
                sql_str += moUtility.IIf(moUtility.IsEmpty(customer_cd), "", " AND sCustomer_cd = '" + customer_cd + "'").ToString();
                if (!include_all)
                {
                    sql_str += " AND iStatus_typ IN (" + o_jc.GetValidJobStatusForTransaction() + ")";
                }
                sql_str += " ORDER BY sJob_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sJob_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sJob_cd")));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadJobCode)");
#else
            				modDialogUtility.DisplayBox(ex.Message + "(LoadJobCode)");
#endif
                cur_set.Release();
                return;

            }

        }

        public static void LoadJobTaskTypeCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = new clsRecordset(ref cur_db);

            try
            {
                sql_str = "SELECT sTaskType_cd, sDescription FROM tblJCTaskType";
                sql_str += " ORDER BY sTaskType_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                while (!cur_set.EOF())
                {
                    if (moUtility.IsNonEmpty(cur_set.sField("sTaskType_cd")))
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sTaskType_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sTaskType_cd")));
                    }

                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadJobTaskTypeCode)");
            }
        }

#if WEB
        public static void LoadJobTransactionTypeCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadJobTransactionTypeCode(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT sTransactionType_cd, sDescription FROM tblJCTransactionType";
                sql_str += " ORDER BY sTransactionType_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                while (!cur_set.EOF())
                {

                    if (moUtility.IsNonEmpty(cur_set.sField("sTransactionType_cd")))
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sTransactionType_cd")));
                    }

                    cur_set.MoveNext();

                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadJobTransactionTypeCode)");
#else
            				modDialogUtility.DisplayBox(ex.Message + "(LoadJobTransactionTypeCode)");
#endif
                cur_set.Release();
                return;

            }

        }

#if WEB
        public static void LoadJobExpenseTransactionTypeCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadJobExpenseTransactionTypeCode(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT sTransactionType_cd, sDescription FROM tblJCTransactionType";
                sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_JC_EXPENSE_TYPE.ToString();
                sql_str += " ORDER BY sTransactionType_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                while (!cur_set.EOF())
                {

                    if (moUtility.IsNonEmpty(cur_set.sField("sTransactionType_cd")))
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sTransactionType_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sTransactionType_cd")));
                    }

                    cur_set.MoveNext();

                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadJobExpenseTransactionTypeCode)");
#else
            				modDialogUtility.DisplayBox(ex.Message + "(LoadJobExpenseTransactionTypeCode)");
#endif
                cur_set.Release();
                return;

            }

        }

#if WEB
        public static void LoadJobRevenueTransactionTypeCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadJobRevenueTransactionTypeCode(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT sTransactionType_cd,sDescription FROM tblJCTransactionType";
                sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_JC_REVENUE_TYPE.ToString();
                sql_str += " ORDER BY sTransactionType_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                while (!cur_set.EOF())
                {

                    if (moUtility.IsNonEmpty(cur_set.sField("sTransactionType_cd")))
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sTransactionType_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sTransactionType_cd")));
                    }

                    cur_set.MoveNext();

                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadJobRevenueTransactionTypeCode)");
#else
            				modDialogUtility.DisplayBox(ex.Message + "(LoadJobRevenueTransactionTypeCode)");
#endif
                cur_set.Release();
                return;

            }

        }


#if WEB
        public static void LoadOperators(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadOperators(ref ComboBox cur_box)
            		{
#endif

            int i = 0;
            string[] list_str = null;
            ArrayList item_list = new ArrayList();


            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("=", "="));
                item_list.Add(new clsComboBoxItem("<", "<"));
                item_list.Add(new clsComboBoxItem(">", ">"));
                item_list.Add(new clsComboBoxItem("<>", "<>"));
                item_list.Add(new clsComboBoxItem(">=", ">="));
                item_list.Add(new clsComboBoxItem("<=", "<="));
                item_list.Add(new clsComboBoxItem("LIKE", "LIKE"));
                item_list.Add(new clsComboBoxItem("BETWEEN", "BETWEEN"));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadQuoteType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadQuoteType(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LI1, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LI1_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LW1, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LW1_NUM)));
            //item_list.Add(New clsComboBoxItem(goARConstant.INVOICE_TYPE_LM1, CStr(goARConstant.INVOICE_TYPE_LM1_NUM)))
            item_list.Add(new clsComboBoxItem(GlobalVar.goARConstant.INVOICE_TYPE_LS1, Convert.ToString(GlobalVar.goARConstant.INVOICE_TYPE_LS1_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goSOConstant.QUOTE_TYPE_LI1, Convert.ToString(GlobalVar.goSOConstant.QUOTE_TYPE_LI1_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goSOConstant.QUOTE_TYPE_LI2, Convert.ToString(GlobalVar.goSOConstant.QUOTE_TYPE_LI2_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadPurchaseOrderType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadPurchaseOrderType(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goPOConstant.ORDER_TYPE_LI1, Convert.ToString(GlobalVar.goPOConstant.ORDER_TYPE_LI1_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPOConstant.ORDER_TYPE_LI2, Convert.ToString(GlobalVar.goPOConstant.ORDER_TYPE_LI2_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPOConstant.ORDER_TYPE_LW1, Convert.ToString(GlobalVar.goPOConstant.ORDER_TYPE_LW1_NUM)));
            //item_list.Add(New clsComboBoxItem(goPOConstant.ORDER_TYPE_LM1, CStr(goPOConstant.ORDER_TYPE_LM1_NUM)))
            item_list.Add(new clsComboBoxItem(GlobalVar.goPOConstant.ORDER_TYPE_LC1, Convert.ToString(GlobalVar.goPOConstant.ORDER_TYPE_LC1_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadSummaryType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadSummaryType(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            int cur_num = 0;

            try
            {

                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.ACTUAL_TYPE, Convert.ToString(GlobalVar.goGLConstant.ACTUAL_TYPE_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.SUMMARY_TYPE, Convert.ToString(GlobalVar.goGLConstant.SUMMARY_TYPE_NUM)));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadSummaryType)");
#else
            				modDialogUtility.DisplayBox(ex.Message + "(LoadSummaryType)");
#endif
                return;

            }

        }

#if WEB
        public static void LoadFilingStatus(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadFilingStatus(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            // Do not change the following order.
            // If you need to change the order, you need to change the correspoding section in PRCONST.BAS
            //
#if !WEB
            			item_list.Add(new clsComboBoxItem("", "0"));
#endif
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.SINGLE_FILING, Convert.ToString(GlobalVar.goPRConstant.SINGLE_FILING_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.MARRIED_FILING, Convert.ToString(GlobalVar.goPRConstant.MARRIED_FILING_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.MARRIED_JOINT_FILING, Convert.ToString(GlobalVar.goPRConstant.MARRIED_JOINT_FILING_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.MARRIED_SEPARATE_FILING, Convert.ToString(GlobalVar.goPRConstant.MARRIED_SEPARATE_FILING_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.MARRIED_2INCOME_FILING, Convert.ToString(GlobalVar.goPRConstant.MARRIED_2INCOME_FILING_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.HOUSEHOLD_HEAD_FILING, Convert.ToString(GlobalVar.goPRConstant.HOUSEHOLD_HEAD_FILING_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.WIDOWS_FILING, Convert.ToString(GlobalVar.goPRConstant.WIDOWS_FILING_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.ALL_STATUS_FILING, Convert.ToString(GlobalVar.goPRConstant.ALL_STATUS_FILING_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.SPECIAL_A_FILING, Convert.ToString(GlobalVar.goPRConstant.SPECIAL_A_FILING_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.SPECIAL_B_FILING, Convert.ToString(GlobalVar.goPRConstant.SPECIAL_B_FILING_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.SPECIAL_C_FILING, Convert.ToString(GlobalVar.goPRConstant.SPECIAL_C_FILING_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.SPECIAL_D_FILING, Convert.ToString(GlobalVar.goPRConstant.SPECIAL_D_FILING_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadDeductionType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadDeductionType(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

#if WEB
            item_list.Add(new clsComboBoxItem("", "0"));
#endif
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.UNION_DUE_DEDUCT, Convert.ToString(GlobalVar.goPRConstant.UNION_DUE_DEDUCT_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.CREDIT_UNION_DEDUCT, Convert.ToString(GlobalVar.goPRConstant.CREDIT_UNION_DEDUCT_NUM)));
            // item_list.Add(New clsComboBoxItem(goPRConstant.GARNISHMENT_DEDUCT, CStr(goPRConstant.GARNISHMENT_DEDUCT_NUM)))  Not yet.
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.OTHER_VOLUNTARY_DEDUCT, Convert.ToString(GlobalVar.goPRConstant.OTHER_VOLUNTARY_DEDUCT_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadAfterTaxDeductionType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadAfterTaxDeductionType(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

#if WEB
            item_list.Add(new clsComboBoxItem("", "0"));
#endif
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.POST_TAX_PENSION, Convert.ToString(GlobalVar.goPRConstant.POST_TAX_PENSION_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadPreTaxDeductionType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadPreTaxDeductionType(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

#if WEB
            item_list.Add(new clsComboBoxItem("", "0"));
#endif
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PRE_TAX_401K_PLAN, Convert.ToString(GlobalVar.goPRConstant.PRE_TAX_401K_PLAN_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PRE_TAX_OTHER_PLAN, Convert.ToString(GlobalVar.goPRConstant.PRE_TAX_OTHER_PLAN_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadInsuranceType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadInsuranceType(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

#if WEB
            item_list.Add(new clsComboBoxItem("", "0"));
#endif
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.HEALTH_INS_PREMIUM, Convert.ToString(GlobalVar.goPRConstant.HEALTH_INS_PREMIUM_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.DENTAL_INS_PREMIUM, Convert.ToString(GlobalVar.goPRConstant.DENTAL_INS_PREMIUM_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.LIFE_INS_PREMIUM, Convert.ToString(GlobalVar.goPRConstant.LIFE_INS_PREMIUM_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.OTHER_INS_PREMIUM, Convert.ToString(GlobalVar.goPRConstant.OTHER_INS_PREMIUM_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadPayrollType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadPayrollType(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            // Do not change the following order.
            // If you need to change the order, you need to change the correspoding section in PRCONST.BAS
            //
#if WEB
            item_list.Add(new clsComboBoxItem("", "0"));
#endif
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PAYROLL_WEEKLY, Convert.ToString(GlobalVar.goPRConstant.PAYROLL_WEEKLY_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PAYROLL_BIWEEKLY, Convert.ToString(GlobalVar.goPRConstant.PAYROLL_BIWEEKLY_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PAYROLL_SEMIMONTHLY, Convert.ToString(GlobalVar.goPRConstant.PAYROLL_SEMIMONTHLY_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PAYROLL_MONTHLY, Convert.ToString(GlobalVar.goPRConstant.PAYROLL_MONTHLY_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PAYROLL_QUARTERLY, Convert.ToString(GlobalVar.goPRConstant.PAYROLL_QUARTERLY_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PAYROLL_SEMIYEARLY, Convert.ToString(GlobalVar.goPRConstant.PAYROLL_SEMIYEARLY_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PAYROLL_YEARLY, Convert.ToString(GlobalVar.goPRConstant.PAYROLL_YEARLY_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadEmployeeStatus(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadEmployeeStatus(ref ComboBox cur_box, bool add_blank_fl = false)
            		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

#if WEB
            item_list.Add(new clsComboBoxItem("", "0"));
#else
            			if (add_blank_fl)
            			{
            				item_list.Add(new clsComboBoxItem("", "0"));
            			}
#endif
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.ACTIVE_EMPLOYEE, Convert.ToString(GlobalVar.goPRConstant.ACTIVE_EMPLOYEE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PROSPECTIVE_EMPLOYEE, Convert.ToString(GlobalVar.goPRConstant.PROSPECTIVE_EMPLOYEE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.SUSPENDED_EMPLOYEE, Convert.ToString(GlobalVar.goPRConstant.SUSPENDED_EMPLOYEE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.INACTIVE_EMPLOYEE, Convert.ToString(GlobalVar.goPRConstant.INACTIVE_EMPLOYEE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PROBATIONARY_EMPLOYEE, Convert.ToString(GlobalVar.goPRConstant.PROBATIONARY_EMPLOYEE_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadEmployeePaymentType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadEmployeePaymentType(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

#if !WEB
            			item_list.Add(new clsComboBoxItem("", "0"));
#endif
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PAYROLL_EMPLOYEE_TYPE, Convert.ToString(GlobalVar.goPRConstant.PAYROLL_EMPLOYEE_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PAYABLE_EMPLOYEE_TYPE, Convert.ToString(GlobalVar.goPRConstant.PAYABLE_EMPLOYEE_TYPE_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadSalaryType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadSalaryType(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

#if !WEB
            			item_list.Add(new clsComboBoxItem("", "0"));
#endif
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.SALARY_BASED_TYPE, Convert.ToString(GlobalVar.goPRConstant.SALARY_BASED_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.HOURLY_BASED_TYPE, Convert.ToString(GlobalVar.goPRConstant.HOURLY_BASED_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.JOB_BASED_TYPE, Convert.ToString(GlobalVar.goPRConstant.JOB_BASED_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PIECEWORK_BASED_TYPE, Convert.ToString(GlobalVar.goPRConstant.PIECEWORK_BASED_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.OTHER_BASED_TYPE, Convert.ToString(GlobalVar.goPRConstant.OTHER_BASED_TYPE_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadShiftType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_blank_line_fl = false)
        {
#else
            		public static void LoadShiftType(ref ComboBox cur_box, bool add_blank_line_fl = false)
            		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            if (add_blank_line_fl)
            {
                item_list.Add(new clsComboBoxItem("", "0"));
            }

            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.MORNING_SHIFT_TYPE, Convert.ToString(GlobalVar.goPRConstant.MORNING_SHIFT_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.EVENING_SHIFT_TYPE, Convert.ToString(GlobalVar.goPRConstant.EVENING_SHIFT_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.NIGHT_SHIFT_TYPE, Convert.ToString(GlobalVar.goPRConstant.NIGHT_SHIFT_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.OTHER_SHIFT_TYPE, Convert.ToString(GlobalVar.goPRConstant.OTHER_SHIFT_TYPE_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadEmploymentType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_blank_line_fl = false)
        {
#else
            		public static void LoadEmploymentType(ref ComboBox cur_box, bool add_blank_line_fl = false)
            		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            if (add_blank_line_fl)
            {
                item_list.Add(new clsComboBoxItem("", "0"));
            }

            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.FULL_TIME_TYPE, Convert.ToString(GlobalVar.goPRConstant.FULL_TIME_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.HALF_TIME_TYPE, Convert.ToString(GlobalVar.goPRConstant.HALF_TIME_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.QTUARTER_TIME_TYPE, Convert.ToString(GlobalVar.goPRConstant.QTUARTER_TIME_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.OTHER_TIME_TYPE, Convert.ToString(GlobalVar.goPRConstant.OTHER_TIME_TYPE_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadAllDeductionType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadAllDeductions(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

#if WEB
            item_list.Add(new clsComboBoxItem("", "0"));
#endif

            sql_str = "SELECT sDeduction_cd, iDeduction_typ, sDescription";
            sql_str += " FROM tblPRDeduct";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), Convert.ToString(cur_set.iField("iDeduction_typ"))));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadDeductionCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, int deduction_type = 0, string employee_code = "")
        {
#else
            		public static void LoadAllDeductions(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

#if WEB
            if (moUtility.IsEmpty(employee_code))
            {
                item_list.Add(new clsComboBoxItem("", ""));
            }
#endif

            sql_str = "SELECT d.sDeduction_cd, d.iDeduction_typ, d.sDescription";
            sql_str += " FROM tblPRDeduct d";

            if (moUtility.IsNonEmpty(employee_code))
            {
                sql_str += " INNER JOIN tblPREmployeeDeduct e ON (e.sDeduction_cd = d.sDeduction_cd AND e.iDeduction_typ = d.iDeduction_typ)";
                sql_str += " WHERE e.sEmployee_cd = '" + employee_code + "'";
            }
            else if (deduction_type > 0)
            {
                sql_str += " WHERE d.iDeduction_typ = " + deduction_type.ToString();
            }

            sql_str += " ORDER BY d.sDeduction_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sDeduction_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription") + moUtility.Space(100) + cur_set.iField("iDeduction_typ").ToString(), cur_set.sField("sDeduction_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadPayrollCheckType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadPayrollCheckType(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.MUTI_PURPOSE_CHECK, Convert.ToString(GlobalVar.goConstant.MUTI_PURPOSE_CHECK_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadPayrollCashAccounts(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadPayrollCashAccounts(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

#if WEB
            item_list.Add(new clsComboBoxItem("", ""));
#endif

            sql_str = "SELECT sPRCashAcct_cd";
            sql_str += " FROM tblPRAccounts ORDER BY sPRCashAcct_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sPRCashAcct_cd"), cur_set.sField("sPRCashAcct_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadManufacturer(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadManufacturer(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sManufacturer_cd, sDescription";
            sql_str += " FROM tblIVManufacturer ORDER BY sManufacturer_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sManufacturer_cd"), cur_set.sField("sManufacturer_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadBrand(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadBrand(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sBrand_cd, sDescription";
            sql_str += " FROM tblIVBrand ORDER BY sBrand_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sBrand_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sBrand_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadModel(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadModel(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sModel_cd, sDescription";
            sql_str += " FROM tblIVModel ORDER BY sModel_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sModel_cd"), cur_set.sField("sModel_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadStyle(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadStyle(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sStyle_cd, sDescription";
            sql_str += " FROM tblIVStyle ORDER BY sStyle_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sStyle_cd"), cur_set.sField("sStyle_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadSize(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadSize(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sSize_cd, sDescription";
            sql_str += " FROM tblIVSize ORDER BY sSize_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sSize_cd"), cur_set.sField("sSize_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadColor(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadColor(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sColor_cd, sDescription ";
            sql_str += " FROM tblIVColor ORDER BY sColor_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sColor_cd"), cur_set.sField("sColor_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadServer(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadServer(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT *";
            sql_str += " FROM tblGOServer ORDER BY sServer_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sServer_nm"), cur_set.sField("sServer_nm")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadWebClass(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
            bool tempVar = false;
            LoadWebClass(ref cur_db, ref cur_box, ref tempVar);
        }

        public static void LoadWebClass(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, ref bool nodes_only)
        {
#else
            		public static void LoadWebClass(ref ComboBox cur_box, ref bool nodes_only)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));

            sql_str = "SELECT sWebClass_cd, sDescription, iLevel";
            sql_str += " FROM tblIVWebClass";
            if (nodes_only)
            {
                sql_str += " WHERE sWebClass_cd NOT IN (SELECT sParentClass_cd FROM tblIVWebClass)";
            }
            sql_str += " ORDER BY sWebClass_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                // Code needs to be attached to the description and the level.
                item_list.Add(new clsComboBoxItem(cur_set.sField("sWebClass_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription") + moUtility.Space(100) + moUtility.STrim(Convert.ToString(cur_set.iField("iLevel"))), Convert.ToString(cur_set.iField("iLevel"))));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadCountryCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadCountryCode(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string usa_code = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT sCountry_cd, sDescription";
                sql_str += " FROM tblGOCountry ORDER BY sDescription";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sCountry_cd")));
                    if (cur_set.sField("sCountry_cd") == "US" || cur_set.sField("sCountry_cd") == "USA" || cur_set.sField("sCountry_cd") == cur_db.oLanguage.oString.STR_UNITED_STATES_OF_AMERICA || cur_set.sField("sCountry_cd") == "U.S." || cur_set.sField("sCountry_cd") == "U.S.A.")
                    {
                        usa_code = cur_set.sField("sCountry_cd");
                    }
                    cur_set.MoveNext();
                }

                cur_set.Release();

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                //modCommonUtility.SetSelectedValue(ref cur_box, usa_code);

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadReferralCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadReferralCode(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sReferral_cd, sDescription";
            sql_str += " FROM tblARReferral";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sReferral_cd"), cur_set.sField("sReferral_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadSimilarityCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadSimilarityCode(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sSimilarity_cd, sDescription";
            sql_str += " FROM tblIVSimilarity";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sSimilarity_cd"), cur_set.sField("sSimilarity_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadSetCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadSetCode(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sSet_cd, sDescription";
            sql_str += " FROM tblIVSet ORDER BY sSet_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sSet_cd"), cur_set.sField("sSet_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadCustomerGroupCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_blank_flag = true)
        {
#else
            		public static void LoadCustomerGroupCode(ref ComboBox cur_box, bool addnew_flag = true)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

#if WEB
            if (add_blank_flag)
            {
                item_list.Add(new clsComboBoxItem("", ""));
            }
#else
            				item_list.Add(new clsComboBoxItem("", ""));
#endif

            sql_str = "SELECT sGroup_cd";
            sql_str += " FROM tblARGroup";
            sql_str += " ORDER BY sGroup_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sGroup_cd"), cur_set.sField("sGroup_cd")));
                cur_set.MoveNext();
            }

#if !WEB
            			if (IsLiteVersion() && addnew_flag)
            			{
            				item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ADDNEW, cur_db.oLanguage.oString.STR_ADDNEW));
            			}
#endif

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadVendorGroupCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_blank_flag = true)
        {
#else
            		public static void LoadVendorGroupCode(ref ComboBox cur_box, bool addnew_flag = true)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

#if WEB
            if (add_blank_flag)
            {
                item_list.Add(new clsComboBoxItem("", ""));
            }
#else
            			item_list.Add(new clsComboBoxItem("", ""));
#endif

            sql_str = "SELECT sGroup_cd FROM tblAPGroup";
            sql_str += " ORDER BY sGroup_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sGroup_cd"), cur_set.sField("sGroup_cd")));
                cur_set.MoveNext();
            }

#if !WEB
            			if (IsLiteVersion() && addnew_flag)
            			{
            				item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ADDNEW, cur_db.oLanguage.oString.STR_ADDNEW));
            			}
#endif

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadItemGroupCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadItemGroupCode(ref ComboBox cur_box, bool addnew_flag = true)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sGroup_cd";
            sql_str += " FROM tblIVGroup";
            sql_str += " ORDER BY sGroup_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sGroup_cd"), cur_set.sField("sGroup_cd")));
                cur_set.MoveNext();
            }

#if !WEB
            			if (IsLiteVersion() && addnew_flag)
            			{
            				item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ADDNEW, cur_db.oLanguage.oString.STR_ADDNEW));
            			}
#endif

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadViaCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
            		public static void LoadViaCode(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sVia_cd";
            sql_str += " FROM tblARVia ORDER BY sVia_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sVia_cd"), cur_set.sField("sVia_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadCommissionCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCommissionCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sCommission_cd FROM tblARCommission ORDER BY sCommission_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                if (moUtility.IsNonEmpty(cur_set.sField("sCommission_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sCommission_cd"), cur_set.sField("sCommission_cd")));
                }
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadWarrantyCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadWarrantyCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sWarranty_cd";
            sql_str += " FROM tblIVWarranty ORDER BY sWarranty_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sWarranty_cd"), cur_set.sField("sWarranty_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadSaleCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadSaleCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sSale_cd";
            sql_str += " FROM tblIVSale ORDER BY sSale_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sSale_cd"), cur_set.sField("sSale_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadEventCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadEventCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sEvent_cd";
            sql_str += " FROM tblIVEvent ORDER BY sEvent_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sEvent_cd"), cur_set.sField("sEvent_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadBox(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadBox(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sBox_cd, sDescription";
            sql_str += " FROM tblIVBox ORDER BY sBox_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sBox_cd"), cur_set.sField("sBox_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadQAStatusCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, int pass_fl)
        {
#else
        		public static void LoadQAStatusCode(ref ComboBox cur_box, int pass_fl)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sQAStatus_cd, sDescription";
            sql_str += " FROM tblIVQAStatus WHERE iPass_fl = " + pass_fl + " ORDER BY sQAStatus_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sQAStatus_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadStatusId(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadStatusId(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));

            sql_str = "SELECT iStatus_id, sDescription";
            sql_str += " FROM tblRMStatus ORDER BY iStatus_id";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), Convert.ToString(cur_set.iField("iStatus_id"))));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadPrinters(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadPrinters(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            //Dim prnt As Printer

            try
            {


                //For	Each prnt In Printers
                //item_list.Add(New clsComboBoxItem(prnt.DeviceName)
                //Next prnt

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadPrinters)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadPrinters)");
#endif
                return;

            }

        }

#if WEB
        public static void LoadCommission(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCommission(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sCommission_cd, sDescription";
            sql_str += " FROM tblARCommission ORDER BY sCommission_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sCommission_cd"), cur_set.sField("sCommission_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadUserGroup(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadUserGroup(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = "SELECT sUserGroup_cd";
                sql_str += ",sDescription";
                sql_str += " FROM tblGOUserGroup";
                //If Not goUtility.IsSystemAdministrator(ref cur_db) _
                //'And cur_form.Name = goRule.USER_ENTRY_FORM Then
                //    sql_str &=  " WHERE sUserGroup_cd = " & cur_db.sUserGroup_cd
                //End If
                sql_str += " ORDER BY sUserGroup_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sUserGroup_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sUserGroup_cd")));
                    cur_set.MoveNext();
                    modGeneralUtility.RunEvents();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadUserGroup)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadUserGroup)");
#endif
                cur_set.Release();
                return;

            }

        }

#if WEB
        public static void LoadUserType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool management_only = false)
        {
#else
        		public static void LoadUserType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);

        			clsDatabase cur_db = null;

        			cur_db = new clsDatabase();
        			cur_db = goDatabase;

#endif

            try
            {
                sql_str = "SELECT iUserType_id";
                sql_str += ",sUserType_id";
                sql_str += ",sUserType_nm";
                sql_str += " FROM tblGOUserType";

                if (moUtility.IsSystemAdministrator(cur_db))
                {
                    sql_str += " WHERE iUserType_id <= " + cur_db.iUserType_id.ToString();
                }
                else
                {
                    sql_str += " WHERE iUserType_id < " + cur_db.iUserType_id.ToString();
                }

                if (management_only)
                {
                    sql_str += " AND iUserType_id >= " + clsConstant.USER_SUPERVISOR_TYPE;
                    sql_str += " AND iUserType_id < " + clsConstant.USER_SA_TYPE;
                }

                sql_str += " ORDER BY iUserType_id";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sUserType_nm"), Convert.ToString(cur_set.iField("iUserType_id"))));
                    cur_set.MoveNext();
                    modGeneralUtility.RunEvents();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadUserType)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadUserType)");
#endif
                cur_set.Release();
                return;

            }

        }

#if WEB
        public static void LoadOffice(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadOffice(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = "SELECT sOffice_cd, sDescription";
                sql_str += " FROM tblGOOffice";
                sql_str += " ORDER BY sOffice_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sOffice_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sOffice_cd")));
                    cur_set.MoveNext();
                    modGeneralUtility.RunEvents();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadOffice)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadOffice)");
#endif
                cur_set.Release();
                return;

            }

        }

#if WEB
        public static void LoadAPPostingCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadAPPostingCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sPosting_cd, sDescription";
            sql_str += " FROM tblAPAccounts";
            sql_str += " ORDER BY sPosting_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sPosting_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sPosting_cd")));
                cur_set.MoveNext();
                modGeneralUtility.RunEvents();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadARPostingCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadARPostingCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sPosting_cd, sDescription";
            sql_str += " FROM tblARAccounts";
            sql_str += " ORDER BY sPosting_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sPosting_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sPosting_cd")));
                cur_set.MoveNext();
                modGeneralUtility.RunEvents();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadIVPostingCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadIVPostingCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sPosting_cd, sDescription";
            sql_str += " FROM tblIVAccounts";
            sql_str += " ORDER BY sPosting_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sPosting_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sPosting_cd")));
                cur_set.MoveNext();
                modGeneralUtility.RunEvents();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadPRPostingCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadPRPostingCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sPosting_cd, sDescription";
            sql_str += " FROM tblPRAccounts";
            sql_str += " ORDER BY sPosting_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sPosting_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sPosting_cd")));
                cur_set.MoveNext();
                modGeneralUtility.RunEvents();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadPROvertimeCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadPROvertimeCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sOvertime_cd, sDescription";
            sql_str += " FROM tblPROvertime";
            sql_str += " ORDER BY sOvertime_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sOvertime_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sOvertime_cd")));
                cur_set.MoveNext();
                modGeneralUtility.RunEvents();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

        //public static void LoadSalesTrackType(ref clsDatabase cur_db, ref RadioButtonList cur_box)
        //{

        //    DataTable data_table = new DataTable();
        //    DataRow data_row = null;

        //    try
        //    {

        //        data_table.Columns.Add(new DataColumn("Text", typeof(string)));
        //        data_table.Columns.Add(new DataColumn("Value", typeof(string)));

        //        data_row = data_table.NewRow();
        //        data_row[0] = "Monthly";
        //        data_row[1] = GlobalVar.goConstant.TRACK_MONTHLY_TYPE_NUM.ToString();
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();
        //        data_row[0] = "Quarterly";
        //        data_row[1] = GlobalVar.goConstant.TRACK_QUARTERLY_TYPE_NUM.ToString();
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();
        //        data_row[0] = "Yearly";
        //        data_row[1] = GlobalVar.goConstant.TRACK_YEARLY_TYPE_NUM.ToString();
        //        data_table.Rows.Add(data_row);

        //        cur_box.DataSource = new DataView(data_table);
        //        cur_box.DataTextField = "Text";
        //        cur_box.DataValueField = "Value";
        //        cur_box.DataBind();

        //        return;

        //    }
        //    catch (Exception ex)
        //    {

        //        return;

        //    }

        //}

        //public static void LoadVendorPurchaseAnalysisType(ref clsDatabase cur_db, ref RadioButtonList cur_box)
        //{

        //    DataTable data_table = new DataTable();
        //    DataRow data_row = null;

        //    try
        //    {

        //        data_table.Columns.Add(new DataColumn("Text", typeof(string)));
        //        data_table.Columns.Add(new DataColumn("Value", typeof(string)));

        //        data_row = data_table.NewRow();
        //        data_row[0] = "Item Only";
        //        data_row[1] = "1";
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();
        //        data_row[0] = "Vendor Only";
        //        data_row[1] = "2";
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();
        //        data_row[0] = "Item & Vendor";
        //        data_row[1] = "3";
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();
        //        data_row[0] = "Vendor & Item";
        //        data_row[1] = "4";
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();

        //        cur_box.DataSource = new DataView(data_table);
        //        cur_box.DataTextField = "Text";
        //        cur_box.DataValueField = "Value";
        //        cur_box.DataBind();

        //        return;

        //    }
        //    catch (Exception ex)
        //    {

        //        return;

        //    }

        //}

        //public static void LoadFiscalPeriodType(ref clsDatabase cur_db, ref RadioButtonList cur_box)
        //{

        //    DataTable data_table = new DataTable();
        //    DataRow data_row = null;

        //    try
        //    {

        //        data_table.Columns.Add(new DataColumn("Text", typeof(string)));
        //        data_table.Columns.Add(new DataColumn("Value", typeof(string)));

        //        data_row = data_table.NewRow();
        //        data_row[0] = "12 Periods";
        //        data_row[1] = "12";
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();
        //        data_row[0] = "13 Periods";
        //        data_row[1] = "13";
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();
        //        data_row[0] = "Others";
        //        data_row[1] = "14";
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();

        //        cur_box.DataSource = new DataView(data_table);
        //        cur_box.DataTextField = "Text";
        //        cur_box.DataValueField = "Value";
        //        cur_box.DataBind();

        //        return;

        //    }
        //    catch (Exception ex)
        //    {

        //        return;

        //    }

        //}

        //public static void LoadCustomerSalesAnalysisType(ref clsDatabase cur_db, ref RadioButtonList cur_box)
        //{

        //    DataTable data_table = new DataTable();
        //    DataRow data_row = null;

        //    try
        //    {

        //        data_table.Columns.Add(new DataColumn("Text", typeof(string)));
        //        data_table.Columns.Add(new DataColumn("Value", typeof(string)));

        //        data_row = data_table.NewRow();
        //        data_row[0] = "Item Only";
        //        data_row[1] = "1";
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();
        //        data_row[0] = "Customer Only";
        //        data_row[1] = "2";
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();
        //        data_row[0] = "Item & Customer";
        //        data_row[1] = "3";
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();
        //        data_row[0] = "Customer & Item";
        //        data_row[1] = "4";
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();

        //        cur_box.DataSource = new DataView(data_table);
        //        cur_box.DataTextField = "Text";
        //        cur_box.DataValueField = "Value";
        //        cur_box.DataBind();

        //        return;

        //    }
        //    catch (Exception ex)
        //    {

        //        return;

        //    }

        //}

        //public static void LoadItemSalesAnalysisType(ref clsDatabase cur_db, ref RadioButtonList cur_box)
        //{

        //    DataTable data_table = new DataTable();
        //    DataRow data_row = null;

        //    try
        //    {

        //        data_table.Columns.Add(new DataColumn("Text", typeof(string)));
        //        data_table.Columns.Add(new DataColumn("Value", typeof(string)));

        //        data_row = data_table.NewRow();
        //        data_row[0] = "Item Only";
        //        data_row[1] = "1";
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();
        //        data_row[0] = "Location Only";
        //        data_row[1] = "2";
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();
        //        data_row[0] = "Item & Location";
        //        data_row[1] = "3";
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();
        //        data_row[0] = "Location & Item";
        //        data_row[1] = "4";
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();

        //        cur_box.DataSource = new DataView(data_table);
        //        cur_box.DataTextField = "Text";
        //        cur_box.DataValueField = "Value";
        //        cur_box.DataBind();

        //        return;

        //    }
        //    catch (Exception ex)
        //    {

        //        return;

        //    }

        //}

        //public static void LoadItemSalesTrackType(ref clsDatabase cur_db, ref RadioButtonList cur_box, bool all_types = false)
        //{

        //    DataTable data_table = new DataTable();
        //    DataRow data_row = null;

        //    try
        //    {

        //        data_table.Columns.Add(new DataColumn("Text", typeof(string)));
        //        data_table.Columns.Add(new DataColumn("Value", typeof(string)));

        //        if (all_types)
        //        {
        //            data_row = data_table.NewRow();
        //            data_row[0] = "Yearly";
        //            data_row[1] = GlobalVar.goConstant.TRACK_YEARLY_TYPE_NUM.ToString();
        //            data_table.Rows.Add(data_row);
        //            data_row = data_table.NewRow();
        //            data_row[0] = "Quarterly";
        //            data_row[1] = GlobalVar.goConstant.TRACK_QUARTERLY_TYPE_NUM.ToString();
        //            data_table.Rows.Add(data_row);
        //            data_row = data_table.NewRow();
        //        }
        //        data_row = data_table.NewRow();
        //        data_row[0] = "Monthly";
        //        data_row[1] = GlobalVar.goConstant.TRACK_MONTHLY_TYPE_NUM.ToString();
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();
        //        data_row[0] = "Weekly";
        //        data_row[1] = GlobalVar.goConstant.TRACK_WEEKLY_TYPE_NUM.ToString();
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();

        //        cur_box.DataSource = new DataView(data_table);
        //        cur_box.DataTextField = "Text";
        //        cur_box.DataValueField = "Value";
        //        cur_box.DataBind();

        //        return;

        //    }
        //    catch (Exception ex)
        //    {

        //        return;

        //    }

        //}

        //public static void LoadKitAssemblyType(ref clsDatabase cur_db, ref RadioButtonList cur_box)
        //{

        //    DataTable data_table = new DataTable();
        //    DataRow data_row = null;

        //    try
        //    {

        //        data_table.Columns.Add(new DataColumn("Text", typeof(string)));
        //        data_table.Columns.Add(new DataColumn("Value", typeof(string)));

        //        data_row = data_table.NewRow();
        //        data_row[0] = "Auto-Assembled";
        //        data_row[1] = GlobalVar.goIVConstant.AUTO_ASSEMBLE_TYPE.ToString();
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();
        //        data_row[0] = "Pre-Assembled";
        //        data_row[1] = GlobalVar.goIVConstant.PRE_ASSEMBLE_TYPE.ToString();
        //        data_table.Rows.Add(data_row);
        //        data_row = data_table.NewRow();

        //        cur_box.DataSource = new DataView(data_table);
        //        cur_box.DataTextField = "Text";
        //        cur_box.DataValueField = "Value";
        //        cur_box.DataBind();

        //        return;

        //    }
        //    catch (Exception ex)
        //    {

        //        return;

        //    }

        //}

#if WEB
        public static void LoadEmailSelectionList(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool all_fl, string module_id)
        {
#else
        		public static void LoadEmailSelectionList(ref ComboBox cur_box, bool all_fl, string module_id)
        		{
#endif

            ArrayList item_list = new ArrayList();
            int address_typ = 0;

#if WEB
            address_typ = cur_db.iAddress_typ;
#else
        			address_typ = goDatabase.iAddress_typ;
#endif

            if (module_id == GlobalVar.goConstant.APMENU_NAME)
            {
                if (all_fl)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL_VENDORS, cur_db.oLanguage.oString.STR_ALL_VENDORS));
                }
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_VENDOR_CODE, "sVendor_cd"));
            }
            else
            {
                if (all_fl)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL_CUSTOMERS, cur_db.oLanguage.oString.STR_ALL_CUSTOMERS));
                }
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CUSTOMER_CODE, "sCustomer_cd"));
            }

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CLASS_CODE, "sClass_cd"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_GROUP_CODE, "sGroup_cd"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_SORT_KEY1, "sSortKey1"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_SORT_KEY2, "sSortKey2"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_STATUS, "iStatus_typ"));

            if (address_typ == GlobalVar.goConstant.ADDRESS_USA)
            {
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CITY, "sCity"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_STATE, "sState"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ZIP_CODE, "sZipCode"));
            }

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_BALANCE, "mBalanceDue_amt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oMessage.LAST_EMAIL_DATE, "iLastEmail_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oMessage.TOTAL_EMAIL_NUM, "iTotalEmails_num"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oMessage.CREATED_DATE, "iCreated_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oMessage.EMAIL_ID, "sLastEmail_id"));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadIncomeTaxType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, int tax_type)
        {
#else
        		public static void LoadIncomeTaxType(ref ComboBox cur_box, int tax_type)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = "SELECT sTax_cd, sDescription FROM tblPRTax";
                sql_str += " WHERE iTax_typ = " + tax_type;
                sql_str += " ORDER BY sTax_cd";
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sTax_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sTax_cd")));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadSETT)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadSETT)");
#endif
                cur_set.Release();
                return;

            }

        }

#if WEB
        public static void LoadPRGroupCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_all_fl = false)
        {
#else
        		public static void LoadPRGroupCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            if (add_all_fl)
            {
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL, cur_db.oLanguage.oString.STR_ALL));
            }

            sql_str = "SELECT * FROM tblPRGroup";
            sql_str += " ORDER BY sDescription";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sGroup_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sGroup_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadProspectType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "")
        {
#else
        		public static void LoadProspectType(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT iProspect_typ, sDescription";
                sql_str += " FROM tblARProspectType";
                sql_str += " ORDER BY sDescription";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iProspect_typ").ToString()));
                    cur_set.MoveNext();
                }

                if (moUtility.IsNonEmpty(additional_item))
                {
                    item_list.Add(new clsComboBoxItem(additional_item, additional_item));
                }

                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.NEWEDIT, clsConstant.CRM_NEWEDIT_ID));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadProspectStatus(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "", bool add_new = true)
        {
#else
        		public static void LoadProspectStatus(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT iProspectStatus_id, sDescription";
                sql_str += " FROM tblARProspectStatus";
                sql_str += " ORDER BY iProspectStatus_id, sDescription";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iProspectStatus_id").ToString()));
                    cur_set.MoveNext();
                }

                if (moUtility.IsNonEmpty(additional_item))
                {
                    item_list.Add(new clsComboBoxItem(additional_item, additional_item));
                }

                if (add_new)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.NEWEDIT, clsConstant.CRM_NEWEDIT_ID));
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadProspectGroup(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "")
        {
#else
        		public static void LoadProspectGroup(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT iProspectGroup_id, sDescription";
                sql_str += " FROM tblARProspectGroup";
                sql_str += " ORDER BY sDescription";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iProspectGroup_id").ToString()));
                    cur_set.MoveNext();
                }

                if (moUtility.IsNonEmpty(additional_item))
                {
                    item_list.Add(new clsComboBoxItem(additional_item, additional_item));
                }

                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.NEWEDIT, clsConstant.CRM_NEWEDIT_ID));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadProspectTitle(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "")
        {
#else
        		public static void LoadProspectTitle(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT iProspectTitle_id, sDescription";
                sql_str += " FROM tblARProspectTitle";
                sql_str += " ORDER BY sDescription";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iProspectTitle_id").ToString()));
                    cur_set.MoveNext();
                }

                if (moUtility.IsNonEmpty(additional_item))
                {
                    item_list.Add(new clsComboBoxItem(additional_item, additional_item));
                }

                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.NEWEDIT, clsConstant.CRM_NEWEDIT_ID));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadProspectDepartment(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "")
        {
#else
        		public static void LoadProspectDepartment(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT iProspectDepartment_id, sDescription";
                sql_str += " FROM tblARProspectDepartment";
                sql_str += " ORDER BY sDescription";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iProspectDepartment_id").ToString()));
                    cur_set.MoveNext();
                }

                if (moUtility.IsNonEmpty(additional_item))
                {
                    item_list.Add(new clsComboBoxItem(additional_item, additional_item));
                }

                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.NEWEDIT, clsConstant.CRM_NEWEDIT_ID));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadProspectHobby(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "")
        {
#else
        		public static void LoadProspectHobby(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT iProspectHobby_id, sDescription";
                sql_str += " FROM tblARProspectHobby";
                sql_str += " ORDER BY sDescription";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iProspectHobby_id").ToString()));
                    cur_set.MoveNext();
                }

                if (moUtility.IsNonEmpty(additional_item))
                {
                    item_list.Add(new clsComboBoxItem(additional_item, additional_item));
                }

                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.NEWEDIT, clsConstant.CRM_NEWEDIT_ID));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadOpportunityStatus(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "", bool add_new = true)
        {
#else
        		public static void LoadOpportunityStatus(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT iOpportunityStatus_id, sDescription";
                sql_str += " FROM tblAROpportunityStatus";
                sql_str += " ORDER BY iOpportunityStatus_id";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iOpportunityStatus_id").ToString()));
                    cur_set.MoveNext();
                }

                if (moUtility.IsNonEmpty(additional_item))
                {
                    item_list.Add(new clsComboBoxItem(additional_item, additional_item));
                }

                if (add_new)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.NEWEDIT, clsConstant.CRM_NEWEDIT_ID));
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadOpportunityStage(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "", bool add_new = true)
        {
#else
        		public static void LoadOpportunityStage(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT iOpportunityStage_id, sDescription";
                sql_str += " FROM tblAROpportunityStage";
                sql_str += " ORDER BY iOpportunityStage_id";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iOpportunityStage_id").ToString()));
                    cur_set.MoveNext();
                }

                if (moUtility.IsNonEmpty(additional_item))
                {
                    item_list.Add(new clsComboBoxItem(additional_item, additional_item));
                }

                if (add_new)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.NEWEDIT, clsConstant.CRM_NEWEDIT_ID));
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadOpportunityProbability(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "", bool add_new = true)
        {
#else
        		public static void LoadOpportunityProbability(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT iOpportunityProbability_id, sDescription";
                sql_str += " FROM tblAROpportunityProbability";
                sql_str += " ORDER BY iOpportunityProbability_id";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iOpportunityProbability_id").ToString()));
                    cur_set.MoveNext();
                }

                if (moUtility.IsNonEmpty(additional_item))
                {
                    item_list.Add(new clsComboBoxItem(additional_item, additional_item));
                }

                if (add_new)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.NEWEDIT, clsConstant.CRM_NEWEDIT_ID));
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadNextContactReason(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "")
        {
#else
        		public static void LoadNextContactReason(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT iNextContactReason_id, sDescription";
                sql_str += " FROM tblARProspectNextContactReason";
                sql_str += " ORDER BY sDescription";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iNextContactReason_id").ToString()));
                    cur_set.MoveNext();
                }

                if (moUtility.IsNonEmpty(additional_item))
                {
                    item_list.Add(new clsComboBoxItem(additional_item, additional_item));
                }

                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.NEWEDIT, clsConstant.CRM_NEWEDIT_ID));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadLastContactResult(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "")
        {
#else
        		public static void LoadLastContactResult(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT iLastContactResult_id, sDescription";
                sql_str += " FROM tblARProspectLastContactResult";
                sql_str += " ORDER BY sDescription";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iLastContactResult_id").ToString()));
                    cur_set.MoveNext();
                }

                if (moUtility.IsNonEmpty(additional_item))
                {
                    item_list.Add(new clsComboBoxItem(additional_item, additional_item));
                }

                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.NEWEDIT, clsConstant.CRM_NEWEDIT_ID));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadCustomerRequest(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "", bool add_new = true)
        {
#else
        		public static void LoadCustomerRequest(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT iReason_id, sDescription";
                sql_str += " FROM tblARCustomerCallReason";
                sql_str += " ORDER BY iReason_id, sDescription";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iReason_id").ToString()));
                    cur_set.MoveNext();
                }

                if (moUtility.IsNonEmpty(additional_item))
                {
                    item_list.Add(new clsComboBoxItem(additional_item, additional_item));
                }

                if (add_new)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.NEWEDIT, clsConstant.CRM_NEWEDIT_ID));
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadCustomerResolution(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "", bool add_new = true)
        {
#else
        		public static void LoadCustomerResolution(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT iResolution_id, sDescription";
                sql_str += " FROM tblARCustomerCallResolution";
                sql_str += " ORDER BY iResolution_id, sDescription";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iResolution_id").ToString()));
                    cur_set.MoveNext();
                }

                if (moUtility.IsNonEmpty(additional_item))
                {
                    item_list.Add(new clsComboBoxItem(additional_item, additional_item));
                }

                if (add_new)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.NEWEDIT, clsConstant.CRM_NEWEDIT_ID));
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadSupportPriority(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool include_higher_fl)
        {
#else
        		public static void LoadSupportPriority(ref ComboBox cur_box, bool include_higher_fl)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));
                item_list.Add(new clsComboBoxItem("Very Low", "1"));
                if (include_higher_fl)
                {
                    item_list.Add(new clsComboBoxItem("Very Low+", "1+"));
                }
                item_list.Add(new clsComboBoxItem("Low", "2"));
                if (include_higher_fl)
                {
                    item_list.Add(new clsComboBoxItem("Low+", "2+"));
                }
                item_list.Add(new clsComboBoxItem("High", "3"));
                if (include_higher_fl)
                {
                    item_list.Add(new clsComboBoxItem("High+", "3+"));
                }
                item_list.Add(new clsComboBoxItem("Very High", "4"));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadSupportStatus(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadSupportStatus(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.SUPPORT_OPEN, GlobalVar.goConstant.SUPPORT_OPEN_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.SUPPORT_PENDING, GlobalVar.goConstant.SUPPORT_PENDING_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.SUPPORT_CLOSED, GlobalVar.goConstant.SUPPORT_CLOSED_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.SUPPORT_CANCELED, GlobalVar.goConstant.SUPPORT_CANCELED_NUM.ToString()));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadUserCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string where_clause = "")
        {
#else
        		public static void LoadUserCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT sUser_cd";
                sql_str += ",sUser_nm";
                sql_str += " FROM tblGOUser";

                if (moUtility.IsNonEmpty(where_clause))
                {
                    sql_str += " WHERE " + where_clause;
                }
                sql_str += " ORDER BY sUser_cd";
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sUser_cd") + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + cur_set.sField("sUser_nm"), cur_set.sField("sUser_cd")));
                    cur_set.MoveNext();
                    modGeneralUtility.RunEvents();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadActualAccount(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, int group_type)
        {
#else
        		public static void LoadActualAccount(ref ComboBox cur_box, int group_type, bool add_blank_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            // Create the list of cash account, income, and earning accts.
            // Only get the actual account type.
            //
            sql_str = modConstant.ACCT_DYNASET;
            sql_str += " WHERE iSummary_typ = " + GlobalVar.goGLConstant.ACTUAL_TYPE_NUM;
            sql_str += " AND (iGroup_typ >= " + group_type;
            sql_str += " AND iGroup_typ < " + moUtility.GetNextAccountGroupType(group_type) + ")";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

#if !WEB
        			if (add_blank_fl)
        			{
        				item_list.Add(new clsComboBoxItem("", ""));
        			}
#endif

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sAccount_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sAccount_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadEvaluationLevel(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadEvaluationLevel(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            try
            {

                item_list.Add(new clsComboBoxItem("", ""));
                item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.REVIEW_EXCELLENT, GlobalVar.goPRConstant.REVIEW_EXCELLENT_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.REVIEW_GOOD, GlobalVar.goPRConstant.REVIEW_GOOD_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.REVIEW_AVERAGE, GlobalVar.goPRConstant.REVIEW_AVERAGE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.REVIEW_POOR, GlobalVar.goPRConstant.REVIEW_POOR_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.REVIEW_UNACCEPTABLE, GlobalVar.goPRConstant.REVIEW_UNACCEPTABLE_NUM.ToString()));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadEducationType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadEducationType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.DEGREE_UK, GlobalVar.goPRConstant.DEGREE_UK));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.DEGREE_HS, GlobalVar.goPRConstant.DEGREE_HS));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.DEGREE_BS, GlobalVar.goPRConstant.DEGREE_BS));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.DEGREE_BA, GlobalVar.goPRConstant.DEGREE_BA));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.DEGREE_MS, GlobalVar.goPRConstant.DEGREE_MS));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.DEGREE_MA, GlobalVar.goPRConstant.DEGREE_MA));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.DEGREE_MD, GlobalVar.goPRConstant.DEGREE_MD));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.DEGREE_JD, GlobalVar.goPRConstant.DEGREE_JD));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.DEGREE_PHD, GlobalVar.goPRConstant.DEGREE_PHD));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadCertificateType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCertificateType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.CERTIFICATE_TYPE, Convert.ToString(GlobalVar.goPRConstant.CERTIFICATE_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PERMIT_TYPE, Convert.ToString(GlobalVar.goPRConstant.PERMIT_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.LICENSE_TYPE, Convert.ToString(GlobalVar.goPRConstant.LICENSE_TYPE_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadSkillCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string employee_code = "")
        {
#else
        		public static void LoadSkillCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        	cur_set = new clsRecordset(goDatabase);
        	o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT s.sSkill_cd, s.sDescription";
                sql_str += " FROM tblPRSkill s";

                if (moUtility.IsNonEmpty(employee_code))
                {
                    sql_str += " INNER JOIN tblPREmployeeSkill e ON (e.sSkill_cd = s.sSkill_cd)";
                    sql_str += " WHERE e.sEmployee_cd = '" + employee_code + "'";
                }

                sql_str += " ORDER BY s.sDescription";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                if (moUtility.IsEmpty(employee_code))
                {
                    item_list.Add(new clsComboBoxItem("", ""));
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sSkill_cd")));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadCertificateCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, int certificate_type = 0)
        {
#else
        		public static void LoadCertificateCode(ref ComboBox cur_box, int certificate_type = 0)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT sCertificate_cd, sDescription";
                sql_str += " FROM tblPRCertificate";
                if (certificate_type > 0)
                {
                    sql_str += " WHERE iCertificate_typ = " + certificate_type.ToString();
                }
                sql_str += " ORDER BY sDescription";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sCertificate_cd")));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadPayRateType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadPayRateType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PAY_RATE_TYPE_HOURLY, GlobalVar.goPRConstant.PAY_RATE_TYPE_HOURLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PAY_RATE_TYPE_DAILY, GlobalVar.goPRConstant.PAY_RATE_TYPE_DAILY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PAY_RATE_TYPE_WEEKLY, GlobalVar.goPRConstant.PAY_RATE_TYPE_WEEKLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PAY_RATE_TYPE_MONTHLY, GlobalVar.goPRConstant.PAY_RATE_TYPE_MONTHLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PAY_RATE_TYPE_YEARLY, GlobalVar.goPRConstant.PAY_RATE_TYPE_YEARLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.PAY_RATE_TYPE_LUMPSUM, GlobalVar.goPRConstant.PAY_RATE_TYPE_LUMPSUM_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadHiringLengthType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadHiringLengthType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.HIRING_LENGTH_HOURS, GlobalVar.goPRConstant.HIRING_LENGTH_HOURS_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.HIRING_LENGTH_DAYS, GlobalVar.goPRConstant.HIRING_LENGTH_DAYS_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.HIRING_LENGTH_WEEKS, GlobalVar.goPRConstant.HIRING_LENGTH_WEEKS_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.HIRING_LENGTH_MONTHS, GlobalVar.goPRConstant.HIRING_LENGTH_MONTHS_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.HIRING_LENGTH_YEARS, GlobalVar.goPRConstant.HIRING_LENGTH_YEARS_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goPRConstant.HIRING_LENGTH_PERMANENT, GlobalVar.goPRConstant.HIRING_LENGTH_PERMANENT_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadBlanketOrderTypes(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadBlanketOrderTypes(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goSOConstant.BLANKET_ORDER_BY_QTY_TYPE, Convert.ToString(GlobalVar.goSOConstant.BLANKET_ORDER_BY_QTY_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goSOConstant.BLANKET_ORDER_BY_AMOUNT_TYPE, Convert.ToString(GlobalVar.goSOConstant.BLANKET_ORDER_BY_AMOUNT_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goSOConstant.BLANKET_ORDER_BY_BOTH_TYPE, Convert.ToString(GlobalVar.goSOConstant.BLANKET_ORDER_BY_BOTH_TYPE_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadTransactionsForApproval(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadTransactionsForApproval(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CASH_RECEIPT, Convert.ToString(GlobalVar.goConstant.TRX_RECEIPT_TYPE)));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CASH_PAYMENT, Convert.ToString(GlobalVar.goConstant.TRX_PAYMENT_TYPE)));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CREDIT_MEMO, Convert.ToString(GlobalVar.goConstant.TRX_CM_TYPE)));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DEBIT_MEMO, Convert.ToString(GlobalVar.goConstant.TRX_DM_TYPE)));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_INVOICE, Convert.ToString(GlobalVar.goConstant.TRX_INVOICE_TYPE)));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ORDER, Convert.ToString(GlobalVar.goConstant.TRX_SO_TYPE))); // should also goes thru credit limit check.
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PURCHASE_ORDER, Convert.ToString(GlobalVar.goConstant.TRX_PO_TYPE)));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PURCHASE_REQUISITION, Convert.ToString(GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE)));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_QUOTE, Convert.ToString(GlobalVar.goConstant.TRX_QUOTE_TYPE)));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_VOUCHER, Convert.ToString(GlobalVar.goConstant.TRX_PURCHASE_TYPE)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadAccountgGroupType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, ref string[,] account_group, int type_col, int desc_col)
        {
#else
        		public static void LoadAccountgGroupType(ref ComboBox cur_box, ref string[,] account_group, int type_col, int desc_col)
        		{
#endif

            ArrayList item_list = new ArrayList();
            int i = 0;

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            for (i = 0; i < account_group.GetLength(1); i++)
            {
                if ((moUtility.ToValue(account_group[type_col, i]) % 100) == 0)
                {
                    item_list.Add(new clsComboBoxItem(account_group[desc_col, i], account_group[type_col, i]));
                }
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

        // Request info is from clsRMA.
        //
#if WEB
        public static void LoadRMARequestID(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadRMARequestID(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            int i = 0;
            string[,] request_info = null;
            clsRMA o_rma = null;

#if WEB
            o_rma = new clsRMA(ref cur_db);
#else
        			o_rma = new clsRMA(goDatabase);
#endif

            if (!o_rma.GetRequestFullInfo(ref request_info))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            for (i = 0; i < request_info.GetLength(1); i++)
            {
                item_list.Add(new clsComboBoxItem(request_info[clsRMA.REQUEST_DESC_COL, i], request_info[clsRMA.REQUEST_ID_COL, i]));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

        // Status info is from clsRMA.
        //
#if WEB
        public static void LoadRMAStatusID(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool exclude_arrival_status_fl = false, bool repair_complete_only = false)
        {
#else
        		public static void LoadRMAStatusID(ref ComboBox cur_box, bool exclude_arrival_status_fl = false, bool repair_complete_only = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string[,] status_info = null;
            int i = 0;
            clsRMA o_rma = null;
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            o_rma = new clsRMA(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			o_rma = new clsRMA(goDatabase);
#endif

            if (!o_rma.GetStatusFullInfo(ref status_info, exclude_arrival_status_fl))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            for (i = 0; i < status_info.GetLength(1); i++)
            {
                if (repair_complete_only)
                {
                    if ((moUtility.ToValue(status_info[clsRMA.STATUS_ID_COL, i]) == clsRMA.STATUS_SENT_TO_CUSTOMER_NUM) || (moUtility.ToValue(status_info[clsRMA.STATUS_ID_COL, i]) == clsRMA.STATUS_SENT_TO_INVENTORY_NUM) || (moUtility.ToValue(status_info[clsRMA.STATUS_ID_COL, i]) == clsRMA.STATUS_REPAIR_COMPLETE_NUM))
                    {
                        item_list.Add(new clsComboBoxItem(status_info[clsRMA.STATUS_DESC_COL, i], status_info[clsRMA.STATUS_ID_COL, i]));
                    }
                }
                else
                {
                    item_list.Add(new clsComboBoxItem(status_info[clsRMA.STATUS_DESC_COL, i], status_info[clsRMA.STATUS_ID_COL, i]));
                }
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

        // Status info is from clsRMA.
        //
#if WEB
        public static void LoadRMAConditionalStatusID(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, int request_id)
        {
#else
        		public static void LoadRMAConditionalStatusID(ref ComboBox cur_box, int request_id)
        		{
#endif

            ArrayList item_list = new ArrayList();
            int i = 0;
            string[,] status_info = null;
            clsRMA o_rma = null;

#if WEB
            o_rma = new clsRMA(ref cur_db);
#else
        			o_rma = new clsRMA(goDatabase);
#endif

            if (!o_rma.GetStatusConditionalInfo(ref status_info, request_id))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            for (i = 0; i < status_info.GetLength(1); i++)
            {
                item_list.Add(new clsComboBoxItem(status_info[clsRMA.STATUS_DESC_COL, i], status_info[clsRMA.STATUS_ID_COL, i]));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadRMAItemCondition(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool exclude_good_condition_fl = false)
        {
#else
        		public static void LoadRMAItemCondition(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            int i = 0;
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT * FROM tblRMItemCondition ";

            if (exclude_good_condition_fl)
            {
                sql_str += " WHERE iGood_fl = 0";
            }

            sql_str += " ORDER BY sItemCondition_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            i = 0;
            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sItemCondition_cd") + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + cur_set.sField("sDescription"), cur_set.sField("sItemCondition_cd")));
                i = i + 1;
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadRMASolution(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadRMASolution(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            int i = 0;
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            // Create the list of cash account, income, and earning accts.
            // Only get the actual account type.
            //
            sql_str = "SELECT * FROM tblRMSolution ORDER BY sSolution_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            i = 0;
            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sSolution_cd")));
                i = i + 1;
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadWarehouse(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box) //, Optional ByVal clear_flag As Boolean = True)
        {
#else
        		public static void LoadWarehouse(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT * FROM tblIVLocation";
            sql_str += " ORDER BY sLocation_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            //If clear_flag Then
            //cur_box.DataSource = Nothing
            //End If

#if !WEB
        			item_list.Add(new clsComboBoxItem("", ""));
#endif

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sLocation_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sLocation_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadRepaishop(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadRepaishop(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT * FROM tblRMRepairshop";
            sql_str += " ORDER BY sShop_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }
            else if (cur_set.IsEmpty())
            {
                return;
            }

            cur_box.Clear();


            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sShop_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sShop_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadQueryTables(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_blank_line_fl = false)
        {
#else
        		public static void LoadQueryTables(ref ComboBox cur_box, bool add_blank_line_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            if (add_blank_line_fl)
            {
                item_list.Add(new clsComboBoxItem("", ""));
            }

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CASH_PAYMENT, "tblAPPayment"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CASH_RECEIPT, "tblARPayment"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CREDIT_MEMO, "tblARCharge"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CUSTOMER, "tblARCustomer"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DEBIT_MEMO, "tblAPCharge"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_EMPLOYEE, "tblGOEmployee"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ITEM, "tblIVItem"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ITEM_BIN, "tblIVItemQty"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_INVOICE, "tblARCharge ")); // Leave a space. Otherwise the List<clsComboBoxItem> behave wierdly because of the same value
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_LOCATION_BIN, "tblIVLocationBin"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_NSF, "tblARPayment ")); // Leave a space. Otherwise the List<clsComboBoxItem> behave wierdly because of the same value
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ORDER, "tblSOTransaction"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PROSPECT, "tblARProspect"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PURCHASE_ORDER, "tblPOTransaction"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_QUOTE, "tblSOTransaction ")); // Leave a space. Otherwise the List<clsComboBoxItem> behave wierdly because of the same value
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_STOP_PAYMENT, "tblAPPayment ")); // Leave a space. Otherwise the List<clsComboBoxItem> behave wierdly because of the same value
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_VENDOR, "tblAPVendor"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_VOUCHER, "tblAPCharge ")); // Leave a space. Otherwise the List<clsComboBoxItem> behave wierdly because of the same value

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadWorkOrderType(ref List<Models.clsCombobox> cur_box, bool jc_exist_fl)
        {
#else
        		public static void LoadWorkOrderType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_TO_GENERAL, Convert.ToString(GlobalVar.goWOConstant.WO_TO_GENERAL_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_TO_PURCHASE_INVENTORY, Convert.ToString(GlobalVar.goWOConstant.WO_TO_PURCHASE_INVENTORY_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_TO_PURCHASE_SUPPLY, Convert.ToString(GlobalVar.goWOConstant.WO_TO_PURCHASE_SUPPLY_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_TO_PRODUCTION, Convert.ToString(GlobalVar.goWOConstant.WO_TO_PRODUCTION_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_TO_SALES, Convert.ToString(GlobalVar.goWOConstant.WO_TO_SALES_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_TO_WAREHOUSE, Convert.ToString(GlobalVar.goWOConstant.WO_TO_WAREHOUSE_NUM)));
            //item_list.Add(New clsComboBoxItem(goWOConstant.WO_TO_ASSET, CStr(goWOConstant.WO_TO_ASSET_NUM)))  not any more 10/16/2017
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_TO_FACILITY, Convert.ToString(GlobalVar.goWOConstant.WO_TO_FACILITY_NUM)));

            if (jc_exist_fl)
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_TO_JOB_COST, Convert.ToString(GlobalVar.goWOConstant.WO_TO_JOB_COST_NUM)));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadWorkOrderStatus(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadWorkOrderStatus(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            int i = 0;

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_STATUS_OPEN, Convert.ToString(GlobalVar.goWOConstant.WO_STATUS_OPEN_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_STATUS_HOLD, Convert.ToString(GlobalVar.goWOConstant.WO_STATUS_HOLD_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_STATUS_CANCEL, Convert.ToString(GlobalVar.goWOConstant.WO_STATUS_CANCEL_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_STATUS_START, Convert.ToString(GlobalVar.goWOConstant.WO_STATUS_START_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_STATUS_FINISH, Convert.ToString(GlobalVar.goWOConstant.WO_STATUS_FINISH_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_STATUS_CONFIRMED, Convert.ToString(GlobalVar.goWOConstant.WO_STATUS_CONFIRMED_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadBOMCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadBOMCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sItem_cd FROM tblMFBOM";
            sql_str += " ORDER BY sItem_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();
            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(moUtility.STrim(cur_set.sField("sItem_cd"))))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sItem_cd").ToString(), cur_set.sField("sItem_cd").ToString()));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadBOMBaseCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadBOMCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sBase_cd FROM tblMFBOMBase";
            sql_str += " ORDER BY sBase_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(moUtility.STrim(cur_set.sField("sBase_cd"))))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sBase_cd").ToString(), cur_set.sField("sBase_cd").ToString()));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadKit(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadKit(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sItem_cd FROM tblIVItem";
            sql_str += " WHERE iKit_typ = " + GlobalVar.goIVConstant.PRE_ASSEMBLE_TYPE.ToString();
            sql_str += " ORDER BY sItem_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();
            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(moUtility.STrim(cur_set.sField("sItem_cd"))))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sItem_cd").ToString(), cur_set.sField("sItem_cd").ToString()));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadGLCustomReport(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadGLCustomReport(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            int i = 0;
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT * FROM tblGLReport ORDER BY sReport_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }
            else if (cur_set.IsEmpty())
            {
                return;
            }

            // A RIDICULUS  TRICK of VS2008/2010 ***************************************************************
            // (i * 1000) was introduced in order to make each item unique in Value property.                   
            // If more than one item has the same value, it always display the first item that matches the value.    
            //
            i = 0;
            while (!cur_set.EOF())
            {
                i += 1;
#if WEB
                item_list.Add(new clsComboBoxItem(cur_set.sField("sReport_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription").ToString(), (i * 1000 + cur_set.iField("iReport_typ")).ToString()));
#else
        				item_list.Add(new clsComboBoxItem((cur_set.sField("sReport_cd")) + GlobalVar.goConstant.ID_DELIMITER + (cur_set.sField("sDescription")), (cur_set.iField("iReport_typ")).ToString()));
#endif
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadCustomReportGroupType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCustomReportGroupType(ref clsDatabase cur_db, ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            clsCustomReport o_cr = new clsCustomReport(ref cur_db);

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_AVG, o_cr.uGLFinancial.FUNCTION_AVG_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_SUM, o_cr.uGLFinancial.FUNCTION_SUM_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_BEGINNING_BALANCE, o_cr.uGLFinancial.FUNCTION_BEGINNING_BALANCE_TYPE.ToString()));
            //item_list.Add(New clsComboBoxItem(goString.STR_ENDING_BALANCE, o_cr.uGLFinancial.FUNCTION_ENDING_BALANCE_TYPE.ToString()))

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadAmountToUse(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_blank_line_fl = false)
        {
#else
        		public static void LoadAmountToUse(ref ComboBox cur_box, bool add_blank_line_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            clsCustomReport o_cr = null;

#if WEB
            o_cr = new clsCustomReport(ref cur_db);
#else
        			o_cr = new clsCustomReport(goDatabase);
#endif

            cur_box.Clear();

            if (add_blank_line_fl)
            {
                item_list.Add(new clsComboBoxItem("", "0")); // Do not use "" for the value.
            }
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PERIODIC_NET, o_cr.uGLFinancial.AMOUNT_NET_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PERIODIC_CREDIT, o_cr.uGLFinancial.AMOUNT_CREDIT_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PERIODIC_DEBIT, o_cr.uGLFinancial.AMOUNT_DEBIT_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_BALANCE, o_cr.uGLFinancial.AMOUNT_BALANCE_TYPE.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadSalesTaxReportType(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadSalesTaxReportType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));

            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.TAX_CYCLE_MONTHLY, GlobalVar.goConstant.TAX_CYCLE_MONTHLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.TAX_CYCLE_QUARTERLY, GlobalVar.goConstant.TAX_CYCLE_QUARTERLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.TAX_CYCLE_SEMIYEARLY, GlobalVar.goConstant.TAX_CYCLE_SEMIYEARLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.TAX_CYCLE_YEARLY, GlobalVar.goConstant.TAX_CYCLE_YEARLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.TAX_CYCLE_OTHER, GlobalVar.goConstant.TAX_CYCLE_OTHER_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadSalesPurchaseTaxType(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadSalesPurchaseTaxType(ref ComboBox cur_box)
        		{
#endif

            int i = 0;
            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.TAX_SALES_TAX_TYPE, GlobalVar.goConstant.TAX_SALES_TAX_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.TAX_VAT_TYPE, GlobalVar.goConstant.TAX_VAT_TYPE_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }
        // Request info is from clsRMA.
        //
#if WEB
        public static void LoadRMAVendorRequestID(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadRMAVendorRequestID(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            int i = 0;
            string[,] request_info = null;
            clsRMA o_rma = null;

#if WEB
            o_rma = new clsRMA(ref cur_db);
#else
        			o_rma = new clsRMA(goDatabase);
#endif

            if (!o_rma.GetRequestFullInfo(ref request_info))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));

            for (i = 0; i < request_info.GetLength(1); i++)
            {
                if (moUtility.ToValue(request_info[clsRMA.REQUEST_ID_COL, i]) == clsRMA.REQUEST_REPAIR_NUM || moUtility.ToValue(request_info[clsRMA.REQUEST_ID_COL, i]) == clsRMA.REQUEST_EXCHANGE_NUM)
                {
                    item_list.Add(new clsComboBoxItem(request_info[clsRMA.REQUEST_DESC_COL, i], request_info[clsRMA.REQUEST_ID_COL, i]));
                }
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

        // Transaction status of Vendor RMA.
        //
#if WEB
        public static void LoadRMAVendorStatus(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_blank_fl = false)
        {
#else
        		public static void LoadRMAVendorStatus(ref ComboBox cur_box, bool add_blank_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            int i = 0;

            cur_box.Clear();

            if (add_blank_fl)
            {
                item_list.Add(new clsComboBoxItem("", "0"));
            }

            item_list.Add(new clsComboBoxItem(clsRMAVendor.TRX_OPEN, clsRMAVendor.TRX_OPEN_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(clsRMAVendor.TRX_HOLD, clsRMAVendor.TRX_HOLD_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(clsRMAVendor.TRX_VOID, clsRMAVendor.TRX_VOID_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(clsRMAVendor.TRX_SENT_TO_VENDOR, clsRMAVendor.TRX_SENT_TO_VENDOR_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(clsRMAVendor.TRX_RECEIVED, clsRMAVendor.TRX_RECEIVED_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadIncomeStatement(ref List<Models.clsCombobox> cur_box, bool add_mtd_ytd_fl = false)
        {
#else
        		public static void LoadIncomeStatement(ref ComboBox cur_box, bool add_mtd_ytd_fl = false)
        		{
#endif

            int i = 0;
            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("Year-To-Date", GlobalVar.goConstant.YEAR_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem("Quarterly", GlobalVar.goConstant.QUARTER_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem("Periodic", GlobalVar.goConstant.MONTH_TYPE.ToString()));

            if (add_mtd_ytd_fl)
            {
                item_list.Add(new clsComboBoxItem("MTD/YTD", GlobalVar.goConstant.MTD_YTD_TYPE.ToString()));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadQuarterlyPeriodEnd(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string fiscal_year, bool add_blank_fl = false)
        {
#else
        		public static void LoadQuarterlyPeriodEnd(ref ComboBox cur_box, string fiscal_year)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = modConstant.PERIODDET_DYNASET + " WHERE sFiscalYear = '" + fiscal_year + "' AND iQuarter_typ = 3 ORDER BY iPeriodEnd_dt DESC";
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                if (add_blank_fl)
                {
                    item_list.Add(new clsComboBoxItem("", ""));
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem("Qtr " + cur_set.iField("iQuarter"), cur_set.iField("iPeriodEnd_dt").ToString()));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                modGeneralUtility.MouseDefault();
                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadCashFlowGroup(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCashFlowGroup(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));
                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.CF_FINANCING_ACTIVITY, GlobalVar.goGLConstant.CF_FINANCING_ACTIVITY_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.CF_INVESTING_ACTIVITY, GlobalVar.goGLConstant.CF_INVESTING_ACTIVITY_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.CF_OPERATING_ACTIVITY, GlobalVar.goGLConstant.CF_OPERATING_ACTIVITY_NUM.ToString()));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadFundCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, int apply_date, int screen_type, bool add_blank_fl = true, bool add_organization_fl = false, bool add_organization_consolidated_fl = false, bool add_inter_fund_fl = false)
        {
#else
        		public static void LoadFundCode(ref ComboBox cur_box, int apply_date, int screen_type, bool add_blank_fl = true, bool add_organization_fl = false, bool add_organization_consolidated_fl = false, bool add_inter_fund_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string general_fund_code = "";
            clsFund o_fund = new clsFund();
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                general_fund_code = "";

                cur_box.Clear();

#if WEB
                if (!GlobalVar.goFund.GetFundRecordSet(ref cur_db, apply_date, ref cur_set, screen_type))
                {
                    return;
                }

                if (cur_db.bFundAccounting_fl)
                {

                    if (!GlobalVar.goFund.GetFundRecordSet(ref cur_db, apply_date, ref cur_set, screen_type))
                    {
                        return;
                    }
#else
        				if (!GlobalVar.goFund.GetFundRecordSet(goDatabase, apply_date, cur_set, screen_type))
        				{
        					return;
        				}

        				if (goDatabase.bFundAccounting_fl)
        				{

        					if (!GlobalVar.goFund.GetFundRecordSet(goDatabase, apply_date, cur_set, screen_type))
        					{
        						return;
        					}
#endif

                    if (screen_type == GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE)
                    {
                        item_list.Add(new clsComboBoxItem("", ""));
                        if (add_inter_fund_fl)
                        {
                            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_INTER_FUND, cur_db.oLanguage.oString.STR_INTER_FUND)); // This is used in lookup pages for search only
                        }
                        item_list.Add(new clsComboBoxItem(clsNPConstant.FUND_ORGANIZATION_CODE, clsNPConstant.FUND_ORGANIZATION_CODE)); // ASP has problem if two items have the same value. In this case, it is an empty string
                    }
                    else
                    {
                        if (add_blank_fl || cur_set.RecordCount() == 0)
                        {
                            item_list.Add(new clsComboBoxItem("", ""));
                        }
                        if (add_inter_fund_fl)
                        {
                            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_INTER_FUND, cur_db.oLanguage.oString.STR_INTER_FUND)); // This is used in lookup pages for search only
                        }
                        if (add_organization_fl)
                        {
                            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ORGANIZATION_SINGLE, cur_db.oLanguage.oString.STR_ORGANIZATION_SINGLE));
                        }
                        if (add_organization_consolidated_fl)
                        {
                            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ORGANIZATION_CONSOLIDATED, cur_db.oLanguage.oString.STR_ORGANIZATION_CONSOLIDATED));
                        }
                    }

                    while (!cur_set.EOF())
                    {
                        if (cur_set.iField("iGeneralFund_fl") == GlobalVar.goConstant.FLAG_ON)
                        {
                            general_fund_code = cur_set.sField("sFund_cd");
                        }
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sFund_cd"), cur_set.sField("sFund_cd")));
                        cur_set.MoveNext();
                    }

                }
                else
                {
                    item_list.Add(new clsComboBoxItem("", "")); // For commercial, to avoid potential problem with empty fund code.
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                //if (screen_type == GlobalVar.goConstant.TRANSACTION_SCREEN_TYPE && moUtility.IsNonEmpty(general_fund_code))
                //{
                //    //modCommonUtility.SetSelectedValue(ref cur_box, general_fund_code);
                //}
                //else if (cur_set.RecordCount() > 0)
                //{
                //    When a blank entry is entered, keep this
                //}

                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

        //#if WEB
        //        public static void LoadFundCodeToListbox(ref clsDatabase cur_db, ref ListBox cur_list)
        //        {
        //#else
        //        		public static void LoadFundCodeToListbox(ref ListBox cur_list)
        //        		{
        //#endif

        //            int i = 0;
        //            clsRecordset cur_set = null;
        //            clsGeneral o_gen = null;

        //#if WEB
        //            cur_set = new clsRecordset(ref cur_db);
        //            o_gen = new clsGeneral(ref cur_db);
        //#else
        //        			cur_set = new clsRecordset(goDatabase);
        //        			o_gen = new clsGeneral(goDatabase);
        //#endif

        //            try
        //            {

        //                cur_list.Items.Clear();

        //#if WEB
        //                if (!GlobalVar.goFund.GetFundRecordSet(ref cur_db, o_gen.CurrentDate(), ref cur_set, GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE))
        //                {
        //                    return;
        //                }
        //#else
        //        				if (!GlobalVar.goFund.GetFundRecordSet(goDatabase, o_gen.CurrentDate(), cur_set, GlobalVar.goConstant.MAINTENANCE_SCREEN_TYPE))
        //        				{
        //        					return;
        //        				}
        //#endif

        //                cur_list.Items.Add(clsNPConstant.FUND_ORGANIZATION_CODE + GlobalVar.goConstant.ID_DELIMITER + cur_db.oLanguage.oString.STR_ORGANIZATION_SINGLE);

        //                while (!cur_set.EOF())
        //                {
        //                    cur_list.Items.Add(cur_set.sField("sFund_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"));
        //                    cur_set.MoveNext();
        //                }

        //                cur_set.Release();
        //                return;

        //            }
        //            catch (Exception ex)
        //            {

        //            }

        //        }

#if WEB
        public static void LoadAllTransactionTypes(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_gl_journal_fl)
        {
#else
        		public static void LoadAllTransactionTypes(ref clsDatabase cur_db, ref ComboBox cur_box, bool add_gl_journal_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            clsRecordset cur_set = new clsRecordset(ref cur_db);
            string sql_str = "";

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));

            sql_str = "SELECT * FROM tblGONextTransactionNumber";
            sql_str += " WHERE iTransaction_typ >= 1000";
            sql_str += " AND iNext_num > 1";
            sql_str += " AND sDescription <> ''";
            if (!add_gl_journal_fl)
            {
                sql_str += " AND iTransaction_typ <> " + GlobalVar.goConstant.TRX_JOURNAL_TYPE.ToString();
            }
            sql_str += " ORDER BY sDescription";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {

                if (moUtility.SInStr(cur_set.sField("sDescription"), "Order") <= 0 && moUtility.SInStr(cur_set.sField("sDescription"), "Quote") <= 0 && moUtility.SInStr(cur_set.sField("sDescription"), "Reservation") <= 0 && moUtility.SInStr(cur_set.sField("sDescription"), "Requisition") <= 0 && moUtility.SInStr(cur_set.sField("sDescription"), "Slip") <= 0 && moUtility.SInStr(cur_set.sField("sDescription"), "Daily") <= 0)
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iTransaction_typ").ToString()));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            return;

            if (add_gl_journal_fl)
            {
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_JOURNAL, GlobalVar.goConstant.TRX_JOURNAL_TYPE.ToString()));
            }
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_INVOICE, GlobalVar.goConstant.TRX_INVOICE_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CM, GlobalVar.goConstant.TRX_CM_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CASH_RECEIPT, GlobalVar.goConstant.TRX_RECEIPT_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_NSF, GlobalVar.goConstant.TRX_NSF_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_VOUCHER, GlobalVar.goConstant.TRX_PURCHASE_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DM, GlobalVar.goConstant.TRX_DM_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PAYMENT, GlobalVar.goConstant.TRX_PAYMENT_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_STOP_PAYMENT, GlobalVar.goConstant.TRX_STOP_PAYMENT_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PAYROLL, GlobalVar.goConstant.TRX_PRJOURNAL_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.QE, GlobalVar.goConstant.TRX_EXPENSE_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.QI, GlobalVar.goConstant.TRX_INCOME_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_RENTAL, GlobalVar.goConstant.TRX_FA_RENTAL_TYPE.ToString()));

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PURCHASE, GlobalVar.goConstant.TRX_IV_PURCHASE_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PURCHASE + " " + cur_db.oLanguage.oString.STR_RETURN, GlobalVar.goConstant.TRX_IV_PURCHASE_RETURN_TYPE.ToString()));

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PURCHASE_ORDER, GlobalVar.goConstant.TRX_PO_TYPE.ToString())); // Encumbrance is created when P/O is saved.

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_SALES, GlobalVar.goConstant.TRX_IV_SALES_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_SALES + " " + cur_db.oLanguage.oString.STR_RETURN, GlobalVar.goConstant.TRX_IV_SALES_RETURN_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ADJUSTMENT, GlobalVar.goConstant.TRX_PHYSICAL_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_SPOILAGE, GlobalVar.goConstant.TRX_SPOILAGE_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DOMESTIC_USE, GlobalVar.goConstant.TRX_IV_INTERNAL_USE_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_TRANSFER + " " + cur_db.oLanguage.oString.STR_IN, GlobalVar.goConstant.TRX_TRANSFER_IN_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_TRANSFER, GlobalVar.goConstant.TRX_TRANSFER_TYPE.ToString()));

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_BANK + " " + cur_db.oLanguage.oString.STR_DEPOSIT, GlobalVar.goConstant.TRX_BR_DEPOSIT_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_BANK + " " + cur_db.oLanguage.oString.STR_WITHDRAWAL, GlobalVar.goConstant.TRX_BR_WITHDRAWAL_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_BANK + " " + cur_db.oLanguage.oString.STR_EXPENSE, GlobalVar.goConstant.TRX_BR_EXPENSE_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_BANK + " " + cur_db.oLanguage.oString.STR_INCOME, GlobalVar.goConstant.TRX_BR_INCOME_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_BANK + " " + cur_db.oLanguage.oString.STR_TRANSFER, GlobalVar.goConstant.TRX_BR_TRANSFER_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_BANK + " " + cur_db.oLanguage.oString.STR_DEPOSIT_SLIP, GlobalVar.goConstant.TRX_BR_DEPOSIT_SLIP_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DISBURSEMENT, GlobalVar.goConstant.TRX_BR_DISBURSEMENT_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_BANK + " F/C " + cur_db.oLanguage.oString.STR_DEPOSIT, GlobalVar.goConstant.TRX_BR_FOREIGN_DEPOSIT_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_BANK + " F/C " + cur_db.oLanguage.oString.STR_WITHDRAWAL, GlobalVar.goConstant.TRX_BR_FOREIGN_WITHDRAWAL_TYPE.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadFundStatusType(ref List<Models.clsCombobox> cur_box, bool add_blank_fl = false)
        {
#else
        		public static void LoadFundStatusType(ref ComboBox cur_box, bool add_blank_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

                if (add_blank_fl)
                {
                    item_list.Add(new clsComboBoxItem("", "0"));
                }

                item_list.Add(new clsComboBoxItem(GlobalVar.goNPConstant.FUND_STATUS_OPEN, GlobalVar.goNPConstant.FUND_STATUS_OPEN_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goNPConstant.FUND_STATUS_HOLD, GlobalVar.goNPConstant.FUND_STATUS_HOLD_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goNPConstant.FUND_STATUS_CANCELED, GlobalVar.goNPConstant.FUND_STATUS_CANCELED_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goNPConstant.FUND_STATUS_APPROVED, GlobalVar.goNPConstant.FUND_STATUS_APPROVED_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goNPConstant.FUND_STATUS_CLOSED, GlobalVar.goNPConstant.FUND_STATUS_CLOSED_NUM.ToString()));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadFundType(ref List<Models.clsCombobox> cur_box, bool add_blank_fl = false)
        {
#else
        		public static void LoadFundType(ref ComboBox cur_box, bool add_blank_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

                if (add_blank_fl)
                {
                    item_list.Add(new clsComboBoxItem("", "0"));
                }

                item_list.Add(new clsComboBoxItem(GlobalVar.goNPConstant.FUND_UNRESTRICTED_TYPE, GlobalVar.goNPConstant.FUND_UNRESTRICTED_TYPE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goNPConstant.FUND_TEMP_RESTRICTED_TYPE, GlobalVar.goNPConstant.FUND_TEMP_RESTRICTED_TYPE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goNPConstant.FUND_RESTRICTED_TYPE, GlobalVar.goNPConstant.FUND_RESTRICTED_TYPE_NUM.ToString()));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadListingRange(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadListingRange(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("All Entries", ""));
            item_list.Add(new clsComboBoxItem("Open Entries", "0"));
            item_list.Add(new clsComboBoxItem("Entries for last 30 days", "30"));
            item_list.Add(new clsComboBoxItem("Entries for last 60 days", "60"));
            item_list.Add(new clsComboBoxItem("Entries for last 90 days", "90"));
            item_list.Add(new clsComboBoxItem("Entries for last 120 days", "120"));
            item_list.Add(new clsComboBoxItem("Entries for last 1 year", "365"));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }

#if WEB
        public static void LoadProjectListingRange(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadProjectListingRange(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("All Entries", ""));
            item_list.Add(new clsComboBoxItem("Open Entries", "0"));
            item_list.Add(new clsComboBoxItem("Started within last 30 days", "30"));
            item_list.Add(new clsComboBoxItem("Started within last 60 days", "60"));
            item_list.Add(new clsComboBoxItem("Started within last 90 days", "90"));
            item_list.Add(new clsComboBoxItem("Started within last 120 days", "120"));
            item_list.Add(new clsComboBoxItem("Started within last 1 year", "365"));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadFundFinancialStatements(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadFundFinancialStatements(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem(GlobalVar.goNPConstant.STATEMENT_ACTIVITIES, GlobalVar.goNPConstant.STATEMENT_ACTIVITIES));
            item_list.Add(new clsComboBoxItem(GlobalVar.goNPConstant.STATEMENT_CASH_FLOW, GlobalVar.goNPConstant.STATEMENT_CASH_FLOW));
            item_list.Add(new clsComboBoxItem(GlobalVar.goNPConstant.STATEMENT_FINANCIAL_POSITION, GlobalVar.goNPConstant.STATEMENT_FINANCIAL_POSITION));
            item_list.Add(new clsComboBoxItem(GlobalVar.goNPConstant.STATEMENT_FUNCTIONAL_EXPENSES, GlobalVar.goNPConstant.STATEMENT_FUNCTIONAL_EXPENSES));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }

#if WEB
        public static void LoadFinancialStatements(ref List<Models.clsCombobox> cur_box, bool community_version = false)
        {
#else
        		public static void LoadFinancialStatements(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            if (community_version == false)
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.STATEMENT_CASH_FLOW, GlobalVar.goGLConstant.STATEMENT_CASH_FLOW));
            }
            item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.STATEMENT_INCOME, GlobalVar.goGLConstant.STATEMENT_INCOME));
            item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.STATEMENT_BALANCE_SHEET, GlobalVar.goGLConstant.STATEMENT_BALANCE_SHEET));
            item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.STATEMENT_COMPARATIVE_INCOME, GlobalVar.goGLConstant.STATEMENT_COMPARATIVE_INCOME));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }

#if WEB
        public static void LoadFundGroupCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadFundGroupCode(ref ComboBox cur_box, bool addnew_flag = true)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT sGroup_cd";
                sql_str += " FROM tblNPGroup";
                sql_str += " ORDER BY sGroup_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sGroup_cd"), cur_set.sField("sGroup_cd").ToString()));
                    cur_set.MoveNext();
                }

#if !WEB
        				if (addnew_flag)
        				{
        					item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ADDNEW, cur_db.oLanguage.oString.STR_ADDNEW));
        				}
#endif
                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadAccountingType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadAccountingType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.ACCRUAL_ACCOUNTING_TYPE, Convert.ToString(GlobalVar.goConstant.ACCRUAL_ACCOUNTING_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.CASH_ACCOUNTING_TYPE, Convert.ToString(GlobalVar.goConstant.CASH_ACCOUNTING_TYPE_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadAccountGroup(ref List<Models.clsCombobox> cur_box, bool add_blank_fl = true)
        {
#else
        		public static void LoadAccountGroup(ref ComboBox cur_box, bool add_blank_fl = true)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            if (add_blank_fl)
            {
                item_list.Add(new clsComboBoxItem("", "0"));
            }

            item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.ASSET_GROUP, GlobalVar.goGLConstant.ASSET_GROUP_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.LIABILITY_GROUP, GlobalVar.goGLConstant.LIABILITY_GROUP_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.EQUITY_GROUP, GlobalVar.goGLConstant.EQUITY_GROUP_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.REVENUE_GROUP, GlobalVar.goGLConstant.REVENUE_GROUP_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.EXPENSE_GROUP, GlobalVar.goGLConstant.EXPENSE_GROUP_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadAccountSubGroup(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, int group_type = 0, bool add_blank_fl = true, bool is_group_only = false)
        {
#else
        		public static void LoadAccountSubGroup(ref ComboBox cur_box, int group_type = 0, bool add_blank_fl = true)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string group_text = "";
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            if (add_blank_fl)
            {
                item_list.Add(new clsComboBoxItem("", ""));
            }

            if (group_type > 0)
            {
                sql_str = "SELECT * FROM tblGLAccountGroup WHERE iGroup_typ = " + (group_type / 1000).ToString() + " ORDER BY iAccount_typ";
            }
            else if (is_group_only)
            {
                sql_str = "SELECT * FROM tblGLAccountGroup WHERE iGroup_typ >= 4 ORDER BY iAccount_typ";
            }
            else
            {
                sql_str = "SELECT * FROM tblGLAccountGroup ORDER BY iAccount_typ";
            }
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                if ((cur_set.iField("iAccount_typ") % 100) > 0)
                {
                    group_text = cur_set.sField("sDescription");
                }
                else
                {
                    group_text = moUtility.SUCase(cur_set.sField("sDescription")); // Means top level summary group
                }
                item_list.Add(new clsComboBoxItem(group_text, cur_set.iField("iAccount_typ").ToString()));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadBudgetAccount(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string fund_code, bool add_blank_line_fl = true)
        {
#else
        		public static void LoadBudgetAccount(ref ComboBox cur_box, string fund_code, bool add_blank_line_fl = true)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string fiscal_year = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            fiscal_year = cur_db.sCurFiscalYear;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			fiscal_year = goDatabase.sCurFiscalYear;
#endif

            sql_str = "SELECT * FROM tblGLAccount WHERE sAccount_cd IN (SELECT sAccount_cd FROM tblGLBudgetDet ";
            sql_str += " WHERE sBudget_cd = '" + fiscal_year + "'";
            sql_str += " AND sFund_cd = '" + fund_code + "')"; // fund_code = '' means no-fund
            sql_str += " ORDER BY sAccount_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            if (add_blank_line_fl || cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem("", ""));
            }

            cur_box.Clear();

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sAccount_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sAccount_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadFOB(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadFOB(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "")); // Do not delete

            sql_str = "SELECT sFOB_cd, sDescription";
            sql_str += " FROM tblGOFOB ORDER BY sFOB_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sFOB_cd"), cur_set.sField("sFOB_cd")));
                cur_set.MoveNext();
            }

            cur_set.Release();

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }

#if WEB
        public static void LoadAPAgent(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool code_only = true)
        {
#else
        		public static void LoadAPAgent(ref ComboBox cur_box, bool code_only = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "")); // Do not delete

            sql_str = "SELECT * FROM tblAPAgent ORDER BY sAgent_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                if (!code_only && moUtility.IsNonEmpty(cur_set.sField("sDescription").ToString()))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sAgent_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sAgent_cd").ToString()));
                }
                else
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sAgent_cd"), cur_set.sField("sAgent_cd").ToString()));
                }
                cur_set.MoveNext();
            }

            cur_set.Release();

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }

#if WEB
        public static void LoadBankAccount(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool include_cash_acct_fl = false, bool include_foreign_bank_fl = false)
        {
#else
        		public static void LoadBankAccount(ref ComboBox cur_box, bool include_cash_acct_fl = false, bool include_foreign_bank_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string currency_cd = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            currency_cd = cur_db.sCurrency_cd;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			currency_cd = goDatabase.sCurrency_cd;
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            if (include_cash_acct_fl)
            {
                sql_str = "SELECT * FROM tblGLAccount WHERE iGroup_typ=" + GlobalVar.goGLConstant.PETTY_CASH_NUM.ToString() + " AND iSummary_typ=" + GlobalVar.goGLConstant.ACTUAL_TYPE_NUM.ToString();
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }
                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sAccount_cd")));
                    cur_set.MoveNext();
                }
            }

            //  DO NOT USE cur_db.uProgram.bBRExist_fl for condition.
            //  Some users may keep the bank account even after B/R is turned off.
            //
            sql_str = "SELECT sBank_cd, sBank_nm, sGLAcct_cd FROM tblBRBankAccount ";
            if (include_foreign_bank_fl == false && moUtility.IsNonEmpty(currency_cd))
            {
                sql_str += " WHERE (sCurrency_cd = '" + currency_cd + "' OR sCurrency_cd= '' OR sCurrency_cd IS NULL)";
            }
            sql_str += " ORDER BY sBank_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            if (cur_set.EOF() == false)
            {
                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sBank_cd"), cur_set.sField("sGLAcct_cd")));
                    cur_set.MoveNext();
                }
            }
            else
            {
                sql_str = "SELECT * FROM tblGLAccount WHERE iGroup_typ=" + GlobalVar.goGLConstant.CHECK_CASH_NUM.ToString();
                sql_str += " AND iSummary_typ=" + GlobalVar.goGLConstant.ACTUAL_TYPE_NUM.ToString();
                sql_str += " ORDER BY sAccount_cd";
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }
                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sAccount_cd")));
                    cur_set.MoveNext();
                }
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadVendorDunnCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadVendorDunnCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT sDunn_cd FROM tblAPDunn";
                sql_str += " ORDER BY sDunn_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                while (!cur_set.EOF())
                {

                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDunn_cd"), cur_set.sField("sDunn_cd")));
                    cur_set.MoveNext();

                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadCustomerDunnCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCustomerDunnCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT sDunn_cd FROM tblARDunn";
                sql_str += " ORDER BY sDunn_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                while (!cur_set.EOF())
                {

                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDunn_cd"), cur_set.sField("sDunn_cd")));
                    cur_set.MoveNext();

                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadCreditCardAccount(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool include_cash_acct_fl = false)
        {
#else
        		public static void LoadCreditCardAccount(ref ComboBox cur_box, bool include_cash_acct_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string cash_acct = "";
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif


            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            if (include_cash_acct_fl)
            {
                sql_str = "SELECT sAccount_cd FROM tblGLAccount WHERE iGroup_typ=" + GlobalVar.goGLConstant.PETTY_CASH_NUM.ToString() + " AND iSummary_typ=" + GlobalVar.goGLConstant.ACTUAL_TYPE_NUM.ToString();
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }
                else if (cur_set.IsEmpty())
                {
                    return;
                }
                cash_acct = cur_set.sField("sAccount_cd");
                cur_set.Release();

                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.PETTY_CASH, cash_acct));
            }

            sql_str = "SELECT sCard_cd, sGLAcct_cd FROM tblBRCreditCard ORDER BY sCard_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sCard_cd"), cur_set.sField("sGLAcct_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadCreditCardCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCreditCardCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sCard_cd, sGLAcct_cd FROM tblBRCreditCard ORDER BY sCard_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sCard_cd"), cur_set.sField("sCard_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadCreditCardChargeType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCreditCardChargeType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_INTEREST_CHARGE, GlobalVar.goConstant.TRX_BR_CARD_INTEREST_CHARGE_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_LATE_CHARGE, GlobalVar.goConstant.TRX_BR_CARD_LATE_CHARGE_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_MEMBERSHIP_FEE, GlobalVar.goConstant.TRX_BR_CARD_MEMBERSHIP_FEE_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_OVERLIMIT_CHARGE, GlobalVar.goConstant.TRX_BR_CARD_OVERLIMIT_CHARGE_TYPE.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadVendor(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool active_only)
        {
#else
        		public static void LoadVendor(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sVendor_cd, sVendor_nm FROM tblAPVendor";

            if (active_only)
            {
                sql_str += " WHERE (iStatus_typ = " + GlobalVar.goAPConstant.ACTIVE_VENDOR_NUM. ToString() + " OR iStatus_typ = " + GlobalVar.goAPConstant.PROSPECTIVE_VENDOR_NUM.ToString() + ")";
            }

            sql_str += " ORDER BY sVendor_nm";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                item_list.Add(new clsComboBoxItem(cur_set.sField("sVendor_cd") + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + cur_set.sField("sVendor_nm"), cur_set.sField("sVendor_cd")));
                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadVendorPayTo(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string vendor_code)
        {
#else
        		public static void LoadVendorPayTo(ref ComboBox cur_box, string vendor_code)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sVendor_cd, sVendor_nm FROM tblAPVendor ";
            sql_str += " WHERE sVendor_cd = '" + vendor_code + "'";
            sql_str += " OR sVendor_cd = ( SELECT sPayTo_cd FROM tblAPVendor WHERE sVendor_cd = '" + vendor_code + "' )";
            sql_str += " ORDER BY sVendor_nm";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sVendor_nm"), cur_set.sField("sVendor_cd").ToString()));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadQuickExpenseType(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadQuickExpenseType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));
                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.QUICK_EXPENSE_GENERAL_TYPE, GlobalVar.goGLConstant.QUICK_EXPENSE_GENERAL_TYPE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.QUICK_EXPENSE_UTILITY_TYPE, GlobalVar.goGLConstant.QUICK_EXPENSE_UTILITY_TYPE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.QUICK_EXPENSE_EMPLOYEE_TYPE, GlobalVar.goGLConstant.QUICK_EXPENSE_EMPLOYEE_TYPE_NUM.ToString()));

                // These are platinum version
#if WEB || PL
                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.QUICK_EXPENSE_FA_INSURANCE_TYPE, GlobalVar.goGLConstant.QUICK_EXPENSE_FA_INSURANCE_TYPE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.QUICK_EXPENSE_FA_PAYMENT_TYPE, GlobalVar.goGLConstant.QUICK_EXPENSE_FA_PAYMENT_TYPE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.QUICK_EXPENSE_FA_SERVICE_TYPE, GlobalVar.goGLConstant.QUICK_EXPENSE_FA_SERVICE_TYPE_NUM.ToString()));

                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.QUICK_EXPENSE_INTERNAL_SALE_COST_TYPE, GlobalVar.goGLConstant.QUICK_EXPENSE_INTERNAL_SALE_COST_TYPE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.QUICK_EXPENSE_INTERNAL_PURCHASE_COST_TYPE, GlobalVar.goGLConstant.QUICK_EXPENSE_INTERNAL_PURCHASE_COST_TYPE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.QUICK_EXPENSE_INTERNAL_CONSIGNMENT_COST_TYPE, GlobalVar.goGLConstant.QUICK_EXPENSE_INTERNAL_CONSIGNMENT_COST_TYPE_NUM.ToString()));
                
#endif

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadGeneralPaymentFrequency(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadGeneralPaymentFrequency(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.PAYMENT_FREQUENCY_WEEKLY, GlobalVar.goConstant.PAYMENT_FREQUENCY_WEEKLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.PAYMENT_FREQUENCY_BIWEEKLY, GlobalVar.goConstant.PAYMENT_FREQUENCY_BIWEEKLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.PAYMENT_FREQUENCY_SEMIMONTHLY, GlobalVar.goConstant.PAYMENT_FREQUENCY_SEMIMONTHLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.PAYMENT_FREQUENCY_MONTHLY, GlobalVar.goConstant.PAYMENT_FREQUENCY_MONTHLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.PAYMENT_FREQUENCY_BIMONTHLY, GlobalVar.goConstant.PAYMENT_FREQUENCY_BIMONTHLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.PAYMENT_FREQUENCY_QUARTERLY, GlobalVar.goConstant.PAYMENT_FREQUENCY_QUARTERLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.PAYMENT_FREQUENCY_SEMIYEARLY, GlobalVar.goConstant.PAYMENT_FREQUENCY_SEMIYEARLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.PAYMENT_FREQUENCY_YEARLY, GlobalVar.goConstant.PAYMENT_FREQUENCY_YEARLY_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadDynastyVersion(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadDynastyVersion(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.DYMENU_CAPTION, GlobalVar.goConstant.DYMENU_NAME));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.GOMENU_CAPTION, GlobalVar.goConstant.GOMENU_NAME));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.ENMENU_CAPTION, GlobalVar.goConstant.ENMENU_NAME));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.PLMENU_CAPTION, GlobalVar.goConstant.PLMENU_NAME));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.SSMENU_CAPTION, GlobalVar.goConstant.SSMENU_NAME));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
        }

#if WEB
        public static void LoadVerticalMarketID(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadVerticalMarketID(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_GENERAL, "0"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_RENTAL, GlobalVar.goConstant.VM_MENU_ID_RENTAL.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_NON_PROFIT, GlobalVar.goConstant.VM_MENU_ID_NP.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadLogTransaction(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_all_fl = false, bool add_login_history_fl = false, bool batch_only = false)
        {
#else
        		public static void LoadLogTransaction(ref ComboBox cur_box, bool add_all_fl = false, bool add_login_history_fl = false, bool batch_only = false)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0")); // Do not use "" for the value.

            if (add_all_fl)
            {
                item_list.Add(new clsComboBoxItem(moUtility.SUCase(cur_db.oLanguage.oString.STR_ALL), cur_db.oLanguage.oString.STR_ALL)); // Use this only for the reports
            }

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CASH_PAYMENT, GlobalVar.goConstant.TRX_PAYMENT_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CASH_RECEIPT, GlobalVar.goConstant.TRX_RECEIPT_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CREDIT_MEMO, GlobalVar.goConstant.TRX_CM_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DEBIT_MEMO, GlobalVar.goConstant.TRX_DM_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_INVOICE, GlobalVar.goConstant.TRX_INVOICE_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_JOURNAL, GlobalVar.goConstant.TRX_JOURNAL_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_NSF, GlobalVar.goConstant.TRX_NSF_TYPE.ToString()));
            if (batch_only == false)
            {
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ORDER, GlobalVar.goConstant.TRX_SO_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PAYROLL + " " + cur_db.oLanguage.oString.STR_JOURNAL, GlobalVar.goConstant.TRX_PRJOURNAL_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PURCHASE_ORDER, GlobalVar.goConstant.TRX_PO_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PURCHASE_QUOTE, GlobalVar.goConstant.TRX_PO_QUOTE_TYPE.ToString()));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_QUOTE, GlobalVar.goConstant.TRX_QUOTE_TYPE.ToString()));
            }
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_STOP_PAYMENT, GlobalVar.goConstant.TRX_STOP_PAYMENT_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_VOUCHER, GlobalVar.goConstant.TRX_PURCHASE_TYPE.ToString()));

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.BANK + " " + cur_db.oLanguage.oCaption.FEE_MISC_CHARGE, GlobalVar.goConstant.TRX_BR_EXPENSE_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.BANK + " " + cur_db.oLanguage.oCaption.INTEREST_MISC_EARNING, GlobalVar.goConstant.TRX_BR_INCOME_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.BANK + " " + cur_db.oLanguage.oCaption.DEPOSIT, GlobalVar.goConstant.TRX_BR_FOREIGN_DEPOSIT_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.BANK + " " + cur_db.oLanguage.oCaption.WITHDRAWAL, GlobalVar.goConstant.TRX_BR_FOREIGN_WITHDRAWAL_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.BANK + " " + cur_db.oLanguage.oCaption.TRANSFER, GlobalVar.goConstant.TRX_BR_TRANSFER_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.BANK + " " + cur_db.oLanguage.oCaption.DAILY_DEPOSIT_SLIP, GlobalVar.goConstant.TRX_BR_DEPOSIT_SLIP_TYPE.ToString()));

            if (add_login_history_fl)
            {
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_LOGIN_HISTORY, cur_db.oLanguage.oString.STR_LOGIN_HISTORY));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PAGES_VISITED, cur_db.oLanguage.oString.STR_PAGES_VISITED));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadEmployee(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string department_cd = "", bool show_staff_fl = false, bool show_name_code_fl = false)
        {
#else
        		public static void LoadEmployee(ref ComboBox cur_box, string department_cd = "", bool show_staff_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string employee_cd = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            employee_cd = cur_db.sEmployee_cd;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			employee_cd = goDatabase.sEmployee_cd;
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            if (show_staff_fl && moUtility.IsEmpty(employee_cd))
            {
                // Get no one
            }
            else
            {

                sql_str = "SELECT * FROM tblGOEmployee";
                if (show_staff_fl)
                {
                    sql_str += " WHERE sDept_cd IN (SELECT sDepartment_cd FROM tblPRDepartment WHERE sManager_cd = '" + employee_cd + "')";
                }
                else if (moUtility.IsNonEmpty(department_cd))
                {
                    sql_str += " WHERE sDept_cd = '" + department_cd + "'";
                }
                sql_str += " ORDER BY sEmployee_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    if (show_name_code_fl)
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sEmployee_cd") + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + cur_set.sField("sEmployee_nm"), cur_set.sField("sEmployee_cd")));
                    }
                    else
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sEmployee_nm"), cur_set.sField("sEmployee_cd")));
                    }
                    cur_set.MoveNext();
                }

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();
            return;

        }

#if WEB
        public static void LoadPeriodBegin(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string fiscal_year = "", bool ascending_order_fl = false, bool add_blank_fl = false)
        {
#else
        		public static void LoadPeriodBegin(ref ComboBox cur_box, string fiscal_year = "", bool ascending_order_fl = false, bool add_blank_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = modConstant.PERIODDET_DYNASET;
                if (moUtility.IsNonEmpty(fiscal_year))
                {
                    sql_str += " WHERE sFiscalYear = '" + fiscal_year + "'";
                }
                else
                {
                    sql_str += " WHERE iPeriodBegin_dt <=" + o_gen.CurrentDate().ToString();
                }
                sql_str += " ORDER BY iPeriodBegin_dt";
                if (!ascending_order_fl)
                {
                    sql_str += " DESC";
                }
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                if (add_blank_fl)
                {
                    item_list.Add(new clsComboBoxItem("", "0"));
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(o_gen.ToStrDate(cur_set.iField("iPeriodBegin_dt")), cur_set.iField("iPeriodBegin_dt").ToString()));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadPeriodEnd(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string fiscal_year = "", bool ascending_order_fl = false, bool add_blank_fl = false)
        {
#else
        		public static void LoadPeriodEnd(ref ComboBox cur_box, string fiscal_year = "", bool ascending_order_fl = false, bool add_blank_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            int period_end = 0;
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            period_end = cur_db.iCurPeriodEnd_dt;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			period_end = goDatabase.iCurPeriodEnd_dt;
#endif

            try
            {

                sql_str = modConstant.PERIODDET_DYNASET;
                if (moUtility.IsNonEmpty(fiscal_year))
                {
                    sql_str += " WHERE sFiscalYear = '" + fiscal_year + "'";
                }
                else
                {
                    sql_str += " WHERE iPeriodBegin_dt <=" + moUtility.AddToDate(GlobalVar.goConstant.MONTH_TYPE, period_end, 3).ToString();
                }
                sql_str += " ORDER BY iPeriodBegin_dt ";
                if (!ascending_order_fl)
                {
                    sql_str += " DESC";
                }
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                if (add_blank_fl)
                {
                    item_list.Add(new clsComboBoxItem("", ""));
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(o_gen.ToStrDate(cur_set.iField("iPeriodEnd_dt")), cur_set.iField("iPeriodEnd_dt").ToString()));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                return;

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadOrderTypes(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadOrderTypes(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goSOConstant.REGULAR_ORDER_TYPE, Convert.ToString(GlobalVar.goSOConstant.REGULAR_ORDER_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goSOConstant.BLANKET_ORDER_BY_QTY_TYPE, Convert.ToString(GlobalVar.goSOConstant.BLANKET_ORDER_BY_QTY_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goSOConstant.BLANKET_ORDER_BY_AMOUNT_TYPE, Convert.ToString(GlobalVar.goSOConstant.BLANKET_ORDER_BY_AMOUNT_TYPE_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goSOConstant.BLANKET_ORDER_BY_BOTH_TYPE, Convert.ToString(GlobalVar.goSOConstant.BLANKET_ORDER_BY_BOTH_TYPE_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadARChargeTypes(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_blank_fl = false)
        {
#else
        		public static void LoadARChargeTypes(ref ComboBox cur_box, bool add_blank_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            if (add_blank_fl)
            {
                item_list.Add(new clsComboBoxItem("", "0"));
            }

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_INVOICE, GlobalVar.goConstant.TRX_INVOICE_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CREDIT_MEMO, GlobalVar.goConstant.TRX_CM_TYPE.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }

#if WEB
        public static void LoadARReceiptTypes(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_blank_fl = false, bool add_deposit_fl = false)
        {
#else
        		public static void LoadARReceiptTypes(ref ComboBox cur_box, bool add_blank_fl = false, bool add_deposit_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            if (add_blank_fl)
            {
                item_list.Add(new clsComboBoxItem("", ""));
            }

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CASH_RECEIPT, GlobalVar.goConstant.TRX_RECEIPT_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_NSF, GlobalVar.goConstant.TRX_NSF_TYPE.ToString()));

            if (add_deposit_fl)
            {
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DEPOSIT, "1"));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }

#if WEB
        public static void LoadAPChargeTypes(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_blank_fl = false)
        {
#else
        		public static void LoadAPChargeTypes(ref ComboBox cur_box, bool add_blank_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            if (add_blank_fl)
            {
                item_list.Add(new clsComboBoxItem("", ""));
            }

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_VOUCHER, GlobalVar.goConstant.TRX_PURCHASE_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DEBIT_MEMO, GlobalVar.goConstant.TRX_DM_TYPE.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }

#if WEB
        public static void LoadAPPaymentTypes(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_blank_fl = false, bool add_deposit_fl = false)
        {
#else
        		public static void LoadAPPaymentTypes(ref ComboBox cur_box, bool add_blank_fl = false, bool add_deposit_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            if (add_blank_fl)
            {
                item_list.Add(new clsComboBoxItem("", ""));
            }

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CASH_PAYMENT, GlobalVar.goConstant.TRX_PAYMENT_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_STOP_PAYMENT, GlobalVar.goConstant.TRX_STOP_PAYMENT_TYPE.ToString()));

            if (add_deposit_fl)
            {
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DEPOSIT, "1"));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }

#if WEB
        public static void LoadOverDueDays(ref List<Models.clsCombobox> cur_box, bool add_future_due = false)
        {
#else
        		public static void LoadOverDueDays(ref ComboBox cur_box, bool add_future_due = false)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("All Outstanding", "")); //This has to have Value = "", not 0.
            item_list.Add(new clsComboBoxItem("Due Today Only", "0"));
            item_list.Add(new clsComboBoxItem("All Over-due", "1"));
            item_list.Add(new clsComboBoxItem("Over 30 days", "30"));
            item_list.Add(new clsComboBoxItem("Over 60 days", "60"));
            item_list.Add(new clsComboBoxItem("Over 90 days", "90"));
            item_list.Add(new clsComboBoxItem("Over 120 days", "120"));
            item_list.Add(new clsComboBoxItem("Over 150 days", "150"));
            item_list.Add(new clsComboBoxItem("Over 180 days", "180"));
            if (add_future_due)
            {
                item_list.Add(new clsComboBoxItem("-", ""));
                item_list.Add(new clsComboBoxItem("Due next week", "-7"));
                item_list.Add(new clsComboBoxItem("Due in next 2 weeks", "-14"));
                item_list.Add(new clsComboBoxItem("Due next month", "-30"));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }


#if WEB
        public static void LoadComparisonTextOperators(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool all_flag)
        {
#else
        		public static void LoadComparisonTextOperators(ref ComboBox cur_box, bool all_flag)
        		{
#endif

            ArrayList item_list = new ArrayList();


            if (all_flag)
            {
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oMessage.OPERATOR_BETWEEN, cur_db.oLanguage.oMessage.OPERATOR_BETWEEN));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oMessage.OPERATOR_EQUAL_TO, "="));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oMessage.OPERATOR_NOT_EQUAL_TO, "<>"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oMessage.OPERATOR_LESS_THAN, "<"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oMessage.OPERATOR_LESS_THAN_OR_EQUAL_TO, "<="));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oMessage.OPERATOR_GREATER_THAN, ">"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oMessage.OPERATOR_GREATER_THAN_OR_EQUAL_TO, ">="));
            }
            else
            {
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oMessage.OPERATOR_EQUAL_TO, "="));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oMessage.OPERATOR_NOT_EQUAL_TO, "<>"));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }
#if WEB
        public static void LoadComparisonOperators(ref List<Models.clsCombobox> cur_box, bool all_flag = true, bool add_between_fl = false, bool add_like_fl = false)
        {
#else
        		public static void LoadComparisonOperators(ref ComboBox cur_box, bool all_flag, bool add_between_fl = false, bool add_like_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            if (all_flag)
            {
                item_list.Add(new clsComboBoxItem("<", "<"));
                item_list.Add(new clsComboBoxItem("<=", "<="));
                item_list.Add(new clsComboBoxItem("=", "="));
                item_list.Add(new clsComboBoxItem(">", ">"));
                item_list.Add(new clsComboBoxItem(">=", ">="));
                item_list.Add(new clsComboBoxItem("<>", "<>"));
            }
            else
            {
                item_list.Add(new clsComboBoxItem("=", "="));
                item_list.Add(new clsComboBoxItem("<>", "<>"));
            }

            if (add_between_fl)
            {
                item_list.Add(new clsComboBoxItem("BETWEEN", " BETWEEN "));
            }
            if (add_like_fl)
            {
                item_list.Add(new clsComboBoxItem("LIKE", " LIKE "));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }

#if WEB
        public static void LoadIVActivityAnalysisType(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadIVActivityAnalysisType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goIVConstant.ANALYSIS_SALES_BY_CUSTOER, GlobalVar.goIVConstant.ANALYSIS_SALES_BY_CUSTOER));
            item_list.Add(new clsComboBoxItem(GlobalVar.goIVConstant.ANALYSIS_SALES_BY_SALESPERSON, GlobalVar.goIVConstant.ANALYSIS_SALES_BY_SALESPERSON));
            item_list.Add(new clsComboBoxItem(GlobalVar.goIVConstant.ANALYSIS_PURCHASE_BY_VENDOR, GlobalVar.goIVConstant.ANALYSIS_PURCHASE_BY_VENDOR));
            item_list.Add(new clsComboBoxItem(GlobalVar.goIVConstant.ANALYSIS_PURCHASE_BY_AGENT, GlobalVar.goIVConstant.ANALYSIS_PURCHASE_BY_AGENT));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }

#if WEB
        public static void LoadFiscalQuarters(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool ascending_order_fl = false, bool add_blank_fl = false, bool current_year_only = false)
        {
#else
        		public static void LoadFiscalQuarters(ref ComboBox cur_box, bool ascending_order_fl = false, bool add_blank_fl = false, bool current_year_only = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            int qtr = 0;
            string sql_str = "";
            string fiscal_year = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            fiscal_year = cur_db.sCurFiscalYear;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			fiscal_year = goDatabase.sCurFiscalYear;
#endif

            try
            {

                sql_str = "SELECT * FROM tblGLPeriodDet WHERE iQuarter_typ = 1";
                if (current_year_only)
                {
                    sql_str += " AND sFiscalYear = '" + fiscal_year + "'";
                }
                sql_str += " ORDER BY iPeriodBegin_dt";
                if (!ascending_order_fl)
                {
                    sql_str += " DESC";
                }
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                if (add_blank_fl)
                {
                    item_list.Add(new clsComboBoxItem("", ""));
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.iField("iQuarter") + " / " + cur_set.sField("sFiscalYear"), cur_set.sField("sFiscalYear").ToString() + cur_set.iField("iQuarter").ToString()));
                    if (cur_set.iField("iPeriodEnd_dt") >= o_gen.CurrentDate() && cur_set.iField("iPeriodBegin_dt") <= o_gen.CurrentDate())
                    {
                        fiscal_year = cur_set.sField("sFiscalYear");
                        qtr = cur_set.iField("iQuarter");
                    }
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                modGeneralUtility.MouseDefault();
                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

                cur_set.Release();
                modGeneralUtility.MouseDefault();
                return;

            }

        }

#if WEB
        public static void LoadCalendarWeeks(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool ascending_order_fl = false, bool add_dates_fl = false)
        {
#else
        		public static void LoadCalendarWeeks(ref ComboBox cur_box, bool ascending_order_fl = false, bool add_dates_fl = false, bool add_blank_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string box_text = "";
            int week_num = 0;
            int week_start = 0;
            int week_end = 0;
            int year_begin = 0;
            int year_end = 0;
            string sql_str = "";
            int fiscal_year = 0;
            string last_year = "";

            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            fiscal_year = moUtility.ToInteger(cur_db.sCurFiscalYear);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
                    fiscal_year = goUtility.ToInteger(goDatabase.sCurFiscalYear);
#endif

            try
            {

                cur_box.Clear();

#if WEB
                item_list.Add(new clsComboBoxItem("", ""));
#else
        				if (add_blank_fl)
        				{
        					item_list.Add(new clsComboBoxItem("", ""));
        				}
#endif

                sql_str = "SELECT * FROM tblGLPeriodDet";
                sql_str += " WHERE sFiscalYear = '" + fiscal_year.ToString() + "'";
                sql_str += " ORDER BY iPeriodBegin_dt";
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                if (!cur_set.EOF())
                {

                    year_begin = cur_set.iField("iPeriodBegin_dt");
                    cur_set.MoveLast();
                    year_end = cur_set.iField("iPeriodEnd_dt");

                    week_start = year_begin;
                    week_end = moUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, week_start, 6);
                    week_num = 1;

                    while (week_start < year_end)
                    {
                        if (week_end + 3 > year_end) // If this is the ending week.
                        {
                            week_end = year_end;
                        }

                        box_text = week_num + " / " + cur_set.sField("sFiscalYear");
                        if (add_dates_fl)
                        {
                            box_text = moUtility.SReplace(box_text, " ", ""); // DO NOT CHANGE THE FORMAT
                            box_text += " (" + moUtility.SLeft(o_gen.ToStrDate(week_start), 5) + "~" + o_gen.ToStrDate(week_end) + ")";
                        }
                        item_list.Add(new clsComboBoxItem(box_text, cur_set.sField("sFiscalYear") + moUtility.SRight(" " + week_num.ToString(), 2)));

                        week_start = moUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, week_start, 7);
                        week_end = moUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, week_end, 7);
                        week_num += 1;
                    }

                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


                modGeneralUtility.MouseDefault();
                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

                cur_set.Release();
                modGeneralUtility.MouseDefault();
                return;

            }

        }

#if WEB
        public static void LoadConsecutiveNumbers(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, int total_numbers, int starting_from = 1, int incremental_step = 1, bool ascending_order_fl = true, bool add_blank_fl = false)
        {
#else
        		public static void LoadConsecutiveNumbers(ref ComboBox cur_box, int total_numbers, int starting_from = 1, int incremental_step = 1, bool ascending_order_fl = true, bool add_blank_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string box_text = "";
            int i = 0;
            int first_num = 0;
            int last_num = 0;

            try
            {

                cur_box.Clear();

                if (add_blank_fl)
                {
                    item_list.Add(new clsComboBoxItem("", ""));
                }

                if (ascending_order_fl)
                {
                    first_num = starting_from;
                    last_num = (starting_from + total_numbers * incremental_step - 1);
                }
                else
                {
                    first_num = (starting_from + total_numbers * incremental_step - 1);
                    last_num = starting_from;
                    starting_from = -starting_from;
                }

                for (i = first_num; i <= last_num; i += starting_from)
                {
                    item_list.Add(new clsComboBoxItem(i.ToString(), i.ToString()));
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


                return;

            }
            catch (Exception ex)
            {

                modGeneralUtility.MouseDefault();
                return;

            }

        }

#if WEB
        public static void LoadARInterestGroup(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "")
        {
#else
        		public static void LoadARInterestGroup(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string user_id = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            user_id = cur_db.sUser_cd;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			user_id = goDatabase.sUser_cd;
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sInterestGroup_cd FROM tblARInterestGroup WHERE iOpenToPublic_fl = 1 OR sUser_cd = '" + user_id + "'";
            sql_str += " ORDER BY sInterestGroup_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sInterestGroup_cd").ToString(), cur_set.sField("sInterestGroup_cd").ToString()));
                cur_set.MoveNext();
            }

            if (moUtility.IsNonEmpty(additional_item))
            {
                item_list.Add(new clsComboBoxItem(additional_item, additional_item));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadAPInterestGroup(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "")
        {
#else
        		public static void LoadAPInterestGroup(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string user_id = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            user_id = cur_db.sUser_cd;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			user_id = goDatabase.sUser_cd;
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sInterestGroup_cd FROM tblAPInterestGroup WHERE iOpenToPublic_fl = 1 OR sUser_cd = '" + user_id + "'";
            sql_str += " ORDER BY sInterestGroup_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sInterestGroup_cd").ToString(), cur_set.sField("sInterestGroup_cd").ToString()));
                cur_set.MoveNext();
            }

            if (moUtility.IsNonEmpty(additional_item))
            {
                item_list.Add(new clsComboBoxItem(additional_item, additional_item));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadIVInterestGroup(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "")
        {
#else
        		public static void LoadIVInterestGroup(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string user_id = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            user_id = cur_db.sUser_cd;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			user_id = goDatabase.sUser_cd;
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sInterestGroup_cd FROM tblIVInterestGroup WHERE iOpenToPublic_fl = 1 OR sUser_cd = '" + user_id + "'";
            sql_str += " ORDER BY sInterestGroup_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sInterestGroup_cd").ToString(), cur_set.sField("sInterestGroup_cd").ToString()));
                cur_set.MoveNext();
            }

            if (moUtility.IsNonEmpty(additional_item))
            {
                item_list.Add(new clsComboBoxItem(additional_item, additional_item));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadPRInterestGroup(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "")
        {
#else
        		public static void LoadPRInterestGroup(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string user_id = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            user_id = cur_db.sUser_cd;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			user_id = goDatabase.sUser_cd;
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sInterestGroup_cd FROM tblPRInterestGroup WHERE iOpenToPublic_fl = 1 OR sUser_cd = '" + user_id + "'";
            sql_str += " ORDER BY sInterestGroup_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sInterestGroup_cd").ToString(), cur_set.sField("sInterestGroup_cd").ToString()));
                cur_set.MoveNext();
            }

            if (moUtility.IsNonEmpty(additional_item))
            {
                item_list.Add(new clsComboBoxItem(additional_item, additional_item));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadGLInterestGroup(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "")
        {
#else
        		public static void LoadGLInterestGroup(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string user_id = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            user_id = cur_db.sUser_cd;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			user_id = goDatabase.sUser_cd;
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sInterestGroup_cd FROM tblGLInterestGroup WHERE iOpenToPublic_fl = 1 OR sUser_cd = '" + user_id + "'";
            sql_str += " ORDER BY sInterestGroup_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sInterestGroup_cd").ToString(), cur_set.sField("sInterestGroup_cd").ToString()));
                cur_set.MoveNext();
            }

            if (moUtility.IsNonEmpty(additional_item))
            {
                item_list.Add(new clsComboBoxItem(additional_item, additional_item));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadJCInterestGroup(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "")
        {
#else
        		public static void LoadJCInterestGroup(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string user_id = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            user_id = cur_db.sUser_cd;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			user_id = goDatabase.sUser_cd;
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sInterestGroup_cd FROM tblJCInterestGroup WHERE iOpenToPublic_fl = 1 OR sUser_cd = '" + user_id + "'";
            sql_str += " ORDER BY sInterestGroup_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sInterestGroup_cd").ToString(), cur_set.sField("sInterestGroup_cd").ToString()));
                cur_set.MoveNext();
            }

            if (moUtility.IsNonEmpty(additional_item))
            {
                item_list.Add(new clsComboBoxItem(additional_item, additional_item));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadFAInterestGroup(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string additional_item = "")
        {
#else
        		public static void LoadFAInterestGroup(ref ComboBox cur_box, string additional_item = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string user_id = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            user_id = cur_db.sUser_cd;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			user_id = goDatabase.sUser_cd;
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sInterestGroup_cd FROM tblFAInterestGroup WHERE iOpenToPublic_fl = 1 OR sUser_cd = '" + user_id + "'";
            sql_str += " ORDER BY sInterestGroup_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sInterestGroup_cd").ToString(), cur_set.sField("sInterestGroup_cd").ToString()));
                cur_set.MoveNext();
            }

            if (moUtility.IsNonEmpty(additional_item))
            {
                item_list.Add(new clsComboBoxItem(additional_item, additional_item));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

        //#if WEB
        //        public static void LoadChartType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_pie_fl = false)
        //        {
        //#else
        //        		public static void LoadChartType(ref ComboBox cur_box, bool add_pie_fl = false)
        //        		{
        //#endif

        //            ArrayList item_list = new ArrayList();
        //            clsGraph o_graph = new clsGraph();

        //            item_list.Add(new clsComboBoxItem("", ""));
        //            item_list.Add(new clsComboBoxItem(clsGraph.CHART_TYPE_3D_BAR, clsGraph.CHART_TYPE_3D_BAR));
        //            item_list.Add(new clsComboBoxItem(clsGraph.CHART_TYPE_2D_BAR, clsGraph.CHART_TYPE_2D_BAR));
        //            item_list.Add(new clsComboBoxItem(clsGraph.CHART_TYPE_3D_LINE, clsGraph.CHART_TYPE_3D_LINE));
        //            item_list.Add(new clsComboBoxItem(clsGraph.CHART_TYPE_2D_LINE, clsGraph.CHART_TYPE_2D_LINE));
        //            item_list.Add(new clsComboBoxItem(clsGraph.CHART_TYPE_3D_STEP, clsGraph.CHART_TYPE_3D_STEP));
        //            item_list.Add(new clsComboBoxItem(clsGraph.CHART_TYPE_2D_STEP, clsGraph.CHART_TYPE_2D_STEP));
        //            item_list.Add(new clsComboBoxItem(clsGraph.CHART_TYPE_3D_AREA, clsGraph.CHART_TYPE_3D_AREA));
        //            item_list.Add(new clsComboBoxItem(clsGraph.CHART_TYPE_2D_AREA, clsGraph.CHART_TYPE_2D_AREA));
        //            if (add_pie_fl)
        //            {
        //                item_list.Add(new clsComboBoxItem(clsGraph.CHART_TYPE_3D_PIE, clsGraph.CHART_TYPE_3D_PIE));
        //                item_list.Add(new clsComboBoxItem(clsGraph.CHART_TYPE_2D_PIE, clsGraph.CHART_TYPE_2D_PIE));
        //            }

        //            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        //        }

#if WEB
        public static void LoadPaymentPostedStatusType(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadPaymentPostedStatusType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.POSTED_TRX, Convert.ToString(GlobalVar.goConstant.POSTED_TRX_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.VOID_TRX, Convert.ToString(GlobalVar.goConstant.VOID_TRX_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.SP_TRX, Convert.ToString(GlobalVar.goConstant.SP_TRX_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }

#if WEB
        public static void LoadReceiptPostedStatusType(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadReceiptPostedStatusType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.POSTED_TRX, Convert.ToString(GlobalVar.goConstant.POSTED_TRX_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.VOID_TRX, Convert.ToString(GlobalVar.goConstant.VOID_TRX_NUM)));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.NSF_TRX, Convert.ToString(GlobalVar.goConstant.NSF_TRX_NUM)));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }

#if WEB
        public static void LoadEntityType(ref List<Models.clsCombobox> cur_box, bool from_ap_fl = false)
        {
#else
        		public static void LoadEntityType(ref ComboBox cur_box, bool from_ap_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.ENTITY_CORPORATE_TYPE, GlobalVar.goConstant.ENTITY_CORPORATE_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.ENTITY_INDIVIDUAL_TYPE, GlobalVar.goConstant.ENTITY_INDIVIDUAL_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.ENTITY_GOVERNMENT_TYPE, GlobalVar.goConstant.ENTITY_GOVERNMENT_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.ENTITY_NON_PROFIT_TYPE, GlobalVar.goConstant.ENTITY_NON_PROFIT_TYPE_NUM.ToString()));
            if (from_ap_fl)
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.ENTITY_EMPLOYEE_TYPE, GlobalVar.goConstant.ENTITY_EMPLOYEE_TYPE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.ENTITY_SERVICE_TYPE, GlobalVar.goConstant.ENTITY_SERVICE_TYPE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.ENTITY_INSURANCE_TYPE, GlobalVar.goConstant.ENTITY_INSURANCE_TYPE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.ENTITY_LENDER_TYPE, GlobalVar.goConstant.ENTITY_LENDER_TYPE_NUM.ToString()));
            }
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.ENTITY_OTHER_TYPE, GlobalVar.goConstant.ENTITY_OTHER_TYPE_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }

#if WEB
        public static void LoadCalendarMonthID(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadCalendarMonthID(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem("January", "1"));
            item_list.Add(new clsComboBoxItem("February", "2"));
            item_list.Add(new clsComboBoxItem("March", "3"));
            item_list.Add(new clsComboBoxItem("April", "4"));
            item_list.Add(new clsComboBoxItem("May", "5"));
            item_list.Add(new clsComboBoxItem("June", "6"));
            item_list.Add(new clsComboBoxItem("July", "7"));
            item_list.Add(new clsComboBoxItem("August", "8"));
            item_list.Add(new clsComboBoxItem("September", "9"));
            item_list.Add(new clsComboBoxItem("October", "10"));
            item_list.Add(new clsComboBoxItem("November", "11"));
            item_list.Add(new clsComboBoxItem("December", "12"));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadNumericUnit(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadNumericUnit(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("One", "1"));
            item_list.Add(new clsComboBoxItem("Thousand", "1000"));
            item_list.Add(new clsComboBoxItem("Million", "1000000"));
            item_list.Add(new clsComboBoxItem("Billion", "1000000000"));
            item_list.Add(new clsComboBoxItem("Trillion", "1000000000000"));
            item_list.Add(new clsComboBoxItem("Quadrillion", "1000000000000000"));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadPieceWork(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool code_only = true)
        {
#else
        		public static void LoadPieceWork(ref ComboBox cur_box, bool code_only = true)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT * FROM tblPRWOrk ORDER BY sWork_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                if (code_only || moUtility.IsEmpty(cur_set.sField("sDescription")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sWork_cd"), cur_set.sField("sWork_cd")));
                }
                else
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sWork_cd")));
                }
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


            cur_set.Release();

        }

#if WEB
        public static void LoadPRHourlyRate(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadPRHourlyRate(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sHourlyRate_cd, sDescription";
            sql_str += " FROM tblPRHourlyRate ORDER BY sDescription";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sHourlyRate_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

        // This is to retrive the records that are in tblGOGenericCode.
        // The records in tblGOGenericCode are created by frmGenericCode.
        //
#if WEB
        public static void LoadGenericCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string table_name, bool show_code_fl, bool show_description_fl)
        {
#else
        		public static void LoadGenericCode(ref ComboBox cur_box, string table_name, bool show_code_fl, bool show_description_fl)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            if (moUtility.IsNonEmpty(table_name))
            {
                sql_str = "SELECT sGeneric_cd, sDescription";
                sql_str += " FROM  tblGOGenericCode";
                sql_str += " WHERE sTable_nm = '" + table_name + "'";
                sql_str += " ORDER BY iOrder_id, sDescription";
                if (cur_set.CreateSnapshot(sql_str))
                {
                    while (!cur_set.EOF())
                    {
                        if (!show_code_fl && show_description_fl)
                        {
                            item_list.Add(new clsComboBoxItem((cur_set.sField("sDescription")), (cur_set.sField("sGeneric_cd"))));
                        }
                        else if (show_code_fl && !show_description_fl)
                        {
                            item_list.Add(new clsComboBoxItem((cur_set.sField("sGeneric_cd")), (cur_set.sField("sGeneric_cd"))));
                        }
                        else
                        {
                            item_list.Add(new clsComboBoxItem((cur_set.sField("sGeneric_cd")) + GlobalVar.goConstant.ID_DELIMITER + (cur_set.sField("sDescription")), (cur_set.sField("sGeneric_cd"))));
                        }
                        cur_set.MoveNext();
                    }
                }
            }

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.NEWEDIT, clsConstant.CRM_NEWEDIT_ID));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


            cur_set.Release();

        }

#if WEB
        public static void LoadBankTransactionType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadBankTransactionType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.BR_INCOME_TYPE, GlobalVar.goBRConstant.BR_INCOME_TYPE));
            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.BR_EXPENSE_TYPE, GlobalVar.goBRConstant.BR_EXPENSE_TYPE));
            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.BR_DEPOSIT_TYPE, GlobalVar.goBRConstant.BR_DEPOSIT_TYPE));
            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.BR_WITHDRAWAL_TYPE, GlobalVar.goBRConstant.BR_WITHDRAWAL_TYPE));
            item_list.Add(new clsComboBoxItem(GlobalVar.goBRConstant.BR_DEPOSIT_SLIP_TYPE, GlobalVar.goBRConstant.BR_DEPOSIT_SLIP_TYPE));
            //item_list.Add(New clsComboBoxItem(goBRConstant.BR_FOREIGN_DEPOSIT_TYPE, goBRConstant.BR_FOREIGN_DEPOSIT_TYPE))
            //item_list.Add(New clsComboBoxItem(goBRConstant.BR_FOREIGN_WITHDRAWAL_TYPE, goBRConstant.BR_FOREIGN_WITHDRAWAL_TYPE))

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }

#if WEB
        public static void LoadVATCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool from_ar_fl)
        {
#else
        		public static void LoadVATCode(ref ComboBox cur_box, bool from_ar_fl)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            // A/R module may not exist, but there may be a type of receipt such as quick receipt/income.
            //
            sql_str = "SELECT sTax_cd FROM " + moUtility.IIf(from_ar_fl, "tblARTax", "tblAPTax") + " ORDER BY sTax_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }
            else if (cur_set.EOF())
            {
                sql_str = "SELECT sTax_cd FROM " + moUtility.IIf(from_ar_fl, "tblAPTax", "tblARTax") + " ORDER BY sTax_cd";
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sTax_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sTax_cd"), cur_set.sField("sTax_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


            cur_set.Release();
            return;

        }

#if WEB
        public static void LoadQuickPaymentType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadQuickPaymentType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();


            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.CASH_TYPE, GlobalVar.goConstant.CASH_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.CHECK_TYPE, GlobalVar.goConstant.CHECK_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.WIRE_TRANSFER_TYPE, GlobalVar.goConstant.WIRE_TRANSFER_TYPE_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }

#if WEB
        public static void LoadBankDraftType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool include_foreign_bank_fl = false)
        {
#else
        		public static void LoadBankDraftType(ref ComboBox cur_box, bool include_foreign_bank_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string currency_cd = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            currency_cd = cur_db.sCurrency_cd;
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			currency_cd = goDatabase.sCurrency_cd;
#endif

            try
            {
                //Err.Clear()

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = "SELECT sBank_cd, sBank_nm, sGLAcct_cd FROM tblBRBankAccount ";
                if (!include_foreign_bank_fl)
                {
                    sql_str += " WHERE sCurrency_cd = '" + currency_cd + "'";
                }
                sql_str += "ORDER BY sBank_cd";
                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
#if WEB
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sBank_cd") + "-" + GlobalVar.goConstant.CHECK_TYPE, GlobalVar.goConstant.CHECK_TYPE_NUM.ToString() + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sGLAcct_cd"))); // 1 & 2 are necessary to each value unique.
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sBank_cd") + "-" + GlobalVar.goConstant.WIRE_TRANSFER_TYPE, GlobalVar.goConstant.WIRE_TRANSFER_TYPE_NUM.ToString() + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sGLAcct_cd"))); // Value needs unique values otherwise it did not select well. It just goes to the first item if Value has the same values.
#else
        					item_list.Add(new clsComboBoxItem(cur_set.sField("sBank_cd") + "-" + GlobalVar.goConstant.CHECK_TYPE, cur_set.sField("sGLAcct_cd")));
        					item_list.Add(new clsComboBoxItem(cur_set.sField("sBank_cd") + "-" + GlobalVar.goConstant.WIRE_TRANSFER_TYPE, cur_set.sField("sGLAcct_cd")));
#endif
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


                modGeneralUtility.MouseDefault();
                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

                cur_set.Release();
                modGeneralUtility.MouseDefault();
#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadBankDraftType)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadBankDraftType)");
#endif
                return;

            }

        }


#if WEB
        public static void LoadWorkOrderPriotiry(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool include_higher_fl)
        {
#else
        		public static void LoadWorkOrderPriotiry(ref ComboBox cur_box, bool include_higher_fl)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_PRIORITY_LOW, GlobalVar.goWOConstant.WO_PRIORITY_LOW_NUM.ToString()));
            if (include_higher_fl)
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_PRIORITY_LOW + "+", GlobalVar.goWOConstant.WO_PRIORITY_LOW_NUM.ToString() + "+"));
            }
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_PRIORITY_MED_LOW, GlobalVar.goWOConstant.WO_PRIORITY_MED_LOW_NUM.ToString()));
            if (include_higher_fl)
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_PRIORITY_MED_LOW + "+", GlobalVar.goWOConstant.WO_PRIORITY_MED_LOW_NUM.ToString() + "+"));
            }
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_PRIORITY_MEDIUM, GlobalVar.goWOConstant.WO_PRIORITY_MEDIUM_NUM.ToString()));
            if (include_higher_fl)
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_PRIORITY_MEDIUM + "+", GlobalVar.goWOConstant.WO_PRIORITY_MEDIUM_NUM.ToString() + "+"));
            }
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_PRIORITY_MED_HIGH, GlobalVar.goWOConstant.WO_PRIORITY_MED_HIGH_NUM.ToString()));
            if (include_higher_fl)
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_PRIORITY_MED_HIGH + "+", GlobalVar.goWOConstant.WO_PRIORITY_MED_HIGH_NUM.ToString() + "+"));
            }
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.WO_PRIORITY_HIGH, GlobalVar.goWOConstant.WO_PRIORITY_HIGH_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadSegmentOptions(ref clsDatabase cur_db, ref List<Models.clsCombobox> segment_box1, ref List<Models.clsCombobox> segment_box2, ref List<Models.clsCombobox> segment_box3, ref List<Models.clsCombobox> segment_box4, ref List<Models.clsCombobox> segment_box5, ref List<Models.clsCombobox> segment_box6, ref string segement_label1, ref string segement_label2, ref string segement_label3, ref string segement_label4, ref string segement_label5, ref string segement_label6)
        {
#else
                		public static void LoadSegmentOptions(ref clsDatabase cur_db, ref ComboBox segment_box1, ref ComboBox segment_box2, ref ComboBox segment_box3, ref ComboBox segment_box4, ref ComboBox segment_box5, ref ComboBox segment_box6, ref Label segement_label1, ref Label segement_label2, ref Label segement_label3, ref Label segement_label4, ref Label segement_label5, ref Label segement_label6)
                		{
#endif

            string sql_str = "";
            clsRecordset cur_set = new clsRecordset(ref cur_db);
            ArrayList item_list1 = new ArrayList();
            ArrayList item_list2 = new ArrayList();
            ArrayList item_list3 = new ArrayList();
            ArrayList item_list4 = new ArrayList();
            ArrayList item_list5 = new ArrayList();
            ArrayList item_list6 = new ArrayList();

            sql_str = "SELECT * FROM tblGLSegmentType ORDER BY iSegmentLevel, sSegment_nm";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }
            else if (cur_set.IsEmpty())
            {
                //cur_set.Release()
                //Exit Sub
            }

            while (!cur_set.EOF())
            {
                if ((cur_set.iField("iSegmentLevel")) == 1)
                {
                    segement_label1 = (cur_set.sField("sSegment_nm"));
                }
                else if ((cur_set.iField("iSegmentLevel")) == 2)
                {
                    segement_label2 = (cur_set.sField("sSegment_nm"));
                }
                else if ((cur_set.iField("iSegmentLevel")) == 3)
                {
                    segement_label3 = (cur_set.sField("sSegment_nm"));
                }
                else if ((cur_set.iField("iSegmentLevel")) == 4)
                {
                    segement_label4 = (cur_set.sField("sSegment_nm"));
                }
                else if ((cur_set.iField("iSegmentLevel")) == 5)
                {
                    segement_label5 = (cur_set.sField("sSegment_nm"));
                }
                else //If (cur_set.iField("iSegmentLevel")) = 6 Then
                {
                    segement_label6 = (cur_set.sField("sSegment_nm"));
                }
                cur_set.MoveNext();
            }

            sql_str = "SELECT * FROM tblGLSegment ORDER BY iSegmentLevel, sSegment_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }
            else if (cur_set.IsEmpty())
            {
                //cur_set.Release()
                //Exit Sub
            }

            item_list1.Add(new clsComboBoxItem("", ""));
            item_list2.Add(new clsComboBoxItem("", ""));
            item_list3.Add(new clsComboBoxItem("", ""));
            item_list4.Add(new clsComboBoxItem("", ""));
            item_list5.Add(new clsComboBoxItem("", ""));
            item_list6.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {
                if ((cur_set.iField("iSegmentLevel")) == 1)
                {
                    item_list1.Add(new clsComboBoxItem(cur_set.sField("sSegment_cd"), cur_set.sField("sSegment_cd")));
                }
                else if ((cur_set.iField("iSegmentLevel")) == 2)
                {
                    item_list2.Add(new clsComboBoxItem(cur_set.sField("sSegment_cd"), cur_set.sField("sSegment_cd")));
                }
                else if ((cur_set.iField("iSegmentLevel")) == 3)
                {
                    item_list3.Add(new clsComboBoxItem(cur_set.sField("sSegment_cd"), cur_set.sField("sSegment_cd")));
                }
                else if ((cur_set.iField("iSegmentLevel")) == 4)
                {
                    item_list4.Add(new clsComboBoxItem(cur_set.sField("sSegment_cd"), cur_set.sField("sSegment_cd")));
                }
                else if ((cur_set.iField("iSegmentLevel")) == 5)
                {
                    item_list5.Add(new clsComboBoxItem(cur_set.sField("sSegment_cd"), cur_set.sField("sSegment_cd")));
                }
                else
                {
                    item_list6.Add(new clsComboBoxItem(cur_set.sField("sSegment_cd"), cur_set.sField("sSegment_cd")));
                }
                cur_set.MoveNext();
            }

            cur_set.Release();

            modGeneralUtility.RunEvents();

            modWebLoadUtility.LoadComboBox(ref segment_box1, item_list1);
            modWebLoadUtility.LoadComboBox(ref segment_box2, item_list2);
            modWebLoadUtility.LoadComboBox(ref segment_box3, item_list3);
            modWebLoadUtility.LoadComboBox(ref segment_box4, item_list4);
            modWebLoadUtility.LoadComboBox(ref segment_box5, item_list5);
            modWebLoadUtility.LoadComboBox(ref segment_box6, item_list6);

        }

#if WEB
        public static void LoadPhysicalInventoryCycleType(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadPhysicalInventoryCycleType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_DAILY, GlobalVar.goConstant.RECUR_DAILY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_WEEKLY, GlobalVar.goConstant.RECUR_WEEKLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_MONTHLY, GlobalVar.goConstant.RECUR_MONTHLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_QUARTERLY, GlobalVar.goConstant.RECUR_QUARTERLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_YEARLY, GlobalVar.goConstant.RECUR_YEARLY_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadPhysicalInventoryCycleCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadPhysicalInventoryCycleCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
#endif

            sql_str = "SELECT * FROM tblIVPhysicalCycle";
            sql_str += " ORDER BY sPhysicalCycle_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sPhysicalCycle_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sPhysicalCycle_cd"), cur_set.sField("sPhysicalCycle_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }


#if WEB
        public static void LoadVendorMemo(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string vendor_code, int trx_num, int memo_num, string currency_code)
        {
#else
        		public static void LoadVendorMemo(ref ComboBox cur_box, string vendor_code, int trx_num, int memo_num, string currency_code)
        		{
#endif

            ArrayList item_list = new ArrayList();
            clsRecordset cur_set = null;
            string sql_str = "";
            string table_name = "";
            decimal previous_amt = 0M;
            decimal deposit_amt = 0M;
            bool foreign_fl = false;
            int previous_memo_num = 0;

            clsMoney o_money = null;
            clsDeposit o_deposit = new clsDeposit();

#if WEB
            foreign_fl = (currency_code != cur_db.sCurrency_cd && moUtility.IsNonEmpty(currency_code));
            cur_set = new clsRecordset(ref cur_db);
            o_money = new clsMoney(ref cur_db);
            deposit_amt = o_deposit.GetVendorDeposit(ref cur_db, vendor_code, currency_code);
#else
        			foreign_fl = (currency_code != goDatabase.sCurrency_cd && moUtility.IsNonEmpty(currency_code));
        			cur_set = new clsRecordset(goDatabase);
        			o_money = new clsMoney(goDatabase);
        			deposit_amt = o_deposit.GetVendorDeposit(goDatabase, vendor_code, currency_code);
#endif

            if (foreign_fl)
            {
                table_name = "tblAPMCPaymentUnposted";
            }
            else
            {
                table_name = "tblAPPaymentUnposted";
            }

            previous_amt = 0M;

            if (!cur_set.CreateSnapshot("SELECT * FROM " + table_name + " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_PAYMENT_TYPE.ToString() + " AND iTransaction_num = " + trx_num.ToString() + " AND iCash_typ = " + GlobalVar.goConstant.MEMO_TYPE_NUM.ToString() + " AND iStatus_typ <> " + GlobalVar.goConstant.VOID_TRX_NUM.ToString()))
            {
                return;
            }
            else if (!cur_set.EOF())
            {
                previous_memo_num = moUtility.ToInteger(cur_set.sField("sDocument_num"));
                previous_amt = cur_set.mField("mPaid_amt");
            }

            // if previous payment was made with cash-deposit
            //
            if (previous_memo_num == 0 && previous_amt > 0M)
            {
                if (foreign_fl)
                {
                    if (cur_set.sField("sCurrency_cd") == currency_code) // make sure the same currency is used. Actually, this is guaranteed at entry time.
                    {
                        deposit_amt += previous_amt;
                    }
                }
                else
                {
                    deposit_amt += previous_amt;
                }
                previous_amt = 0M;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            if (deposit_amt > 0M)
            {
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DEPOSIT + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + o_money.ToStrMoney(deposit_amt), "0"));
            }

            if (foreign_fl)
            {
                table_name = "tblAPMCCharge";
            }
            else
            {
                table_name = "tblAPCharge";
            }

            sql_str = "SELECT iTransaction_num, (mDue_amt - mCommitted_amt) AS mBalance_amt FROM " + table_name;
            sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_DM_TYPE.ToString();
            sql_str += " AND iOrder_num = 0"; // non-voucher specific.
            sql_str += " AND iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM.ToString();
            sql_str += " AND sVendor_cd = '" + vendor_code + "'";
            if (previous_amt > 0M && memo_num > 0)
            {
                sql_str += " AND ((mDue_amt - mCommitted_amt) >= 0.01 OR iTransaction_num = " + memo_num.ToString() + ")";
            }
            else
            {
                sql_str += " AND ((mDue_amt - mCommitted_amt) >= 0.01)";
            }
            if (foreign_fl)
            {
                sql_str += " AND sCurrency_cd = '" + currency_code + "'";
            }
            else
            {
                sql_str += " AND iTransaction_num NOT IN (SELECT iTransaction_num FROM tblAPMCCharge WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_DM_TYPE.ToString() + " AND sVendor_cd = '" + vendor_code + "')";
            }
            sql_str += " ORDER BY iTransaction_num";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {

                if (cur_set.iField("iTransaction_num") == memo_num && memo_num > 0)
                {
                    item_list.Add(new clsComboBoxItem(cur_set.iField("iTransaction_num").ToString() + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + o_money.ToStrMoney(cur_set.mField("mBalance_amt") + previous_amt), cur_set.iField("iTransaction_num").ToString()));
                }
                else
                {
                    item_list.Add(new clsComboBoxItem(cur_set.iField("iTransaction_num").ToString() + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + o_money.ToStrMoney(cur_set.mField("mBalance_amt")), cur_set.iField("iTransaction_num").ToString()));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }


#if WEB
        public static void LoadCustomerMemo(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string customer_code, int trx_num, int memo_num, string currency_code)
        {
#else
        		public static void LoadCustomerMemo(ref ComboBox cur_box, string customer_code, int trx_num, int memo_num, string currency_code)
        		{
#endif

            ArrayList item_list = new ArrayList();
            clsRecordset cur_set = null;
            string sql_str = "";
            string table_name = "";
            decimal previous_amt = 0M;
            decimal deposit_amt = 0M;
            bool foreign_fl = false;
            int previous_memo_num = 0;

            clsMoney o_money = null;
            clsDeposit o_deposit = new clsDeposit();

#if WEB
            foreign_fl = (moUtility.IsNonEmpty(currency_code) && moUtility.IsNonEmpty(cur_db.sCurrency_cd) && currency_code != cur_db.sCurrency_cd);
            cur_set = new clsRecordset(ref cur_db);
            o_money = new clsMoney(ref cur_db);
            deposit_amt = o_deposit.GetCustomerDeposit(ref cur_db, customer_code, currency_code);
#else
        			foreign_fl = currency_code != goDatabase.sCurrency_cd;
        			cur_set = new clsRecordset(goDatabase);
        			o_money = new clsMoney(goDatabase);
        			deposit_amt = o_deposit.GetCustomerDeposit(goDatabase, customer_code, currency_code);
#endif

            if (foreign_fl)
            {
                table_name = "tblARMCPaymentUnposted";
            }
            else
            {
                table_name = "tblARPaymentUnposted";
            }

            previous_amt = 0M;

            if (!cur_set.CreateSnapshot("SELECT * FROM " + table_name + " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_RECEIPT_TYPE.ToString() + " AND iTransaction_num = " + trx_num.ToString() + " AND iCash_typ = " + GlobalVar.goConstant.MEMO_TYPE_NUM.ToString() + " AND iStatus_typ <> " + GlobalVar.goConstant.VOID_TRX_NUM.ToString()))
            {
                return;
            }
            else if (!cur_set.EOF())
            {
                previous_memo_num = moUtility.ToInteger(cur_set.sField("sDocument_num"));
                previous_amt = cur_set.mField("mPaid_amt");
            }

            // if previous payment was made with cash-deposit
            //
            if (previous_memo_num == 0 && previous_amt > 0M)
            {
                if (foreign_fl)
                {
                    if (cur_set.sField("sCurrency_cd") == currency_code) // make sure the same currency is used. Actually, this is guaranteed at entry time.
                    {
                        deposit_amt += previous_amt;
                    }
                }
                else
                {
                    deposit_amt += previous_amt;
                }
                previous_amt = 0M;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            if (deposit_amt > 0M)
            {
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DEPOSIT + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + o_money.ToStrMoney(deposit_amt), "0"));
            }

            if (foreign_fl)
            {
                table_name = "tblARMCCharge";
            }
            else
            {
                table_name = "tblARCharge";
            }

            sql_str = "SELECT iTransaction_num, (mDue_amt - mCommitted_amt) AS mBalance_amt FROM " + table_name;
            sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_CM_TYPE.ToString();
            sql_str += " AND iOrder_num = 0"; // non-voucher specific.
            sql_str += " AND iStatus_typ = " + GlobalVar.goConstant.POSTED_TRX_NUM.ToString();
            sql_str += " AND sCustomer_cd = '" + customer_code + "'";
            if (previous_amt > 0M && memo_num > 0)
            {
                sql_str += " AND ((mDue_amt - mCommitted_amt) >= 0.01 OR iTransaction_num = " + memo_num.ToString() + ")";
            }
            else
            {
                sql_str += " AND ((mDue_amt - mCommitted_amt) >= 0.01)";
            }
            if (foreign_fl)
            {
                sql_str += " AND sCurrency_cd = '" + currency_code + "'";
            }
            else
            {
                sql_str += " AND iTransaction_num NOT IN (SELECT iTransaction_num FROM tblARMCCharge WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_CM_TYPE.ToString() + " AND sCustomer_cd = '" + customer_code + "')";
            }
            sql_str += " ORDER BY iTransaction_num";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {

                if (cur_set.iField("iTransaction_num") == memo_num && memo_num > 0)
                {
                    item_list.Add(new clsComboBoxItem(cur_set.iField("iTransaction_num").ToString() + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + o_money.ToStrMoney(cur_set.mField("mBalance_amt") + previous_amt), cur_set.iField("iTransaction_num").ToString()));
                }
                else
                {
                    item_list.Add(new clsComboBoxItem(cur_set.iField("iTransaction_num").ToString() + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + o_money.ToStrMoney(cur_set.mField("mBalance_amt")), cur_set.iField("iTransaction_num").ToString()));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadRentalBillingCycleType(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadRentalBillingCycleType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            //item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_DAILY, GlobalVar.goConstant.RECUR_DAILY_NUM.ToString()));
            //item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_WEEKLY, GlobalVar.goConstant.RECUR_WEEKLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_MONTHLY, GlobalVar.goConstant.RECUR_MONTHLY_NUM.ToString()));
            //item_list.Add(New clsComboBoxItem(goConstant.RECUR_QUARTERLY, goConstant.RECUR_QUARTERLY_NUM.ToString))  does not make saense.  maybe later if necessary
            //item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.RECUR_YEARLY, GlobalVar.goConstant.RECUR_YEARLY_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadRentalBillingCycleCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadRentalBillingCycleCode(ref clsDatabase cur_db, ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = new clsRecordset(ref cur_db);

            cur_box.Clear();

            sql_str = "SELECT * FROM tblFARentalBillingCycle";
            sql_str += " ORDER BY sBillingCycle_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sBillingCycle_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sBillingCycle_cd"), cur_set.sField("sBillingCycle_cd")));
                }

                cur_set.MoveNext();

            }
            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadFAInsuranceGroup(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadFAInsuranceGroup(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
#endif

            sql_str = "SELECT * FROM tblFAInsuranceGroup";
            sql_str += " ORDER BY sInsuranceGroup_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sInsuranceGroup_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sInsuranceGroup_cd"), cur_set.sField("sInsuranceGroup_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadFALeaseGroup(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadFALeaseGroup(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
#endif

            sql_str = "SELECT * FROM tblFALeaseGroup";
            sql_str += " ORDER BY sLeaseGroup_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sLeaseGroup_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sLeaseGroup_cd"), cur_set.sField("sLeaseGroup_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadFAServiceGroup(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadFAServiceGroup(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
#endif

            sql_str = "SELECT * FROM tblFAServiceGroup";
            sql_str += " ORDER BY sServiceGroup_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sServiceGroup_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sServiceGroup_cd"), cur_set.sField("sServiceGroup_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadFAPostingCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadFAPostingCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
#endif

            sql_str = "SELECT * FROM tblFAAccounts";
            sql_str += " ORDER BY sPosting_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sPosting_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sPosting_cd"), cur_set.sField("sPosting_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadFAGroup(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadFAGroup(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
#endif

            sql_str = "SELECT * FROM tblFAGroup";
            sql_str += " ORDER BY sGroup_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sGroup_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sGroup_cd"), cur_set.sField("sGroup_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadFAClass(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadFAClass(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
#endif

            sql_str = "SELECT * FROM tblFAClass";
            sql_str += " ORDER BY sClass_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sClass_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sClass_cd") + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + cur_set.sField("sDescription"), cur_set.sField("sClass_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadAssetCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool code_only = true, string class_cd = "")
        {
#else
        		public static void LoadAssetCode(ref ComboBox cur_box, bool code_only = true, string class_cd = "")
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT * FROM tblFAAsset";
            if (moUtility.IsNonEmpty(class_cd))
            {
                sql_str += " WHERE sClass_cd = '" + class_cd + "'";
            }
            sql_str += " ORDER BY sAsset_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                if (code_only || moUtility.IsEmpty(cur_set.sField("sDescription")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sAsset_cd"), cur_set.sField("sAsset_cd")));
                }
                else
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sAsset_nm"), cur_set.sField("sAsset_cd")));
                }
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


            cur_set.Release();

        }

#if WEB
        public static void LoadFAServiceCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool code_only_fl = false)
        {
#else
        		public static void LoadFAServiceCode(ref ComboBox cur_box, bool code_only_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
#endif

            sql_str = "SELECT * FROM tblFAService";
            sql_str += " ORDER BY sService_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sService_cd")))
                {
                    if (code_only_fl)
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sService_cd"), cur_set.sField("sService_cd")));
                    }
                    else
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sService_cd") + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + cur_set.sField("sDescription"), cur_set.sField("sService_cd")));
                    }
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadFARentalFeeCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadFARentalFeeCode(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
#endif

            sql_str = "SELECT * FROM tblFARentalFee";
            sql_str += " ORDER BY sRentalFee_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sRentalFee_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sRentalFee_cd"), cur_set.sField("sRentalFee_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadRentalStatus(ref List<Models.clsCombobox> cur_box, bool show_full_fl = false)
        {
#else
        		public static void LoadRentalStatus(ref ComboBox cur_box, bool show_full_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.RENTAL_OPEN_TRX, GlobalVar.goFAConstant.RENTAL_OPEN_TRX_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.RENTAL_HOLD_TRX, GlobalVar.goFAConstant.RENTAL_HOLD_TRX_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.RENTAL_VOID_TRX, GlobalVar.goFAConstant.RENTAL_VOID_TRX_NUM.ToString()));

            if (show_full_fl)
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.RENTAL_CLOSED_TRX, GlobalVar.goFAConstant.RENTAL_CLOSED_TRX_NUM.ToString()));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadRentalPostedStatus(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadRentalPostedStatus(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();


            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.RENTAL_CLOSED_TRX, GlobalVar.goFAConstant.RENTAL_CLOSED_TRX_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.RENTAL_VOID_TRX, GlobalVar.goFAConstant.RENTAL_VOID_TRX_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadFARentalCycleCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool code_only_fl, ref string default_code, bool lease_only)
        {
#else
        		public static void LoadFARentalCycleCode(ref ComboBox cur_box, bool code_only_fl, ref string default_code, bool lease_only)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
#endif

            sql_str = "SELECT * FROM tblFARentalBillingCycle";
            sql_str += " ORDER BY sBillingCycle_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));
            default_code = "";

            while (!cur_set.EOF())
            {
                if (moUtility.IsNonEmpty(cur_set.sField("sBillingCycle_cd")))
                {
                    if (cur_set.BOF())
                    {
                        default_code = cur_set.sField("sBillingCycle_cd");
                    }
                    if (!lease_only || (cur_set.iField("iFrequency_typ") != GlobalVar.goConstant.RECUR_DAILY_NUM && cur_set.iField("iFrequency_typ") != GlobalVar.goConstant.RECUR_WEEKLY_NUM)) // Lease does not include daily/weekly.
                    {
                        if (code_only_fl)
                        {
                            item_list.Add(new clsComboBoxItem(cur_set.sField("sBillingCycle_cd"), cur_set.sField("sBillingCycle_cd")));
                        }
                        else
                        {
                            item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sBillingCycle_cd")));
                        }
                        if (cur_set.iField("iDefault_fl") > 0)
                        {
                            default_code = cur_set.sField("sBillingCycle_cd");
                        }
                    }
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadRentalListingOrder(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadRentalListingOrder(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CUSTOMER_CODE, cur_db.oLanguage.oString.STR_CUSTOMER_CODE));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_CUSTOMER_NAME, cur_db.oLanguage.oString.STR_CUSTOMER_NAME));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadPageNamesToLocalize(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string language_code, bool for_all_languages_fl = false)
        {
#else
        public static void LoadPageNamesToLocalize(ref ComboBox cur_box, string language_code, bool for_all_languages_fl = false)
        {
#endif
            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsFileIO io_stream = new clsFileIO();
            string[] file_list;
            string folder_name = "";
            string file_ext = "";
            string tmp = "";

            cur_set = new clsRecordset(ref cur_db);

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem("Caption", "CAPTION"));
            item_list.Add(new clsComboBoxItem("Menu", "MAINMENU"));
            item_list.Add(new clsComboBoxItem("Message", "MESSAGE"));
            item_list.Add(new clsComboBoxItem("String", "STRING"));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadOfficeType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadOfficeType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.FM_GENERAL_OFFICE_TYPE, GlobalVar.goConstant.FM_GENERAL_OFFICE_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.FM_SALES_OFFICE_TYPE, GlobalVar.goConstant.FM_SALES_OFFICE_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.FM_GENERAL_FACILITY_TYPE, GlobalVar.goConstant.FM_GENERAL_FACILITY_TYPE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.FM_WAREHOUSE_TYPE, GlobalVar.goConstant.FM_WAREHOUSE_TYPE_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadFAServiceType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadFAServiceType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.SERVICE_PREVENTIVE_TYPE, GlobalVar.goFAConstant.SERVICE_PREVENTIVE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.SERVICE_CORRECTIVE_TYPE, GlobalVar.goFAConstant.SERVICE_CORRECTIVE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.SERVICE_BREAKDOWN_TYPE, GlobalVar.goFAConstant.SERVICE_BREAKDOWN_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.SERVICE_UPGRADE_TYPE, GlobalVar.goFAConstant.SERVICE_UPGRADE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.SERVICE_NEW_INSTALLATION_TYPE, GlobalVar.goFAConstant.SERVICE_NEW_INSTALLATION_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadWorkOrderDates(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadWorkOrderDates(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DATE_ENTERED, "iEntry_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DATE_REQUIRED, "iRequired_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DATE_ESTIMATED, "iWorkEstimated_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DATE_STARTED, "iWorkStarted_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DATE_COMPLETED, "iWorkCompleted_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DATE_CONFIRMED, "iWorkConfirmed_dt"));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadWorkOrderSortOrder(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadWorkOrderSortOrder(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_TRANSACTION_NUMBER, cur_db.oLanguage.oString.STR_TRANSACTION_NUMBER));          // DO NOT USE "iTransaction_num"
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DATE_ENTERED, "iEntry_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DATE_REQUIRED, "iRequired_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DATE_ESTIMATED, "iWorkEstimated_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DATE_STARTED, "iWorkStarted_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DATE_COMPLETED, "iWorkCompleted_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DATE_CONFIRMED, "iWorkConfirmed_dt"));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }
#if WEB
        public static void LoadFAServiceDates(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_trx_num = false)
        {
#else
        		public static void LoadFAServiceDates(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            if (add_trx_num)
            {
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_TRANSACTION_NUMBER, cur_db.oLanguage.oString.STR_TRANSACTION_NUMBER));          // DO NOT USE "iTransaction_num"
            }
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DATE_ENTERED, "iEntry_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DATE_REQUIRED, "iRequired_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DATE_ESTIMATED, "iEstimated_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DATE_COMPLETED, "iCompleted_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DATE_ORDERED, "iWOEntered_dt"));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadDepartmentCodeForTimesheet(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_all_fl = false)
        {
#else
        		public static void LoadDepartmentCodeForTimesheet(ref ComboBox cur_box, bool add_all_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {

                sql_str = "SELECT * FROM tblPRDepartment ORDER BY sDepartment_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                if (add_all_fl)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL, cur_db.oLanguage.oString.STR_ALL));
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sDepartment_cd")));
                    cur_set.MoveNext();
                }

                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_WORK_ORDER, cur_db.oLanguage.oString.STR_WORK_ORDER));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DAILY_DISPATCH, cur_db.oLanguage.oString.STR_DAILY_DISPATCH));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadDepartmentCode)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadDepartmentCode)");
#endif
                cur_set.Release();
                return;

            }

        }

#if WEB
        public static void LoadJobCodeParentsOnly(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool active_only)
        {
#else
        		public static void LoadJobCodeParentsOnly(ref ComboBox cur_box, bool active_only)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;
            clsJobCost o_jc = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            o_jc = new clsJobCost(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			o_jc = new clsJobCost(goDatabase);
#endif


            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = "SELECT sJob_cd, sDescription FROM tblJCJob";
                sql_str += " WHERE sJob_cd IN (SELECT sParentJob_cd FROM tblJCJob";
                sql_str += " WHERE sParentJob_cd IS NOT NULL";

#if WEB
                if (cur_db.CurrentDatabaseType() != GlobalVar.goConstant.DB_ORACLE_TYPE)
                {
                    sql_str += " AND sParentJob_cd <> ''";
                }
#else
        				if (goDatabase.CurrentDatabaseType() != GlobalVar.goConstant.DB_ORACLE_TYPE)
        				{
        					sql_str += " AND sParentJob_cd <> ''";
        				}
#endif
                sql_str += ")";
                if (active_only)
                {
                    sql_str += " AND iStatus_typ NOT IN (" + o_jc.GetInactiveJobStatus() + ")";
                }
                sql_str += " ORDER BY sJob_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sJob_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sJob_cd")));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadJobCodeParentsOnly)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadJobCodeParentsOnly)");
#endif
                cur_set.Release();
                return;

            }

        }
        public static void LoadJobSupervisorCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool active_only)
        {
            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;

            cur_set = new clsRecordset(ref cur_db);

            try
            {
                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = "SELECT * FROM tblGOUser WHERE iJC_fl > 0 AND iUserType_id >= " + clsConstant.USER_SUPERVISOR_TYPE;
                if (active_only)
                {
                    sql_str += " AND iDeactivated_fl = 0";
                }
                sql_str += " ORDER BY sUser_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sUser_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sUser_nm"), cur_set.sField("sUser_cd")));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadJobSupervisorCode)");
            }

        }

#if WEB
        public static void LoadJobCreatorCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool active_only)
        {
#else
        		public static void LoadJobCreatorCode(ref ComboBox cur_box, bool active_only)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;
            clsJobCost o_jc = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            o_jc = new clsJobCost(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			o_jc = new clsJobCost(goDatabase);
#endif


            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = "SELECT * FROM tblGOUser WHERE sUser_cd IN (SELECT sCreator_id FROM tblJCJob ";
                sql_str += " WHERE sCreator_id IS NOT NULL";
#if WEB
                if (cur_db.CurrentDatabaseType() != GlobalVar.goConstant.DB_ORACLE_TYPE)
                {
                    sql_str += " AND sCreator_id <> ''";
                }
#else
        				if (goDatabase.CurrentDatabaseType() != GlobalVar.goConstant.DB_ORACLE_TYPE)
        				{
        					sql_str += " AND sCreator_id <> ''";
        				}
#endif
                if (active_only)
                {
                    sql_str += " AND iStatus_typ NOT IN (" + o_jc.GetInactiveJobStatus() + ")";
                }
                sql_str += ")";
                sql_str += " ORDER BY sUser_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sUser_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sUser_nm"), cur_set.sField("sUser_cd")));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                cur_set.Release();

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadJobCreatorCode)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadJobCodeParentsOnly)");
#endif
                cur_set.Release();
                return;

            }

        }

        public static void LoadRiskLevel(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.LOW, "10"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.MEDIUM, "20"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.HIGH, "30"));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
        }

#if WEB
        public static void LoadPercentile(ref List<Models.clsCombobox> cur_box, bool include_higher_fl)
        {
#else
        		public static void LoadPercentile(ref ComboBox cur_box, bool include_higher_fl)
        		{
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));
                item_list.Add(new clsComboBoxItem("0", "0"));
                if (include_higher_fl)
                {
                    item_list.Add(new clsComboBoxItem("0+", "0+"));
                }
                item_list.Add(new clsComboBoxItem("10", "10"));
                if (include_higher_fl)
                {
                    item_list.Add(new clsComboBoxItem("10+", "10+"));
                }
                item_list.Add(new clsComboBoxItem("20", "20"));
                if (include_higher_fl)
                {
                    item_list.Add(new clsComboBoxItem("20+", "20+"));
                }
                item_list.Add(new clsComboBoxItem("30", "30"));
                if (include_higher_fl)
                {
                    item_list.Add(new clsComboBoxItem("30+", "30+"));
                }
                item_list.Add(new clsComboBoxItem("40", "40"));
                if (include_higher_fl)
                {
                    item_list.Add(new clsComboBoxItem("40+", "40+"));
                }
                item_list.Add(new clsComboBoxItem("50", "50"));
                if (include_higher_fl)
                {
                    item_list.Add(new clsComboBoxItem("50+", "50+"));
                }
                item_list.Add(new clsComboBoxItem("60", "60"));
                if (include_higher_fl)
                {
                    item_list.Add(new clsComboBoxItem("60+", "60+"));
                }
                item_list.Add(new clsComboBoxItem("70", "70"));
                if (include_higher_fl)
                {
                    item_list.Add(new clsComboBoxItem("70+", "70+"));
                }
                item_list.Add(new clsComboBoxItem("80", "80"));
                if (include_higher_fl)
                {
                    item_list.Add(new clsComboBoxItem("80+", "80+"));
                }
                item_list.Add(new clsComboBoxItem("90", "90"));
                if (include_higher_fl)
                {
                    item_list.Add(new clsComboBoxItem("90+", "90+"));
                }
                item_list.Add(new clsComboBoxItem("100", "100"));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadInvoiceSortOrder(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadInvoiceSortOrder(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_INVOICE_NUM, "iTransaction_num"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_AMOUNT, "mTotal_amt"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_AMOUNT_DUE, "mDue_amt"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DUE_DATE, "iDue_dt"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DISCOUNT_DUE_DATE, "iDiscountDue_dt"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_INVOICE_DATE, "iApply_dt"));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadVoucherSortOrder(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadVoucherSortOrder(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_VOUCHER_NUM, "iTransaction_num"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_AMOUNT, "mTotal_amt"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_AMOUNT_DUE, "mDue_amt"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DUE_DATE, "iDue_dt"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_DISCOUNT_DUE_DATE, "iDiscountDue_dt"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_INVOICE_DATE, "iInvoice_dt"));
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_INVOICE_NUM, "sYourReference"));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadMaxPageOptions(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadMaxPageOptions(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("40 per page", "40"));            // 40 is the max line for on A4 page.
                item_list.Add(new clsComboBoxItem("100 per page", "100"));
                item_list.Add(new clsComboBoxItem("200 per page", "200"));
                item_list.Add(new clsComboBoxItem("300 per page", "300"));
                item_list.Add(new clsComboBoxItem("400 per page", "400"));
                item_list.Add(new clsComboBoxItem("500 per page", "500"));
                // item_list.Add(new clsComboBoxItem("Show All", "0"));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadIntegers(ref List<Models.clsCombobox> cur_box, int min_num, int max_num, string text_description = "", int increment_factor = 1)
        {
#else
        		public static void LoadIntegers(ref ComboBox cur_box, int min_num, int max_num, string text_description = "", int increment_factor = 1)
        		{
#endif

            ArrayList item_list = new ArrayList();
            int i = 0;

            try
            {

                cur_box.Clear();

                if (moUtility.IsNonEmpty(moUtility.STrim(text_description)))
                {
                    text_description = " " + moUtility.STrim(text_description);
                }

                if (increment_factor == 0)
                {
                    increment_factor = 1;
                }

                increment_factor = Math.Abs(increment_factor);

                if (min_num > max_num)
                {
                    moUtility.Swap(ref min_num, ref max_num);
                }

                if (min_num != 0)
                {
                    item_list.Add(new clsComboBoxItem("", "0"));
                }

                i = min_num;

                while (i <= max_num)
                {
                    item_list.Add(new clsComboBoxItem(i.ToString() + text_description, i.ToString()));
                    i += increment_factor;
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadFADepreciationConvention(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadFADepreciationConvention(ref clsDatabase cur_db, ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));
                item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.CONVENTION_FM_TYPE + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + GlobalVar.goFAConstant.CONVENTION_FM, GlobalVar.goFAConstant.CONVENTION_FM_TYPE));
                item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.CONVENTION_HM_TYPE + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + GlobalVar.goFAConstant.CONVENTION_HM, GlobalVar.goFAConstant.CONVENTION_HM_TYPE));
                item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.CONVENTION_MM_TYPE + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + GlobalVar.goFAConstant.CONVENTION_MM, GlobalVar.goFAConstant.CONVENTION_MM_TYPE));
                item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.CONVENTION_NM_TYPE + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + GlobalVar.goFAConstant.CONVENTION_NM, GlobalVar.goFAConstant.CONVENTION_NM_TYPE));
                item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.CONVENTION_MQ_TYPE + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + GlobalVar.goFAConstant.CONVENTION_MQ, GlobalVar.goFAConstant.CONVENTION_MQ_TYPE));
                item_list.Add(new clsComboBoxItem(GlobalVar.goFAConstant.CONVENTION_HY_TYPE + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + GlobalVar.goFAConstant.CONVENTION_HY, GlobalVar.goFAConstant.CONVENTION_HY_TYPE));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadFiscalPeriodID(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string cur_year, bool next_periods_only = false)
        {
#else
        		public static void LoadFiscalPeriodID(ref ComboBox cur_box, string cur_year, bool next_periods_only = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            int i = 0;
            int period_begin = 0;
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
            period_begin = cur_db.iCurPeriodBegin_dt;
            if (moUtility.IsEmpty(moUtility.STrim(cur_year)))
            {
                cur_year = cur_db.sCurFiscalYear;
            }
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
        			period_begin = goDatabase.iCurPeriodBegin_dt;
        			if (moUtility.IsEmpty(moUtility.STrim(cur_year)))
        			{
        				cur_year = goDatabase.sCurFiscalYear;
        			}
#endif

            try
            {

                if (moUtility.IsEmpty(moUtility.STrim(cur_year)))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = modConstant.PERIODDET_DYNASET + " WHERE sFiscalYear = '" + cur_year + "'";
                if (next_periods_only)
                {
                    sql_str += " AND iPeriodBegin_dt > " + period_begin;
                }
                sql_str += " ORDER BY iDetail_num ";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sPeriod_nam"), cur_set.iField("iDetail_num").ToString()));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                modGeneralUtility.MouseDefault();
                cur_set.Release();
                return;

            }
            catch (Exception ex)
            {

                cur_set.Release();
                modGeneralUtility.MouseDefault();
#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadFiscalPeriod)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadFiscalPeriod)");
#endif
                return;

            }

        }

#if WEB
        public static void LoadFADepreciationYear(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadFADepreciationYear(ref clsDatabase cur_db, ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(cur_db.sCurFiscalYear, cur_db.sCurFiscalYear));
            item_list.Add(new clsComboBoxItem(cur_db.sLastFiscalYear, cur_db.sLastFiscalYear));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadTrialBalanceItemType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool add_all_inventory_item_fl = true, bool exclude_summary_fl = false)
        {
#else
        		public static void LoadTrialBalanceItemType(ref clsDatabase cur_db, ref ComboBox cur_box, bool add_all_inventory_item_fl = true, bool exclude_summary_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            int i = 0;
            bool first_one = false;
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);

            try
            {

                sql_str = "SELECT * FROM tblIVItemType";
                sql_str += " ORDER BY iItem_typ";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                if (add_all_inventory_item_fl)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL_INVENTORY_ITEMS, "0"));
                }
                else
                {
                    item_list.Add(new clsComboBoxItem("", "0"));
                }

                first_one = true;

                while (!cur_set.EOF())
                {

                    if (moUtility.IsNonEmpty(cur_set.sField("sDescription")))
                    {
                        if (cur_set.iField("iItem_typ") == GlobalVar.goIVConstant.REGULAR_ITEM_NUM || cur_set.iField("iItem_typ") == GlobalVar.goIVConstant.SERIAL_ITEM_NUM
                            || cur_set.iField("iItem_typ") == GlobalVar.goIVConstant.LOT_ITEM_NUM || cur_set.iField("iItem_typ") == GlobalVar.goIVConstant.RENTAL_ITEM_NUM
                            || cur_set.iField("iItem_typ") == GlobalVar.goIVConstant.RAW_MATERIAL_ITEM_NUM || cur_set.iField("iItem_typ") == GlobalVar.goIVConstant.WIP_ITEM_NUM)
                        {
                            item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iItem_typ").ToString()));
                            i += 1;
                        }
                        else if ((cur_set.iField("iItem_typ")) >= GlobalVar.goIVConstant.SUMMARY_SALES_ITEM_TYPES)
                        {
                            if (!exclude_summary_fl)
                            {
                                if (first_one)
                                {
                                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oMessage.ACCT_TYPE_DIVIDER, "0"));
                                    first_one = false;
                                }
                                item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iItem_typ").ToString()));
                                i += 1;
                            }
                        }
                    }

                    cur_set.MoveNext();

                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                cur_set.Release();

            }
            catch (Exception ex)
            {

                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadTrialBalanceItemType)");

            }

        }

#if WEB
        public static void LoadAveryLabelNames(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadAveryLabelNames(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_AVERY_5160, cur_db.oLanguage.oString.STR_AVERY_5160));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_AVERY_5160_SINGLE, cur_db.oLanguage.oString.STR_AVERY_5160_SINGLE));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_AVERY_5163, cur_db.oLanguage.oString.STR_AVERY_5163));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_AVERY_5163_SHIPPING, cur_db.oLanguage.oString.STR_AVERY_5163_SHIPPING));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_AVERY_5267, cur_db.oLanguage.oString.STR_AVERY_5267));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_AVERY_5267_SINGLE, cur_db.oLanguage.oString.STR_AVERY_5267_SINGLE));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadJournalType(ref List<Models.clsCombobox> cur_box, int trx_type)
        {
#else
        		public static void LoadJournalType(ref ComboBox cur_box, int trx_type)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));

            if (trx_type == GlobalVar.goConstant.TRX_CM_TYPE)
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.JOURNAL_RETURN_CREDIT_TYPE, clsConstant.JOURNAL_RETURN_CREDIT_TYPE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.JOURNAL_REFUND_TYPE, clsConstant.JOURNAL_REFUND_TYPE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.JOURNAL_REPLACEMENT_TYPE, clsConstant.JOURNAL_REPLACEMENT_TYPE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.JOURNAL_WRITEOFF_TYPE, clsConstant.JOURNAL_WRITEOFF_TYPE_NUM.ToString()));
            }
            else if (trx_type == GlobalVar.goConstant.TRX_DM_TYPE) // Vendor replacement can also be done thru vendor RMA
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.JOURNAL_RETURN_CREDIT_TYPE, clsConstant.JOURNAL_RETURN_CREDIT_TYPE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.JOURNAL_REFUND_TYPE, clsConstant.JOURNAL_REFUND_TYPE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.JOURNAL_REPLACEMENT_TYPE, clsConstant.JOURNAL_REPLACEMENT_TYPE_NUM.ToString()));         // Added 01/08/2021
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.JOURNAL_WRITEOFF_TYPE, clsConstant.JOURNAL_WRITEOFF_TYPE_NUM.ToString()));
            }
            else if (trx_type == GlobalVar.goConstant.TRX_SO_TYPE)
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.JOURNAL_REPLACEMENT_TYPE, clsConstant.JOURNAL_REPLACEMENT_TYPE_NUM.ToString()));
                // item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.JOURNAL_RESEND_TYPE, clsConstant.JOURNAL_RESEND_TYPE_NUM.ToString()));                // This is available only when B2C RMA is implemented, which would not be a case, yet.
            }
            else if (trx_type == GlobalVar.goConstant.TRX_PO_TYPE)
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.JOURNAL_REPLACEMENT_TYPE, clsConstant.JOURNAL_REPLACEMENT_TYPE_NUM.ToString()));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }


#if WEB
        public static void LoadUnpostedMemoStatusType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, int trx_type, bool add_blank_fl)
        {
#else
        		public static void LoadUnpostedMemoStatusType(ref ComboBox cur_box, int trx_type, bool add_blank_fl)
        		{
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

#if WEB
                item_list.Add(new clsComboBoxItem("", ""));
#else
        				if (add_blank_fl)
        				{
        					item_list.Add(new clsComboBoxItem("", "0"));
        				}
#endif
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.OPEN_TRX, GlobalVar.goConstant.OPEN_TRX_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.HOLD_TRX, GlobalVar.goConstant.HOLD_TRX_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.VOID_TRX, GlobalVar.goConstant.VOID_TRX_NUM.ToString()));

                if (trx_type == GlobalVar.goConstant.TRX_CM_TYPE)
                {
                    item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.AWAITING_ARRIVAL_TRX, GlobalVar.goConstant.AWAITING_ARRIVAL_TRX_NUM.ToString()));
                }
                else if (trx_type == GlobalVar.goConstant.TRX_DM_TYPE)
                {
                    item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.AWAITING_SHIPMENT_TRX, GlobalVar.goConstant.AWAITING_SHIPMENT_TRX_NUM.ToString()));
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            }
            catch (Exception ex)
            {

                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadUnpostedMemoStatusType)");

            }

        }

#if WEB
        public static void LoadWarehouseTransaction(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadWarehouseTransaction(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PACKING_SLIP, GlobalVar.goConstant.TRX_SO_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_RMA_SENT_TO_VENDOR, GlobalVar.goConstant.TRX_DM_TYPE.ToString()));

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_PO_RECEIVING, GlobalVar.goConstant.TRX_PO_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_RMA_RECEIVING_FROM_CUSTOMER, GlobalVar.goConstant.TRX_CM_TYPE.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadShippingLabel(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadShippingLabel(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.SHIPPING_LABEL_TYPE_2, clsConstant.SHIPPING_LABEL_TYPE_2_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.SHIPPING_LABEL_TYPE_2_ADDRESS, clsConstant.SHIPPING_LABEL_TYPE_2_ADDRESS_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.SHIPPING_LABEL_TYPE_4, clsConstant.SHIPPING_LABEL_TYPE_4_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.SHIPPING_LABEL_TYPE_2_COMPACT, clsConstant.SHIPPING_LABEL_TYPE_2_COMPACT_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.SHIPPING_LABEL_TYPE_2_ADDRESS_COMPACT, clsConstant.SHIPPING_LABEL_TYPE_2_ADDRESS_COMPACT_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.SHIPPING_LABEL_TYPE_4_COMPACT, clsConstant.SHIPPING_LABEL_TYPE_4_COMPACT_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadContactPointTypes(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadContactPointTypes(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.CONTACT_POINT_TYPE_ACCOUNTING, clsConstant.CONTACT_POINT_TYPE_ACCOUNTING_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.CONTACT_POINT_TYPE_ADMIN, clsConstant.CONTACT_POINT_TYPE_ADMIN_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.CONTACT_POINT_TYPE_HR, clsConstant.CONTACT_POINT_TYPE_HR_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.CONTACT_POINT_TYPE_PAYABLE, clsConstant.CONTACT_POINT_TYPE_PAYABLE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.CONTACT_POINT_TYPE_PURCHASING, clsConstant.CONTACT_POINT_TYPE_PURCHASING_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.CONTACT_POINT_TYPE_RECEIVABLE, clsConstant.CONTACT_POINT_TYPE_RECEIVABLE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.CONTACT_POINT_TYPE_SALES, clsConstant.CONTACT_POINT_TYPE_SALES_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.CONTACT_POINT_TYPE_WAREHOUSE, clsConstant.CONTACT_POINT_TYPE_WAREHOUSE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.CONTACT_POINT_TYPE_OTHER, clsConstant.CONTACT_POINT_TYPE_OTHER_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadColumnSizeCSS(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadColumnSizeCSS(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.COLUMN_CSS_STD, clsConstant.COLUMN_CSS_STD_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.COLUMN_CSS_MIN, clsConstant.COLUMN_CSS_MIN_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.COLUMN_CSS_MAX, clsConstant.COLUMN_CSS_MAX_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.COLUMN_CSS_SERVICE, clsConstant.COLUMN_CSS_SERVICE_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadARStatementGroupCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadARStatementGroupCode(ref ComboBox cur_box, bool addnew_flag = true)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sStatementGroup_cd";
            sql_str += " FROM tblARStatementGroup";
            sql_str += " ORDER BY sStatementGroup_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sStatementGroup_cd"), cur_set.sField("sStatementGroup_cd")));
                cur_set.MoveNext();
            }

#if !WEB
        			if (IsLiteVersion() && addnew_flag)
        			{
        				item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ADDNEW, cur_db.oLanguage.oString.STR_ADDNEW));
        			}
#endif

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadStatementPeriod(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string cur_year, bool format_value_fl = false, bool for_print_fl = false)
        {
#else
        		public static void LoadStatementPeriod(ref ComboBox cur_box, string cur_year, bool format_value_fl = false, bool for_print_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string value_text = "";
            int i = 0;
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

            try
            {

#if WEB
                cur_set = new clsRecordset(ref cur_db);
                o_gen = new clsGeneral(ref cur_db);
#else
        				cur_set = new clsRecordset(goDatabase);
        				o_gen = new clsGeneral(goDatabase);
#endif

                sql_str = "SELECT * FROM tblARStatementPeriod";
                if (for_print_fl)
                {
                    sql_str += " WHERE iPeriodEnd_dt < " + o_gen.CurrentDate().ToString();      // Do not use <=. Printing has to be at least one-day after month-close.
                    sql_str += " AND iPeriodBegin_dt >= " + moUtility.AddToDate(GlobalVar.goConstant.YEAR_TYPE, o_gen.CurrentDate(), -1).ToString();
                }
                sql_str += " ORDER BY iPeriodEnd_dt DESC";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                if (!for_print_fl || cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem("", ""));
                }

                while (!cur_set.EOF())
                {
                    value_text = moUtility.IIf(format_value_fl, o_gen.ToStrDate(cur_set.iField("iPeriodBegin_dt")), cur_set.iField("iPeriodBegin_dt").ToString());
                    item_list.Add(new clsComboBoxItem(o_gen.ToStrDate(cur_set.iField("iPeriodBegin_dt")) + GlobalVar.goConstant.ID_DELIMITER + o_gen.ToStrDate(cur_set.iField("iPeriodEnd_dt")), value_text));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                modGeneralUtility.MouseDefault();
                cur_set.Release();

            }
            catch (Exception ex)
            {

                cur_set.Release();
                modGeneralUtility.MouseDefault();

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadStatementPeriod)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadStatementPeriod)");
#endif

            }

        }

#if WEB
        public static void LoadStatementPeriodBegin(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string cur_year, bool format_value_fl = false)
        {
#else
        		public static void LoadStatementPeriodBegin(ref ComboBox cur_box, string cur_year, bool format_value_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            int i = 0;
            string value_text = "";

            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

            try
            {

#if WEB
                cur_set = new clsRecordset(ref cur_db);
                o_gen = new clsGeneral(ref cur_db);
#else
        				cur_set = new clsRecordset(goDatabase);
        				o_gen = new clsGeneral(goDatabase);
#endif

                sql_str = "SELECT * FROM tblARStatementPeriod";
                sql_str += " WHERE iPeriodBegin_dt <= " + o_gen.CurrentDate().ToString(); // Include the current month for up-to date statement
                sql_str += " AND iPeriodBegin_dt >= " + moUtility.AddToDate(GlobalVar.goConstant.YEAR_TYPE, o_gen.CurrentDate(), -1).ToString();
                sql_str += " ORDER BY iPeriodBegin_dt DESC";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                while (!cur_set.EOF())
                {
                    value_text = moUtility.IIf(format_value_fl, o_gen.ToStrDate(cur_set.iField("iPeriodBegin_dt")), cur_set.iField("iPeriodBegin_dt").ToString());
                    item_list.Add(new clsComboBoxItem(o_gen.ToStrDate(cur_set.iField("iPeriodBegin_dt")), value_text));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                modGeneralUtility.MouseDefault();
                cur_set.Release();

            }
            catch (Exception ex)
            {

                cur_set.Release();
                modGeneralUtility.MouseDefault();

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadStatementPeriodBegin)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadStatementPeriodBegin)");
#endif

            }

        }

#if WEB
        public static void LoadStatementPeriodEnd(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string cur_year, bool format_value_fl = false)
        {
#else
        		public static void LoadStatementPeriodEnd(ref ComboBox cur_box, string cur_year, bool format_value_fl = false)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string value_text = "";
            int i = 0;
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

            try
            {

#if WEB
                cur_set = new clsRecordset(ref cur_db);
                o_gen = new clsGeneral(ref cur_db);
#else
        				cur_set = new clsRecordset(goDatabase);
        				o_gen = new clsGeneral(goDatabase);
#endif

                sql_str = "SELECT * FROM tblARStatementPeriod";
                sql_str += " WHERE iPeriodBegin_dt <= " + o_gen.CurrentDate().ToString(); // Include the current month for up-to date statement
                sql_str += " AND iPeriodBegin_dt >= " + moUtility.AddToDate(GlobalVar.goConstant.YEAR_TYPE, o_gen.CurrentDate(), -1).ToString();
                sql_str += " ORDER BY iPeriodEnd_dt DESC";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                while (!cur_set.EOF())
                {
                    value_text = moUtility.IIf(format_value_fl, o_gen.ToStrDate(cur_set.iField("iPeriodEnd_dt")), cur_set.iField("iPeriodEnd_dt").ToString());
                    item_list.Add(new clsComboBoxItem(o_gen.ToStrDate(cur_set.iField("iPeriodEnd_dt")), value_text));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                modGeneralUtility.MouseDefault();
                cur_set.Release();

            }
            catch (Exception ex)
            {

                cur_set.Release();
                modGeneralUtility.MouseDefault();

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadStatementPeriodEnd)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadStatementPeriodEnd)");
#endif

            }

        }
#if WEB
        public static void LoadSplitPaymentFrequency(ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadSplitPaymentFrequency(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.PAYMENT_FREQUENCY_WEEKLY, GlobalVar.goConstant.PAYMENT_FREQUENCY_WEEKLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.PAYMENT_FREQUENCY_BIWEEKLY, GlobalVar.goConstant.PAYMENT_FREQUENCY_BIWEEKLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.PAYMENT_FREQUENCY_MONTHLY, GlobalVar.goConstant.PAYMENT_FREQUENCY_MONTHLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.PAYMENT_FREQUENCY_BIMONTHLY, GlobalVar.goConstant.PAYMENT_FREQUENCY_BIMONTHLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.PAYMENT_FREQUENCY_QUARTERLY, GlobalVar.goConstant.PAYMENT_FREQUENCY_QUARTERLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.PAYMENT_FREQUENCY_SEMIYEARLY, GlobalVar.goConstant.PAYMENT_FREQUENCY_SEMIYEARLY_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.PAYMENT_FREQUENCY_YEARLY, GlobalVar.goConstant.PAYMENT_FREQUENCY_YEARLY_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

#if WEB
        public static void LoadIEExpenseCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool foreign_fl)
        {
#else
        		public static void LoadIEExpenseCode(ref ComboBox cur_box, bool foreign_fl)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT * FROM tblIEExpense";
            if (foreign_fl)
            {
                sql_str += " WHERE iForeign_fl = 1";
            }
            else
            {
                sql_str += " WHERE iForeign_fl = 0";
            }
            sql_str += " ORDER BY sExpense_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(cur_set.sField("sExpense_cd")))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.sField("sExpense_cd")));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadIEExpenseType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadIEExpenseType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));

            sql_str = "SELECT * FROM tblIEExpenseType";
            sql_str += " ORDER BY iExpense_typ";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {

                if (cur_set.iField("iExpense_typ") > 0)
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sDescription"), cur_set.iField("iExpense_typ").ToString()));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

#if WEB
        public static void LoadPurchaseRequisitionType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadPurchaseRequisitionType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0")); // Needed for searching

                item_list.Add(new clsComboBoxItem(GlobalVar.goPOConstant.PURCHASE_REQUISITION_TYPE, GlobalVar.goPOConstant.PURCHASE_REQUISITION_TYPE_NUM.ToString()));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadPurchaseRequisitionStatusType)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadPurchaseRequisitionStatusType)");
#endif
                return;

            }

        }

#if WEB
        public static void LoadProcurementType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadProcurementType(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0")); // Needed for searching

                item_list.Add(new clsComboBoxItem(GlobalVar.goPOConstant.REQUEST_FOR_PROPOSAL_TYPE, GlobalVar.goPOConstant.REQUEST_FOR_PROPOSAL_TYPE_NUM.ToString()));
                item_list.Add(new clsComboBoxItem(GlobalVar.goPOConstant.REQUEST_FOR_QUOTE_TYPE, GlobalVar.goPOConstant.REQUEST_FOR_QUOTE_TYPE_NUM.ToString()));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadPurchaseRequisitionStatusType)");
#else
        				modDialogUtility.DisplayBox(ex.Message + "(LoadPurchaseRequisitionStatusType)");
#endif
                return;

            }

        }

        public static void LoadDatabaseStatus(ref List<Models.clsCombobox> cur_box)
        {
            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.DATABASE_STATUS_TEST, clsConstant.DATABASE_STATUS_TEST_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.DATABASE_STATUS_HOLD, clsConstant.DATABASE_STATUS_HOLD_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.DATABASE_STATUS_PRODUCTION, clsConstant.DATABASE_STATUS_PRODUCTION_NUM.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
        }


#if WEB
        public static void LoadDatabaseName(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadDatabaseName(ref clsDatabase cur_db, ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
#endif

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT * FROM sys.databases ";
            sql_str += " WHERE name NOT IN ('master', 'model', 'msdb', 'tempdb')";
            sql_str += " AND name NOT LIKE 'ReportServer%'";
            sql_str += " ORDER BY name";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("name"), cur_set.sField("name")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }
#if WEB
        public static void LoadSegment(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, int level_num, bool add_blank_fl = false)
        {
#else
            public static void LoadSegment(ref ComboBox cur_box, bool add_blank_fl = false)
            {
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        			cur_set = new clsRecordset(goDatabase);
        			o_gen = new clsGeneral(goDatabase);
#endif

            try
            {
                cur_box.Clear();

                sql_str = "SELECT * FROM tblGLSegment WHERE iSegmentLevel = " + level_num.ToString();
                sql_str += " ORDER BY sSegment_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                if (add_blank_fl)
                {
                    item_list.Add(new clsComboBoxItem("", "0"));
                }

                while (!cur_set.EOF())
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sSegment_cd"), Convert.ToString(cur_set.sField("sSegment_cd"))));
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadSegment)");
            }

        }

#if WEB
        public static void LoadGLListing(ref List<Models.clsCombobox> cur_box, bool fund_account_fl)
        {
#else
        		public static void LoadGLListing(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            try
            {
                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0"));
                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.ACCT_CODE_LISTING, "1"));
                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.BUDGET_LISTING, "2"));
                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.JOURNAL_CODE_LISTING, "3"));
                item_list.Add(new clsComboBoxItem(GlobalVar.goGLConstant.PERIOD_LISTING, "4"));
                if (fund_account_fl)
                {
                    item_list.Add(new clsComboBoxItem(GlobalVar.goNPConstant.FUND_LISTING, "5"));
                    item_list.Add(new clsComboBoxItem(GlobalVar.goNPConstant.FUND_GROUP_LISTING, "6"));
                    item_list.Add(new clsComboBoxItem(GlobalVar.goNPConstant.DUE_ACCOUNT_LISTING, "7"));
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            }
            catch (Exception ex)
            {

            }

        }

#if WEB
        public static void LoadBatchNumbers(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string user_cd)
        {
#else
	public static void LoadBatchNumbers(ref clsDatabase cur_db, ref ComboBox cur_box, string user_cd)
	{
#endif

            clsRecordset cur_set = new clsRecordset(ref cur_db);
            ArrayList item_list = new ArrayList();
            string sql_str = null;
            string filler = null;

            if (!cur_db.bEnableBatchEntry_fl)
            {
                return;
            }

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            //goPlatinum.DeleteBatch(ref cur_db, cur_db.sUser_cd, 0, 0)       ' 0, 0 This will delete phantom batch created by s/o, p/o, b/r, etc...

            sql_str = "SELECT * FROM tblGOBatch";
            if (user_cd == cur_db.sUser_cd && cur_db.iUserType_id >= clsConstant.USER_SUPERVISOR_TYPE)
            {
                // Show all
            }
            else
            {
                sql_str += " WHERE sUser_cd = '" + user_cd + "'";
            }
            sql_str += " ORDER BY sUser_cd, iBatch_num";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            if (cur_set.RecordCount() > 1)
            {
                item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ALL, GlobalVar.goConstant.FOR_ALL_NUM.ToString()));
            }

            filler = moUtility.Space(5);

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sUser_cd") + GlobalVar.goConstant.ID_DELIMITER + filler + cur_set.iField("iBatch_num").ToString(), cur_set.iField("iBatch_num").ToString()));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

        public static void LoadUnitCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
            ArrayList item_list = new ArrayList();
            string sql_str = null;
            string last_code = null;
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;
            string[] unit_codes = null;
            int i = 0;

            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            sql_str = "SELECT sFromUnit_cd, sToUnit_cd FROM tblGOUnit";
            sql_str += " ORDER BY sFromUnit_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            if (cur_set.RecordCount() > 0)
            {

                moUtility.ResizeDim(ref unit_codes, (cur_set.RecordCount() * 2 - 1));

                i = 0;

                while (!cur_set.EOF())
                {

                    unit_codes[i] = cur_set.sField("sFromUnit_cd");
                    unit_codes[i + 1] = cur_set.sField("sToUnit_cd");

                    i += 2;
                    cur_set.MoveNext();

                }

                moUtility.QuickSort1(ref unit_codes);

                last_code = "";

                for (i = 0; i <= unit_codes.GetUpperBound(0); i++)
                {

                    if (moUtility.IsNonEmpty(unit_codes[i]) & unit_codes[i] != last_code)
                    {
                        item_list.Add(new clsComboBoxItem(unit_codes[i], unit_codes[i]));
                        last_code = unit_codes[i];
                    }

                }

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
        }

#if WEB
        public static void LoadPrimaryItemCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        public static void LoadPrimaryItemCode(ref ComboBox cur_box)
        {
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
        	cur_set = new clsRecordset(goDatabase);
        	o_gen = new clsGeneral(goDatabase);
#endif

            sql_str = "SELECT sItem_cd FROM tblIVItem WHERE iItem_typ >= " + GlobalVar.goIVConstant.SUMMARY_SALES_ITEM_TYPES.ToString();
            sql_str += " ORDER BY sItem_cd";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            cur_box.Clear();
            item_list.Add(new clsComboBoxItem("", ""));

            while (!cur_set.EOF())
            {

                if (moUtility.IsNonEmpty(moUtility.STrim(cur_set.sField("sItem_cd"))))
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sItem_cd").ToString(), cur_set.sField("sItem_cd").ToString()));
                }

                cur_set.MoveNext();

            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

#if WEB
        public static void LoadExtraWageCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, string employee_code = "")
        {
#else
            		public static void LoadAllDeductions(ref ComboBox cur_box)
            		{
#endif

            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = null;
            clsGeneral o_gen = null;

#if WEB
            cur_set = new clsRecordset(ref cur_db);
            o_gen = new clsGeneral(ref cur_db);
#else
            			cur_set = new clsRecordset(goDatabase);
            			o_gen = new clsGeneral(goDatabase);
#endif

            cur_box.Clear();

#if WEB
            if (moUtility.IsEmpty(employee_code))
            {
                item_list.Add(new clsComboBoxItem("", ""));
            }
#endif

            sql_str = "SELECT w.sWage_cd, w.mWage_amt, w.iWage_typ, w.iModifiable_fl, w.sDescription";
            sql_str += " FROM tblPRExtraWage w";

            if (moUtility.IsNonEmpty(employee_code))
            {
                sql_str += " INNER JOIN tblPREmployeeExtraWage e ON (e.sWage_cd = w.sWage_cd)";
                sql_str += " WHERE e.sEmployee_cd = '" + employee_code + "'";
            }

            sql_str += " ORDER BY w.sWage_cd";
            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sWage_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sWage_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            cur_set.Release();

        }

        public static void LoadHours(ref List<Models.clsCombobox> cur_box)
        {
            ArrayList item_list = new ArrayList();
            int i = 0;

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            for (i = 1; i <= 12; i++)
            {
                item_list.Add(new clsComboBoxItem(i.ToString(), i.ToString()));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

        public static void LoadMinutes(ref List<Models.clsCombobox> cur_box)
        {
            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            // item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem("00", "00"));
            item_list.Add(new clsComboBoxItem("10", "10"));
            item_list.Add(new clsComboBoxItem("20", "20"));
            item_list.Add(new clsComboBoxItem("30", "30"));
            item_list.Add(new clsComboBoxItem("40", "40"));
            item_list.Add(new clsComboBoxItem("50", "50"));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
        }

        public static void LoadAMPM(ref List<Models.clsCombobox> cur_box)
        {
            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem("AM", "AM"));
            item_list.Add(new clsComboBoxItem("PM", "PM"));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
        }


#if WEB
        public static void LoadJobDates(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        		public static void LoadWorkOrderDates(ref ComboBox cur_box)
        		{
#endif

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.DATE_ESTIMATED_TO_START, "iExpectedFrom_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.DATE_ESTIMATED_TO_COMPLETE, "iExpectedThru_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.DATE_STARTED, "iActualFrom_dt"));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.DATE_COMPLETED, "iActualThru_dt"));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }


        public static void LoadListingBy(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, int trx_type, Models.clsUser cur_user)
        {

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.TRANSACTION, "iTransaction_num"));
            item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.TRANSACTION + " " + cur_user.Language.oCaption.DESCENDING, "iTransaction_num DESC"));

            item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.ENTRY_DATE, "iEntry_dt, iTransaction_num"));
            item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.ENTRY_DATE + " " + cur_user.Language.oCaption.DESCENDING, "iEntry_dt DESC, iTransaction_num"));

            if (trx_type == GlobalVar.goConstant.TRX_QUOTE_TYPE)
            {
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.DATE_APPROVED, "iApply_dt, iTransaction_num"));
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.DATE_APPROVED + " " + cur_user.Language.oCaption.DESCENDING, "iApply_dt DESC, iTransaction_num"));
            }
            else
            {
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.APPLY_DATE, "iApply_dt, iTransaction_num"));
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.APPLY_DATE + " " + cur_user.Language.oCaption.DESCENDING, "iApply_dt DESC, iTransaction_num"));
            }

            if (trx_type == GlobalVar.goConstant.TRX_INVOICE_TYPE || trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE)
            {
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.DUE_DATE, "iDue_dt, iTransaction_num"));
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.DUE_DATE + " " + cur_user.Language.oCaption.DESCENDING, "iApply_dt DESC, iTransaction_num"));
            }


            if (trx_type == GlobalVar.goConstant.TRX_QUOTE_TYPE || trx_type == GlobalVar.goConstant.TRX_SO_TYPE || trx_type == GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE || trx_type == GlobalVar.goConstant.TRX_PO_TYPE)
            {
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.DATE_REQUIRED, "iRequired_dt, iTransaction_num"));
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.DATE_REQUIRED + " " + cur_user.Language.oCaption.DESCENDING, "iRequired_dt DESC, iTransaction_num"));
            }

            if (trx_type == GlobalVar.goConstant.TRX_QUOTE_TYPE || trx_type == GlobalVar.goConstant.TRX_SO_TYPE || trx_type == GlobalVar.goConstant.TRX_INVOICE_TYPE || trx_type == GlobalVar.goConstant.TRX_CM_TYPE
                || trx_type == GlobalVar.goConstant.TRX_RECEIPT_TYPE || trx_type == GlobalVar.goConstant.TRX_NSF_TYPE)
            {
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.CUSTOMER_CODE, "sCustomer_cd, iTransaction_num"));
                //item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.CUSTOMER_CODE + " " + cur_user.Language.oCaption.DESCENDING, "sCustomer_cd DESC, iTransaction_num"));

                if (trx_type != GlobalVar.goConstant.TRX_RECEIPT_TYPE && trx_type != GlobalVar.goConstant.TRX_NSF_TYPE)
                {
                    item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.CUSTOMER_NAME, "sCustomer_nm, iTransaction_num"));
                    //item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.CUSTOMER_NAME + " " + cur_user.Language.oCaption.DESCENDING, "sCustomer_nm DESC, iTransaction_num"));

                    item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.SALESREP, "sSalesrep_cd, iTransaction_num"));
                    //item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.SALESREP + " " + cur_user.Language.oCaption.DESCENDING, "sSalesrep_cd DESC, iTransaction_num"));
                }
            }
            else if (trx_type == GlobalVar.goConstant.TRX_PO_TYPE || trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE || trx_type == GlobalVar.goConstant.TRX_DM_TYPE
                || trx_type == GlobalVar.goConstant.TRX_PAYMENT_TYPE || trx_type == GlobalVar.goConstant.TRX_STOP_PAYMENT_TYPE)
            {
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.VENDOR_CODE, "sVendor_cd, iTransaction_num"));
                //item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.VENDOR_CODE + " " + cur_user.Language.oCaption.DESCENDING, "sVendor_cd DESC, iTransaction_num"));

                if (trx_type != GlobalVar.goConstant.TRX_PAYMENT_TYPE && trx_type != GlobalVar.goConstant.TRX_STOP_PAYMENT_TYPE)
                {
                    item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.VENDOR_NAME, "sVendor_nm, iTransaction_num"));
                    //item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.VENDOR_NAME + " " + cur_user.Language.oCaption.DESCENDING, "sVendor_nm DESC, iTransaction_num"));

                    item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.PURCHASE_AGENT, "sAgent_cd, iTransaction_num"));
                    //item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.PURCHASE_AGENT + " " + cur_user.Language.oCaption.DESCENDING, "sAgent_cd DESC, iTransaction_num"));
                }
            }
            else if (trx_type == GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE)
            {
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.DEPARTMENT_CODE, "sDepartment_cd, iTransaction_num"));
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.JOBPROJECT_CODE, "sJob_cd, iTransaction_num"));
            }

            item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.STATUS, "iStatus_typ, iTransaction_num"));

            if (trx_type == GlobalVar.goConstant.TRX_INVOICE_TYPE || trx_type == GlobalVar.goConstant.TRX_CM_TYPE || trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE || trx_type == GlobalVar.goConstant.TRX_DM_TYPE)
            {
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.AMOUNT, "mTotal_amt, iTransaction_num"));
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.AMOUNT_DUE, "mDue_amt, iTransaction_num"));
            }
            else if (trx_type == GlobalVar.goConstant.TRX_QUOTE_TYPE || trx_type == GlobalVar.goConstant.TRX_SO_TYPE || trx_type == GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE || trx_type == GlobalVar.goConstant.TRX_PO_TYPE)
            {
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.AMOUNT, "mTotal_amt, iTransaction_num"));
            }
            else if (trx_type == GlobalVar.goConstant.TRX_RECEIPT_TYPE || trx_type == GlobalVar.goConstant.TRX_PAYMENT_TYPE)
            {
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.AMOUNT_PAID, "mPaid_amt, iTransaction_num"));
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.AMOUNT_USED, "mUsed_amt, iTransaction_num"));
            }
            else if (trx_type == GlobalVar.goConstant.TRX_STOP_PAYMENT_TYPE || trx_type == GlobalVar.goConstant.TRX_NSF_TYPE)
            {
                item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.AMOUNT, "mPaid_amt, iTransaction_num"));
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
        }


        public static void LoadItemCodeSeparator(Models.clsUser cur_user, ref List<Models.clsCombobox> cur_box)
        {

            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem(".", "."));
            item_list.Add(new clsComboBoxItem("-", "-"));
            item_list.Add(new clsComboBoxItem("/", "/"));
            item_list.Add(new clsComboBoxItem(cur_user.Language.oString.STR_NONE, cur_user.Language.oString.STR_NONE));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
        }

        public static void LoadCalendarYear(ref List<Models.clsCombobox> cur_box)
        {
            int current_year = 0;
            int num = 0;

            ArrayList item_list = new ArrayList();

            current_year = moUtility.ToInteger(moUtility.SFormat(DateTime.Now, "yyyy"));

            cur_box.Clear();

            for (num = 0; num < 10; num++)
            {
                item_list.Add(new clsComboBoxItem("since " + (current_year - num).ToString(), (current_year - num).ToString()));
            }

            item_list.Add(new clsComboBoxItem("All", "0"));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

        public static void LoadItemBin(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, Models.clsUser cur_user, string location_cd, string item_cd)
        {
            ArrayList item_list = new ArrayList();
            string sql_str = "";

            clsRecordset cur_set = new clsRecordset(ref cur_db);

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            // 03/05/2022  tblIVLocationBinYard is merged to tblIVLocationBin
            //
            sql_str = "SELECT sBin_cd FROM tblIVLocationBin";
            sql_str += " WHERE sLocation_cd = '" + location_cd + "'";
            sql_str += " AND sItem_cd = '" + item_cd + "'";
            sql_str += " ORDER BY sBin_cd";
            if (cur_set.CreateSnapshot(sql_str) == false)
            {
                return;
            }
            while (cur_set.EOF() == false)
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sBin_cd") , cur_set.sField("sBin_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

        public static void LoadReturnTransactionType(Models.clsUser cur_user, ref List<Models.clsCombobox> cur_box)
        {
            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem("", ""));
            //item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.CREDIT_MEMO, GlobalVar.goConstant.TRX_CM_TYPE.ToString()));
            item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.RENTAL_RETURN, GlobalVar.goConstant.TRX_FA_RENTAL_RETURN_TYPE.ToString()));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
        }

        public static void LoadFreeMonths(Models.clsUser cur_user, ref List<Models.clsCombobox> cur_box)
        {
            ArrayList item_list = new ArrayList();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.FREE_MONTH_HALF, "0.5")); 
            item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.FREE_MONTH_ONE, "1")); 
            item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.FREE_MONTH_ONE_HALF, "1.5")); 
            item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.FREE_MONTH_TWO, "2")); 
            item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.FREE_MONTH_TWO_HALF, "2.5")); 
            item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.FREE_MONTH_THREE, "3")); 
            item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.FREE_MONTH_FOUR, "4")); 
            item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.FREE_MONTH_FIVE, "5")); 
            item_list.Add(new clsComboBoxItem(cur_user.Language.oCaption.FREE_MONTH_SIX, "6"));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
        }


        public static void LoadRentalPromoCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool valid_only = true)
        {
            ArrayList item_list = new ArrayList();
            string sql_str = "";

            clsGeneral o_gen = new clsGeneral(ref cur_db);
            clsRecordset cur_set = new clsRecordset(ref cur_db);

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));

            // 03/05/2022  tblIVLocationBinYard is merged to tblIVLocationBin
            //
            sql_str = "SELECT * FROM tblFAPromo";

            if (valid_only)
            {
                sql_str += " WHERE iExpired_fl = 0";
                sql_str += " AND (iEnd_dt = 0 OR iEnd_dt >= " + o_gen.CurrentDate().ToString() + ")";   // Do not worry about the promo start day
            }

            sql_str += " ORDER BY sPromo_cd";
            if (cur_set.CreateSnapshot(sql_str) == false)
            {
                return;
            }
            while (cur_set.EOF() == false)
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sPromo_cd") + " " + GlobalVar.goConstant.ITEM_CODE_SEPARATOR + " " + cur_set.sField("sDescription"), cur_set.sField("sPromo_cd")));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

        }

        // This function should work with
        //       GetQuoteStatusType() and GetQuoteStatusTypeNum()
        //
#if WEB
        public static void LoadPurchaseQuoteStatusType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
#else
        public static void LoadPurchaseQuoteStatusType(ref ComboBox cur_box)
        {
#endif

            ArrayList item_list = new ArrayList();

            try
            {

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "0")); // Needed for searching

                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.OPEN_TRX, Convert.ToString(GlobalVar.goConstant.OPEN_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.HOLD_TRX, Convert.ToString(GlobalVar.goConstant.HOLD_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.VOID_TRX, Convert.ToString(GlobalVar.goConstant.VOID_TRX_NUM)));
                item_list.Add(new clsComboBoxItem(GlobalVar.goConstant.ORDERED_TRX, Convert.ToString(GlobalVar.goConstant.ORDERED_TRX_NUM)));

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

                return;

            }
            catch (Exception ex)
            {

#if WEB
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadPurchaseQuoteStatusType)");
#else
            	modDialogUtility.DisplayBox(ex.Message + "(LoadPurchaseQuoteStatusType)");
#endif
                return;

            }

        }

        public static bool loadSalesSupervisorCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
            bool return_value = false;
            string sql_str = "SELECT DISTINCT sManager_cd FROM tblARSalesRep WHERE sManager_cd <> '' ORDER BY sManager_cd";
            clsRecordset cur_set = new clsRecordset(ref cur_db);
            ArrayList item_list = new ArrayList();

            try
            {
                if (cur_set.CreateSnapshot(sql_str) == false)
                {
                    return false;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", "")); 

                while (cur_set.EOF() == false)
                {
                    item_list.Add(new clsComboBoxItem(cur_set.sField("sManager_cd"), cur_set.sField("sManager_cd"))); 
                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                return_value = true;
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(loadSalesSupervisorCode)");
            }

            return return_value;
        }

        public static void LoadJobRentalItemCode(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = new clsRecordset(ref cur_db);

            try
            {
                sql_str = "SELECT sRentalItem_cd, sDescription FROM tblJCRentalItem";
                sql_str += " ORDER BY sRentalItem_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                while (!cur_set.EOF())
                {
                    if (moUtility.IsNonEmpty(cur_set.sField("sRentalItem_cd")))
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sRentalItem_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sRentalItem_cd")));
                    }

                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadJobRentalItemCode)");
            }
        }

        public static void LoadGeneralListingRange(ref List<Models.clsCombobox> cur_box)
        {

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("All Entries", "0"));
            item_list.Add(new clsComboBoxItem("last 30 days", "30"));
            item_list.Add(new clsComboBoxItem("last 60 days", "60"));
            item_list.Add(new clsComboBoxItem("last 90 days", "90"));
            item_list.Add(new clsComboBoxItem("last 120 days", "120"));
            item_list.Add(new clsComboBoxItem("for last 1 year", "365"));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);


        }


        public static void BankImportFileType(ref List<Models.clsCombobox> cur_box)
        {

            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", ""));
            item_list.Add(new clsComboBoxItem("QuickBooks(QBO)", Models.clsBankReconciliation.BANK_FILE_TYPE_QBO));
            item_list.Add(new clsComboBoxItem("Quicken(QFX)", Models.clsBankReconciliation.BANK_FILE_TYPE_QFX));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
        }

        public static void LoadBOM(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, int wo_num = 0)
        {
            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = new clsRecordset(ref cur_db);

            try
            {
                sql_str = "SELECT sItem_cd, sDescription FROM tblMFBOM";
                if (wo_num > 0)
                {
                    sql_str += " WHERE sItem_cd IN (SELECT sItem_cd FROM tblWOTransactionDet ";
                    sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_WO_TYPE.ToString();
                    sql_str += " AND iTransaction_num = " + wo_num.ToString();
                    sql_str += " AND iLine_typ = " + GlobalVar.goWOConstant.LINE_TYPE_TO_MFG_NUM.ToString() + ")";
                }
                sql_str += " ORDER BY sItem_cd";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    return;
                }

                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                while (!cur_set.EOF())
                {
                    if (moUtility.IsNonEmpty(cur_set.sField("sItem_cd")))
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sItem_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription"), cur_set.sField("sItem_cd")));
                    }

                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadBOM)");
            }
        }

        public static void LoadBOMLineInWorkOrder(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, int wo_num, int line_type)
        {
            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = new clsRecordset(ref cur_db);

            try
            {
                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = "SELECT * FROM tblWOTransactionDet ";
                sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_WO_TYPE.ToString();
                sql_str += " AND iTransaction_num = " + wo_num.ToString();

                if (line_type == GlobalVar.goWOConstant.LINE_TYPE_TO_MFG_NUM)
                {
                    sql_str += " AND iLine_typ = " + GlobalVar.goWOConstant.LINE_TYPE_TO_MFG_NUM.ToString();
                    sql_str += " AND sItem_cd IN (SELECT sItem_cd FROM tblMFBOM)";
                }
                else
                {
                    sql_str += " AND iLine_typ = " + GlobalVar.goWOConstant.LINE_TYPE_TO_ASSEMBLE_NUM.ToString();
                }

                sql_str += " ORDER BY iDetail_num";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                    return;
                }

                while (!cur_set.EOF())
                {
                    if (moUtility.IsNonEmpty(cur_set.sField("sItem_cd")))
                    {
                        // Item code should come first in the text.
                        //
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sItem_cd") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sDescription") + " on line# " + cur_set.iField("iLine_id").ToString(), cur_set.iField("iLine_id").ToString()));
                    }

                    cur_set.MoveNext();
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadBOMLineInWorkOrder)");
            }
        }

        public static void LoadWOLineType(ref List<Models.clsCombobox> cur_box)
        {
            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem("", "0"));
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.LINE_TYPE_TO_ASSEMBLE, GlobalVar.goWOConstant.LINE_TYPE_TO_ASSEMBLE_NUM.ToString()));
            item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.LINE_TYPE_TO_MFG, GlobalVar.goWOConstant.LINE_TYPE_TO_MFG_NUM.ToString()));
            //item_list.Add(new clsComboBoxItem(GlobalVar.goWOConstant.LINE_TYPE_TO_PURCHASE, GlobalVar.goWOConstant.LINE_TYPE_TO_PURCHASE_NUM.ToString()));  This has a separate order type

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
        }

        public static void LoadARStatementType(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box)
        {
            ArrayList item_list = new ArrayList();

            cur_box.Clear();

            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.MONTHLY_STATEMENT, cur_db.oLanguage.oCaption.MONTHLY_STATEMENT));
            item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oCaption.AD_HOC, cur_db.oLanguage.oCaption.AD_HOC));

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
        }

        public static void LoadCCN(ref clsDatabase cur_db, ref List<Models.clsCombobox> cur_box, bool addnew_flag = false)
        {
            ArrayList item_list = new ArrayList();
            string sql_str = "";
            clsRecordset cur_set = new clsRecordset(ref cur_db);

            try
            {
                cur_box.Clear();

                item_list.Add(new clsComboBoxItem("", ""));

                sql_str = "SELECT * FROM tblGOCCN ORDER BY sCCN";

                if (!cur_set.CreateSnapshot(sql_str))
                {
                    modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
                    return;
                }

                while (!cur_set.EOF())
                {
                    if (moUtility.IsNonEmpty(cur_set.sField("sCCN")))
                    {
                        item_list.Add(new clsComboBoxItem(cur_set.sField("sCCN") + GlobalVar.goConstant.ID_DELIMITER + cur_set.sField("sCompany_nm"), cur_set.sField("sCCN")));
                    }

                    cur_set.MoveNext();
                }

                if (addnew_flag)
                {
                    item_list.Add(new clsComboBoxItem(cur_db.oLanguage.oString.STR_ADDNEW, cur_db.oLanguage.oString.STR_ADDNEW));
                }

                modWebLoadUtility.LoadComboBox(ref cur_box, item_list);
            }
            catch (Exception ex)
            {
                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LoadCCN)");
            }
        }


    }
}
