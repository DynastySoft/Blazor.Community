﻿//  Copyright (c) DynastySoft Corporation, 2011.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//

using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Drawing;
// using System.Windows.Forms;

using Dynasty.Local;
using Dynasty.Database;

namespace Dynasty.ASP
{
	public class clsCustomReport
	{

		// -----------------------------------------------------------------------------------------
		// This object is to generate the data for custom report.
		// -----------------------------------------------------------------------------------------

		public string sFund_cd;

		private const int SUMMARY_PROCESS_ID = 1000;
		private const int CONSOLIDATION_PROCESS_ID = 2000;

		public struct udtGLFinancialType
		{

			public string[,] sGroupFormula;

            public int FORMULA_COL { get { return 0; } }
            public int DESCRIPTION_COL { get { return 1; } }
            public int GROUP_TYPE_COL { get { return 2; } }
            public int GROUP_NUM_COL { get { return 3; } }

            public int SUMMARY_LINE { get { return 1; } }
            public int DETAIL_LINE { get { return 2; } }
            public int FUNCTION_SUM_TYPE { get { return 1; } }
            public int FUNCTION_AVG_TYPE { get { return 2; } }
            public int FUNCTION_BEGINNING_BALANCE_TYPE { get { return 3; } }
            public int FUNCTION_ENDING_BALANCE_TYPE { get { return 4; } }
            public int AMOUNT_NET_TYPE { get { return 1; } }
            public int AMOUNT_CREDIT_TYPE { get { return 2; } }
            public int AMOUNT_DEBIT_TYPE { get { return 3; } }
            public int AMOUNT_BALANCE_TYPE { get { return 4; } }
            public int REPORT_ACTIVITY_TYPE { get { return 1; } }
            public int REPORT_BALANCE_TYPE { get { return 2; } }

			public bool bSummaryOnly_fl;
			public bool bConsolidated_fl;

		}

		public udtGLFinancialType uGLFinancial;

		private string sReport_cd;
		private int iCurrentDatabase_typ;
		private int iPeriodBegin_dt;
		private int iPeriodEnd_dt;

		// THESE ARE DB CONNECTION-RELATED VARS THAT ALL CLASSES MUST CARRY FROM NOW ON 08/20/2011.
		//
		private bool bConnected_fl;
		private clsDatabase oDatabase = new clsDatabase();

		// General objects that are used acrossed modules.
		// These are database-dependant.
		//
		private clsGeneral oGeneral;
		private clsValidate oValidate;
		private clsMoney oMoney;
		private clsPostIV oPostIV;
		private clsPostGL oPostGL;
		private clsDynastyUtility oUtility;

		public clsCustomReport(ref clsDatabase cur_db) : base()
		{


			try
			{

				oDatabase = cur_db;

				if (!InitLocalObjects(ref cur_db))
				{
					return;
				}

				bConnected_fl = true;
				return;

			}
			catch (Exception ex)
			{
				bConnected_fl = false;

			}

		}

		private bool InitLocalObjects(ref clsDatabase cur_db)
		{

			bool return_value = false;

			try
			{

				oMoney = new clsMoney(ref cur_db);
				oGeneral = new clsGeneral(ref cur_db);
				oValidate = new clsValidate(ref cur_db);
				oPostIV = new clsPostIV(ref cur_db);
				oPostGL = new clsPostGL(ref cur_db);
				oUtility = new clsDynastyUtility();

				sFund_cd = "";

				return true;

			}
			catch (Exception ex)
			{
				return return_value;

			}

		}

		~clsCustomReport()
		{

			try
			{

				bConnected_fl = false;
				//base.Finalize();

			}
			catch (Exception ex)
			{

			}

		}

		public void Release()
		{

		}

		// Set the connection manually.
		//
		public void SetDBConnection(ref clsDatabase cur_db)
		{
			oDatabase = cur_db;
			bConnected_fl = InitLocalObjects(ref cur_db);
		}

		public bool IsErrorFound()
		{

			bool return_value = (oUtility.IsNonEmpty(oDatabase.sPostingError));

			return return_value;

		}

		public string GetErrorMessage()
		{

			string return_value = oDatabase.sPostingError;

			oDatabase.sPostingError = "";
			return return_value;

		}

		public bool CreateGLFinancialData(string report_code, bool consolidated_fl, string[,] company_list, int period_begin, int period_end, string fund_code)
		{

			bool return_value = false;

			int i = 0;
			int k = 0;
			int m = 0;
			string dsn_name = "";
			string company_short_name = "";
			string company_full_name = "";
			string db_type = "";
			string db_name = "";
			string server_name = "";
			string user_id = "";
			string password = "";
			string sql_str = "";
			string group_det_str = "";
			clsRecordset report_set = new clsRecordset(ref oDatabase);
			bool use_sp_fl = false;
			clsDatabase temp_db = new clsDatabase();

			try
			{
				if (consolidated_fl && company_list == null)
                {
					return false;
                }

				sFund_cd = fund_code;
				iPeriodBegin_dt = period_begin;
				iPeriodEnd_dt = period_end;
				sReport_cd = report_code;
				oUtility.ResizeDim(ref uGLFinancial.sGroupFormula, 3, 99);

				// This report info will be copied into the all datbases that are consolidated.
				//
				sql_str = "SELECT * FROM tblGLReportGroupDet WHERE sReport_cd = '" + sReport_cd + "'";
				if (!report_set.CreateSnapshot(sql_str))
				{
					return return_value;
				}
				else if (report_set.EOF())
				{
					return return_value;
				}

				sql_str = "DELETE FROM tblComparativeBalance WHERE sLastUpdate_id = '" + oDatabase.sUser_cd + "'";
				if (!oDatabase.ExecuteSQL(sql_str))
				{
					return return_value;
				}
				else if (!CreateGroupFormula())
				{
					return return_value;
				}

				iCurrentDatabase_typ = oDatabase.CurrentDatabaseType();

				if (consolidated_fl) // We already know "company_list.GetLength > 0"
				{

					for (i = 0; i < company_list.GetLength(1); i++)
					{

						if (oUtility.IsEmpty(company_list[GlobalVar.goConstant.COMPANY_SHORT_NAME_COL, i]))
						{
							break;
						}

						// Need to reset all these  so that GetDatabaseInfo() will get new values
						//
						company_short_name = company_list[GlobalVar.goConstant.COMPANY_SHORT_NAME_COL, i];
						company_full_name = company_list[GlobalVar.goConstant.COMPANY_FULL_NAME_COL, i];
						db_name = company_list[GlobalVar.goConstant.COMPANY_DATABASE_NAME_COL, i];
						server_name = company_list[GlobalVar.goConstant.COMPANY_SERVER_NAME_COL, i];
						dsn_name = company_list[GlobalVar.goConstant.COMPANY_DSN_COL, i];
						db_type = company_list[GlobalVar.goConstant.COMPANY_DB_TYPE_COL, i];

						if (oDatabase.bFundAccounting_fl)
						{
							sFund_cd = oUtility.IIf(oUtility.SUCase(company_short_name) == clsNPConstant.FUND_ORGANIZATION_CODE, "", company_short_name).ToString(); // The fund code for organization is an empty string.
						}
						else
						{
							temp_db.sCCN = dsn_name;
							temp_db.sDSN = dsn_name;
							temp_db.sServer_nm = server_name;
							temp_db.sDatabase_nm = db_name;
							temp_db.bIsWEBVersion_fl = oDatabase.bIsWEBVersion_fl;
							temp_db.bIsSAASVersion_fl = oDatabase.bIsSAASVersion_fl;
							temp_db.sConnectionString = temp_db.CreateSQLConnectionString(temp_db.sServer_nm, temp_db.sDatabase_nm);

							if (!GlobalVar.goCompany.OpenDatabase(ref temp_db, company_short_name))
							{
								return false;
							}

						}

						if (!CreateOneCompany(ref temp_db, company_short_name, (i + 1)))
						{
							return return_value;
						}

						temp_db.CloseDatabase();

					}

                    sql_str = "UPDATE tblComparativeBalance SET mBalance_amt1 = mBalance_amt0, mBalance_amt0 = 0, iAcctLevel = " + uGLFinancial.DETAIL_LINE.ToString();
					sql_str += " WHERE sLastUpdate_id = '" + oDatabase.sUser_cd + "'";
					if (!oDatabase.ExecuteSQL(sql_str))
					{
						return return_value;
					}

					if (!CreateConsolidationSummary())
					{
						return return_value;
					}

				}
				else if (!CreateOneCompany(ref temp_db, "", 0)) // Current database non-consolidated.
				{
					return return_value;
				}

				return true;

			}
			catch (Exception ex)
			{

                modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(CreateGLFinancialData)");

				return return_value;

			}

		}

		private bool CreateGroupFormula()
		{

			bool return_value = false;

			string sql_str = "";
			clsRecordset cur_set = new clsRecordset(ref oDatabase);
			int i = 0;

			// Grab the report groups. iDisplayOrder_id carries the group num.
			//
			sql_str = "SELECT * FROM tblGLReportGroup where sReport_cd = '" + sReport_cd + "' ORDER BY iDisplayOrder_id";
			if (!cur_set.CreateSnapshot(sql_str))
			{
				return return_value;
			}
			else if (cur_set.EOF())
			{
				return return_value;
			}

			oUtility.ResizeDim(ref uGLFinancial.sGroupFormula, 3, cur_set.RecordCount() - 1);

			// iDisplayOrder_id of tblGLReportGroupDet may not be consistent with that of tblGLReportGroup.  Make them consistent.
			// One UPDATE statement with multiple tables( with JOIN) does not work with the current version of Access database.
			//
			while (!cur_set.EOF())
			{
				sql_str = "UPDATE tblGLReportGroupDet SET iDisplayOrder_id = " + cur_set.iField("iDisplayOrder_id").ToString();
				sql_str += " WHERE sReport_cd = '" + cur_set.sField("sReport_cd") + "'";
				sql_str += " AND sGroup_cd = '" + cur_set.sField("sGroup_cd") + "'";
				if (!oDatabase.ExecuteSQL(sql_str))
				{
					return return_value;
				}
                uGLFinancial.sGroupFormula[uGLFinancial.FORMULA_COL, i] = cur_set.sField("sFunction");
                uGLFinancial.sGroupFormula[uGLFinancial.DESCRIPTION_COL, i] = cur_set.sField("sDescription");
                uGLFinancial.sGroupFormula[uGLFinancial.GROUP_TYPE_COL, i] = cur_set.iField("iGroup_typ").ToString();
                uGLFinancial.sGroupFormula[uGLFinancial.GROUP_NUM_COL, i] = cur_set.iField("iDisplayOrder_id").ToString();
				cur_set.MoveNext();
				i += 1;
			}

			return_value = true;

			return return_value;

		}

		private bool CreateOneCompany(ref clsDatabase temp_db, string company_name, int company_num)
		{

			bool return_value = false;

			string sql_str = "";
			string insert_str = "";
			int i = 0;
			decimal group_sum = 0M;
			clsRecordset cur_set = null;
			bool secondary_db_fl = false;

			try
			{

				secondary_db_fl = (oUtility.IsNonEmpty(company_name));

				if (!oDatabase.bFundAccounting_fl && secondary_db_fl)
				{
					cur_set = new clsRecordset(ref temp_db);
				}
				else
				{
					cur_set = new clsRecordset(ref oDatabase);
				}

				// Delete the records that were created by this user.
				//
				if (!oDatabase.bFundAccounting_fl && secondary_db_fl)
				{
					sql_str = "DELETE FROM tblComparativeBalance WHERE sLastUpdate_id = '" + oDatabase.sUser_cd + "' AND iProcess_id = " + company_num.ToString();
					if (!temp_db.ExecuteSQL(sql_str))
					{
						return return_value;
					}
				}

				// Create all report details.
				//
				if (!CreateDetails(ref temp_db, uGLFinancial.AMOUNT_BALANCE_TYPE, true, secondary_db_fl, company_num))
				{
					return return_value;
				}
				else if (!CreateDetails(ref temp_db, uGLFinancial.AMOUNT_BALANCE_TYPE, false, secondary_db_fl, company_num))
				{
					return return_value;
				}
				else if (!CreateDetails(ref temp_db, uGLFinancial.AMOUNT_CREDIT_TYPE, true, secondary_db_fl, company_num))
				{
					return return_value;
				}
				else if (!CreateDetails(ref temp_db, uGLFinancial.AMOUNT_CREDIT_TYPE, false, secondary_db_fl, company_num))
				{
					return return_value;
				}
				else if (!CreateDetails(ref temp_db, uGLFinancial.AMOUNT_DEBIT_TYPE, true, secondary_db_fl, company_num))
				{
					return return_value;
				}
				else if (!CreateDetails(ref temp_db, uGLFinancial.AMOUNT_DEBIT_TYPE, false, secondary_db_fl, company_num))
				{
					return return_value;
				}
				else if (!CreateDetails(ref temp_db, uGLFinancial.AMOUNT_NET_TYPE, true, secondary_db_fl, company_num))
				{
					return return_value;
				}
				else if (!CreateDetails(ref temp_db, uGLFinancial.AMOUNT_NET_TYPE, false, secondary_db_fl, company_num))
				{
					return return_value;
				}

				//  Update the account descriptions.
				//  Thi is necessary only for the non-consolidation reports
				//  because the consolidation reports do not show the details.
				//
				if (!secondary_db_fl) // Non consolidation.
				{
					sql_str = "SELECT d.sAccount_cd AS sAcct, a.sDescription AS sAcctDesc";
					sql_str += " FROM tblGLReportGroupDet d INNER JOIN tblGLAccount a ON (a.sAccount_cd = d.sAccount_cd)";
					sql_str += " WHERE d.sReport_cd = '" + sReport_cd + "'";
					if (!cur_set.CreateSnapshot(sql_str))
					{
						return return_value;
					}
					else if (cur_set.EOF())
					{
						return return_value;
					}

					// If sAccount_nm = '', then use that in tblGLAccount.
					//
					while (!cur_set.EOF())
					{
						sql_str = "UPDATE tblComparativeBalance SET sAccount_nm = '" + cur_set.sField("sAcctDesc") + "'";
						sql_str += " WHERE sAccount_cd = '" + cur_set.sField("sAcct") + "'";
						sql_str += " AND ((sAccount_nm IS NULL) OR (sAccount_nm = ''))";
						sql_str += " AND sLastUpdate_id = '" + oDatabase.sUser_cd + "'";
						if (!oDatabase.ExecuteSQL(sql_str))
						{
							return return_value;
						}
						cur_set.MoveNext();
					}
				}

				if (iCurrentDatabase_typ == GlobalVar.goConstant.DB_ACCESS_TYPE)
				{
					oUtility.WaitFor(2); // This will give enough time for Access to process properly.
				}

				if (!CreateGroupSummaries(ref temp_db, company_name, secondary_db_fl, company_num))
				{
					return return_value;
				}

				if (secondary_db_fl)
				{
					if (!oDatabase.bFundAccounting_fl)
					{
						sql_str = "DELETE FROM tblComparativeBalance WHERE sLastUpdate_id = '" + oDatabase.sUser_cd + "' AND iAcctLevel = " + uGLFinancial.DETAIL_LINE.ToString();
						sql_str += " AND iProcess_id = " + (SUMMARY_PROCESS_ID + company_num).ToString();
						if (!oDatabase.ExecuteSQL(sql_str))
						{
							return return_value;
						}
					}
					sql_str = "UPDATE tblComparativeBalance SET sAccount_cd = '" + oUtility.SRight("000" + company_num.ToString(), 3) + "'"; // This is for sorting in reporting.
					sql_str += " WHERE sLastUpdate_id = '" + oDatabase.sUser_cd + "'";
					sql_str += " AND iProcess_id = " + (SUMMARY_PROCESS_ID + company_num).ToString();
					if (!oDatabase.ExecuteSQL(sql_str))
					{
						return return_value;
					}
				}

				return true;

			}
			catch (Exception ex)
			{

                modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(CreateOneCompany)");
                return return_value;

			}

		}

		private bool CreateGroupSummaries(ref clsDatabase temp_db, string company_name, bool secondary_db_fl, int company_num)
		{

			bool return_value = false;

			const string TEMP_DESC_STR = "^$^%%^$^%^%";
			string sql_str = "";
			string target_str = "";
			string insert_str = "";
			decimal group_sum = 0M;
			int i = 0;
			clsRecordset cur_set = null;
			clsDatabase cur_db = null;
			bool rec_exist_fl = false;

			try
			{

				if (!oDatabase.bFundAccounting_fl && secondary_db_fl)
				{
					cur_db = temp_db;
					cur_set = new clsRecordset(ref temp_db);
				}
				else
				{
					cur_db = oDatabase;
					cur_set = new clsRecordset(ref oDatabase);
				}

				// Create summaries for each group.
				//
				sql_str = "INSERT INTO tblComparativeBalance(";
				sql_str += " sAccount_cd";
				sql_str += ",sAccount_nm";
				sql_str += ",iGroup_typ";
				sql_str += ",iAcctLevel";
				sql_str += ",mBalance_amt0";
				sql_str += ",sLastUpdate_id";
				sql_str += ",iProcess_id";
				sql_str += ") SELECT ";
				sql_str += " '" + cur_db.oLanguage.oString.STR_SUM + "'";
				sql_str += ",''";
				sql_str += ",iGroup_typ";
				sql_str += "," + uGLFinancial.SUMMARY_LINE.ToString();
				sql_str += ",SUM(mBalance_amt1)";
				sql_str += ",sLastUpdate_id";
				sql_str += "," + company_num.ToString();
				sql_str += " FROM tblComparativeBalance";
				sql_str += " WHERE sLastUpdate_id = '" + oDatabase.sUser_cd + "'";
				sql_str += " AND iProcess_id = " + company_num.ToString();
				sql_str += " GROUP BY iGroup_typ, sLastUpdate_id";
				if (!cur_db.ExecuteSQL(sql_str))
				{
					return return_value;
				}

				for (i = 1; i <= uGLFinancial.sGroupFormula.GetLength(1); i++)
				{
					group_sum = 0M;

					if (oUtility.IsNonEmpty(uGLFinancial.sGroupFormula[uGLFinancial.FORMULA_COL, i - 1]))
					{

						if (oUtility.ToValue(uGLFinancial.sGroupFormula[uGLFinancial.GROUP_TYPE_COL, i - 1]) == uGLFinancial.FUNCTION_AVG_TYPE)
						{
							sql_str = "SELECT AVG(mBalance_amt0) AS mSum FROM tblComparativeBalance WHERE sAccount_cd = '" + cur_db.oLanguage.oString.STR_SUM + "'";
						}
						else // oUtility.ToValue(sGroupFormula(FORMULA_COL, i - 1)) = uGLFinancial.FUNCTION_SUM_TYPE Then
						{
							sql_str = "SELECT SUM(mBalance_amt0) AS mSum FROM tblComparativeBalance WHERE sAccount_cd = '" + cur_db.oLanguage.oString.STR_SUM + "'";
						}
						sql_str += " AND (iGroup_typ IN (" + uGLFinancial.sGroupFormula[uGLFinancial.FORMULA_COL, i - 1] + "))";
						sql_str += " AND sLastUpdate_id = '" + oDatabase.sUser_cd + "'";
						sql_str += " AND iProcess_id = " + company_num.ToString();
						if (!cur_set.CreateSnapshot(sql_str))
						{
							return return_value;
						}
						else if (!cur_set.EOF())
						{
							group_sum = cur_set.mField("mSum");
						}

					}
					else if (oUtility.ToValue(uGLFinancial.sGroupFormula[uGLFinancial.GROUP_TYPE_COL, i - 1]) == uGLFinancial.FUNCTION_BEGINNING_BALANCE_TYPE)
					{
						group_sum = GetBeginningBalance(ref temp_db, i, uGLFinancial.sGroupFormula[uGLFinancial.DESCRIPTION_COL, i - 1], secondary_db_fl, company_num);
					}
					else
					{
						sql_str = "SELECT mBalance_amt0 FROM tblComparativeBalance ";
						sql_str += " WHERE sAccount_cd = '" + cur_db.oLanguage.oString.STR_SUM + "'";
						sql_str += " AND iGroup_typ = " + i.ToString();
						sql_str += " AND sLastUpdate_id = '" + oDatabase.sUser_cd + "'";
						sql_str += " AND iProcess_id = " + company_num.ToString();
						if (!cur_set.CreateSnapshot(sql_str))
						{
							return return_value;
						}
						else if (!cur_set.EOF())
						{
							group_sum = cur_set.mField("mBalance_amt0");
						}
					}

					rec_exist_fl = false;

					sql_str = "DELETE FROM tblComparativeBalance";
					sql_str += " WHERE sAccount_cd = '" + cur_db.oLanguage.oString.STR_SUM + "'";
					sql_str += " AND iGroup_typ = " + i.ToString();
					sql_str += " AND sLastUpdate_id = '" + oDatabase.sUser_cd + "'";
					sql_str += " AND iProcess_id = " + company_num.ToString();
					if (!cur_db.ExecuteSQL(sql_str))
					{
						return return_value;
					}

					sql_str = "INSERT INTO tblComparativeBalance(";
					sql_str += " sAccount_cd";
					sql_str += ",sAccount_nm";
					sql_str += ",iGroup_typ";
					sql_str += ",iAcctLevel";
					sql_str += ",mBalance_amt0";
					sql_str += ",sLastUpdate_id";
					sql_str += ",iProcess_id";
					sql_str += ") VALUES (";
					sql_str += " '" + cur_db.oLanguage.oString.STR_SUM + "'";
					sql_str += ",'" + TEMP_DESC_STR + "'";
					sql_str += "," + i.ToString();
					sql_str += "," + uGLFinancial.SUMMARY_LINE.ToString();
					sql_str += "," + group_sum.ToString();
					sql_str += ",'" + oDatabase.sUser_cd + "'";

					if (oUtility.IsEmpty(company_name)) // Non-consolidation report.
					{
						target_str = sql_str + "," + company_num.ToString();
						target_str += ")";
						if (!oDatabase.ExecuteSQL(oUtility.SReplace(target_str, TEMP_DESC_STR, uGLFinancial.sGroupFormula[uGLFinancial.DESCRIPTION_COL, i - 1])))
						{
							return return_value;
						}
					}
					else
					{
						target_str = sql_str + "," + company_num.ToString();
						target_str += ")";
						if (!cur_db.ExecuteSQL(oUtility.SReplace(target_str, TEMP_DESC_STR, uGLFinancial.sGroupFormula[uGLFinancial.DESCRIPTION_COL, i - 1])))
						{
							return return_value;
						}
					}

					// Move the summary data to the reporting database.
					// This will create duplicate records for the current database if it is included in the consolidation, 
					// and it will be taken care of in CreateConsolidationSummary() using SUMMARY_PROCESS_ID.
					//
					if (secondary_db_fl)
					{
						target_str = sql_str + "," + (SUMMARY_PROCESS_ID + company_num).ToString();
						target_str += ")";
						if (!oDatabase.ExecuteSQL(oUtility.SReplace(target_str, TEMP_DESC_STR, uGLFinancial.sGroupFormula[uGLFinancial.DESCRIPTION_COL, i - 1] + " : " + company_name)))
						{
							return return_value;
						}
					}

					if (iCurrentDatabase_typ == GlobalVar.goConstant.DB_ACCESS_TYPE)
					{
						oUtility.WaitFor(1); // This will give enough time for Access to process properly.
					}

				}

				return true;

			}
			catch (Exception ex)
			{

                modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(CreateGroupSummaries)");
				return return_value;

			}

		}

		private decimal GetBeginningBalance(ref clsDatabase temp_db, int group_num, string group_name, bool secondary_db_fl, int company_num)
		{

			decimal return_value = 0M;

			string sql_str = "";
			int period_end = 0;
			decimal group_amt = 0M;
			clsRecordset cur_set = null;
			clsDatabase cur_db = null;

			try
			{

				if (!oDatabase.bFundAccounting_fl && secondary_db_fl)
				{
					cur_db = temp_db;
					cur_set = new clsRecordset(ref temp_db);
				}
				else
				{
					cur_db = oDatabase;
					cur_set = new clsRecordset(ref oDatabase);
				}

				if (group_num <= 0)
				{
					return_value = 0M;
					return return_value;
				}

				// We do not show the details of beginning balance at this point.
				sql_str = "DELETE FROM tblComparativeBalance WHERE sLastUpdate_id = '" + oDatabase.sUser_cd + "'";
				sql_str += " AND iGroup_typ = " + group_num.ToString();
				sql_str += " AND iProcess_id = " + company_num.ToString();
				if (!cur_db.ExecuteSQL(sql_str))
				{
					return return_value;
				}

				sql_str = "SELECT MAX(iPeriodEnd_dt) AS iMax_dt FROM tblGLBalance";
				sql_str += " WHERE iPeriodEnd_dt < " + iPeriodBegin_dt.ToString();
				sql_str += " AND sFund_cd = '" + sFund_cd + "'";
				if (!cur_set.CreateSnapshot(sql_str))
				{
					return_value = 0M;
					return return_value;
				}
				else if (!cur_set.EOF())
				{
					period_end = cur_set.iField("iMax_dt");
				}
				else
				{
					return_value = 0M;
					return return_value;
				}

				sql_str = "SELECT SUM(mBalance_amt) AS mBegin_amt";
				sql_str += " FROM tblGLBalance b INNER JOIN tblGLReportGroupDet g ON (b.sAccount_cd = g.sAccount_cd)";
				sql_str += " WHERE b.iPeriodEnd_dt = " + period_end.ToString();
				sql_str += " AND g.sReport_cd = '" + sReport_cd + "'";
				sql_str += " AND g.iDisplayOrder_id = " + group_num.ToString();
				sql_str += " AND b.sFund_cd = '" + sFund_cd + "'";
				if (!cur_set.CreateSnapshot(sql_str))
				{
					return_value = 0M;
					return return_value;
				}
				else if (!cur_set.EOF())
				{
					return_value = cur_set.mField("mBegin_amt");
				}
				else
				{
					return_value = 0M;
				}

				return return_value;

				// We do not show the details of beginning balance at this point.
				sql_str = "SELECT b.sAccount_cd, b.mBalance_amt";
				sql_str += " FROM tblGLBalance b INNER JOIN tblGLReportGroupDet g ON (b.sAccount_cd = g.sAccount_cd)";
				sql_str += " WHERE b.iPeriodEnd_dt = " + period_end.ToString();
				sql_str += " AND g.sReport_cd = '" + sReport_cd + "'";
				sql_str += " AND g.iDisplayOrder_id = " + group_num.ToString();
				sql_str += " AND b.sFund_cd = '" + sFund_cd + "'";
				if (!cur_set.CreateSnapshot(sql_str))
				{
					return_value = 0M;
					return return_value;
				}
				else if (cur_set.EOF())
				{
					return_value = 0M;
					return return_value;
				}

				group_amt = 0M;
				while (!cur_set.EOF())
				{
					sql_str = "UPDATE tblComparativeBalance SET mBalance_amt1 = " + cur_set.mField("mBalance_amt").ToString();
					sql_str += " WHERE sAccount_cd = '" + cur_set.sField("sAccount_cd") + "'";
					sql_str += " AND iGroup_typ = " + group_num.ToString();
					sql_str += " AND iProcess_id = " + company_num.ToString();
					if (!cur_db.ExecuteSQL(sql_str))
					{
						return_value = 0M;
						return return_value;
					}
					group_amt += cur_set.mField("mBalance_amt");
					cur_set.MoveNext();
				}

				return_value = group_amt;
				return return_value;

			}
			catch (Exception ex)
			{

                modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(GetBeginningBalance)");
				return return_value;

			}

		}

		private bool CreateDetails(ref clsDatabase temp_db, int amount_type, bool negate_fl, bool secondary_db_fl, int company_num)
		{

			bool return_value = false;

			string sql_str = "";

			try
			{

				sql_str = "INSERT INTO tblComparativeBalance(";
				sql_str += " sAccount_cd";
				sql_str += ",sAccount_nm";
				sql_str += ",iGroup_typ";
				sql_str += ",iAcctLevel";
				sql_str += ",mBalance_amt1";
				sql_str += ",sLastUpdate_id";
				sql_str += ",iProcess_id";
				sql_str += ") SELECT ";
				sql_str += " g.sAccount_cd";
				sql_str += ",g.sDescription";
				sql_str += ",g.iDisplayOrder_id";
				sql_str += "," + uGLFinancial.DETAIL_LINE.ToString();

				if (amount_type == uGLFinancial.AMOUNT_BALANCE_TYPE)
				{
					sql_str += "," + oUtility.IIf(negate_fl, "-", "").ToString() + "b.mBalance_amt";
				}
				else if (amount_type == uGLFinancial.AMOUNT_CREDIT_TYPE)
				{
					sql_str += ",SUM(" + oUtility.IIf(negate_fl, "-", "").ToString() + "b.mPeriodCr_amt)";
				}
				else if (amount_type == uGLFinancial.AMOUNT_DEBIT_TYPE)
				{
					sql_str += ",SUM(" + oUtility.IIf(negate_fl, "-", "").ToString() + "b.mPeriodDr_amt)";
				}
				else // amount_type = uGLFinancial.AMOUNT_NET_TYPE Then
				{
					sql_str += ",SUM(" + oUtility.IIf(negate_fl, "-", "").ToString() + "b.mPeriodNet_amt)";
				}

				sql_str += ",'" + oDatabase.sUser_cd + "'";
				sql_str += "," + company_num.ToString();
				sql_str += " FROM tblGLBalance b INNER JOIN tblGLReportGroupDet g ON (b.sAccount_cd = g.sAccount_cd)";

				if (amount_type == uGLFinancial.AMOUNT_BALANCE_TYPE)
				{
					sql_str += " WHERE (b.iPeriodEnd_dt = " + iPeriodEnd_dt.ToString() + ") ";
				}
				else
				{
					sql_str += " WHERE (b.iPeriodEnd_dt >= " + iPeriodBegin_dt.ToString() + ") ";
					sql_str += " AND (b.iPeriodBegin_dt <= " + iPeriodEnd_dt.ToString() + ")";
				}

				sql_str += " AND (g.sReport_cd = '" + sReport_cd + "')";
				sql_str += " AND (g.iAmount_typ = " + amount_type.ToString() + ")";
				sql_str += " AND (g.iNegate_fl " + oUtility.IIf(negate_fl, ">", "=").ToString() + " 0)";
				if (oDatabase.bFundAccounting_fl)
				{
					sql_str += " AND b.sFund_cd = '" + sFund_cd + "'";
				}

				if (amount_type != uGLFinancial.AMOUNT_BALANCE_TYPE)
				{
					sql_str += " GROUP BY g.sAccount_cd,g.sDescription,g.iDisplayOrder_id";
				}

				if (!oDatabase.bFundAccounting_fl && secondary_db_fl)
				{
					return_value = temp_db.ExecuteSQL(sql_str);
				}
				else
				{
					return_value = oDatabase.ExecuteSQL(sql_str);
				}

				return return_value;

			}
			catch (Exception ex)
			{

                modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(CreateDetails)");
				return return_value;

			}

		}

		private bool CreateConsolidationSummary()
		{

			bool return_value = false;

			string sql_str = "";
			decimal group_sum = 0M;
			int i = 0;
			clsRecordset cur_set = new clsRecordset(ref oDatabase);

			try
			{

				// This is to eliminate the duplicates for the current database that in included in consolidation.
				// The records are created in CreateGroupSummaries().
				//
				sql_str = "DELETE FROM tblComparativeBalance";
				sql_str += " WHERE sLastUpdate_id = '" + oDatabase.sUser_cd + "'";
				sql_str += " AND iProcess_id < " + SUMMARY_PROCESS_ID.ToString();
				if (!oDatabase.ExecuteSQL(sql_str))
				{
					return return_value;
				}

				// This will cerate consolidation for each group.
				//
				sql_str = "INSERT INTO tblComparativeBalance(";
				sql_str += " sAccount_cd";
				sql_str += ",sAccount_nm";
				sql_str += ",iGroup_typ";
				sql_str += ",iAcctLevel";
				sql_str += ",mBalance_amt0";
				sql_str += ",sLastUpdate_id";
				sql_str += ",iProcess_id";
				sql_str += ") SELECT ";
				sql_str += " '" + oDatabase.oLanguage.oString.STR_SUM + "'";
				sql_str += ",''";
				sql_str += ",iGroup_typ";
				sql_str += "," + uGLFinancial.SUMMARY_LINE.ToString();
				sql_str += ",SUM(mBalance_amt1)";
				sql_str += ",'" + oDatabase.sUser_cd + "'";
				sql_str += "," + CONSOLIDATION_PROCESS_ID.ToString();
				sql_str += " FROM tblComparativeBalance";
				sql_str += " WHERE sLastUpdate_id = '" + oDatabase.sUser_cd + "'";
				sql_str += " GROUP BY iGroup_typ";
				if (!oDatabase.ExecuteSQL(sql_str))
				{
					return return_value;
				}

				if (oDatabase.CurrentDatabaseType() == GlobalVar.goConstant.DB_ACCESS_TYPE)
				{
					oUtility.WaitFor(1); // This will give enough time for Access to process properly.
				}

				for (i = 0; i < uGLFinancial.sGroupFormula.GetLength(1); i++)
				{
					if (oUtility.ToValue(uGLFinancial.sGroupFormula[uGLFinancial.GROUP_NUM_COL, i]) == 0M)
					{
						break;
					}
					sql_str = "UPDATE tblComparativeBalance SET sAccount_nm = '" + uGLFinancial.sGroupFormula[uGLFinancial.DESCRIPTION_COL, i] + " " + oUtility.SUCase(oDatabase.oLanguage.oString.STR_TOTAL) + "'";
					sql_str += " WHERE iGroup_typ = " + uGLFinancial.sGroupFormula[uGLFinancial.GROUP_NUM_COL, i];
					sql_str += " AND iProcess_id = " + CONSOLIDATION_PROCESS_ID;
					if (!oDatabase.ExecuteSQL(sql_str))
					{
						return return_value;
					}
				}

				return true;

			}
			catch (Exception ex)
			{

                modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(CreateConsolidationSummary)");
				return return_value;

			}

		}

		public bool SyncCustomReport(string[,] company_list, string report_id)
		{
			bool return_value = false;
			int i = 0;
			int k = 0;
			int m = 0;
			string dsn_name = "";
			string company_short_name = "";
			string company_full_name = "";
			string db_type = "";
			string db_name = "";
			string server_name = "";
			string user_id = "";
			string password = "";
			string sql_str = "";
			bool use_sp_fl = false;

			clsDatabase temp_db = new clsDatabase();
			clsRecordset report_set = new clsRecordset(ref oDatabase);
			clsRecordset reportgroup_set = new clsRecordset(ref oDatabase);
			clsRecordset reportgroupdet_set = new clsRecordset(ref oDatabase);

			try
			{
				sql_str = "SELECT * FROM tblGLReport WHERE sReport_cd = '" + report_id + "'";
				if (!report_set.CreateSnapshot(sql_str))
				{
					return return_value;
				}
				sql_str = "SELECT * FROM tblGLReportGroup WHERE sReport_cd = '" + report_id + "'";
				if (!reportgroup_set.CreateSnapshot(sql_str))
				{
					return return_value;
				}
				sql_str = "SELECT * FROM tblGLReportGroupDet WHERE sReport_cd = '" + report_id + "'";
				if (!reportgroupdet_set.CreateSnapshot(sql_str))
				{
					return return_value;
				}

				for (i = 0; i < company_list.GetLength(1); i++)
				{
					if (oUtility.IsEmpty(company_list[GlobalVar.goConstant.COMPANY_SHORT_NAME_COL, i]))
					{
						break;
					}

					// Need to reset all these so that GetDatabaseInfo() will get new values
					//
					company_short_name = company_list[GlobalVar.goConstant.COMPANY_SHORT_NAME_COL, i];
					company_full_name = company_list[GlobalVar.goConstant.COMPANY_FULL_NAME_COL, i];
					db_name = company_list[GlobalVar.goConstant.COMPANY_DATABASE_NAME_COL, i];
					server_name = company_list[GlobalVar.goConstant.COMPANY_SERVER_NAME_COL, i];
					dsn_name = company_list[GlobalVar.goConstant.COMPANY_DSN_COL, i];
					db_type = company_list[GlobalVar.goConstant.COMPANY_DB_TYPE_COL, i];

					if ((oDatabase.IsDSNless() && oUtility.SUCase(oDatabase.sDSN) != oUtility.SUCase(company_short_name)) || (!oDatabase.IsDSNless() && oUtility.SUCase(dsn_name) != oUtility.SUCase(oDatabase.sDSN))) // Skip the current database
					{
						temp_db.sCCN = dsn_name;
						temp_db.sServer_nm = server_name;
						temp_db.sDatabase_nm = db_name;
						temp_db.bIsWEBVersion_fl = oDatabase.bIsWEBVersion_fl;
						temp_db.bIsSAASVersion_fl = oDatabase.bIsSAASVersion_fl;
						temp_db.sConnectionString = temp_db.CreateSQLConnectionString(temp_db.sServer_nm, temp_db.sDatabase_nm);

						if (!GlobalVar.goCompany.OpenDatabase(ref temp_db, company_short_name))
						{
							return false;
						}

						sql_str = "DELETE FROM tblGLReport WHERE sReport_cd = '" + report_id + "'";
						if (temp_db.ExecuteSQL(sql_str) == false)
						{
							return return_value;
						}
						sql_str = "DELETE FROM tblGLReportGroup WHERE sReport_cd = '" + report_id + "'";
						if (temp_db.ExecuteSQL(sql_str) == false)
						{
							return return_value;
						}
						sql_str = "DELETE FROM tblGLReportGroupDet WHERE sReport_cd = '" + report_id + "'";
						if (temp_db.ExecuteSQL(sql_str) == false)
						{
							return return_value;
						}

						report_set.MoveFirst();
						reportgroup_set.MoveFirst();
						reportgroupdet_set.MoveFirst();

						if (!report_set.EOF())
						{
							sql_str = "INSERT INTO tblGLReport (";
							sql_str += " sReport_cd";
							sql_str += ",sDescription";
							sql_str += ",sRemarks";
							sql_str += ",sReportFile_nm";
							sql_str += ",iReport_typ";
							sql_str += ",sFooter";
							sql_str += ",sFooterFormula";
							sql_str += ",sLastUpdate_id";
							sql_str += ",dtLastUpdate_dt";
							sql_str += ") VALUES ( ";
							sql_str += "'" + report_set.sField("sReport_cd") + "'";
							sql_str += ",'" + report_set.sField("sDescription") + "'";
							sql_str += ",'" + report_set.sField("sRemarks") + "'";
							sql_str += ",'" + report_set.sField("sReportFile_nm") + "'";
							sql_str += "," + report_set.iField("iReport_typ").ToString();
							sql_str += ",'" + report_set.sField("sFooter") + "'";
							sql_str += ",'" + report_set.sField("sFooterFormula") + "'";
							sql_str += ",'" + report_set.sField("sLastUpdate_id") + "'";
							sql_str += "," + oDatabase.CreateDatetimeValue(DateTime.Now);
							sql_str += ")";
							if (temp_db.ExecuteSQL(sql_str) == false)
							{
								return return_value;
							}
						}

						while (!reportgroup_set.EOF())
						{
							sql_str = "INSERT INTO tblGLReportGroup (";
							sql_str += "sReport_cd";
							sql_str += ",sGroup_cd";
							sql_str += ",iDisplayOrder_id";
							sql_str += ",sDescription";
							sql_str += ",iNegate_fl";
							sql_str += ",sFunction";
							sql_str += ",sRemarks";
							sql_str += ",iGroup_typ";
							sql_str += ",iAmount_typ";
							sql_str += ",sLastUpdate_id";
							sql_str += ",dtLastUpdate_dt";
							sql_str += ") VALUES ( ";
							sql_str += "'" + reportgroup_set.sField("sReport_cd") + "'";
							sql_str += ",'" + reportgroup_set.sField("sGroup_cd") + "'";
							sql_str += "," + reportgroup_set.iField("iDisplayOrder_id").ToString();
							sql_str += ",'" + reportgroup_set.sField("sDescription") + "'";
							sql_str += "," + reportgroup_set.iField("iNegate_fl").ToString();
							sql_str += ",'" + reportgroup_set.sField("sFunction") + "'";
							sql_str += ",'" + reportgroup_set.sField("sRemarks") + "'";
							sql_str += "," + reportgroup_set.iField("iGroup_typ").ToString();
							sql_str += "," + reportgroup_set.iField("iAmount_typ").ToString();
							sql_str += ",'" + reportgroup_set.sField("sLastUpdate_id") + "'";
							sql_str += "," + oDatabase.CreateDatetimeValue(DateTime.Now);
							sql_str += ")";
							if (temp_db.ExecuteSQL(sql_str) == false)
							{
								return return_value;
							}
							reportgroup_set.MoveNext();
						}

						while (!reportgroupdet_set.EOF())
						{
							sql_str = "INSERT INTO tblGLReportGroupDet (";
							sql_str += "sReport_cd";
							sql_str += ",sGroup_cd";
							sql_str += ",iDisplayOrder_id";
							sql_str += ",sAccount_cd";
							sql_str += ",iNegate_fl";
							sql_str += ",sDescription";
							sql_str += ",iAmount_typ";
							sql_str += ",sLastUpdate_id";
							sql_str += ",dtLastUpdate_dt";
							sql_str += ") VALUES ( ";
							sql_str += "'" + reportgroupdet_set.sField("sReport_cd") + "'";
							sql_str += ",'" + reportgroupdet_set.sField("sGroup_cd") + "'";
							sql_str += "," + reportgroupdet_set.iField("iDisplayOrder_id").ToString();
							sql_str += ",'" + reportgroupdet_set.sField("sAccount_cd") + "'";
							sql_str += "," + reportgroupdet_set.iField("iNegate_fl").ToString();
							sql_str += ",'" + reportgroupdet_set.sField("sDescription") + "'";
							sql_str += "," + reportgroupdet_set.iField("iAmount_typ").ToString();
							sql_str += ",'" + reportgroupdet_set.sField("sLastUpdate_id") + "'";
							sql_str += "," + oDatabase.CreateDatetimeValue(DateTime.Now);
							sql_str += ")";
							if (temp_db.ExecuteSQL(sql_str) == false)
							{
								return return_value;
							}
							reportgroupdet_set.MoveNext();
						}

						temp_db.CloseDatabase();
					}

				}

				return_value = true;

			}
			catch (Exception ex)
			{

                modDialogUtility.DisplayBox(ref oDatabase, ex.Message + "(SyncCustomReport)");
				return_value = false;

			}

			return return_value;

		}
	}

}
