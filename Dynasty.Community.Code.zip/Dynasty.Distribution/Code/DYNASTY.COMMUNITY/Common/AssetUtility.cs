﻿using System;

//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//

using Dynasty.Database;
using System.Web.UI.WebControls;

internal static class modAssetUtility
{

	public static void LoadFAType(ref clsDatabase cur_db, ref DropDownList cur_box, bool add_blank_fl = false)
	{

		clsRecordset cur_set = new clsRecordset(cur_db);
		ArrayList item_list = new ArrayList();

		if (add_blank_fl)
		{
			item_list.Add(new clsComboBoxItem("", "0"));
		}

		if (!cur_set.CreateSnapshot("SELECT * FROM tblFAAssetType ORDER BY sDescription"))
		{
			return;
		}
		else if (!add_blank_fl && cur_set.EOF)
		{
			return;
		}

		while (!cur_set.EOF)
		{
			item_list.Add(new clsComboBoxItem(cur_set.Field("sDescription"), cur_set.Field("iAsset_typ").ToString()));
			cur_set.MoveNext();
		}

		LoadComboBox(cur_box, item_list);
		if (add_blank_fl)
		{
			cur_box.SelectedIndex = 0;
		}

	}

	public static void LoadFAStatus(ref DropDownList cur_box, bool add_blank_fl = false)
	{

		ArrayList item_list = new ArrayList();

		if (add_blank_fl)
		{
			item_list.Add(new clsComboBoxItem("", "0"));
		}

		item_list.Add(new clsComboBoxItem(goFAConstant.STATUS_OPERATIONAL, goFAConstant.STATUS_OPERATIONAL_NUM.ToString()));
		item_list.Add(new clsComboBoxItem(goFAConstant.STATUS_IN_REPAIRSHOP, goFAConstant.STATUS_IN_REPAIRSHOP_NUM.ToString()));
		item_list.Add(new clsComboBoxItem(goFAConstant.STATUS_SUSPENDED, goFAConstant.STATUS_SUSPENDED_NUM.ToString()));
		item_list.Add(new clsComboBoxItem(goFAConstant.STATUS_RETIRED, goFAConstant.STATUS_RETIRED_NUM.ToString()));

		LoadComboBox(cur_box, item_list);
		if (add_blank_fl)
		{
			cur_box.SelectedIndex = 0;
		}

	}

	public static void LoadFADepreciationMethods(ref DropDownList cur_box, bool add_blank_fl = false, bool depreciable_only_fl = false, bool disposable_only_fl = false)
	{

		ArrayList item_list = new ArrayList();

		if (add_blank_fl)
		{
			item_list.Add(new clsComboBoxItem("", "0"));
		}

		if (depreciable_only_fl)
		{

		}
		else if (disposable_only_fl)
		{
			item_list.Add(new clsComboBoxItem(goFAConstant.METHOD_NOT_DEPRECIABLE, goFAConstant.METHOD_NOT_DEPRECIABLE_NUM.ToString()));
		}
		else
		{
			item_list.Add(new clsComboBoxItem(goFAConstant.METHOD_NOT_DEPRECIABLE, goFAConstant.METHOD_NOT_DEPRECIABLE_NUM.ToString()));
			item_list.Add(new clsComboBoxItem(goFAConstant.METHOD_DISPOSED, goFAConstant.METHOD_DISPOSED_NUM.ToString()));
		}

		item_list.Add(new clsComboBoxItem(goFAConstant.METHOD_STRAIGHT_LINE, goFAConstant.METHOD_STRAIGHT_LINE_NUM.ToString()));
		item_list.Add(new clsComboBoxItem(goFAConstant.METHOD_DECLINING_BALANCE, goFAConstant.METHOD_DECLINING_BALANCE_NUM.ToString()));
		item_list.Add(new clsComboBoxItem(goFAConstant.METHOD_DBL_DECLINING_BALANCE, goFAConstant.METHOD_DBL_DECLINING_BALANCE_NUM.ToString()));
		item_list.Add(new clsComboBoxItem(goFAConstant.METHOD_150_DECLINING_BALANCE, goFAConstant.METHOD_150_DECLINING_BALANCE_NUM.ToString()));
		item_list.Add(new clsComboBoxItem(goFAConstant.METHOD_SUM_OF_YEARS_DIGITS, goFAConstant.METHOD_SUM_OF_YEARS_DIGITS_NUM.ToString()));

		LoadComboBox(cur_box, item_list);
		if (add_blank_fl)
		{
			cur_box.SelectedIndex = 0;
		}

	}

	public static void LoadFAPropertyType(ref DropDownList cur_box, bool add_blank_fl = false, bool depreciable_only_fl = false)
	{

		ArrayList item_list = new ArrayList();

		if (add_blank_fl)
		{
			item_list.Add(new clsComboBoxItem("", "0"));
		}

		if (!depreciable_only_fl)
		{
			item_list.Add(new clsComboBoxItem(goFAConstant.PROPERTY_ON_LOAN, goFAConstant.PROPERTY_ON_LOAN_NUM.ToString()));
		}
		if (!depreciable_only_fl)
		{
			item_list.Add(new clsComboBoxItem(goFAConstant.PROPERTY_ON_LEASE, goFAConstant.PROPERTY_ON_LEASE_NUM.ToString()));
		}
		item_list.Add(new clsComboBoxItem(goFAConstant.PROPERTY_TO_PURCHASE, goFAConstant.PROPERTY_TO_PURCHASE_NUM.ToString()));
		item_list.Add(new clsComboBoxItem(goFAConstant.PROPERTY_PURCHASED, goFAConstant.PROPERTY_PURCHASED_NUM.ToString()));

		LoadComboBox(cur_box, item_list);
		if (add_blank_fl)
		{
			cur_box.SelectedIndex = 0;
		}

	}

	public static void LoadFAQueryType(ref DropDownList cur_box, bool add_general_fl = false)
	{

		ArrayList item_list = new ArrayList();

		item_list.Add(new clsComboBoxItem("", ""));

		if (add_general_fl)
		{
			item_list.Add(new clsComboBoxItem(goString.STR_GENERAL_INFO, goString.STR_GENERAL_INFO));
		}

		item_list.Add(new clsComboBoxItem(goFAConstant.QUERY_DEPRECIATION_INFO, goFAConstant.QUERY_DEPRECIATION_INFO));
		item_list.Add(new clsComboBoxItem(goFAConstant.QUERY_DISPOSAL_INFO, goFAConstant.QUERY_DISPOSAL_INFO));
		item_list.Add(new clsComboBoxItem(goFAConstant.QUERY_DISPOSED_INFO, goFAConstant.QUERY_DISPOSED_INFO));
		item_list.Add(new clsComboBoxItem(goFAConstant.QUERY_PAYMENT_INFO, goFAConstant.QUERY_PAYMENT_INFO));
		item_list.Add(new clsComboBoxItem(goFAConstant.QUERY_SERVICE_INFO, goFAConstant.QUERY_SERVICE_INFO));
		item_list.Add(new clsComboBoxItem(goFAConstant.QUERY_INSURANCE_INFO, goFAConstant.QUERY_INSURANCE_INFO));

		LoadComboBox(cur_box, item_list);
		cur_box.SelectedIndex = 0;

	}

	public static void LoadFAServiceQueryType(ref DropDownList cur_box)
	{

		ArrayList item_list = new ArrayList();

		item_list.Add(new clsComboBoxItem("", ""));

		item_list.Add(new clsComboBoxItem(goFAConstant.SERVICE_QUERY_HISTORY, goFAConstant.SERVICE_QUERY_HISTORY));
		item_list.Add(new clsComboBoxItem(goFAConstant.SERVICE_QUERY_NO_HISTORY, goFAConstant.SERVICE_QUERY_NO_HISTORY));
		item_list.Add(new clsComboBoxItem(goFAConstant.SERVICE_QUERY_UPCOMING, goFAConstant.SERVICE_QUERY_UPCOMING));

		LoadComboBox(cur_box, item_list);
		cur_box.SelectedIndex = 0;

	}

	public static void LoadFAServiceCode(ref clsDatabase cur_db, ref DropDownList cur_box, bool add_blank_fl = false)
	{

		clsRecordset cur_set = new clsRecordset(cur_db);
		ArrayList item_list = new ArrayList();

		if (add_blank_fl)
		{
			item_list.Add(new clsComboBoxItem("", ""));
		}

		if (!cur_set.CreateSnapshot("SELECT * FROM tblFAService ORDER BY sDescription"))
		{
			return;
		}
		else if (!add_blank_fl && cur_set.EOF)
		{
			return;
		}

		while (!cur_set.EOF)
		{
			item_list.Add(new clsComboBoxItem(cur_set.Field("sDescription"), cur_set.Field("sService_cd").ToString()));
			cur_set.MoveNext();
		}

		LoadComboBox(cur_box, item_list);
		if (add_blank_fl)
		{
			cur_box.SelectedIndex = 0;
		}

	}
}
