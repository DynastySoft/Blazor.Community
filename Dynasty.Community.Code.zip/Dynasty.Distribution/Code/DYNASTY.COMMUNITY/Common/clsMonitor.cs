﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP
{
    public class clsMonitor
    {

        public int VALUE_COL { get { return 0; } }
        public int TEXT_COL { get { return 1; } }

#if WEB
        public bool CreateMonitorShowCases(ref clsDatabase cur_db, ref string[,] case_data, ref DropDownList cur_box)
        {
#else
	public bool CreateMonitorShowCases(ref clsDatabase cur_db, ref string[,] case_data, ref ComboBox cur_box)
	{
#endif


            bool return_value = false;
            int total_col = 0;
            int i = 0;
            int row_num = 0;

            try
            {

                total_col = 0;
                for (i = 0; i < cur_box.Items.Count; i++)
                {
                    if (GlobalVar.goUtility.SInStr(cur_box.Items[i].Text, "+") <= 0) // will include the empty value. "+" is used for priority.
                    {
                        total_col += 1;
                    }
                }

                GlobalVar.goUtility.ResizeDim(ref case_data, 2, total_col - 1);

                row_num = 0;
                for (i = 0; i < cur_box.Items.Count; i++)
                {
                    if (GlobalVar.goUtility.SInStr(cur_box.Items[i].Text, "+") <= 0)
                    {
                        case_data[VALUE_COL, row_num] = cur_box.Items[i].Value;
                        case_data[TEXT_COL, row_num] = cur_box.Items[i].Text;
                        row_num += 1;
                    }
                }

                return_value = true;

            }
            catch (Exception ex)
            {

                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CreateMonitorShowCases)");

            }

            return return_value;

        }

        public bool CreateMonitorShowCases(ref clsDatabase cur_db, ref string[,] case_data, ref clsRecordset cur_set, string value_field, string text_field)
        {

            bool return_value = false;
            int total_col = 0;
            int row_num = 0;
            string last_item = "";

            try
            {

                GlobalVar.goUtility.ResizeDim(ref case_data, 2, cur_set.RecordCount());

                case_data[VALUE_COL, 0] = ""; // For empty values
                case_data[TEXT_COL, 0] = "";

                total_col = 1;
                last_item = "";

                while (!cur_set.EOF())
                {
                    if (string.CompareOrdinal(last_item, cur_set.sField(value_field)) < 0)
                    {
                        case_data[VALUE_COL, total_col] = cur_set.sField(value_field).ToString();
                        case_data[TEXT_COL, total_col] = cur_set.sField(text_field);
                        last_item = cur_set.sField(value_field);
                        total_col += 1;
                    }
                    cur_set.MoveNext();
                }

                cur_set.MoveFirst();
                GlobalVar.goUtility.ResizeDimPreserved(ref case_data, 2, total_col - 1);

                return_value = true;

            }
            catch (Exception ex)
            {

                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CreateMonitorShowCases)");

            }

            return return_value;

        }

        public bool CreateMonitorShowDateCases(ref clsDatabase cur_db, ref string[,] case_data, ref clsRecordset cur_set, string value_field, string text_field)
        {

            bool return_value = false;
            int total_col = 0;
            int row_num = 0;
            int last_date = 0;
            clsGeneral o_gen = new clsGeneral(ref cur_db);

            try
            {

                GlobalVar.goUtility.ResizeDim(ref case_data, 2, cur_set.RecordCount());

                case_data[VALUE_COL, 0] = ""; // For empty values
                case_data[TEXT_COL, 0] = "";

                total_col = 1;
                last_date = 0;

                while (!cur_set.EOF())
                {
                    if (last_date < cur_set.iField(value_field))
                    {
                        case_data[VALUE_COL, total_col] = cur_set.iField(value_field).ToString();
                        case_data[TEXT_COL, total_col] = o_gen.ToStrDate(cur_set.iField(text_field));
                        last_date = cur_set.iField(value_field);
                        total_col += 1;
                    }
                    cur_set.MoveNext();
                }

                cur_set.MoveFirst();
                GlobalVar.goUtility.ResizeDimPreserved(ref case_data, 2, total_col - 1);

                return_value = true;

            }
            catch (Exception ex)
            {

                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CreateMonitorShowCases)");

            }

            return return_value;

        }

        public bool CreateMonitorShowWOStatusCases(ref clsDatabase cur_db, ref string[,] case_data, ref clsRecordset cur_set)
        {

            bool return_value = false;
            int total_col = 0;
            int row_num = 0;
            int last_num = 0;
            string value_field = "iStatus_typ";

            try
            {

                GlobalVar.goUtility.ResizeDim(ref case_data, 2, cur_set.RecordCount());

                case_data[VALUE_COL, 0] = ""; // For empty values
                case_data[TEXT_COL, 0] = "";

                total_col = 1;
                last_num = -1;

                while (!cur_set.EOF())
                {
                    if (last_num < cur_set.iField(value_field))
                    {
                        case_data[VALUE_COL, total_col] = cur_set.iField(value_field).ToString();
                        case_data[TEXT_COL, total_col] = GlobalVar.goStatus.WorkOrderStatusTypeText(cur_set.iField(value_field));
                        last_num = cur_set.iField(value_field);
                        total_col += 1;
                    }
                    cur_set.MoveNext();
                }

                cur_set.MoveFirst();
                GlobalVar.goUtility.ResizeDimPreserved(ref case_data, 2, total_col - 1);

                return_value = true;

            }
            catch (Exception ex)
            {

                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CreateMonitorShowCases)");

            }

            return return_value;

        }

#if WEB

        public bool BindCasesToSpreadsheet(ref clsDatabase cur_db, ref GridView cur_grid, int total_col, int max_row, string[,] header_data, string[,] main_data, ref clsWebDropdownList web_dropdownlist)
        {

            bool return_value = false;
            int col_num = 0;
            int row_num = 0;
            DataTable dt = new DataTable();
            DataRow dr = null;
            bool undefined_exist_fl = false;

            try
            {

                modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, 0, false, total_col - 1);
                modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, total_col, true, cur_grid.Columns.Count - 1);

                modWebGridUtility.SpreadsheetSetCell(ref cur_grid, 0, -1, GlobalVar.goString.STR_UNDEFINED); // The first column is for the undefined

                for (col_num = 1; col_num < total_col; col_num++)
                {
                    modWebGridUtility.SpreadsheetSetCell(ref cur_grid, col_num, -1, header_data[TEXT_COL, col_num]);
                }

                for (col_num = 0; col_num < total_col; col_num++)
                {
                    dt.Columns.Add(new DataColumn(modWebGridUtility.GetColumnId(col_num), typeof(string)));
                }

                undefined_exist_fl = false;

                for (row_num = 0; row_num <= max_row; row_num++)
                {
                    dr = dt.NewRow();
                    for (col_num = 0; col_num < total_col; col_num++)
                    {
                        dr[modWebGridUtility.GetColumnId(col_num)] = main_data[col_num, row_num];
                    }
                    if (!undefined_exist_fl)
                    {
                        undefined_exist_fl = !GlobalVar.goUtility.IsEmpty(main_data[0, row_num]);
                    }
                    dt.Rows.Add(dr);
                }

                cur_grid.DataSource = dt;
                cur_grid.DataBind();

                modWebGridUtility.CopyDataTableToGridView(ref cur_db, ref cur_grid, ref dt, ref web_dropdownlist);

                modWebGridUtility.SpreadsheetHideColumns(ref cur_grid, 0, !undefined_exist_fl);

                return_value = true;

            }
            catch (Exception ex)
            {

                modDialogUtility.DisplayBox(ref cur_db, ex.Message + "BindCasesToSpreadsheet");

            }

            return return_value;

        }

#endif

    }
}
