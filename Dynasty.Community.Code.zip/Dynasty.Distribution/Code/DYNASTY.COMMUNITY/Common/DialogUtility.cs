﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP
{
    internal static class modDialogUtility
    {
        public static void DisplayBox(ref clsDatabase cur_db, string dialog_msg, int dialog_option = 0, string dialog_name = "")
        {
            RaiseError(ref cur_db, dialog_msg);
        }

        //  PURPOSE: This is used to set the error message to the clsDatabase error-handler for WEB version
        //
        private static void RaiseError(ref clsDatabase cur_db, string dialog_msg)
        {
            cur_db.SetPostingError(dialog_msg);
        }
    }
}
