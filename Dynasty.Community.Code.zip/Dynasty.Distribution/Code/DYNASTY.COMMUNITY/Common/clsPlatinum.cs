﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP
{
    public class clsPlatinum
    {

        public const string BATCH_TABLE_NAME = "tblGOBatch";
        public const int TOTAL_SUMMARY_PAGES = 5;

        public string BatchBoard { get; set; } = "";

        public void ShowBatch(clsDatabase cur_db)
        {
            if (cur_db.ViewOnly() ||  cur_db.AllowBatchEntry() == false)
            {
                BatchBoard = "";
            }
            else if (cur_db.iBatch_num > 0)
            {
                BatchBoard = GlobalVar.goUtility.SUCase(GlobalVar.goString.STR_BATCH) + ": " + cur_db.iBatch_num.ToString();
            }
            else
            {
                BatchBoard = GlobalVar.goUtility.SUCase(GlobalVar.goString.STR_BATCH_OFF);
            }

        }

        public void ToggleBatch(ref clsDatabase cur_db)
        {
            if (cur_db.ViewOnly() || cur_db.AllowBatchEntry() == false)
            {
                cur_db.iBatch_num = 0;
            }
            else if (cur_db.iBatch_num == 0)
            {
                cur_db.iBatch_num = GetBatchNumber(ref cur_db, cur_db.sUser_cd);
            }
            else
            {
                if (TurnOffBatch(ref cur_db, cur_db.sUser_cd))
                {
                    cur_db.iBatch_num = 0;
                }
            }

            ShowBatch(cur_db);
        }

        public int GetBatchNumber(ref clsDatabase cur_db, string user_code)
        {

            int return_value = 0;
            string sql_str = "";
            int batch_um = 0;
            clsGeneral o_gen = new clsGeneral(ref cur_db);
            clsRecordset cur_set = new clsRecordset(ref cur_db);

            try
            {

                return_value = 0;

                if (!cur_db.AllowBatchEntry())
                {
                    return return_value;
                }

                if (!cur_db.TransactionBegin())
                {
                    return return_value;
                }

                batch_um = o_gen.GetSurrogateKey(BATCH_TABLE_NAME); // This will make sure BATCH_TABLE_NAME exists.

                if (batch_um <= 0)
                {
                    cur_db.TransactionRollback();
                    return return_value;
                }

                // At posting, batch table is deleted.  
                // When it is empty, reset the batch number.
                //
                if (!cur_set.CreateSnapshot("SELECT * FROM " + BATCH_TABLE_NAME))
                {

                    cur_db.TransactionRollback();
                    return return_value;

                }
                else if (cur_set.EOF())
                {

                    batch_um = 1;

                    sql_str = "UPDATE tblGONextKeyNumber SET";
                    sql_str += " iNextKey_num = " + (batch_um + 1).ToString();
                    sql_str += " WHERE sTable_nm = '" + BATCH_TABLE_NAME + "'";
                    if (!cur_db.ExecuteSQL(sql_str))
                    {
                        cur_db.TransactionRollback();
                        return return_value;
                    }

                }

                sql_str = "INSERT INTO " + BATCH_TABLE_NAME + " (";
                sql_str += " iBatch_num";
                sql_str += ",sUser_cd";
                sql_str += ",iStarted_dt";
                sql_str += ",iEnded_dt";
                sql_str += ") VALUES (";
                sql_str += " " + batch_um.ToString();
                sql_str += ",'" + user_code + "'";
                sql_str += "," + o_gen.CurrentDate();
                sql_str += ",0";
                sql_str += ")";
                if (!cur_db.ExecuteSQL(sql_str))
                {
                    cur_db.TransactionRollback();
                    return return_value;
                }

                if (!cur_db.TransactionCommit())
                {
                    cur_db.TransactionRollback();
                    return return_value;
                }

                if (GlobalVar.goUtility.SUCase(user_code) == GlobalVar.goUtility.SUCase(cur_db.sUser_cd))
                {
                    cur_db.iBatch_num = batch_um;
                }

                return_value = batch_um;

            }
            catch
            {
                // Just in case
            }

            return return_value;

        }

        public bool TurnOffBatch(ref clsDatabase cur_db, string user_code)
        {

            bool return_value = false;
            string sql_str = "";
            clsGeneral o_gen = new clsGeneral(ref cur_db);

            sql_str = "UPDATE " + BATCH_TABLE_NAME + " SET ";
            sql_str += " iEnded_dt = " + o_gen.CurrentDate();
            sql_str += " WHERE iEnded_dt = 0";
            if (GlobalVar.goUtility.IsNonEmpty(user_code))
            {
                sql_str += " AND sUser_cd = '" + user_code + "'";     // No user is specified, reset all.
            }
            if (cur_db.ExecuteSQL(sql_str))
            {
                if (GlobalVar.goUtility.SUCase(user_code) == GlobalVar.goUtility.SUCase(cur_db.sUser_cd))
                {
                    cur_db.iBatch_num = 0;
                }
                return_value = true;
            }

            return return_value;

        }

        public bool BatchIsUtilized(ref clsDatabase cur_db)
        {

            bool return_value = false;
            bool batch_exists_fl = false;
            clsRecordset cur_set = new clsRecordset(ref cur_db);

            if (!cur_db.bEnableBatchEntry_fl)
            {
                return false;
            }

            // Below, does not make sense
            batch_exists_fl = false;
            if (!cur_set.CreateSnapshot("SELECT MAX(iBatch_num) AS iMax FROM " + BATCH_TABLE_NAME))
            {
            }
            else if (cur_set.EOF())
            {
            }
            else if (cur_set.iField("iMax") > 0)
            {
                batch_exists_fl = true;
            }

            return_value = batch_exists_fl;

            return return_value;

        }

        // PURPOSE : To delete batch-if after posting.
        //
        public bool DeleteBatch(ref clsDatabase cur_db, string user_cd, int from_num, int thru_num)
        {

            bool return_value = false;
            string sql_str = "";

            if (!cur_db.bEnableBatchEntry_fl)
            {
                return true;
            }

            // Do not check for from_num > 0 or thru_num > 0
            // because this can be called with (from_num = 0 and thru_num = 0) to delete the phantom batch explained below.
            //
            sql_str = "DELETE FROM " + clsPlatinum.BATCH_TABLE_NAME;
            sql_str += " WHERE (iBatch_num BETWEEN " + from_num.ToString() + " AND " + thru_num.ToString();
            if (user_cd == cur_db.sUser_cd && cur_db.iUserType_id >= clsConstant.USER_SUPERVISOR_TYPE)
            {
                // Delete all
            }
            else if (from_num != thru_num) // If a batch range is sent for a regular staff, need to check the ownership.
            {
                sql_str += " AND sUser_cd = '" + user_cd + "'";
            }
            sql_str += ")";

            // Phantom: Transactions that do not post may come into this table.
            // Need to delete them.  i.e., Orders, B/R, payrolls, etc...
            // Not any more.  We only allow the transactions that are qualified for batch.
            //
            //sql_str &= " OR (iBatch_num NOT IN (SELECT iBatch_num FROM tblGOTransaction WHERE iBatch_num > 0))"

            return_value = cur_db.ExecuteSQL(sql_str);

            return return_value;

        }

        // PURPOSE : To clear the batch-id after daily-posting.
        //           inventory-oriented C/M and D/M do not post until the merchandise is arrvied and shipped, respectively.
        //           Until then, they hold batch-id, and it will cause trouble with new-id generated next day.
        //           We will just clean them up at daily posting with a fact that daily-batch id are meaningless after posting.
        //
        public bool ClearBatch(ref clsDatabase cur_db, string user_cd, int from_num, int thru_num)
        {

            bool return_value = false;
            string sql_str = "";
            string where_str = "";

            if (!cur_db.bEnableBatchEntry_fl)
            {
                return true;
            }

            where_str = " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_CM_TYPE.ToString();
            where_str += " AND iCompleted_fl = 0";
            where_str += " AND (iBatch_num BETWEEN " + from_num.ToString() + " AND " + thru_num.ToString();
            if (user_cd == cur_db.sUser_cd && cur_db.iUserType_id >= clsConstant.USER_SUPERVISOR_TYPE)
            {
                // Clear all
            }
            else if (from_num != thru_num) // If a batch range is sent for a regular staff, need to check the ownership.
            {
                where_str += " AND sCreator_id = '" + user_cd + "'";
            }
            where_str += ")";

            sql_str = "UPDATE tblGOTransaction SET iBatch_num = 0 WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_CM_TYPE.ToString();
            sql_str += " AND iTransaction_num IN (SELECT iTransaction_num FROM tblARChargeUnposted " + where_str + ")";
            if (!cur_db.ExecuteSQL(sql_str))
            {
                return false;
            }

            if (!cur_db.ExecuteSQL("UPDATE tblARChargeUnposted SET iBatch_num = 0 " + where_str))
            {
                return false;
            }

            sql_str = GlobalVar.goUtility.SReplace(sql_str, GlobalVar.goConstant.TRX_CM_TYPE.ToString(), GlobalVar.goConstant.TRX_DM_TYPE.ToString());
            sql_str = GlobalVar.goUtility.SReplace(sql_str, "tblAR", "tblAP");

            if (!cur_db.ExecuteSQL(sql_str))
            {
                return false;
            }

            where_str = GlobalVar.goUtility.SReplace(where_str, GlobalVar.goConstant.TRX_CM_TYPE.ToString(), GlobalVar.goConstant.TRX_DM_TYPE.ToString());
            where_str = GlobalVar.goUtility.SReplace(where_str, "tblAR", "tblAP");

            if (!cur_db.ExecuteSQL("UPDATE tblAPChargeUnposted SET iBatch_num = 0 " + where_str))
            {
                return false;
            }

            return_value = true;

            return return_value;

        }

    }
}
