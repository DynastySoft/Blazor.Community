﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;


using Dynasty.Local;
using Dynasty.Database;

namespace Dynasty.ASP
{
	public class clsSplitPayment
	{

#if WEB
		public bool CreateSchedule(ref clsDatabase cur_db, ref GridView cur_grid, int trx_type, decimal amt_due, int payment_num, int interval_type, int starting_date, ref clsWebDropdownList dropdown_list)
		{
#else
		public bool CreateSchedule(ref clsDatabase cur_db, ref DataGridView cur_grid, int trx_type, decimal amt_due, int payment_num, int interval_type, int starting_date)
		{
#endif

			bool return_value = false;
			int i = 0;
			string[,] schedule_data = null;

			if (cur_grid.Rows.Count < payment_num)
			{
#if WEB
				modWebGridUtility.SpreadsheetAddLines(ref cur_db, ref cur_grid, ref dropdown_list, payment_num - cur_grid.Rows.Count);
#else
				cur_grid.Rows.Clear();
				cur_grid.RowCount = payment_num;
#endif
			}

			GlobalVar.goUtility.ResizeDim(ref schedule_data, GlobalVar.goConstant.SPLIT_PAYMENT_TOTAL_DETAIL_COL - 1, cur_grid.Rows.Count - 1);

			for (i = 0; i < cur_grid.Rows.Count; i++)
			{
				modWebGridUtility.CopyCurrentRowIntoArray(ref cur_grid, i, ref schedule_data);
			}

			if (!CreateSchedule(ref cur_db, ref schedule_data, trx_type, amt_due, payment_num, interval_type, starting_date))
			{
				return false;
			}

			// This is necessary because schedule_data() could have been updated.
			//
			for (i = 0; i < cur_grid.Rows.Count; i++)
			{
				modWebGridUtility.CopyCurrentArrayRowToGrid(ref cur_grid, schedule_data, i);
			}

			return true;

		}

#if WEB
		public bool SaveSchedule(ref clsDatabase cur_db, GridView cur_grid, int trx_type, int trx_num, int apply_date, int invoice_date, string entity_code)
		{
#else
		public bool SaveSchedule(ref clsDatabase cur_db, ref DataGridView cur_grid, int trx_type, int trx_num, int apply_date, int invoice_date, string entity_code)
		{
#endif

			bool return_value = false;
			int i = 0;
			string[,] schedule_data = null;

			GlobalVar.goUtility.ResizeDim(ref schedule_data, GlobalVar.goConstant.SPLIT_PAYMENT_TOTAL_DETAIL_COL - 1, cur_grid.Rows.Count - 1);

			for (i = 0; i < cur_grid.Rows.Count; i++)
			{
				modWebGridUtility.CopyCurrentRowIntoArray(ref cur_grid, i, ref schedule_data);
			}

			return SaveSchedule(ref cur_db, ref schedule_data, trx_type, trx_num, apply_date, invoice_date, entity_code);

		}

#if WEB
		public bool CheckSchedule(ref clsDatabase cur_db, ref GridView cur_grid, ref clsWebDropdownList dropdown_list, int trx_type, int trx_num, decimal amt_total, ref decimal amt_total_splited, ref int due_date, decimal discount_amt, int discount_date)
		{
#else
		public bool CheckSchedule(ref clsDatabase cur_db, ref DataGridView cur_grid, int trx_type, int trx_num, decimal amt_total, ref decimal amt_total_splited, ref int due_date, decimal discount_amt, int discount_date)
		{
#endif

			bool return_value = false;
			int i = 0;
			string[,] schedule_data = null;

			if (cur_grid.Rows.Count == 0)
			{

#if WEB
				modWebGridUtility.SpreadsheetAddLines(ref cur_db, ref cur_grid, ref dropdown_list, 5);
#else
				cur_grid.RowCount = 5;
#endif

			}

			GlobalVar.goUtility.ResizeDim(ref schedule_data, GlobalVar.goConstant.SPLIT_PAYMENT_TOTAL_DETAIL_COL - 1, cur_grid.Rows.Count - 1);

			for (i = 0; i < cur_grid.Rows.Count; i++)
			{
				modWebGridUtility.CopyCurrentRowIntoArray(ref cur_grid, i, ref schedule_data);
			}

			if (!CheckSchedule(ref cur_db, ref schedule_data, trx_type, trx_num, amt_total, ref amt_total_splited, ref due_date, discount_amt, discount_date))
			{
				return false;
			}

			// This is necessary because schedule_data() could have been updated.
			//
			for (i = 0; i < cur_grid.Rows.Count; i++)
			{
				modWebGridUtility.CopyCurrentArrayRowToGrid(ref cur_grid, schedule_data, i);
			}

			return true;

		}

		public bool CreateSchedule(ref clsDatabase cur_db, ref string[,] schedule_data, int trx_type, decimal amt_due, int payment_num, int interval_type, int starting_date)
		{


			bool return_value = false;
			int i = 0;
			decimal split_amt = 0M;
			decimal total_amt = 0M;
			int due_date = 0;
			int apart_type = 0;
			int interval_num = 0;

			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			try
			{

				total_amt = amt_due;
				split_amt = Convert.ToInt32(amt_due) / payment_num;

				if (split_amt == 0M)
				{
					split_amt = total_amt;
				}

				if (interval_type == GlobalVar.goConstant.PAYMENT_FREQUENCY_YEARLY_NUM)
				{
					apart_type = GlobalVar.goConstant.YEAR_TYPE;
					interval_num = 1;
				}
				else if (interval_type == GlobalVar.goConstant.PAYMENT_FREQUENCY_SEMIYEARLY_NUM)
				{
					apart_type = GlobalVar.goConstant.MONTH_TYPE;
					interval_num = 6;
				}
				else if (interval_type == GlobalVar.goConstant.PAYMENT_FREQUENCY_QUARTERLY_NUM)
				{
					apart_type = GlobalVar.goConstant.MONTH_TYPE;
					interval_num = 3;
				}
				else if (interval_type == GlobalVar.goConstant.PAYMENT_FREQUENCY_BIMONTHLY_NUM)
				{
					apart_type = GlobalVar.goConstant.MONTH_TYPE;
					interval_num = 2;
				}
				else if (interval_type == GlobalVar.goConstant.PAYMENT_FREQUENCY_MONTHLY_NUM)
				{
					apart_type = GlobalVar.goConstant.MONTH_TYPE;
					interval_num = 1;
				}
				else if (interval_type == GlobalVar.goConstant.PAYMENT_FREQUENCY_BIWEEKLY_NUM)
				{
					apart_type = GlobalVar.goConstant.DAY_TYPE;
					interval_num = 14;
				}
				else if (interval_type == GlobalVar.goConstant.PAYMENT_FREQUENCY_WEEKLY_NUM)
				{
					apart_type = GlobalVar.goConstant.DAY_TYPE;
					interval_num = 7;
				}
				else
				{
					modDialogUtility.DisplayBox(ref cur_db, "Invalid interval is found.");
					return false;
				}

				due_date = starting_date;

				for (i = 0; i <= schedule_data.GetUpperBound(1); i++)
				{

					if (total_amt <= 0M)
					{

						schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, i] = "";
						schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, i] = "";

					}
					else
					{

						if (i == 0)
						{
							schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, i] = o_money.ToStrMoney(split_amt + (total_amt - (split_amt * payment_num)));
						}
						else
						{
							schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, i] = o_money.ToStrMoney(split_amt);
						}

						schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, i] = o_gen.ToStrDate(due_date);

						due_date = GlobalVar.goUtility.AddToDate(apart_type, due_date, interval_num);

						total_amt -= o_money.ToNumMoney(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, i]);

					}

					schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_AMOUNT_COL, i] = "";
					schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_DATE_COL, i] = "";

				}

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CreateSchedule)");
				return_value = false;

			}

			return return_value;


		}

		public bool SaveSchedule(ref clsDatabase cur_db, ref string[,] schedule_data, int trx_type, int trx_num, int apply_date, int invoice_date, string entity_code)
		{


			bool return_value = false;
			string sql_str = "";
			int line_num = 0;
			int detail_num = 0;
			clsRecordset cur_set = new clsRecordset(ref cur_db);
			string table_name = "";

			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			try
			{

				if (trx_type == GlobalVar.goConstant.TRX_INVOICE_TYPE)
				{
					table_name = "tblARChargeDue";
				}
				else
				{
					table_name = "tblAPChargeDue";
				}

				// Complete the partial payment if exists
				//
				sql_str = "UPDATE " + table_name + " SET mTotal_amt = mTotal_amt - mDue_amt, mDue_amt = 0";
				sql_str += " WHERE iTransaction_num = " + trx_num;
				sql_str += " AND iTransaction_typ = " + trx_type;
				sql_str += " AND mDue_amt > 0 AND mDue_amt < mTotal_amt";
				if (!cur_db.ExecuteSQL(sql_str))
				{
					return false;
				}

				//  Delete the open balance only.
				//
				sql_str = "DELETE FROM " + table_name;
				sql_str += " WHERE iTransaction_num = " + trx_num;
				sql_str += " AND iTransaction_typ = " + trx_type;
				sql_str += " AND mDue_amt > 0 ";
				if (!cur_db.ExecuteSQL(sql_str))
				{
					return false;
				}

				sql_str = "SELECT * FROM " + table_name;
				sql_str += " WHERE iTransaction_num = " + trx_num;
				sql_str += " AND iTransaction_typ = " + trx_type;
				sql_str += " ORDER BY iDetail_num DESC";
				if (!cur_set.CreateSnapshot(sql_str))
				{
					return false;
				}
				else if (cur_set.EOF())
				{
					detail_num = 0;
				}
				else
				{
					detail_num = cur_set.iField("iDetail_num");
				}

				for (line_num = 0; line_num <= schedule_data.GetUpperBound(1); line_num++)
				{

					if (GlobalVar.goUtility.STrim(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, line_num]) != "" && o_money.ToNumMoney(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, line_num]) > 0)
					{

						detail_num += 1;

						sql_str = "INSERT INTO " + table_name + "(";
						sql_str += " iTransaction_typ";
						sql_str += ",iTransaction_num";
						sql_str += ",iDetail_num";
						sql_str += ",iStatus_typ";
						sql_str += ",iDue_dt";
						sql_str += ",iDiscountDue_dt";
						sql_str += ",iApply_dt";

						if (trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE)
						{
							sql_str += ",iInvoice_dt";
							sql_str += ",sVendor_cd";
						}
						else
						{
							sql_str += ",sCustomer_cd";
						}

						sql_str += ",mTotal_amt";
						sql_str += ",mPaid_amt";
						sql_str += ",mDue_amt";
						sql_str += ",mReturned_amt";
						sql_str += ",mDiscForEarlyPaid_amt";
						sql_str += ",mRestockCharge_amt";
						sql_str += ",mDiscountAvailable_amt";
						sql_str += ",dtLastUpdate_dt";
						sql_str += ",sLastUpdate_id";
						sql_str += ") VALUES (";
						sql_str += " " + trx_type;
						sql_str += "," + trx_num;
						sql_str += "," + detail_num.ToString();
						sql_str += "," + GlobalVar.goConstant.POSTED_TRX_NUM.ToString();
						sql_str += "," + o_gen.ToNumDate(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, line_num]).ToString();
						sql_str += "," + o_gen.ToNumDate(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_DATE_COL, line_num]).ToString();
						sql_str += "," + apply_date;

						if (trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE)
						{
							sql_str += "," + invoice_date;
						}

						sql_str += ",'" + entity_code + "'";
						sql_str += "," + o_money.ToNumMoney(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, line_num]).ToString();
						sql_str += ",0";
						sql_str += "," + o_money.ToNumMoney(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, line_num]).ToString();
						sql_str += ",0";
						sql_str += ",0";
						sql_str += ",0";
						sql_str += "," + o_money.ToNumMoney(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_AMOUNT_COL, line_num]);
						sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
						sql_str += ",'" + cur_db.sUser_cd + "'";
						sql_str += ")";
						if (!cur_db.ExecuteSQL(sql_str))
						{
							return false;
						}
					}

				}

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(SaveSchedule)");
				return_value = false;

			}

			return return_value;

		}

		public bool CheckSchedule(ref clsDatabase cur_db, ref string[,] schedule_data, int trx_type, int trx_num, decimal amt_total, ref decimal amt_total_splited, ref int due_date, decimal discount_amt, int discount_date)
		{

			bool return_value = false;
			int row_num = 0;
			decimal cur_amt = 0M;

			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);

			try
			{


				if (due_date <= 0)
				{
					// Meanning that due date of posted invoice is changed.
				}
				else if ((amt_total <= 0M) || GlobalVar.goUtility.IsEmpty(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, 1])) // If this is a credit, or single payment scedule
				{

					// Single payment schedule STRICTLY goes by the invoice date and term.
					//
					schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, 0] = o_gen.ToStrDate(due_date);
					schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, 0] = amt_total.ToString();

					if (amt_total > 0M && discount_amt > 0M && discount_date > 0 && discount_date < due_date)
					{

						schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_DATE_COL, 0] = o_gen.ToStrDate(discount_date);
						schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_AMOUNT_COL, 0] = discount_amt.ToString();

					}
					else
					{

						schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_DATE_COL, 0] = "";
						schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_AMOUNT_COL, 0] = "";

					}

					for (row_num = 1; row_num <= schedule_data.GetUpperBound(1); row_num++)
					{
						schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, row_num] = "";
						schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, row_num] = "";
						schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_DATE_COL, row_num] = "";
						schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_AMOUNT_COL, row_num] = "";
					}

					amt_total_splited = amt_total;
					return true;

				}

				amt_total_splited = 0M;
				due_date = 0; // get the latest user entered

				for (row_num = 0; row_num <= schedule_data.GetUpperBound(1); row_num++)
				{

					if (o_money.ToNumMoney(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, row_num]) != 0 && !o_gen.ValidDate(ref schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, row_num]))
					{
						modDialogUtility.DisplayBox(ref cur_db, "Payment schedule dates are not set up, properly.");
						return false;
					}
					else if (GlobalVar.goUtility.IsEmpty(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, row_num]))
					{
						break;
					}

					if (row_num > 0)
					{
						if (o_gen.ToNumDate(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, row_num]) < o_gen.ToNumDate(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, row_num - 1]))
						{
							modDialogUtility.DisplayBox(ref cur_db, "Payment schedule dates are not in a proper order.");
							return false;
						}
					}

					if (o_gen.ToNumDate(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, row_num]) < o_gen.ToNumDate(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_DATE_COL, row_num]))
					{
						modDialogUtility.DisplayBox(ref cur_db, "Invalid discount date is found: " + schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_DATE_COL, row_num]);
						return false;
					}

					cur_amt = o_money.ToNumMoney(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, row_num]);
					amt_total_splited += cur_amt;

					if (due_date < o_gen.ToNumDate(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, row_num]))
					{
						due_date = o_gen.ToNumDate(schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, row_num]);
					}

				}

				if (amt_total != amt_total_splited)
				{

					if ((cur_amt + (amt_total - amt_total_splited)) < 0)
					{
						modDialogUtility.DisplayBox(GlobalVar.goMessage.IMPROPER_SPLIT_PAYMENT_FOUND);
						return false;
					}
					else
					{
						if (row_num > 0)
						{
							schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, row_num - 1] = o_money.ToStrMoney(cur_amt + amt_total - amt_total_splited);
							if (!o_gen.ValidDate(ref schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, row_num - 1]))
							{
								schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, row_num - 1] = o_gen.ToStrDate(due_date);
							}
						}
						else
						{
							schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, 0] = o_money.ToStrMoney(cur_amt + amt_total - amt_total_splited);
							schedule_data[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, 0] = o_gen.ToStrDate(due_date);
						}
					}

					amt_total_splited = amt_total;

				}

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CheckSchedule)");
				return_value = false;

			}

			return return_value;

		}
	}

}
