﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Database;
using Dynasty.Report;
using System.Drawing.Printing;

namespace Dynasty.ASP
{
#if WEB
#else
using System.Windows.Forms;
//	Imports System.Windows.Forms.Application
#endif

	internal static class modCommonReportUtility
	{

		public const string BLANK_REPORT_FILE_NAME = "blankpage.rpt";

#if WEB
#else
		private static PrintDocument moPrintDocument;
#endif

		private static int miTotalLines;
		private static string[] msOnePageText = new string[101];

		// PURPOSE : To get the initial of report scripts depending on the connection type.
		//
		public static string GetReportInitial(ref clsDatabase cur_db)
		{

			string return_value = "";

			if (cur_db.CurrentConnectionType() == GlobalVar.goConstant.CONNECTION_OLEDB_TYPE)
			{
				return_value = "3"; // Access database only
			}
			else if (cur_db.CurrentDatabaseType() == GlobalVar.goConstant.DB_ORACLE_TYPE)
			{
				return_value = "2"; // ORACLE reports start with 2
			}
			else if (cur_db.CurrentDatabaseType() == GlobalVar.goConstant.DB_MYSQL_TYPE)
			{
				return_value = "4"; // MySQL reports start with 4
			}
			else
			{
				return_value = "1"; // SQLServer/Access ODBC reports start with 1
			}

			return return_value;

		}

		// PURPOSE : To select a invoice script name.
		//
		public static string GetInvoiceReportFileName(ref clsDatabase cur_db, string form_type)
		{

			string return_value = "";

			if (form_type == "FRMMCINVOICE")
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "604l1mc.rpt"; // foreign currency
			}
			else if (form_type == "FRMMCINVOICE-PC")
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "604l1pc.rpt"; // primary currency from foreign currency transaction
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FI1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "601f1.rpt"; // Form-based inventory 1
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FI2)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "602f2.rpt"; // Form-based inventory 2
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FS)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "603fs.rpt"; // Form-based service
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LI1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "604l1.rpt"; // Laser-based inventory 1
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LW1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "604w1.rpt"; // Laser-based matrix type 1
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LM1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "604m1.rpt"; // Laser-based matrix type 1
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LI2)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "605l2.rpt"; // Laser-based inventory 2
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LC1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "604c1.rpt"; // Laser-based compact type 1
			}
			else
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "606ls.rpt"; // Laser-based service
			}

			return return_value;

		}

		// PURPOSE : To select a invoice script name.
		//
		public static string GetReprintInvoiceReportFileName(ref clsDatabase cur_db, string form_type)
		{

			string return_value = "";
			if (form_type == "FRMMCINVOICE")
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "607l1mc.rpt"; // foreign currency
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LI1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "607l1.rpt"; // Laser-based inventory 1
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LW1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "607w1.rpt"; // Laser-based matrix type 1
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LM1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "607m1.rpt"; // Laser-based matrix type 1
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LC1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "607c1.rpt"; // Laser-based compact type 1
			}
			else
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "607l1.rpt"; // Laser-based inventory 1
			}

			return return_value;
		}

		// PURPOSE : To select a C/M script name.
		//
		public static string GetCMReportFileName(ref clsDatabase cur_db, string form_type)
		{

			string return_value = "";
			if (form_type == "FRMMCCREDITMEMO")
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "608l1mc.rpt"; // foreign currency
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LW1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "608w1.rpt"; // Laser-based matrix type 1
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LC1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "608c1.rpt"; // Laser-based compact type 1
			}
			else
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "608l1.rpt"; // Laser-based inventory 1
			}

			return return_value;
		}

		// PURPOSE : To select a C/M script name.
		//
		public static string GetReprintCMReportFileName(ref clsDatabase cur_db, string form_type)
		{

			string return_value = "";

			if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LC1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "609c1.rpt"; // Laser-based compact type 1
			}
			else
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "609l1.rpt"; // Laser-based inventory 1
			}

			return return_value;
		}

		// PURPOSE : To select a packing slip name from invoice.
		//           This works with invoice report names.
		//           Check with GetInvoiceReportFileName(goDatabase, moDatabase, ).
		//
		public static string GetInvoicePackingSlipFileName(ref clsDatabase cur_db, string form_type)
		{

			string return_value = "";

			if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FI1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "621f1.rpt"; // Form-based inventory 1
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FI2)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "622f2.rpt"; // Form-based inventory 2
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FS)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "623fs.rpt"; // Form-based service
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LI1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "624l1.rpt"; // Laser-based inventory 1
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LW1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "624w1.rpt"; // Laser-based wide
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LM1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "624m1.rpt"; // Laser-based matrix type 1
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LI2)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "625l2.rpt"; // Laser-based inventory 2
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LC1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "624c1.rpt"; // Laser-based compact type 1
			}
			else
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "626ls.rpt"; // Laser-based service
			}

			return return_value;

		}

		// PURPOSE : To select a statement script name.
		//
		public static string GetStatementReportFileName(ref clsDatabase cur_db, string form_type, bool open_item = true, bool aging_bucket = false, bool adhoc_fl = false)
		{

			string return_value = "";
			if (form_type == "MCSTATEMENT")
			{
				//If open_item Then
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "614l1mc.rpt"; // Laser-based open-item statement
				//Else
				//return_value = cur_db.uDirectory.sReportDirectory_nm & "\ar" & GetReportInitial(ref cur_db) & "612l1mc.rpt"          ' Laser-based balance-forward statement
				//End If
			}
			else
			{
				//If open_item Then

				if (adhoc_fl)
				{
                    return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "612AdHocl1.rpt"; // Laser-based Ad-Hoc statement
                }
                else
				{
                    return_value = cur_db.uDirectory.sReportDirectory_nm + "\\ar" + GetReportInitial(ref cur_db) + "612l1.rpt"; // Laser-based open-item statement
                }
                //Else
                //return_value = cur_db.uDirectory.sReportDirectory_nm & "\ar" & GetReportInitial(ref cur_db) & "614l1.rpt"               ' Laser-based balance-forward statement
                //End If
            }

			return return_value;

		}

		// PURPOSE : To select the sales order report file name.
		//
		public static string GetOrderReportFileName(ref clsDatabase cur_db, string form_type)
		{

			string return_value = "";
			if (form_type == "MCORDER-PC")
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "604l1pc.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FI1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "601f1.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FI2)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "602f2.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FS)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "603fs.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LW1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "604w1.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LM1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "604m1.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LI2)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "605l2.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LS1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "606ls.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LC1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "604c1.rpt"; // Laser-based compact type 1
			}
			else
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "604l1.rpt";
			}

			return return_value;
		}

		// PURPOSE : To select a packing slip name from order screen.
		//           This works with order report names.
		//           Check with GetOrderReportFileName(goDatabase, ).
		//
		public static string GetOrderPackingSlipFileName(ref clsDatabase cur_db, string form_type)
		{

			string return_value = "";
			if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FI1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "621f1.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FI2)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "622f2.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FS)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "623fs.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LW1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "624w1.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LM1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "624m1.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LI2)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "625l2.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LS1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "626ls.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LC1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "624c1.rpt"; // Laser-based compact type 1
			}
			else
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "624l1.rpt";
			}

			return return_value;
		}

		// PURPOSE : To select a packing slip name from packing slip screen.
		//           This works with order report names.
		//           Check with GetOrderPackingSlipFileName(goDatabase, ).
		//
		public static string GetPackingSlipFileName(ref clsDatabase cur_db, string form_type)
		{

			string return_value = "";
			if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FI1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "631f1.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FI2)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "632f2.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FS)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "633fs.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LW1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "634w1.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LM1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "634m1.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LI2)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "635l2.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LS1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "636ls.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_LC1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "634c1.rpt"; // Laser-based compact type 1
			}
			else
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "634l1.rpt";
			}

			return return_value;
		}

		// PURPOSE : To select a picking slip name from packing slip screen.
		//           This works with order report names.
		//           Check with GetOrderPackingSlipFileName(goDatabase, ).
		//
		public static string GetPickingSlipFileName(ref clsDatabase cur_db, string form_type)
		{

			clsGeneral o_gen = new clsGeneral(ref cur_db);
			string report_name = "";

			string return_value = "";
			if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FI1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "641f1.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FI2)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "642f2.rpt";
			}
			else if (form_type == GlobalVar.goARConstant.INVOICE_TYPE_FS)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "643fs.rpt";
			}
			else
			{

				if (!o_gen.IsBinManaged())
				{
					report_name = "644l1.rpt";
				}
				else if (cur_db.iMaxBins_num <= 3)
				{
					report_name = "644l1mb.rpt";
				}
				else
				{
					report_name = "644l1mb5.rpt";
				}

				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + report_name;

			}

			return return_value;
		}

		// PURPOSE : To select the quote report file name.
		//
		public static string GetQuoteReportFileName(ref clsDatabase cur_db, string cur_form_type)
		{

			string return_value = "";
			if (cur_form_type == "MCQUOTE-PC")
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "614l1pc.rpt";
			}
			else if (cur_form_type == GlobalVar.goARConstant.INVOICE_TYPE_FI1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "611f1.rpt";
			}
			else if (cur_form_type == GlobalVar.goARConstant.INVOICE_TYPE_FS)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "613fs.rpt";
			}
			else if (cur_form_type == GlobalVar.goARConstant.INVOICE_TYPE_LI1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "614l1.rpt";
			}
			else if (cur_form_type == GlobalVar.goARConstant.INVOICE_TYPE_LW1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "614w1.rpt";
			}
			else if (cur_form_type == GlobalVar.goARConstant.INVOICE_TYPE_LM1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "614m1.rpt";
			}
			else if (cur_form_type == GlobalVar.goSOConstant.QUOTE_TYPE_LI2)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "617lp.rpt";
			}
			else if (cur_form_type == GlobalVar.goSOConstant.QUOTE_TYPE_LI1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "618lq.rpt";
			}
			else
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\so" + GetReportInitial(ref cur_db) + "616ls.rpt";
			}

			return return_value;
		}

		// PURPOSE : To select the purchase order report scrit.
		//
		public static string GetPurchaseOrderReportFileName(ref clsDatabase cur_db, string form_type)
		{

			string return_value = "";

			if (form_type == "MCORDER-PC")
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\po" + GetReportInitial(ref cur_db) + "601i1pc.rpt";
			}
			else if (form_type == GlobalVar.goPOConstant.ORDER_TYPE_FI1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\po" + GetReportInitial(ref cur_db) + "602f1.rpt";
			}
			else if (form_type == GlobalVar.goPOConstant.ORDER_TYPE_LI1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\po" + GetReportInitial(ref cur_db) + "601i1.rpt";
			}
			else if (form_type == GlobalVar.goPOConstant.ORDER_TYPE_LM1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\po" + GetReportInitial(ref cur_db) + "601m1.rpt";
			}
			else if (form_type == GlobalVar.goPOConstant.ORDER_TYPE_LW1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\po" + GetReportInitial(ref cur_db) + "601w1.rpt";
			}
			else if (form_type == GlobalVar.goPOConstant.ORDER_TYPE_LC1)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\po" + GetReportInitial(ref cur_db) + "601c1.rpt"; // Laser-based compact type 1
			}
			else
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\po" + GetReportInitial(ref cur_db) + "603i1.rpt";
			}

			return return_value;
		}

		// PURPOSE : To select the purchase quote report scrit.
		//
		public static string GetPurchaseQuoteReportFileName(ref clsDatabase cur_db, bool foreign_fl)
		{

			string return_value = "";
			if (foreign_fl)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\po" + GetReportInitial(ref cur_db) + "611i1.rpt";
			}
			else
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\po" + GetReportInitial(ref cur_db) + "611i1pc.rpt";
			}

			return return_value;
		}

		// PURPOSE : To set the company info in each report.
		//
		public static bool SetCompanyInReport(ref clsDatabase cur_db, string form_name, ref clsReportViewer cur_report, string dropship_customer_cd = "", bool use_logo_fl = false)
		{

			bool return_value = false;
			string sql_str = "";
			clsRecordset cur_set = null;

			try
			{

				cur_set = new clsRecordset(ref cur_db);

				if (GlobalVar.goUtility.IsEmpty(dropship_customer_cd))
				{
					sql_str = "SELECT sCompany_nm";
					sql_str += ",sAddress1";
					sql_str += ",sAddress2";
					sql_str += ",sAddress3";
					sql_str += ",sPhone";
					sql_str += ",sFax";
					sql_str += " FROM tblGOMaster";
				}
				else
				{
					sql_str = "SELECT sCustomer_nm AS sCompany_nm";
					sql_str += ",sAddress1";
					sql_str += ",sAddress2";
					sql_str += ",sAddress3";
					sql_str += ",sPhone1 AS sPhone";
					sql_str += ",sFax";
					sql_str += " FROM tblARCustomer";
					sql_str += " WHERE sCustomer_cd = '" + dropship_customer_cd + "'";
				}

				if (!cur_set.CreateSnapshot(sql_str))
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_set.GetErrorMessage());
					return return_value;
				}
				else if (cur_set.EOF())
				{
					return return_value;
				}


				if (use_logo_fl && GlobalVar.goUtility.IsEmpty(dropship_customer_cd) && GlobalVar.goUtility.SInStr(GlobalVar.goUtility.SUCase(form_name), "LABEL") <= 0)
				{

					cur_report.SetFormula("comp_name", "");
					cur_report.SetFormula("comp_addr1", "");
					cur_report.SetFormula("comp_addr2", "");
					cur_report.SetFormula("comp_addr3", "");
					cur_report.SetFormula("comp_phone", "");
					cur_report.SetFormula("comp_fax", "");

					if (GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmPrintStatement"))
					{
						cur_report.SetFormula("return_name", (cur_set.sField("sCompany_nm")));
						cur_report.SetFormula("return_addr1", (cur_set.sField("sAddress1")));
						if (GlobalVar.goUtility.IsNonEmpty(cur_set.sField("sAddress2")))
						{
							cur_report.SetFormula("return_addr2", (cur_set.sField("sAddress2")));
							cur_report.SetFormula("return_addr3", (cur_set.sField("sAddress3")));
						}
						else
						{
							cur_report.SetFormula("return_addr2", (cur_set.sField("sAddress3")));
							cur_report.SetFormula("return_addr3", "");
						}
					}

					cur_set.Release();
					return true;

				}
				else if (GlobalVar.goUtility.SInStr(GlobalVar.goUtility.SUCase(form_name), "LABEL") <= 0)
				{

					cur_report.SetFormula("comp_name", (cur_set.sField("sCompany_nm")));
					cur_report.SetFormula("comp_addr1", (cur_set.sField("sAddress1")));
					if (GlobalVar.goUtility.IsNonEmpty(cur_set.sField("sAddress2")))
					{
						cur_report.SetFormula("comp_addr2", (cur_set.sField("sAddress2")));
					}
					else
					{
						cur_report.SetFormula("comp_addr2", (cur_set.sField("sAddress3")));
					}

				}

				if (GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmPrintDepositSlip"))
                {
					if (GlobalVar.goUtility.IsNonEmpty(cur_set.sField("sAddress2")))
					{
						cur_report.SetFormula("comp_addr3", (cur_set.sField("sAddress3")));
					}
					else
					{
						cur_report.SetFormula("comp_addr3", "");
					}
					if (GlobalVar.goUtility.IsNonEmpty(cur_set.sField("sPhone")))
					{
						cur_report.SetFormula("comp_phone", cur_set.sField("sPhone"));
					}
					if (GlobalVar.goUtility.IsNonEmpty(cur_set.sField("sFax")))
					{
						cur_report.SetFormula("comp_fax", cur_set.sField("sFax"));
					}
				}
				else if (GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmQuickPrintInvoice") || GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmQuickPrintPackage") 
					|| GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmQuickPrintPackingSlip") || GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmReprintInvoice") 
					|| GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmQuickPrintCM") || GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmPrintPostedCM") 
					|| GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmQuickPrintSlip") || GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmPrintStatement") 
					|| GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmPrintInvoice") || GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmQuickPrintPO") 
					|| GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmQuickPrintPOQuote") || GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmQuickPrintOrder") 
					|| GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmQuickPrintQuote") || GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmPrintPostedInvoice") 
					|| GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmPrint1099") || GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmPrintPR1099") 
					|| GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmCashPayment") || GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmLookupCashPayment") 
					|| GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmCashDisbursement") || GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmQuickFARental") 
					|| GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmQuickPurchaseRequisition") || GlobalVar.goUtility.SInStr(GlobalVar.goUtility.SUCase(form_name), GlobalVar.goUtility.SUCase("frmRMA")) > 0 
					|| GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmQuickPrintDM") || GlobalVar.goUtility.SUCase(form_name) == GlobalVar.goUtility.SUCase("frmQuickPrintReceipt"))
				{

					if (GlobalVar.goUtility.IsNonEmpty(cur_set.sField("sAddress2")))
					{
						cur_report.SetFormula("comp_addr3", (cur_set.sField("sAddress3")));
					}
					else
					{
						cur_report.SetFormula("comp_addr3", "");
					}
					if (GlobalVar.goUtility.IsNonEmpty(cur_set.sField("sPhone")))
					{
						cur_report.SetFormula("comp_phone", "Phone : " + cur_set.sField("sPhone"));
					}
					if (GlobalVar.goUtility.IsNonEmpty(cur_set.sField("sFax")))
					{
						cur_report.SetFormula("comp_fax", "Fax : " + cur_set.sField("sFax"));
					}

				}

				cur_set.Release();
				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(SetCompanyInReport(goDatabase, )");

			}

			return return_value;

		}

		public static void InitPrinterFont()
		{

			int temp = 0;

			try
			{

#if WEB
#else
			   moPrintDocument = new PrintDocument();
#endif
				miTotalLines = 0;

			}
			catch (Exception ex)
			{

			}

		}

		public static void PrintToPrinter(string text_line)
		{

			msOnePageText[miTotalLines] = text_line;
			miTotalLines += 1;

		}

		// This will finish the current printing.
		//
#if WEB

		public static void EndToPrinter(ref clsReportViewer cur_report)
		{

			PrintToPrinter("");
			SetReportSelection(ref cur_report);

		}

		private static bool SetReportSelection(ref clsReportViewer cur_report)
		{

			bool return_value = false;
			try
			{

				cur_report.SetFormula("line_01", msOnePageText[0]);
				cur_report.SetFormula("line_02", msOnePageText[1]);
				cur_report.SetFormula("line_03", msOnePageText[2]);
				cur_report.SetFormula("line_04", msOnePageText[3]);
				cur_report.SetFormula("line_05", msOnePageText[4]);
				cur_report.SetFormula("line_06", msOnePageText[5]);
				cur_report.SetFormula("line_07", msOnePageText[6]);
				cur_report.SetFormula("line_08", msOnePageText[7]);
				cur_report.SetFormula("line_09", msOnePageText[8]);
				cur_report.SetFormula("line_10", msOnePageText[9]);
				cur_report.SetFormula("line_11", msOnePageText[10]);
				cur_report.SetFormula("line_12", msOnePageText[11]);
				cur_report.SetFormula("line_13", msOnePageText[12]);
				cur_report.SetFormula("line_14", msOnePageText[13]);
				cur_report.SetFormula("line_15", msOnePageText[14]);
				cur_report.SetFormula("line_16", msOnePageText[15]);
				cur_report.SetFormula("line_17", msOnePageText[16]);
				cur_report.SetFormula("line_18", msOnePageText[17]);
				cur_report.SetFormula("line_19", msOnePageText[18]);
				cur_report.SetFormula("line_20", msOnePageText[19]);
				cur_report.SetFormula("line_21", msOnePageText[20]);
				cur_report.SetFormula("line_22", msOnePageText[21]);
				cur_report.SetFormula("line_23", msOnePageText[22]);
				cur_report.SetFormula("line_24", msOnePageText[23]);
				cur_report.SetFormula("line_25", msOnePageText[24]);
				cur_report.SetFormula("line_26", msOnePageText[25]);
				cur_report.SetFormula("line_27", msOnePageText[26]);
				cur_report.SetFormula("line_28", msOnePageText[27]);
				cur_report.SetFormula("line_29", msOnePageText[28]);
				cur_report.SetFormula("line_30", msOnePageText[29]);
				cur_report.SetFormula("line_31", msOnePageText[30]);
				cur_report.SetFormula("line_32", msOnePageText[31]);
				cur_report.SetFormula("line_33", msOnePageText[32]);
				cur_report.SetFormula("line_34", msOnePageText[33]);
				cur_report.SetFormula("line_35", msOnePageText[34]);
				cur_report.SetFormula("line_36", msOnePageText[35]);
				cur_report.SetFormula("line_37", msOnePageText[36]);
				cur_report.SetFormula("line_38", msOnePageText[37]);
				cur_report.SetFormula("line_39", msOnePageText[38]);
				cur_report.SetFormula("line_40", msOnePageText[39]);
				cur_report.SetFormula("line_41", msOnePageText[40]);
				cur_report.SetFormula("line_42", msOnePageText[41]);
				cur_report.SetFormula("line_43", msOnePageText[42]);
				cur_report.SetFormula("line_44", msOnePageText[43]);
				cur_report.SetFormula("line_45", msOnePageText[44]);
				cur_report.SetFormula("line_46", msOnePageText[45]);
				cur_report.SetFormula("line_47", msOnePageText[46]);
				cur_report.SetFormula("line_48", msOnePageText[47]);
				cur_report.SetFormula("line_49", msOnePageText[48]);
				cur_report.SetFormula("line_50", msOnePageText[49]);
				cur_report.SetFormula("line_51", msOnePageText[50]);
				cur_report.SetFormula("line_52", msOnePageText[51]);
				cur_report.SetFormula("line_53", msOnePageText[52]);
				cur_report.SetFormula("line_54", msOnePageText[53]);
				cur_report.SetFormula("line_55", msOnePageText[54]);
				cur_report.SetFormula("line_56", msOnePageText[55]);
				cur_report.SetFormula("line_57", msOnePageText[56]);
				cur_report.SetFormula("line_58", msOnePageText[57]);
				cur_report.SetFormula("line_59", msOnePageText[58]);
				cur_report.SetFormula("line_60", msOnePageText[59]);

				return return_value;
			}
			catch (Exception ex)
			{

			}

			return false;
		}

#else

		public static void EndToPrinter()
		{

			PrintToPrinter("");
			moPrintDocument.Print();

		}

		private static void moPrintDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{

			 // Just in case. Some events kicks in when form is loaded and raise errors.

			int line_num = 0;
			int text_len = 0;
			int cur_pos = 0;
			Font printFont = new Font(GlobalVar.goConstant.CHECK_FONT_NAME, GlobalVar.goConstant.CHECK_FONT_SIZE);
			int pos_y = 0;
			int pos_x = 0;
			int top_margin = 0;
			int left_margin = 0;

			top_margin = 0;
			left_margin = 0;
			for (line_num = 0; line_num < miTotalLines; line_num++)
			{
				pos_y = Convert.ToInt32(line_num * (printFont.GetHeight(e.Graphics) - 2.15));
				text_len = msOnePageText[line_num].Length;
				for (cur_pos = 1; cur_pos <= text_len; cur_pos++)
				{
					pos_x = Convert.ToInt32((cur_pos - 1) * 10);
					e.Graphics.DrawString(GlobalVar.goUtility.SMid(msOnePageText[line_num], cur_pos, 1), printFont, Brushes.Black, pos_x, pos_y);
				}
			}

		}

#endif

		public static string CleanupFormula(string formula_str)
		{

			string return_value = "";

			formula_str = GlobalVar.goUtility.STrim(formula_str);
			if (GlobalVar.goUtility.IsNonEmpty(formula_str))
			{
				if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(formula_str, 4)) == "AND ")
				{
					formula_str = GlobalVar.goUtility.SRight(formula_str, GlobalVar.goUtility.SLength(formula_str) - 4);
				}
				else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(formula_str, 3)) == "OR ")
				{
					formula_str = GlobalVar.goUtility.SRight(formula_str, GlobalVar.goUtility.SLength(formula_str) - 3);
				}
			}
			return_value = GlobalVar.goUtility.STrim(formula_str);

			return return_value;

		}


		// PURPOSE : To select a invoice script name.
		//
		public static string GetWorkOrderFileName(ref clsDatabase cur_db, string where_clause, int wo_type)
		{

			string return_value = "";
			clsRecordset cur_set = new clsRecordset(ref cur_db);
			string sql_str = "";

            if (wo_type == GlobalVar.goWOConstant.WO_TO_GENERAL_NUM)
            {
                return_value = cur_db.uDirectory.sReportDirectory_nm + "\\wo" + GetReportInitial(ref cur_db) + "601.rpt";
            }
            else if (wo_type == GlobalVar.goWOConstant.WO_TO_WAREHOUSE_NUM || wo_type == GlobalVar.goWOConstant.WO_TO_PRODUCTION_NUM)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\wo" + GetReportInitial(ref cur_db) + "603.rpt";
			}
			else if (wo_type == GlobalVar.goWOConstant.WO_TO_FACILITY_NUM)
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\wo" + GetReportInitial(ref cur_db) + "605.rpt";
			}
			else 
			{
				return_value = cur_db.uDirectory.sReportDirectory_nm + "\\wo" + GetReportInitial(ref cur_db) + "607.rpt";
			}

			return return_value;

		}


		static modCommonReportUtility()
		{

//   static event handler wireups:
#if ! (WEB)
			moPrintDocument.PrintPage += moPrintDocument_PrintPage;
#endif
		}
	}

}
