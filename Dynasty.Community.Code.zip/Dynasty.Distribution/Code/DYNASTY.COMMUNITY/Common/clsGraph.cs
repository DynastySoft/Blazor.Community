﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//



using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Caching;
using System.Web.SessionState;
using System.Web.Security;
using System.Web.Profile;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Dynasty.ASP
{
#if WEB
using System.Web.UI.DataVisualization.Charting;
#else
using System.Windows.Forms.DataVisualization.Charting;
#endif

using System.Drawing;
using Dynasty.Database;
using Dynasty.Local;

	public class clsGraph
	{

		public const string CHART_TYPE_3D_BAR = "3D Bar";
		public const string CHART_TYPE_2D_BAR = "2D Bar";
		public const string CHART_TYPE_3D_LINE = "3D Line";
		public const string CHART_TYPE_2D_LINE = "2D Line";
		public const string CHART_TYPE_3D_AREA = "3D Area";
		public const string CHART_TYPE_2D_AREA = "2D Area";
		public const string CHART_TYPE_3D_STEP = "3D Step";
		public const string CHART_TYPE_2D_STEP = "2D Step";
		public const string CHART_TYPE_3D_PIE = "3D Pie";
		public const string CHART_TYPE_2D_PIE = "2D Pie";

		private string[,] sGraphData; // Just to preserve the original data.

		public bool DrawChart(ref clsDatabase cur_db, ref Chart cur_chart, string[,] chart_data, SeriesChartType chart_type = SeriesChartType.Line, bool D3_fl = true, string chart_title = "", string chart_sub_title = "", int u_of_m = 1)
		{

			bool return_value = false;

			int row_num = 0;
			int col_num = 0;
			int i = 0;
			clsMoney o_money = new clsMoney(ref cur_db);
			string units = "";

			try
			{

				if (u_of_m == 1000000000000000)
				{
					units = "(in Q)";
				}
				else if (u_of_m == 1000000000000)
				{
					units = "(in T)";
				}
				else if (u_of_m == 1000000000)
				{
					units = "(in B)";
				}
				else if (u_of_m == 1000000)
				{
					units = "(in M)";
				}
				else if (u_of_m == 1000)
				{
					units = "(in K)";
				}
				else
				{
					units = "";
				}

				if (u_of_m <= 0)
				{
					u_of_m = 1;
				}

				while (cur_chart.Series.Count > 1)
				{
					cur_chart.Series.RemoveAt(cur_chart.Series.Count - 1);
					modGeneralUtility.RunEvents();
				}

				while (cur_chart.Titles.Count > 0)
				{
					cur_chart.Titles.RemoveAt(cur_chart.Titles.Count - 1);
					modGeneralUtility.RunEvents();
				}

				while (cur_chart.Legends.Count > 0)
				{
					cur_chart.Legends.RemoveAt(cur_chart.Legends.Count - 1);
					modGeneralUtility.RunEvents();
				}

				if ((chart_data == null))
				{
					return return_value;
				}
				else if (chart_data.GetLength(0) == 0 || chart_data.GetLength(1) == 0)
				{
					return return_value;
				}

				GlobalVar.goUtility.ResizeDim(ref sGraphData, chart_data.GetUpperBound(0), chart_data.GetUpperBound(1));
				for (col_num = 0; col_num < sGraphData.GetLength(0); col_num++)
				{
					for (row_num = 0; row_num < sGraphData.GetLength(1); row_num++)
					{
						sGraphData[col_num, row_num] = chart_data[col_num, row_num];
					}
				}

				chart_data = null;

				// DATA EXAMPLE :
				//    The first row shows the item codes.
				//    The first column shows the periods.
				//    The actual data starts from cell(1,1) which is 2652 in the example below
				//
				//   0   |    1     |    2     |    3     |    4     |    5     |
				// ----------------------------------------------------------------------------------
				//       | ITEM 01  | ITEM 02  | ITEM 03  | ITEM 04  | ITEM 05  |
				// 1997  |  2652    |  627     |   536    |    465   |   423    |   
				// 1998  |  1722    |  767     |   736    |    735   |   223    |   
				// 1999  |  1928    |  327     |   236    |    265   |   323    |   
				// 2000  |   626    |  725     |   733    |    765   |   823    |   
				// 2001  |  2352    |  122     |   435    |    465   |   783    |   
				// 

				// Each item will be a series meaning each column.
				//

				for (col_num = 1; col_num < sGraphData.GetLength(0); col_num++)
				{
					if (!GlobalVar.goUtility.IsEmpty(sGraphData[col_num, 0]))
					{
						cur_chart.Series.Add(sGraphData[col_num, 0]); // Item name.
						cur_chart.Series[sGraphData[col_num, 0]].ChartType = chart_type;
						cur_chart.Series[sGraphData[col_num, 0]].IsValueShownAsLabel = true;
						cur_chart.Series[sGraphData[col_num, 0]].CustomProperties = "ShowMarkerLines = true";
						cur_chart.Series[sGraphData[col_num, 0]].LabelForeColor = System.Drawing.Color.Red;
						cur_chart.Series[sGraphData[col_num, 0]].BorderWidth = 1;
						cur_chart.Series[sGraphData[col_num, 0]].BorderColor = System.Drawing.Color.Gray;

						// If less than 6, manipulate the color
						//
						if (sGraphData.GetLength(0) < 6)
						{
							switch (col_num)
							{
								case 1:
									cur_chart.Series[sGraphData[col_num, 0]].Color = System.Drawing.Color.Red;
									break;
								case 2:
									cur_chart.Series[sGraphData[col_num, 0]].Color = System.Drawing.Color.Navy;
									break;
								case 3:
									cur_chart.Series[sGraphData[col_num, 0]].Color = System.Drawing.Color.Green;
									break;
								case 4:
									cur_chart.Series[sGraphData[col_num, 0]].Color = System.Drawing.Color.DarkCyan;
									break;
								case 5:
									cur_chart.Series[sGraphData[col_num, 0]].Color = System.Drawing.Color.SteelBlue;
									break;
								default:

								break;
							}
						}

						for (row_num = 1; row_num < sGraphData.GetLength(1); row_num++)
						{
							cur_chart.Series[sGraphData[col_num, 0]].Points.AddY(Math.Round(o_money.ToNumMoney(sGraphData[col_num, row_num]) / u_of_m, 2));
							modGeneralUtility.RunEvents();
						}
					}
				}

				// Place the x-axis labels.
				//
				for (row_num = 1; row_num < sGraphData.GetLength(1); row_num++)
				{
					cur_chart.Series[1].Points[row_num - 1].AxisLabel = sGraphData[0, row_num];
					modGeneralUtility.RunEvents();
				}

				cur_chart.Series[0].IsVisibleInLegend = false; // Series(0) is system generated, and we do not use it.

				if (!GlobalVar.goUtility.IsEmpty(chart_title))
				{
					cur_chart.Titles.Add(chart_title);
					cur_chart.Titles[0].Text = chart_title;
					cur_chart.Titles[0].TextOrientation = TextOrientation.Horizontal;
					cur_chart.Titles[0].ForeColor = System.Drawing.Color.RoyalBlue;
					cur_chart.Titles[0].Font = new Font("Arial", 12F, FontStyle.Bold);
					if (!GlobalVar.goUtility.IsEmpty(chart_sub_title))
					{
						cur_chart.Titles.Add(chart_sub_title);
						cur_chart.Titles[1].Text = "- " + chart_sub_title + units + " -";
						cur_chart.Titles[1].TextOrientation = TextOrientation.Horizontal;
						cur_chart.Titles[1].ForeColor = System.Drawing.Color.RoyalBlue;
						cur_chart.Titles[1].Font = new Font("Arial", 10);
					}
				}

				cur_chart.ChartAreas[0].BackColor = System.Drawing.Color.White;
				cur_chart.ChartAreas[0].BackGradientStyle = GradientStyle.TopBottom;
				cur_chart.ChartAreas[0].ShadowColor = System.Drawing.Color.LightGray;
				cur_chart.ChartAreas[0].BorderColor = System.Drawing.Color.Silver;
				cur_chart.ChartAreas[0].BorderWidth = 1;

				cur_chart.ChartAreas[0].AxisX.LineColor = System.Drawing.Color.Silver;
				cur_chart.ChartAreas[0].AxisX.LineWidth = 1;
				cur_chart.ChartAreas[0].AxisX.MajorGrid.LineColor = System.Drawing.Color.Silver;
				cur_chart.ChartAreas[0].AxisX.MajorGrid.LineWidth = 1;

				cur_chart.ChartAreas[0].AxisY.LineColor = System.Drawing.Color.Silver;
				cur_chart.ChartAreas[0].AxisY.LineWidth = 1;
				cur_chart.ChartAreas[0].AxisY.MajorGrid.LineColor = System.Drawing.Color.Silver;
				cur_chart.ChartAreas[0].AxisY.MajorGrid.LineWidth = 1;

				cur_chart.Legends.Add("0");
				cur_chart.Legends[0].BorderColor = System.Drawing.Color.Silver;
				cur_chart.Legends[0].BackColor = System.Drawing.Color.Transparent;

				cur_chart.BackColor = System.Drawing.Color.White;


				ChangeChartType(ref cur_chart, chart_type, D3_fl);
				modGeneralUtility.RunEvents();
				return_value = true;

				return return_value;

			}
			catch (Exception ex)
			{

#if WEB
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "((DrawChart))");
#else
				modDialogUtility.DisplayBox("DrawChart");
#endif
				return return_value;

			}

		}

		public void ChangeChartType(ref Chart cur_chart, SeriesChartType chart_type, bool D3_fl = true)
		{

			try
			{

				int i = 0;
				cur_chart.ChartAreas[0].Area3DStyle.Enable3D = D3_fl;
				for (i = 0; i < cur_chart.Series.Count; i++)
				{
					cur_chart.Series[i].ChartType = chart_type;
				}

			}
			catch
			{
				// Just in case
			}


		}


		public SeriesChartType FindChartType(string chart_type, ref bool d3_fl)
		{

			SeriesChartType return_value = 0;

			try
			{

				d3_fl = false;

				switch (chart_type)
				{

					case CHART_TYPE_3D_BAR:
						return_value = SeriesChartType.Bar;
						d3_fl = true;
						break;
					case CHART_TYPE_2D_BAR:
						return_value = SeriesChartType.Bar;
						break;
					case CHART_TYPE_3D_LINE:
						return_value = SeriesChartType.Line;
						d3_fl = true;
						break;
					case CHART_TYPE_2D_LINE:
						return_value = SeriesChartType.Line;
						break;
					case CHART_TYPE_3D_AREA:
						return_value = SeriesChartType.Area;
						d3_fl = true;
						break;
					case CHART_TYPE_2D_AREA:
						return_value = SeriesChartType.Area;
						break;
					case CHART_TYPE_3D_STEP:
						return_value = SeriesChartType.StepLine;
						d3_fl = true;
						break;
					case CHART_TYPE_2D_STEP:
						return_value = SeriesChartType.StepLine;
						break;
					case CHART_TYPE_3D_PIE:
						return_value = SeriesChartType.Pie;
						d3_fl = true;
						break;
					case CHART_TYPE_2D_PIE:
						return_value = SeriesChartType.Pie;
						break;
					default:
						return_value = 0;
						break;
				}

			}
			catch
			{
				return_value = 0;
			}

			return return_value;

		}

	}

}
