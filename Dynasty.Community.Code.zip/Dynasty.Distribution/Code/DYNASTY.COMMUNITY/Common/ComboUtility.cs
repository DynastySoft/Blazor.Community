﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

using Dynasty.ASP.Models;
using Dynasty.Database;

namespace Dynasty.ASP
{

    //  THIS IS THE COLLECTION OF LOADING FOR BOTH WEB/WIN VERSION.
    //  THIS WORKS WITH WinLoadUtility and WebLoadUtility.
    //
    internal static class modComboUtility
    {
        private static clsDynastyUtility moUtility = new clsDynastyUtility();

		public static string GetText(List<Models.clsCombobox> cur_list, string cur_value)
		{
			string return_value = "";

			return_value = cur_list.Single(i => i.Value == cur_value).Text;

			return return_value;

		}

		// This Function extracts a code embedded in combobox.text to save.
		// Normally, a ComboBox.text has a code followed by the its description
		// divided by goConstant.ID_DELIMITER.
		//
		public static string GetCodeInText(List<Models.clsCombobox> cur_list, string cur_value)
		{
			string return_value = "";
			string combo_text = "";

			combo_text = cur_list.Single(i => i.Value == cur_value).Text;

			// If delimiter is used, the code comes before the delimiter.
			//
			if (moUtility.SInStr(combo_text, GlobalVar.goConstant.ID_DELIMITER) > 0)
			{
				return_value = moUtility.SLeft(combo_text, moUtility.SInStr(combo_text, GlobalVar.goConstant.ID_DELIMITER) - 1);
			}
			else
			{
				return_value = combo_text;
			}

			return return_value;

		}

		// This will extract the description from a combobox text in the format of "CODE : DESCRIPTION".
		//
		public static string GetDescriptionInText(List<Models.clsCombobox> cur_list, string cur_value)
		{
			string return_value = "";
			string combo_text = "";

			combo_text = cur_list.Single(i => i.Value == cur_value).Text;

			if (moUtility.SInStr(combo_text, GlobalVar.goConstant.ID_DELIMITER) > 1)
			{
				return_value = moUtility.SRight(combo_text, moUtility.SLength(combo_text) - moUtility.SInStr(combo_text, GlobalVar.goConstant.ID_DELIMITER) - 1);
			}
			else
			{
				return_value = combo_text;
			}

			return_value = moUtility.STrim(return_value);

			return return_value;

		}

		// This will extract the actual value from dropdown list that has extra letters for the sake of uniqueness.
		// Example is LoadBankDraftType() of web-version
		//
		public static string GetSelectedValue(string cur_value)
		{
			string return_value = "";

			if (moUtility.SInStr(cur_value, GlobalVar.goConstant.ID_DELIMITER) > 1)
			{
				return_value = moUtility.SRight(cur_value, moUtility.SLength(cur_value) - moUtility.SInStr(cur_value, GlobalVar.goConstant.ID_DELIMITER) - 1);
			}
			else
			{
				return_value = cur_value;
			}

			return_value = moUtility.STrim(return_value);

			return return_value;
		}

	}
}
