﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//
//Option Explicit On 
//Option Strict On


using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Local;
using Dynasty.Database;
//Imports System.Windows.Forms.Application

namespace Dynasty.ASP
{
	internal static class modDetailUtility
	{
		public static bool GetDetail(ref clsDatabase cur_db, string form_name, string key_value, string key_field_name, ref int total_rows, string detail_table, int transaction_type, string[] field_names, ref string[,] detail_data
			, bool exact_rows_fl = false, bool get_balance_fl = false, string entity_code = "")
		{

			bool return_value = false;
			string sql_str = "";
			clsRecordset cur_set = null;
			int col_num = 0;
			int total_cols = 0;
			int row_num = 0;
			string tmp = "";
			string data_field = "";
			string encloser = "";
			bool skip_line_fl = false;
			decimal smallest_qty = 0;

			clsGeneral o_gen = null;
			clsMoney o_money = null;
			clsWorkOrder o_wo = null;
			clsSerial o_serial = null;

			try
			{

				o_gen = new clsGeneral(ref cur_db);
				o_money = new clsMoney(ref cur_db);
				o_wo = new clsWorkOrder(ref cur_db);
				o_serial = new clsSerial(ref cur_db);
				cur_set = new clsRecordset(ref cur_db);
				smallest_qty = cur_db.fSmallestNumber;

				if (GlobalVar.goUtility.SLeft(key_field_name, GlobalVar.goUtility.SLength(GlobalVar.goRule.STRING_FIELD_PREFIX)) == GlobalVar.goRule.STRING_FIELD_PREFIX)
				{
					encloser = "'";
				}
				else
				{
					encloser = "";
				}

				if (GlobalVar.goUtility.SRight(key_field_name, GlobalVar.goUtility.SLength(GlobalVar.goRule.DATE_FIELD_SUFFIX)) == GlobalVar.goRule.DATE_FIELD_SUFFIX)
				{
					key_value = GlobalVar.goUtility.STrim(GlobalVar.goUtility.ToStr(o_gen.ToNumDate(key_value)));
				}

				sql_str = "SELECT * FROM " + detail_table;

				if (GlobalVar.goUtility.IsNonEmpty(key_field_name))
                {
					sql_str += " WHERE " + key_field_name + "=" + encloser + key_value + encloser;
				}

				if (GlobalVar.goUtility.SUCase(detail_table) == GlobalVar.goUtility.SUCase("tblWOTransactionDet"))
				{
					sql_str += " AND iRecord_typ = " + clsWorkOrder.RECORD_TYPE_REGULAR.ToString();
				}

				// 01/09/2020
				// When get_balance_fl is true, this needs to get back order only.
				//
				if (get_balance_fl)
				{
					sql_str += " AND fBackorder_qty > " + smallest_qty.ToString();
				}

				if (transaction_type == GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE && GlobalVar.goUtility.IsNonEmpty(entity_code))
				{
					sql_str += " AND (sEntity_cd = '" + entity_code + "' OR sEntity_cd = '' OR sEntity_cd IS NULL)";
				}

				if (transaction_type == GlobalVar.goConstant.MAINT_SERIAL_TYPE)
				{
					sql_str += " ORDER BY sItem_cd, sLocation_cd, sSerial_num ";
					//ElseIf transaction_type = BIN_ASSIGNMENT_TYPE Then
					//    sql_str &= " ORDER BY sBin_cd "
				}
				else if (transaction_type == GlobalVar.goConstant.MAINT_CURRENCY_TYPE)
				{
					exact_rows_fl = true;
					sql_str += " AND iIndex_dt > " + GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.MONTH_TYPE, o_gen.CurrentDate(), -3).ToString();
					sql_str += " ORDER BY sCurrency_cd, iIndex_dt DESC";
				}
				else if (transaction_type == GlobalVar.goConstant.MAINT_PREMPLOYEE_TYPE)
				{
					sql_str += " ORDER BY sGroup_cd";
				}
				else if (transaction_type == GlobalVar.goConstant.MAIN_IV_ITEM_TYPE)
				{
					sql_str += " ORDER BY sSummaryItem_cd";
				}
				else if (form_name == cur_db.oLanguage.oCaption.UNIT_OF_MEASUREMENT)
                {
					sql_str += " ORDER BY sItem_cd, sFromUnit_cd, sToUnit_cd";
				}
				else
				{
					if (detail_table == "tblIVLocationBin")
					{
						sql_str += " ORDER BY sBin_cd";
					}
					else if (detail_table == "tblIVItemType")
					{
						sql_str += " WHERE iItem_typ >= " + GlobalVar.goIVConstant.SUMMARY_SALES_ITEM_TYPES.ToString();
						sql_str += " ORDER BY iItem_typ, sDescription";
					}
					else if (GlobalVar.goUtility.SInStr(GlobalVar.goUtility.SUCase(detail_table), GlobalVar.goUtility.SUCase("InterestGroupDet")) > 0)
					{
						sql_str += " ORDER BY sInterestGroup_cd";
					}
					else
					{
						if (detail_table == "tblPRTaxDet")
						{
							sql_str += " AND iTax_typ = " + transaction_type;
						}
						else if (transaction_type > 0 && transaction_type != GlobalVar.goConstant.TRX_PRJOURNAL_TYPE && transaction_type != GlobalVar.goConstant.TRX_MULTI_JOURNAL_TYPE && transaction_type != GlobalVar.goConstant.TRX_JOURNAL_TYPE) // Journal does not have iTransaction_typ field.
						{
							sql_str += " AND iTransaction_typ = " + transaction_type;
						}

						sql_str += " ORDER BY iDetail_num";
					}

				}

				if (cur_set.CreateSnapshot(sql_str) == false)
				{
					return return_value;
				}
				else if (cur_set.IsEmpty())
				{
					if (transaction_type == GlobalVar.goConstant.MAINT_CURRENCY_TYPE)
					{
						sql_str = "SELECT * FROM " + detail_table;
						sql_str += " WHERE " + key_field_name + " = " + encloser + key_value + encloser;
						sql_str += " AND iIndex_dt > " + GlobalVar.goUtility.AddToDate(GlobalVar.goConstant.YEAR_TYPE, o_gen.CurrentDate(), -5).ToString();
						sql_str += " ORDER BY sCurrency_cd, iIndex_dt DESC";
						if (!cur_set.CreateSnapshot(sql_str))
						{
							return return_value;
						}
						else if (cur_set.IsEmpty())
						{
							return true;
						}
					}
					else
					{
						return true;
					}
				}

				modGeneralUtility.RunEvents();

				if ((GlobalVar.goUtility.SInStr(GlobalVar.goUtility.SUCase(form_name), "LOOKUP") > 0) 
					|| (GlobalVar.goUtility.SInStr(GlobalVar.goUtility.SUCase(form_name), "LOOK-UP") > 0) 
					|| (GlobalVar.goUtility.SInStr(GlobalVar.goUtility.SUCase(form_name), "CASHPAYMENT") > 0) 
					|| (GlobalVar.goUtility.SInStr(GlobalVar.goUtility.SUCase(form_name), "CASHRECEIPT") > 0)
					|| (GlobalVar.goUtility.SInStr(GlobalVar.goUtility.SUCase(form_name), "PERIOD") > 0)
					|| (GlobalVar.goUtility.SInStr(GlobalVar.goUtility.SUCase(form_name), "PRJOURNAL") > 0)
					|| transaction_type == GlobalVar.goConstant.TRX_RFQ_TYPE
					|| transaction_type == GlobalVar.goConstant.TRX_PO_QUOTE_TYPE
					|| transaction_type == GlobalVar.goConstant.TRX_BR_DEPOSIT_SLIP_TYPE
					)
				{
					GlobalVar.goUtility.ResizeDim(ref detail_data, detail_data.GetUpperBound(0), cur_set.RecordCount() - 1); // No trailing lines.
				}
				else
				{
                    //if (detail_data.GetLength(1) < cur_set.RecordCount() + 2)
                    //{
                    GlobalVar.goUtility.ResizeDim(ref detail_data, detail_data.GetUpperBound(0), cur_set.RecordCount() + 1);		// just 2 more lines for mobile practice.
                    //}
                }

				total_cols = field_names.GetLength(0);
				total_rows = detail_data.GetLength(1);
				row_num = 0;

				while (!cur_set.EOF())
				{

					skip_line_fl = false;

					if (GlobalVar.goUtility.SInStr(GlobalVar.goUtility.SUCase(form_name), "LOOKUP") > 0)
                    {

                    }
					else if (transaction_type == GlobalVar.goConstant.TRX_SO_TYPE || transaction_type == GlobalVar.goConstant.TRX_QUOTE_TYPE)
					{
						if (cur_set.iField("iLine_typ") > 0)
						{
							skip_line_fl = true;
						}
					}
					else if ((transaction_type == GlobalVar.goConstant.TRX_INVOICE_TYPE || transaction_type == GlobalVar.goConstant.TRX_SO_PACKING_SLIP_TYPE)
					|| (transaction_type == GlobalVar.goConstant.TRX_CM_TYPE || transaction_type == GlobalVar.goConstant.TRX_DM_TYPE || transaction_type == GlobalVar.goConstant.TRX_TRANSFER_TYPE)
					|| (transaction_type == GlobalVar.goConstant.TRX_TRANSFER_OUT_TYPE || transaction_type == GlobalVar.goConstant.TRX_TRANSFER_IN_TYPE))
					{
						if (cur_set.iField("iLine_typ") > 0)
						{
							skip_line_fl = true;
						}
						else if ((GlobalVar.goUtility.IsEmpty(cur_set.sField("sItem_cd"))) && (o_serial.IsSerialOrLotItem(cur_set.iField("iItem_typ"))) 
						&& (GlobalVar.goUtility.SInStr(cur_set.sField("sDescription").ToString(), cur_db.oLanguage.oString.STR_SERIAL_NUM_MARKER) == 1 || GlobalVar.goUtility.SInStr(cur_set.sField("sDescription").ToString(), cur_db.oLanguage.oString.STR_LOT_NUM_MARKER) == 1))
						{
							skip_line_fl = true;
						}
					}

					if (!skip_line_fl)
					{
						for (col_num = 0; col_num < total_cols; col_num++)
						{
							data_field = GlobalVar.goUtility.STrim(GlobalVar.goUtility.GetDataFieldName(field_names[col_num]));

							if (GlobalVar.goUtility.IsNonEmpty(data_field))
							{
								if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SRight(data_field, GlobalVar.goUtility.SLength(GlobalVar.goRule.AMOUNT_FIELD_SUFFIX))) == GlobalVar.goUtility.SUCase(GlobalVar.goRule.AMOUNT_FIELD_SUFFIX))
								{
									tmp = o_money.ToStrMoney(cur_set.mField(data_field));
								}
								else if (GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SRight(data_field, GlobalVar.goUtility.SLength(GlobalVar.goRule.DATE_FIELD_SUFFIX))) == GlobalVar.goUtility.SUCase(GlobalVar.goRule.DATE_FIELD_SUFFIX) 
								&& GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(data_field, GlobalVar.goUtility.SLength(GlobalVar.goRule.INTEGER_FIELD_PREFIX))) == GlobalVar.goUtility.SUCase(GlobalVar.goRule.INTEGER_FIELD_PREFIX))
								{
									tmp = o_gen.ToStrDate(cur_set.iField(data_field));
								}
								else if (transaction_type == GlobalVar.goConstant.TRX_PHYSICAL_TYPE 
								&& GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SLeft(data_field, GlobalVar.goUtility.SLength(GlobalVar.goRule.FLOAT_FIELD_PREFIX))) == GlobalVar.goUtility.SUCase(GlobalVar.goRule.FLOAT_FIELD_PREFIX))
								{

									// 02/28/2020
									// Extra qty used to be represented with "-" sign which confused users.
									//
									if (cur_set.mField(data_field) < 0)
									{
										tmp = "(" + Math.Abs(cur_set.mField(data_field)).ToString() + ")";
									}
									else
									{
										tmp = cur_set.mField(data_field).ToString();
									}

								}
								else
								{
									tmp = GlobalVar.goUtility.ToStr(cur_set.Field(data_field));
								}

								// In Price and U/M table, goConstant.FOR_ALL string is used to indicate
								// for all items.  It should not be shown.
								//
								if (GlobalVar.goUtility.SUCase(data_field) == GlobalVar.goUtility.SUCase("sItem_cd") && tmp == GlobalVar.goConstant.FOR_ALL)
								{
									detail_data[col_num, row_num] = "";
								}
								else if (GlobalVar.goUtility.SUCase(data_field) == ("sOrigin") && tmp == GlobalVar.goConstant.FOR_ALL)
								{
									detail_data[col_num, row_num] = "";
								}
								else if ((GlobalVar.goUtility.SUCase(data_field) == GlobalVar.goUtility.SUCase("iPO_num") || GlobalVar.goUtility.SUCase(data_field) == GlobalVar.goUtility.SUCase("iOrder_num")) && GlobalVar.goUtility.ToValue(tmp) == 0)
								{
									detail_data[col_num, row_num] = "";
								}
								else if (get_balance_fl && (GlobalVar.goUtility.SUCase(data_field) == GlobalVar.goUtility.SUCase("iSourceDetail_num")))
								{
									detail_data[col_num, row_num] = cur_set.iField("iDetail_num").ToString();				// 01/09/2020. When get_balance_fl is True, get the remaining balance
								}
								else
								{
									detail_data[col_num, row_num] = tmp;
								}
							}
						}

						// 08/20/2021.  
						// Local invoice has discount calculation problem because it is based on UNIT_PRICE_IN_PRIMARY_CURRENCY_COL
						//
						if (transaction_type == GlobalVar.goConstant.TRX_INVOICE_TYPE && GlobalVar.goUtility.IsEmpty(detail_data[Models.clsChargeDetail.UNIT_PRICE_IN_PRIMARY_CURRENCY_COL, row_num]))
                        {
							detail_data[Models.clsChargeDetail.UNIT_PRICE_IN_PRIMARY_CURRENCY_COL, row_num] = detail_data[Models.clsChargeDetail.UNIT_PRICE_COL, row_num];
							detail_data[Models.clsChargeDetail.AMT_DISC_IN_PRIMARY_CURRENCY_COL, row_num] = detail_data[Models.clsChargeDetail.AMT_DISC_COL, row_num];
						}

						row_num += 1;
					}

					cur_set.MoveNext();

				}

				modGeneralUtility.RunEvents();
				return_value = true;

			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(GetDetail)");
			}

			return return_value;

		}

		// Delete the old details and get an empty record that will carry the size of each field.
		//
		public static bool PreSaveDetail(ref clsDatabase cur_db,ref clsRecordset size_set, ref string field_list, int trx_type, string key_value, string key_field_name, string table_name, string[] field_names, int total_cols)
		{
			bool return_value = false;

			int col_num = 0;
			string sql_str = "";
			string dummy_val = "";
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			try
			{
				size_set = new clsRecordset(ref cur_db);

				// Delete the existing records, first.
				//
				sql_str = "DELETE FROM " + table_name;

				if (GlobalVar.goUtility.IsNonEmpty(key_field_name))		// Some tables such as tblGOUnit do not have key field provided.
                {
					sql_str += " WHERE " + key_field_name + "=" + o_gen.EncloseField(key_field_name, key_value);
				}
				else if (GlobalVar.goUtility.SUCase(table_name) == GlobalVar.goUtility.SUCase("tblIVItemType"))     
				{
					sql_str += " WHERE iItem_typ > " + GlobalVar.goIVConstant.SUMMARY_SALES_ITEM_TYPES.ToString();
				}

				if (trx_type > 0 && trx_type != GlobalVar.goConstant.TRX_JOURNAL_TYPE && trx_type != GlobalVar.goConstant.TRX_MULTI_JOURNAL_TYPE && trx_type != GlobalVar.goConstant.TRX_PRJOURNAL_TYPE)
				{
					sql_str += " AND iTransaction_typ = " + trx_type.ToString();
				}

				if (cur_db.ExecuteSQL(sql_str) == false)
				{
					return false;
				}

				sql_str = "SELECT * FROM " + table_name;

				// Grab the name and size of each field.
				//
				if (GlobalVar.goUtility.IsNonEmpty(key_field_name))
				{
					if (GlobalVar.goUtility.SLeft(key_field_name, GlobalVar.goRule.INTEGER_FIELD_PREFIX.Length) == GlobalVar.goRule.INTEGER_FIELD_PREFIX)
					{
						dummy_val = "-100";
					}
					else
					{
						dummy_val = "'!'";
					}

					sql_str += " WHERE " + key_field_name + " = " + dummy_val;
				}

				if (size_set.CreateSnapshot(sql_str) == false)
				{
					return false;
				}

				// Create the field list.
				//
				if (GlobalVar.goUtility.IsNonEmpty(key_field_name))
                {
					field_list = key_field_name;
					if (trx_type > 0 && trx_type != GlobalVar.goConstant.TRX_JOURNAL_TYPE && trx_type != GlobalVar.goConstant.TRX_MULTI_JOURNAL_TYPE && trx_type != GlobalVar.goConstant.TRX_PRJOURNAL_TYPE)
					{
						field_list += ",iTransaction_typ";
					}
					if (GlobalVar.goUtility.SUCase(table_name) != GlobalVar.goUtility.SUCase("tblFARentalFeeDet"))
                    {
						field_list += ",iDetail_num";
					}
				}

				for (col_num = 0; col_num < total_cols; col_num++)
				{
					if (GlobalVar.goUtility.IsNonEmpty(field_names[col_num]))	// Attach if field name exist.
					{
						field_list += GlobalVar.goUtility.IIf(GlobalVar.goUtility.IsNonEmpty(field_list), ",", "") + field_names[col_num];
					}
					modGeneralUtility.RunEvents();
				}

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(PreSaveDetail)");
				return_value = false;

			}

			return return_value;
		}

		public static  bool DeleteCurrentRow(ref clsDatabase cur_db, ref string[,] detail_data, int cur_row)
        {
			clsArray o_array = new clsArray();

			if(o_array.DeleteCurrentRow(ref detail_data, cur_row) == false)
            {
				cur_db.SetPostingError(o_array.GetErrorMessage());
				return false;
            }

			return true;
        }

		public static bool InsertNewRow(ref clsDatabase cur_db, ref string[,] detail_data, int cur_row)
        {
			clsArray o_array = new clsArray();

			if (o_array.InsertNewRow(ref detail_data, cur_row) == false)
			{
				cur_db.SetPostingError(o_array.GetErrorMessage());
				return false;
			}

			return true;
		}
	}

}
