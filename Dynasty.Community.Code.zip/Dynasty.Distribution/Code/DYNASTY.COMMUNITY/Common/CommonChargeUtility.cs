﻿//  Copyright (c) DynastySoft Corporation, 2012.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP
{
	internal static class CommonChargeUtility
	{
		public static bool CalculateDetailRow(ref clsDatabase cur_db, ref string[,] detail_data, int trx_type, int cur_row, int item_code_col, int item_type_col, int job_code_col, int unit_price_col, int tax_code_col, int tax_perc_col, int amt_tax_col, int qty_col, int amt_extended_col, int disc_perc_col, int amt_disc_col, int total_cost_col, int amt_tax_in_pc_col = -1, int amt_extended_in_pc_col = -1, int amt_disc_in_pc_col = -1, int unit_price_in_pc_col = -1, decimal exchange_rate = -1)
		{
			bool return_value = false;
			decimal qty_shipped = 0;
			decimal unit_price = 0;
			decimal line_tax_amt = 0;
			decimal tax_perc = 0;
			decimal disc_perc = 0;
			decimal amt_taxable = 0;
			decimal amt_extended = 0;
			decimal amt_nontaxable = 0;
			decimal total_tax = 0;
			decimal amt_trx = 0;
			string item_code = "";
			string tax_code = "";
			string job_code = "";

			decimal amt_disc = 0;
			int item_type = 0;

			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);

			try
			{
				unit_price = o_money.ToNumMoney(detail_data[unit_price_col, cur_row]);
				item_type = GlobalVar.goUtility.ToInteger(detail_data[item_type_col, cur_row]);
				item_code = detail_data[item_code_col, cur_row];
				tax_code = detail_data[tax_code_col, cur_row];
				tax_perc = GlobalVar.goUtility.ToValue(detail_data[tax_perc_col, cur_row]);
				if (job_code_col >= 0)
				{
					job_code = detail_data[job_code_col, cur_row];
				}
				if (disc_perc_col >= 0)
				{
					disc_perc = GlobalVar.goUtility.ToValue(detail_data[disc_perc_col, cur_row]);
				}
				if (amt_disc_col >= 0)
				{
					amt_disc = o_money.ToNumMoney(detail_data[amt_disc_col, cur_row]);
				}

				// Accept negative line items, now
				//
				if (unit_price < 0)
				{
					if (!GlobalVar.goUtility.IsNegativePriceCarryItemType(item_type)) // 07/04/2016 This will let the rebate/discount item carry the item code for report later on
					{
						item_code = "";
					}
					job_code = "";
					disc_perc = 0;
					amt_disc = 0;
				}

				// If tax_code field is empty, then it is assummed that this item is either non-taxable or exempted.
				//
				if (GlobalVar.goUtility.IsEmpty(tax_code))
				{
					tax_perc = 0;
				}

				//  Copy to the vars in order to handle easier in the small screen.
				//
				qty_shipped = o_money.ToNumMoney(detail_data[qty_col, cur_row]);
				unit_price = o_money.ToNumMoney(detail_data[unit_price_col, cur_row]);

				amt_extended = o_money.RoundToMoney(qty_shipped * unit_price);

				if (o_money.TooLargeDollar(amt_extended))
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.TOO_LARGE_DOLLAR);
					return return_value;
				}

				// Caluculate the tax for this line.
				//
				if (!o_gen.CalcSalesTax(amt_extended, tax_perc, ref line_tax_amt, (tax_perc < 0)))
				{
					return return_value;
				}

				detail_data[item_code_col, cur_row] = item_code;
				detail_data[tax_code_col, cur_row] = tax_code;
				if (job_code_col >= 0)
				{
					detail_data[job_code_col, cur_row] = job_code;
				}
				if (disc_perc_col >= 0)
				{
					detail_data[disc_perc_col, cur_row] = disc_perc.ToString();
				}
				if (amt_disc_col >= 0)
				{
					detail_data[amt_disc_col, cur_row] = amt_disc.ToString();
				}
				detail_data[amt_tax_col, cur_row] = o_money.ToStrMoney(line_tax_amt);
				detail_data[amt_extended_col, cur_row] = o_money.ToStrMoney(amt_extended);

				// 08/08/2018  Was sending wrong cost.
				//
				if (trx_type != GlobalVar.goConstant.TRX_INVOICE_TYPE && trx_type != GlobalVar.goConstant.TRX_CM_TYPE)
				{
					if (total_cost_col >= 0)
					{
						detail_data[total_cost_col, cur_row] = o_money.ToStrMoney(amt_extended);
					}
				}

				if (amt_tax_in_pc_col > 0)
				{
					detail_data[amt_tax_in_pc_col, cur_row] = o_money.ToStrMoney(o_currency.ConvertToPrimaryCurrency(o_money.ToNumMoney(detail_data[amt_tax_col, cur_row]), exchange_rate));
				}
				if (amt_extended_in_pc_col > 0 && unit_price_in_pc_col > 0)
				{
					detail_data[amt_extended_in_pc_col, cur_row] = o_money.ToStrMoney(o_money.RoundToMoney(o_money.ToNumMoney(detail_data[unit_price_in_pc_col, cur_row]) * GlobalVar.goUtility.ToValue(detail_data[qty_col, cur_row])));
				}
				if (amt_disc_in_pc_col > 0)
				{
					detail_data[amt_disc_in_pc_col, cur_row] = o_money.ToStrMoney(o_currency.ConvertToPrimaryCurrency(o_money.ToNumMoney(detail_data[amt_disc_col, cur_row]), exchange_rate));
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (CalculateDetailRow)");
			}

			return return_value;
		}

		public static bool WithinTaxTolerance(ref clsDatabase cur_db, decimal total_taxable, decimal freight_amt, decimal tax_pc, decimal tax_entered)
		{
			bool return_value = false;
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			decimal tax_calculated = 0;

			if (!cur_db.bFreightTax_fl)
			{
				freight_amt = 0;
			}

            if (!o_gen.CalcSalesTax(total_taxable + freight_amt, tax_pc, ref tax_calculated, cur_db.bIncludeTaxInTaxableTotal_fl))
			{
				return false;
			}

			// Do not allow more than 20% because it is to adjust the roundgin errors.  Otherwise, CalculateDetailTotals() may have a problem
			// If they need to adjust a large portion of tax, they must be adjusting the freight tax.
			// If it is the case, they need to put the freight in the detail and adjust it there.
			//
			return_value = (Math.Abs(tax_calculated - tax_entered) <= (tax_calculated * 0.2M));

			return return_value;
		}

		// ********************************************************************************************************************************************
		// IMPORTANT NOTE FOR ASP VERSION :  ASP version does not use detail_data(), and it is empty/null.  Do not reference it for ASP version at all.
		// ********************************************************************************************************************************************
		//
		// PURPOSE : When user enters tax amount for flex-tax type, this will distribute the total tax amount to the detail items proportionally.
		//       
		public static bool CalculateFlexTaxRate(ref clsDatabase cur_db, ref string[,] detail_data, int tax_code_col, int tax_perc_col, int tax_amt_col, int ext_amt_col, string tax_code, decimal tax_amt, decimal freight_amt, ref decimal flex_tax_perc, ref decimal freight_tax_amt)
		{
			bool return_value = false;
			int row_num = 0;
			int first_taxable_line = 0;
			decimal amt_taxable = 0;
			decimal amt_other_taxable = 0;
			decimal amt_other_tax = 0;
			decimal amd_detail_total_tax = 0;
			clsMoney o_money = new clsMoney(ref cur_db);
			decimal amt_flex_taxable = 0;
			decimal amt_left = 0;
			decimal amt_line_tax = 0;

			try
			{
				// If tax is less than freight tax, let freight tax keep it.
				//
				if (freight_tax_amt >= tax_amt)
				{
					for (row_num = 0; row_num < detail_data.GetLength(1); row_num++)
					{
						detail_data[tax_amt_col, row_num] ="0";
					}

					freight_tax_amt = tax_amt;
					return true;
				}

				// Check if there is different tax code. Then, preserve it.
				//
				for (row_num = 0; row_num < detail_data.GetLength(1); row_num++)
				{
					if (!GlobalVar.goUtility.IsEmpty(detail_data[tax_code_col, row_num]))
					{
						if (detail_data[tax_code_col, row_num] == tax_code)
						{
							amt_flex_taxable += o_money.ToNumMoney(detail_data[ext_amt_col, row_num]);
						}
						else
						{
							amt_other_taxable += o_money.ToNumMoney(detail_data[ext_amt_col, row_num]);
							amt_other_tax += o_money.ToNumMoney(detail_data[tax_amt_col, row_num]);
						}
					}
					else
					{
						detail_data[tax_amt_col, row_num] = "0";
					}
				}

				first_taxable_line -= 1;
				amt_left = tax_amt - freight_tax_amt;

				for (row_num = 0; row_num < detail_data.GetLength(1); row_num++)
				{
					if (GlobalVar.goUtility.IsEmpty(detail_data[tax_code_col, row_num]))
					{

						detail_data[tax_amt_col, row_num] = "0";
						detail_data[tax_perc_col, row_num] = "0";

					}
					else if (detail_data[tax_code_col, row_num] == tax_code && o_money.ToNumMoney(detail_data[ext_amt_col, row_num]) > 0 && amt_flex_taxable > 0)
					{

						if (first_taxable_line <= 0)
						{
							first_taxable_line = row_num;
						}

						amt_line_tax = o_money.RoundToMoney(tax_amt * o_money.ToNumMoney(detail_data[ext_amt_col, row_num]) / amt_flex_taxable);

						if (amt_line_tax < amt_left)
						{
							detail_data[tax_amt_col, row_num] = amt_line_tax.ToString();
							amt_left -= amt_line_tax;
						}
						else
						{
							detail_data[tax_amt_col, row_num] = amt_left.ToString();
							amt_left = 0;
						}
					}

					if (amt_left <= 0)
					{
						break;
					}
				}

				if (Math.Abs(amt_left) > cur_db.mSmallestMoney_amt)
				{
					detail_data[tax_amt_col, first_taxable_line] = (amt_left + o_money.ToNumMoney(detail_data[tax_amt_col, first_taxable_line])).ToString();
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (CalculateFlexTaxRate)");
			}

			return return_value;
		}

		// 07/07/2019
		// Discount & Unit Price is calcluated in the primary currency.  The caller should convert it to f/c.
		//
		public static bool CalculateDetailDiscountAmt(ref clsDatabase cur_db, ref string[,] detail_data, int trx_type, decimal exchange_rate, int cur_row, int item_code_col, int unit_price_in_pc_col, int qty_col, int unit_code_col, int item_type_col, int disc_perc_col, int amt_disc_col, int amt_disc_in_pc_col, int item_size_col, int sell_unit_price_col, int sell_unit_code_col, int ivunit_code_col, int conversion_rate_col)
		{
			bool return_value = false;
			decimal qty = 0;
			decimal sell_unit_price = 0;
			decimal price_conversion_rate = 0;
			string ivunit_code = "";
			string unit_code = "";
			string sell_unit_code = "";
			string item_code = "";
			decimal size_qty = 0;
			decimal unit_price_in_pc = 0; // amounts in primary currency
			decimal amt_disc_in_pc = 0;

			clsMoney o_money = new clsMoney(ref cur_db);
			clsValidate o_val = new clsValidate(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);

			try
			{
				sell_unit_code = detail_data[sell_unit_code_col, cur_row];
				ivunit_code = detail_data[ivunit_code_col, cur_row];
				unit_code = detail_data[unit_code_col, cur_row];
				unit_price_in_pc = o_money.ToNumMoney(detail_data[unit_price_in_pc_col, cur_row]);
				item_code = detail_data[item_code_col, cur_row];
				qty = GlobalVar.goUtility.ToValue(detail_data[qty_col, cur_row]);

				// We keep all in primary currency.
				//
				if (amt_disc_col > 0 && amt_disc_in_pc_col <= 0)
				{
					amt_disc_in_pc_col = amt_disc_col;
				}

				// There is no discount for the service-item.
				//
				if (!GlobalVar.goUtility.IsInventoryItemType(GlobalVar.goUtility.ToInteger(detail_data[item_type_col, cur_row])))
				{
					detail_data[disc_perc_col, cur_row] = "0";
					detail_data[amt_disc_in_pc_col, cur_row] = "0";
				}
				else if (!GlobalVar.goUtility.IsEmpty(detail_data[item_code_col, cur_row]))
				{
					if (item_size_col > 0)
					{
						size_qty = o_money.ToNumMoney(detail_data[item_size_col, cur_row]);
					}

					// 07/07/2019            
					// SELL_UNIT_PRICE_COL  carries the price in primary currency
					// We calclulate "everything" here in the primary currency, first, and then, translate them in F/C
					//
					if (sell_unit_price_col <= 0)
					{
						sell_unit_price = 0;
					}
					else if (cur_db.uSecurity.bApplySizeToUnitPrice_fl & cur_db.uSecurity.bShowSizeColumn_fl && size_qty >= cur_db.fSmallestNumber)
					{
						sell_unit_price = GlobalVar.goUtility.RoundToQtyFactor(o_money.ToNumMoney(detail_data[sell_unit_price_col, cur_row]) * size_qty);
					}
					else
					{
						sell_unit_price = o_money.ToNumMoney(detail_data[sell_unit_price_col, cur_row]);
					}

					if (sell_unit_code == unit_code)
					{
						price_conversion_rate = 1;
					}
                    else if (!o_val.IsValidUnitCode(item_code, sell_unit_code, unit_code, ref price_conversion_rate)) // price_conversion_rate = sell_unit_code vs. unit_code. iv_conversion_rate = iv_unit_code vs. unit_code
					{
						detail_data[unit_code_col, cur_row] = "";
						modDialogUtility.DisplayBox(ref cur_db, unit_code + cur_db.oLanguage.oMessage.IS_INVALID);
						return false;
					}

					amt_disc_in_pc = o_money.RoundToMoney(qty * (sell_unit_price * price_conversion_rate - unit_price_in_pc));

					// if discount amount is <= 0 then, set it to 0.
					//
					if (amt_disc_in_pc > 0)
					{
						detail_data[amt_disc_in_pc_col, cur_row] = GlobalVar.goUtility.ToStr(amt_disc_in_pc);
					}
					else
					{
						detail_data[disc_perc_col, cur_row] = "0";
						detail_data[amt_disc_in_pc_col, cur_row] = "0";
					}
				}
				else
				{
					detail_data[disc_perc_col, cur_row] = "0";
					detail_data[amt_disc_in_pc_col, cur_row] = "0";
				}

				// Only F/C transactions send a valid column for this.
				//
				if (amt_disc_col > 0 && amt_disc_col != amt_disc_in_pc_col)
				{
					detail_data[amt_disc_col, cur_row] = o_currency.ConvertToForeignCurrency(amt_disc_in_pc, exchange_rate).ToString();
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CalculateDetailDiscountAmt)");
			}

			return return_value;
		}

		public static bool CalculateDetailTotals(ref clsDatabase cur_db, ref string[,] detail_data, int tax_code_col, int tax_amt_col, int tax_perc_col, int extended_amt_col, int discount_col, int weight_col, int qty_in_unit_col, ref decimal header_nontaxable_amt, ref decimal header_taxable_amt, ref decimal header_tax_amt, ref decimal header_discount_amt, ref decimal header_weight, ref decimal amt_freight_tax)
		{
			bool return_value = false;
			int i = 0;
			int total_rows = 0;
			decimal line_tax_amt = 0;
			decimal line_wight = 0;
			decimal line_discount_amt = 0;
			decimal line_extended_amt = 0;
			decimal line_tax_pc = 0;
			bool special_tax_exists = false;
			string last_tax_code = "";
			string line_tax_code = "";
			decimal last_tax_perc = 0;
			decimal amt_trx = 0;
			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			decimal detail_tax_total_amt = 0;
			decimal amt_left = 0;
			decimal detail_taxable_total_amt = 0;
			int first_taxable_line = 0;

			try
			{

				header_nontaxable_amt = 0;
				header_taxable_amt = 0;
				header_discount_amt = 0;
				header_weight = 0;

				special_tax_exists = false;
				last_tax_code = "";
				last_tax_perc = 0;
				detail_tax_total_amt = 0;
				detail_taxable_total_amt = 0;

				total_rows = detail_data.GetLength(1);

				// 1. Get the detail totals
				// ----------------------------------------------------------------------------------------------------------------------------------------------
				for (i = 0; i < total_rows; i++)
				{
					line_tax_amt = 0;
					line_extended_amt = 0;
					line_discount_amt = 0;
					line_wight = 0;
					line_tax_pc = 0;
					line_tax_code = "";

					line_tax_code = detail_data[tax_code_col, i];
					line_tax_amt = o_money.ToNumMoney(detail_data[tax_amt_col, i]);
					line_extended_amt = o_money.ToNumMoney(detail_data[extended_amt_col, i]);
					line_tax_pc = GlobalVar.goUtility.ToValue(detail_data[tax_perc_col, i]);

					if (discount_col > 0)
					{
						line_discount_amt = o_money.ToNumMoney(detail_data[discount_col, i]);
					}
					if (weight_col > 0)
					{
						line_wight = GlobalVar.goUtility.ToValue(detail_data[weight_col, i]) * GlobalVar.goUtility.ToValue(detail_data[qty_in_unit_col, i]);
					}

					// if (header_tax_amt = 0) is entered, we will recalculate the default tax.
					// Each time tax is adjusted, the line taxes are adjusted accordingly so that, when the tax is reset, it is necessary to recalculate to default.
					// In the normal course of business, it may not happen.
					// However, in demo, tax amount can be manipulated multiple times so that it is a safe bet to recalculate the line tax.
					// And it won't take long.
					//
					//If header_tax_amt = 0 Then
                    if (!o_gen.CalcSalesTax(line_extended_amt, line_tax_pc, ref line_tax_amt, (line_tax_pc < 0)))
					{
						return false;
					}
					detail_data[tax_amt_col, i] = line_tax_amt.ToString();
					//End If

					header_discount_amt += line_discount_amt;
					detail_tax_total_amt += line_tax_amt;
					header_weight += line_wight;

					if (Math.Abs(line_tax_pc) > 0)
					{
						detail_taxable_total_amt += line_extended_amt;
					}

					if (Math.Abs(line_tax_pc) > 0 && Math.Abs(last_tax_perc) > 0 && line_tax_pc != last_tax_perc)
					{
						special_tax_exists = true;
					}

					if (Math.Abs(line_tax_pc) > 0)
					{
						last_tax_code = line_tax_code;
						last_tax_perc = line_tax_pc;
					}

					if (!GlobalVar.goUtility.IsEmpty(line_tax_code) && Math.Abs(line_tax_pc) > 0 && line_extended_amt >= cur_db.fSmallestNumber) // do not use this--> line_tax_amt >= cur_db.fSmallestNumber Then
					{
						header_taxable_amt += line_extended_amt;

						// Included Tax
						//
						if (line_tax_pc < 0 && !cur_db.bIncludeTaxInTaxableTotal_fl)
						{
							header_taxable_amt -= line_tax_amt;
						}
					}
					else
					{
						header_nontaxable_amt += line_extended_amt;
					}

					// If the amount is too large, return false.
					//
					if (o_money.TooLargeDollar(header_nontaxable_amt + header_taxable_amt))
					{
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.TOO_LARGE_DOLLAR);
						return false;
					}
				}

				// 2. If user enters the tax, adjust the line item tax proportionally before calculation.
				// ----------------------------------------------------------------------------------------------------------------------------------------------
				if (header_tax_amt > 0)
				{
					// For inclusive tax, taxable amount should be greater than the tax.
					//
					if (detail_taxable_total_amt <= header_tax_amt && last_tax_perc < 0M && !cur_db.bIncludeTaxInTaxableTotal_fl)
					{
						return false;
					}

					if (detail_taxable_total_amt < cur_db.mSmallestMoney_amt)
					{
						amt_freight_tax = header_tax_amt;
						amt_left = 0;
					}
					else if (header_tax_amt > amt_freight_tax)
					{
						amt_left = header_tax_amt - amt_freight_tax;
					}
					else
					{
						amt_freight_tax = 0; // If the tax entered is less than freight tax, need to wipe out freight first.
						amt_left = header_tax_amt;
					}

					first_taxable_line = -1;
					header_taxable_amt = 0; // recalculate

					for (i = 0; i <= total_rows - 1; i++)
					{
						line_tax_amt = 0;

						// We know taxable line has tax% on each line.
						//
						if (Math.Abs(GlobalVar.goUtility.ToValue(detail_data[tax_perc_col, i])) > 0 && o_money.ToNumMoney(detail_data[extended_amt_col, i]) >= cur_db.mSmallestMoney_amt)
						{
							if (amt_left > 0M)
							{
								line_tax_amt = o_money.RoundToMoney(header_tax_amt * o_money.ToNumMoney(detail_data[extended_amt_col, i]) / detail_taxable_total_amt);
								header_taxable_amt += o_money.ToNumMoney(detail_data[extended_amt_col, i]);

								if (amt_left >= line_tax_amt)
								{
									amt_left -= line_tax_amt;
								}
								else
								{
									line_tax_amt = amt_left;
									amt_left = 0;
								}
							}

							if (first_taxable_line < 0) // Remember the first taxable line.
							{
								first_taxable_line = i;
							}
						}

						detail_data[tax_amt_col, i] = line_tax_amt.ToString();
					}

					// If there is any remaining, put it on the first item possible.
					if (amt_left != 0)
					{
						for (i = 0; i < total_rows; i++)
						{
							if (Math.Abs(o_money.ToNumMoney(detail_data[tax_amt_col, i])) > amt_left || (amt_left > 0M && o_money.ToNumMoney(detail_data[tax_amt_col, i]) > 0))
							{
								detail_data[tax_amt_col, i] = (o_money.ToNumMoney(detail_data[tax_amt_col, i]) + amt_left).ToString();
								break;
							}
						}
					}

					if (last_tax_perc < 0M && !cur_db.bIncludeTaxInTaxableTotal_fl)
					{
						header_taxable_amt -= header_tax_amt;
					}
				}

				// 3. Finalize header_tax_amt
				// ----------------------------------------------------------------------------------------------------------------------------------------------
				if (header_taxable_amt == 0) // And header_nontaxable_amt = 0 Then ' 07/25/2017 Fex Tax may have freight tax only.
				{
					if (amt_freight_tax == 0)
					{
						header_tax_amt = 0;
					}
					else
					{
						header_tax_amt = amt_freight_tax;
					}

					// If a special tax exists, the total of the line items will be the total tax.
					//
					//ElseIf special_tax_exists Then
					//header_tax_amt = tax_total_amt
					//return_value = True

					// If not, the total of the line items may not be the same as the total tax calculated
					// from the total sales amount due to rounding error.
					//
				}
				else
				{
					// If header_tax_amt is not passed, calculate it with header_taxable_amt.  DO NOT use SUM(line tax).  The tax has to be always derived from the total amount.
					//
					if (header_tax_amt < cur_db.mSmallestMoney_amt)
					{
						if (!o_gen.CalcSalesTax(header_taxable_amt, last_tax_perc, ref header_tax_amt, cur_db.bIncludeTaxInTaxableTotal_fl))
						{
							return false;
						}

						header_tax_amt += amt_freight_tax;
					}
				}

				return_value = true;

			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + " (CalculateDetailTotals)");
			}

			if (header_tax_amt < cur_db.mSmallestMoney_amt) // by any chance
			{
				header_tax_amt = 0;
			}

			if (header_taxable_amt < 0M)
			{
				header_taxable_amt = 0; // Could happen when tax >> header_taxable_amt
			}

			return return_value;
		}

		public static decimal CalculateSubTotal(ref clsDatabase cur_db, decimal taxable_amt, decimal non_taxable_amt, decimal freight_amt, decimal tax_amt, decimal tax_perc)
		{
			decimal return_value = 0;

			try
			{
				return_value = taxable_amt + non_taxable_amt + freight_amt;

				if (tax_perc >= 0 || !cur_db.bIncludeTaxInTaxableTotal_fl) // DO NOT use "tax_perc > 0" because flex-tax can be 0.
				{
					return_value += tax_amt;
				}
			}
			catch (Exception ex)
			{
				return_value = 0;
			}

			return return_value;
		}

		public static bool CheckChargeDetail(ref clsDatabase cur_db, ref string[,] detail_data, int trx_type, string header_location_code, int item_code_col, int location_code_col, int item_type_col, int unit_code_col, int qty_col, int tax_perc_col, int extended_amt_col, decimal header_tax_perc)
		{
			bool return_value = false;
			clsMoney o_money = new clsMoney(ref cur_db);
			int row_num = 0;
			int item_type = 0;
			int i = 0;
			bool regular_tax_fl = false;
			bool included_tax_fl = false;
			string item_code = "";
			string unit_code = "";
			string location_code = "";
			decimal qty = 0;
			decimal extended_amt = 0;
			decimal tax_perc = 0;

			try
			{
				if (header_tax_perc >= cur_db.fSmallestNumber)
				{
					regular_tax_fl = true;
				}
				else if (header_tax_perc <= -cur_db.fSmallestNumber)
				{
					included_tax_fl = true;
				}

				for (row_num = 0; row_num < detail_data.GetLength(1); row_num++)
				{
					item_code = detail_data[item_code_col, row_num];
					location_code = detail_data[location_code_col, row_num];
					unit_code = detail_data[unit_code_col, row_num];
					item_type = GlobalVar.goUtility.ToInteger(detail_data[item_type_col, row_num]);
					if (tax_perc_col >= 0)
					{
						tax_perc = GlobalVar.goUtility.ToValue(detail_data[tax_perc_col, row_num]);
					}

					qty = GlobalVar.goUtility.ToValue(detail_data[qty_col, row_num]);
					extended_amt = o_money.ToNumMoney(detail_data[extended_amt_col, row_num]);

					// At this point, multi-location entry is not allowed.  If location code is changed in the middle of entry at UI, details may have different location code.
					// Make sure it has correct code.
					//
					detail_data[location_code_col, row_num] = header_location_code;

					if (!GlobalVar.goUtility.IsEmpty(item_code))
					{
						if (Math.Abs(qty) >= cur_db.fSmallestNumber && !GlobalVar.goUtility.IsNegativePriceCarryItemType(item_type) & GlobalVar.goUtility.IsEmpty(unit_code))
						{
							modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.UNIT_CODE_IS_MISSING_ON_THE_LINE_NUMBER + (row_num + 1).ToString());
							return false;
						}

						// 07/05/2019
						// For the sake of easier return, we need to make sure that each item uses the same unit code if an item appears more than once in this transaction.
						// Otherwise, the return qty be messed up when an item is returned multiple times.
						//
						// 08/08/2019
						// Not any more, return can handle this situation nicely.   Mutipple-occurance of same item is handled fine now.
						//
						if (GlobalVar.goUtility.IsInventoryItemType(item_type))
						{
							//For i = row_num + 1 To detail_data.GetLength(1) - 1
							//   If (trx_type = goConstant.TRX_CM_TYPE Or trx_type = goConstant.TRX_DM_TYPE) _
							//   And SpreadsheetGetCell(cur_grid, item_code_col, i] = item_code _
							//   And item_type <> goIVConstant.SERIAL_ITEM_NUM And item_type <> goIVConstant.LOT_ITEM_NUM Then
							//       DisplayBox(ref cur_db, item_code & " : " & goMessage.SAME_ITEM_CANNOT_APPEAR_MORE_THAN_ONCE_IN_RETURN)  ' For the sake of simpler return process.   
							//       Return False
							//   ElseIf SpreadsheetGetCell(cur_grid, item_code_col, i] = item_code And SpreadsheetGetCell(cur_grid, unit_code_col, i] <> unit_code Then
							//       DisplayBox(ref cur_db, item_code & goMessage.APPEARS_MORE_THAN_ONCE_WITH_DIFFERENT_UNIT_CODE)
							//       Return False
							//   End If
							//Next
						}
					}

					if (extended_amt >= cur_db.mSmallestMoney_amt)
					{
						if (tax_perc >= cur_db.fSmallestNumber)
						{
							regular_tax_fl = true;
						}
						else if (tax_perc <= -cur_db.fSmallestNumber)
						{
							included_tax_fl = true;
						}
					}

				}

				if (regular_tax_fl && included_tax_fl)
				{
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.TWO_TAX_TYPES_ARE_NOT_ALLOWED);
					return false;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CheckChargeDetail)");
			}

			return return_value;
		}

		// 07/07/2019
		// Discount & Unit Price is calcluated in the primary currency.  The caller should convert it to f/c.
		//
		public static bool CalculateDetailUnitPrice(ref clsDatabase cur_db, ref string[,] detail_data, int trx_type, decimal exchange_rate, int cur_row, int item_code_col, int qty_col, int unit_code_col, int item_type_col, int disc_perc_col, int amt_disc_in_pc_col, int item_size_col, int sell_unit_price_col, int sell_unit_code_col, int ivunit_code_col, int conversion_rate_col, int qty_in_ivunit_col, int unit_price_col, int unit_price_in_pc_col, string customer_code, string item_code, string price_code, bool get_disc_flag)
		{
			bool return_value = false;
			decimal sell_unit_price = 0;
			decimal iv_qty = 0;
			decimal disc_perc = 0;
			decimal price_conversion_rate = 0;
			decimal unit_price_in_pc = 0; // in primary currency
			string sell_unit_code = "";
			string ivunit_code = "";
			string unit_code = "";
			decimal sale_price = 0;
			decimal size_qty = 0;
			string size_code = "";
			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsValidate o_val = new clsValidate(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);

			try
			{
				// 07/07/2019            
				// SELL_UNIT_PRICE_COL  carries the price in primary currency
				// We calclulate "everything" here in the primary currency, first, and then, translate them in F/C
				//
				sell_unit_price = o_money.ToNumMoney(detail_data[sell_unit_price_col, cur_row]);

				sell_unit_code = detail_data[sell_unit_code_col, cur_row];
				item_code = detail_data[item_code_col, cur_row];
				unit_code = detail_data[unit_code_col, cur_row];
				ivunit_code = detail_data[ivunit_code_col, cur_row];
				iv_qty = GlobalVar.goUtility.ToValue(detail_data[qty_in_ivunit_col, cur_row]);

				if (sell_unit_code == unit_code || !GlobalVar.goUtility.IsInventoryItemType(GlobalVar.goUtility.ToInteger(detail_data[item_type_col, cur_row])))
				{ 
					price_conversion_rate = 1;
				}
                else if (!o_val.IsValidUnitCode(item_code, sell_unit_code, unit_code, ref price_conversion_rate))
				{
					detail_data[unit_code_col, cur_row] = ivunit_code;
					detail_data[qty_in_ivunit_col, cur_row] = iv_qty.ToString();
					modDialogUtility.DisplayBox(ref cur_db, unit_code + cur_db.oLanguage.oMessage.IS_INVALID);
				}

				// Calculate the unit-price using price code.
				// Do not forward if item_code is empty or service-item.
				//
				if (GlobalVar.goUtility.IsEmpty(item_code))
				{
					detail_data[disc_perc_col, cur_row] = "0";
					detail_data[amt_disc_in_pc_col, cur_row] = "0";
					return true;
				}
				else if (!GlobalVar.goUtility.IsInventoryItemType(GlobalVar.goUtility.ToInteger(detail_data[item_type_col, cur_row])))
				{
					detail_data[disc_perc_col, cur_row] = "0";
					detail_data[amt_disc_in_pc_col, cur_row] = "0";
					disc_perc = 0;
					unit_price_in_pc = o_money.RoundToMoneyFactor(sell_unit_price * price_conversion_rate * (100 - disc_perc) / 100);
				}
				else if (get_disc_flag && price_conversion_rate > 0M && sell_unit_price > 0M)
				{
					// Grab the quantity discount and sale price, and compare them.
					//
					disc_perc = o_gen.GetQuantityDiscount(customer_code, price_code, item_code, ref iv_qty);
					unit_price_in_pc = o_money.RoundToMoneyFactor(sell_unit_price * price_conversion_rate * (100 - disc_perc) / 100);
					sale_price = o_money.RoundToMoneyFactor(o_gen.GetBestSalePrice(item_code, sell_unit_price) * price_conversion_rate);

					if (sale_price >= cur_db.mSmallestMoney_amt && unit_price_in_pc > sale_price)
					{
						unit_price_in_pc = sale_price;
					}

					if (sell_unit_price >= cur_db.mSmallestMoney_amt && price_conversion_rate > 0M)
					{
						disc_perc = 100 - o_money.RoundToMoneyFactor(unit_price_in_pc * 100 / sell_unit_price / price_conversion_rate);
					}
					else
					{
						disc_perc = 0;
					}
				}
				else
				{
					disc_perc = o_money.ToNumMoney(detail_data[disc_perc_col, cur_row]);
					unit_price_in_pc = o_money.RoundToMoneyFactor(sell_unit_price * price_conversion_rate * (100 - disc_perc) / 100);
				}

				size_code = detail_data[item_size_col, cur_row];
				if (cur_db.uSecurity.bApplySizeToUnitPrice_fl & cur_db.uSecurity.bShowSizeColumn_fl && o_money.ToNumMoney(size_code) >= cur_db.fSmallestNumber)
				{
					size_qty = o_money.ToNumMoney(size_code);
					unit_price_in_pc = o_money.RoundToMoney(size_qty * unit_price_in_pc);
				}

				detail_data[disc_perc_col, cur_row] = disc_perc.ToString();

				detail_data[unit_price_in_pc_col, cur_row] = o_money.ToStrMoney(unit_price_in_pc); // We calclulate "everything" here in the primary currency, first, and then, translate them in F/C

				if (unit_price_col > 0 && unit_price_col != unit_price_in_pc_col)
				{
					detail_data[unit_price_col, cur_row] = o_money.ToStrMoney(o_currency.ConvertToForeignCurrency(unit_price_in_pc, exchange_rate));
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CalculateDetailUnitPrice)");
			}

			return return_value;
		}

		public static bool CalculateDetailQtyInIvUnit(ref clsDatabase cur_db, ref string[,] detail_data, int trx_type, int cur_row, int item_code_col, int qty_col, int unit_code_col, int ivunit_code_col, int conversion_rate_col, int qty_in_ivunit_col, int item_size_col, int item_type_col)
		{
			bool return_value = false;
			string ivunit_code = "";
			string unit_code = "";
			decimal iv_conversion_rate = 0;
			string item_code = "";
			decimal qty = 0;
			decimal new_qty = 0;
			decimal size_qty = 0;
			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsValidate o_val = new clsValidate(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);

			try
			{
				ivunit_code = detail_data[ivunit_code_col, cur_row];
				unit_code = detail_data[unit_code_col, cur_row];
				item_code = detail_data[item_code_col, cur_row];
				qty = o_money.ToNumMoney(detail_data[qty_col, cur_row]);

				if (GlobalVar.goUtility.IsEmpty(item_code))
				{
					detail_data[conversion_rate_col, cur_row] = "1";

				}
				else if (ivunit_code == unit_code || !GlobalVar.goUtility.IsInventoryItemType(GlobalVar.goUtility.ToInteger(detail_data[item_type_col, cur_row])))
				{
					detail_data[conversion_rate_col, cur_row] = "1";
					detail_data[qty_in_ivunit_col, cur_row] = qty.ToString();

				}
                else if (o_val.IsValidUnitCode(item_code, ivunit_code, unit_code, ref iv_conversion_rate))
				{
					detail_data[conversion_rate_col, cur_row] = iv_conversion_rate.ToString(); // conversion_rate_col SHOULD carry the inventory conversion rate.
					detail_data[qty_in_ivunit_col, cur_row] = GlobalVar.goUtility.RoundToQtyFactor(iv_conversion_rate * qty).ToString();

				}
				else
				{
					detail_data[conversion_rate_col, cur_row] = "1";
					detail_data[unit_code_col, cur_row] = ivunit_code;
					detail_data[qty_in_ivunit_col, cur_row] = qty.ToString();
				}

				if ((trx_type >= 3000 && trx_type <= 3999) || (trx_type >= 5000 && trx_type <= 5999)) // Only for sales
				{
					size_qty = o_money.ToNumMoney(detail_data[item_size_col, cur_row]);
					qty = o_money.ToNumMoney(detail_data[qty_in_ivunit_col, cur_row]);

					if (cur_db.uSecurity.bApplySizeToUnitPrice_fl & cur_db.uSecurity.bShowSizeColumn_fl && size_qty >= cur_db.fSmallestNumber)
					{
						detail_data[qty_in_ivunit_col, cur_row] = GlobalVar.goUtility.RoundToQtyFactor(qty * size_qty).ToString();
					}
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CalculateDetailQtyInIvUnit)");
			}

			return return_value;
		}

		// 07/07/2019
		// Discount & Unit Price is calcluated in the primary currency.  The caller should convert it to f/c.
		//
		public static bool ProcessDetailSalesUnit(ref clsDatabase cur_db, ref string[,] detail_data, int trx_type, decimal exchange_rate, int cur_row, int item_code_col, int qty_col, int unit_code_col, int item_type_col, int disc_perc_col, int amt_disc_in_pc_col, int item_size_col, int sell_unit_price_col, int sell_unit_code_col, int ivunit_code_col, int conversion_rate_col, int unit_price_in_pc_col, int qty_in_ivunit_col, string customer_code, string price_code)
		{
			bool return_value = false;
			string unit_code = "";
			string item_code = "";
			decimal price_conversion_rate = 0;
			string ivunit_code = "";
			decimal new_ivqty = 0;
			decimal qty_shipped = 0;
			string tmp = "";
			string sell_unit_code = "";
			decimal unit_price_in_pc = 0; // amounts in primary currency
			decimal sale_price_in_pc = 0;
			decimal iv_qty = 0;
			decimal sell_unit_price = 0;
			decimal disc_amt = 0;
			decimal disc_perc = 0;
			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsValidate o_val = new clsValidate(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);

			try
			{
				unit_code = modCommonUtility.CleanCode(detail_data[unit_code_col, cur_row]);

				if (!cur_db.uProgram.bIVExist_fl)
				{
					detail_data[unit_code_col, cur_row] = unit_code;
					return true;
				}

				// 07/07/2019            
				// SELL_UNIT_PRICE_COL  carries the price in primary currency
				// We calclulate everything in the primary currency, first, and then, translate them in F/C
				//
				sell_unit_price = o_money.ToNumMoney(detail_data[sell_unit_price_col, cur_row]);
				unit_price_in_pc = o_money.ToNumMoney(detail_data[unit_price_in_pc_col, cur_row]);

				item_code = detail_data[item_code_col, cur_row];
				disc_perc = o_money.ToNumMoney(detail_data[disc_perc_col, cur_row]);
				ivunit_code = detail_data[ivunit_code_col, cur_row];
				sell_unit_code = detail_data[sell_unit_code_col, cur_row];

				if ((GlobalVar.goUtility.IsEmpty(unit_code)) || GlobalVar.goUtility.IsEmpty(item_code) || !GlobalVar.goUtility.IsInventoryItemType(GlobalVar.goUtility.ToInteger(detail_data[item_type_col, cur_row])))
				{
					detail_data[unit_code_col, cur_row] = unit_code;
					return_value = true;

				}
                else if (!o_val.IsValidUnitCode(item_code, sell_unit_code, unit_code, ref price_conversion_rate))
				{
					detail_data[unit_code_col, cur_row] = "";
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NO_CONVERSION_EXIST + "(" + sell_unit_code + ":" + unit_code + ")");
					return false;
				}
				else
				{
					detail_data[unit_code_col, cur_row] = unit_code;
					detail_data[disc_perc_col, cur_row] = "0";
					detail_data[amt_disc_in_pc_col, cur_row] = "0";

					//  Calculate the qty in inventory unit.
					//
					if (!CalculateDetailQtyInIvUnit(ref cur_db, ref detail_data, trx_type, cur_row, item_code_col, qty_col, unit_code_col, ivunit_code_col, conversion_rate_col, qty_in_ivunit_col, item_size_col, item_type_col))
					{
						return false;
					}

					// Calculate the discount now according to the new qty.
					//
					iv_qty = o_money.ToNumMoney(detail_data[qty_in_ivunit_col, cur_row]);

					// Grab the quantity discount and sale price, and compare them.
					//
                    disc_perc = o_gen.GetQuantityDiscount(customer_code, price_code, item_code, ref iv_qty);
					unit_price_in_pc = o_money.RoundToMoneyFactor(sell_unit_price * price_conversion_rate * ((100 - disc_perc) / 100));
					sale_price_in_pc = o_money.RoundToMoneyFactor(o_gen.GetBestSalePrice(item_code, sell_unit_price) * price_conversion_rate);

					if (unit_price_in_pc > sale_price_in_pc)
					{
						unit_price_in_pc = sale_price_in_pc;
					}

					if (sell_unit_price >= cur_db.mSmallestMoney_amt && price_conversion_rate >= cur_db.fSmallestNumber)
					{
						disc_perc = 100 - GlobalVar.goUtility.RoundToDiscountPerc(unit_price_in_pc * 100 / sell_unit_price / price_conversion_rate);
					}
					else
					{
						disc_perc = 0;
					}

					detail_data[disc_perc_col, cur_row] = GlobalVar.goUtility.ToStr(disc_perc);
					detail_data[unit_price_in_pc_col, cur_row] = o_money.ToStrMoney(unit_price_in_pc);

					if (!CalculateDetailDiscountAmt(ref cur_db, ref detail_data, trx_type, exchange_rate, cur_row, item_code_col, unit_price_in_pc_col, qty_col, unit_code_col, item_type_col, disc_perc_col, amt_disc_in_pc_col, amt_disc_in_pc_col, item_size_col, sell_unit_price_col, sell_unit_code_col, ivunit_code_col, conversion_rate_col))
					{
						return false;
					}

					return_value = true;
				}

			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessDetailUnit)");
			}

			return return_value;
		}

		// 07/07/2019
		// Discount & Unit Price is calcluated in the primary currency.  The caller should convert it to f/c.
		//
		public static bool ProcessDetailUnitPrice(ref clsDatabase cur_db, ref string[,] detail_data, int trx_type, decimal exchange_rate, int cur_row, int item_code_col, int unit_price_col, int qty_col, int unit_code_col, int item_type_col, int disc_perc_col, int amt_disc_col, int amt_disc_in_pc_col, int item_size_col, int sell_unit_price_col, int sell_unit_code_col, int ivunit_code_col, int conversion_rate_col, int unit_price_in_pc_col, int job_code_col, int tax_code_col, string job_code, bool recalc_fl)
		{
			bool return_value = false;
			decimal disc_perc = 0;
			decimal unit_price = 0;
			decimal sell_unit_price = 0;
			decimal unit_price_in_pc = 0; // in primary currency
			decimal price_conversion_rate = 0;
			string unit_code = "";
			string sell_unit_code = "";
			string ivunit_code = "";
			string item_code = "";
			clsMoney o_money = new clsMoney(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsValidate o_val = new clsValidate(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);
			clsSerial o_serial = new clsSerial(ref cur_db);
			int item_type = 0;

			try
			{
				item_code = detail_data[item_code_col, cur_row];
				item_type = GlobalVar.goUtility.ToInteger(detail_data[item_type_col, cur_row]);
				unit_price = o_money.RoundToMoney(o_money.ToNumMoney(detail_data[unit_price_col, cur_row]));
				detail_data[unit_price_col, cur_row] = o_money.ToStrMoney(unit_price);

				// We keep all in primary currency.
				//
				if (amt_disc_col > 0 && amt_disc_in_pc_col <= 0)
				{
					amt_disc_in_pc_col = amt_disc_col;
				}

				// If this is the line that has serial/lot number that is generated by moSerialUtility.InsertSerialNumbersIntoDetail().
				//
				if (GlobalVar.goUtility.IsEmpty(item_code) && o_serial.IsSerialOrLotItem(item_type))
				{
					return true;
				}

				// Accept negative line items, now
				//
				if (unit_price < 0M)
				{
					if (!GlobalVar.goUtility.IsEmpty(detail_data[item_code_col, cur_row]) && GlobalVar.goUtility.IsInventoryItemType(GlobalVar.goUtility.ToInteger(detail_data[item_type_col, cur_row])))
					{
						detail_data[unit_price_col, cur_row] = "";
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NEGATIVE_VALUE_NOT_ALLOWED);
						return false;
					}
					else if (!GlobalVar.goUtility.IsNegativePriceCarryItemType(GlobalVar.goUtility.ToInteger(detail_data[item_type_col, cur_row]))) // 07/04/2016 This will let the rebate/discount item carry the item code for report later on
					{
						detail_data[item_code_col, cur_row] = "";
					}
					detail_data[job_code_col, cur_row] = "";
					detail_data[tax_code_col, cur_row] = "";
					if (disc_perc_col > 0)
					{
						detail_data[disc_perc_col, cur_row] = "0";
					}
					if (amt_disc_in_pc_col > 0)
					{
						detail_data[amt_disc_in_pc_col, cur_row] = "0";
					}

					return true;
				}

				item_code = detail_data[item_code_col, cur_row];
				unit_code = detail_data[unit_code_col, cur_row];
				ivunit_code = detail_data[ivunit_code_col, cur_row];

				// 07/07/2019            
				// SELL_UNIT_PRICE_COL  carries the price in primary currency
				// We calclulate everything in the primary currency, first, and then, translate them in F/C
				//
				if (sell_unit_price_col > 0)
				{
					sell_unit_price = o_money.ToNumMoney(detail_data[sell_unit_price_col, cur_row]);
				}
				if (sell_unit_code_col > 0)
				{
					sell_unit_code = detail_data[sell_unit_code_col, cur_row];
				}

				if (!recalc_fl && unit_price_in_pc_col > 0)
				{
					detail_data[unit_price_in_pc_col, cur_row] = o_money.ToStrMoney(o_currency.ConvertToPrimaryCurrency(unit_price, exchange_rate));
				}

				if (unit_price_in_pc_col > 0)
				{
					unit_price_in_pc = o_money.ToNumMoney(detail_data[unit_price_in_pc_col, cur_row]);
				}
				else
				{
					unit_price_in_pc = unit_price;
				}

				if (sell_unit_code == unit_code || !GlobalVar.goUtility.IsInventoryItemType(GlobalVar.goUtility.ToInteger(detail_data[item_type_col, cur_row])))
				{
					price_conversion_rate = 1;
				}
                else if (!o_val.IsValidUnitCode(item_code, sell_unit_code, unit_code, ref price_conversion_rate)) // price_conversion_rate = sell_unit_code vs. unit_code. iv_conversion_rate = iv_unit_code vs. unit_code
				{
					detail_data[unit_code_col, cur_row] = "";
					modDialogUtility.DisplayBox(ref cur_db, unit_code + cur_db.oLanguage.oMessage.IS_INVALID);
					return false;
				}

				if (Math.Abs(o_money.RoundToMoney(unit_price)) < cur_db.mSmallestMoney_amt && GlobalVar.goUtility.IsEmpty(detail_data[item_code_col, cur_row]))
				{
					detail_data[job_code_col, cur_row] = "";
				}
				else if (Math.Abs(o_money.RoundToMoney(unit_price)) >= cur_db.mSmallestMoney_amt && GlobalVar.goUtility.IsEmpty(detail_data[job_code_col, cur_row]))
				{
					detail_data[job_code_col, cur_row] = job_code;
				}

				if (disc_perc_col > 0 && amt_disc_in_pc_col > 0)
				{
					if (GlobalVar.goUtility.STrim(detail_data[item_code_col, cur_row]) == "")
					{
						detail_data[disc_perc_col, cur_row] = "0";
						detail_data[amt_disc_in_pc_col, cur_row] = "0";
						return_value = true;
					}
					else
					{
						if (sell_unit_price > 0M && price_conversion_rate > 0M)
						{
							disc_perc = 100 - GlobalVar.goUtility.RoundToDiscountPerc(unit_price_in_pc * 100 / sell_unit_price / price_conversion_rate);
						}
						else
						{
							disc_perc = 0;
						}
						detail_data[disc_perc_col, cur_row] = GlobalVar.goUtility.ToStr(disc_perc);

						if (!CalculateDetailDiscountAmt(ref cur_db, ref detail_data, trx_type, exchange_rate, cur_row, item_code_col, unit_price_in_pc_col, qty_col, unit_code_col, item_type_col, disc_perc_col, amt_disc_col, amt_disc_in_pc_col, item_size_col, sell_unit_price_col, sell_unit_code_col, ivunit_code_col, conversion_rate_col))
						{
							return false;
						}
					}
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessDetailUnitPrice)");
			}

			return return_value;
		}

		public static bool ProcessDetailUnitPriceInPrimary(ref clsDatabase cur_db, ref string[,] detail_data, int trx_type, decimal exchange_rate, int cur_row, int item_code_col, int unit_price_col, int qty_col, int unit_code_col, int item_type_col, int disc_perc_col, int amt_disc_col, int amt_disc_in_pc_col, int item_size_col, int sell_unit_price_col, int sell_unit_code_col, int ivunit_code_col, int conversion_rate_col, int unit_price_in_pc_col, int job_code_col, int tax_code_col, string job_code)
		{
			bool return_value = false;
			decimal unit_price_in_pc = 0;

			clsMoney o_money = new clsMoney(ref cur_db);
			clsCurrency o_currency = new clsCurrency(ref cur_db);

			try
			{
				unit_price_in_pc = o_money.RoundToMoney(o_money.ToNumMoney(detail_data[unit_price_in_pc_col, cur_row]));
				detail_data[unit_price_in_pc_col, cur_row] = o_money.ToStrMoney(unit_price_in_pc);

				// Accept negative line items, now
				//
				if (unit_price_in_pc < 0M)
				{
					if (!GlobalVar.goUtility.IsNegativePriceCarryItemType(GlobalVar.goUtility.ToInteger(detail_data[item_type_col, cur_row]))) // 07/04/2016 This will let the rebate/discount item carry the item code for report later on
					{
						detail_data[item_code_col, cur_row] = "";
					}
					detail_data[job_code_col, cur_row] = "";
					detail_data[tax_code_col, cur_row] = "";
					detail_data[disc_perc_col, cur_row] = "0";
					detail_data[amt_disc_col, cur_row] = "0";
					return true;
				}

				detail_data[unit_price_col, cur_row] = o_money.ToStrMoney(o_currency.ConvertToForeignCurrency(unit_price_in_pc, exchange_rate));

				if (!ProcessDetailUnitPrice(ref cur_db, ref detail_data, trx_type, exchange_rate, cur_row, item_code_col, unit_price_col, qty_col, unit_code_col, item_type_col, disc_perc_col, amt_disc_col, amt_disc_in_pc_col, item_size_col, sell_unit_price_col, sell_unit_code_col, ivunit_code_col, conversion_rate_col, unit_price_in_pc_col, job_code_col, tax_code_col, job_code, true))
				{
					return false;

				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessDetailUnitPriceInPrimary)");
			}

			return return_value;
		}

		// 07/07/2019
		// Discount & Unit Price is calcluated in the primary currency.  The caller should convert it to f/c.
		//
		public static bool ProcessDetailChargeQty(ref clsDatabase cur_db, ref string[,] detail_data, int trx_type, decimal exchange_rate, int cur_row, int item_code_col, int qty_col, int unit_code_col, int item_type_col, int disc_perc_col, int amt_disc_col, int amt_disc_in_pc_col, int item_size_col, int sell_unit_price_col, int sell_unit_code_col, int ivunit_code_col, int conversion_rate_col, int unit_price_col, int unit_price_in_pc_col, int tax_code_col, int qty_in_ivunit_col, string customer_code, string price_code, int qty_ordered_col = -1, int qty_shipped_col = -1, int order_num_col = -1)
		{
			bool return_value = false;
			decimal old_ivqty = 0;
			decimal iv_conversion_rate = 0;
			string item_code = "";
			int line_order_num = 0;
			decimal new_qty = 0;
			decimal shipped_qty = 0;
			decimal order_qty = 0;
			clsRecordset cur_set = null;
			string sql_str = "";
			clsMoney o_money = new clsMoney(ref cur_db);

			cur_set = new clsRecordset(ref cur_db);

			try
			{
				item_code = detail_data[item_code_col, cur_row];
				old_ivqty = GlobalVar.goUtility.ToValue(detail_data[qty_in_ivunit_col, cur_row]);
				new_qty = GlobalVar.goUtility.ToValue(detail_data[qty_col, cur_row]);
				iv_conversion_rate = GlobalVar.goUtility.ToValue(detail_data[conversion_rate_col, cur_row]);

				if (trx_type == GlobalVar.goConstant.TRX_SO_TYPE && qty_shipped_col > 0)
				{
					shipped_qty = GlobalVar.goUtility.ToValue(detail_data[qty_shipped_col, cur_row]);
				}
				else
				{
					shipped_qty = 0;
				}

				if (trx_type == GlobalVar.goConstant.TRX_INVOICE_TYPE && qty_ordered_col > 0)
				{
					order_qty = GlobalVar.goUtility.ToValue(detail_data[qty_ordered_col, cur_row]);
				}
				else
				{
					order_qty = 0;
				}

				if (trx_type == GlobalVar.goConstant.TRX_INVOICE_TYPE && order_num_col > 0)
				{
					line_order_num = GlobalVar.goUtility.ToInteger(detail_data[order_num_col, cur_row]);
				}
				else
				{
					line_order_num = 0;
				}

				// Order qty cannot go below the shipped qty.
				//
				if (trx_type == GlobalVar.goConstant.TRX_SO_TYPE)
				{
					if (shipped_qty >= cur_db.fSmallestNumber && shipped_qty > new_qty)
					{
						detail_data[qty_col, cur_row] = detail_data[qty_shipped_col, cur_row];
						new_qty = GlobalVar.goUtility.ToValue(detail_data[qty_shipped_col, cur_row]);
					}
				}

				if (new_qty < 0M)
				{
					detail_data[qty_col, cur_row] = "";
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NEGATIVE_VALUE_NOT_ALLOWED);
					return false;

				}
				else if (trx_type == GlobalVar.goConstant.TRX_INVOICE_TYPE && new_qty > order_qty && line_order_num > 0)
				{

					detail_data[qty_col, cur_row] = "";
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.QTY_CANNOT_EXCEED_ORDERED_QTY_WHEN_ORDER_ENTERED);
					return false;

				}
				else if (!GlobalVar.goUtility.IsEmpty(item_code))
				{

					detail_data[qty_in_ivunit_col, cur_row] = GlobalVar.goUtility.RoundToQtyFactor(new_qty * iv_conversion_rate).ToString();

					if (!CalculateDetailDiscountAmt(ref cur_db, ref detail_data, trx_type, exchange_rate, cur_row, item_code_col, unit_price_in_pc_col, qty_col, unit_code_col, item_type_col, disc_perc_col, amt_disc_col, amt_disc_in_pc_col, item_size_col, sell_unit_price_col, sell_unit_code_col, ivunit_code_col, conversion_rate_col))
					{
						return false;
					}

				}

				detail_data[qty_col, cur_row] = GlobalVar.goUtility.RoundToQtyFactor(new_qty).ToString();

				if (!CalculateDetailQtyInIvUnit(ref cur_db, ref detail_data, trx_type, cur_row, item_code_col, qty_col, unit_code_col, ivunit_code_col, conversion_rate_col, qty_in_ivunit_col, item_size_col, item_type_col))
				{
					return false;
				}

				if (!CalculateDetailUnitPrice(ref cur_db, ref detail_data, trx_type, exchange_rate, cur_row, item_code_col, qty_col, unit_code_col, item_type_col, disc_perc_col, amt_disc_in_pc_col, item_size_col, sell_unit_price_col, sell_unit_code_col, ivunit_code_col, conversion_rate_col, qty_in_ivunit_col, unit_price_col, unit_price_in_pc_col, customer_code, item_code, price_code, true))
				{
					return false;
				}

				if (!CalculateDetailDiscountAmt(ref cur_db, ref detail_data, trx_type, exchange_rate, cur_row, item_code_col, unit_price_in_pc_col, qty_col, unit_code_col, item_type_col, disc_perc_col, amt_disc_col, amt_disc_in_pc_col, item_size_col, sell_unit_price_col, sell_unit_code_col, ivunit_code_col, conversion_rate_col))
				{
					return false;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessDetailChargeQty)");
			}

			return return_value;
		}

		public static bool ProcessDetailReturnQty(ref clsDatabase cur_db, ref string[,] detail_data, int trx_type, decimal exchange_rate, int cur_row, int item_code_col, int qty_col, int unit_code_col, int item_type_col, int disc_perc_col, int amt_disc_col, int amt_disc_in_pc_col, int item_size_col, int sell_unit_price_col, int sell_unit_code_col, int ivunit_code_col, int conversion_rate_col, int unit_price_col, int unit_price_in_pc_col, int tax_code_col, int qty_in_ivunit_col, int total_cost_col, int qty_invoiced_col, int qty_cur_returned_col, int qty_prev_return_col, string customer_code, string price_code, int invoice_num)
		{
			bool return_value = false;
			decimal old_ivqty = 0;
			decimal conversion_rate = 0;
			string item_code = "";
			int kit_id = 0;
			decimal new_qty = 0;
			bool recalc_flag = false;
			decimal original_qty = 0;
			decimal prev_returned_qty = 0;
			decimal cur_returned_qty = 0;
			decimal old_qty = 0;

			clsMoney o_money = new clsMoney(ref cur_db);

			try
			{
				new_qty = o_money.ToNumMoney(detail_data[qty_col, cur_row]);

				item_code = detail_data[item_code_col, cur_row];
				old_ivqty = o_money.ToNumMoney(detail_data[qty_in_ivunit_col, cur_row]);
				old_qty = o_money.ToNumMoney(detail_data[qty_col, cur_row]);
				original_qty = o_money.ToNumMoney(detail_data[qty_invoiced_col, cur_row]);
				cur_returned_qty = o_money.ToNumMoney(detail_data[qty_cur_returned_col, cur_row]);
				prev_returned_qty = o_money.ToNumMoney(detail_data[qty_prev_return_col, cur_row]);
				conversion_rate = o_money.ToNumMoney(detail_data[conversion_rate_col, cur_row]);

				if (new_qty < 0M)
				{

					detail_data[qty_col, cur_row] = "";
					modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NEGATIVE_VALUE_NOT_ALLOWED);
					return false;

				}
				else if (!GlobalVar.goUtility.IsEmpty(item_code))
				{

					if (new_qty < cur_returned_qty)
					{
						detail_data[qty_col, cur_row] = detail_data[qty_cur_returned_col, cur_row];
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.THIS_RETURN_IS_ALREADY_COMPLETE);
						return false;
					}

					// If this is from a specific invoice, returning qty can not exceed
					// the original qty.
					//
					if (invoice_num > 0)
					{
						if (o_money.RoundToMoney(new_qty + prev_returned_qty) > o_money.RoundToMoney(original_qty))
						{
							detail_data[qty_col, cur_row] = "";
							modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.RETURN_QTY_CANNOT_EXCEED_ORIGINAL);
							return false;
						}

						// Calculate the total cost for this item.
						//
						if (old_qty >= cur_db.fSmallestNumber)
						{
							detail_data[total_cost_col, cur_row] = o_money.RoundToMoney(o_money.ToNumMoney(detail_data[total_cost_col, cur_row]) * new_qty / old_qty).ToString();
						}
					}
					else
					{
						detail_data[qty_invoiced_col, cur_row] = GlobalVar.goUtility.RoundToQtyFactor(new_qty).ToString();
					}

					detail_data[qty_in_ivunit_col, cur_row] = GlobalVar.goUtility.RoundToQtyFactor(new_qty * conversion_rate).ToString();
					detail_data[qty_col, cur_row] = GlobalVar.goUtility.RoundToQtyFactor(new_qty).ToString();

					//  If this is from an existing invoice, do not calculatethe discount, again.
					//  Otherwise, do it again.
					//
					recalc_flag = (invoice_num == 0);

					if (!CalculateDetailQtyInIvUnit(ref cur_db, ref detail_data, trx_type, cur_row, item_code_col, qty_col, unit_code_col, ivunit_code_col, conversion_rate_col, qty_in_ivunit_col, item_size_col, item_type_col))
					{
						return false;
					}

					if (invoice_num == 0)
					{
						if (!CalculateDetailUnitPrice(ref cur_db, ref detail_data, trx_type, exchange_rate, cur_row, item_code_col, qty_col, unit_code_col, item_type_col, disc_perc_col, amt_disc_in_pc_col, item_size_col, sell_unit_price_col, sell_unit_code_col, ivunit_code_col, conversion_rate_col, qty_in_ivunit_col, unit_price_col, unit_price_in_pc_col, customer_code, item_code, price_code, recalc_flag))
						{
							return false;
						}
					}

					// If this memo is linked to an invoice, calculate the discount amount
					// using the originaly given discount instead of the current price.
					//
					if (invoice_num > 0)
					{
						if (old_qty < cur_db.fSmallestNumber)
						{
							detail_data[amt_disc_col, cur_row] = "0";
						}
						else
						{
							detail_data[amt_disc_col, cur_row] = o_money.RoundToMoney(GlobalVar.goUtility.ToValue(detail_data[amt_disc_col, cur_row]) / old_qty * GlobalVar.goUtility.ToValue(detail_data[qty_col, cur_row])).ToString();
						}
					}
					else
					{
						if (!CalculateDetailDiscountAmt(ref cur_db, ref detail_data, trx_type, exchange_rate, cur_row, item_code_col, unit_price_in_pc_col, qty_col, unit_code_col, item_type_col, disc_perc_col, amt_disc_col, amt_disc_in_pc_col, item_size_col, sell_unit_price_col, sell_unit_code_col, ivunit_code_col, conversion_rate_col))
						{
							return false;
						}
					}
				}
				else
				{
					detail_data[qty_col, cur_row] = GlobalVar.goUtility.RoundToQtyFactor(new_qty).ToString();
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessDetailReturnQty)");
			}

			return return_value;
		}

		public static bool ProcessTransactionTaxCode(ref clsDatabase cur_db, ref string[,] detail_data, int trx_type, int tax_code_col, int tax_perc_col, int cur_row, decimal tax_perc)
		{
			bool return_value = false;
			string tax_code = "";
			decimal tmp = 0;
			clsValidate o_val = new clsValidate(ref cur_db);

			try
			{
				tax_code = modCommonUtility.CleanCode(detail_data[tax_code_col, cur_row]);

				// If empty tax_code, reset tax percent.
				// However, do not reset tax_amt, here because it is done CalculateCurrentRow().
				//
				if (GlobalVar.goUtility.IsEmpty(tax_code))
				{
					tax_code = "";
					tax_perc = 0;
					return_value = true;
				}
				else
				{
					if (trx_type == GlobalVar.goConstant.TRX_PURCHASE_TYPE || trx_type == GlobalVar.goConstant.TRX_DM_TYPE || trx_type == GlobalVar.goConstant.TRX_PO_TYPE || trx_type == GlobalVar.goConstant.TRX_PO_QUOTE_TYPE || trx_type == GlobalVar.goConstant.TRX_PURCHASE_REQUISITION_TYPE)
					{
						if (!o_val.IsValidAPTaxCode(tax_code))
						{
							detail_data[tax_code_col, cur_row] = "";
							detail_data[tax_perc_col, cur_row] = "";
							modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oString.STR_TAX_CODE + " " + tax_code + cur_db.oLanguage.oMessage.DOES_NOT_EXIST);
							return false;
						}
					}
					else
					{
						if (!o_val.IsValidARTaxCode(tax_code))
						{
							detail_data[tax_code_col, cur_row] = "";
							detail_data[tax_perc_col, cur_row] = "";
							modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oString.STR_TAX_CODE + " " + tax_code + cur_db.oLanguage.oMessage.DOES_NOT_EXIST);
							return false;
						}
					}

					if ((tax_perc >= cur_db.fSmallestNumber && o_val.oRecordset.iField("iTax_typ") == GlobalVar.goConstant.INCLUDED_TAX_NUM) || (tax_perc <= -cur_db.fSmallestNumber && o_val.oRecordset.iField("iTax_typ") == GlobalVar.goConstant.REGULAR_TAX_NUM))
					{
						detail_data[tax_code_col, cur_row] = "";
						detail_data[tax_perc_col, cur_row] = "";
						modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.TWO_TAX_TYPES_ARE_NOT_ALLOWED);
						return false;
					}
					else
					{
						if (o_val.oRecordset.iField("iTax_typ") == GlobalVar.goConstant.REGULAR_TAX_NUM)
						{
							tax_perc = o_val.oRecordset.mField("fTotalTax_pc");
						}
						else
						{
							tax_perc = -o_val.oRecordset.mField("fTotalTax_pc"); // Meaning included tax
						}
						return_value = true;
					}

				}

				detail_data[tax_code_col, cur_row] = tax_code;
				detail_data[tax_perc_col, cur_row] = tax_perc.ToString();

			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(ProcessTransactionTax)");
			}

			return return_value;
		}

		public static bool ProcessTransactionJobCode(ref clsDatabase cur_db, ref string[,] detail_data, int trx_type, int job_code_col, int cur_row, string customer_code)
		{
			bool return_value = false;

			string job_code = "";
			string original_job_code = "";
			string err_msg = "";
			clsValidate o_val = new clsValidate(ref cur_db);

			job_code = modCommonUtility.CleanCode(detail_data[job_code_col, cur_row]);

			// If empty Job_code, reset Job percent.
			// However, do not reset Job_amt, here because it is done CalculateCurrentRow().
			//
			if (GlobalVar.goUtility.IsEmpty(job_code))
			{
				job_code = "";
				return_value = true;
			}
            else if (!o_val.IsValidJobForTransaction(job_code, ref err_msg, customer_code))
			{
				detail_data[job_code_col, cur_row] = "";
				modDialogUtility.DisplayBox(ref cur_db, err_msg);
				return false;
			}
			else
			{
				return_value = true;
			}

			detail_data[job_code_col, cur_row] = job_code;

			return return_value;
		}

		public static bool ProcessDetailAccountCode(ref clsDatabase cur_db, ref string[,] detail_data, int trx_type, int cur_col, int cur_row, bool use_natural_code_fl)
		{
			bool return_value = false;

			string acct_code = "";
			clsValidate o_val = new clsValidate(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			acct_code = modCommonUtility.CleanCode(detail_data[cur_col, cur_row]);

			if (o_gen.IsBlankGLAccountCode(acct_code))
			{
				detail_data[cur_col, cur_row] = "";
				return_value = true;
			}
			else if (!o_val.IsValidActualAcctCode(acct_code, use_natural_code_fl)) // 04/31/2020 allow any account since data entry clerks should know what they do.
			{
				detail_data[cur_col, cur_row] = "";
				modDialogUtility.DisplayBox(ref cur_db, acct_code + cur_db.oLanguage.oMessage.IS_NOT_VALID_ACTUAL_ACCT);
				return_value = false;
			}
			else
			{
				detail_data[cur_col, cur_row] = acct_code;
				return_value = true;
			}

			o_val.oRecordset.Release();

			return return_value;
		}

		public static bool ProcessDetailPurchaseUnit(ref clsDatabase cur_db, ref string[,] detail_data, int trx_type, int cur_row, int item_code_col, int unit_code_col, int ivunit_code_col, int item_type_col)
		{
			bool return_value = false;

			string unit_code = "";
			string item_code = "";
			decimal conversion_rate = 0;
			string ivunit_code = "";
			clsValidate o_val = new clsValidate(ref cur_db);

			unit_code = modCommonUtility.CleanCode(detail_data[unit_code_col, cur_row]);

			if (!cur_db.uProgram.bIVExist_fl)
			{
				detail_data[unit_code_col, cur_row] = unit_code;
			}

			item_code = detail_data[item_code_col, cur_row];
			ivunit_code = detail_data[ivunit_code_col, cur_row];

			if (GlobalVar.goUtility.IsEmpty(unit_code) || GlobalVar.goUtility.IsEmpty(item_code) || !GlobalVar.goUtility.IsInventoryItemType(GlobalVar.goUtility.ToInteger(detail_data[item_type_col, cur_row])))
			{
				return_value = true;
			}
			else if (!o_val.IsValidUnitCode(item_code, ivunit_code, unit_code, ref conversion_rate))
			{
				detail_data[unit_code_col, cur_row] = "";
				modDialogUtility.DisplayBox(ref cur_db, cur_db.oLanguage.oMessage.NO_CONVERSION_EXIST + "(" + ivunit_code + ":" + unit_code + ")");
				return false;
			}
			else
			{
				return_value = true;
			}

			detail_data[unit_code_col, cur_row] = unit_code;

			return return_value;
		}

	}

}
