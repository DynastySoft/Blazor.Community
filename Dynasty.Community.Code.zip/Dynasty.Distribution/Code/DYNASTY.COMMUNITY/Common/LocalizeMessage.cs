﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//


using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP
{
	internal static class modLocalizeMessage
	{



		public static void InitLabelLocalization()
		{

		}

		public static string LocalizeLabels(ref clsDatabase cur_db, string language_typ, string form_name, string control_caption)
		{

			string return_value = "";
			int i = 0;
			int j = 0;

			try
			{

				return_value = control_caption; // Default

				form_name = GlobalVar.goUtility.STrim(GlobalVar.goUtility.SUCase(GlobalVar.goUtility.SReplace(form_name, "&", "")));

				if (GlobalVar.goUtility.SLength(control_caption) <= 1 || GlobalVar.goUtility.IsNumeric(control_caption))
				{
					return control_caption;
				}

				if (GlobalVar.goUtility.IsEmpty(form_name) | GlobalVar.goUtility.IsEmpty(language_typ))
				{
					return return_value;
				}
				else if (form_name != cur_db.uPageTranslater.sCurrentForm_nm)
				{
					InitLabelLocalization();
					cur_db.uPageTranslater.sCurrentForm_nm = form_name;
				}

				if (!cur_db.uPageTranslater.bLabelFileIsRead_fl)
				{
					if (!ReadLabelFile(ref cur_db, language_typ, form_name))
					{
						return return_value;
					}
				}

				if (GlobalVar.goUtility.IsEmpty(GlobalVar.goUtility.STrim(control_caption)))
				{
					return return_value;
				}

				i = GlobalVar.goUtility.BinarySearch(cur_db.uPageTranslater.sLabelCaption, cur_db.uPageTranslater.ORIGINAL_CAPTION_COL, control_caption);

				if (i >= 0)
				{
                    return_value = cur_db.uPageTranslater.sLabelCaption[cur_db.uPageTranslater.LOCAL_CAPTION_COL, i];
					return return_value;
				}

				// If not found, the english value has to be added.
				//
				AddConstant(ref cur_db, language_typ, form_name, control_caption);

				return_value = control_caption;

				return return_value;


				for (j = 0; j < cur_db.uPageTranslater.iTotalCaptions; j++)
				{
					modGeneralUtility.RunEvents();
					if (GlobalVar.goUtility.SUCase(cur_db.uPageTranslater.sLabelCaption[cur_db.uPageTranslater.FORM_NAME_COL, j]) == GlobalVar.goUtility.SUCase(form_name))
					{
						break;
					}
					else if (GlobalVar.goUtility.IsEmpty(cur_db.uPageTranslater.sLabelCaption[cur_db.uPageTranslater.FORM_NAME_COL, j]))
					{
						break;
					}
				}

				for (i = j; i < cur_db.uPageTranslater.iTotalCaptions; i++)
				{
					modGeneralUtility.RunEvents();
					if (cur_db.uPageTranslater.sLabelCaption[cur_db.uPageTranslater.ORIGINAL_CAPTION_COL, i] == control_caption)
					{
						return_value = cur_db.uPageTranslater.sLabelCaption[cur_db.uPageTranslater.LOCAL_CAPTION_COL, i];
						return return_value;
					}
				}

				// If not found, the english value has to be added.
				//
				AddConstant(ref cur_db, language_typ, form_name, control_caption);

				return_value = control_caption;

			}
			catch (Exception ex)
			{
				return_value = control_caption; // Pass whatever it was.
			}

			return return_value;

		}

		// FUNCTION: To write the local constants into the language file
		//
		public static void WriteLabelsToFile(ref clsDatabase cur_db, string language_typ, string form_name)
		{

			int i = 0;
			int max_line = 0;
			string sql_str = "";

			try
			{

				if (GlobalVar.goUtility.IsEmpty(form_name) | GlobalVar.goUtility.IsEmpty(language_typ) | !cur_db.uPageTranslater.bNewLabelIsAdded_fl)
				{
					return;
				}

				sql_str = "DELETE FROM tblGOLanguageTranslator";
				sql_str += " WHERE sLanguage_cd = '" + language_typ + "'";
				sql_str += " AND sPage_nm = '" + form_name + "'";
				if (!cur_db.ExecuteSQL(sql_str))
				{
					return;
				}

				for (i = 0; i < cur_db.uPageTranslater.iTotalCaptions; i++)
				{
					sql_str = "INSERT INTO tblGOLanguageTranslator(";
					sql_str += " sLanguage_cd";
					sql_str += ",sPage_nm";
					sql_str += ",sOriginal";
					sql_str += ",sLocal";
					sql_str += ",sMenu_nm";
					sql_str += ") VALUES (";
					sql_str += " '" + language_typ + "'";
					sql_str += ",'" + form_name + "'";
					sql_str += ",'" + cur_db.uPageTranslater.sLabelCaption[cur_db.uPageTranslater.ORIGINAL_CAPTION_COL, i] + "'";
					sql_str += ",'" + cur_db.uPageTranslater.sLabelCaption[cur_db.uPageTranslater.LOCAL_CAPTION_COL, i] + "'";
					sql_str += ",''";
					sql_str += ")";
					if (!cur_db.ExecuteSQL(sql_str))
					{
						return;
					}
				}

				cur_db.uPageTranslater.bLabelFileIsRead_fl = false;
				cur_db.uPageTranslater.bNewLabelIsAdded_fl = false;

			}
			catch (Exception ex)
			{

			}

		}

		private static bool ReadLabelFile(ref clsDatabase cur_db, string language_typ, string form_name)
		{

			bool return_value = false;
			string sql_str = "";
			int line_num = 0;
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			try
			{

				if (GlobalVar.goUtility.IsEmpty(language_typ))
				{
					return true;
				}

				sql_str = "SELECT * FROM tblGOLanguageTranslator ";
				sql_str += " WHERE sLanguage_cd = '" + language_typ + "'";
				sql_str += " AND sPage_nm = '" + form_name + "'";
				sql_str += " ORDER BY sOriginal"; // Make sure sorted by sOriginal because of BinarySearch() later on.
				if (!cur_set.CreateSnapshot(sql_str))
				{
					return return_value;
				}

				GlobalVar.goUtility.ResizeDim(ref cur_db.uPageTranslater.sLabelCaption, 3, cur_set.RecordCount() + 100);

				line_num = 0;

				while (!cur_set.EOF())
				{
					cur_db.uPageTranslater.sLabelCaption[cur_db.uPageTranslater.FORM_NAME_COL, line_num] = cur_set.sField("sPage_nm");
					cur_db.uPageTranslater.sLabelCaption[cur_db.uPageTranslater.ORIGINAL_CAPTION_COL, line_num] = cur_set.sField("sOriginal");
					cur_db.uPageTranslater.sLabelCaption[cur_db.uPageTranslater.LOCAL_CAPTION_COL, line_num] = cur_set.sField("sLocal");
					cur_set.MoveNext();
					line_num += 1;
				}

				cur_db.uPageTranslater.bLabelFileIsRead_fl = true;
				cur_db.uPageTranslater.iTotalCaptions = line_num;

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message);

			}

			return return_value;

		}

		private static void AddConstant(ref clsDatabase cur_db, string language_typ, string form_name, string control_caption)
		{

			int i = 0;
			int j = 0;
			string sql_str = "";

			try
			{

				if (!IsEnglish(control_caption))
				{
					return;
				}

				// Fnd the beginning of the page/form.
				//
				for (i = 0; i < cur_db.uPageTranslater.iTotalCaptions; i++)
				{
					modGeneralUtility.RunEvents();
					if (GlobalVar.goUtility.SUCase(cur_db.uPageTranslater.sLabelCaption[cur_db.uPageTranslater.FORM_NAME_COL, i]) == GlobalVar.goUtility.SUCase(form_name))
					{
						break;
					}
					else if (GlobalVar.goUtility.IsEmpty(cur_db.uPageTranslater.sLabelCaption[cur_db.uPageTranslater.ORIGINAL_CAPTION_COL, i]))
					{
						break;
					}
				}

				cur_db.uPageTranslater.iTotalCaptions += 1;

				// If the array is full, enlarge it.
				//
				if (i >= cur_db.uPageTranslater.sLabelCaption.GetUpperBound(1) || cur_db.uPageTranslater.iTotalCaptions >= cur_db.uPageTranslater.sLabelCaption.GetUpperBound(1))
				{
					GlobalVar.goUtility.ResizeDimPreserved(ref cur_db.uPageTranslater.sLabelCaption, 3, cur_db.uPageTranslater.sLabelCaption.GetUpperBound(1) + 100);
				}

				cur_db.uPageTranslater.sLabelCaption[cur_db.uPageTranslater.FORM_NAME_COL, cur_db.uPageTranslater.iTotalCaptions - 1] = form_name;
				cur_db.uPageTranslater.sLabelCaption[cur_db.uPageTranslater.ORIGINAL_CAPTION_COL, cur_db.uPageTranslater.iTotalCaptions - 1] = control_caption;
				cur_db.uPageTranslater.sLabelCaption[cur_db.uPageTranslater.LOCAL_CAPTION_COL, cur_db.uPageTranslater.iTotalCaptions - 1] = control_caption;

				sql_str = "INSERT INTO tblGOLanguageTranslator(";
				sql_str += " sLanguage_cd";
				sql_str += ",sPage_nm";
				sql_str += ",sOriginal";
				sql_str += ",sLocal";
				sql_str += ",sMenu_nm";
				sql_str += ") VALUES (";
				sql_str += " '" + language_typ + "'";
				sql_str += ",'" + form_name + "'";
				sql_str += ",'" + cur_db.uPageTranslater.sLabelCaption[cur_db.uPageTranslater.ORIGINAL_CAPTION_COL, cur_db.uPageTranslater.iTotalCaptions - 1] + "'";
				sql_str += ",'" + cur_db.uPageTranslater.sLabelCaption[cur_db.uPageTranslater.LOCAL_CAPTION_COL, cur_db.uPageTranslater.iTotalCaptions - 1] + "'";
				sql_str += ",''";
				sql_str += ")";
				if (!cur_db.ExecuteSQL(sql_str))
				{
					return;
				}

				cur_db.uPageTranslater.bNewLabelIsAdded_fl = true;

			}
			catch (Exception ex)
			{

			}

		}

		public static bool IsEnglish(string cur_str)
		{

			return true;

		}

		// FUNCTION: This will localize the constants and messages.
		//
		public static void LocalizeConstants(ref clsDatabase cur_db, string language_type)
		{

			string local_dir = "";

			try
			{

				if (!cur_db.IsDSNless() & GlobalVar.goUtility.IsEmpty(cur_db.sDSN)) // When this is called before log-in, just exit
				{
					return;
				}

				local_dir = cur_db.uDirectory.sLocaleDirectory_nm;

				if (GlobalVar.goUtility.IsNonEmpty(cur_db.sDSN) && GlobalVar.goUtility.SInStr(local_dir, "\\" + cur_db.sDSN) <= 0) // This could be called before sDSN is attached to sLocaleDirectory_nm.
				{
					local_dir += "\\" + cur_db.sDSN;
				}

				if (GlobalVar.goUtility.IsEmpty(language_type))
				{
					GlobalVar.goLocalize.ResetLocalization();
				}
				else
				{
					if (!GlobalVar.goFile.DirectoryExists(local_dir + "\\" + language_type))
					{
						System.IO.Directory.CreateDirectory(local_dir + "\\" + language_type);
					}
					GlobalVar.goLocalize.SetLocalization();
					GlobalVar.goLocalize.GetLocalConstants(local_dir + "\\" + language_type + "\\Constants.lan");
					GlobalVar.goLocalize.GetLocalMessages(local_dir + "\\" + language_type + "\\Messages.lan");
					GlobalVar.goLocalize.GetLocalWebMessages(local_dir + "\\" + language_type + "\\WebMessages.lan");
				}

				GlobalVar.goWebMessage.LocalizeMessages();
				GlobalVar.goMessage.LocalizeMessages();
				GlobalVar.goString.LocalizeConstants();
				GlobalVar.goConstant.LocalizeConstants();
				GlobalVar.goAPConstant.LocalizeConstants();
				GlobalVar.goARConstant.LocalizeConstants();
				GlobalVar.goBRConstant.LocalizeConstants();
				GlobalVar.goGLConstant.LocalizeConstants();
				GlobalVar.goIVConstant.LocalizeConstants();
				GlobalVar.goJCConstant.LocalizeConstants();
				GlobalVar.goPOConstant.LocalizeConstants();
				GlobalVar.goPRConstant.LocalizeConstants();
				GlobalVar.goRMConstant.LocalizeConstants();
				GlobalVar.goSOConstant.LocalizeConstants();
				GlobalVar.goWOConstant.LocalizeConstants();

				// Write back to the file if there was new constant/message.
				//
				GlobalVar.goLocalize.WriteConstantsToFile();
				GlobalVar.goLocalize.WriteMessagesToFile();
				GlobalVar.goLocalize.WriteWebMessagesToFile();

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(LocalizeConstants)");

			}

		}

	}


}
