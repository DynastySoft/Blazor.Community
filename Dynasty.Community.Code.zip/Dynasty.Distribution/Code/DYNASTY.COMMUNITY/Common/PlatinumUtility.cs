﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Database;
using Dynasty.Local;

namespace Dynasty.ASP
{

#if WEB
    using System.Web.UI.WebControls;
#else
using static System.Windows.Forms.Application;
#endif

    internal static class modPlatinumUtility
    {

        public static clsPlatinum goPlatinum = new clsPlatinum();
        public static clsEnterprise goEnterprise = new clsEnterprise();

#if WEB
        public static void LoadBatchNumbers(ref clsDatabase cur_db, ref DropDownList cur_box, string user_cd)
        {
#else
	public static void LoadBatchNumbers(ref clsDatabase cur_db, ref ComboBox cur_box, string user_cd)
	{
#endif

            clsRecordset cur_set = new clsRecordset(ref cur_db);
            ArrayList item_list = new ArrayList();
            string sql_str = "";
            string filler = "";

            if (!cur_db.bEnableBatchEntry_fl)
            {
                return;
            }

            item_list.Add(new clsComboBoxItem("", ""));

            //goPlatinum.DeleteBatch(ref cur_db, cur_db.sUser_cd, 0, 0)       ' 0, 0 This will delete phantom batch created by s/o, p/o, b/r, etc...

            sql_str = "SELECT * FROM " + clsPlatinum.BATCH_TABLE_NAME;
            if (user_cd == cur_db.sUser_cd && cur_db.iUserType_id >= clsConstant.USER_SUPERVISOR_TYPE)
            {
                // Show all
            }
            else
            {
                sql_str += " WHERE sUser_cd = '" + user_cd + "'";
            }
            sql_str += " ORDER BY sUser_cd, iBatch_num";

            if (!cur_set.CreateSnapshot(sql_str))
            {
                return;
            }

            if (cur_set.RecordCount() > 1)
            {
                item_list.Add(new clsComboBoxItem(GlobalVar.goString.STR_ALL, "0"));
            }

            filler = GlobalVar.goUtility.Space(5);

            while (!cur_set.EOF())
            {
                item_list.Add(new clsComboBoxItem(cur_set.sField("sUser_cd") + GlobalVar.goConstant.ID_DELIMITER + filler + cur_set.iField("iBatch_num").ToString(), cur_set.iField("iBatch_num").ToString()));
                cur_set.MoveNext();
            }

            modWebLoadUtility.LoadComboBox(ref cur_box, item_list);

            cur_set.Release();

        }

    }

}
