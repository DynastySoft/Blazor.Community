﻿//  Copyright (c) DynastySoft Corporation, 2003.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//




using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing.Design;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using Dynasty.Local;
using Dynasty.Database;
using Dynasty.Report;

namespace Dynasty.ASP
{
	public class clsRentalBilling
	{

		clsDynastyUtility oUtility = new clsDynastyUtility();

		public bool GenerateLeaseInvoices(ref clsDatabase cur_db, int invoice_date, int due_date, string billing_cycle, ref int total_lease, ref int num_created, ref string lease_list, ref string emails_failed, int last_invoice_date, int rental_num = 0)
		{

			bool return_value = false;
			string sql_str = "";
			clsRecordset cur_set = new clsRecordset(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);
			int i = 0;
			int billing_id = 0;
			int invoice_num = 0;
			bool original_fl = false;
			bool do_not_email_invoice_fl = false;

			try
			{

				billing_id = oUtility.ToInteger(oUtility.SFormat(DateTime.Now, "Mddhhmmss"));

				num_created = 0;
				total_lease = 0;
				lease_list = "";

				sql_str = "SELECT r.*, c.sAddress1, c.sAddress2, c.sAddress3, c.sTerms_cd, c.sPosting_cd, c.sPrice_cd, c.sSalesrep_cd, c.iEmailStmt_fl";
				sql_str += " FROM tblFARental r INNER JOIN tblARCustomer c ON (r.sCustomer_cd = c.sCustomer_cd)";
				sql_str += " WHERE r.iTransaction_typ = " + GlobalVar.goConstant.TRX_FA_RENTAL_TYPE.ToString();
				if (rental_num > 0)
                {
					sql_str += " AND r.iTransaction_num = " + rental_num.ToString();
				}
				else
                {
					sql_str += " AND r.iStatus_typ = " + GlobalVar.goFAConstant.RENTAL_OPEN_TRX_NUM.ToString();
					sql_str += " AND r.mDue_amt >= 1 AND r.sCustomer_cd <> '' ";
					sql_str += " AND r.iContractBegin_dt <= " + invoice_date.ToString() + " AND ( r.iContractEnd_dt = 0 OR r.iContractEnd_dt > " + invoice_date.ToString() + ")";
					sql_str += " AND r.sBillingCycle_cd = '" + billing_cycle + "'";
				}
				sql_str += " AND r.iCompleted_fl = 1" ;
				sql_str += " AND r.iLastBilled_dt < " + invoice_date.ToString();		

				sql_str += " ORDER BY r.iTransaction_num";
				if (!cur_set.CreateSnapshot(sql_str))
				{
					return false;
				}
				else if (cur_set.EOF())
				{
					// return true;   need to run CreateHistory()
				}

				total_lease = cur_set.RecordCount();
				emails_failed = "";
				num_created = cur_set.RecordCount();

				for (i = 0; i < cur_set.RecordCount(); i++)
				{

					if (!cur_db.TransactionBegin())
					{
						return false;
					}

					do_not_email_invoice_fl = (cur_set.iField("iEmailStmt_fl") == 0);

					// Create invoice for this lease.
					//
					if (!CreateInvoice(ref cur_db, ref cur_set, o_gen.CurrentDate(), invoice_date, due_date, billing_id, do_not_email_invoice_fl, ref invoice_num, 0))
					{
						cur_db.TransactionRollback();
						return false;
					}

					if (!cur_db.TransactionCommit())
					{
						cur_db.TransactionRollback();
						return false;
					}

					// Send email
					// Should be outside transaction loop.  Otherwise, the invoice won't be found until it is committed.
					//
					if (do_not_email_invoice_fl == false && cur_set.iField("iEmailInvoice_fl") == GlobalVar.goConstant.FLAG_ON && oUtility.IsNonEmpty(cur_set.sField("sContactEmailAddress")))
					{

						original_fl = GlobalVar.gbUsePDFFileForReport_fl;
						GlobalVar.gbUsePDFFileForReport_fl = true;

						if (!SendEmail(ref cur_db, ref cur_set, invoice_num))
						{
                            emails_failed += oUtility.IIf(oUtility.IsNonEmpty(emails_failed), ",", "") + invoice_num.ToString();
						}

						GlobalVar.gbUsePDFFileForReport_fl = original_fl;

					}

					lease_list += oUtility.IIf(oUtility.IsNonEmpty(lease_list), ",", "") + cur_set.iField("iTransaction_num");

					cur_set.MoveNext();

				}

				CreateHistory(ref cur_db, billing_id, invoice_date, due_date, billing_cycle, do_not_email_invoice_fl, lease_list);

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(GenerateLeaseInvoices)");

			}

			return return_value;

		}

		public bool CreateInvoice(ref clsDatabase cur_db, ref clsRecordset cur_set, int entry_date, int invoice_date, int due_date, int billing_id, bool do_not_email_invoice_fl, ref int invoice_num, decimal contract_amt)
		{
			bool return_value = false;

			clsInvoice o_invoice = new clsInvoice(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);
			clsRecordset empty_set = new clsRecordset(ref cur_db);
			clsRecordset detail_set = new clsRecordset(ref cur_db);
			clsRecordset comm_set = new clsRecordset(ref cur_db);

			int row_num = 0;
			int i = 0;
			string str_invoice_num = "";
			string sql_str = "";
			decimal line_tax = 0;
			decimal total_line_tax = 0;
			int month_invoiced = 0;
			string asset_list = "";
			int next_due_date = 0;
			decimal remaining_amt = 0;

			decimal amt_taxable = 0;
			decimal amt_nontaxable = 0;
			decimal amt_tax = cur_set.mField("mTax_amt");
			decimal amt_subtotal= cur_set.mField("mSubTotal_amt");
			decimal amt_total= cur_set.mField("mDue_amt");
			decimal amt_due = cur_set.mField("mDue_amt");

			try
			{
				if (cur_set.mField("mTax_amt") > 0)
                {
					amt_taxable = amt_subtotal;
				}
				else
                {
					amt_nontaxable = amt_subtotal;
				}

				// If contract_amt > 0, then this is from the rental page. Create the the month invoiced with iContractBegin_dt.
				//
				if (contract_amt > 0)
                {
					month_invoiced = ((cur_set.iField("iContractBegin_dt") / 100) * 100 + 1);		// First month of the contract.
                }
				else
                {
					month_invoiced = ((invoice_date / 100) * 100 + 1);								// Make sure the first day of month
				}

				if (cur_set.iField("iLastBilled_dt") > 0)
                {
					// this is from monthly billing.  Use the numbers in the lease
                }
				// The first first billing coming from the rental page and bLockRentalAtBilling_fl is off
				//
				else if (cur_db.uSecurity.bLockRentalAtBilling_fl == false && contract_amt > 0)       
				{
					// If the contract starts in the middle of month, the first invoice SHOULD include the prorated amount for the partial month and full chrage for the next month
					//
					if ((cur_set.iField("iContractBegin_dt") % 100) > 1)
					{
						month_invoiced = ((oUtility.AddToDate(GlobalVar.goConstant.MONTH_TYPE, cur_set.iField("iContractBegin_dt"), 1) / 100) * 100 + 1);

						amt_due = CalculateFirstMonthDue(ref cur_db, cur_set.iField("iContractBegin_dt"), cur_set.iField("iContractEnd_dt"), cur_set.iField("mDue_amt"));

						amt_total = amt_due;

						if (cur_set.mField("mTax_amt") == 0)
                        {
							amt_tax = 0;
							amt_subtotal = amt_due;
							amt_taxable = 0;
							amt_nontaxable = amt_due;
							amt_subtotal = amt_due;
						}
						else 
						{
							// At this point, amt_due includes the tax.  Find out the real tax amount.
							//
							if (o_gen.CalcSalesTax(amt_due, cur_set.mField("fTax_pc"), ref amt_tax, true) == false)
							{
								return false;
							}

							if (cur_set.mField("fTax_pc") > 0)
                            {
								amt_subtotal = amt_due - amt_tax;
							}
							else
                            {
								amt_subtotal = amt_due;			// Tax is embedded
							}

							amt_taxable = amt_subtotal;
							amt_nontaxable = 0;
						}
					}
				}

				// If bLockRentalAtBilling_fl option is on, and this is from the rental page(contract_amt  > 0), then, create one invoice with full contract amount w/ monthly payment schedule.
				//
				else if (cur_db.uSecurity.bLockRentalAtBilling_fl && contract_amt  > 0 && cur_set.mField("mDue_amt") > 0)
                {
					amt_due = contract_amt;
					amt_total = contract_amt;

					amt_subtotal = o_money.RoundToMoney(amt_subtotal * contract_amt / cur_set.mField("mDue_amt"));
					amt_taxable = o_money.RoundToMoney(amt_taxable * contract_amt / cur_set.mField("mDue_amt"));
					amt_nontaxable = o_money.RoundToMoney(amt_nontaxable * contract_amt / cur_set.mField("mDue_amt"));

					if (cur_set.mField("fTax_pc") > 0)
                    {
						//amt_tax = o_money.RoundToMoney(amt_tax * contract_amt / cur_set.mField("mDue_amt"));
						amt_tax = contract_amt - amt_subtotal;
					}
					else 
					{
						if (o_gen.CalcSalesTax(amt_due, cur_set.mField("fTax_pc"), ref amt_tax, true) == false)
                        {
							return false;
                        }
                    }

					// Invoiced for all until the end of contract
					//
					month_invoiced = ((oUtility.AddToDate(GlobalVar.goConstant.MONTH_TYPE, cur_set.iField("iContractEnd_dt"), 1) / 100) * 100 + 1);
				}

				invoice_num = o_gen.GetNextNumber(GlobalVar.goConstant.TRX_INVOICE_TYPE);

				if (invoice_num <= 0)
				{
					return false;
				}

				str_invoice_num = o_gen.GetFormatedDocumentNumber(GlobalVar.goConstant.TRX_INVOICE_TYPE, invoice_num.ToString());

				due_date = oUtility.IIf(due_date > 0, due_date, invoice_date);

				// --------------------------------------------------------------------------------------------------
				// HEADER SECTION
				// --------------------------------------------------------------------------------------------------
				o_invoice.iTransaction_typ = GlobalVar.goConstant.TRX_INVOICE_TYPE;
				o_invoice.iTransaction_num = invoice_num;
				o_invoice.iStatus_typ = GlobalVar.goConstant.OPEN_TRX_NUM;
				o_invoice.iDropShipment_fl = 0;
				o_invoice.iGiftShipment_fl = 0;
				o_invoice.sJob_cd = "";
				o_invoice.sYourReference = o_gen.GetFormatedDocumentNumber(GlobalVar.goConstant.TRX_FA_RENTAL_TYPE, cur_set.iField("iTransaction_num").ToString());
				o_invoice.sReference = "EQUIP.RENTAL";
				o_invoice.sLocation_cd = o_gen.GetDefaultLocationCode("");
				o_invoice.sDunn_cd = "";
				o_invoice.sComment = "";
				o_invoice.sTax_cd = cur_set.sField("sTax_cd");
				o_invoice.iEntry_dt = entry_date;
				o_invoice.iOrder_num = 0;
				o_invoice.sVia_cd = "";
				o_invoice.sPrice_cd = cur_set.sField("sPrice_cd");
				o_invoice.sSalesrep_cd = cur_set.sField("sSalesrep_cd");
				o_invoice.sTerms_cd = cur_set.sField("sTerms_cd");
				o_invoice.iShipped_dt = entry_date;
				o_invoice.iRequired_dt = entry_date;
				o_invoice.iApply_dt = entry_date;
				o_invoice.sFob_cd = "";
				o_invoice.sCustomer_cd = cur_set.sField("sCustomer_cd");
				o_invoice.sCustomer_nm = cur_set.sField("sCustomer_nm");
				o_invoice.sCustomerAttn = cur_set.sField("sContact_nm");
				o_invoice.sCustomerAddress1 = cur_set.sField("sAddress1");
				o_invoice.sCustomerAddress2 = cur_set.sField("sAddress2");
				o_invoice.sCustomerAddress3 = cur_set.sField("sAddress3");
				o_invoice.fWeight = 0;
				o_invoice.fTax_pc = cur_set.mField("fTax_pc");
				o_invoice.mNonTaxable_amt = amt_nontaxable;
				o_invoice.mTaxable_amt = amt_taxable;
				o_invoice.mTax_amt = amt_tax;
				o_invoice.mDiscount_amt = 0;
				o_invoice.mFreight_amt = 0;
				o_invoice.mTotal_amt = amt_total;       // cur_set.mField("mSubTotal_amt") + cur_set.mField("mTax_amt"); // mSubTotal_amt carrys the detail total only.
				o_invoice.mPaid_amt = 0;
				o_invoice.mDue_amt = amt_due;
				o_invoice.sCreator_id = "AUTO";
				o_invoice.sPosting_cd = cur_set.sField("sPosting_cd");
				o_invoice.sShipToFax = "";
				o_invoice.sShipToPhone = "";
				o_invoice.sShipToCountry_cd = "";
				o_invoice.sShipToZipCode = "";
				o_invoice.sShipToState = "";
				o_invoice.sShipToCity = "";
				o_invoice.sShipTo_cd = "";
				o_invoice.sWebUser_id = "";
				o_invoice.iBatch_num = 0;
				o_invoice.iDue_dt = due_date;
				o_invoice.iPrinted_num = 0;
				o_invoice.iRecurring_typ = 0;
				o_invoice.iToRecur_num = 0;
				o_invoice.iToRecur_dt = 0;
				o_invoice.sShipToAttn = cur_set.sField("sContact_nm");
				o_invoice.sShipToAddress3 = cur_set.sField("sAddress3");
				o_invoice.sShipToAddress2 = cur_set.sField("sAddress2");
				o_invoice.sShipToAddress1 = cur_set.sField("sAddress1");
				o_invoice.sShipTo_nm = cur_set.sField("sCustomer_nm");
				o_invoice.sTransaction_num = str_invoice_num;
				o_invoice.sLastUpdate_id = cur_set.sField("sLastUpdate_id");
				o_invoice.dtLastUpdate_dt = DateTime.Now;
				o_invoice.sUserApproved_cd = "";
				o_invoice.iToApprove_num = 0;
				o_invoice.sFund_cd = "";
				o_invoice.iFromPackingSlip_fl = 0;
				o_invoice.mFreightTax_amt = 0;
				o_invoice.iSource_typ = cur_set.iField("iTransaction_typ");
				o_invoice.iSource_num = cur_set.iField("iTransaction_num");
				o_invoice.iEmailed_num = oUtility.IIf(do_not_email_invoice_fl == false && cur_set.iField("iEmailInvoice_fl") == GlobalVar.goConstant.FLAG_ON && oUtility.IsNonEmpty(cur_set.sField("sContactEmailAddress")), 1, 0);
				o_invoice.iBilling_id = billing_id;

				// --------------------------------------------------------------------------------------------------
				// DETAIL SECTION
				// --------------------------------------------------------------------------------------------------
				sql_str = "SELECT * FROM tblFARentalDet";
				sql_str += " WHERE iTransaction_typ = " + cur_set.iField("iTransaction_typ").ToString() + " AND iTransaction_num = " + cur_set.iField("iTransaction_num").ToString();
				sql_str += " AND iReturned_dt = 0";
				if (detail_set.CreateSnapshot(sql_str) == false)
				{
					return false;
				}

				if (contract_amt > 0 && cur_db.uSecurity.bLockRentalAtBilling_fl)
				{
					oUtility.ResizeDim(ref o_invoice.sDetailData, clsInvoice.TOTAL_COLUMNS, 1);

					o_invoice.sDetailData[clsInvoice.DESCRIPTION_COL, 0] = "Charge for the entire contract" ;
					o_invoice.sDetailData[clsInvoice.UNIT_CODE_COL, 0] = "EA";
					o_invoice.sDetailData[clsInvoice.QTY_SHIPPED_COL, 0] = "1";
					o_invoice.sDetailData[clsInvoice.QTY_ORDERED_COL, 0] = "1";
					o_invoice.sDetailData[clsInvoice.QTY_BACKORDER_COL, 0] = "0";
					o_invoice.sDetailData[clsInvoice.UNIT_PRICE_COL, 0] = amt_subtotal.ToString();
					o_invoice.sDetailData[clsInvoice.AMT_EXTENDED_COL, 0] = amt_subtotal.ToString();
					o_invoice.sDetailData[clsInvoice.TAX_CODE_COL, 0] = cur_set.sField("sTax_cd");
					o_invoice.sDetailData[clsInvoice.TAX_PERC_COL, 0] = cur_set.mField("fTax_pc").ToString();
					o_invoice.sDetailData[clsInvoice.AMT_TAX_COL, 0] = amt_tax.ToString();
					o_invoice.sDetailData[clsInvoice.ITEM_TYPE_COL, 0] = GlobalVar.goIVConstant.SERVICE_ITEM_NUM.ToString();
					o_invoice.sDetailData[clsInvoice.LINE_ID_COL, 0] = "1";

					o_invoice.sDetailData[clsInvoice.DESCRIPTION_COL, 1] = "Rental Period : " + o_gen.ToStrDate(cur_set.iField("iContractBegin_dt")) + " ~ " + o_gen.ToStrDate(cur_set.iField("iContractEnd_dt"));

				}
				else if ((cur_set.iField("iContractBegin_dt") % 100) > 1 || detail_set.RecordCount() == 1)		// this includes the prorated amount
                {
					for (row_num = 0; row_num < detail_set.RecordCount(); row_num++)
					{
						asset_list += oUtility.IIf(oUtility.IsEmpty(detail_set.sField("sAsset_cd")), "", ", ") + detail_set.sField("sAsset_cd");

						detail_set.MoveNext();
					}

					detail_set.MoveFirst();

					oUtility.ResizeDim(ref o_invoice.sDetailData, clsInvoice.TOTAL_COLUMNS, 1);

					if (detail_set.RecordCount() == 1)
                    {
						o_invoice.sDetailData[clsInvoice.ASSET_CODE_COL, 0] = detail_set.sField("sAsset_cd");
						o_invoice.sDetailData[clsInvoice.LOCATION_COL, 0] = o_gen.GetDefaultLocationCode("");
						o_invoice.sDetailData[clsInvoice.DESCRIPTION_COL, 0] = detail_set.sField("sAsset_cd") + " : " + detail_set.sField("sDescription");
					}
					else
                    {
						o_invoice.sDetailData[clsInvoice.DESCRIPTION_COL, 0] = asset_list;
					}

					o_invoice.sDetailData[clsInvoice.UNIT_CODE_COL, 0] = "EA";
					o_invoice.sDetailData[clsInvoice.QTY_SHIPPED_COL, 0] = "1";
					o_invoice.sDetailData[clsInvoice.QTY_ORDERED_COL, 0] = "1";
					o_invoice.sDetailData[clsInvoice.QTY_BACKORDER_COL, 0] = "0";
					o_invoice.sDetailData[clsInvoice.UNIT_PRICE_COL, 0] = amt_subtotal.ToString();
					o_invoice.sDetailData[clsInvoice.AMT_EXTENDED_COL, 0] = amt_subtotal.ToString();
					o_invoice.sDetailData[clsInvoice.TAX_CODE_COL, 0] = cur_set.sField("sTax_cd");
					o_invoice.sDetailData[clsInvoice.TAX_PERC_COL, 0] = cur_set.mField("fTax_pc").ToString();
					o_invoice.sDetailData[clsInvoice.AMT_TAX_COL, 0] = amt_tax.ToString();
					o_invoice.sDetailData[clsInvoice.ITEM_TYPE_COL, 0] = GlobalVar.goIVConstant.SERVICE_ITEM_NUM.ToString();
					o_invoice.sDetailData[clsInvoice.LINE_ID_COL, 0] = "1";

					if (detail_set.RecordCount() == 1 && (cur_set.iField("iContractBegin_dt") % 100) == 1)
                    {
						o_invoice.sDetailData[clsInvoice.DESCRIPTION_COL, 1] = "Rental Period : " + Convert.ToDateTime(o_gen.ToStrDate(invoice_date)).ToString("MMMM") + " " + Convert.ToDateTime(o_gen.ToStrDate(invoice_date)).Year;
					}
					else
                    {
						o_invoice.sDetailData[clsInvoice.DESCRIPTION_COL, 1] = "Rental Period : " + o_gen.ToStrDate(cur_set.iField("iContractBegin_dt")) + " ~ " + o_gen.ToStrDate(oUtility.AddToDate(GlobalVar.goConstant.DAY_TYPE, oUtility.AddToDate(GlobalVar.goConstant.MONTH_TYPE, (cur_set.iField("iContractBegin_dt") / 100) * 100 + 1, 2), -1));
					}
				}
				else 
				{
					oUtility.ResizeDim(ref o_invoice.sDetailData, clsInvoice.TOTAL_COLUMNS, detail_set.RecordCount());

					for (row_num = 0; row_num < detail_set.RecordCount(); row_num++)
					{
						o_invoice.sDetailData[clsInvoice.ASSET_CODE_COL, row_num] = detail_set.sField("sAsset_cd");
						o_invoice.sDetailData[clsInvoice.LOCATION_COL, row_num] = o_gen.GetDefaultLocationCode("");
						o_invoice.sDetailData[clsInvoice.DESCRIPTION_COL, row_num] = detail_set.sField("sAsset_cd") + " : " + detail_set.sField("sDescription");
						o_invoice.sDetailData[clsInvoice.UNIT_CODE_COL, row_num] = "EA";
						o_invoice.sDetailData[clsInvoice.QTY_SHIPPED_COL, row_num] = "1";
						o_invoice.sDetailData[clsInvoice.QTY_ORDERED_COL, row_num] = "1";
						o_invoice.sDetailData[clsInvoice.QTY_BACKORDER_COL, row_num] = "0";
						o_invoice.sDetailData[clsInvoice.UNIT_PRICE_COL, row_num] = detail_set.mField("mUnitPrice_amt").ToString();
						o_invoice.sDetailData[clsInvoice.AMT_EXTENDED_COL, row_num] = detail_set.mField("mUnitPrice_amt").ToString();
						o_invoice.sDetailData[clsInvoice.TAX_CODE_COL, row_num] = cur_set.sField("sTax_cd");
						o_invoice.sDetailData[clsInvoice.TAX_PERC_COL, row_num] = cur_set.mField("fTax_pc").ToString();
						o_invoice.sDetailData[clsInvoice.AMT_TAX_COL, row_num] = o_money.RoundToMoney(detail_set.mField("mUnitPrice_amt") * cur_set.mField("fTax_pc") / 100).ToString();
						o_invoice.sDetailData[clsInvoice.ITEM_TYPE_COL, row_num] = GlobalVar.goIVConstant.SERVICE_ITEM_NUM.ToString();
						o_invoice.sDetailData[clsInvoice.LINE_ID_COL, row_num] = (row_num + 1).ToString();
						o_invoice.sDetailData[clsInvoice.SELL_UNIT_CODE_COL, row_num] = "EA";
						o_invoice.sDetailData[clsInvoice.SELL_UNIT_PRICE_COL, row_num] = detail_set.mField("mSellUnitPrice_amt").ToString();
						o_invoice.sDetailData[clsInvoice.AMT_TAX_COL, 0] = amt_tax.ToString();

						if (amt_tax != 0)
						{
							if (detail_set.mField("mUnitPrice_amt") > 0 && cur_set.mField("mSubTotal_amt") > 0)
							{
								line_tax = o_money.RoundToMoney((amt_tax * (detail_set.mField("mUnitPrice_amt") / cur_set.mField("mSubTotal_amt"))));
								total_line_tax += line_tax;
							}
						}

						o_invoice.sDetailData[clsInvoice.AMT_TAX_COL, row_num] = line_tax.ToString();

						detail_set.MoveNext();
					}

					o_invoice.sDetailData[clsInvoice.DESCRIPTION_COL, row_num] = "Rental Period : " + Convert.ToDateTime(o_gen.ToStrDate(invoice_date)).ToString("MMMM") + " " + Convert.ToDateTime(o_gen.ToStrDate(invoice_date)).Year;

					// If there is rounding error, take care of it.
					//
					if (amt_tax != 0 && amt_tax != total_line_tax)
					{
						for (i = 0; i < row_num; i++)
						{
							if (o_money.ToNumMoney(o_invoice.sDetailData[clsInvoice.UNIT_PRICE_COL, i]) > 0)
							{
								o_invoice.sDetailData[clsInvoice.AMT_TAX_COL, i] = (o_money.ToNumMoney(o_invoice.sDetailData[clsInvoice.AMT_TAX_COL, i]) + (amt_tax - total_line_tax)).ToString();
								break;
							}
						}
					}
				}

				// --------------------------------------------------------------------------------------------------
				// COMMISSION SECTION
				// --------------------------------------------------------------------------------------------------
				if (oUtility.IsNonEmpty(o_invoice.sSalesrep_cd))
                {
					sql_str = "SELECT com.* FROM tblARSalesRep rep INNER JOIN tblARCommission com ON (rep.sCommission_cd = com.sCommission_cd)";
					sql_str += " WHERE rep.sSalesrep_cd = '" + o_invoice.sSalesrep_cd + "'";
					if (comm_set.CreateSnapshot(sql_str) == false)
                    {
						return false;
                    }
					if (comm_set.EOF())
                    {
						return false;
                    }
					o_invoice.oCommission.InitCommission(cur_set.iField("iTransaction_typ"), cur_set.iField("iTransaction_num"));
					o_invoice.oCommission.mInvoice_amt = o_invoice.mTaxable_amt + o_invoice.mNonTaxable_amt;
					o_invoice.oCommission.iStatus_typ = o_invoice.iStatus_typ;
					o_invoice.oCommission.iApply_dt = o_invoice.iApply_dt;
					o_invoice.oCommission.iEntry_dt = o_invoice.iEntry_dt;
					o_invoice.oCommission.bPaid_fl = (o_invoice.mDue_amt <= 0);
					o_invoice.oCommission.AddCommission(cur_set.sField("sSalesrep_cd"), comm_set.mField("fCommission_amt"), comm_set.iField("iCommission_typ"));
				}

				// --------------------------------------------------------------------------------------------------
				// PAYMENT SCHEDULE SECTION
				// --------------------------------------------------------------------------------------------------
				if (contract_amt > 0 && cur_db.uSecurity.bLockRentalAtBilling_fl)
				{
					i = (int)(contract_amt / cur_set.mField("mDue_amt"));
				}
				else
                {
					i = 1;
                }

				oUtility.ResizeDim(ref o_invoice.sSplitPayment, GlobalVar.goConstant.SPLIT_PAYMENT_TOTAL_DETAIL_COL, i - 1);

				// FIRST PAYMENT DUE -----
				//  If the amount paid is at least as much as the amount the system suggests, use it.
				//  Otherwise, the first month due should be the one suggested by the system
				//
				if (cur_set.mField("mPaid_amt") >= CalculateFirstMonthDue(ref cur_db, cur_set.iField("iContractBegin_dt"), cur_set.iField("iContractEnd_dt"), cur_set.mField("mDue_amt")))
                {
					o_invoice.sSplitPayment[GlobalVar.goConstant.SPLIT_PAYMENT_TOTAL_AMOUNT_COL, 0] = cur_set.mField("mPaid_amt").ToString();
					o_invoice.sSplitPayment[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, 0] = cur_set.mField("mPaid_amt").ToString();

					remaining_amt = contract_amt - cur_set.mField("mPaid_amt");     // After the first one.
				}
				else
                {
					decimal first_month_amt = CalculateFirstMonthDue(ref cur_db, cur_set.iField("iContractBegin_dt"), cur_set.iField("iContractEnd_dt"), cur_set.mField("mDue_amt"));

					o_invoice.sSplitPayment[GlobalVar.goConstant.SPLIT_PAYMENT_TOTAL_AMOUNT_COL, 0] = first_month_amt.ToString();
					o_invoice.sSplitPayment[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, 0] = first_month_amt.ToString();

					remaining_amt = contract_amt - first_month_amt;					// After the first one.
				}

				o_invoice.sSplitPayment[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, 0] = o_gen.ToStrDate(due_date);
				o_invoice.sSplitPayment[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_DATE_COL, 0] = "0";
				o_invoice.sSplitPayment[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_AMOUNT_COL, 0] = "0";

				if (remaining_amt > 0)
                {
					// If the contract starts in the middle of month, adjust  the next invoice date
					// 
					if (invoice_date % 100 > 1 && i > 1)
					{
						next_due_date = (due_date / 100) * 100 + 1;
						next_due_date = oUtility.AddToDate(GlobalVar.goConstant.MONTH_TYPE, next_due_date, 1);  // will skip the current & next month
					}
					else
					{
						next_due_date = due_date;
					}

					for (row_num = 1; row_num < i; row_num++)
					{
						o_invoice.sSplitPayment[GlobalVar.goConstant.SPLIT_PAYMENT_TOTAL_AMOUNT_COL, row_num] = (remaining_amt / (i - 1)).ToString();
						o_invoice.sSplitPayment[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_DATE_COL, row_num] = o_gen.ToStrDate(oUtility.AddToDate(GlobalVar.goConstant.MONTH_TYPE, next_due_date, row_num));
						o_invoice.sSplitPayment[GlobalVar.goConstant.SPLIT_PAYMENT_DUE_AMOUNT_COL, row_num] = (remaining_amt / (i - 1)).ToString();
						o_invoice.sSplitPayment[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_DATE_COL, row_num] = "0";
						o_invoice.sSplitPayment[GlobalVar.goConstant.SPLIT_PAYMENT_DISCOUNT_AMOUNT_COL, row_num] = "0";
					}
				}

				o_invoice.oCommission.InitCommission(GlobalVar.goConstant.TRX_INVOICE_TYPE, invoice_num);

				if (o_invoice.SaveTransaction(ref empty_set) == false)
                {
					return false;
                }

                if (MarkComplete(ref cur_db, ref cur_set, month_invoiced) == false)
                {
                    return false;
                }

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CreateInvoice)");
			}

			return return_value;

		}

		private bool SendEmail(ref clsDatabase cur_db, ref clsRecordset cur_set, int invoice_num)
		{

			bool return_value = false;
			clsReportViewer cur_report = new clsReportViewer();
			string pdf_file_name = "";
			string sql_str = "";
			string report_name = "";
			clsMail o_mail = new clsMail(ref cur_db);
			string mail_topic = "";
			string mail_text = "";

			try
			{

				if (oUtility.IsEmpty(cur_db.sSMTPServer_nm) || oUtility.IsEmpty(cur_db.sEmailAddress))
				{
					return true;
				}

                cur_report.InitReport(oUtility.GetServerName(ref cur_db), oUtility.GetDatabaseName(ref cur_db), oUtility.GetDBUser(ref cur_db, GlobalVar.goConstant.SYSTEM_USER_ID), oUtility.GetDBPassword(ref cur_db, GlobalVar.goConstant.SYSTEM_USER_PASSWORD), cur_db.uDirectory.sPDFDirectory_nm, true, GlobalVar.gbUsePDFFileForReport_fl);

				report_name = modCommonReportUtility.GetInvoiceReportFileName(ref cur_db, GlobalVar.goARConstant.INVOICE_TYPE_LI1);

				sql_str = "{tblARChargeUnposted.iTransaction_typ} = " + GlobalVar.goConstant.TRX_INVOICE_TYPE.ToString();
				sql_str += " and {tblARChargeUnposted.iTransaction_num} = " + invoice_num.ToString();

				cur_report.SetSelectionFormula(sql_str);
				cur_report.SetFileName(report_name, oUtility.GetCustomReportFolder(ref cur_db));

				if (!modCommonReportUtility.SetCompanyInReport(ref cur_db, "frmQuickPrintInvoice", ref cur_report))
				{
					return false;
				}
				if (!cur_report.PrintReport(ref cur_db, GlobalVar.goConstant.PRINT_TO_PDF, ref pdf_file_name))
				{
					return return_value;
				}

				// pdf_file_name = cur_report.GetPDFFileName();

				if (oUtility.IsEmpty(pdf_file_name))
				{
					return return_value;
				}

				mail_topic = "Rental Invoice from " + cur_db.sCompany_nm;

				mail_text = " Hi " + cur_set.sField("sContact_nm");
				mail_text += "\n";
				mail_text += "\n" + "Please, find attached is the invoice for your rental contract(" + cur_set.iField("iTransaction_num").ToString() + ")";
				mail_text += "\n";
				mail_text += "\n" + "Best Regards,";
				mail_text += "\n";
				mail_text += "\n" + cur_db.sCompany_nm;

				if (!o_mail.SendMail(mail_text, mail_topic, cur_db.sEmailAddress, cur_set.sField("sContactEmailAddress"), pdf_file_name))
				{
					return return_value;
				}

				modGeneralUtility.RunEvents();

				GlobalVar.goFile.Remove(pdf_file_name);

				return_value = true;

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(SendEmail)");

			}

			return return_value;

		}

		private bool MarkComplete(ref clsDatabase cur_db, ref clsRecordset cur_set, int invoice_date)
		{

			bool return_value = false;
			string sql_str = "";
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			try
			{
				sql_str = "UPDATE tblFARental SET";
				sql_str += " iLastBilled_dt = " + ((invoice_date / 100) * 100 + 1) .ToString();		// Make sure in the format of yyyymm01
				sql_str += " WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_FA_RENTAL_TYPE.ToString() + " AND iTransaction_num = " + cur_set.iField("iTransaction_num").ToString();

				return_value = cur_db.ExecuteSQL(sql_str);

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(MarkComplete)");

			}

			return return_value;

		}

		private bool CreateHistory(ref clsDatabase cur_db, int billing_id, int invoice_date, int due_date, string billing_cycle, bool do_not_email_invoice_fl, string lease_list)
		{

			bool return_value = false;
			string sql_str = "";

			try
			{

				sql_str = "INSERT INTO tblFABillingHistory (";
				sql_str += "iTransaction_typ";
				sql_str += ",iEntry_dt";
				sql_str += ",iInvoice_dt";
				sql_str += ",iInvoiceDue_dt";
				sql_str += ",iEmailInvoice_fl";
				sql_str += ",sBillingCycle_cd";
				sql_str += ",sBillingList";
				sql_str += ",iBilling_id";
				sql_str += ",dtLastUpdate_dt";
				sql_str += ",sLastUpdate_id";
				sql_str += ") VALUES (";
				sql_str += GlobalVar.goConstant.TRX_FA_RENTAL_TYPE.ToString();
				sql_str += "," + oUtility.SFormat(DateTime.Now, "yyyyMMdd");
				sql_str += "," + ((invoice_date / 100) * 100 + 1).ToString();       // Make sure in the format of yyyymm01
				sql_str += "," + due_date.ToString();
				sql_str += "," + oUtility.IIf(do_not_email_invoice_fl, "0", "1");
				sql_str += ",'" + billing_cycle + "'";
				sql_str += ",'" + oUtility.SLeft(lease_list, 255) + "'";
				sql_str += "," + billing_id.ToString();
				sql_str += "," + cur_db.CreateDatetimeValue(DateTime.Now);
				sql_str += ",'" + cur_db.sUser_cd + "'";
				sql_str += ")";

				return_value = cur_db.ExecuteSQL(sql_str);

			}
			catch (Exception ex)
			{

				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CreateHistory)");

			}

			return return_value;

		}

		public int GetLastInvoiceDate(ref clsDatabase cur_db, string billing_cycle)
		{

			int return_value = 0;
			string sql_str = "";
			clsRecordset cur_set = new clsRecordset(ref cur_db);

			sql_str = "SELECT MAX(iInvoice_dt) AS iMax FROM tblFABillingHistory WHERE iTransaction_typ = " + GlobalVar.goConstant.TRX_FA_RENTAL_TYPE.ToString() + " AND sBillingCycle_cd = '" + billing_cycle + "'";
			if (!cur_set.CreateSnapshot(sql_str))
			{
				return return_value;
			}
			else if (cur_set.EOF())
			{
				return return_value;
			}

			return_value = cur_set.iField("iMax");
			return return_value;

		}

		public bool CreateCashReceipt(ref clsDatabase cur_db, int contract_num, int journal_type, decimal payment_amt, int payment_type, int entry_date, string customer_code
			, string customer_name, string cash_acct_code, string document_num)
		{
			bool return_value = false;
			int trx_num = 0;

			clsCashReceipt o_receipt = new clsCashReceipt(ref cur_db);
			clsRecordset cur_set = new clsRecordset(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);

			try
			{
				trx_num = o_gen.GetNextNumber(GlobalVar.goConstant.TRX_RECEIPT_TYPE);

				if (trx_num <= 0)
				{
					return false;
				}

				o_receipt.bNew_fl = true;
				o_receipt.iJournal_typ = journal_type;
				o_receipt.iTransaction_typ = GlobalVar.goConstant.TRX_RECEIPT_TYPE;
				o_receipt.iTransaction_num = trx_num;
				o_receipt.iStatus_typ = GlobalVar.goConstant.OPEN_TRX_NUM;
				o_receipt.iCash_typ = payment_type;
				o_receipt.iApply_dt = entry_date;
				o_receipt.iEntry_dt = entry_date;
				o_receipt.mPaid_amt = payment_amt;
				o_receipt.mUsed_amt = 0;
				o_receipt.sCustomer_cd =customer_code;
				o_receipt.sDescription = "From Rental";
				o_receipt.sReference = "Rental";
				o_receipt.sCashAcct_cd = cash_acct_code;
				o_receipt.sDocument_num = document_num;
				o_receipt.sOnDocument_nm = "";
				o_receipt.sUserApproved_cd = "";
				o_receipt.iToApprove_num = 0;
				o_receipt.sCustomer_nm = customer_name;
				o_receipt.iImported_fl = 0;
				o_receipt.iSource_typ = GlobalVar.goConstant.TRX_FA_RENTAL_TYPE;
				o_receipt.iSource_num = contract_num;

				o_receipt.sCreator_id = cur_db.sUser_cd;
				o_receipt.sLastUpdate_id = cur_db.sUser_cd;
				o_receipt.dtLastUpdate_dt = DateTime.Now;

				if (o_receipt.SaveTransaction(ref cur_set) == false)
				{
					return false;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CreateCashReceipt)");
			}

			return return_value;
		}

		public decimal CalculateFirstMonthDue(ref clsDatabase cur_db,int contract_begin_dt, int contract_end_dt, decimal monthly_due_amt)
		{
			int total_days = 0;
			decimal first_month_due = 0;

			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsMoney o_monney = new clsMoney(ref cur_db);

			try
			{
				if (contract_begin_dt == 0)
				{
					first_month_due = monthly_due_amt;
				}
				else if ((contract_begin_dt % 100) > 1)
				{
					total_days = oUtility.DaysInMonth(Convert.ToDateTime(o_gen.ToStrDate(contract_begin_dt)).Year, Convert.ToDateTime(o_gen.ToStrDate(contract_begin_dt)).Month);

					first_month_due = monthly_due_amt + monthly_due_amt * (total_days - (contract_begin_dt % 100) + 1) / total_days;
				}
				else if (cur_db.iFirstPayment_pc > 0)
				{
					first_month_due = monthly_due_amt * cur_db.iFirstPayment_pc / 100;
				}
				else
                {
					first_month_due = monthly_due_amt;
				}

			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CalculateFirstMonthDue)");
			}

			return o_monney.RoundToMoney(first_month_due);
		}

		public bool CreateCreditMemo(ref clsDatabase cur_db, ref clsRecordset cur_set, int entry_date, int invoice_num, decimal credit_amt, decimal free_months)
        {
			bool return_value = false;
			int memo_num = 0;
			string str_memo_num = "";

			clsCreditMemo o_memo = new clsCreditMemo(ref cur_db);
			clsGeneral o_gen = new clsGeneral(ref cur_db);
			clsMoney o_money = new clsMoney(ref cur_db);

			try
            {
				memo_num = o_gen.GetNextNumber(GlobalVar.goConstant.TRX_CM_TYPE);

				if (memo_num <= 0)
				{
					return false;
				}

				credit_amt = o_money.RoundToMoney(credit_amt);
				str_memo_num = o_gen.GetFormatedDocumentNumber(GlobalVar.goConstant.TRX_CM_TYPE, invoice_num.ToString());

				// --------------------------------------------------------------------------------------------------
				// HEADER SECTION
				// --------------------------------------------------------------------------------------------------
				o_memo.iTransaction_typ = GlobalVar.goConstant.TRX_CM_TYPE;
				o_memo.iTransaction_num = memo_num;
				o_memo.iStatus_typ = GlobalVar.goConstant.OPEN_TRX_NUM;
				o_memo.iOrder_num = invoice_num;
				o_memo.iJournal_typ = clsConstant.JOURNAL_RETURN_CREDIT_TYPE_NUM;
				o_memo.sJob_cd = "";
				o_memo.sYourReference = o_gen.GetFormatedDocumentNumber(GlobalVar.goConstant.TRX_FA_RENTAL_TYPE, cur_set.iField("iTransaction_num").ToString());
				o_memo.sReference = "EQUIP.RENTAL";
				o_memo.sLocation_cd = o_gen.GetDefaultLocationCode("");
				o_memo.sDunn_cd = "";
				o_memo.sComment = "";
				o_memo.sTax_cd = o_gen.GetARNoTaxCode();

				if (oUtility.IsEmpty(o_memo.sTax_cd))
                {
					modDialogUtility.DisplayBox(ref cur_db, "Zero-tax code is not found in A/R tax table. (CreateCreditMemo)");
					return false;
				}

				o_memo.iEntry_dt = entry_date;
				o_memo.iRequired_dt = entry_date;
				o_memo.iApply_dt = entry_date;
				o_memo.sCustomer_cd = cur_set.sField("sCustomer_cd");
				o_memo.sCustomer_nm = cur_set.sField("sCustomer_nm");
				o_memo.sCustomerAttn = cur_set.sField("sContact_nm");
				o_memo.sCustomerAddress1 = cur_set.sField("sAddress1");
				o_memo.sCustomerAddress2 = cur_set.sField("sAddress2");
				o_memo.sCustomerAddress3 = cur_set.sField("sAddress3");
				o_memo.sVia_cd = "";
				o_memo.sPrice_cd = "";
				o_memo.sSalesrep_cd = "";
				o_memo.sTerms_cd = "";
				o_memo.fWeight = 0;
				o_memo.fTax_pc = 0;
				o_memo.mNonTaxable_amt = credit_amt;
				o_memo.mTaxable_amt = 0;
				o_memo.mTax_amt = 0;
				o_memo.mDiscount_amt = 0;
				o_memo.mFreight_amt = 0;
				o_memo.mTotal_amt = credit_amt;       // cur_set.mField("mSubTotal_amt") + cur_set.mField("mTax_amt"); // mSubTotal_amt carrys the detail total only.
				o_memo.mPaid_amt = 0;
				o_memo.mDue_amt = credit_amt;
				o_memo.sCreator_id = "AUTO";
				o_memo.sPosting_cd = cur_set.sField("sPosting_cd");
				o_memo.sShipToFax = "";
				o_memo.sShipToPhone = "";
				o_memo.sShipToCountry_cd = "";
				o_memo.sShipToZipCode = "";
				o_memo.sShipToState = "";
				o_memo.sShipToCity = "";
				o_memo.sShipTo_cd = "";
				o_memo.iBatch_num = 0;
				o_memo.sShipToAttn = cur_set.sField("sContact_nm");
				o_memo.sShipToAddress3 = cur_set.sField("sAddress3");
				o_memo.sShipToAddress2 = cur_set.sField("sAddress2");
				o_memo.sShipToAddress1 = cur_set.sField("sAddress1");
				o_memo.sShipTo_nm = cur_set.sField("sCustomer_nm");
				o_memo.sTransaction_num = str_memo_num;
				o_memo.sLastUpdate_id = cur_set.sField("sLastUpdate_id");
				o_memo.dtLastUpdate_dt = DateTime.Now;
				o_memo.sUserApproved_cd = "";
				o_memo.iToApprove_num = 0;
				o_memo.sFund_cd = "";
				o_memo.mFreightTax_amt = 0;
				o_memo.iSource_typ = cur_set.iField("iTransaction_typ");
				o_memo.iSource_num = cur_set.iField("iTransaction_num");

				oUtility.ResizeDim(ref o_memo.sDetailData, clsCreditMemo.TOTAL_COLUMNS, 1);

				o_memo.sDetailData[clsInvoice.DESCRIPTION_COL, 0] = "Credit for the initial " + oUtility.RemoveTrailingZeros(free_months.ToString()) + " months";
				o_memo.sDetailData[clsInvoice.UNIT_CODE_COL, 0] = "";
				o_memo.sDetailData[clsInvoice.QTY_SHIPPED_COL, 0] = "1";
				o_memo.sDetailData[clsInvoice.QTY_ORDERED_COL, 0] = "1";
				o_memo.sDetailData[clsInvoice.QTY_BACKORDER_COL, 0] = "0";
				o_memo.sDetailData[clsInvoice.UNIT_PRICE_COL, 0] = credit_amt.ToString();
				o_memo.sDetailData[clsInvoice.AMT_EXTENDED_COL, 0] = credit_amt.ToString();
				o_memo.sDetailData[clsInvoice.TAX_CODE_COL, 0] = o_memo.sTax_cd;
				o_memo.sDetailData[clsInvoice.TAX_PERC_COL, 0] = "";
				o_memo.sDetailData[clsInvoice.AMT_TAX_COL, 0] = "";
				o_memo.sDetailData[clsInvoice.ITEM_TYPE_COL, 0] = GlobalVar.goIVConstant.SERVICE_ITEM_NUM.ToString();
				o_memo.sDetailData[clsInvoice.LINE_ID_COL, 0] = "1";

				cur_set.Release();
				if (o_memo.SaveTransaction(ref cur_set) == false)
				{
					return false;
				}

				return_value = true;
			}
			catch (Exception ex)
			{
				modDialogUtility.DisplayBox(ref cur_db, ex.Message + "(CreateCreditMemo)");
			}

			return return_value;
		}
	}

}
