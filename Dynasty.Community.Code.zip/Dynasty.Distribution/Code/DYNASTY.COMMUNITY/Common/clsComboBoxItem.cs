﻿//  Copyright (c) DynastySoft Corporation, 2009.  All Worldwide rights reserved.
//  Modification and distribution of this source code without prior written
//  approval from the manufacturer is strictly prohibited by the International
//  Copyright Law.
//



using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace Dynasty.Database
{
	public class clsComboBoxItem
	{

		private string sText; // Visual text
		private string sValue; // Actual data value

		public clsComboBoxItem(string item_text, string item_value) : base()
		{
			this.sText = item_text;
			this.sValue = item_value;
		}

		public string Value
		{
			get
			{
				return sValue;
			}
		}

		public string Text
		{
			get
			{
				return sText;
			}
		}

		public override string ToString()
		{

			string return_value = null;

			return this.Value + " - " + this.Text;
			return return_value;

		}

	}

}
