
function ShowAlert(msg) {

    alert(msg);

}

function ShowMessage(control_name, msg, error_fl) {

    try {

        var element = document.getElementById(control_name);

        if (msg == null || msg == '') {
            element.innerText = "";
            element.style.display = 'none';
            return true;
        }

        element.style.display = '';
        element.innerText = msg;

        if (error_fl == null || error_fl == false) {
            // element.style.backgroundColor = 'lightgreen';
            element.style.border = "thin solid green";
            element.style.Color = 'royalblue';
        }
        else {
            //element.style.backgroundColor = 'lightpink';
            element.style.border = "thin solid red";
            element.style.Color = 'red';
        }

        return true;

    }
    catch (err) {
        return true;
    }
}

function IsEmpty(cur_value) {

    try {

        if (cur_value == null || cur_value.length == 0) {
            return true;
        }
        else {
            return false;
        }

    }
    catch (err) {
        return true;
    }

}

function ToNumeric(cur_value) {

    var return_value = 0;

    try {

        if (cur_value == null || cur_value.length == 0) {

            return_value = 0;

        }
        else {

            // When a number is very small and comes in with exponent such as 4.55e-13, accounting.unformat() will show all numbers before "e".  i.e., 4.55e-13 will be interpreted as 4.55.
            //
            if (Math.abs(cur_value) < 0.000001) {
                return_value = 0;
            }
            else {
                return_value = Number(accounting.unformat(cur_value));
            }

        }

    }
    catch (err) {

        ShowAlert(err);
        return_value = 0;

    }

    return return_value;

}

function IsValidInteger(cur_cell, negative_allowed) {

    var maxlength = 13;
    var new_val = '';
    var i = 0;
    var tmp = 0;
    var sign_char = '';

    if (negative_allowed == null) {
        negative_allowed = true;        
    }

    if (cur_cell.value.length == 0) {
        return true;
    }

    if (cur_cell.value.substring(0, 1) == '-') {

        if (negative_allowed == false) {
            ShowAlert("Negative value is not allowed.");
            cur_cell.value = '';
            return false;
        }

        sign_char = '-';
    }

    while (i <= cur_cell.value.length - 1) {
        if (cur_cell.value.substring(i, i + 1) >= '0' && cur_cell.value.substring(i, i + 1) <= '9') {
            new_val += cur_cell.value.substring(i, i + 1);
        }
        i++;
    }

    if (new_val.length > maxlength) {
        cur_cell.value = "";
        ShowAlert(" Only " + maxlength + " numbers are allowed.");
        return false;
    }

    cur_cell.value = sign_char + new_val;
    return true;

}

function IsValidSmallInteger(cur_cell, negative_allowed) {

    var maxlength = 8;

    if (IsValidInteger(cur_cell, negative_allowed) == false) {
        return false;
    }
    else if (new_val.length > maxlength) {
        cur_cell.value = "";
        ShowAlert(" Only " + maxlength + " numbers are allowed.");
        return false;
    }

    return true;
}

function IsValidFloat(cur_cell) {

    var maxlength = 13;
    var new_val = '';
    var i = 0;
    var found = 0;
    var decimal_pt = '.';
    var thousand_pt = ',';
    var sign_char = '';
    var money_type = 0; 

    try {
        money_type = document.getElementById('txtMoney_typ').value;
    }
    catch (er) {
        money_type = 1;         // In case txtMoney_typ is not implemenetd, use the default type
    }

    if (cur_cell.value.length == 0) {
        return true;
    }

    // EURO type
    if (money_type == 5) {
        decimal_pt = ',';
        thousand_pt = '.'
    }

    if (cur_cell.value.substring(0, 1) == '-') {
        sign_char = '-';
    }

    while (i <= cur_cell.value.length - 1) {
        if ((cur_cell.value.substring(i, i + 1) >= '0' && cur_cell.value.substring(i, i + 1) <= '9') || cur_cell.value.substring(i, i + 1) == decimal_pt) {
            if (found == 1 && cur_cell.value.substring(i, i + 1) == decimal_pt) {
                break;
            }
            new_val += cur_cell.value.substring(i, i + 1);
            if (cur_cell.value.substring(i, i + 1) == decimal_pt) {
                found = 1;
            }
        }
        i++;
    }

    if (new_val.length > maxlength) {
        cur_cell.value = "";
        ShowAlert(" Only " + maxlength + " numbers are allowed.");
        return false;
    }

    new_val = sign_char + new_val;

    if (new_val == '-' || new_val == '+' || new_val == '.' || new_val == ',') {
        new_val = '';
    }

    cur_cell.value = new_val;
    return true;

}

function IsValidQuantity(cur_cell, negative_allowed) {
    
    if (negative_allowed == null) {
        negative_allowed = false;        // for qty, false is default
    }

    if (cur_cell == null) {
        return false;
    }
    else if (!IsValidFloat(cur_cell)) {
        cur_cell.value = '';
        return false;
    }
    else if ((ToNumeric(cur_cell.value) < 0) && (!negative_allowed)) {
        ShowAlert("Negative quantity is not allowed.");
        cur_cell.value = '';
        return false;
    }

    return true;

}

function SmallestMoney() {

    var return_value = 0;
    var money_type = 0;

    try {
        money_type = document.getElementById('txtMoney_typ').value;
    }
    catch (er) {
        money_type = 1;         // In case txtMoney_typ is not implemenetd, use the default type
    }

    if (money_type == 1) {
        return_value = 0.01;
    }
    else if (money_type == 2) {
        return_value = 0;
    }
    else if (money_type == 3) {
        return_value = 0;
    }
    else if (money_type == 4) {
        return_value = 0;
    }
    else {
        return_value = 0.01;
    }

    return return_value;

}

function SmallestNumber() {

    return 0.0001;

}

function IsValidMoney(cur_cell, negative_allowed, integer_only) {

    var maxlength = 13;
    var new_val = '';
    var i = 0;
    var found = 0;
    var decimal_pt = '.';
    var thousand_pt = ',';
    var cur_value = 0.0 ;
    var money_type = 0;
    
    if (negative_allowed == null) {
        negative_allowed = true;        // true is default
    }

    try {
        money_type = document.getElementById('txtMoney_typ').value;
    }
    catch (er) {
        money_type = 1;         // In case txtMoney_typ is not implemenetd, use the default type
    }

    if (integer_only) {
        money_type = 2;         // integer portion only
    }

    // When a number is very small and comes in with exponent such as 4.55e-13, accounting.unformat() will show all numbers before "e".  i.e., 4.55e-13 will be interpreted as 4.55.
    //
    if (Math.abs(cur_cell.value) < 0.0001) {
        cur_value = 0;
    }
    else {
        cur_value = accounting.unformat(cur_cell.value);
    }

    if (cur_value.length == 0) {
        return true;
    }
    else if (cur_value.length > maxlength) {
        ShowAlert(" Only " + maxlength + " numbers are allowed. (" + cur_value.value + ")");
        cur_cell.value = "";
        return false;
    }
    else if (money_type == 1) {
        cur_value = accounting.formatMoney(cur_value, "", 2, ",", "."); // 9,999.99
    }
    else if (money_type == 2) {
        cur_value = accounting.formatMoney(cur_value, "", 0, ",", ""); // 9,999
    }
    else if (money_type == 3) {
        cur_value = accounting.formatMoney(cur_value, "", 3, ",", "."); // 9,999.999
    }
    else if (money_type == 4) {
        cur_value = accounting.formatMoney(cur_value, "", 0, ",", ""); // 9,999  should be 9,9999 but it does not offer this format
    }
    else {
        cur_value = accounting.formatMoney(cur_value, "", 2, ".", ","); // 4.999,99
    }

    if ((cur_value < 0) && (!negative_allowed)) {
        cur_cell.value = "";
        ShowAlert("Negative amount is not allowed.");
        return false;
    }

    cur_cell.value = cur_value;

    return true;

}

function MMDDYYYY() {
    return 1;               // American date type
}

function DDMMYYYY() {
    return 2;               // European date type
}

function YYYYMMDD() {
    return 3;               // Asian date type
}

// Validate the date enterred.
function IsValidDate(date_passed) {

    if (date_passed.value.length == 0) {
        return false;
    }

    var date_type = document.getElementById('txtDate_typ').value;

    // MMDDYYYY : 1
    // DDMMYYYY : 2
    // YYYYMMDD : 3

    var cur_date = new Date();
    var date_passed_value = date_passed.value;

    var day = 0;
    var month = cur_date.getMonth() + 1;
    var year = cur_date.getFullYear();
    var str_day = '';
    var str_month = '';
    var str_year = '';

    if (date_passed_value.indexOf("/") >= 0) {

        var parts = date_passed_value.split("/");

    }
    else if (date_passed_value.indexOf("-") >= 0) {

        var parts = date_passed_value.split("-");

    }
    else {

        if (date_passed_value.length <= 2) {
            var parts = [parseInt(date_passed_value)];
        }
        else if (date_passed_value.length == 4) {
            var parts = [parseInt(date_passed_value.substring(0, 2)), parseInt(date_passed_value.substring(2, 4))]
        }
        else if (date_passed_value.length == 6) {
            var parts = [parseInt(date_passed_value.substring(0, 2)), parseInt(date_passed_value.substring(2, 4)), parseInt(date_passed_value.substring(4))]
        }
        else if (date_passed_value.length == 8) {
            if (date_type == YYYYMMDD()) {
                var parts = [parseInt(date_passed_value.substring(0, 4)), parseInt(date_passed_value.substring(4, 6)), parseInt(date_passed_value.substring(6))]        
            }
            else {
                var parts = [parseInt(date_passed_value.substring(0, 2)), parseInt(date_passed_value.substring(2, 4)), parseInt(date_passed_value.substring(4))]        // mmddyyyy or ddmmyyyy
            }
        }
        else {
            ShowAlert('Invalid date is entered(101).');
            date_passed.value = '';
            date_passed.focus();
            return false;
        }

    }

    if (parts.length <= 1) {
        day = parseInt(parts[0], 10);
    }
    else if (parts.length == 2) {
        if (date_type == DDMMYYYY()) {
            day = parseInt(parts[0], 10);
            month = parseInt(parts[1], 10);
        }
        else {
            month = parseInt(parts[0], 10);
            day = parseInt(parts[1], 10);
        }
    }
    else if (parts.length == 3) {
        if (date_type == YYYYMMDD()) {
            year = parseInt(parts[0], 10);
            month = parseInt(parts[1], 10);
            day = parseInt(parts[2], 10);
        }
        else if (date_type == DDMMYYYY()) {
            day = parseInt(parts[0], 10);
            month = parseInt(parts[1], 10);
            year = parseInt(parts[2], 10);
        }
        else {
            month = parseInt(parts[0], 10);
            day = parseInt(parts[1], 10);
            year = parseInt(parts[2], 10);
        }
    }
    else {
        ShowAlert('Invalid date is entered(110).');
        date_passed.value = '';
        date_passed.focus();
        return false;
    }

    //  Next three IF statements are necessary to filter out the non-numeric chars.
    //  Exceptional chars will fall into ELSE clause.
    if (year >= 2000 && year < 3000) {
        year = year;
    }
    else if (year >= 1 && year < 100) {
        year = (parseInt(cur_date.getFullYear() / 100) * 100) + year;
    }
    else if (year == 0) {
        year = cur_date.getFullYear();
    }
    else {
        ShowAlert('Invalid date is entered(120).');
        date_passed.value = '';
        date_passed.focus();
        return false;
    }

    if (month >= 1 && month <= 12) {
        month = month;
    }
    else if (month == 0) {
        month = cur_date.getMonth() + 1;
    }
    else {
        ShowAlert('Invalid date is entered(130).');
        date_passed.value = '';
        date_passed.focus();
        return false;
    }

    if (day >= 1 && day <= 31) {
        day = day;
    }
    else if (day == 0) {
        day = cur_date.getDate();
    }
    else {
        ShowAlert('Invalid date is entered(140).');
        date_passed.value = '';
        date_passed.focus();
        return false;
    }

    // Check the ranges of month and year
    if (year < 1000 || year > 3000 || month == 0 || month > 12) {
        ShowAlert('Invalid date is entered(150).');
        date_passed.value = '';
        date_passed.focus();
        return false;
    }

    var monthLength = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    // Adjust for leap years
    if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0)) {
        monthLength[1] = 29;
    }

    // Check the range of the day
    if (day <= 0 || day > monthLength[month - 1]) {
        ShowAlert('Invalid date is entered(160).');
        date_passed.value = '';
        date_passed.focus();
        return false;
    }

    str_year = Right('0' + year, 4);
    str_month = Right('0' + month, 2);
    str_day = Right('0' + day, 2);

    if (date_type == YYYYMMDD()) {
        date_passed.value = str_year + '/' + str_month + '/' + str_day;
    }
    else if (date_type == DDMMYYYY()) {
        date_passed.value = str_day + '/' + str_month + '/' + str_year;
    }
    else {
        date_passed.value = str_month + '/' + str_day + '/' + str_year;
    }

    return true;

}

function Left(str, n) {
    if (n <= 0)
        return "";
    else if (n > String(str).length)
        return str;
    else
        return String(str).substring(0, n);
}

function Right(str, n) {
    if (n <= 0)
        return "";
    else if (n > String(str).length)
        return str;
    else {
        var iLen = String(str).length;
        return String(str).substring(iLen - n, iLen);
    }
}

function ClearTextbox(field_name_passed) {

    document.getElementById(field_name_passed).value = '';
    return true;

}

function ClearLabel(field_name_passed) {

    document.getElementById(field_name_passed).innerHTML = "";
    return true;

}

function SetFocus(field_name_passed) {

    if (field_name_passed == null ||field_name_passed == '') {
        return false;
    }

    try
    {
        document.getElementById(field_name_passed).focus();
    }
    catch (err)
    {
        // let it go
    }

    return true;

}

function ValidDateSetFocus(date_passed, field_name_to_focus) {

    if (date_passed == null || date_passed == '') {
        return false;
    }

    if (field_name_to_focus == null || field_name_to_focus == '') {
        return false;
    }

    if (IsValidDate(date_passed) == true) {
        SetFocus(field_name_to_focus);
    }

    return true;

}

function toggleFullScreen(elem, do_not_toggle) {

    // In order to invoke this, use OnClientClick="toggleFullScreen(document.body)" on any server control such as button.
    // Currently used in Dynasty.Mobile.
    //
    // Background color defaults to black.  In order to change it, use <div style="position:fixed; left:0; top: 0; width:100%; height:100%; background:white">
    //
    // ## The below if statement seems to work better ## if ((document.fullScreenElement && document.fullScreenElement !== null) || (document.msfullscreenElement && document.msfullscreenElement !== null) || (!document.mozFullScreen && !document.webkitIsFullScreen)) {
    if ((document.fullScreenElement !== undefined && document.fullScreenElement === null) || (document.msFullscreenElement !== undefined && document.msFullscreenElement === null) || (document.mozFullScreen !== undefined && !document.mozFullScreen) || (document.webkitIsFullScreen !== undefined && !document.webkitIsFullScreen)) {
        if (elem.requestFullScreen) {
            elem.requestFullScreen();
        } else if (elem.mozRequestFullScreen) {
            elem.mozRequestFullScreen();
        } else if (elem.webkitRequestFullScreen) {
            elem.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);
        } else if (elem.msRequestFullscreen) {
            elem.msRequestFullscreen();
        }
    } else {

        if (do_not_toggle == true) {
            return true;
        }

        if (document.cancelFullScreen) {
            document.cancelFullScreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.webkitCancelFullScreen) {
            document.webkitCancelFullScreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }
    }
}

function RoundToMoney(cur_value) {
    
    try {

        var money_type = 0;

        try {
            money_type = document.getElementById('txtMoney_typ').value;
        }
        catch (er) {
            money_type = 1;         // In case txtMoney_typ is not implemenetd, use the default type
        }

        if (cur_value.length == 0) {
            return 0;
        }
        else if (money_type == 1) {
            cur_value = accounting.formatMoney(cur_value, "", 2, ",", "."); // 9,999.99
        }
        else if (money_type == 2) {
            cur_value = accounting.formatMoney(cur_value, "", 0, ",", ""); // 9,999
        }
        else if (money_type == 3) {
            cur_value = accounting.formatMoney(cur_value, "", 3, ",", "."); // 9,999.999
        }
        else if (money_type == 4) {
            cur_value = accounting.formatMoney(cur_value, "", 0, ",", ""); // 9,999  should be 9,9999 but it does not offer this format
        }
        else {
            cur_value = accounting.formatMoney(cur_value, "", 2, ".", ","); // 4.999,99
        }

        return ToNumeric(cur_value);

    }
    catch (err) {

        ShowAlert(err);
        return cur_value;

    }
    
}

function RoundToDiscountPerc(cur_value) {
    
    try {

        cur_value = accounting.formatMoney(cur_value, "", 2, ",", ".");     // 9,999.99

        return ToNumeric(cur_value);

    }
    catch (err) {

        ShowAlert(err);
        return cur_value;

    }

}

function UCase(cur_value) {

    try {

        if (cur_value.length == 0) {
            cur_value = '';
        }
        else {
            cur_value = cur_value.toUpperCase();
        }

    }
    catch (err) {
        // let it go.  Sometimes, toUpperCase() raise error
    }

    return cur_value;

}

function CleanCode(cur_value) {

    if (cur_value.length == 0) {
        cur_value = '';
    }
    else {
        cur_value = cur_value.trim();
        cur_value = cur_value.replace("'", "");
        cur_value = cur_value.replace('"', '');
        cur_value = cur_value.replace('_', '');
        cur_value = cur_value.replace('-', '');
        cur_value = cur_value.replace('*', '');
        cur_value = cur_value.replace('&', '');
        cur_value = UCase(cur_value);
    }

    return cur_value;

}

function RoundToQtyFactor(cur_value) {

    try {

        cur_value = accounting.formatMoney(cur_value, "", 2, ",", ".");   // 9,999.99
        return ToNumeric(cur_value);

    }
    catch (err) {

        ShowAlert(err);
        return cur_value;

    }

}

function IsTooLargeDollar(dollar_amt) {

    try {

        return (dollar_amt >= giLARGEST_DOLLAR());

    }
    catch (err) {

        return true;

    }

}

function GetSelectedRadioListValue(cur_control) {

    try {

        var list_values = cur_control.getElementsByTagName('input');
        var selected_value = -1;

        for (var i = 0; i < list_values.length; i++) {
            if (list_values[i].checked) {
                selected_value = ToNumeric(list_values[i].value);
            }
        }

        return selected_value;

    }
    catch (err) {

        return -1;

    }

}

function DisableField(control_name, disable_fl) {

    try {

        var element = document.getElementById(control_name);

        if (disable_fl == null) {
            disable_fl = true;
        }

        element.disabled = disable_fl;

    }
    catch (err)
    {
       //  ShowAlert(err);  Let it go because the field may not be visible yet
    }

    return true;

}

function HideField(control_name, hide_fl) {

    try {

        var element = document.getElementById(control_name);

        if (hide_fl == null) {
            hide_fl = true;
        }

        if (hide_fl) {
            element.style.visibility = "hidden";
        }
        else {
            element.style.visibility = "visible";
        }

    }
    catch (err) {
        // ShowAlert(err);  let it go because the field may not be visible yet
    }

    return true;

}

function SetValue(control_name, field_value) {

    try {

        var element = document.getElementById(control_name);

        if (element == null) {
            return true;
        }
        element.innerText = field_value;
        //element.value = field_value;
        //element.innerHTML = field_value;

        return true;

    }
    catch (err) {
        return true;
    }

}
function GetValue(control_name) {

    try {

        var cell_value = '';

        if (document.getElementById(control_name) != null) {
            cell_value = document.getElementById(control_name).value;
        }

        return cell_value;

    }
    catch (err) {

        return cell_value;

    }

}

function DoNotGoBack() {
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
}

function OpenWindow(page_name) {

    if (page_name == null) {
        return false;
    }

    try {
        window.open(page_name, '_blank');
    }
    catch (err) {
    }

    return true;
}

function isDevice() {
    return /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini|mobile/i.test(navigator.userAgent);
}

window.GetDimensions = function () {
    return {
        width: window.innerWidth,
        height: window.innerHeight
    };
}

function DownloadFromUrl(url, fileName) {

    try
    {
        const anchorElement = document.createElement('a');
        anchorElement.href = url;
        anchorElement.download = fileName;
        anchorElement.click();
        anchorElement.remove();
    }
    catch (err)
    {
        ShowAlert(err);
    }

}


// This will change the image of control passed  *** the control_name should be concatenated with the ContentPlaceHolderID
function ChangeImage(control_name, file_name) {
    document.getElementById(control_name).src = file_name;
}
// MaxLength for multiline textbox does not work so that this will stop the keystroke after the number specified.
function CountText(text_box, long) {
    var maxlength = new Number(long); // Change number to your max length. 
    if (text_box.value.length > maxlength) {
        text_box.value = text_box.value.substring(0, maxlength);
        alert(" Only " + long + " chars are allowed.");
    }
}
// This will change the font color of control passed 
function MasterChangeFontColor(control_name, font_color) {
    document.getElementById(control_name).style.color = font_color;
}

//
// timer and popup for session timeout - values actually come from web.config - script injected from master -->
//
function SessionExpireAlert(timeout) {

    try {
        var seconds = timeout / 1000;
        document.getElementsByName("secondsIdle").innerHTML = seconds;
        document.getElementsByName("seconds").innerHTML = seconds;
        setInterval(function () {
            seconds--;
            document.getElementById("seconds").innerHTML = seconds;     // If you get stopped in this line, read the comments about timeout in Page_Load() of Dynasty.Master.vb.
            document.getElementById("secondsIdle").innerHTML = seconds;
        }, 1000);
        setTimeout(function () {
            //Show Popup in x seconds before timeout.
            //$find("pnlSessionPopup").show();
            var confirmation = window.alert("Session will time out in 1 minute due to inactivity!\n\nPlease save your work!\n\nResuming work will continue your session.");
            //if (confirmation) {
            //  seconds = timeout / 1000;
            //} //else {
            //  seconds = seconds;
            //}
        }, timeout - 60 * 1000);
        setTimeout(function () {
            window.location = "default.aspx";
        }, timeout);
    }
    catch (err) {
        var ex = 0;  // do nothing
    }

};

function GetLocalDate() {

    try {

        var local_date = document.getElementById('txtLocal_dt');
        var date_type = document.getElementById('txtDate_typ').value;

        var local_time = new Date();

        var day = local_time.getDate();
        var month = local_time.getMonth() + 1;
        var year = local_time.getFullYear();
        var str_day = '';
        var str_month = '';
        var str_year = '';

        str_year = Right('0' + year, 4);
        str_month = Right('0' + month, 2);
        str_day = Right('0' + day, 2);

        if (date_type == 3) {
            local_date.value = str_year + '/' + str_month + '/' + str_day;
        }
        else if (date_type == 2) {
            local_date.value = str_day + '/' + str_month + '/' + str_year;
        }
        else {
            local_date.value = str_month + '/' + str_day + '/' + str_year;
        }

    }
    catch (err) {
        var ex = 0;  // do nothing
    }

}



